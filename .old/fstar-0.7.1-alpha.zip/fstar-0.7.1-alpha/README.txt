This is an alpha release of the F* compiler, version 0.5-alpha. You
can find out more about F* from the following website:
http://research.microsoft.com/fstar

**Contents**

0. README.txt
   
   This file.

1. LICENSE*.txt
    
    This software is released under the MSR-LA license. See
    LICENSE-fsharp.txt, LICENSE-proof.txt and LICENSE-js.txt, for
    licenses that also apply to selected sources which this
    compiler uses. 

2. INSTALL.txt
   
     Instructions on how to build, install and test the compiler. 

3. examples/
   
   Several subdirectories underneath examples/ contain example
   programs in F*.
   
    fx:
        Programs translated from the FX language, presented at PLPV '11.

    healthweb-azure: 
        An Azure-deployable model cloud app for managing electronic
        health records.

    higher-order:
        Examples that highlight F*'s ability to do modular
        verification of higher-order programs.

    ibex:
        A suite of verified browser extensions, presented at Oakland '11. 

    misc:
        An illustration of using the refined Hoare state monad in F*
        Also, an example using linear maps.
	And, two examples using the Dijkstra state monad.

    pldi10-benchmarks: 
        Contains the 6 programs reported at PLDI '10 for the Fine, 
        DCIL and rDCIL languages.

    prov:
        Provenance tracking and programming with proofs. 

    sessions:
        Higher-order, dynamic session types encoded in F*

    interop:
	A tiny example showing how to interop between F# and F*

    jsverify:
	A verified library providing runtime support for JavaScript
	programs translated to F*. This makes use of the Dijkstra 
	state monad.

    fromjs: 
       Examples associated with TS*, a gradually typed surface
       language securely embedded in JavaScript.

5. lib/
   
   Standard libraries for F* programs, in source form 

6. bin/

   F* binaries and their dependences
   
7. setenv.sh

   A Cygwin bash script to add FSTAR_HOME to your environment
