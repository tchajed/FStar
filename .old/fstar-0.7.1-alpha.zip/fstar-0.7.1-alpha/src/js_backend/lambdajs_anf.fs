#light "off"
(* Copyright (c) 2009-2010 Arjun Guha and Claudiu Saftoiu *)
module Microsoft.FStar.LambdaJS.ANF

open Microsoft.FStar.JavaScript.Prelude

type anfval =
  | Const of Microsoft.FStar.JavaScript.Syntax.const
  | Id of id
  | Lambda of id list * anfexp

and bindexp =
  | Val of anfval
  | Op1 of Microsoft.FStar.LambdaJS.Syntax.op1 * anfval
  | Op2 of  Microsoft.FStar.LambdaJS.Syntax.op2 * anfval * anfval
  | Object of (string * anfval) list
  | Array of anfval list
  | UpdateField of anfval * anfval * anfval
  | App of anfval * anfval list

and anfexp =
  | Bind of (id * bindexp) list * anfexp
  | Bindrec of (id * anfval) list * anfexp
  | If of anfval * anfexp * anfexp
  | TailApp of anfval * anfval list
  | Return of anfval
  | Throw of anfval

(*
 * Conversion to ANF
 *)


let new_name () : id = mk_name "anf"

type cont = 
  | Cont of (anfval -> anfexp)
  | Jmp of id

let ret cont v = match cont with
  | Cont k -> k v
  | Jmp l -> TailApp (Id l, [ v ])

let bind_cont cont fn = match cont with
  | Jmp l -> fn l
  | Cont k ->
      let k' = new_name () in
      let r = new_name () in
        Bind ([(k', Val (Lambda ([r], k (Id r))))], fn k')

open Microsoft.FStar.LambdaJS.Syntax

let rec anf_exp (exp : exp) (k : cont) : anfexp = match exp with
  | EConst (_, c) -> ret k (Const c)
  | EId (_, x) -> ret k (Id x)
  | EObject (_, fields) ->
      let f_xs = map (fun (_, x, _) -> x) fields in
      let f_es = map (fun (_, _, e) -> e) fields in
      anf_exp_list f_es
        (fun vs ->
           let obj = new_name () in
             Bind ([(obj, Object (List.combine f_xs vs))], ret k (Id obj)))
  | EOp1 (_, op, e) ->
      anf_exp' e
        (fun v -> 
          let x = new_name () in
            Bind ([(x, Op1 (op, v))], ret k (Id  x)))
  | EOp2 (_, op, e1, e2) ->
      anf_exp' e1
        (fun v1 -> 
          anf_exp' e2
            (fun v2 ->
              let x = new_name () in
              Bind ([(x, Op2 (op, v1, v2))], ret k (Id  x))))
  | EIf (_, e1, e2, e3) ->
      anf_exp' e1
        (fun v1 ->
          bind_cont k
            (fun k' ->
              (If (v1, anf_exp e2 (Jmp k'), anf_exp e3 (Jmp k')))))
  | EApp (_, func, args) ->
      anf_exp' func
        (fun f ->
          anf_exp_list args
            (fun vs ->
              let r = new_name () in
               (* TODO: breaks tail calls. Directly translate to TailApp if
                  k is a Jmp. *)
                Bind ([(r, App (f, vs))], ret k (Id r))))
  | ESeq (_, e1, e2) ->
      anf_exp' e1 (fun _ -> anf_exp e2 k)
  | ELet (_, x, e1, e2) ->
      anf_exp' e1
        (fun v ->
          Bind ([(x, Val v)], anf_exp e2 k))
  | EFix (_, binds, body) ->
      Bindrec (map anf_bind binds, anf_exp body k)
  | ELambda (_, xs, e) ->
      ret k (Lambda (xs, anf_exp' e (fun v -> Return v)))
  | EThrow (_, e) ->
    anf_exp' e (fun v -> Throw v)

and anf_bind (x, e) = match e with
  | EConst (_, c) -> (x, Const c)
  | ELambda (_, xs, e) -> (x, Lambda (xs, anf_exp' e (fun v -> Return v)))
  | _ -> failwith "RHS of EFix should be an EConst or ELambda"

and anf_exp_list (exps : exp list) (k : anfval list -> anfexp) = match exps with
  | [] -> k []
  | e :: rest ->
      anf_exp' e (fun v -> anf_exp_list rest (fun vs -> k (v :: vs)))

and anf_exp' e f = anf_exp e (Cont f)

let to_anf (e : exp) : anfexp = anf_exp' e (fun v -> Return v)



open Microsoft.FStar.JavaScript.Syntax

let p = Lexing.Position.Empty


// Pre: s does not have nested blocks
let unblock (s : stmt) : stmt list = match s with
  | BlockStmt (_, ss) -> ss
  | _ -> [s]

// Avoid unnecessary nested blocks. Arguments should not have nested blocks
let rec block (ss : stmt list) : stmt = match List.concat (map unblock ss) with
  | [] -> EmptyStmt p
  | [s] -> s
  | ss' -> BlockStmt (p, ss')

let rec js_anfexp (e : anfexp) : stmt  = match e with
  | Bind (binds, body) ->
      let f (x, be) =   VarDeclStmt (p, [ VarDecl (p, x, js_bindexp be) ]) in
      block ((map f binds) @ [ js_anfexp body ])
  | Bindrec (binds, body) ->
      let f (x, v) =   VarDeclStmt (p, [ VarDecl (p, x, js_anfval v) ]) in
      block ((map f binds) @ [ js_anfexp body ])
  | If (v1, e2, e3) ->
      IfStmt (p, js_anfval v1, js_anfexp e2, js_anfexp e3)
  | TailApp (f, vs) ->
      ReturnStmt (p, CallExpr (p, js_anfval f, map js_anfval vs))
  | Return v ->
      ReturnStmt (p, js_anfval v)
  | Throw v -> ThrowStmt (p, js_anfval v)

and js_bindexp (be : bindexp) : expr = match be with
  | Val v -> js_anfval v
  | Op1 (Op1Prefix op, v) -> PrefixExpr (p, op, js_anfval v)
  | Op2 (Op2Infix op, v1, v2) -> InfixExpr (p, op, js_anfval v1, js_anfval v2)
  | Op2 (UnsafeGetField, v1, v2) -> BracketExpr (p, js_anfval v1, js_anfval v2)
  | Op2 (SetRef, Id x, v) -> 
      AssignExpr (p, OpAssign, VarLValue (p, x), js_anfval v)
  | Object fields -> 
      let f (x, v) = (p, PropString x, js_anfval v) in
      ObjectExpr (p, map f fields)
  | App (f, vs) -> CallExpr (p, js_anfval f, map js_anfval vs)


and js_anfval (v : anfval) : expr = match v with
  | Const c -> ConstExpr (p, c)
  | Id x -> VarExpr (p, x)
  | Lambda (xs, e) -> FuncExpr (p, xs, js_anfexp e)

let to_js (e : anfexp) : stmt = js_anfexp e
