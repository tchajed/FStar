module Microsoft.FStar.JavaScript.Prelude
(* Copyright (c) 2009-2010 Arjun Guha and Claudiu Saftoiu *)

type id = string

let mk_name : string -> id = 
  let next_name = ref 0 in
    fun str ->
      incr next_name;
      str ^ string_of_int (!next_name - 1)

let map = List.map
