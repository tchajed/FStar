#light "off"
(* Copyright (c) 2009-2010 Arjun Guha and Claudiu Saftoiu *)
module Microsoft.FStar.LambdaJS.Syntax

open Lexing
open Microsoft.FStar.JavaScript.Prelude

type pos = Position

type const = Microsoft.FStar.JavaScript.Syntax.const

type op1 = 
  | Op1Prefix of id
  | Deref
  | Ref
  | Prim1 of string

(* TODO: unchecked operations should always use differnet syntax. add an
   uncheckedGetField, uncheckedSetField, updateField, App, and if, ? *)
type op2 =
  | Op2Infix of id
  | Prim2 of string
  | GetField
  | UnsafeGetField
  | DeleteField
  | SetRef

(** NOTE: reference and object manipulation are defined using [EOp1] and 
    [EOp2]. This design shrinks the size of many cases. *)
type exp =
  | EConst of pos * const
  | EId of pos * id
  | EObject of pos * (pos * string * exp) list
  | EUpdateField of pos * exp * exp * exp
  | EOp1 of pos * op1 * exp
  | EOp2 of pos * op2 * exp * exp
  | EIf of pos * exp * exp * exp
  | EApp of pos * exp * exp list
  | ESeq of pos * exp * exp
  | ELet of pos * id * exp * exp
  | EFix of pos * (id * exp) list * exp 
      (** All bindings must be [ELambda]s. *)
  | ELabel of pos * id * exp
  | EBreak of pos * id * exp
  | ETryCatch of pos * exp * exp
      (** Catch block must be an [ELambda] *)
  | ETryFinally of pos * exp * exp
  | EThrow of pos * exp
  | ELambda of pos * id list * exp


(*
 * Renames identifiers for JavaScript compatibility
 *)

type env = Map<id, id>

let ren_id (x : id) : id =
  mk_name (System.Text.RegularExpressions.Regex.Replace(x,  "[^ A-Za-z0-9_]", "_"))

let rec ren (env : env) (exp : exp) : exp = match exp with
  | EConst  _ -> exp
  | EId (p, x) -> 
    begin try
      EId (p, Map.find x env)
    with
      Not_found -> 
        (Microsoft.FStar.Util.pr "INFO: external reference to %s\n" x;
         exp)
    end
  | EObject (p, fields) -> 
      let f (p', f_name, f_e) = (p', f_name, ren env f_e) in
      EObject (p, map f fields)
  | EUpdateField (p, e1, e2, e3) ->
      EUpdateField (p, ren env e1, ren env e2, ren env e3)
  | EOp1 (p, op, e) -> EOp1 (p, op, ren env e)
  | EOp2 (p, op, e1, e2) -> EOp2 (p, op, ren env e1, ren env e2)
  | EIf (p, e1, e2, e3) -> EIf (p, ren env e1, ren env e2, ren env e3)
  | EApp (p, f, args) -> EApp (p, ren env f, map (ren env) args)
  | ESeq (p, e1, e2) -> ESeq (p, ren env e1, ren env e2)
  | ELet (p, x, e1, e2) -> 
      let y = ren_id x in
        ELet (p, y, ren env e1, ren (Map.add x y env) e2)
  | EFix (p, binds, body) ->
      let xs = map fst binds in
      let env = 
        List.fold_right (fun x env -> Map.add x (ren_id x) env) xs env in
      let f (x, e) = (Map.find x env, ren env e) in
      EFix (p, map f binds, ren env body)
  | ELabel (p, lbl, e) -> ELabel (p, lbl, ren env e)
  | EBreak (p, lbl, e) -> EBreak (p, lbl, ren env e)
  | ETryCatch (p, e1, e2) -> ETryCatch (p, ren env e1, ren env e2)
  | ETryFinally (p, e1, e2) -> ETryFinally (p, ren env e1, ren env e2)
  | EThrow (p, e) -> EThrow (p, ren env e)
  | ELambda (p, xs, e) ->
      let env = 
        List.fold_right (fun x env -> Map.add x (ren_id x) env) xs env in
      ELambda (p, map (fun x -> Map.find x env) xs, ren env e)

let ids_for_js (e : exp) : exp = ren (Map.empty) e

