#light "off"
module Microsoft.FStar.JavaScript.FromFStar

open Microsoft.FStar.JavaScript.Prelude
open Microsoft.FStar.Absyn
open Microsoft.FStar.LambdaJS.Syntax

module FStar = Microsoft.FStar.Absyn
module FStarSugar = Microsoft.FStar.Sugar
module JS = Microsoft.FStar.LambdaJS.Syntax

let p = Lexing.Position.Empty


let conv_bvar (bv : FStar.bvdef<'a>) = bv.ppname.idText

let conv_longident (xs : FStarSugar.LongIdent) : string = 
  String.concat "." (List.map (fun (x : FStarSugar.ident) -> x.idText) xs.lid)

let iota max_n =
  let rec f n = if n = max_n then [] else n :: (f (n + 1)) in
    f 0

let mk_array exps = 
  let nums = iota (List.length exps) in
  let nums = List.map (fun (n : int) -> n.ToString()) nums in
  let props = List.combine nums exps in
  let props = List.map (fun (x, y) -> (p, x, y)) props in
  EObject (p, props)

let conv_extern_ref (externref : FStarSugar.externref) (x : FStar.ident) =
  let m = conv_longident (asLid <| externref.namespce.lid @ externref.classname.lid) in
  let m = match externref.innerclass with
    | None -> m 
    | Some s -> m ^ "_" ^ s in
  EOp2 (p, UnsafeGetField, EId (p, m), EConst (p, Syntax.CString (x.idText)))

let conv_extern_ref_li (externref : FStarSugar.externref) (x : FStar.lident) =
  let m = conv_longident (asLid <| externref.namespce.lid @ externref.classname.lid) in
  let m = match externref.innerclass with
    | None -> m 
    | Some s -> m ^ "______________________________" ^ s in
  EOp2 (p, UnsafeGetField, EId (p, m), EConst (p, Syntax.CString (conv_longident x)))

let rec lident_as_ref (xs : FStarSugar.LongIdent) = match xs.lid with
  | [] -> failwith "unexpected empty list for LongIdent"
  | [x] -> EId (p, x.idText)
  | [obj; fld] -> EOp2 (p, UnsafeGetField, EId (p, obj.idText),
                        EConst (p, Syntax.CString fld.idText))
  | obj :: xs' -> EOp2 (p, UnsafeGetField, EId (p, obj.idText), lident_as_ref (asLid xs'))
 

let extern_ (id : FStarSugar.ident) = new FStarSugar.ident("externs", id.idRange)

let enc = new System.Text.UnicodeEncoding()

let rec erase (e : FStar.exp') : JS.exp = match e with
  | Exp_bvar bv -> EId (p, (conv_bvar bv.v))
  | Exp_fvar (x, None) -> lident_as_ref (x.v)
  | Exp_fvar (x, Some externref) ->
      let x' = x.v.lid.Item(x.v.lid.Length - 1).idText in
      EOp2 (p, UnsafeGetField, EId (p,"extern"),
            EConst (p, Syntax.CString x'))
  | Exp_constant c -> EConst (p, erase_const c)
  | Exp_constr_app (constr, _, _, es) ->
      mk_array  (EConst (p, Syntax.CString (conv_longident constr.v)) ::
                 (List.map erase' es))
  | Exp_abs (x, _, e) -> ELambda (p, [x.ppname.idText], erase' e)
  | Exp_tabs (_, _, _, e) -> erase' e
  | Exp_app (e1, e2) -> EApp (p, erase' e1, [erase' e2])
  | Exp_match (e, cases, default_) ->
      ELet (p, "__r", erase' e, erase_cases "__r" cases (erase' default_))
  | Exp_cond (e1, e2, e3) ->
      EIf (p, erase' e1, erase' e2, erase' e3)
  | Exp_recd (_, _, _, fields) ->
      let f (f_x, f_e) = (p, conv_longident f_x, erase' f_e) in
      EObject (p, map f fields)
  | Exp_tapp (e, _) -> erase' e
  | Exp_proj (e, field) ->
      EOp2 (p, UnsafeGetField, erase' e, 
            EConst (p, Syntax.CString (conv_longident field)))
  | Exp_ascribed (e, _, _) -> erase' e
  | Exp_let (false, binds, body) ->
    (* TODO: potentially breaks binding. However, FStar does ensure unique names,
       right? *)
      let f (x, _, e) body = ELet (p, x.ppname.idText, erase' e, body) in
      List.fold_right f binds (erase' body)
  | Exp_let (true, binds, body) ->
      let f (x, _, e) = (x.ppname.idText, erase' e) in
      EFix (p, map f binds, erase' body)
  | Exp_gvar n -> failwith "unexpected Exp_gvar while translating to JavaScript"
  | Exp_bot -> EThrow (p, EConst (p, Syntax.CString "_|_"))
  | Exp_extern_call (externref, f, _, _, args) -> 
      EApp (p, conv_extern_ref externref f,  map erase' args)
  | Exp_primop (x, es) ->
      EApp (p, EOp2 (p, UnsafeGetField, EId (p, "extern"), 
                     EConst (p, Syntax.CString x.idText)),
            map erase' es)

and erase_cases (x : id) (cases : (FStar.pat * FStar.exp) list) (default_ : exp) =
  let f ((pat, e) : FStar.pat * FStar.exp) (elseExp : exp) : exp = 
    erase_match_pat x pat (erase' e) elseExp in
  List.fold_right f cases default_

and erase_match_pat (x : id) (pat : FStar.pat) (then_ : exp) (else_ : exp) = 
  match pat with
    | Pat_variant (variant_name, _, _, arg_names, __GADT_FLAG_IGNORED) -> (* NIK: Ignoring flag!! *)
        let v_name = EConst (p, Syntax.CString (conv_longident variant_name)) in
        let x_variant = EOp2 (p, UnsafeGetField, EId (p, x), 
                              EConst (p, Syntax.CString "0")) in
        let f (n, bv) e =
          let arg_x = bv.v.ppname.idText in
          ELet (p, arg_x, EOp2 (p, UnsafeGetField, EId (p, x),
                                EConst (p, Syntax.CInt (n + 1))), e) in
        EIf (p, EOp2 (p, Op2Infix "===", x_variant, v_name),
             List.fold_right f
               (List.combine (iota (List.length arg_names)) arg_names)
               then_,
            else_)
  
and erase' (e : FStar.exp) : JS.exp = erase (e.v)

and erase_const (c : FStarSugar.sconst) : Syntax.const = match c with
  | FStarSugar.Const_unit -> Syntax.CUndefined
  | FStarSugar.Const_bool b -> Syntax.CBool b
  | FStarSugar.Const_int32 n -> Syntax.CInt n
  | FStarSugar.Const_string (arr, _) -> Syntax.CString (enc.GetString(arr))
(*
  | FStarSugar.Const_int8 
  | FStarSugar.Const_uint8 of byte
  | FStarSugar.Const_int16 of int16
  | FStarSugar.Const_uint16 of uint16

  | FStarSugar.Const_uint32 of uint32
  | FStarSugar.Const_int64 of int64
  | FStarSugar.Const_uint64 of uint64
  | FStarSugar.Const_nativeint of int64
  | FStarSugar.Const_unativeint of uint64
  | FStarSugar.Const_float32 of single
  | FStarSugar.Const_float of double
  | FStarSugar.Const_char of char
  | FStarSugar.Const_decimal of System.Decimal
  | FStarSugar.Const_bigint of byte[] (* in unicode *)
  | FStarSugar.Const_bignum of byte[] (* in unicode *)
  | FStarSugar.Const_string of byte[] * range (* unicode encoded, F#/Caml independent *)
  | FStarSugar.Const_bytearray of byte[] * range 
  | FStarSugar.Const_uint16array of uint16[] 
*)

let erase_bind (bv : FStar.bvdef<'a>, _, e : FStar.exp) =
  (conv_bvar bv, erase' e)

let erase_letbinding (binds : FStar.letbinding, isRec : bool) 
                     (rest : JS.exp) : JS.exp = match isRec with
  | true -> EFix (p, map erase_bind binds, rest)
  | false ->
      let f (x, e) rest' = ELet (p, x, e, rest') in
      List.fold_right f (map erase_bind binds) rest

let conv_modul_binding (bv : FStar.bvdef<'a>, _, _) = 
  (p, conv_bvar bv, EId (p, conv_bvar bv))

let conv_modul_bindings (binds : letbinding, _) =
  map conv_modul_binding binds  

let erase_modul (m : FStar.modul) (rest : JS.exp) : JS.exp =
  let mName = conv_longident m.name in
  ELet 
    (p, mName, EConst (p, Syntax.CUndefined),
      List.fold_right erase_letbinding (m.letbindings)
      (ESeq 
         (p, EOp2 (p, SetRef, EId (p, mName), 
                   EObject (p, List.concat (List.map conv_modul_bindings (m.letbindings)))),
      match m.main with
      | None -> rest
      | Some e -> ESeq (p, erase' e, rest))))
  
let fineToJavaScript (moduls : FStar.modul list) : string = 
  let direct = List.fold_right erase_modul moduls
                 (EConst (p, Syntax.CUndefined)) in
  let direct = ids_for_js direct in
  let anf = Microsoft.FStar.LambdaJS.ANF.to_anf direct in
  let js =  Microsoft.FStar.LambdaJS.ANF.to_js anf in
  FormatExt.to_string (PrettyPrint.p_stmt) js
  

