#light "off"
// (c) Microsoft Corporation. All rights reserved
module Microsoft.FStar.Anf

open Absyn
open AbsynUtils
type anf_env = {enclosing_let:option<bvvdef>; ascribed_typ:option<typ>; normalize_app:bool; hoist_lambda:bool}
let empty_env hl = {enclosing_let=None; 
                    ascribed_typ=None;
                    normalize_app=true;
                    hoist_lambda=hl}


let ascribe env e = match env.ascribed_typ with 
    | None -> e
    | Some t -> ewithinfo (Exp_ascribed(e, t, [])) t e.p

let p_hoist env e k = match env.enclosing_let, k with 
  | None, None
  | Some _, None  -> ascribe env e
  | Some _, Some k -> k (ascribe env e)
  | None, Some k -> hoistexp (ascribe env e) k e.p
      
let rec anf_exp env e: option<(exp -> exp)> -> exp = 
  let anf_exp_l (el:list<exp>) (c:list<exp> -> exp) = 
    let cl = List.map (anf_exp (empty_env env.hoist_lambda)) el in
    let rec builder names = function
      | [] -> c (List.rev names)
      | cx::rest -> cx (Some (fun x -> builder (x::names) rest)) in
      builder [] cl in
  let apply k e = match k with
      None -> ascribe env e
    | Some k -> k (ascribe env e) in
    match e.v with 
      | Exp_bvar _ 
      | Exp_fvar _
      | Exp_constant _ 
      | Exp_gvar _
      | Exp_bot -> (fun k -> apply k e)
      | Exp_constr_app(dc, tl, phantoms, el) -> 
          (fun k -> 
             (anf_exp_l el 
                (fun xl -> 
                   let app =  ewithinfo (Exp_constr_app (dc, tl, phantoms, xl)) e.sort e.p in
                     apply k app)))
      | Exp_abs (bvd, t, body) ->
          (fun k -> 
             let abs = ewithinfo (Exp_abs(bvd, t, anf_exp (empty_env env.hoist_lambda) body None)) e.sort e.p in
               if env.hoist_lambda
               then p_hoist env abs k
               else apply k abs)
      | Exp_tabs (bvd, kind, formula, e) ->
          (fun k -> 
             let tabs = ewithinfo (Exp_tabs(bvd, kind, formula, anf_exp (empty_env env.hoist_lambda) e None)) e.sort e.p in
               if env.hoist_lambda
               then p_hoist env tabs k
               else apply k tabs)
      | Exp_primop(id, args) -> 
          (fun k -> 
             anf_exp_l args 
               (fun xl -> 
                  let primop = (ewithinfo (Exp_primop(id, xl)) e.sort e.p) in
                    p_hoist env primop k))
      | Exp_app(e1, e2) -> 
          (fun k -> 
             anf_exp {(empty_env env.hoist_lambda) with normalize_app=false} e1 
               (Some (fun x1 -> 
                        anf_exp {(empty_env env.hoist_lambda) with normalize_app=true} e2 
                          (Some (fun x2 -> 
                                   let app = ewithinfo (Exp_app (x1, x2)) e.sort e.p in
                                     if env.normalize_app
                                     then p_hoist env app k
                                     else apply k app)))))
      | Exp_tapp(e', t) -> 
          if !Options.certify 
          then
            (fun k -> 
               anf_exp (empty_env env.hoist_lambda) e'
                 (Some (fun x1 -> 
                          let tapp = ewithinfo (Exp_tapp (x1, t)) e.sort e.p in
                            p_hoist env tapp k)))
          else
            let rec collect_typs out e = match e.v with 
              | Exp_tapp(e', t) -> collect_typs ((t, e'.sort, e.p)::out) e'
              | _ -> e, out in
            let e', ts = collect_typs [(t, e.sort, e.p)] e' in 
              (fun k -> 
                 (anf_exp (empty_env env.hoist_lambda) e') 
                   (Some (fun x -> 
                            let tapp = List.fold_left (fun out (t, sort, p) -> ewithinfo (Exp_tapp (out, t)) sort p) x ts in
                              if env.normalize_app 
                              then p_hoist env tapp k
                              else apply k tapp)))
      | Exp_match(v, branches, def) -> 
          (fun k -> 
             (anf_exp (empty_env env.hoist_lambda) v)
               (Some (fun x -> 
                        let branches' = List.map (fun (pat, branch) -> pat, anf_exp (empty_env env.hoist_lambda) branch None) branches in
                        let match' = ewithinfo (Exp_match(x, branches', anf_exp (empty_env env.hoist_lambda) def None)) e.sort e.p in
                          p_hoist env match' k)))
      | Exp_cond (e1, e2, e3) -> 
          (fun k -> 
             (anf_exp (empty_env env.hoist_lambda) e1) 
               (Some (fun x -> 
                        let cond = ewithinfo (Exp_cond(x, anf_exp (empty_env env.hoist_lambda) e2 None, anf_exp (empty_env env.hoist_lambda) e3 None)) e.sort e.p in
                          p_hoist env cond k)))
      | Exp_recd (lidopt, tl, el, fn_e_l) -> 
          (fun k -> 
             let fn, el = List.unzip fn_e_l in
               (anf_exp_l el (fun xl -> 
                                let recd = ewithinfo (Exp_recd (lidopt, tl, el, (List.zip fn xl))) e.sort e.p in
                                  if AbsynUtils.is_value recd
                                  then apply k recd
                                  else p_hoist env recd k)))
      | Exp_proj(e', fn) -> 
          (fun k -> 
             (anf_exp (empty_env env.hoist_lambda) e') 
               (Some (fun x -> (* projections are values in TC but we still hoist them to ease derefinement *)
                        let proj = ewithinfo (Exp_proj(x, fn)) e.sort e.p in
                        p_hoist env proj k)))
      | Exp_ascribed(e, t, ev) -> 
          (fun k -> 
             (anf_exp {(empty_env env.hoist_lambda) with ascribed_typ=Some t; enclosing_let=env.enclosing_let} e) 
               (Some (fun x -> apply k x)))

      | Exp_let(isrec, [bvd, t, e], body) when isrec=false-> 
          (fun k -> 
             let env' = {enclosing_let=Some bvd; ascribed_typ=None; normalize_app=false; hoist_lambda=env.hoist_lambda} in
             let anf_let = anf_exp env' e
               (Some (fun x -> 
                        ewithinfo (Exp_let(isrec, [bvd, t, x], anf_exp (empty_env env.hoist_lambda) body None)) e.sort e.p)) in
               p_hoist env anf_let k)
      | Exp_let(isrec, bindings, body) when isrec=true-> 
          (fun k -> 
             let bindings' = List.map (fun (bvd, t, e) -> (bvd, t, anf_exp (empty_env env.hoist_lambda) e None)) bindings in
             let elet = ewithinfo (Exp_let(isrec, bindings', anf_exp (empty_env env.hoist_lambda) body None)) e.sort e.p in
               p_hoist env elet k)
      | Exp_extern_call (eref, ident, t, tl, el) -> 
          (fun k -> 
             (anf_exp_l el (fun xl -> 
                              let call = ewithinfo (Exp_extern_call (eref, ident, t, tl, xl)) e.sort e.p in
                                p_hoist env call k)))

let anf_module hl m = 
  let lbs = List.map 
    (fun (bindings, isrec) -> 
       let bindings' = List.map (fun (bvd, t, e) -> (bvd, t, anf_exp (empty_env hl) e None)) bindings in
         (bindings', isrec)) m.letbindings in
  let main = Util.bind_opt m.main (fun main -> Some (anf_exp (empty_env hl) main None)) in
  let anf_m = {m with letbindings=lbs; main=main} in
    (*   let _ = *)
    (*     if not (Sugar.lid_equals m.name Const.prims_lid) then *)
    (*       (Printf.printf "Desugared module before ANF:\n"; Pretty.printModule m; *)
    (*        Printf.printf "\nANF module:\n"; Pretty.printModule anf_m); *)
    (*   in *)
    anf_m
      
