#light "off"
// (c) Microsoft Corporation 2010
module Microsoft.FStar.TransFs7

open Fs7
open Sugar
open Const
open Util 

type name = list<string>
type env = {currentModule:string; preds:list<(ident*ident)>}
type st<'a> = Util.state<env, 'a>
let rangeOfPos p = Absyn.dummyRange

let s2i = Absyn.string2ident
let n2i = s2i -<- (String.concat ".") 
let r = Absyn.dummyRange
let bvdOfStr s = 
   let x = Absyn.string2ident s in (x,x)
let lidOfName n = Absyn.asLid <| List.map Absyn.string2ident n
let identEquals i1 i2 = (text_of_id i1) = (text_of_id i2)

let addAndRet (dcname, predname)  (v:'a) : st<'a> = get >> (fun e -> 
    match Util.findOpt (fun (dcname', _) -> identEquals dcname dcname') e.preds with 
        | None -> 
            if List.exists (fun (dc',_) -> dc' = dcname) e.preds
            then ret v
            else put {e with preds=((dcname, predname)::e.preds)} >> (fun _ -> ret v)
        | Some _ -> ret v)
let currentModule : st<string> = get >> (fun e -> ret e.currentModule)

let elimTrue = function
   | Form_atom(Atom_true, _) -> None 
   | f -> Some f
let typOfName n = Type_lid(lidOfName n, r)
let unitTyp = typOfName (Sugar.path_of_text "Prims.unit")
let unitVal = Expr_const(Const_unit, r)

let rec typOptOfType : Type -> st<option<typ>> = function 
   | TVar tv -> ret (Some (Type_var(Typar(s2i tv, None), r)))
   | TApp(tl, vl, v) ->
      let t = typOfName v in 
      (stmap tl typOfType) >> (fun tl -> 
      (stmap vl expOfMessage) >> (fun el -> 
         let el = List.map (fun e -> Type_term_index(e, r)) el in
         ret (Some (Type_app(t, tl@el, r)))))
   | TTuple([], form) -> 
      (formOfForm form) >> (fun f -> 
          match elimTrue f with 
          | None -> ret (Some unitTyp)
          | Some f -> let x = Absyn.new_bvd None in ret (Some (Type_refinement(x.ppname, unitTyp, f, true, r))))
   | TTuple (xt_l, form) -> 
      (stmap xt_l (fun (x,t) -> (typOfType t) >> (fun t -> ret (Some (s2i x), t)))) >> (fun xt_l ->  
      (formOfForm form) >> (fun f ->
        let rest, (Some xlast, tlast) = pfx xt_l in
        let xtlast = match elimTrue f with 
            | None -> (None, tlast) 
            | Some f -> (None, Type_refinement(xlast, tlast, f, true, r)) in
        let xtl = rest@[xtlast] in 
          ret (Some (Type_tuple(xtl, r)))))
   | TFun (x, t, f, y, t', f') ->
       (typOfType t) >> (fun t -> 
       (typOfType t') >> (fun t' -> 
       (formOfForm f) >> (fun f -> 
       (formOfForm f') >> (fun f' ->  
         let x, y = s2i x, s2i y in
         ret (Some (match elimTrue f, elimTrue f' with 
                | None, None -> Type_fun((Some x, t), t', r)
                | None, Some f' -> Type_fun((Some x, t), Type_refinement(y, t', f', true, r), r)
                | Some f, None -> Type_fun((Some x, Type_refinement(x, t, f, true, r)), t', r)
                | Some f, Some f' -> Type_fun((Some x, Type_refinement(x, t, f, true, r)), Type_refinement(y, t', f', true, r), r)))))))
   | TTop 
   | TUvar _ -> ret None 

and typOfType : Type -> st<typ> = fun t -> 
    (typOptOfType t) >> (function None -> failwith (spr "Failed to translate type %A" t) | Some t -> ret t)

and expOfMessage : Message -> st<synexpr> = function 
  | MVar([local], p) -> ret (Expr_id_get(s2i local)) 
  | MVar(x, p) -> ret (Expr_lid_get(false, lidOfName x, r))
  | Literal c -> ret (Expr_const (constOfConstant c, r))
  | Tuple [] -> ret (unitVal)
  | Tuple ml -> 
       (stmap ml expOfMessage) >> (fun el -> 
        ret (Expr_tuple(el, r)))
  | Term(x,Tuple []) -> ret (Expr_lid_get(false, lidOfName x, r))
  | Term(x, m) ->
        (expOfMessage m) >> (fun e -> 
        (expOfMessage (MVar(x, ""))) >> (fun c -> 
         ret (Expr_app(c, e, r))))
  | Recd fm_l ->
      stmap fm_l (fun (fn, m) -> (expOfMessage m) >> (fun e -> 
                                 let m, f = match fn with [f] -> [], f | _ -> Util.pfx fn in 
                                 ret ((lidOfName m, s2i f), e))) >> (fun fne_l -> 
        ret (Expr_recd(None, fne_l, r)))
  | Lookup(m, fn) -> 
        (expOfMessage m) >> (fun e -> 
          ret (Expr_lvalue_get(e, lidOfName fn, r)))

and formOfForm : Formula -> st<formula> = function
  | True -> ret (Form_atom(Atom_true, r))
  | False -> ret (Form_atom(Atom_false, r))
  | Not f -> (formOfForm f) >> (fun f -> ret (Form_not(f, r)))
  | Iff(f1, f2) -> formOfForm (Conj (Imp(f1, f2), Imp(f2, f1))) 
  | Imp(f1, f2) ->
        (formOfForm f1) >> (fun f1 -> 
        (formOfForm f2) >> (fun f2 ->
         ret (Form_impl(f1, f2, r))))
  | Conj(f1, f2) -> 
        (formOfForm f1) >> (fun f1 -> 
        (formOfForm f2) >> (fun f2 -> 
         ret (Form_conj(f1, f2, r))))
  | Disj(f1, f2) ->
        (formOfForm f1) >> (fun f1 -> 
        (formOfForm f2) >> (fun f2 -> 
         ret (Form_disj(f1, f2, r))))
  | All(x, t, f, pats) -> 
        (typOptOfType t) >> (fun topt -> 
        (formOfForm f) >> (fun f -> 
        (stmap pats expOfMessage) >> (fun exps ->
         let pats = List.map (fun exp -> Atom_pred (Type_term_index(exp, Absyn.dummyRange))) exps in
         let x = s2i x in 
         let t = match topt with None -> Type_anon r | Some t -> t in
          ret (Form_all(x, t, f, r, pats, false)))))
  | Ex(x, t, f, pats) -> 
        (typOptOfType t) >> (fun topt -> 
        (formOfForm f) >> (fun f -> 
        (stmap pats expOfMessage) >> (fun exps ->
         let pats = List.map (fun exp -> Atom_pred (Type_term_index(exp, Absyn.dummyRange))) exps in
         let x = s2i x in 
         let t = match topt with None -> Type_anon r | Some t -> t in
          ret (Form_exists(x, t, f, r, pats, false)))))
  | Pred (path, ml) ->  //record x as a predicate symbol in environment?
        currentModule >> (fun curmod ->
        (stmap ml expOfMessage) >> (fun el -> 
         let t, propOpt = 
           let modul, dc = Util.pfx path in
             if modul=[] || (Sugar.text_of_path modul)=curmod then 
               let propName = dc^".prop" in typOfName [propName], Some (s2i dc, s2i propName)
             else typOfName (modul @ [dc^".prop"]), None in
         let arg = Expr_tuple(el, r) in
         let result = Form_atom (Atom_pred (Type_app (t, [Type_term_index(arg, r)], r)), r) in
           (match propOpt with 
              | None -> ret result
              | Some propName -> addAndRet propName result)))
   | Eq (m1, m2) -> 
        (expOfMessage m1) >> (fun e1 -> 
        (expOfMessage m2) >> (fun e2 -> 
         let t = Type_lid(Const.eq_lid, r) in
            ret (Form_atom(Atom_pred(Type_app(t, [Type_term_index(e1, r);
                                                  Type_term_index(e2, r)], r)), r))))
  | NEq(m1, m2) -> formOfForm (Not(Eq(m1,m2)))
  | Says _ -> raise Impos
and constOfConstant = function 
  | String s -> Sugar.Const_string (Util.unicodeEncoding.GetBytes s, r)
  | Int i -> Sugar.Const_int32 i
  | Bool b -> Sugar.Const_bool b
  | Float f -> Sugar.Const_float f

let typarsOfTvks = List.map (fun (tv, k) -> Typar(s2i tv, None))
let tmparsOfXvts xvts = (stmap xvts (fun (x,t) -> (typOfType t) >> 
                                                  (fun t -> ret (s2i x, t))))
let tciOfTabs (tvks, xvts, name) = 
    let typars = typarsOfTvks tvks in 
    (tmparsOfXvts xvts) >> (fun tmpars ->
    let l = lidOfName name in 
    let tps = List.map (fun t -> TyparDecl t) typars in
    let xps = List.map (fun x -> TermparDecl x) tmpars in
    let tci = Tycon(l, Sugar.Kind_star, tps@xps, false, r) in
    ret tci)

let rec mimplOfTypeDef : TypeDef -> st<ModuleImplDecl> = function
  | TAbs(tvks, xvts, name) ->
        tciOfTabs (tvks, xvts, name) >> (fun tci -> 
        let tcd = TyconDefn(tci, TyconCore_repr_hidden r, r) in
        ret (Def_tycon([tcd], false, false, [], r)))
  | TAlg(tvks, xvts, name, sigma) ->
        let mkDcon (name, t, _dp) = 
            let d = s2i (String.concat "." name) in 
            (typOfType t) >> (fun t -> 
                if t = unitTyp then ret (UnionConstr(d, ConstrFields[], r))
                else ret (UnionConstr(d, ConstrMLType t, r))) in
        tciOfTabs (tvks, xvts, name) >> (fun tci ->
        stmap sigma mkDcon >> (fun dcons -> 
        let tcd = TyconDefn(tci, TyconCore_union(dcons, r), r) in
        ret (Def_tycon([tcd], false, false, [], r))))
  | TAbbrv(tvks, xvts, name, t) -> 
        tciOfTabs (tvks, xvts, name) >> (fun tci -> 
        (typOfType t) >> (fun t -> 
        let tcd = TyconDefn(tci, TyconCore_abbrev(t, r), r) in
        ret (Def_tycon([tcd], false, false, [], r))))
  | TRecd(tvks, xvts, name, fnts) -> 
        tciOfTabs (tvks, xvts, name) >> (fun tci -> 
        stmap fnts (fun (fn, t) -> 
                      typOfType t >> (fun t -> 
                      let rf = s2i (String.concat "." fn) in
                      ret (Field(rf, t, r)))) >> (fun fds ->
        let  tcd = TyconDefn(tci, TyconCore_recd(fds, r), r) in
        ret (Def_tycon([tcd], false, false, [], r)))) 


let markPreds : ModuleImplDecl -> st<unit> = function
  | Def_tycon([TyconDefn(tci, TyconCore_union(dcons, _), _)], _, _, _, _) -> 
      stmap dcons (fun (UnionConstr(dc, _, _)) -> addAndRet (dc, s2i (dc.idText ^ ".prop")) ()) >> (fun _ -> ret ())
  | _ -> ret ()

let mimplOfDecl : Decl -> st<option<ModuleImplDecl>> = function 
  | Exn _ 
  | Kind _ 
  | SubTy _
  | Val(_, _, _, _::_, _) -> raise Impos (* top level value with phantom indices *)
  | Open x -> ret <| (Some (Def_open(lidOfName x, r)))
  | Val(q, name, tvks, [], t) -> 
        let l = s2i (String.concat "." name) in
        let tps = typarsOfTvks tvks in
        (typOfType t) >> (fun t -> 
            let t = match tps with [] -> t | _ -> Type_qtyp(tps, t, r) in 
            ret <| (Some (Def_val(l, t, r))))
  | Query (_, name, f) when !Options.ignore_queries -> 
      (formOfForm f) >> (fun f -> 
         let x = s2i (String.concat "." name) in 
         ret <| (Some (Def_assume(Some x, f, Sugar.Assumption, r))))
  | Form(_, name, f) -> 
        (formOfForm f) >> (fun f -> 
         let x = s2i (String.concat "." name) in 
         ret <| (Some (Def_assume(Some x, f, Sugar.Assumption, r))))
  | Query (_, v, form) -> 
      (formOfForm form) >> (fun f -> 
        let lid = lidOfName v in
          ret (Some (Def_query(lid, f, r))))
  | AbsType (tvks, xvts, name) -> (mimplOfTypeDef (TAbs(tvks, xvts, name))) >> (fun x -> ret (Some x))
  | ConcType(qual, tvks, xvts, name, sigma) -> 
      mimplOfTypeDef (TAlg(tvks, xvts, name, sigma)) >> (fun x -> 
        match qual.usage with
          | Predicate -> markPreds x >> (fun () -> ret (Some x))
          | _ -> ret (Some x))
  | TypeAbbrv(tvks, xvts, name, t) -> mimplOfTypeDef(TAbbrv(tvks, xvts, name, t)) >> (fun x -> ret (Some x))
  | TypeRecd(tvks, xvts, name, fnts) -> mimplOfTypeDef (TRecd(tvks, xvts, name, fnts)) >> (fun x -> ret (Some x))
  | RecType(_, tdl) -> (stmap tdl mimplOfTypeDef) >> (fun x -> 
                        let tdfl = List.map (fun (Def_tycon(tdf, _, _, _, _)) -> tdf) x |> List.flatten in 
                        ret <| (Some (Def_tycon(tdfl, false, false, [], r))))

let addPred (dcname:ident) (pred:ident) : ModuleImplDecls -> ModuleImplDecls = 
  let rec aux out = function 
     | [] -> List.rev out
     | hd::tl -> match hd with 
        | Def_tycon(tdfl, _, _, _, _) -> 
             (match getDataconOpt tdfl with 
               | None -> aux (hd::out) tl
               | Some (ConstrFields[]) -> 
                   let prop = mkProp None in
                    (List.rev out)@(hd::prop::tl)
               | Some (ConstrMLType t) -> 
                   let prop = mkProp (Some t) in
                    (List.rev out)@(hd::prop::tl))
        | _ -> aux (hd::out) tl
  and mkProp t = 
    let kind = match t with None -> Sugar.Kind_star | Some t -> Sugar.Kind_dcon(None, t, Sugar.Kind_star) in
    let tci = Tycon(Absyn.asLid [pred], kind, [], false, r) in 
      Def_tycon([TyconDefn(tci, TyconCore_repr_hidden r, r)], true, false, [], r) 
  and getDataconOpt = function 
    | [] -> None
    | (TyconDefn(_tcd, TyconCore_union(constrs, _), _))::tl ->
(*         pr "Looking in type %A for dc %s\n" _tcd dcname.idText; *)
        (match Util.findOpt (function UnionConstr(ucid, _, _) -> identEquals ucid dcname) constrs with
            | None -> getDataconOpt tl 
            | Some (UnionConstr(_, mltyp, _)) -> Some mltyp
            | blah -> failwith (spr "Unexpected result %A" blah))
    | _::tl -> getDataconOpt tl in
  aux []
let addPreds (preds:list<ident*ident>) mimpls = 
   List.fold_left (fun mimpls (dcname, pname) -> addPred dcname pname mimpls) mimpls preds 

let modulOfFs7 (FS7(ns, modname, decls) as fs7) = 
  let (mimpls, {preds=preds; currentModule=_}) = stmap decls mimplOfDecl |> runState {currentModule=modname; preds=[]} in
  let mimpls = List.filter (function None -> false | _ -> true) mimpls |> projSomes in
  let mimpls = addPreds preds mimpls in 
  let l = lidOfName (match modname with "" -> ns | _ -> ns@[modname]) in
  let mi = ModuleOrNamespaceImpl(l, None, mimpls, r) in
  let sugar = NamedTopModuleImpl mi in (* change this  *)
    (* pr "Translated fs7 to sugar: %A\n" sugar; *)
    sugar
      

let isExpect = function 
   | Expr_id_get id -> id.idText = "expect" 
   | Expr_lid_get (_, lid, _) -> Pretty.str_of_lident lid = "expect"
   | _ -> false
let isAssume = function 
   | Expr_id_get id -> id.idText = "Assume" 
   | Expr_lid_get (_, lid, _) -> Pretty.str_of_lident lid = "Assume"
   | _ -> false
let rec asPred = function 
   | Expr_id_get id -> 
        let x = id.idText in
        let x = n2i [x;"prop"] in
          Type_lid(Absyn.asLid [x],id.idRange) 
   | Expr_lid_get(_, lid, r) -> 
        let x = Pretty.str_of_lident lid in 
        let x = n2i [x;"prop"] in
            Type_lid(Absyn.asLid [x], r)
   | Expr_app(e1, e2, r) -> 
        let t = asPred e1 in
        Type_app(t, [Type_term_index(e2, r)], r)
   | Expr_paren(e, _) -> asPred e
   | e -> failwith (spr "Expected pred; got %A" e)
let rec fixupExpr e = match e with 
    | Expr_app(e1, e2, r) when isExpect e1 || isAssume e1 -> 
        let t = asPred e2 in
        let e = Expr_tyapp(e1, [unitTyp;t], r) in
            Expr_app(e, unitVal, r) 
    | Expr_typed(e, t, r) -> Expr_typed(fixupExpr e, t, r)
    | Expr_const _ 
    | Expr_id_get _ 
    | Expr_lid_get _ -> e
    | Expr_lvalue_get (e, lid, r) -> Expr_lvalue_get(fixupExpr e, lid, r)
    | Expr_paren(e, r) -> Expr_paren(fixupExpr e, r)
    | Expr_tuple(el, r) -> Expr_tuple(List.map fixupExpr el, r)
    | Expr_list(el, r) -> Expr_list(List.map fixupExpr el, r)
    | Expr_recd(eopt, fs, r) -> Expr_recd(bind_opt eopt (fun e -> Some (fixupExpr e)), 
                                          List.map (fun (rf, e) -> rf, fixupExpr e) fs, 
                                          r)
    | Expr_lambda(pats, e, r) -> Expr_lambda(pats, fixupExpr e, r)
    | Expr_match(e, clauses, b, r) -> Expr_match(fixupExpr e, List.map fixupClause clauses, b, r)
    | Expr_app(e1, e2, r) -> Expr_app(fixupExpr e1, fixupExpr e2, r)
    | Expr_tyapp(e1, tl, r) -> Expr_tyapp(fixupExpr e1, tl, r)
    | Expr_let(b1, b2, bindings, e, r) -> Expr_let(b1, b2, List.map fixupBinding bindings, fixupExpr e, r)
    | Expr_seq(b, e1, e2, r) -> Expr_seq(b, fixupExpr e1, fixupExpr e2, r)
    | Expr_cond(e1, e2, eopt, r1, r2) -> Expr_cond(fixupExpr e1, fixupExpr e2, bind_opt eopt (fun x -> Some (fixupExpr x)), r1, r2)

and fixupClause (Clause(pat, eopt, e, t)) = Clause(pat, bind_opt eopt (fun x -> Some (fixupExpr x)), fixupExpr e, t)

and fixupBinding (Binding(bk, pat, (BindingExpr(topt, e)), r)) = 
    Binding(bk, pat, BindingExpr(topt, fixupExpr e), r)

let fixupFsDecl d = match d with 
  | Def_let(b, bl, r) -> Def_let(b, List.map fixupBinding bl, r)
  | Def_expr(e, r) -> Def_expr(fixupExpr e, r)
let fixupFs = List.map fixupFsDecl

let rec merge (NamedTopModuleImpl mifs7) (ParsedImplFile [NamedTopModuleImpl mifs]) = match mifs7, mifs with 
  | ModuleOrNamespaceImpl(l, _, fs7, _), 
    ModuleOrNamespaceImpl(l', _, fs, r) -> 
        if not(Sugar.lid_equals l l') then failwith (spr "Got fs7 %s and fs %s\n" (Pretty.str_of_lident l) (Pretty.str_of_lident l'));
        let fs = List.filter (keep fs7) fs in
        let fs = fixupFs fs in
          ParsedImplFile [(NamedTopModuleImpl (ModuleOrNamespaceImpl(l, None, fs7@fs, r)))]
  | _ -> raise Impos
and keep fs7 = function 
  | Def_open _ -> false
  | Def_tycon _ -> false (* for now *)
  | Def_let _ -> true
  | Def_expr _ -> true
  | Def_assume _ 
  | Def_val _
  | Def_extern_val _ 
  | Def_extern_typ _
  | Def_extern_ref _ -> raise Impos 
