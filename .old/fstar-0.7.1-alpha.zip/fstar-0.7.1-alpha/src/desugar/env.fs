#light "off"
// (c) Microsoft Corporation. All rights reserved

module Microsoft.FStar.DesugarEnv

open Sugar
open Absyn 
open AbsynUtils
open Const
open Util
open Profiling

let id_ctr_cum, id_ctr = new_counter "Env.lookup_id", ref ""
let lid_ctr_cum, lid_ctr = new_counter "Env.lookup_lid", ref ""
let dc_ctr_cum, dc_ctr = new_counter "Env.lookup_datacon", ref ""
let fn_ctr_cum, fn_ctr = new_counter "Env.lookup_field_name", ref ""
let vd_ctr_cum, vd_ctr = new_counter "Env.lookup_val_decl_typ", ref ""

let freshen_counters n = 
  id_ctr := (new_counter ("Env.lookup_id "^n));
  lid_ctr := (new_counter ("Env.lookup_lid "^n));
  dc_ctr := (new_counter ("Env.lookup_datacon "^n));
  fn_ctr := (new_counter ("Env.lookup_field_name "^n));
  vd_ctr := (new_counter ("Env.lookup_val_decl_typ "^n))
    
type binding = 
  | DSBinding_typ_var of ident * kind
  | DSBinding_var of ident * typ
  | DSBinding_tycon of ident * kind
  | DSBinding_pending_subst of ident * ident

type env = {
  curmodule: lident;
  modules:list<lident * modul>;  (* already fully type checked modules *)
  open_namespaces: list<lident>; (* fully qualified names, in order of precedence *)

  sigaccum:signature;            (* type declarations being accumulated for the current module *)
  externs:signature;
  localbindings:list<Disj<btvdef,bvvdef> * binding>;  (* local name bindings for name resolution, paired with an env-generated unique name *)
  recbindings:list<binding>;    (* names bound by type t1 .. and t2 = .. *)
  generalize_tvars:bool;
  extern_typ:bool;
  extern_ref:option<externref>;
  eref_bindings:list<ident * externref>
}
(* exception Found_var_binding of lident * exp *)
(* exception Found_typ_binding of typ *)
exception Not_found_binding of lident 

let open_modules e = e.modules
let current_module env = env.curmodule
let generalize env = env.generalize_tvars 
let set_generalize env b = {env with generalize_tvars = b}

let newenv n =  {curmodule=n; modules=[]; open_namespaces=[];
                 sigaccum=[]; externs=[];localbindings=[]; recbindings=[]; 
                 eref_bindings=[];
                 generalize_tvars=true; extern_typ=false; extern_ref=None}

let env_as_modul env ext = {name = env.curmodule; extends=ext; pos=(range_of_lid env.curmodule); 
                            signature = List.rev env.sigaccum;
                            letbindings=[]; main=None;exports=[]; pragmas=[]} 

let push_eref_binding env id eref = {env with eref_bindings=(id,eref)::env.eref_bindings}
let set_extern_typ env eref = {env with extern_typ=true; extern_ref=Some eref}
let extern_typ env = env.extern_typ
let extern_ref env = env.extern_ref
let clear_extern_typ env = {env with extern_typ=false; extern_ref=None}

let initial_env open_modules module_lid =
  let open_ns =
    if lid_equals module_lid Const.prims_lid then [] else [Const.prims_lid] in
  let externs = List.concat (List.map (fun (_,modul) -> (List.filter (function
                                                                        | Sig_extern_value _ 
                                                                        | Sig_extern_typ _ -> true
                                                                        | _ -> false) modul.signature)) open_modules) in
  let env = {curmodule=module_lid; modules=open_modules; open_namespaces=open_ns;
             sigaccum=[]; externs=externs; localbindings=[]; recbindings=[]; 
             eref_bindings=[];
             generalize_tvars=true; extern_typ=false; extern_ref=None} in
    debug_dump 1 "Initial desugaring environment" env;
    freshen_counters (text_of_lid module_lid);
    env

let range_of_binding = function
  | DSBinding_typ_var(id, _)
  | DSBinding_var(id, _) 
  | DSBinding_tycon (id, _) -> id.idRange
  | DSBinding_pending_subst (id, id') -> Range.union_ranges id.idRange id'.idRange

let gen_bvd = function 
  | DSBinding_typ_var(id, _) -> Inl (mkbvd(id, genident (Some id.idRange)))
  | DSBinding_pending_subst(id, _) 
  | DSBinding_var(id, _) -> Inr (mkbvd(id, genident (Some id.idRange)))
  | DSBinding_tycon _ -> raise Impos

    
let push_tbinding_with_real_name env b rn = 
  {env with localbindings=(Inl rn, b)::env.localbindings}

let push_vbinding_with_real_name env b rn = 
  {env with localbindings=(Inr rn, b)::env.localbindings}
    
let push_local_binding env b = 
  let bvd = gen_bvd b in 
    {env with localbindings=(bvd, b)::env.localbindings}, bvd

let push_local_tbinding env b = 
  let env, Inl x = push_local_binding env b in 
    env, x
      
let push_local_vbinding env b = 
  let env, Inr x = push_local_binding env b in 
    env, x
      
let push_rec_binding env b = 
  {env with recbindings=b::env.recbindings}
    
let push_sigelt env s = 
  {env with sigaccum=s::env.sigaccum}
    
let push_namespace env lid = 
  {env with open_namespaces = lid::env.open_namespaces}

let try_lookup_eref env (id:ident) =
  match List.tryFind (fun ((id':ident), er) -> 
(*                         pr "Searching for eref binding %s against %s" id.idText id'.idText; *)
                        id.idText = id'.idText) env.eref_bindings with 
      None -> None
    | Some (_, er) -> Some er
        
let try_lookup_typ_var env (id:ident) =
  let fopt = List.tryFind (fun (fn, b) -> match b with 
                             | DSBinding_typ_var (id',k) -> id.idText=id'.idText 
                             | _ -> false) env.localbindings in
    match fopt with 
      | Some (Inl fn, DSBinding_typ_var (id',k)) -> 
          let r = id.idRange in 
          let t = twithinfo (Typ_btvar (bvwithinfo fn k r)) k r in 
            Some t
      | _ -> None 


let try_lookup_unqualified_typ_name env (lid:lident) (finder:lident -> sigelt -> option<typ>) : option<typ> = 
  (* GOTCHA: Sometimes the parser will parse a term index as a type index *)
  match lid.lid with 
    | [n] -> 
        (* Unqualified name: try to resolve using, in order, 
           1. rec bindings
           2. sig bindings in current module
           3. each open namespace, in order *)
        let found = find_map env.recbindings 
          (function 
             | DSBinding_tycon (id,k) when id.idText=n.idText -> 
                 let name, eref_opt = match env.extern_ref with 
                     None -> asLid <| env.curmodule.lid @ [id], None
                   | Some eref -> asLid [id], Some eref in
                   
                   Some (twithsort (Typ_const (fvwithinfo name k n.idRange, eref_opt)) k)
             | _ -> None) in
        let found' = found =^^=> 
          (fun _ -> 
             find_map (env.sigaccum@env.externs) (finder (asLid (env.curmodule.lid @ [n])))) in
          found' =^^=>
              (fun _ -> 
                 find_map env.open_namespaces 
                   (fun ns -> 
                      let modul_opt = List.tryFind (fun (ns', _) -> lid_equals ns ns') env.modules in
                        match modul_opt with 
                            None -> None
                          | Some (_,m) -> find_map m.signature (finder (asLid (ns.lid@[n])))))
    | _ -> 
        (* Resolve qnames first in the current module, then as a
           relatively qualified name using open namespaces.  Then
           try to resolve as a fully qualified name *)
        let module_name, id = pfx lid.lid in
        let found = if Sugar.lid_equals (asLid module_name) env.curmodule then
          find_map (env.sigaccum@env.externs) (finder lid) else None in
          found =^^=>
            (fun _ -> 
               find_map (env.open_namespaces @ [asLid []])
                 (fun ns -> 
                    let qname = ns.lid@lid.lid in
                    let prefix, id = pfx qname in 
                    let modul_opt = List.tryFind (fun (ns', _) -> lid_equals ns' (asLid prefix)) env.modules in
                      match modul_opt with 
                          None -> None
                        | Some (_,m) -> find_map m.signature (finder (asLid qname))))
        
let try_lookup_typ_name env lid = 
  let rec find_in_signature lid = function
    | Sig_tycon_kind (lid',_,k,_,_,_) when Sugar.lid_equals lid lid' -> 
        let t = twithsort (Typ_const (fvwithinfo lid' k (Sugar.range_of_lid lid'), None)) k in
          Some t
    | Sig_record_typ(lid',_,_,_,_)
    | Sig_typ_abbrev (lid',_,_,_) when Sugar.lid_equals lid lid' -> 
        let t = twithsort (Typ_const (ftvwithpos lid' (Sugar.range_of_lid lid'), None)) Kind_unknown in
          Some t 
    | Sig_extern_typ (eref, s) as ss -> 
        let mname, id = Util.pfx lid.lid in
          if not (Sugar.lid_equals (asLid mname) env.curmodule) then None
          else
            (match find_in_signature (asLid [id]) s with 
               | Some {v=Typ_const(name, _); sort=k; p=_} -> 
                   let t = twithsort (Typ_const(name, Some eref)) k in
                     Some t 
               | None -> None)
    | _ -> None
  in
    (* GOTCHA: Sometimes the parser will parse a term index as a type index *)
(*     (if (Sugar.text_of_lid env.curmodule <> "Prims") then *)
(*       print_any ("lookup typ name in env: ", env.externs@env.sigaccum)); *)
    match lid.lid with 
      | [n] -> 
          (match try_lookup_typ_var env n with
             | None -> try_lookup_unqualified_typ_name env lid find_in_signature
             | Some t -> Some t)
      | _ -> 
          try_lookup_unqualified_typ_name env lid find_in_signature 

let unmangleOpName (id:ident) = 
    if id.idText = "op_ColonColon" then Sugar.lid_of_path ["Prims"; "Cons"] id.idRange
    else asLid [id] 
let try_lookup_id env (id:ident) =
  if is_operator id.idText then
    let lid = unmangleOpName id in
    let e = ewithpos (Exp_fvar(Wfv lid, None)) id.idRange in
      Some e
  else if (id.idText = "not") then 
    let notlid = lid_of_path ["Prims"; "_dummy_op_Negation"] id.idRange in
    let e = ewithpos (Exp_fvar(Wfv notlid, None)) id.idRange in
      Some e
  else if (id.idText = "op_Equality") then 
    let eqlid = lid_of_path ["Prims"; "op_Equality"] id.idRange in
    let e = ewithpos (Exp_fvar(Wfv eqlid, None)) id.idRange in
      Some e
  else
    let rec do_find (searchKey:ident) = function
        [] -> None
      | (fn,b)::tl -> 
          match fn, b with 
            | Inr fn, DSBinding_var (id', t) when id'.idText=searchKey.idText -> 
                let v = bvwithinfo fn t (searchKey.idRange) in
                let exp = ewithinfo (Exp_bvar v) t searchKey.idRange  in
                  Some exp
            | _, DSBinding_pending_subst (key, key') when key.idText = searchKey.idText ->
                do_find key' tl 
            | _ -> do_find searchKey tl in
      do_find id env.localbindings
        
let try_lookup_module env path = 
  match List.tryFind (fun (mlid, modul) -> (path_of_lid mlid) = path) env.modules with
  |  Some (_, modul) -> Some modul
  | None -> None

let rec try_lookup_unqualified_name env lid finder = 
  match lid.lid with 
    | [n] -> 
        (* Unqualified name: try to resolve using, in order, 
           1. sig bindings in current module
           2. each open namespace, in order *)
        let found = find_map (env.sigaccum@env.externs) (finder (asLid (env.curmodule.lid@lid.lid))) in
          found =^^=>
            (fun _ -> 
               find_map env.open_namespaces
                 (fun ns -> 
                    let ns_path = Sugar.path_of_lid ns in
                    let m = try_lookup_module env ns_path in
                      match m with
                          None -> None
                        | Some m -> 
                            find_map m.signature (finder (asLid <| ns.lid@lid.lid))))

    | hd::tl when hd=Sugar.extern_id ->
        let _, n = Util.pfx tl in
          try_lookup_unqualified_name env (asLid [n]) finder
        
    | _ -> 
        (* Resolve qnames first as a relatively qualified name using open namespaces. 
           Then try to resolve as a fully qualified name *)
        find_map (env.open_namespaces@[asLid []])
          (fun ns -> 
             let qname = ns.lid@lid.lid in
             let prefix, id = pfx qname in 
             let prefix = asLid prefix in 
             let signature = 
               match prefix.lid with 
                 | [] -> Some (env.sigaccum@env.externs)
                 | _ -> 
                     if Sugar.lid_equals env.curmodule prefix then
                       Some (env.sigaccum@env.externs)
                     else
                       let m = try_lookup_module env (path_of_lid prefix) in
                         match m with 
                             None -> None
                           | Some m -> Some m.signature in
               bind_opt signature 
                 (fun s -> find_map s (finder (asLid qname))))
          
let try_lookup_lid env (lid:lident) = 
  let ll () = 
    let rec finder r key_lid = function
      | Sig_datacon_typ (lid', tps, t, _, aq, _, _, _) when Sugar.lid_equals key_lid lid' -> 
          let e = Exp_fvar (fvwithpos lid' r, None) in (*  need to figure out instantiations of type parms *)
            Some(key_lid, (ewithpos e r))
      | Sig_logic_function (lid', t, _) when Sugar.lid_equals key_lid lid' -> 
          let e = Exp_fvar (fvwithpos lid' r, None) in (*  need to figure out instantiations of type parms *)
            Some(key_lid, (ewithpos e r))
      | Sig_value_decl (lid', t) when Sugar.lid_equals key_lid lid' ->
          let e = Exp_fvar (fvwithpos lid' r, None) in (*  need to figure out instantiations of type parms *)
            Some (key_lid, (ewithpos e r))
      | Sig_extern_value (eref, lid', t) when Sugar.lid_equals key_lid lid' -> 
          let e = Exp_fvar ((fvwithpos lid' r), Some eref) in (*  need to figure out instantiations of type parms *)
            Some (key_lid, (ewithpos e r))
      | Sig_extern_typ (eref, s) as ss-> (* this is for extern data constructors *)
          let mname, id = Util.pfx key_lid.lid in
            if not (Sugar.lid_equals (asLid mname) env.curmodule) then None
            else
              (match finder r (asLid [id]) s with
                   Some (key_lid, {v=Exp_fvar(lid, _); sort=s; p=p}) ->
                     Some (key_lid, ewithinfo (Exp_fvar(lid, Some eref)) s p)
                 | _ -> None)
      | _ -> None  in
      match lid.lid with 
        | [] -> failwith "Unexpected empty lid in try_lookup_lid"
        | [n] -> 
            (match try_lookup_id env n with
               | Some e -> Some e
               | None -> 
                   match try_lookup_unqualified_name env lid (finder n.idRange) with 
                       Some (_, e) -> Some e
                     | _ -> None)
        | _ -> 
            match try_lookup_unqualified_name env lid (finder (range_of_lid lid)) with
                Some (_, e) -> Some e
              | _ -> None in
    profilel ll [!lid_ctr; lid_ctr_cum]
      
let try_lookup_val_decl_typ env (lid:lident) = 
  let f () = 
    let lid = asLid <| env.curmodule.lid@lid.lid in
    let finder = function
      | Sig_value_decl(lid', t) when Sugar.lid_equals lid' lid -> Some t
      | Sig_extern_value (lang, lid', t) when Sugar.lid_equals lid' lid -> Some t
      | _ -> None in
      find_map (env.sigaccum@env.externs) finder in
    profilel f [!vd_ctr; vd_ctr_cum]
                                                                                      
let try_lookup_datacon env (lid:lident) = 
  let f () = 
    let rec finder r key_lid = function
      | Sig_datacon_typ (lid', tps, t, None, aq, _, _, _) when Sugar.lid_equals key_lid lid' -> 
          let e = Exp_fvar (fvwithpos lid' r, None) in (*  need to figure out instantiations of type parms *)
            Some (key_lid, (ewithpos e r))
      | Sig_logic_function (lid', t, _) when Sugar.lid_equals key_lid lid' -> 
          let e = Exp_fvar (fvwithpos lid' r, None) in (*  need to figure out instantiations of type parms *)
            Some (key_lid, (ewithpos e r))
      | Sig_extern_typ (eref, s) as ss -> 
          let mname, id = Util.pfx key_lid.lid in
            if not (Sugar.lid_equals (asLid mname) env.curmodule) then None
            else
              (match finder r lid s with 
                   Some(key_lid, {v=Exp_fvar(l', _); sort=s; p=p}) -> 
                     Some(key_lid, ewithinfo (Exp_fvar(l', Some eref)) s p)
                 | None -> None)
      | _ -> None in
      match try_lookup_unqualified_name env lid (finder (range_of_lid lid)) with
        Some (_, e) -> Some e
      | _ -> None in
    profilel f [!dc_ctr; dc_ctr_cum]

let try_lookup_field_name env lid = 
  let f () = 
    let rec finder full_lid = function
      | Sig_record_typ (_, _, _, {v=Typ_record(fn_t_l, _)}, _) -> 
          find_map fn_t_l 
            (fun (fn,t) -> 
               if Sugar.lid_equals full_lid fn then 
                 Some (full_lid, ewithpos Exp_bot dummyRange)
               else None)

      | Sig_extern_typ(eref, s) -> 
          let mname, id = Util.pfx full_lid.lid in
            if not (Sugar.lid_equals (asLid mname) env.curmodule) then None
            else
              finder lid s (* TODO: fix this for extern field names
                              let lid' = (Sugar.eref_to_lid eref)@[id] in
                              finder lid' s *)
          
      | _ -> None in
      match try_lookup_unqualified_name env lid finder with
          Some(l, _) -> Some l 
        | _ -> None in
    profilel f [!fn_ctr; fn_ctr_cum]

let try_lookup_all_associated_field_names env lid = 
  let f () = 
    let rec finder full_lid = function
      | Sig_record_typ (_, _, _, {v=Typ_record(fn_t_l, _)}, _) -> 
          find_map fn_t_l 
            (fun (fn,t) -> 
               if Sugar.lid_equals full_lid fn then 
                 let all_fields = List.map fst fn_t_l in 
                   Some (all_fields, ewithpos Exp_bot dummyRange)
               else None)

      | Sig_extern_typ(eref, s) -> 
          let mname, id = Util.pfx full_lid.lid in
            if not (Sugar.lid_equals (asLid mname) env.curmodule) then None
            else finder lid s (* TODO: fix this for extern field names
                                 let lid' = (Sugar.eref_to_lid eref)@[id] in
                                 finder lid' s *)
      | _ -> None in
      match try_lookup_unqualified_name env lid finder with
        | Some(l, _) -> Some l 
        | _ -> None in
    profilel f [!fn_ctr; fn_ctr_cum]

      
let unique_name env lid = 
  match try_lookup_lid env lid with
      None -> true
    | Some _ -> false
        
let unique_typ_name env lid = 
  match try_lookup_typ_name env lid with
      None -> true
    | Some a -> 
        pr "Found type %A\n" a; false

let dump_env (env:env) = printfn "%A" (env.sigaccum@env.externs)
