#light "off"
// (c) Microsoft Corporation. All rights reserved
module Microsoft.FStar.Desugar 

open Sugar
open Absyn
open Range
open Const
open Util
open DesugarEnv
open Profiling 
open KindAbbrevs

type range = Range.range

exception Error of string * range 

let Kind_prop = withhash Absyn.Kind_prop
let Kind_affine = withhash Absyn.Kind_affine
let Kind_star = withhash Absyn.Kind_star
let Kind_erasable = withhash Absyn.Kind_erasable
let Kind_unknown = withhash Absyn.Kind_unknown
let Kind_tcon x = withhash (Absyn.Kind_tcon x)
let Kind_dcon x = withhash (Absyn.Kind_dcon x)
let Kind_boxed x = withhash (Absyn.Kind_boxed x)

let dstyp_ctr = new_counter "desugar_typ"
let dsform_ctr = new_counter "desugar_formula"
let dsexp_ctr = new_counter "desugar_exp"
let dsmatch_ctr = new_counter "desugar_match"
let dstdef_ctr = new_counter "desugar_typ_defn"
let dstdecl_ctr = new_counter "desugar_typ_decl"
let dstermdecl_ctr = new_counter "desugar_term_decl"
let peq_by_constr_ctr = new_counter "partitionEqnsByConstructor" 
let peq_mixture_ctr = new_counter "partitionMixture" 
let cra_ctr = new_counter "constructor_rule_applicable" 
let vra_ctr = new_counter "variable_rule_applicable" 
let mra_ctr = new_counter "mixture_rule_applicable" 


exception ErrorEnv of string * range * env

let DEBUG_LEVEL = 10
(* let W t = withsort t Kind_unknown *)

let collect_typ_decls decls = 
  let accum = List.fold_left (fun accum d -> match d with 
                                | Def_extern_ref _
                                | Def_extern_val _
                                | Def_extern_typ _
                                | Def_val _ 
                                | Def_open _ 
                                | Def_tycon _ 
                                | Def_query _ 
                                | Def_logic_function _
                                | Def_assume _ -> d::accum
                                | _ -> accum) [] decls in
    List.rev accum

let collect_letbound_names decls = 
  let name_of_pat = function 
    | Pat_as(Pat_wild _, name, _, _) -> Some name
    | Pat_lid({lid=[f]}, _, _) -> Some f
    | _ -> None in
  let name_of_binding = function 
    | Binding(_, p, _, _) -> name_of_pat p in
  let exists_val_decl (id:Sugar.ident) decls = 
    match decls |> Util.findOpt (function Def_val(id',_, _) -> id.idText=id'.idText | _ -> false) with 
      | None -> false
      | Some _ -> true in 
  let rec check_val_decls names drev = match names with 
    | [] -> true
    | id::rest -> 
        if exists_val_decl id decls
        then match drev with 
          | [] -> false
          | hd::drest -> exists_val_decl id [hd] && check_val_decls rest drest
        else check_val_decls rest drev in
    List.fold_left (fun (accum,drev) d -> match d with 
                      | Def_let(_, bindings, r) -> 
                          let names = bindings |> List.map name_of_binding |> List.filter (function None -> false | _ -> true) |> Util.projSomes in 
                            if !Options.relax_order || check_val_decls names drev then 
                              names@accum, d::drev
                            else 
                              let msg = spr "Value declarations and let-bindings for (%s) are out of order" (String.concat ", " (names |> List.map (fun id -> id.idText))) in 
                                raise (Error(msg,r))
                      | _ -> accum, d::drev) ([],[]) decls 
      
let var_from_fvar fv = match fv.v with
    Exp_fvar (qname, _) -> qname
  | _ -> raise Impos

let lid_from_fvar fv = match fv.v with
    Exp_fvar (qname, _) -> 
      qname.v
  | _ -> raise Impos

let ppname_from_bvar bv = match bv.v with
    Exp_bvar bv -> bvar_ppname bv
  | _ -> raise Impos

let get_pat_var = function
    Pat_as(Pat_wild _, v, _, _) -> Some v
  | _ -> None

let rec is_tuple_pat = function
    Pat_tuple _ -> true
  | Pat_paren(p,r) -> is_tuple_pat p
  | _ -> false
      
(* Type definitions used in pattern matching compiler *)
type eqnlhs = list<exp>
type eqnbranch = {patterns:list<Sugar.synpat>;
                  pendingsubs:list<binding>; (* pending substs *)
                  whenclause:option<Sugar.synexpr>;
                  branch:Sugar.synexpr; (* branch *)
                  range:Range.range}
type constreqn = {constrname:Disj<lident,sconst>; nargs:int; argppnames:list<option<Disj<ident, option<typar>>>>; crange:Range.range; eqnbranches:list<eqnbranch>}
type eqns_t = (int*env*eqnlhs*list<eqnbranch>)
exception ErrorPat of string * eqnlhs * list<eqnbranch>

let extend_env_with_quants env lid = 
  let env = match try_lookup_val_decl_typ env lid with
    | None -> env
    | Some t -> 
        let rec collect_quants out t = match t.v with 
          | Typ_univ(bvd, k, formulas, t) -> collect_quants ((bvd, k)::out) t
          | _ -> out in
        let quants = collect_quants [] t in
          List.fold_left (fun env (bvd, k) -> 
                            push_tbinding_with_real_name env (DSBinding_typ_var(bvd.ppname, k)) bvd) env quants  in
    env

let is_constr_app env e = match e.v with
    Exp_constr_app(v, tl, _, el) -> Some(v, tl, el)
  | Exp_fvar (v, _) -> 
      (match try_lookup_datacon env v.v with 
           Some _ -> Some(v, [], [])
         | _ -> None)
  | _ -> None 
let is_primop e = match e.v with 
  | Exp_primop(v, el) ->  Some(v,el) 
  | Exp_fvar ({v={lid=[v]}; sort=_; p=_}, _) 
  | Exp_fvar ({v={lid=[_;v]}; sort=_; p=_}, _) 
      when AbsynUtils.is_operator v.idText -> Some(v, [])
  | _ -> None 

let rec try_desugar_arithmetic_exp e = match e.v with 
  | _ when AbsynUtils.is_value e -> e
  | Exp_primop(opname, args) -> 
      let args = List.map try_desugar_arithmetic_exp args in 
      let mkApp lid = ewithinfo (Exp_constr_app(fvwithpos lid e.p, [], [], args)) e.sort e.p in 
        (match opname.idText with 
           | "op_Addition" -> mkApp Const.add_lid
           | "op_Subtraction" -> mkApp Const.sub_lid
           | "op_Multiply" -> mkApp Const.mul_lid
           | "op_Division" -> mkApp Const.div_lid
           | "op_Minus" -> mkApp Const.minus_lid 
           | "op_Modulus" -> mkApp Const.modulo_lid 
           | _ -> ewithinfo (Exp_primop(opname, args)) e.sort e.p)
  | _ -> e

(* extend type environment with type variables appearing in t *)
let rec collect_tvars_typ bindings env t : (list<btvdef * kind> * env) =
  let rec simple_kind_eq (k1:Sugar.kind) (k2:Absyn.kind) = match k1, k2(* .u *) with (* cheap equality on kinds; the real thing follows in tc *)
    | Sugar.Kind_star, Kind_star
    | Sugar.Kind_affine, Kind_affine  
    | Sugar.Kind_prop, Kind_prop
    | Sugar.Kind_erasable, Kind_erasable -> true
    | _ -> false in
  let desugar_simple_kind : Sugar.kind -> Absyn.kind option = function 
    | Sugar.Kind_star -> Some Kind_star
    | Sugar.Kind_affine -> Some Kind_affine  
    | Sugar.Kind_prop -> Some Kind_prop
    | Sugar.Kind_erasable -> Some Kind_erasable 
    | _ -> None in
    match t with
      | Type_var (Typar(id,kindOpt), r) ->
          (match try_lookup_typ_var env id with
             | Some tv -> 
                 (match kindOpt with
                    | Some k1 when not (simple_kind_eq k1 tv.sort) -> 
                        let msg = spr "Inconsistent kind annotation on type variables (%s); use an explicit type abstraction" id.idText in
                          raise (Error(msg,r))
                    | _ -> bindings, env)
             | None -> (* TODO: some of these will be Kind_affine *)
                 let kind = match kindOpt with 
                     None -> Kind_star
                   | Some k -> 
                       match desugar_simple_kind k with 
                         | None -> 
                             let msg = spr "Complex kind ascriptions are not supported on implicit type variables (%s); use an explicit type abstraction" id.idText in
                               raise (Error(msg,r))
                         | Some k -> k in
                   (* desugar_kind env k in *)
                 let b = DSBinding_typ_var (id, kind) in
                 let env', bvd = push_local_tbinding env b in
                   (bvd, kind)::bindings, env')
      | Type_tid _ 
      | Type_anon _
      | Type_term_index _
      | Type_lid _ -> bindings, env
      | Type_app (t, tl, r) ->
          let bindings', env' = collect_tvars_typ bindings env t in
            List.fold_left (fun (bindings', env') t -> collect_tvars_typ bindings' env' t) (bindings',env') tl
      | Type_tuple (xtl, r) ->
          List.fold_left (fun (b,env) (x,t) -> collect_tvars_typ b env t) (bindings, env) xtl
      | Type_fun ((x,t), t', r) ->
          List.fold_left (fun (b,env) t -> collect_tvars_typ b env t) (bindings, env) [t;t']
      | Type_refinement (x, t, f, _, r) ->
          let b',env' = collect_tvars_typ bindings env t in
          let b'', env'' = collect_tvars_formula b' env' f in
            b'', env''
      | Type_named(_, t, r)
      | Type_affine(t, r) -> collect_tvars_typ bindings env t
      | Type_lam (id,t,t',_) -> 
          let bindings, env = collect_tvars_typ bindings env t in
            collect_tvars_typ bindings env t'
      | Type_tlam(Typar(a,kopt), t, _) -> 
          let b = DSBinding_typ_var(a, Kind_unknown) in 
          let env, _ = push_local_tbinding env b in 
            collect_tvars_typ bindings env t
      | Type_formula(f,r) -> collect_tvars_formula bindings env f
      | Type_qtyp (ars, t, _) -> 
          let f (bindings, env) (ta : typar) = 
            let b, x, k = match ta with 
              | Typar (x, None) -> DSBinding_typ_var (x, Kind_star), x, Kind_star
              | Typar (x, Some k) -> 
                  let kk = desugar_simple_kind k in 
                  let kk = match kk with None -> Kind_unknown | Some kk -> kk in
                    DSBinding_typ_var (x, kk), x, kk in 
            let env, bvd = push_local_tbinding env b in
              (bvd, k)::bindings, env in
        let _, env' = List.fold_left f (bindings, env) ars in
        let bindings'', env'' = collect_tvars_typ [] env' t in
        let env''' = List.fold_left (fun env (x, k) -> let b = DSBinding_typ_var (x.realname, k) in push_tbinding_with_real_name env b x) env bindings'' in
          (bindings'' @ bindings), env'''
      | Type_paren(t, _) -> collect_tvars_typ bindings env t
      | Type_ascribed(t, k, _) -> 
          let bindings, env = collect_tvars_typ bindings env t in
            collect_tvars_kind bindings env k 
      | _ -> raise (NYI "Unexpected type in CTV") 
          
and collect_tvars_formula bindings env f : (list<btvdef*kind> * env) =
  match f with
    | Form_atom (Atom_true, _) -> bindings, env
    | Form_atom (Atom_false, _) -> bindings, env
    | Form_atom (Atom_pred t, _) -> collect_tvars_typ bindings env t
    | Form_relational(f, _)
    | Form_labeled(_, f, _)
    | Form_paren(f, _)
    | Form_not (f,_) -> collect_tvars_formula bindings env f
    | Form_conj (f1, f2, _)
    | Form_disj (f1, f2, _) 
    | Form_iff (f1, f2, _)
    | Form_impl (f1, f2, _) -> 
        let b, e = collect_tvars_formula bindings env f1 in
          collect_tvars_formula b e f2
    | Form_ite (f1, f2, f3, _) -> 
        let b, e = collect_tvars_formula bindings env f1 in
        let b, e = collect_tvars_formula b e f2 in
          collect_tvars_formula b e f3
    | Form_all (x, t, f, _, _, _)
    | Form_exists (x, t, f, _, _, _) ->
        let b',env' = collect_tvars_typ bindings env t in
          collect_tvars_formula b' env' f
    | Form_quant(Typar (tv, Some k), f, _) -> 
        let bindings1, env = collect_tvars_kind bindings env k in
        let b = DSBinding_typ_var(tv, Kind_unknown) in 
        let env1, _ = push_local_tbinding env b in
        let bindings2, env2 = collect_tvars_formula [] env1 f in
        let env2 = bindings2 |> List.fold_left 
            (fun env (x, k) -> 
               let b = DSBinding_typ_var (x.realname, k) in 
                 push_tbinding_with_real_name env b x) env in
          bindings2@bindings1, env2
            
and collect_tvars_kind bindings env : (Sugar.kind -> (list<btvdef * kind> * env)) = function
  | Sugar.Kind_unknown
  | Sugar.Kind_prop
  | Sugar.Kind_erasable
  | Sugar.Kind_star 
  | Sugar.Kind_affine -> bindings, env
  | Sugar.Kind_tcon (aopt, k, k') -> 
      let bindings1, env = collect_tvars_kind bindings env k in
      let env2 = match aopt with 
        | None -> env 
        | Some a -> 
            let kk = desugar_kind env k in 
            let b = DSBinding_typ_var(a, kk) in
            let env, _ = push_local_tbinding env b in 
              env in 
      let bindings2, _ = collect_tvars_kind [] env k' in
      let env2 = bindings2 |> List.fold_left 
          (fun env (x, k) -> 
             let b = DSBinding_typ_var (x.realname, k) in 
               push_tbinding_with_real_name env b x) env in
        bindings2@bindings1, env2
  | Sugar.Kind_dcon(xopt, t, k) ->
      let bindings, env = collect_tvars_typ bindings env t in
        collect_tvars_kind bindings env k 
          
and desugar_kind env k = 
  (* let _ = pr "@@@@@Trying to collect tvars for kind %A\n" k in *)
  (* let quants, env = collect_tvars_kind [] env k in  *)
  (* let _ = pr "@@@@@Got tvars\n" in *)
  let quants = [] in
  let rec aux env = function
    | Sugar.Kind_erasable -> Kind_erasable
    | Sugar.Kind_prop -> Kind_prop
    | Sugar.Kind_star -> Kind_star
    | Sugar.Kind_affine -> Kind_affine
    | Sugar.Kind_unknown -> Kind_unknown
    | Sugar.Kind_tcon (aopt, k1, k2) -> 
          let k1 = aux env k1 in 
          let env, aopt = match aopt with 
            | None -> env, None
            | Some a -> 
                let b = DSBinding_typ_var(a, k1) in
                let env, bvd = push_local_tbinding env b in 
                   env, Some bvd in 
          let k2 = aux env k2 in
           Kind_tcon (aopt, k1, k2)
    | Sugar.Kind_dcon (xopt, t, k) as kk ->
        let env0 = env in 
        let t = desugar_typ env t in
        let env, xopt = match xopt with 
          | None -> env, None
          | Some x -> 
              let b = DSBinding_var(x, t) in 
              let env, bvd = push_local_vbinding env b in
                   env, Some bvd in 
          (* pr "\n************************\nDesugaring dependent kind %A\n initial env %A\n binding env %A\n" kk env0.localbindings env.localbindings; *)
        let k = aux env k in 
            Kind_dcon (xopt, t, k) in
  let k' = aux env k in 
    match quants with 
      | [] -> k'
      | _ -> List.fold_right (fun (bvd,k) out -> Kind_tcon(Some bvd, k, out)) quants k'

and desugar_to_typ_or_exp env t : Disj<typ, (exp*range)> = 
  let Wt t' = twithinfo t' Kind_unknown (range_of_syntype t) in
  let top = t in 
    match t with
      | Type_lid (lid, r) -> (* GOTCHA: Fix parser ambiguity here? *)
          (match try_lookup_typ_name env lid with
               Some t -> Inl t
             | None -> 
                 (* The parser cannot distinguish typ params from term
                    params; So, if we can't resolve lid to a type name,
                    try to resolve it as a term param.  GOTCHA: This may
                    be a problem if term variable names can shadow type
                    names. FYI: New parser ensures that bound tvar names
                    are distinct from bound vars. But, this could still be
                    an issue for free variables. *)
                 let e = desugar_expression env (Expr_lid_get(false, lid, r)) in 
                   Inr(e, r))
      | Type_app (t, tl, r) -> 
          (match desugar_to_typ_or_exp env t with 
             | Inl t -> 
                 let tapp =
                   List.fold_left (fun tapp t ->
                                     match (desugar_to_typ_or_exp env t) with
                                       | Inl t -> Wt (Typ_app (tapp, t)) 
                                       | Inr (e,p) -> 
                                           let e = try_desugar_arithmetic_exp e in 
                                             Wt (Typ_dep (tapp, e))) t tl in
                   Inl tapp
             | Inr (e,_) -> (* this may be a data constructor application *)
                 match is_constr_app env e with 
                   | Some (v, targs, vargs) -> (* e1 is a constr app; so produce an Exp_constr_app *)
                       let el = tl |> List.map (fun t -> match desugar_to_typ_or_exp env t with 
                                                  | Inr (e,_) -> e
                                                  | Inl t -> raise (Error (spr "Expected expression; got type (%s)" (Pretty.strTyp t), r))) in
                         Inr ((ewithpos (Exp_constr_app (v, targs, [], vargs@el)) r), r)
                   | _ -> 
                       raise (Error (spr "Expected type; got expression (%s)" (Pretty.strExp e), r)))
            
      | Type_tuple (xtl, r) ->
          let rec desugar_tuple_typ env = function
            | [] -> raise (Error ("Unexpected empty tuple type", r))
            | [(x,t)] -> desugar_typ env t
            | (x1,t1)::tl -> 
                let t1 = desugar_typ env t1 in
                let tup = match x1 with 
                    None -> 
                      let t2 = desugar_tuple_typ env tl in
                        Typ_dtuple([(None, t1); (None, t2)])
                  | Some x1 -> 
                      let env', x1bvd = push_local_vbinding env (DSBinding_var(x1,t1)) in
                      let t2 = desugar_tuple_typ env' tl in
                        Typ_dtuple [(Some(x1bvd), t1); (None, t2)] in
                  (Wt tup) in
            Inl (desugar_tuple_typ env xtl)
              
      | Type_fun ((x,t), t', r) ->
          let t = desugar_typ env t in
          let bvd_opt, env' = match x with
            | None -> None, env
            | Some x -> 
                let env', xbvd = 
                  push_local_vbinding env (DSBinding_var(x, t)) in
                  Some(xbvd), env' in
          let t' = desugar_typ env' t' in
            Inl (Wt (Typ_fun (bvd_opt, t, t')))
              
      | Type_var (Typar(id,_), r) ->
          (match try_lookup_typ_var env id with
               Some t -> Inl t
             | None -> 
                 raise (ErrorEnv ("Unbound type variable: "^id.idText, r, env)))
            
      | Type_term_index (e, r) ->
          let e = desugar_expression env e in
            Inr (e, r)
              
      | Type_refinement (x, t, f, ghost, r) ->
          let t = desugar_typ env t in
          let env', xbvd = push_local_vbinding env (DSBinding_var(x, t)) in
          let f = AbsynUtils.strip_pf_typ (desugar_formula ghost env' f) in
            Inl (Wt (Typ_refine (xbvd, t, f, ghost)))

      | Type_affine(t,r) -> 
          let t = desugar_typ env t in
            Inl (Wt (Typ_affine t))
              
      | Type_anon(r) ->
          Inl (twithinfo Typ_unknown Kind_unknown r)

      | Type_tid(i,r) -> 
          Inl (twithinfo (Typ_meta (Meta_tid i)) Kind_unknown r)

      | Type_named(s, t, r) -> 
          let t = desugar_typ env t in 
            Inl (twithinfo (Typ_meta (Meta_named(s, t))) Kind_unknown r)

      | Type_lam(x, t, t',_) -> 
          let t = desugar_typ env t in
          let env, xbvd = push_local_vbinding env (DSBinding_var(x, t)) in
          let t' = desugar_typ env t' in
            Inl (Wt (Typ_lam(xbvd, t, t')))

      | Type_tlam(Typar(a,kopt), t, r) ->
          let k = match kopt with
            | None -> Kind_unknown
            | Some k -> desugar_kind env k in
          let env, abvd = push_local_tbinding env (DSBinding_typ_var(a, k)) in
          let t = desugar_typ env t in
            Inl (Wt (Typ_tlam(abvd, k, t)))

      | Type_formula(f, r) -> 
          let f = AbsynUtils.strip_pf_typ (desugar_formula false env f) in  (* Nik: ToDo Review EA kind, ghost = true *)
            Inl f

      | Type_paren(t, _) -> desugar_to_typ_or_exp env t
          
      | Type_ascribed(t, k, _) -> 
          let tt = desugar_typ env t in 
          let kk = desugar_kind env k in 
            Inl (Wt (Typ_ascribed(tt, kk)))

      | Type_qtyp(tps, t, r) -> 
          let env, bvdefs_rev = 
            List.fold_left (fun (env, (bvdefs:list<btvdef * kind>)) (Typar(id, kopt)) -> 
                              let k = match kopt with   
                                | None -> Kind_star
                                | Some k -> desugar_kind env k in
                              let env, idbvd = 
                                push_local_tbinding env (DSBinding_typ_var(id, k)) in
                                env, ((idbvd, k)::bvdefs)) (env, []) tps  in
          let t = desugar_typ env t in
          let tuniv = List.fold_left (fun t (bvd,k) -> Wt (Typ_univ(bvd, k, [], t))) t bvdefs_rev in
            Inl tuniv
      | _ -> raise (NYI "Unknown type constructor")

and desugar_typ env t : Absyn.typ =
  let top = t in 
  let t, (quants, env_with_quants) =  match t with 
    | Type_qtyp(tpars, t, r) ->
        let out = List.fold_left 
          (fun (bindings, qenv) (Typar(id, kopt)) -> 
             (match try_lookup_typ_var qenv id with 
                | Some _ -> raise (Error ("Declared type variables must be unique; '"^id.idText^ " has already been used", r))
                | None -> 
                    let kind = match kopt with
                      | None -> Kind_star 
                      | Some k -> desugar_kind qenv k in
                    let b = DSBinding_typ_var (id, kind) in
                    let qenv', idbvd = push_local_tbinding qenv b in
                      (idbvd, kind)::bindings, qenv')) ([], env) tpars in
          t, out 
    | _ -> if generalize env then t, collect_tvars_typ [] env t else t, ([], env) in
    match desugar_to_typ_or_exp env_with_quants t with
        Inl t ->
          List.fold_left (fun t (bvd, k) -> 
                            let r = union_ranges (range_of_bvd bvd) t.p in
                              AbsynUtils.Wtr (Typ_univ (bvd, k, [], t)) r) t quants
      | Inr (e,r) -> raise (Error (spr "Expected type; got expression (%s)" (Pretty.strExp e), r))
          
and desugar_formula ghost env ff = 
  let r = range_of_synformula ff in 
  let wrap_pf_typ, wrap_pf_typ' = AbsynUtils.wrap_pf_typ_r r, AbsynUtils.wrap_pf_typ'_r r in
    (* if ghost then AbsynUtils.wrap_e2p_typ_r r , AbsynUtils.wrap_e2p_typ'_r r *)
    (* else *) 
  let desugar_formula = desugar_formula ghost in
  let Wt t = twithinfo t Kind_unknown r in
  let rec aux env = function
    | Form_atom (a,r) ->
        let t = desugar_atom env a in
          wrap_pf_typ t
          
    | Form_labeled(s, f, r) -> 
        let t = desugar_formula env f in 
        let s = ewithpos (Exp_constant (Const_string(s, r))) r in 
          Wt (Typ_app(Wt(Typ_dep(lbl_typ, s)), t))
            
    | Form_not (f, r) ->
        let t = desugar_formula env f in
          Wt (wrap_pf_typ' (Typ_app(not_typ, t)))

    | Form_conj (f1, f2, r) ->
        let t1 = desugar_formula env f1 in
        let t2 = desugar_formula env f2 in
        let t1' = Wt (Typ_app (and_typ, t1)) in
          Wt (wrap_pf_typ' (Typ_app (t1', t2)))

    | Form_disj (f1, f2, r) ->
        let t1 = desugar_formula env f1 in
        let t2 = desugar_formula env f2 in
        let t1' = Wt (Typ_app (or_typ, t1)) in
          Wt (wrap_pf_typ' (Typ_app (t1', t2)))
           
    | Form_all (x, t, f, r, pats, isAffine) -> 
        let t = desugar_typ env t in
        let env', xbvd = push_local_vbinding env (DSBinding_var(x, t)) in
        let f' = desugar_formula env' f in
        let f' = match desugar_patterns env' pats with 
          | [] -> f'
          | p -> Wt (wrap_pf_typ' (Typ_meta(Meta_pattern(f', p)))) in 
        wrap_pf_typ (AbsynUtils.mkForall xbvd t f')

    | Form_exists (x, t, f, r, pats, isAffine) -> 
        let t = desugar_typ env t in
        let env', xbvd = push_local_vbinding env (DSBinding_var(x, t)) in
        let f = desugar_formula env' f in
        let f = match desugar_patterns env' pats with 
          | [] -> f
          | p -> Wt (wrap_pf_typ' (Typ_meta(Meta_pattern(f, p)))) in
        let exists_typ = if isAffine then Const.existsA_typ else Const.exists_typ in 
        Wt (wrap_pf_typ' (Typ_app(Wt (Typ_app(exists_typ, t)),
                                  Wt (Typ_lam(xbvd, t, f)))))
            
    | Form_impl (f1, f2, r) -> 
        let t1 = desugar_formula env f1 in
        let t2 = desugar_formula env f2 in
        let t1' = Wt (Typ_app (implies_typ, t1)) in
          Wt (wrap_pf_typ' (Typ_app (t1', t2)))

    | Form_iff(f1, f2, r) -> 
        let t1 = desugar_formula env f1 in
        let t2 = desugar_formula env f2 in
        let t1' = Wt (Typ_app (iff_typ, t1)) in
          Wt (wrap_pf_typ' (Typ_app (t1', t2)))
        
    | Form_paren(f, r) -> aux env f

    | Form_quant (Typar(tv, Some k), f, r) -> 
        let k = desugar_kind env k in 
        let env, tvbvd = push_local_tbinding env (DSBinding_typ_var(tv, k)) in 
        let t = desugar_formula env f in 
          Wt (Typ_univ(tvbvd, k, [], t))

    | Form_ite(f, f1, f2, r) -> 
        let p = desugar_formula env f in 
        let p1 = AbsynUtils.mkTlam None (fst <| AbsynUtils.mkRefinedUnit p) (desugar_formula env f1) in 
        let p2 = AbsynUtils.mkTlam None (fst <| AbsynUtils.mkRefinedUnit (AbsynUtils.mkNot p)) (desugar_formula env f2) in 
          AbsynUtils.mkTypApp (AbsynUtils.mkTypConst Const.ifthenelse_lid) [p;p1;p2] []
            
    | Form_relational(f, r) -> 
        let t = desugar_formula env f in 
          Wt (Typ_app(reln_typ, t))
  in
        
  let bindings, env = collect_tvars_formula [] env ff in
  let t = aux env ff in
  List.fold_left (fun t (a, k) -> Wt (Typ_univ(a, k, [], t))) t bindings 

and desugar_patterns env pats : formula_pat list = 
    pats |> List.map (function  
                        | Atom_pred(t) -> 
                            (match desugar_to_typ_or_exp env t with
                               | Inl t -> Inl t
                               | Inr (e,_) -> Inr e)
                        | _ -> failwith "Unexpected pattern in formula") 

and desugar_atom env = function
  | Atom_true -> true_typ
  | Atom_false -> false_typ
  | Atom_pred t -> desugar_typ env t
    
and desugar_expression env (ee:Sugar.synexpr):  exp = 
  let desugar_fieldproj env e path r = 
    let e = desugar_expression env e in
    let ltxt = Sugar.text_of_lid path in
      if ltxt  = "One" then 
        ewithpos (Exp_proj(e, Const.tuple_proj_one)) r
      else if ltxt = "Two" then
        ewithpos (Exp_proj(e, Const.tuple_proj_two)) r
      else
        List.fold_left 
          (fun e fn -> 
            let lid = asLid [fn] in 
            let fn = 
              if !Options.ts_star then lid 
              else match try_lookup_field_name env lid with
                | Some l -> l
                | None -> 
                  raise (ErrorEnv ("Unbound field name: "^(text_of_lid lid), 
                                   range_of_lid lid, env)) in
            ewithpos (Exp_proj (e, fn)) r) e path.lid  in
  let check_constr_app env e = match is_constr_app env e with 
    | None -> e
    | Some(v, _, _) -> ewithpos (Exp_constr_app(v, [], [], [])) e.p in
  let thunk () = match ee with
    | Expr_id_get x -> 
        (match try_lookup_lid env (asLid [x]) with
           | Some e -> check_constr_app env e
           | None -> 
               (* pr "Expr_id_get: Variable is %A\nEnvironment is %A\n" x env; *)
               raise (ErrorEnv ("Unbound variable: "^x.idText, x.idRange, env)))
          
    | Expr_lid_get (b, lid, r) -> 
        (match try_lookup_lid env lid with
           | Some e -> check_constr_app env e
           | None -> (* not a qname; try a projection *)
               (match lid.lid with 
                    [x] -> raise (ErrorEnv("Unbound variable: "^x.idText, x.idRange, env))
                  | _ ->
                      let lid', fieldname = Util.pfx lid.lid in
                      let e = Expr_lid_get(b, asLid lid', r) in
                        try 
                          desugar_fieldproj env e (asLid [fieldname]) r
                        with _ -> raise (ErrorEnv("Unbound variable: "^ (Pretty.str_of_lident lid), range_of_lid lid, env))
               ))
          
    | Expr_typed (e,t,r) -> (* TODO: This can also be a pack expression *)
        let e = desugar_expression env e in
        let t = desugar_typ env t in
          ewithpos (Exp_ascribed (e, t, [])) r
            
    | Expr_const (c, r) ->
        ewithpos (Exp_constant c) r
          
    | Expr_lvalue_get (e, lid, r) ->
        (* try to desugar this as a qualified name first; otherwise as a field projection. *)
        (match e with 
           | Expr_id_get x -> 
               let e = Expr_lid_get(false, asLid <| x::lid.lid, r) in
                 desugar_expression env e (* will try as a qname first; then as a projection *)
           | _ -> desugar_fieldproj env e lid r) (* definitely not a qname; parse as a projection *)
            
    | Expr_paren(e,r) -> (* parenthesized expressions kept in AST to distinguish A.M((x,y)) from A.M(x,y) *) 
        (* TODO: Not sure what diff this makes *)
        let e = desugar_expression env e in
        let r = Range.union_ranges e.p r in
          ewithpos e.v r

    | Expr_tuple (el, r) ->
        let rec desugar_tuple_exp = function
            [] -> raise Impos
          | [e] -> desugar_expression env e 
          | e::tl -> 
              let e1 = desugar_expression env e in
              let e2 = desugar_tuple_exp tl in
              let c = match try_lookup_lid env Const.tuple_UU_lid with
                | Some c -> c
                | None -> raise Impos in (* tuple_UU_lid should always be in there *)
                ewithpos (Exp_constr_app (var_from_fvar c, [], [], [e1;e2])) r in
          desugar_tuple_exp el 
            
    | Expr_list (el, r) ->
        let consExp, nilExp = match try_lookup_lid env cons_lid, try_lookup_lid env nil_lid with
            Some c, Some n -> c, n
          | _ -> raise Impos (* Should always be in there *) in
        let consVar, nilVar = match consExp.v, nilExp.v with 
            Exp_fvar (cvar, _), Exp_fvar(nvar, _) -> cvar, nvar 
          | _ -> raise Impos in
        let nilExp = ewithpos (Exp_constr_app (nilVar, [AbsynUtils.Wt Typ_unknown], [], [])) r in
          List.fold_right
            (fun e listExp ->
               let e = desugar_expression env e in
               let r' = Range.union_ranges e.p r in
                 ewithpos (Exp_constr_app (consVar, [AbsynUtils.Wt Typ_unknown], [], [e; listExp])) r')
            el nilExp
            
    | Expr_recd (eOpt, rel, r) when !Options.ts_star ->
      begin match eOpt with 
        | Some _ -> raise (ErrorEnv("TS* mode does not support the \"{e with fields}\" syntax", r, env))
        | None -> 
          let fields = rel |> List.map (fun ((path,fn), e) -> 
            match path.lid with 
              | [] -> (asLid [fn], desugar_expression env e)
              | _ -> raise (ErrorEnv("TS* mode does not support qualified field names", r, env))) in 
          ewithpos (Exp_recd(None, [], [], AbsynUtils.sortByFieldName fields)) r
      end
      
    | Expr_recd (eOpt, rel, r) ->
        let rel = (match eOpt, rel with
                     | Some e_base, ((path, fn), _)::_ -> 
                         let full_field_name = asLid (path.lid@[fn]) in 
                           (match try_lookup_all_associated_field_names env full_field_name with
                              | None -> raise (ErrorEnv ("Unbound field name: "^(text_of_lid full_field_name), fn.idRange, env))
                              | Some all_fields -> 
                                  let rec mk_rel (out, rel : (RecdFieldPath * synexpr) list ) = function
                                    | full_field_name::rest -> 
                                        let path, fn = Util.pfx full_field_name.lid in 
                                        let path = asLid path in
                                          (match findAndSub (fun ((_, (fn':ident)), _) -> fn.idText = fn'.idText) rel with 
                                             | None, rel -> (* no explicit assignment to field; use a projection from e_base *)
                                                 let exp = Expr_lvalue_get(e_base, asLid [fn], r) in (* maybe use full_field_name here? *)
                                                   mk_rel ((((path, fn), exp)::out), rel) rest
                                             | Some re, rel -> mk_rel (re::out, rel) rest)
                                    | [] -> 
                                        if rel = [] then out 
                                        else 
                                          let extras = String.concat ", " (List.map (fun ((path, fn), _) -> text_of_lid (asLid <| path.lid@[fn])) rel) in 
                                          let msg = spr "Extra fields: {%s}" extras in 
                                            raise (ErrorEnv(msg, fn.idRange, env)) in
                                    mk_rel ([], rel) all_fields)
                     | None, _ -> rel) in 
        let fields = List.fold_left (fun accum ((path, fn), e) ->
                                       let qname = 
                                         match try_lookup_field_name env (asLid <| path.lid@[fn]) with
                                             Some q -> q
                                           | _ -> 
                                               raise (ErrorEnv ("Unbound field name: "^(text_of_lid (asLid <| path.lid@[fn])), fn.idRange, env)) in
                                       let e = desugar_expression env e in
                                         (qname, e)::accum) [] rel in
          ewithpos (Exp_recd(None, [], [], (AbsynUtils.sortByFieldName fields))) r
            
    | Expr_lambda (spats, body, r) ->
        let spats = match spats with 
          | SPats([], r) -> SPats([SPat_typed(SPat_as(genident(Some r), r), 
                                              Type_lid(Const.unit_lid, r), r)], r)
          | _ -> spats in
        let rec spat_as_var_typ = function
          | SPat_as (id,r) ->
              (id, AbsynUtils.Wt Typ_unknown)
          | SPat_typed (p, t, r) ->
              match (spat_as_var_typ p) with
                | (id, {v=Typ_unknown; sort=_; p=_}) ->
                    let t = desugar_typ env t in
                      (id, t)
                | _ -> raise (Error ("Too many type ascriptions", r)) in
        let spat_as_binding p = 
          let (v,t) = spat_as_var_typ p in 
            DSBinding_var(v, t) in
        let rec spats_as_bindings_topt = function
          | SPats (pl, r) ->
              let bindings = List.map spat_as_binding pl in
                bindings, None
          | SPats_typed (spats, t, r) ->
              let bindings, rtopt = spats_as_bindings_topt spats  in
              let rtopt = match rtopt with 
                | None -> Some (desugar_typ env t) 
                | Some _ -> raise (Error ("Multiple return type ascriptions on a function", r)) in
                bindings, rtopt in
        let bindings, retTypOpt = spats_as_bindings_topt spats in
        let env', bvds_rev = List.fold_left 
          (fun (env, out) ((DSBinding_var(ppname,t)) as b) -> 
             let env', bvd = push_local_vbinding env b  in
               env', (bvd, t)::out) (env, []) bindings in
        let body = desugar_expression env' body in
        let body = match retTypOpt with
            None -> body
          | Some t -> ewithpos (Exp_ascribed (body, t, [])) body.p in
          List.fold_left 
            (fun body (bvd, t) -> 
               ewithpos (Exp_abs (bvd, t, body)) r) body bvds_rev
            
            
    | Expr_match (e, eqns, _, r) -> (* TODO: discard third arg from sugar *)
        profile (fun () -> desugar_match env e eqns r) dsmatch_ctr

    | Expr_app (e1, e2, r) -> 
        let exp1 = desugar_expression env e1 in
        let exp2 = desugar_expression env e2 in
          (match is_constr_app env exp1 with 
             | Some (v, tl, el) -> 
                 ewithpos (Exp_constr_app (v, tl, [], el@[exp2])) r
             | _ -> 
                 (match is_primop exp1 with 
                    | None ->  ewithpos (Exp_app (exp1, exp2)) r
                    | Some(op, args) -> ewithpos (Exp_primop(op, args@[exp2])) r))
            
    | Expr_tyapp (e1, tl, r) ->
        let e1 = desugar_expression env e1 in
        let tl = List.map (desugar_typ env) tl in
          (match is_constr_app env e1 with 
             | Some (v, [], []) -> 
                 ewithpos (Exp_constr_app(v, tl, [], [])) r
             | _ -> 
                 List.fold_left (fun e t -> ewithpos (Exp_tapp(e, t)) r) e1 tl)

    | Expr_let (false, _, [Binding(_, pat, BindingExpr(_,e), r)], body, r') when is_tuple_pat pat -> 
        (* special case: unpack expressions; desugared as match expressions *) 
        desugar_expression env (Expr_match(e, [Clause(pat, None, body, r)], false, r'))
          
    | Expr_let (isRec, _, bindings, body, r) -> 
        (* TODO: isUse is unnecessary; remove from Sugar *)
        let bodyenv, bindings = desugar_let_bindings env isRec bindings in 
        let body = desugar_expression bodyenv body in
          ewithpos (Exp_let(isRec, bindings, body)) r                

    | Expr_seq (maybe_do, e1, e2, r) -> (* TODO: ignore? false indicates "do a then b then return a" *)
        let e1 = desugar_expression env e1 in
        let dummyname = genident (Some r) in
        let env', bvd = push_local_vbinding env (DSBinding_var(dummyname, AbsynUtils.Wt Typ_unknown)) in
        let e2 = desugar_expression env' e2 in
          ewithpos (Exp_let (false, [(bvd, AbsynUtils.Wt Typ_unknown, e1)], e2)) r
            
    | Expr_cond (e, ethen, Some(eelse), rIftoThen, riftoend) ->
        let e' = Expr_match(e, [Clause(Pat_const (Const_bool true, dummyRange), None, ethen, rIftoThen);
                                Clause(Pat_const (Const_bool false, dummyRange), None, eelse, rIftoThen)],
                            false, riftoend) in
          desugar_expression env e'
            (*       let e = desugar_expression env e in *)
            (*       let ethen = desugar_expression env ethen in *)
            (*       let eelse = desugar_expression env eelse in *)
            (*         withpos (Exp_cond(e, ethen, eelse)) riftoend *)
            
    | Expr_paren(e, _) -> desugar_expression env e

    | Expr_cond (e, ethen, None, rIftoThen, riftoend) ->
        raise (Error ("Every conditional statement requires both a then- and else-branch", riftoend))
  in profile thunk dsexp_ctr
       
and desugar_let_bindings env isRec bindings : (env * list<bvvdef*typ*exp>) = 
  let unascribe = function 
    | Expr_typed(b, _, _) -> b
    | e -> e in
  match isRec, bindings with 
    | false, [Binding(bk, p, BindingExpr(tyOpt, body), r)] -> 
        let ppname, t, exp' =
          (match p with
             | Pat_as(Pat_wild _, name, _, _) ->
                 let env = extend_env_with_quants env (asLid [name]) in
                   (match tyOpt with 
                      | None -> 
                          let body = desugar_expression env body in
                            name, AbsynUtils.Wt Typ_unknown, body 
                      | Some (t,r) -> 
                          let t = desugar_typ env t in
                          let body = desugar_expression env (unascribe body) in
                          (* let body = ewithpos (Exp_ascribed (body, t, [])) (Range.union_ranges r body.p) in *)
                            name, t, body)

             | Pat_wild r -> 
                 let name = genident (Some r) in
                 let body = desugar_expression env body in
                   (match tyOpt with 
                      | None -> name, AbsynUtils.Wt Typ_unknown, body 
                      | Some (t,r) -> 
                          let t = desugar_typ env t in
                          (* let body = ewithpos (Exp_ascribed (body, t, [])) (Range.union_ranges r body.p) in *)
                            name, t, body)

             | Pat_lid(_, pats, _) ->
                 let ppname, exp', t = desugar_pat_exp_as_lambda env p body tyOpt in 
                   ppname, t, exp'

             | _ ->
              let str_range = string_of_range r in
              raise (NYI (spr "Non variable and application let bindings: %s\n %A" (string_of_range r) p))) in

        let binding = DSBinding_var (ppname, AbsynUtils.Wt Typ_unknown) in
        let env', bvd = push_local_vbinding env binding in 
          env', [(bvd, t, exp')]
            
    | false, (Binding(bk, p, BindingExpr(tyOpt, body), r))::_ -> 
        raise (Error("Unexpected multiple non-recursive let-bindings", r))
          
    | true, bindings -> 
        let env, bvd_bindings_rev = List.fold_left
          (fun (env, out) ((Binding(bk, p, bexp, r)) as b) ->
             match p with
               | Pat_as(Pat_wild _, fname, _, _)
               | Pat_lid({lid=[fname]}, _, _) -> (* TODO: where does the type annot for a let rec come from? Wthat if fname is really a lid?*)
                   let binding = DSBinding_var (fname, AbsynUtils.Wt Typ_unknown) in
                   let env', bvd = push_local_vbinding env binding in
                     env', (bvd, AbsynUtils.Wt Typ_unknown, b)::out
               | _ -> raise (NYI "Non application let rec bindings")) (env,[]) bindings in
        let letbindings = List.fold_left
          (fun bindings (bvd, t, (Binding(bk, p, BindingExpr(tyOpt, body), r))) ->
             let _, lam, t = desugar_pat_exp_as_lambda env p body tyOpt in
               (bvd, t, lam)::bindings) [] bvd_bindings_rev in
          env, letbindings

and desugar_pat_exp_as_lambda env pat exp rettyOpt : (ident * exp * typ) = (* ppname * exp *)
  match pat with
    | Pat_as(Pat_wild _, fname, _, _) -> 
        let body = desugar_expression env exp in
        let body = match rettyOpt with 
            None -> body 
          | Some (t,r) -> 
              let t = desugar_typ env t in
                ewithpos (Exp_ascribed (body, t, [])) (Range.union_ranges r (body.p)) in
          (fname, body, AbsynUtils.Wt Typ_unknown)

    | Pat_lid (fname, args, r) ->
        let (argbindings, env) =
          List.fold_left
            (fun (bindings, env) pat -> 
               let rec transPat pat = match pat with
                 | Pat_typed (Pat_as(Pat_wild _, ppname, _, _), typ, r) ->
                     let typ = desugar_typ env typ in
                     let binding = DSBinding_var(ppname, typ) in
                     let env', bvd = push_local_vbinding env binding in
                       (Inl(bvd, typ), r)::bindings, env'
                         
                 | Pat_as(Pat_wild _, ppname, _, r) ->
                     let binding = DSBinding_var(ppname, AbsynUtils.Wt Typ_unknown) in
                     let env', bvd = push_local_vbinding env binding in
                       (Inl(bvd, (AbsynUtils.Wt Typ_unknown)), r)::bindings, env'
                         
                 | Pat_paren(p,_) -> transPat p

                 | Pat_const (Const_unit,r) -> 
                     let typ = Const.unit_typ in 
                     let bvd = new_bvd (Some r) in
                       (Inl(bvd, typ), r)::bindings, env (* no point pushing into env. *)
                         
                 | Pat_tvar (Typar(id, kopt), r ) ->
                   let kk = match kopt with
                     | None -> Kind_unknown
                     | Some k -> desugar_kind env k in
                   let b = DSBinding_typ_var(id, kk) in
                   let env, bvd = push_local_tbinding env b in
                   (Inr(bvd, kk), r)::bindings, env
                     
                 | _ -> raise (Error ((spr "Do not support patterns in formal parameters: %A" pat), r)) in
                 transPat pat) ([], env) args in
          (* If there's a val declaration for fname, then gather the type variables 
             in the val decl into the current environment *)
        let env = 
          if List.exists (function Pat_paren(Pat_tvar _, _) | Pat_tvar _ -> true | _ -> false) args
          then env (* Unless there's already an explicit type abstraction *)
          else extend_env_with_quants env fname in 

        let exp, t = match exp, rettyOpt with 
          | Expr_typed(b, _, _), Some (t,r) -> 
              let t = desugar_typ env t in
                b, Some t 
          | _, None -> exp, None in 

        let body = desugar_expression env exp in

                (* ewithpos (Exp_ascribed (body, t, [])) (Range.union_ranges r (body.p)) in *)

        let lambda,t' = List.fold_left (fun (body,topt) (bvd_typ_or_kind, r) -> 
                                          match bvd_typ_or_kind with
                                            | Inl(bvd,typ) ->
                                                let body' = Exp_abs (bvd, typ, body) in
                                                let t'= match topt with None -> None | Some t -> Some (twithpos (Typ_fun(Some bvd, typ, t)) r) in
                                                let r' = Range.union_ranges r body.p in
                                                  ewithpos body' r', t'
                                            | Inr(bvd, kind) ->
                                                let body' = Exp_tabs (bvd, kind, [], body) in
                                                let t'= match topt with None -> None | Some t -> Some (twithpos (Typ_univ(bvd, kind, [], t)) r) in
                                                let r' = Range.union_ranges r body.p in
                                                  ewithpos body' r', t') (body,t) argbindings in
        let t = match t' with 
          | None -> AbsynUtils.Wt Typ_unknown 
          | Some t -> t in 
          (match fname.lid with 
               [fname] -> (fname, lambda, t)
             | _ -> raise (Error ("Unexpected qualified name in let binding", range_of_lid fname)))
    | _ ->   raise (Error ("Unexpected pattern in a function declaration", range_of_synpat pat))
  
and desugar_match env exp eqns range =
  (* See slpj-book Ch 5: Efficient compilation of pattern matching *)
    
  let rec dmatch _ix env discrims eqns defaultExp : exp =
    let flatten_constr_arg_pats ap = match ap with 
        [Pat_paren(Pat_tuple(plist, _), r)] -> plist
      | _ -> ap in
    (* drop type parameters from the pattern variables *)
    let rec drop_tvar ap = match ap with 
      | (Pat_tvar _) :: rest 
      | (Pat_uvar _) :: rest -> drop_tvar rest
      | p :: rest -> p :: (drop_tvar rest) 
      | _ -> ap in
    let rec partitionEqnsByConstructor (xx: list<eqnbranch>) : list<constreqn> = 
      let thunk () = match xx with 
        | [] -> []
        | cbranch::eqbranches ->
            match cbranch.patterns with 
              | [] -> raise Impos (* applicability check should have occured already *)
              | pat::otherPats -> 
                  let cName, argPats = match pat with
                    | Pat_lid (lid, argPats, r') ->
                        (match try_lookup_lid env lid with
                             Some fvar -> 
                               Inl (lid_from_fvar fvar), flatten_constr_arg_pats argPats
                           | None -> 
                               raise (ErrorEnv ("Unbound variable: "^(text_of_lid lid), range_of_lid lid, env)))
                    | Pat_const (c, r) -> 
                        Inr c, []
                    | _ -> raise Impos (* app check done *) in
                  let cgroup, rest =
                    List.partition (fun eqb -> match List.hd (eqb.patterns), cName with 
                                      | Pat_lid (lid, argPats, r'), Inl cname ->
                                          let qname = 
                                            match try_lookup_lid env lid with 
                                                Some q -> lid_from_fvar q
                                              | None -> raise (ErrorEnv ("Unbound variable: "^(text_of_lid lid), range_of_lid lid, env)) in
                                            qname = cname
                                      | Pat_const (c',r), Inr c when c=c' -> true
                                      | _ -> false) eqbranches in
                  let otherGroups = partitionEqnsByConstructor rest in
                  let nargs = List.length argPats in
                  let argppnames = List.map (function 
                                                 Pat_as (Pat_wild _, id, _, _) -> Some (Inl id)
                                               | Pat_tvar (typar, _) -> Some (Inr (Some typar))
                                               | Pat_uvar r -> Some (Inr None)
                                               | _ -> None) argPats in
                  let cgroup =
                    List.map (fun eqb -> match eqb.patterns, cName with 
                                | Pat_const (c', r)::otherPats, Inr _ -> {eqb with patterns=otherPats}
                                | Pat_lid(_, argPats, r')::otherPats, Inl cname -> 
                                    let argPats = flatten_constr_arg_pats argPats in
                                      if List.length argPats <> nargs then
                                        raise (Error ("Inconsistent number of arguments to constructor " 
                                                      ^((Sugar.text_of_path -<- Sugar.path_of_lid) cname)^" in pattern", r'))
                                      else
                                        {eqb with patterns=(drop_tvar argPats)@otherPats}
                                | _ -> raise Impos) (cbranch::cgroup) in
                  let ceqn = {constrname=cName; nargs=nargs; argppnames=argppnames; crange=cbranch.range; eqnbranches=cgroup} in
                    ceqn::otherGroups
      in
        profile thunk peq_by_constr_ctr
    in


    let partitionMixture (eqbranches:list<eqnbranch>) : list<list<eqnbranch>> =
      let thunk () = 
        let rec phelper groups is_var_chunk eqbranches =
          let gather_group test eqbranches =(*  : list<eqnbranch> = *)
            let rec matching_prefix group eqbranches = (*  : (list<eqnbranch> * list<eqnbranch>) =  *)
              match eqbranches with
                | [] -> group, eqbranches
                | hd::tl -> if test hd then matching_prefix (hd::group) tl else group, eqbranches
            in
            let group, rest = matching_prefix [] eqbranches in
              List.rev group, rest
          in
          let is_eqb_pat_a_var eqb = 
            match eqb.patterns with 
              | (Pat_wild _)::_ 
              | (Pat_as(Pat_wild _, _, _, _))::_ -> true
              | _ -> false
          in
            match eqbranches with
              | [] -> List.rev groups
              | _  ->
                  let test = if is_var_chunk then is_eqb_pat_a_var else (not -<- is_eqb_pat_a_var) in
                  let hdGroup, rest = gather_group test eqbranches in
                    let groups = match hdGroup with
                      | [] -> groups
                      | _ -> hdGroup::groups in
                      phelper groups (not is_var_chunk) rest
        in
          phelper [] true eqbranches
      in
        profile thunk peq_mixture_ctr 
    in
      
    let constructor_rule_applicable eqbs = 
      let thunk () = 
      let result = List.for_all (fun eqb -> match eqb.patterns with 
                                     | [] -> false
                                     | pat::_ -> 
                                         match pat with
                                           | Pat_lid _ 
                                           | Pat_const _ -> true
                                           | _ -> false) eqbs in
        result in
        profile thunk cra_ctr in


    let variable_rule_applicable eqbs =       
      let thunk () = List.for_all
        (fun eqb -> match eqb.patterns with 
             [] -> false 
           | pat::tl ->  match pat with 
               | Pat_uvar _
               | Pat_tvar _
               | Pat_wild _ 
               | Pat_as(Pat_wild _, _, _, _) -> true
               | _ -> false) eqbs in
        profile thunk vra_ctr in


    let mixture_rule_applicable eqbs = 
      let thunk () = 
        ((not -<- variable_rule_applicable) eqbs) &&
          ((not -<- constructor_rule_applicable) eqbs) &&
          List.for_all (fun eqb -> match eqb.patterns with 
                          | [] -> false
                          | pat::tl -> match pat with
                              | Pat_lid _
                              | Pat_wild _ 
                              | Pat_const _
                              | Pat_as(Pat_wild _, _, _, _) -> true
                              | _ -> false) eqbs in 
        profile thunk mra_ctr in
      
    let mk_inr s eqns = 
      (*let _ = pr "########## %s\n" s in*)
      let (_, _, discrims, eqbs) = eqns in
      let _ = match discrims with 
        | [] -> 
            List.for_all (fun eqb -> match eqb.patterns with
                              [] -> true
                            | _ -> raise (NYI s)) eqbs
        | _ -> true in
        Inr eqns in
      
    (* If each eqn E_i begins with a variable x_i,
       we can reduce the match by substituting v_0 the
       discriminant variable for x_i in each branch b_i. *)
    let try_elim_vars (_ix, env, discrims, eqns) : Disj<exp, eqns_t> = 
      match discrims with
          [] -> Inr(_ix, env, discrims, eqns)
        | discrim_hd::discrim_tl ->
            if (variable_rule_applicable eqns) then 
              let eqbs_rev = List.fold_left
                (fun eqbs eqb -> (* (pat::pats, branch, r) eqns -> *)
                   match eqb.patterns with 
                       pat::rest -> 
                         (match pat with                              
                            | Pat_wild _ -> 
                                let eqb' = {eqb with patterns=rest} in
                                  eqb'::eqbs
                            | Pat_as(Pat_wild _, x, _,  _) -> 
                                let ppname = ppname_from_bvar discrim_hd in
                                let bps = DSBinding_pending_subst (x, ppname) in
                                let eqb' = 
                                  {eqb with pendingsubs=bps::eqb.pendingsubs;
                                     patterns=rest} in   
                                  eqb'::eqbs
                            | _ -> raise Impos)
                     | _ -> raise Impos) [] eqns in
              let eqbs = List.rev eqbs_rev in
                mk_inr "vars prog" (_ix, env, discrim_tl, eqbs)
            else
              mk_inr "vars no prog" (_ix, env, discrims, eqns) (* no progress *)
    in
      
    let try_elim_constructors (_ix, env, discrims, eqbranches) : Disj<exp, eqns_t> =
      match discrims with
        | [] -> mk_inr "constr np" (_ix, env, discrims, eqbranches) (* no progress *)
        | discrim_hd::discrim_tl ->
            let rec eqnGroups2exp env groups : (Disj<list<pat*exp>, list<sconst*exp>> * exp * Range.range) = match groups with
              | [] -> Inl [], defaultExp, defaultExp.p
              | ceqns::rest ->
                  let newnames = (* List.map (fun n -> ident(n, discrim_hd.p)) *) 
                    (List.map (function Some id -> id | None -> Inl (ident (gensym None, discrim_hd.p))) ceqns.argppnames) in
                  let env', vars_bvds_rev, ts_rev =
                    List.fold_left (fun (env, vars, ts) name_or_typar ->
                                      match name_or_typar with
                                        | Inl name ->
                                          let env', bvd = push_local_vbinding env (DSBinding_var (name, AbsynUtils.Wt Typ_unknown)) in
                                          let bvar = bvwithpos bvd (ceqns.crange) in
                                          let v = ewithpos (Exp_bvar bvar) (ceqns.crange) in
                                            (env', (v, bvd)::vars, ts)
                                        | Inr None -> 
                                            let tv = twithpos (Typ_unknown) (ceqns.crange) in
                                              (env, vars, tv::ts) 
                                        | Inr (Some (Typar(id, kopt))) ->
                                            let env', bvd = push_local_tbinding env (DSBinding_typ_var(id, Kind_unknown)) in
                                            let btvar = btvwithpos bvd (ceqns.crange) in
                                            let tv = twithpos (Typ_btvar btvar) (ceqns.crange) in
                                              (env', vars, tv::ts)) (env, [], []) newnames in
                  let vars, bvds = List.split (List.rev vars_bvds_rev) in
                  let vars = vars@discrim_tl in
                  let thenBranch = dmatch (_ix + 1) env' vars ceqns.eqnbranches defaultExp in
                  let elseBranches, defaultExp, range = eqnGroups2exp env rest in
                  let range = Range.union_ranges ceqns.crange range in
                  let branches = match elseBranches, ceqns.constrname with
                    | Inl lpe, Inl cname -> 
                        let thisPat = Pat_variant(cname, List.rev ts_rev, [], List.map (fun bvd -> bvd_to_bvar_s bvd Absyn.tunknown) bvds, false) in
                          Inl ((thisPat, thenBranch)::lpe)
                    | Inr lce, Inr constt -> Inr ((constt, thenBranch)::lce)
                    | Inl [], Inr constt -> Inr [constt, thenBranch]
                    | _ -> raise (Error ("Mixture of constant and constructor patterns is never well-typed", range)) in
                    branches, defaultExp, range
            in
              if (constructor_rule_applicable eqbranches) then 
                let ceqnGroups = partitionEqnsByConstructor eqbranches in
                let branches, defaultExp, range = eqnGroups2exp env ceqnGroups in
                  match branches with 
                    | Inl pat_branches -> 
                        let matchExp = Exp_match(discrim_hd, pat_branches, defaultExp) in
                          Inl (ewithpos matchExp range)
                            
                    | Inr [(Const_bool true,  _); (Const_bool false, _)] 
                    | Inr [(Const_bool true,  _)] -> 
                        let thenBranch, elseBranch = match branches with 
                            Inr [(_, thenBranch); (_, elseBranch)] -> thenBranch, elseBranch
                          | Inr [(_, thenBranch)] -> thenBranch, defaultExp in
                        let ifstmt = ewithpos (Exp_cond(discrim_hd, thenBranch, elseBranch)) range in
                          Inl ifstmt
                        
                    | Inr const_branches -> 
                        let nested_cond = List.fold_right 
                          (fun (constt, then_branch) else_branch -> 
                             let discr = match constt with
                               | Const_bool true -> discrim_hd
                               | _ ->  
                                   let constt = AbsynUtils.Wr (Exp_constant constt) discrim_hd.p in
                                   let eq_test = AbsynUtils.mk_eqtest constt discrim_hd in
                                     eq_test in
                             let mk_else x =
                               let r = union_ranges then_branch.p else_branch.p in 
                                 AbsynUtils.Wr (Exp_cond(x, then_branch, else_branch)) r in
                               ewithpos (AbsynUtils.hoist discr mk_else) range) const_branches defaultExp in
                          Inl (nested_cond)
              else
                mk_inr "constr np 2" (_ix, env, discrims, eqbranches) (* no progress *)
    in
      
    let try_mixture (_ix, env, discrims, eqbranches) : Disj<exp,eqns_t> =
      if (mixture_rule_applicable eqbranches) then 
        (let groups = partitionMixture eqns in
         let matchExp =
           List.fold_right (dmatch (_ix + 1) env discrims) groups defaultExp in
           Inl matchExp)
      else
        mk_inr "mix np" (_ix, env, discrims, eqbranches) (* no progress *)
    in
      
    let try_empty_discrims (_ix, env, discrims, eqbranches) : Disj<exp,eqns_t> = match discrims with
      | hd::tl -> mk_inr "empty np" (_ix, env, discrims, eqbranches) (* no progress *)
      | [] ->
          let allEmptyPats = List.for_all
            (fun eqb -> match eqb.patterns with
               | [] -> true
               | pat::_ -> 
                   raise (Error ("Unexpected extra pattern variables", (range_of_synpat pat)))) eqbranches in
            match eqbranches with
              | [] -> Inl defaultExp
              | eqb::tl -> (* ordering of cases requires taking the first branch *)
                  let env = List.fold_right 
                    (fun psub env ->  (* TODO: Shadow variables between pending sub and target will blow up? *) 
                       let env, _ = push_local_vbinding env psub in 
                         env) eqb.pendingsubs env in
                  let branch =
                    match eqb.whenclause with 
                        Some wc' ->
                          let wc = desugar_expression env wc' in
                          let then_branch = desugar_expression env (eqb.branch) in
                          let else_branch = dmatch (_ix + 1) env [] tl defaultExp in
                            (*                           let eq_test = mk_eqtest wc (W (Exp_constant (Const_bool true))) in *)
                          let range = Range.union_ranges (Range.union_ranges wc.p then_branch.p) else_branch.p in
                            ewithpos (Exp_cond(wc, then_branch, else_branch)) range 
                      | None -> 
                          desugar_expression env (eqb.branch) in
                    Inl branch
    in

    let try_elim_paren_pats (_ix, env, discrims, eqbranches) : Disj<exp, eqns_t> =
      let eqb' = List.map (fun eqb -> match eqb.patterns with 
                             | pat::tl -> 
                                 (match pat with 
                                    | Pat_paren(p, r) -> 
                                        {eqb with patterns=p::tl}
                                    | _ -> eqb)
                             | _ -> eqb) eqbranches in
        mk_inr "paren" (_ix, env, discrims, eqb')
    in

    let try_elim_array_or_list (_ix, env, discrims, eqbranches) : Disj<exp, eqns_t> =
      let nilPat = Pat_lid(Const.nil_lid, [], dummyRange) in
      let eqb' = List.map (fun eqb -> 
                             let pats = List.map (function 
                                                    | Pat_array_or_list(false, pats, r) -> 
                                                        List.fold_right (fun eltpat out -> 
                                                                           Pat_lid (Const.cons_lid, [eltpat; out], r)) pats nilPat
                                                    | p -> p) eqb.patterns in
                               {eqb with patterns=pats}) eqbranches in 
        mk_inr "list patterns" (_ix, env, discrims, eqb')
    in

    let try_elim_tuple_pats (_ix, env, discrims, eqbranches) : Disj<exp, eqns_t> = 
      let eqb' = List.map (fun eqb -> match eqb.patterns with 
                             | pat::tl -> 
                                 (match pat with 
                                    | Pat_tuple(pats, r) -> 
                                        let rec desugar_tuple_pat = function
                                            [] -> raise Impos
                                          | [pat] -> pat
                                          | hd::tl -> 
                                              let pat_tl = desugar_tuple_pat tl in
                                                Pat_lid (Const.tuple_UU_lid, [hd;pat_tl], r) in
                                        let tupleConsPat = desugar_tuple_pat pats in
                                          {eqb with patterns=tupleConsPat::tl}
                                    | _ -> eqb)
                             | _ -> eqb) eqbranches in
        mk_inr "tuple" (_ix, env, discrims, eqb')
    in

    let (-||-) f g x = match g x with
      | Inl result -> Inl result
      | Inr y -> 
(*           if (x <> y) then  *)
(*             print_state y; *)
          f y in
      
    let pipeline =
      (try_mixture -||- try_elim_tuple_pats -||- try_elim_paren_pats -||- 
         try_elim_constructors -||- try_elim_vars -||- try_empty_discrims -||- try_elim_array_or_list) in
      
(*       debug "\n Equations on recursive call \n"; *)
(*       print_state (_ix, env, discrims, eqns); *)
      (* Sometimes CBN would be so nice! *)
      (* (pipeline -||- try_mixture -||- try_elim_constructors -||- try_elim_vars -||- try_empty_discrims) *)
      match pipeline (_ix, env, discrims, eqns) with
        | Inl res -> res
        | Inr (_ix, env', discrims', eqns') -> 
            if (eqns' === eqns) || (_ix > 100000) then               (* no progress *)
              raise (ErrorPat ("Pattern matching compiler may have entered an infinite loop", discrims, eqns))
            else
              ((* debug "."; *)
                dmatch (_ix + 1) env' discrims' eqns' defaultExp)
  in
    
    (* TODO:
       Desugar list patterns into constructor apps
       Handle tuple patterns
       Deal with pending substitutions
    *)
  let mk_eqnbranch = function
    | Clause (pat, whenclause, branch, r) -> 
        {patterns=[pat]; pendingsubs=[]; whenclause=whenclause; branch=branch; range=r}
  in
  let eqbranches = List.map mk_eqnbranch eqns in 

  let dummyname = genident (Some range) in
  let env', bvd = push_local_vbinding env (DSBinding_var (dummyname, tunknown)) in (* add a binding for the new discriminant var *)
  let newbvar = bvd_to_bvar_s bvd tunknown in 
  let discriminant = ewithpos (Exp_bvar newbvar) range in

  let defaultExp = ewithpos Exp_bot range in (* type checker can try to prove that this case is unreachable *)
  let matchexp = dmatch 0 env' [discriminant] eqbranches defaultExp in (* do the real work of desugaring the match *)
    
  let exp' = desugar_expression env exp in (* desugar the real discriminant and let-bind it to the new var *)
    
  let letexp = Exp_let (false, [(bvd, tunknown, exp')], matchexp) in
    ewithpos letexp range
        

let desugar_union_constr env tycon uctd : typ = 
  let typOfTycon = function
    | Sig_tycon_kind(lid, tps, _, _,_,_) -> 
        let r = range_of_lid lid in
        let t = AbsynUtils.Wtr (Typ_const({AbsynUtils.Wftv lid with p=r}, None)) r in
          List.fold_left (fun t -> function
                            | Tparam_typ(a,k) -> 
                                let r = range_of_bvd a in
                                let r' = union_ranges t.p r in
                                  AbsynUtils.Wtr (Typ_app(t, AbsynUtils.Wtr (Typ_btvar (bvwithsort a k)) r)) r'
                            | Tparam_term(x, tx) -> 
                                let r = range_of_bvd x in
                                let r' = union_ranges t.p r in
                                  AbsynUtils.Wtr (Typ_dep(t, AbsynUtils.Wr (Exp_bvar (bvwithsort x tx)) r)) r') t tps 
    | _ -> raise Impos in
    match uctd with
      | ConstrFields [] -> typOfTycon tycon
      | ConstrMLType styp -> 
          let typ = desugar_typ env styp in 
          let r = range_of_syntype styp in 
          let Wt t = twithinfo t Kind_unknown r in
            Wt (Typ_fun(None, typ, typOfTycon tycon))
              (*   | ConstrFields(fieldDecls) -> raise (NYI "ML-style declarations for variant types")(\*  ML-style declaration *\) *)
              (*       let desugar_fdecl = function *)
              (*         | Field (None, t, _, _) -> *)
              (*             desugar_typ env t *)
              (*         | Field (_, _, _, r) -> *)
              (*             raise (Error ("Unexpected record field identifier in variant constructor argument", r)) *)
              (*       in *)
              (*       let argTyps = List.map desugar_fdecl fieldDecls in (\* no dependences *\) *)
              (*       let final_typ = match tycon with *)
              (*         | Sig_tycon_kind (lid, tps, k, _) -> *)
              (*             let final_typ = Typ_const (withinfo_s lid k (range_of_lid lid)) in *)
              (*               (\* convert tparams into de Bruijn indexed bvars *\) *)
              (*             let bvars = *)
              (*               List.fold_right (fun tp ((tix, xix), accum) -> match tp with *)
              (*                                  | Tparam_typ (id, k) -> *)
              (*                                      let btvar = withinfo_s (tix, id) k id.idRange in *)
              (*                                        ((tix+1, xix), (Inl (Typ_btvar btvar))::accum) *)
              (*                                  | Tparam_term (id, t) -> *)
              (*                                      let bvar = withinfo_s (xix, id) t id.idRange in *)
              (*                                      let bvarexp = withinfo_s (Exp_bvar bvar) t id.idRange in *)
              (*                                        ((tix, xix+1), (Inr bvarexp)::accum)) tps ((0,0),[]) in *)
              (*               List.fold_left (fun ft -> function *)
              (*                                 | Inl btvar -> *)
              (*                                     Typ_app (ft, btvar) *)
              (*                                 | Inr bvar -> *)
              (*                                     Typ_dep (ft, bvar)) final_typ (snd bvars) *)
              (*         | _ -> raise Impos in *)
              (*       let ctyp = *)
              (*         match argTyps with *)
              (*           | [] -> final_typ *)
              (*           | [t] -> Typ_fun (None, t, final_typ) *)
              (*           | _ -> Typ_fun (None, Typ_dtuple (List.map (fun x -> (None, x)) argTyps), final_typ) (\* TODO: really? Should this be curried? *\) *)
              (*       in *)
              (*         ctyp *)
      | ConstrType styp -> (* GADT-style declaration *)
          let typ = desugar_typ env styp in
          let rec instance_of plid t = match t.v with
            | Typ_const (idt, _) when (Sugar.lid_equals idt.v plid) -> true
            | Typ_app (t, _) 
            | Typ_dep (t, _) -> instance_of plid t
            | _ -> false
          in
          let rec final_typ t = match t.v with
            | Typ_refine(_, t', _, _) 
            | Typ_fun (_,_,t') 
            | Typ_univ (_,_,_,t') -> final_typ t'
            | _ -> t in
          let lid, inst = match tycon with
            | Sig_tycon_kind (lid, _, _, _, _, _) ->
                lid, instance_of lid (final_typ typ)
            | _ -> raise Impos
          in
            if ((not inst) && (text_of_lid lid <> "Prims.NTuple")) then
              let msg = spr "Constructor does not construct expected type: expected %s, got %s " (text_of_lid lid) (Pretty.strTyp (final_typ typ)) in
                raise (Error (msg, range_of_lid lid))
            else typ
          
let desugar_typ_defn env tycon_lid tycon_kind tparams isprop td priv logic_tags : signature = 
  let close_typ tparams t = List.fold_right 
    (fun tp t -> match tp with 
       | Tparam_typ(a, k) -> twithpos (Typ_univ(a, k, [], t)) t.p
       | Tparam_term(x, tx) -> twithpos (Typ_fun(Some x, tx, t)) t.p)
    tparams t in 
  let close_kind_aux tck t = 
    let rec mkTparams tck = match tck with 
      | Kind_tcon(a, k, k') -> 
          let a = match a with 
            | Some a -> a
            | None -> new_bvd None in 
            Tparam_typ(a,k)::mkTparams k'
      | Kind_dcon(x, t, k') -> 
          let x = match x with 
            | Some x -> x
            | None -> new_bvd None in 
            Tparam_term(x,t)::mkTparams k'
      | _ -> [] in
    let tparams' = mkTparams tck in 
    let t = List.fold_left (fun t p -> match p with 
                              | Tparam_term(x,t') -> 
                                  twithpos (Typ_dep(t, bvd_to_exp x t')) t.p
                              | Tparam_typ(a,k) -> 
                                  twithpos (Typ_app(t, bvd_to_typ a k)) t.p)
      t tparams' in 
      tparams', t in
  let close_kind tparams k = 
    List.fold_right 
    (fun tp k -> match tp with 
       | Tparam_typ(a, k1) -> Kind_tcon(Some a, k1, k)
       | Tparam_term(x, tx) -> Kind_dcon(Some x, tx, k))
    tparams k in 
  let thunk () = match td with
    | TyconCore_repr_hidden (r) ->
        [Sig_tycon_kind (tycon_lid, tparams, tycon_kind, isprop, [], logic_tags)]
          
    | TyconCore_union (funionConstrDecls, r) ->
        let tyconTags = logic_tags |> List.filter (function Logic_data | Logic_tfun | Logic_array _ -> true | _ -> false) in
        let tyconSig = Sig_tycon_kind (tycon_lid, tparams, tycon_kind, isprop, [], tyconTags) in
        let env' = push_sigelt env tyconSig in
        let desugar_variant_constr env' = function
          | UnionConstr(unionCaseId, unionConstrTypeDecl, range) ->
              let qname, eref_opt = match extern_ref env with
                | Some eref -> asLid [unionCaseId], Some eref
                | None -> asLid <| (current_module env).lid @ [unionCaseId], None in
              let _ = if not (unique_name env qname) then
                let msg = spr "Data constructor names must be unique; the name %s has already been used" (text_of_lid qname) in
                  raise (Error (msg, r)) in 
              let dc = Sig_datacon_typ (qname, tparams, (desugar_union_constr env' tyconSig unionConstrTypeDecl), 
                                        None, (if priv then Private else Public), Some tycon_lid, eref_opt, []) in 
                match Util.findOpt (function Logic_data -> true | _ -> false) logic_tags with
                  | None -> (dc, [])
                  | Some _ -> 
                      (* let _ = pr "got Logic tags %A\n" logic_tags in  *)
                      (* Add a discriminator for the dc
                         And also projections for each type and value argument *)
                      begin match dc with 
                        | Sig_datacon_typ(qname, _, dtyp, _, _, Some tc, _, _) -> 
                            let tctyp = List.fold_left 
                              (fun t tp -> match tp with
                                 | Tparam_typ(a, k) -> twithpos (Typ_app(t, bvd_to_typ a k)) t.p
                                 | Tparam_term(x, tx) -> twithpos (Typ_dep(t, bvd_to_exp x tx)) t.p)
                              (twithpos (Typ_const(twithpos tc (range_of_lid tc), None)) (range_of_lid tc)) tparams in
                            let q, name = Util.pfx qname.lid in 
                            let mk_name str = asLid <| q@[(ident(str, name.idRange))] in
                            let tparams', tctyp = close_kind_aux tycon_kind tctyp in 
                            let disc = 
                              let disc_name = mk_name (spr "%s_is" (name.idText)) in 
                              let disc_kind = close_kind (tparams@tparams') <| Kind_dcon(None, tctyp, Kind_erasable) in
                              (* let _ = pr "Adding discriminator %s : %s\n" (text_of_lid disc_name) (Pretty.strKind disc_kind) in *)
                                Sig_tycon_kind(disc_name, [], disc_kind, false, [], [Logic_discriminator]) in 
                              (* Sig_logic_function(disc_name, disc_typ, [Logic_discriminator]) in  *)
                              
                            let tcx = gen_bvar tctyp in
                            let tparams_orig = tparams in
                            let tparams = tparams@tparams' in 
                            let projectors = 
                              let rec mk_projs (ix, out) t = match t.v with 
                                | Typ_univ(a, k, _, t') -> 
                                    let name = mk_name (spr "%s_proj_%d" (name.idText) ix) in 
                                    let kfun = close_kind tparams <| Kind_dcon(Some tcx.v, tctyp, k) in 
                                    let t' = 
                                      if tparams |> List.exists (function Tparam_typ(a',_) -> bvd_eq a a' | _ -> false)
                                      then t'
                                      else
                                        let atyp = 
                                          let proj = List.fold_left (fun t tp -> match tp with
                                                                       | Tparam_typ(a,k1) -> twithsort (Typ_app(t, bvd_to_typ a k1)) kunknown
                                                                       | Tparam_term(x,tx) -> twithsort (Typ_dep(t, bvd_to_exp x tx)) kunknown)
                                            (twithsort (Typ_const(twithsort name kfun, None)) kfun) tparams in
                                            twithsort (Typ_dep(proj, ewithsort (Exp_bvar tcx) tctyp)) k in
                                          substitute t' a atyp in 
                                    let proji = Sig_tycon_kind(name, [], kfun, false, [], [Logic_projector]) in 
                                    (* let _ = pr "Gen'd type projector %s at kind %s\n" (text_of_lid name) (Pretty.strKind kfun) in  *)
                                      mk_projs (ix+1, proji::out) t'
                                        
                                | Typ_fun(xopt, t1, t2) -> 
                                    let name = mk_name (spr "%s_proj_%d" (name.idText) ix) in 
                                    let t = close_typ tparams <| twithpos (Typ_fun(Some tcx.v, tctyp, (* AbsynUtils.unrefine *) t1)) t1.p in 
                                    let proji = Sig_logic_function(name, t, [Logic_projector]) in 
                                    (* let _ = pr "Gen'd term projector %s at type %s\n" (text_of_lid name) (Pretty.strTyp t) in *)
                                    let t2 = match xopt with 
                                      | None -> t2 
                                      | Some x -> 
                                          if tparams |> List.exists (function Tparam_term(y,_) -> bvd_eq x y | _ -> false)
                                          then t2
                                          else
                                            let targs = List.collect (function Tparam_typ(a,k) -> [bvd_to_typ a k] | _ -> []) tparams in
                                            let vargs = List.collect (function Tparam_term(x,t) -> [bvd_to_exp x t] | _ -> []) tparams in
                                            let vargs = vargs@[ewithsort (Exp_bvar tcx) tctyp] in 
                                            let aval = ewithsort (Exp_constr_app(ewithsort name t, targs, [], vargs)) ((* AbsynUtils.unrefine *) t1) in 
                                              substitute_exp t2 x aval in 
                                      mk_projs (ix+1, proji::out) t2 
                                        
                                | _ -> List.rev out in 
                                mk_projs (0, []) (close_typ tparams_orig dtyp) in 

                              (dc, disc::projectors)
                        | _ -> raise Impos 
                      end
        in
        let _, (dcs, dfuns) = 
          List.fold_left 
            (fun (env', (dcs, alldfuns)) dc -> 
               let (dc, dfuns) = desugar_variant_constr env' dc in 
               let env' = List.fold_left push_sigelt env dfuns in 
                 env', (dc::dcs, dfuns::alldfuns))
            (env', ([],[])) funionConstrDecls in
        let dcs = List.rev dcs in 
        let dfuns = List.flatten <| List.rev dfuns in 
          tyconSig::(dfuns@dcs)
            
    (* let dcs, dfuns = List.unzip <| List.map desugar_variant_constr funionConstrDecls in *)
        (*   tyconSig::((List.flatten dfuns)@dcs) *)
            
    | TyconCore_recd (fieldDecls, r) -> 
        let fn_t_l = List.map (fun (Field(fieldname, t, r)) -> 
                                 let fn = 
                                   if extern_typ env then 
                                     match extern_ref env with
                                         Some eref -> asLid [fieldname]
                                       | _ -> raise Impos 
                                   else 
                                     if !Options.ts_star then asLid [fieldname]
                                     else asLid <| (current_module env).lid@[fieldname] in
                                 fn, desugar_typ env t) fieldDecls in
        let fn_t_l = AbsynUtils.sortByFieldName fn_t_l in
        let record = twithpos (Typ_record(fn_t_l, None)) r in
          [Sig_record_typ (tycon_lid, tparams, tycon_kind, record, extern_ref env)]
            
    | TyconCore_abbrev (typ, r) -> 
        let env = set_generalize env false in
        let t = desugar_typ env typ in
          [Sig_typ_abbrev(tycon_lid, tparams, tycon_kind, t)] in
    profile thunk dstdef_ctr
          
let desugar_eref env = function
  | ExternRefId id -> (match (try_lookup_eref env id) with 
                         | None -> raise (Error ((spr "Extern reference %s not found" id.idText), id.idRange))
                         | Some er -> er)
  | ExternRef er -> er 
      
let desugar_typ_decls letbound_names env decl : env * signature = 
  let should_push_vdecl (id:ident) = true in
    (* not (letbound_names |> List.exists (fun (id':Sugar.ident) -> id.idText = id'.idText)) in *)
  let rec dtd_helper env decl : env * signature = match decl with
    | Def_open (id,_) ->
        (* TODO: Fix this to qualify the namespace.
           open Foo
           open Bar   <-- is this open Bar, or open Foo.Bar?
        *)
        push_namespace env id, []
    | Def_tycon (tds, isprop, priv, logic_tags, _) -> (* type t1 = ... and tn = ... *)
        let initial_env = env in
        let td_to_sig (env, sigelts) = function
            TyconDefn (Tycon(name, kind, tpdecls, _, _),  tdRepr, r) ->
              let qname, eref_opt = match extern_ref env with
                | Some eref -> name, Some eref 
                | None -> asLid <| (current_module env).lid @ name.lid, None in
                if not (unique_typ_name initial_env qname) then
                  let msg = spr "Type names must be unique; the name %s has already been used" (text_of_lid qname) in
                    raise (Error (msg, r))
                else
                  let env', tparams_rev = List.fold_left 
                    (fun (env, tparams) -> function
                       | TyparDecl (Typar(a,k_opt)) -> (* TODO:record kind in Typar *)
                           let k = match k_opt with
                               None -> Kind_star
                             | Some k -> desugar_kind env k  in
                           let env', bvd = push_local_tbinding env (DSBinding_typ_var(a,k)) in
                             env', (Tparam_typ(bvd, k)::tparams)
                       | TermparDecl (x, t) ->
                           let t = desugar_typ env t in
                           let env', bvd = push_local_vbinding env (DSBinding_var(x,t)) in
                             env', (Tparam_term(bvd, t)::tparams)) (env, []) tpdecls in
                  let tparams = List.rev tparams_rev in
                  let kind = desugar_kind env' kind in
                  let logic_tags = logic_tags |> List.map 
                      (function 
                         | Logic_array larr -> 
                             Logic_array {array_sel = asLid <| env.curmodule.lid@larr.array_sel.lid;
                                          array_upd = asLid <| env.curmodule.lid@larr.array_upd.lid;
                                          array_emp = asLid <| env.curmodule.lid@larr.array_emp.lid;
                                          array_indom = asLid <| env.curmodule.lid@larr.array_indom.lid}
                         | l -> l) in
                  let ty_data_cons = desugar_typ_defn env' qname kind tparams isprop tdRepr priv logic_tags in
                  let env' = List.fold_left push_sigelt env ty_data_cons in 
                    (env', sigelts@ty_data_cons) in
        let rec_bindings =
          List.fold_left (fun names -> function
                              TyconDefn (Tycon({lid=[name]}, _, _, _, _),  _, _) -> (* TODO: is name always an ident and not lid? *)
                                (DSBinding_tycon (name, Kind_unknown)::names)) [] tds in
        let recenv = List.fold_left push_rec_binding env rec_bindings in
        let (_, signature) = List.fold_left td_to_sig (recenv, []) tds in
        let tycons, datacons = List.partition (function
                                                 | Sig_tycon_kind _ 
                                                 | Sig_typ_abbrev _ -> true
                                                 | _ -> false) signature in
        let names = List.collect (function Sig_tycon_kind(lid, _, _, _, _, _) -> [lid] | Sig_typ_abbrev _ -> []) tycons in 
        let tycons = List.map (function Sig_tycon_kind(lid, tps, k, b, _, tags) -> Sig_tycon_kind(lid, tps, k, b, names, tags) | s -> s) tycons in 
        let env = List.fold_left push_sigelt env tycons in
          List.fold_left push_sigelt env datacons, List.rev (tycons@datacons)
            
    | Def_assume (idopt, formula, atag, r) -> 
        let ftyp = desugar_formula true env formula in
        let lid = match idopt with 
          | Some id -> asLid <| (current_module env).lid @ [id]
          | None -> asLid <| (current_module env).lid @ [genident (Some r)] in
          if not (unique_name env lid) then
            let msg = spr "Assumptions must bind unique names; the name %s has already been used" (text_of_lid lid) in
              raise (Error (msg, r))
          else
            let b = 
              (* if ghost then Sig_ghost_assume(lid, ftyp, Public) *)
              (* else *) Sig_datacon_typ(lid, [], ftyp, Some atag, Public, None, None, []) in
              push_sigelt env b, [b]
                
    | Def_val (id, t, r) -> 
        let t = desugar_typ env t in
        let lid = asLid <| (current_module env).lid @ [id] in
          if not (unique_name env lid) then
            let msg = spr "Value declarations must bind unique names; the name %s has already been used" id.idText in
              raise (Error (msg, r))
          else
            let b = Sig_value_decl (lid, t) in 
              if should_push_vdecl id
              then push_sigelt env b, [b]
              else env, [b]

    | Def_extern_val(eref, id, t, _) -> 
        let t = desugar_typ env t in
        let eref = desugar_eref env eref in
        let lid = asLid <| (current_module env).lid@[id] in
        let b = Sig_extern_value(eref, lid, t) in
          push_sigelt env b, [b]
            
    | Def_extern_typ(eref, td, m) ->
        let decl' = Def_tycon([td], false, false, [], m) in 
        let eref = desugar_eref env eref in
          (* get rid of stashing eref in env *)
        let env' = set_extern_typ env eref in
        let _, sigelts = dtd_helper env' decl' in
        let sigelts' = List.map (fun se -> Sig_extern_typ(eref, se)) sigelts in
          List.fold_left push_sigelt env sigelts', sigelts' 

    | Def_extern_ref(id, eref, _) -> 
        push_eref_binding env id eref, []
          
    | Def_query(lid, formula, _) -> 
        let t = desugar_formula true env formula in
        let se = Sig_query(lid, t) in  
          push_sigelt env se, [se]

    | Def_logic_function(id, t, _) -> 
        let t = desugar_typ env t in
        let lid = asLid <| (current_module env).lid@[id] in
        let b = Sig_logic_function(lid, t, []) in
          push_sigelt env b, [b]
            
    | _ -> raise Impos in
    profile (fun () -> dtd_helper env decl) dstdecl_ctr

let desugar_term_decls modul env decls : modul = 
  let thunk () = 
    let modul', _ =  List.fold_left 
      (fun (modul, env) decl -> 
         match decl with 
           | Def_let (isRec, bindings, r) -> 
               let env', bindings = desugar_let_bindings env isRec bindings in
               let modul' = {modul with letbindings=modul.letbindings@[(bindings,isRec)]} in
                 (modul', env')
           | Def_expr (e, r) -> 
               let exp = desugar_expression env e in 
               let modul = 
                 match modul.main with 
                     None -> {modul with main=Some exp}
                   | Some _ -> raise (Error ("Multiple main expressions in module", r)) in
                 (modul, env)
           | _ -> (modul, env)) (modul, env) decls in
      modul' in
    profile thunk dstermdecl_ctr

let desugar_pragma env = function
  | Sugar.PRAGMA_LIGHT -> []
  | Sugar.PRAGMA_MONADIC(t1,t2,t3) -> 
      let [t1;t2;t3] = List.map (desugar_typ env) [t1;t2;t3] in 
        [Absyn.PRAGMA_MONADIC(t1,t2,t3)]
          
let desugar_mimpl pragmas openModules : Sugar.moduleImpl -> modul = function
  | ModuleOrNamespaceImpl (lid, extendsOpt, decls, range) ->
      let env = initial_env openModules lid in
      let letbound_names = collect_letbound_names decls in
      let env, sigaccum = List.fold_left (fun (env, sigaccum) y -> 
                                            try 
                                              let env, sigelts = desugar_typ_decls letbound_names env y in 
                                                env, sigelts@sigaccum
                                            with 
                                              | ErrorEnv(s, r, env) as e when (pr "Failed while desugaring \n"; false) -> raise e
                                              | e when (pr "Failed while desugaring\n"; false) -> raise e)
        (env,[]) (collect_typ_decls decls) in
      let pragmas = List.collect (desugar_pragma env) pragmas in 
      let modul = {name = env.curmodule; extends=extendsOpt; pos=(range_of_lid env.curmodule); 
                   signature = List.rev sigaccum; letbindings=[]; main=None;exports=[]; pragmas=pragmas} in
        desugar_term_decls modul env decls 
          
type dsenv = list<lident*modul>
let desugar pragmas (openModuleList:dsenv) : Sugar.ParsedImplFile -> (dsenv * list<modul>) = 
  "Desugar" ^^ lazy function
  | ParsedImplFile modules -> 
      try 
        let oml, out = 
          List.fold_left (fun (oml, out) frag -> 
                            let mimpl =
                              match frag with
                                | AnonTopModuleImpl (decls, r) -> 
                                    ModuleOrNamespaceImpl(asLid [], None, decls, r)
                                | NamedTopModuleImpl m -> m in
                            let modul = desugar_mimpl pragmas oml mimpl in
                              (modul.name, modul)::oml, modul::out) (openModuleList, []) modules in
          oml, List.rev out
      with
        | Error (m, r) -> 
            Printf.printf "ERROR at %s: %s\n" (Range.string_of_range r) m;
            raise (Failure "Desugaring failed") 
              
        | ErrorEnv (m,r,env) -> 
            if !Options.verbosity > 4 then 
              begin
                debug_dump 4 "Environment:" ();
                dump_env env;
                Printf.printf "\n================================================================================\n";
              end;
            Printf.printf "ERROR at %s: %s\n" (Range.string_of_range r) m;
            raise (Failure "Desugaring failed") 
              
        | ErrorPat (m, lhs, branches) -> 
            if !Options.verbosity > 4 then 
              begin
                Printf.printf "\n================================================================================\n";
                Printf.printf "\nEqn lhs=\n";
                printfn "%A" lhs;
                Printf.printf "\nEqn branches=\n";
                printfn "%A" branches;
                Printf.printf "\n================================================================================\n";
              end;
            Printf.printf "ERROR %s\n" m;
            raise (Failure "Desugaring failed") 
              
        | NYI s -> 
            Printf.printf "\nFeature not yet implemented: %s\n" s;
            raise (Failure "Desugaring failed") 
              
                
                
