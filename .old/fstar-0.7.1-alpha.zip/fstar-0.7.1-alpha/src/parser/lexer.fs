#light "off"
module Microsoft.FStar.Lexer

open System

open FParsec
open FParsec.Error
open FParsec.Primitives
open FParsec.CharParsers
open Microsoft.FStar.Util
open Microsoft.FStar.Range

(* Keywords and special symbols *)
(* %token LET *)
(* %token FORALL EXISTS NOT ASSUME *)
(* %token BAR_BAR LESS GREATER NULL MODULE   *)
(* %token AND AS ASSERT BEGIN DO DONE ELSE END DOT_DOT *)
(* %token EXCEPTION FALSE FOR FUN FUNCTION IF IN FINALLY  *)
(* %token LAZY MATCH NEW OF  *)
(* %token OPEN OR PROP REC THEN TO TRUE TRY TYPE VAL  *)
(* %token WHEN WHILE WITH AMP AMP_AMP QUOTE LPAREN RPAREN STAR COMMA RARROW RRARROW IFF LPAREN_STAR_RPAREN *)
(* %token QMARK DOT COLON COLON_COLON COLON_EQUALS SEMICOLON  *)
(* %token SEMICOLON_SEMICOLON LARROW EQUALS  LBRACK  LBRACK_BAR  LBRACK_LESS LBRACE BACKSLASH *)
(* %token LBRACE_LESS BAR_RBRACK GREATER_RBRACE UNDERSCORE BANG  *)
(* %token BAR RBRACK RBRACE MINUS DOLLAR  *)
(* %token EXTERN REFERENCE PUBLIC PRIVATE INTERNAL  *)
(* %token LQUOTE RQUOTE  *)

(* Operators *)
(* %token <string> INFIX_STAR_STAR_OP  *)
(* %token <string> INFIX_COMPARE_OP  *)
(* %token <string> INFIX_AT_HAT_OP  *)
(* %token <string> INFIX_BAR_OP  *)
(* %token <string> PREFIX_OP *)
(* %token <string> INFIX_STAR_DIV_MOD_OP  *)
(* %token <string> INFIX_AMP_OP  *)
(* %token <string> PLUS_MINUS_OP  *)

(* Identifiers *)
(* %token <string> IDENT  *)
(* %token <string> LANG *)

(* bool indicates if INT8 was 'bad' max_int+1, e.g. '128'  *)
(* Data *)
(* %token <byte[]> STRING  *)
(* %token <char> CHAR *)

(* TODO *)
(* %token <byte[]> BYTEARRAY *)
(* %token <sbyte * bool> INT8  *)
(* %token <int16 * bool> INT16 *)
(* %token <int32 * bool> INT32 INT32_DOT_DOT *)
(* %token <int64 * bool> INT64 *)
(* %token <byte> UINT8 *)
(* %token <uint16> UINT16 *)
(* %token <uint32> UINT32 *)
(* %token <uint64> UINT64 *)
(* %token <uint64> UNATIVEINT *)
(* %token <int64> NATIVEINT *)
(* %token <single> IEEE32 *)
(* %token <double> IEEE64 *)
(* %token <System.Decimal> DECIMAL  *)
(* %token <byte[]> BIGINT BIGNUM *)
(* Positions and ranges *)
let curpos : Parser<Position, 'a> = fun s -> 
    Reply(s.Position, s)

let posOfPosition (p:Position) = 
    let l = p.Line in
    let c = p.Column in
    let pos = Range.mk_pos (int l) (int (c - 1L)) in
    pos

let rangeOfPos (p:Position) = 
    let p1 = posOfPosition p in 
    let f = p.StreamName in
    Range.mk_range f p1 p1

let mkRange p p' = 
    let p1 = posOfPosition p in
    let p2 = posOfPosition p' in 
    let f = p.StreamName in
    Range.mk_range f p1 p2

let rhs = fun s -> (curpos |>> rangeOfPos) s

(* Utility combinators *)
let u2b : Parser<unit, 'a> -> Parser<bool, 'a> = fun pu state -> 
    let reply = pu state in 
    Reply(reply.Status=Ok, reply.State)
let a2u (p:Parser<'a, 'b>) : Parser<unit, 'b> =
    p >>. preturn ()
    
let pfail : Parser<'a,'b> = fun state -> (Reply(Error, expectedError "", state))
let perr msg : Parser<'a,'b> = fun state -> (pr "%s" msg; Reply(Error, expectedError msg, state))
let prestore msg state : Parser<'a,'b> = fun _ -> Reply(Error, expectedError msg, state)
let prevCharMatches c = u2b (previousCharSatisfies (fun c' -> c=c'))
let currentCharMatches c = u2b (currentCharSatisfies (fun c' -> c=c'))
let nextCharMatches c = u2b (nextCharSatisfies (fun c' -> c=c'))
let peekMatches s = u2b (followedByString s)
let nextToken p = u2b (followedBy p)

let peekn n (s:State<'a>) =
  let rec aux m out = 
    if m>=n then out
    else aux (m+1) (spr "%s%c" out (s.Iter.Peek(m)))
  in
    aux 0 ""

(* If p matches, then parse p and consume it.
   Otherwise, leave stream unchanged and return unit. 
   Always succeeds. *)
let ifNextToken p q r =
    (nextToken p) >>= (fun b -> 
    if b then p >>= q else r)

let peekIfNextToken (p:Parser<'a,'b>) q r = fun s -> 
    let reply = p s in 
        match reply.Status with 
            | Ok -> q s
            | _ -> r s

let peekIfNextTokenMsg (p:Parser<'a,'b>) q r = fun s -> 
  (* let _ = pr "peeking token: %s\n" (peekn 5 s) in *)
  let reply = p s in 
    match reply.Status with 
      | Ok -> q (peekn 5 s) s
      | _ -> r (peekn 5 s) s
          
(* Backtracking *)
let bt msg (p:Parser<'a,'b>) = fun s -> 
  (* pr "Setting backtrack point %s\n" msg; *)
  let reply = p s in 
    match reply.Status with 
      | FParsec.Primitives.FatalError
      | FParsec.Primitives.Error -> 
            (*       if not !Util.silent then *)
          (* pr "Backtracking: %s (reply %A)\n" msg (reply.Status, reply.Result); *)
          Reply(FParsec.Primitives.Error, reply.Error, s) 
      | _ -> 
          (*       if not !Util.silent then *)
          (*               pr "Parser %s produced reply %A\n" msg reply.Status; *)
          reply
              
let btOpt msg (p:Parser<'a,'b>) = fun s -> 
  (* pr "Setting backtrack opt point %s\n" msg; *)
  let reply = p s in 
    match reply.Status with 
        | Ok -> Reply(Some reply.Result, reply.State)
        | FParsec.Primitives.Error -> 
            (* pr "Backtracking: %s\n" msg;  *)
            Reply(None, s)
        | status -> Reply(status, reply.Error, reply.State)

let btOptList msg (p :Parser<list<'a>, 'b>) = 
    (btOpt msg p) >>= (fun ol -> 
    match ol with 
        | Some l -> preturn l
        | None -> preturn [])

let cstart : Parser<unit, 'a> = fun s -> s |> ((skipString "(*") |>> ignore)
let cend   : Parser<unit, 'a> = fun s -> s |> ((skipString "*)") |>> ignore)
    
let rec comment : Parser<unit, 'a> = fun s -> s |>
    (cstart >>. comment_end)
and comment_end : Parser<unit, 'a> = fun s -> s |>
    ((manyCharsTill anyChar (lookAhead (cstart <|> cend))) >>.
     (cend  <|> (comment >>. comment_end)))

// adding support for //comments
let slashslash: Parser<unit, 'a> = fun s -> s |> (skipString "//" >>. skipRestOfLine)
          
(* let rec comment : Parser<unit, 'a> = fun s -> s |> *)
(*     let comment_start s = skipString "(\*" s in *)
(*     let comment_end s = skipString "*\)" s in *)
(*       ((comment_start >>.  *)
(*          (manyCharsTill anyChar  *)
(*             (lookAhead (comment_start <|> comment_end)))) *)
(*       |>> ((comment_end |>> ignore) *)
(*            <|> ((lookAhead comment_start) |>>  *)
(*                     comment |>>  *)
                    
(*          comment_end) |>> ignore) *)

let rec ws = fun s -> s |>
begin
    spaces >>. (btOpt "comment" slashslash) >>. (btOpt "comment" comment) >>= (function None -> preturn ()
                                           | _ -> ws)
end

let wsUntil (c:Parser<'a,'b>) = fun s ->
 let reply1 = ws s in
 let reply2 = c reply1.State in
 match reply2.Status with 
    | Ok -> reply1
    | _ -> Reply(reply2.Status, reply2.Error, reply1.State)
    
let ch  c = skipChar c >>. ws
let str s = skipString s >>. ws

let keywords = ["let";
                "forall";
                "forallA";
                "exists";
                "existsA";
                (* "not"; *)
                "assume";
                "define";
                "ghost";
                "null";
                "module";
                "and";
                "as";
                "assert"; 
                "begin";
                "do";
                "done";
                "else";
                "end";
                "exception" ;
                "false" ;
                "for" ;
                "fun" ;
                "function" ;
                "if" ;
                "in" ;
                "finally" ;
                "lazy" ;
                "match" ;
                "new" ;
                "of" ;
                "open" ;
                "or" ;
                "prop" ;
                "rec" ;
                "then" ;
                "to" ;
                "true" ;
                "try" ;
                "type" ;
                "val" ;
                "when" ;
                "while" ;
                "with" ;
                "extern" ;
                "reference" ;
                "public" ;
                "private" ;
                "internal" ;
                "logic";
                "Meta_tid";
                "Meta_named"]
let keywordSet = System.Collections.Generic.HashSet<_> keywords

let isIdentStartChar x = isLower x || isUpper x || (x ='_') 
let isIdentChar x = isLower x || isUpper x || isDigit x || (x = '_') || (x = '\'') 
let firstIDENT = fun s -> s |> ((satisfy isIdentStartChar) >>= (fun c -> preturn (String.of_char c)))
let IDENT : Parser<string, 'a> = fun state ->
    let idStr = satisfy isIdentStartChar >>= (fun c -> 
                let first = String.of_char c in 
                opt (many1Satisfy isIdentChar) >>= (fun restOpt -> 
                  match restOpt with                                                   
                    | None -> preturn first
                    | Some rest -> preturn (first^rest))) .>> ws in (* ([_a-zA-Z][a-zA-Z0-9'_]*   *)
    let reply = idStr state in
    if reply.Status = Ok then
        let id = reply.Result in
        if (not (keywordSet.Contains(id))) && (id <> "_") then
            Reply(reply.Result, reply.State)
        else
            Reply(Error, expectedError "identifier", state)
    else // reconstruct error
        Reply(reply.Status, reply.Error, reply.State)

let IDENT_NOWS : Parser<string, 'a> = fun state ->
  let idStr = satisfy isIdentStartChar >>= (fun c -> 
                let first = String.of_char c in 
                opt (many1Satisfy isIdentChar) >>= (fun restOpt -> 
                  match restOpt with                                                   
                    | None -> preturn first
                    | Some rest -> preturn (first^rest))) in  (* ([_a-zA-Z][a-zA-Z0-9'_]* *)
    let reply = idStr state in
      if reply.Status = Ok then
        let id = reply.Result in
          if (not (keywordSet.Contains(id))) && (id <> "_") then
            Reply(reply.Result, reply.State)
          else
            Reply(Error, expectedError "identifier", state)
      else // reconstruct error
        Reply(reply.Status, reply.Error, reply.State)


type tok<'a> = Parser<unit,'a>
let tok s : tok<'a> = fun st -> st |> 
begin
    (skipString s) >>. 
    (u2b (currentCharSatisfies isIdentStartChar)) >>= 
    (fun b -> if b then prestore "not token" st else ws)
end
      
let POUND     st = tok "#" st
let MONADIC   st = tok "#monadic" st
let LIGHT     st = tok "#light" st
let LET       st = tok "let" st
let FORALL    st = tok "forall" st 
let EXISTS    st = tok "exists" st 
let FORALL_A  st = tok "Aforall" st 
let EXISTS_A  st = tok "Aexists" st 
let NOT       st = tok "not" st 
let LBL       st = tok "LBL" st 
let PATTERN   st = tok "pattern" st 
let ASSUME    st = tok "assume" st 
let DEFINE    st = tok "define" st 
let GHOST     st = tok "ghost" st 
let NULL      st = tok "null" st 
let MODULE    st = tok "module" st 
let AND       st = tok "and" st 
let AS        st = tok "as" st 
let ASSERT    st = tok "assert" st 
let BEGIN     st = tok "begin" st 
let DO        st = tok "do" st 
let DONE      st = tok "done" st 
let ELSE      st = tok "else" st 
let END       st = tok "end" st 
let DOT_DOT   st = tok ".." st 
let EXCEPTION st = tok "exception"  st 
let FALSE     st = tok "false"  st 
let FOR       st = tok "for"  st 
let FUN       st = tok "fun"  st 
let FUNCTION  st = tok "function"  st 
let IF        st = tok "if"  st 
let IN        st = tok "in"  st 
let FINALLY   st = tok "finally"  st 
let LAZY      st = tok "lazy"  st 
let MATCH     st = tok "match"  st 
let NEW       st = tok "new"  st 
let OF        st = tok "of"  st 
let OPEN      st = tok "open"  st 
let OR        st = tok "or"  st 
let PROP      st = tok "prop"  st 
let REC       st = tok "rec"  st 
let THEN      st = tok "then"  st 
let TO        st = tok "to"  st 
let TRUE      st = tok "true"  st 
let TRY       st = tok "try"  st 
let TYPE      st = tok "type"  st 
let VAL       st = tok "val"  st 
let WHEN      st = tok "when"  st 
let WHILE     st = tok "while"  st 
let WITH      st = tok "with"  st 
let EXTERN    st = tok "extern"  st 
let REFERENCE st = tok "reference"  st 
let REF       st = tok "ref"  st 
let PUBLIC    st = tok "public"  st 
let PRIVATE   st = tok "private"  st 
let INTERNAL  st = tok "internal"  st 
let LOGIC     st = tok "logic" st
let DATA_TAG  st = tok "data" st
let ARRAY_TAG st = tok "array" st
let TFUN_TAG  st = tok "tfun" st
let META_TID  st = tok "Meta_tid" st
let META_NAMED st = tok "Meta_named" st
let DOUBLE_QUOTE st = skipString "\"" st 

let QUOTE     st = skipString "'"  st 

type stok<'a> = Parser<string,'a>
let stok s : stok<'a> = pstring s .>> ws
let QUOTETOK st = stok "'" st
let AMP       st = stok "&"  st 
let AMP_AMP   st = stok "&&"  st 
let BAR_BAR   st = stok "||" st 
let LESS      st = stok "<" st 
let GREATER   st = stok ">" st 
let LESS_OR_EQ st = stok "<=" st 
let GREATER_OR_EQ st = stok ">=" st 
let LPAREN    st = stok "("  st 
let RPAREN    st = stok ")"  st 
let UNIT_VAL  st = stok "()" st
let STAR      st = stok "*"  st 
let COMMA     st = stok ","  st 
let RARROW    st = stok "->"  st 
let RRARROW   st = stok "=>"  st 
let LONG_RRARROW   st = stok "==>"  st 
let GTGT      st = stok ">>"  st 
let IFF       st = stok "<=>"  st 
let LONG_IFF       st = stok "<==>"  st 
let QMARK     st = stok "?"  st 
let DOT       st = stok "."  st 
let COLON     st = stok ":"  st 
let LARROW    st = stok "<-"  st 
let EQUALS    st = stok "="  st 
let LTGT      st = stok "<>"  st 
let LBRACK    st = stok "["  st 
let LBRACE    st = stok "{"  st 
let LQUOTE    st = stok "`"  st
let RQUOTE    st = stok "'"  st
let BACKSLASH st = stok "\\"  st 
let BANG      st = stok "!"  st 
let BAR       st = stok "|"  st 
let RBRACK    st = stok "]"  st 
let RBRACE    st = stok "}"  st 
let MINUS     st = stok "-"  st 
let DOLLAR    st = stok "$"  st 
let BAR_RBRACK st = stok "|]"  st 
let UNDERSCORE st = stok "_"  st 
let LBRACK_BAR st = stok "[|"  st 
let COLON_COLON  st = stok "::"  st 
let COLON_EQUALS st = stok ":="  st 
let SEMICOLON    st = stok ";"  st 
let SEMICOLON_SEMICOLON st = stok ";;"  st 
let PERCENT st = stok "%" st 
let INFIX_STAR_STAR_OP    st = stok "**" st
let INFIX_COMPARE_OP      st = stok "=" st
let INFIX_AT_HAT_OP       st = (stok "@" <|> stok "^") st
let INFIX_BAR_OP          st = stok "|" st
let INFIX_STAR_DIV_MOD_OP st = (stok "*" <|> stok "/" <|> stok "%") st 
let INFIX_AMP_OP          st = stok "&" st
let PLUS_MINUS_OP         st = (stok "+"<|> stok "-") st 

let INFIX_OP = fun s -> s |>
begin
    BAR_BAR
<|> (OR >>. preturn "or")
<|> AMP_AMP     
<|> AMP         
<|> INFIX_AMP_OP
<|> EQUALS      
<|> INFIX_COMPARE_OP
<|> LESS            
<|> GREATER
<|> LESS_OR_EQ         
<|> GREATER_OR_EQ         
<|> COLON_COLON   
<|> COLON_EQUALS
<|> PLUS_MINUS_OP 
<|> MINUS         
<|> STAR          
<|> INFIX_STAR_DIV_MOD_OP
<|> INFIX_STAR_STAR_OP  
end

let UNARY_PREFIX_OP = fun s -> s |>
    begin 
      MINUS <|> BANG 
    end

let LANG : Parser<string, 'a> = fun s -> (pstring "F#" <|> pstring "C#" .>> ws) s
    
let STRING : Parser<string, 'a> = fun s ->
    let isStringChar x = not (x = '\n' || x= '\r' || x='"' || x='\\') in
    let rec not_string_end : Parser<string, 'a> = 
         opt (many1Satisfy isStringChar) >>= (fun init -> 
         currentCharMatches '\\' >>=  (fun b -> 
         if b (* escape char *) 
         then (anyChar >>. anyChar >>= (fun escaped ->  (* TODO: Handle other escape characters *)
               not_string_end >>= (fun rest -> 
                                    let tl = (String.of_char escaped) ^ rest in
                                      preturn (match init with None -> tl | Some hd -> hd ^ tl))))
         else
           currentCharMatches '"' >>= (fun b -> 
           if b then preturn (match init with None -> "" | Some i -> i)
           else perr "unexpected char in string literal"))) in
    (DOUBLE_QUOTE >>. not_string_end .>> DOUBLE_QUOTE .>> ws) s
    
let numberFormat =     NumberLiteralOptions.AllowMinusSign
                   ||| NumberLiteralOptions.AllowFraction
                   ||| NumberLiteralOptions.AllowExponent

let numberLit s = (numberLiteral numberFormat "number" .>> ws) s

type token = 
  | D_LET 
  | D_FORALL 
  | D_EXISTS 
  | D_FORALL_A
  | D_EXISTS_A
  | D_NOT 
  | D_LBL 
  | D_ASSUME
  | D_DEFINE
  | D_GHOST
  | D_BAR_BAR 
  | D_LESS 
  | D_GREATER 
  | D_NULL 
  | D_MODULE
  | D_AND 
  | D_AS 
  | D_ASSERT 
  | D_BEGIN 
  | D_DO 
  | D_DONE 
  | D_ELSE 
  | D_END 
  | D_DOT_DOT
  | D_EXCEPTION 
  | D_FALSE 
  | D_FOR 
  | D_FUN 
  | D_FUNCTION 
  | D_IF 
  | D_IN 
  | D_FINALLY
  | D_LAZY 
  | D_MATCH 
  | D_NEW 
  | D_OF
  | D_OPEN 
  | D_OR 
  | D_PROP 
  | D_REC 
  | D_THEN 
  | D_TO 
  | D_TRUE 
  | D_TRY 
  | D_TYPE 
  | D_VAL
  | D_WHEN 
  | D_WHILE 
  | D_WITH 
  | D_AMP 
  | D_AMP_AMP 
  | D_QUOTE 
  | D_LPAREN 
  | D_RPAREN 
  | D_STAR 
  | D_COMMA 
  | D_RARROW 
  | D_RRARROW 
  | D_IFF 
  | D_LPAREN_STAR_RPAREN
  | D_QMARK 
  | D_DOT 
  | D_COLON 
  | D_COLON_COLON 
  | D_COLON_EQUALS 
  | D_SEMICOLON
  | D_SEMICOLON_SEMICOLON 
  | D_LARROW 
  | D_EQUALS 
  | D_LBRACK 
  | D_LBRACK_BAR 
  | D_LBRACK_LESS 
  | D_LBRACE 
  | D_BACKSLASH
  | D_LBRACE_LESS 
  | D_BAR_RBRACK 
  | D_GREATER_RBRACE 
  | D_UNDERSCORE 
  | D_BANG
  | D_BAR 
  | D_RBRACK 
  | D_RBRACE 
  | D_MINUS 
  | D_DOLLAR
  | D_EXTERN 
  | D_REFERENCE 
  | D_PUBLIC 
  | D_PRIVATE 
  | D_INTERNAL
  | D_LQUOTE 
  | D_RQUOTE
  | D_LIGHT
  | D_INFIX_STAR_STAR_OP  of string
  | D_INFIX_COMPARE_OP  of string
  | D_INFIX_AT_HAT_OP of string
  | D_INFIX_BAR_OP  of string
  | D_PREFIX_OP of string
  | D_INFIX_STAR_DIV_MOD_OP of string
  | D_INFIX_AMP_OP of string
  | D_PLUS_MINUS_OP of string
  | D_IDENT of string
  | D_TVAR of string
  | D_LANG of string
  | D_STRING of string
  | D_CHAR of char
  | D_EOF
  | D_WS

let QTHING : Parser<token,'a> = fun s -> 
 ((QUOTE >>.
  anyChar >>= (fun c1 -> 
  if c1='\\' then (* this must be a char literal with an escape char *)
    anyChar .>> QUOTE >>= (fun c2 -> preturn (D_CHAR c2))
  else 
    currentCharMatches '\'' >>= (fun b -> 
    if b then QUOTE >>. preturn (D_CHAR c1)
    else (* first char not escape; 2nd char not close quote ... must be a tvar *)
      if isIdentStartChar c1 then
        let c1 = String.of_char c1 in
        opt (many1Satisfy isIdentChar) >>= (fun restOpt ->
        match restOpt with 
          | None -> preturn (D_TVAR("'"^c1))
          | Some c2 -> 
              let str = c1^c2 in 
                preturn (D_TVAR ("'"^str)))
      else perr "Expected either type variable or char literal"))) .>> ws) s


let CHAR : Parser<char, 'a> = fun s -> 
  (QTHING >>= (function 
                | D_CHAR c -> preturn c
                | _ -> perr "Expected char literal")) s

let TVAR : Parser<string, 'a> = fun s -> 
  (QTHING >>= (function 
                | D_TVAR s -> preturn s
                | _ -> perr "Expected type variable")) s


(* (\* TODO: Parse escape sequences *\) *)
(* let string_to_bytes s : byte[] = Util.unicodeEncoding.GetBytes(s) *)
(* let STRING_UNTIL_CLOSE_QUOTE : Parser<byte[], 'a> = fun s ->  *)
(*   (regex "([^\\\\]*(\\\\.)*\)*\"") >>= (fun str -> preturn (string_to_bytes str)) *)

let STRING_BYTES : Parser<byte[], 'a> = fun st -> st |>
  (STRING |>> (fun str -> Util.unicodeEncoding.GetBytes(str)))

let EOF = fun s -> s |>
begin
    ws >>. eof 
end
      
let token : Parser<token, 'b> = fun st -> st |>
begin
       (LIGHT |>> fun _ -> D_LIGHT)
   <|> (QTHING)
   <|> (LET |>> fun _ -> D_LET)
   <|> (FORALL |>> fun _ -> D_FORALL)
   <|> (EXISTS |>> fun x -> D_EXISTS) 
   <|> (FORALL_A |>> fun _ -> D_FORALL_A)
   <|> (EXISTS_A |>> fun x -> D_EXISTS_A) 
   <|> (NOT |>> fun x -> D_NOT) 
   <|> (LBL |>> fun x -> D_LBL) 
   <|> (ASSUME |>> fun x -> D_ASSUME)
   <|> (DEFINE |>> fun x -> D_DEFINE)
   <|> (GHOST |>> fun x -> D_GHOST)
   <|> (BAR_BAR |>> fun x -> D_BAR_BAR)
   <|> (LESS |>> fun x -> D_LESS) 
   <|> (GREATER |>> fun x -> D_GREATER) 
   <|> (NULL |>> fun x -> D_NULL) 
   <|> (MODULE |>> fun x -> D_MODULE)
   <|> (AND |>> fun x -> D_AND) 
   <|> (AS |>> fun x -> D_AS) 
   <|> (ASSERT |>> fun x -> D_ASSERT) 
   <|> (BEGIN |>> fun x -> D_BEGIN) 
   <|> (DO |>> fun x -> D_DO) 
   <|> (DONE |>> fun x -> D_DONE) 
   <|> (ELSE |>> fun x -> D_ELSE) 
   <|> (END |>> fun x -> D_END) 
   <|> (DOT_DOT |>> fun x -> D_DOT_DOT)
   <|> (EXCEPTION |>> fun x -> D_EXCEPTION) 
   <|> (FALSE |>> fun x -> D_FALSE) 
   <|> (FOR |>> fun x -> D_FOR) 
   <|> (FUN |>> fun x -> D_FUN) 
   <|> (FUNCTION |>> fun x -> D_FUNCTION) 
   <|> (IF |>> fun x -> D_IF) 
   <|> (IN |>> fun x -> D_IN) 
   <|> (FINALLY |>> fun x -> D_FINALLY)
   <|> (LAZY |>> fun x -> D_LAZY) 
   <|> (MATCH |>> fun x -> D_MATCH) 
   <|> (NEW |>> fun x -> D_NEW) 
   <|> (OF |>> fun x -> D_OF)
   <|> (OPEN |>> fun x -> D_OPEN) 
   <|> (OR |>> fun x -> D_OR) 
   <|> (PROP |>> fun x -> D_PROP) 
   <|> (REC |>> fun x -> D_REC) 
   <|> (THEN |>> fun x -> D_THEN) 
   <|> (TO |>> fun x -> D_TO) 
   <|> (TRUE |>> fun x -> D_TRUE) 
   <|> (TRY |>> fun x -> D_TRY) 
   <|> (TYPE |>> fun x -> D_TYPE) 
   <|> (VAL |>> fun x -> D_VAL)
   <|> (WHEN |>> fun x -> D_WHEN) 
   <|> (WHILE |>> fun x -> D_WHILE) 
   <|> (WITH |>> fun x -> D_WITH) 
   <|> (AMP |>> fun x -> D_AMP) 
   <|> (AMP_AMP |>> fun x -> D_AMP_AMP)
   <|> (LPAREN |>> fun x -> D_LPAREN) 
   <|> (RPAREN |>> fun x -> D_RPAREN) 
   <|> (STAR |>> fun x -> D_STAR) 
   <|> (COMMA |>> fun x -> D_COMMA) 
   <|> (RARROW |>> fun x -> D_RARROW) 
   <|> (RRARROW |>> fun x -> D_RRARROW) 
   <|> (IFF |>> fun x -> D_IFF) 
   <|> (QMARK |>> fun x -> D_QMARK) 
   <|> (DOT |>> fun x -> D_DOT) 
   <|> (COLON |>> fun x -> D_COLON) 
   <|> (COLON_COLON |>> fun x -> D_COLON_COLON)
   <|> (COLON_EQUALS |>> fun x -> D_COLON_EQUALS )
   <|> (SEMICOLON |>> fun x -> D_SEMICOLON)
   <|> (SEMICOLON_SEMICOLON  |>> fun x -> D_SEMICOLON_SEMICOLON)
   <|> (LARROW |>> fun x -> D_LARROW) 
   <|> (EQUALS |>> fun x -> D_EQUALS) 
   <|> (LBRACK |>> fun x -> D_LBRACK) 
   <|> (LBRACK_BAR  |>> fun x -> D_LBRACK_BAR)
   <|> (LBRACE |>> fun x -> D_LBRACE) 
   <|> (BACKSLASH |>> fun x -> D_BACKSLASH)
   <|> (UNDERSCORE |>> fun x -> D_UNDERSCORE) 
   <|> (BANG |>> fun x -> D_BANG)
   <|> (BAR |>> fun x -> D_BAR) 
   <|> (RBRACK |>> fun x -> D_RBRACK) 
   <|> (RBRACE |>> fun x -> D_RBRACE) 
   <|> (MINUS |>> fun x -> D_MINUS) 
   <|> (DOLLAR |>> fun x -> D_DOLLAR)
   <|> (EXTERN |>> fun x -> D_EXTERN) 
   <|> (REFERENCE |>> fun x -> D_REFERENCE) 
   <|> (PUBLIC |>> fun x -> D_PUBLIC) 
   <|> (PRIVATE |>> fun x -> D_PRIVATE) 
   <|> (INTERNAL |>> fun x -> D_INTERNAL)
   <|> (LQUOTE |>> fun x -> D_LQUOTE) 
   <|> (INFIX_STAR_STAR_OP |>> D_INFIX_STAR_STAR_OP)
   <|> (INFIX_COMPARE_OP |>> D_INFIX_COMPARE_OP)
   <|> (INFIX_AT_HAT_OP |>> D_INFIX_AT_HAT_OP)
   <|> (INFIX_BAR_OP |>> D_INFIX_BAR_OP)
   <|> (INFIX_STAR_DIV_MOD_OP |>> D_INFIX_STAR_DIV_MOD_OP)
   <|> (INFIX_AMP_OP |>> D_INFIX_AMP_OP)
   <|> (PLUS_MINUS_OP |>> D_PLUS_MINUS_OP)
   <|> (IDENT |>> D_IDENT) 
   <|> (LANG |>> D_LANG) 
   <|> (STRING |>> D_STRING)
   <|> (EOF >>. preturn D_EOF)
end

let rec tokenize : Parser<list<token>, 'a> = fun s -> 
  let reply = token s in 
     (match reply.Status with 
        | Ok -> (* pr "Parsed one token\n"; *)
            (match reply.Result with 
               | D_EOF -> ((* pr "reached EOF";  *)
                   preturn [D_EOF])
               | t -> ((* pr "tokenizing more ...";  *)tokenize) >>= fun ts -> preturn (t::ts))
        | Error -> Printf.printf "Error: %A" (reply.Error, reply.State.Line, reply.State.Column); preturn []) reply.State
       
