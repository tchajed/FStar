#light "off"
module Microsoft.FStar.ParseAST
open Microsoft.FStar.Range
open Microsoft.FStar.Sugar
open Microsoft.FStar.Util
let to_string_l sep l =
  String.concat sep (List.map (fun x -> x.ToString()) l)
let to_string_l' sep f l = 
  String.concat sep (List.map f l)

type level = Un | Expr | Type | Kind | Formula
type lid = Sugar.LongIdent
let lid_with_range lid r = lid_of_path (path_of_lid lid) r
type term' = 
  | Wild      
  | Const     of Sugar.sconst
  | Op        of string * list<term>
  | Tvar      of ident
  | Var       of lid
  | Name      of lid
  | Construct of lid * list<term>       (* data, type, predicate *)
  | Abs       of list<pattern> * term
  | App       of term * term 
  | Let       of bool * list<pattern * term> * term  (* bool is for let rec *)
  | Seq       of term * term
  | If        of term * term * term
  | Match     of term * list<branch>
  | Ascribed  of term * term 
  | Record    of option<term> * list<lid * term>
  | Project   of term * lid
  | Product   of list<binder> * term (* function space *)
  | Sum       of list<binder> * term (* dependent tuple *)
  | QForall   of list<binder> * list<term> * term 
  | QExists   of list<binder> * list<term> * term 
  | Refine    of binder * term 
  | Paren     of term
  | Affine    of term
and term = {term:term'; range:range; level:level}
  with override x.ToString() = match x.term with 
    | Wild -> "_"
    | Const c -> Pretty.strConst c
    | Op(s, xs) -> spr "%s(%s)" s (String.concat ", " (List.map (fun x -> x.ToString()) xs))
    | Tvar id -> id.idText
    | Var l
    | Name l -> Pretty.sli l
    | Construct(l, args) -> 
        spr "(%s %s)" (Pretty.sli l) (to_string_l " " args)
    | Abs(pats, t) when x.level = Expr -> 
        spr "(fun %s -> %s)" (to_string_l " " pats) (t.ToString())
    | Abs(pats, t) when x.level = Type -> 
        spr "(fun %s => %s)" (to_string_l " " pats) (t.ToString())
    | App(t1, t2) -> spr "%s %s" (t1.ToString()) (t2.ToString())
    | Let(false, [(pat,tm)], body) -> 
        spr "let %s = %s in %s" (pat.ToString()) (tm.ToString()) (body.ToString())
    | Let(_, lbs, body) -> 
        spr "let rec %s in %s" (to_string_l' " and " (fun (p,b) -> spr "%s=%s" (p.ToString()) (b.ToString())) lbs) (body.ToString()) 
    | Seq(t1, t2) ->
        spr "%s; %s" (t1.ToString()) (t2.ToString())
    | If(t1, t2, t3) ->
        spr "if %s then %s else %s" (t1.ToString()) (t2.ToString()) (t3.ToString()) 
    | Match(t, branches) -> 
        spr "match %s with %s" (t.ToString()) (to_string_l " | " branches)
    | Ascribed(t1, t2) -> 
        spr "(%s : %s)" (t1.ToString()) (t2.ToString())
    | Record(Some e, fields) -> 
        spr "{%s with %s}" (e.ToString()) (to_string_l' " " (fun (l,e) -> spr "%s=%s" (Pretty.sli l) (e.ToString())) fields)
    | Record(None, fields) -> 
        spr "{%s}" (to_string_l' " " (fun (l,e) -> spr "%s=%s" (Pretty.sli l) (e.ToString())) fields)
    | Project(e,l) -> 
        spr "%s.%s" (e.ToString()) (Pretty.sli l)
    | Product([b], t) when x.level = Type -> 
        spr "%s -> %s" (b.ToString()) (t.ToString())
    | Product([b], t) when x.level = Kind -> 
        spr "%s => %s" (b.ToString()) (t.ToString())
    | Sum([b], t) -> 
        spr "%s * %s" (b.ToString()) (t.ToString())
    | QForall(bs, pats, t) -> 
        spr "forall %s.{:pattern %s} %s"
          (to_string_l " " bs)
          (to_string_l "; " pats)
          (t.ToString())
    | QExists(bs, pats, t) ->
        spr "exists %s.{:pattern %s} %s"
          (to_string_l " " bs)
          (to_string_l "; " pats)
          (t.ToString())
    | Refine(b, t) -> 
        spr "%s:{%s}" (b.ToString()) (t.ToString())      
    | Paren t -> spr "(%s)" (t.ToString())
    | Affine t -> spr "!%s" (t.ToString())
    | _ -> raise Impos
end
and binder' = 
  | Variable of ident
  | Annotated of ident * term 
  | NoName of term
and binder = {binder:binder'; range:range; level:level}
with override x.ToString() = match x.binder with 
  | Variable i -> i.idText
  | Annotated(i,t) -> spr "%s:%s" (i.idText) (t.ToString())
  | NoName t -> t.ToString()
end      

and pattern' = 
  | PatWild
  | PatConst    of Sugar.sconst 
  | PatApp      of pattern * list<pattern> 
  | PatVar      of ident
  | PatName     of lid
  | PatTvar     of ident
  | PatList     of list<pattern>
  | PatTuple    of list<pattern>
  | PatRecord   of list<lid * pattern>
  | PatAscribed of pattern * term 
and pattern = {pattern:pattern'; range:range}
with override x.ToString() = match x.pattern with 
  | PatWild -> "_"
  | PatConst c -> Pretty.strConst c
  | PatApp(p, ps) -> spr "(%s %s)" (p.ToString()) (to_string_l " " ps)
  | PatTvar i 
  | PatVar i -> i.idText
  | PatName l -> Pretty.sli l
  | PatList l -> spr "[%s]" (to_string_l "; " l)
  | PatTuple l -> spr "[%s]" (to_string_l ", " l)
  | PatRecord l -> spr "{%s}" (to_string_l' "; " (fun (f,e) -> spr "%s=%s" (Pretty.sli f) (e.ToString())) l)
  | PatAscribed(p,t) -> spr "(%s:%s)" (p.ToString()) (t.ToString())
end

and branch = (pattern * term)

type kind = term
type typ = term
type expr = term
type atag = AssumeTag | QueryTag | DefinitionTag

type tycon =  
  | TyconAbstract of ident * list<binder> * option<kind>
  | TyconAbbrev   of ident * list<binder> * option<kind> * term
  | TyconRecord   of ident * list<binder> * option<kind> * list<ident * term>
  | TyconVariant  of ident * list<binder> * option<kind> * list<ident * term>

type tyvalQual = 
  | LogicTag of option<logic_tag>
  | Extern of ident

type decl' = 
  | Open of lid 
  | Tycon of option<tyvalQual> * list<tycon>
  | ToplevelLet of bool * list<pattern * term> 
  | Main of term
  | Assume of atag * ident * term
  | Val of option<tyvalQual> * ident * term  (* bool is for logic val *)
  | ExternRef of ident * list<string * string>
and decl = {decl:decl'; range:range}

type pragma =
  | Monadic of lid * lid * lid
  | Dynamic 
type modul = Module of LongIdent * list<decl>
type file = list<pragma> * list<modul>

type types_in_mod = {mname:LongIdent;
                     types:list<ident>}
type env = {mods:list<types_in_mod>;
            curmod:list<ident>;
            open_mods:list<lid>;
            phase:level}
let initial_env = {mods=[]; curmod=[]; open_mods=[Const.prims_lid]; phase=Un}

let decl d r = {decl=d; range=r}
let binder b r l = {binder=b; range=r; level=l}
let term t r l = {term=t; range=r; level=l}
let pattern p r = {pattern=p; range=r}
let error msg tm r =
  let tm = tm.ToString() in 
  let tm = if tm.Length >= 80 then tm.Substring(0,77) ^"..." else tm in 
  raise (Error(msg^"\n"^tm, r))

let op_LT = Const.p2l ["op_LessThan"]
let op_LTE = Const.p2l ["op_LessThanOrEqual"]
let op_GT = Const.p2l ["op_GreaterThan"]
let op_GTE = Const.p2l ["op_GreaterThanOrEqual"]
let op_Subtraction = Const.p2l ["op_Subtraction"]
let op_Minus = Const.p2l ["op_Minus"]
let op_Addition = Const.p2l ["op_Addition"]
let op_Multiply = Const.p2l ["op_Multiply"]
let op_Division = Const.p2l ["op_Division"]
let op_Modulus = Const.p2l ["op_Modulus"]
let op_And = Const.p2l ["op_AmpAmp"]
let op_Or = Const.p2l ["op_BarBar"]

let op_as_vlid (env:env) arity r s = 
  let r l = Some <| lid_with_range l r in
    match s, env.phase with 
      | "=", _ ->    r Const.op_Eq
      | ":=", _ ->   r Const.op_ColonEquals_lid
      | "<", _ ->    r op_LT
      | "<=", _ ->   r op_LTE
      | ">", _ ->    r op_GT
      | ">=", _ ->   r op_GTE
      | "&&", _ ->   r op_And
      | "||", _ ->   r op_Or
      | "*", Expr -> r op_Multiply
      | "*", _ ->    r Const.mul_lid
      | "+", Expr -> r op_Addition
      | "+", _ ->    r Const.add_lid
      | "-", Expr when arity=1 -> r op_Minus
      | "-", _ when arity=1 -> r Const.minus_lid
      | "-", Expr -> r op_Subtraction
      | "-", _ ->    r Const.sub_lid
      | "/", Expr -> r op_Division
      | "/", _ ->    r Const.div_lid
      | "%", Expr -> r op_Modulus
      | "%", _ ->    r Const.modulo_lid
      | _ -> None

let op_as_tylid r s = 
  let r l = Some <| lid_with_range l r in
    match s with 
      | "=" ->    r Const.eq2_lid
      | "<>" ->   r Const.neq2_lid
      | "<" ->    r Const.lt_lid
      | "<=" ->   r Const.lte_lid
      | ">" ->    r Const.gt_lid
      | ">=" ->   r Const.gte_lid
      | "/\\" ->  r Const.and_lid
      | "\\/" ->  r Const.or_lid
      | "==>" ->  r Const.implies_lid
      | "<==>" -> r Const.iff_lid 
      | _ -> None

let is_type_lid (t:term) (l:lid) env = 
  if (t.level=Type || t.level=Kind) && Sugar.lid_equals l Const.cons_lid
  then error "Unexpected list constructor where type ascription was expected" t t.range;
  let q, name = Util.pfx l.lid in 
  let name = name.idText in 
  let name_in nm (types:list<ident>) = types |> List.exists (fun id -> nm = id.idText) in 
  let in_open_mods nm = 
    (* pr "Checking if %s in open mods %s\n" (Pretty.sli l) (to_string_l' "; " Pretty.sli env.open_mods); *)
    env.mods |> List.exists 
        (fun mt -> 
           (* pr "Checking module %s\n" (Pretty.sli mt.mname); *)
           if (lid_equals mt.mname (Absyn.asLid q) )
             || (env.open_mods |> List.exists 
                     (fun o -> 
                        let m2 = Absyn.asLid (o.lid @ q) in 
                          (* pr "Checking eq %s and %s" (Pretty.sli mt.mname) (Pretty.sli m2); *)
                          lid_equals mt.mname m2))
           then name_in nm mt.types
           else false) in 
    match q with 
      | [] -> name_in name env.curmod || in_open_mods name
      | _ -> in_open_mods name 

let rec is_type (t:term) env = 
  if t.level = Type then true
  else match t.term with 
    | Wild -> true
    | Op("*", hd::tl) -> is_type hd env
    | Op("=", hd::_) -> is_type hd env
    | Op("<", _)
    | Op("<=", _)
    | Op(">", _)
    | Op(">=", _) -> env.phase = Formula
    | Op(s, _) -> (match op_as_tylid t.range s with None -> false | _ -> true)
    | Tvar _ -> true
    | Var l
    | Name l 
    | Construct(l, _) -> is_type_lid t l env
    | App(t1, _) -> is_type t1 env
    | Paren t -> is_type t env
    | _ -> false

let rec desugar_pat env p = match p.pattern with 
  | PatWild -> Pat_wild p.range
  | PatConst c -> Pat_const(c, p.range)
  | PatVar x -> Pat_as(Pat_wild p.range, x, false, p.range)
  | PatApp({pattern=PatName l}, args) -> Pat_lid(l, List.map (desugar_pat env) args, p.range)
  | PatApp({pattern=PatVar x}, args) ->  Pat_lid(Absyn.asLid [x], List.map (desugar_pat env) args, p.range)
  | PatApp _ -> error "Unexpected pattern" p p.range
  | PatName l -> Pat_lid(l, [], p.range)
  | PatTvar x -> 
      if x.idText = "'_" then Pat_uvar(p.range)
      else Pat_tvar (Typar(x, None), p.range)
  | PatList pats -> Pat_array_or_list(false, List.map (desugar_pat env) pats, p.range)
  | PatTuple pats -> Pat_tuple(List.map (desugar_pat env) pats, p.range)
  | PatRecord fields -> Pat_recd(fields |> List.map (fun (l,p) -> 
                                                       let p = desugar_pat env p in 
                                                       let path,field = Util.pfx l.lid in 
                                                         (Absyn.asLid path, field), p),
                                 p.range)
  | PatAscribed(p, t) -> 
      if t.level = Kind
      then let k = desugar_kind' env t in 
           match desugar_pat env p with
             | Pat_tvar (Typar(x, None), r) -> Pat_tvar(Typar(x, Some k), r)
             | _ -> error "Unexpected kind ascription" p p.range
      else Pat_typed(desugar_pat env p, desugar_typ env t, p.range)
                      
and desugar_simple_pat env p = match p.pattern with 
  | PatVar x -> Inl(x, Type_anon p.range)
  | PatTvar x -> Inr (Typar(x, None))
  | PatAscribed(p,t) when t.level = Type -> 
      (match desugar_simple_pat env p with 
         | Inl(x, _) -> Inl(x, desugar_typ env t)
         | _ -> raise Impos)
  | PatAscribed(p,k) when k.level = Kind -> 
      (match desugar_simple_pat env p with 
         | Inr(Typar(x, _)) -> Inr(Typar(x, Some(desugar_kind' env k)))
         | _ -> raise Impos)
  | _ -> error "Expected a simple pattern" p p.range

and desugar_exp_or_typ env top = 
  let mkApp e args = 
    List.fold_left 
      (fun out -> function
         | Inl e -> Expr_app(out, e, 
                             Range.union_ranges (range_of_synexpr out) (range_of_synexpr e))
         | Inr t -> 
             let r = Range.union_ranges (range_of_synexpr out) (range_of_syntype t) in 
             (match out with 
                | Expr_tyapp(out', targs, r) -> Expr_tyapp(out', targs@[t], r)
                | _ -> Expr_tyapp(out, [t], 
                                  Range.union_ranges (range_of_synexpr out) (range_of_syntype t))))
      e args in
    if is_type top env 
    then Inr (desugar_typ env top)
    else
      let exp = match top.term with
        | Const c -> Expr_const(c, top.range)
        | Op("Tuple", args) -> Expr_tuple(List.map (desugar_exp env) args, top.range)
        | Op(s, args) -> 
            begin match op_as_vlid env (List.length args) top.range s with 
              | None -> error "Unexpected operator: " s top.range
              | Some l -> 
                  let args = args |> List.map (desugar_exp_or_typ env) in 
                  let op = Expr_lid_get(false, l, top.range) in 
                    mkApp op args
            end
        | Var l
        | Name l -> Expr_lid_get(false, l, top.range)
        | Construct(l, args) -> 
            let d = Expr_lid_get(false, l, range_of_lid l) in 
            let args = List.map (desugar_exp_or_typ env) args in 
              mkApp d args
        | Abs(pats, body) -> 
            let pats = List.map (desugar_pat env) pats in
            let body = desugar_exp env body in 
              Sugar.mksyn_match_lambdas false top.range pats body
        | App({term=Var a}, arg) when (Sugar.lid_equals a Const.assert_lid
                                       || Sugar.lid_equals a Const.assume_lid) -> 
            let phi = desugar_formula env arg in 
            let r = top.range in 
              Expr_app(Expr_tyapp(Expr_lid_get(false, a, r), 
                                  [Type_formula(phi, arg.range)], 
                                  r), 
                       Expr_const(Const_unit, r), 
                       r)
        | App(e, t) ->
            let e = desugar_exp env e in 
            let t = desugar_exp_or_typ env t in 
              mkApp e [t]
        | Let(b, lbs, t) -> 
            let bindings = List.map (desugar_binding env) lbs in 
              Expr_let(b, false, bindings, desugar_exp env t, top.range)
        | Seq(t1, t2) -> 
            Expr_seq(true, desugar_exp env t1, desugar_exp env t2, top.range)
        | If(t1, t2, t3) -> 
            Expr_cond(desugar_exp env t1, 
                      desugar_exp env t2, 
                      Some (desugar_exp env t3), 
                      top.range, top.range)
        | Match(e, branches) -> 
            let desugar_branch (pat, b) = 
              let spat = desugar_pat env pat in 
              let sb = desugar_exp env b in 
                Clause(spat, None, sb, Range.union_ranges pat.range b.range) in 
            let bs = List.map desugar_branch branches in 
              Expr_match(desugar_exp env e, bs, false, top.range)
        | Ascribed(e, t) -> 
            Expr_typed(desugar_exp env e, desugar_typ env t, top.range)
        | Record(eopt, fields) -> 
            let eopt = match eopt with 
              | None -> None
              | Some e -> Some (desugar_exp env e) in 
            let desugar_field (l, e) =
              let path, f = Util.pfx l.lid in 
                ((Absyn.asLid path, f), desugar_exp env e) in
              Expr_recd(eopt, List.map desugar_field fields, top.range)
        | Project(e, f) -> 
            Expr_lvalue_get(desugar_exp env e, f, top.range)
        | Paren e -> Expr_paren(desugar_exp env e, top.range)
        | _ -> error "Unexpected term" top top.range in 
        Inl exp

and desugar_exp env top = 
  match desugar_exp_or_typ env top with 
    | Inl e -> e
    | Inr t -> error "Expected an expression; got a type" top top.range

and desugar_exp' env t = desugar_exp {env with phase=Expr} t

and desugar_typ_or_exp env (top:term) = 
  let expr () = Type_term_index(desugar_exp env top, top.range) in
  let rec flatten_tuple t = match t.term with
    | Op("*", [t1;t2]) -> binder (NoName t1) t1.range t1.level::flatten_tuple t2
    | Sum([b],t) -> b::flatten_tuple t
    | _ -> [binder (NoName t) t.range t.level] in 
    match top.term with 
      | Wild -> Type_anon(top.range)
      | Op("*", [t1;t2]) when is_type t1 env -> 
          let binders = flatten_tuple top in 
          let args = binders |> List.map (fun b -> desugar_value_binder env {b with level=Type}) in
            Type_tuple(args, top.range)
      | Op("<>", args) -> 
          (match desugar_typ_or_exp env (term (Op("=", args)) top.range top.level) with 
             | Type_term_index(e,r) -> Type_term_index(Expr_app(Expr_lid_get(false, Const.op_Not_lid, top.range), e, r), r)
             | t -> Type_app(Type_lid(Const.not_lid, top.range), [t], top.range))
      | Op(s, args) ->
          begin match op_as_tylid top.range s with 
            | None -> expr ()
            | Some l -> 
                let t = Type_lid(l, top.range) in 
                let ts = List.map (desugar_typ_or_exp env) args in 
                  Type_app(t, ts, top.range)
          end
      | Tvar a -> Type_var(Typar(a, None), top.range)
      | Var l
      | Name l when (is_type_lid top l env || top.level=Type) -> Type_lid(l, top.range)
      | Construct(l, args) when is_type_lid top l env -> 
          Type_app(Type_lid(l, range_of_lid l), 
                   List.map (desugar_typ_or_exp env) args, 
                   top.range)
      | Abs(pats, body) when top.level=Type -> 
          let spats = List.map (desugar_simple_pat env) pats in
          let body = desugar_typ env body in 
            List.fold_right (fun pat body -> match pat with 
                               | Inl(x,t) -> Type_lam(x, t, body, top.range)
                               | Inr tv -> Type_tlam(tv, body, top.range))
              spats body
      | App(t1, t2) when is_type t1 env -> 
          let t1 = desugar_typ env t1 in 
          let t2 = desugar_typ_or_exp env t2 in 
            Type_app(t1, [t2], top.range)
      | Product([b], t) ->
          let tk = desugar_binder env b in 
          let t2 = desugar_typ env t in 
            begin match tk with 
              | Inl t1 -> Type_fun(t1, t2, top.range)
              | Inr (Some x, k) -> Type_qtyp([Typar(x, Some k)], t2, top.range)
              | _ -> error "Expected a type variable" b b.range
            end
      | Sum(b, t) -> 
          let binders = flatten_tuple top in 
          let args = List.map (desugar_value_binder env) binders in
            Type_tuple(args, top.range)
      | Refine(b,f) -> 
          begin match desugar_value_binder env b with 
            | (None, _) -> raise Impos
            | (Some id, t) -> 
                let f = desugar_formula env f in 
                  Type_refinement(id, t, f, true, top.range)
          end
      | Paren t -> desugar_typ_or_exp env t
      | Affine t -> Type_affine(desugar_typ env t, top.range)
      | _ when top.level=Formula -> Type_formula(desugar_formula env top, top.range)
      | _ ->
          if is_type top env 
          then error "Expected a type" top top.range
          else expr ()
          
and desugar_typ env t =
  match desugar_typ_or_exp {env with phase=Type} t with 
    | Type_term_index(m,_) -> error "Expected type; got expression" t t.range
    | t -> t

and desugar_kind' env k = 
  let is_kind b = b.level=Kind
    || (match b.binder with 
          | NoName ({term=Name {str=s}}) -> 
              s="P" || s="A" || s="S" || s="E"
          | NoName t -> not (is_type t env)
          | _ -> false) in 
    match k.term with 
      | Name {str="P"} -> Kind_prop
      | Name {str="S"} -> Kind_star
      | Name {str="E"} -> Kind_erasable
      | Name {str="A"} -> Kind_affine
      | Wild           -> Kind_unknown
      | Product([b], k) when is_kind b -> 
          let k = desugar_kind env k in 
          let (aopt, k') = desugar_type_binder env {b with level=Kind} in 
            Kind_tcon(aopt, k', k)
      | Product([b], k) -> 
          let k = desugar_kind env k in 
          let (xopt, t) = desugar_value_binder env {b with level=Type} in 
            Kind_dcon(xopt, t, k)
      | _ -> error "Unexpected term where kind was expected" k k.range

and desugar_kind env t = desugar_kind' {env with phase=Kind} t

and desugar_formula' env (f:term) : formula = 
  let atom t = Form_atom(Atom_pred t, f.range) in 
  let connective s = match s with 
    | "&&"
    | "/\\" -> Some Form_conj
    | "||" 
    | "\\/" -> Some Form_disj 
    | "==>" -> Some Form_impl
    | "<==>" -> Some Form_iff
    | _ -> None in 
  let mkQuant q qt binders pats fbody = 
    let binders = List.map (fun (b:binder) -> b.range, desugar_binder env b) binders in 
    let body = desugar_formula env fbody in
    let pats = List.map (fun x -> Atom_pred <| desugar_typ_or_exp env x) pats in 
    snd <| List.fold_right (fun (r,binder) (addpats,body) -> match binder with 
                         | Inl (Some (x:ident), t) -> 
                           let pats = if addpats then pats else [] in 
                           false, q(x,t,body,Range.union_ranges x.idRange fbody.range, pats, false)
                         | Inr (Some (a:ident), k) -> 
                           if addpats && pats <> [] then error "Patterns cannot be attached to a type-quantifier" fbody fbody.range;
                           false, qt(Typar(a, Some k), body, Range.union_ranges a.idRange fbody.range)
                         | _ -> error "Unexpected binder in quantifier" binder r)
        binders (true,body) in
    match f.term with 
      | Op("=", ((hd::_) as args)) -> 
          let args = List.map (desugar_typ_or_exp env) args in 
          let eq = if is_type hd env then Const.eqTyp_lid else Const.eq2_lid in
            atom <| Type_app(Type_lid(eq, f.range), args, f.range)
      | Op(s, args) -> 
          begin match connective s, args with 
            | Some conn, [f1;f2] -> 
                conn(desugar_formula env f1, 
                     desugar_formula env f2, 
                     f.range)
            | _ -> atom (desugar_typ env f)
          end
      | App({term=Var l}, arg) when l.str = "not" -> 
          Form_not(desugar_formula env arg, f.range)
      | If(f1, f2, f3) -> 
          Form_ite(desugar_formula env f1, 
                   desugar_formula env f2, 
                   desugar_formula env f3, 
                   f.range)
      | QForall(binders, pats, f) ->
          mkQuant Form_all Form_quant binders pats f
      | QExists(binders, pats, f) -> 
          mkQuant Form_exists Form_texists binders pats f
      | Paren f -> desugar_formula env f 
      | _ when is_type f env -> 
          atom <| desugar_typ env f
      | _ -> error "Expected a formula" f f.range

and desugar_formula env t = desugar_formula' {env with phase=Formula} t          

and desugar_binding env (pat, term) = 
  let p = desugar_pat env pat in 
  let e = desugar_exp' env term in 
  let p, topt = match p with 
    | Pat_typed(p, t, r) -> p, Some (t,r)
    | _ -> p, None in 
  let e = match topt with 
    | None -> e
    | Some(t,_) -> Expr_typed(e, t, term.range) in
    Binding(NormalBinding, p, BindingExpr(topt, e), pat.range)

and desugar_binder env b = match b.level with 
  | Un
  | Type -> Inl (desugar_value_binder env {b with level=Type})
  | Kind -> Inr (desugar_type_binder env b)
  | _ -> raise Impos

and desugar_value_binder env b = match b.binder, b.level with 
  | Annotated(x, t), Type 
  | Annotated(x, t), _ when is_type t env -> Some x, desugar_typ env t
  | NoName t, Type 
  | NoName t, _ when is_type t env -> None, desugar_typ env t
  | Variable x, Type -> Some x, Type_anon b.range
  | _ -> error "Unexpected domain or range of an arrow or sum (expected a type)" b b.range

and desugar_type_binder env b = match b.binder, b.level with 
  | Annotated(x, t), Kind -> Some x, desugar_kind env t
  | NoName t, Kind -> None, desugar_kind env t
  | Variable x, Kind -> Some x, Kind_star
  | _ -> error "Unexpected domain or range of an arrow or sum (expected a kind)" b b.range

let typar_of_binder env b = match b.level with 
  | Kind -> (match b.binder with 
               | Variable id -> TyparDecl (Typar(id, None))
               | Annotated(id, k) -> TyparDecl (Typar(id, Some <| desugar_kind' env k))
               | _ -> error "Unexpected type parameter" b b.range)
  | Type -> (match b.binder with 
               | Annotated(id, t) -> TermparDecl(id, desugar_typ env t)
               | _ -> error "Unexpected type parameter" b b.range)
  | _ -> raise Impos

let desugar_tycon env tc : tyconDefn =
  let mkTyconInfo id binders kopt def_k = 
    let k = match kopt with 
      | None -> def_k
      | Some k -> desugar_kind' env k in 
    let typars = List.map (typar_of_binder env) binders in 
      Sugar.Tycon(Absyn.asLid [id], k, typars, false, id.idRange) in 
  let mkRecdField (id, t) = Field(id, desugar_typ env t, id.idRange) in 
  let mkConstructor (id, t) = UnionConstr(id, ConstrType <| desugar_typ env t, id.idRange) in 
  match tc with 
    | TyconAbstract(id, binders, kopt) -> 
        TyconDefn(mkTyconInfo id binders kopt Kind_star, 
                  TyconCore_repr_hidden id.idRange, 
                  id.idRange)
    | TyconAbbrev(id, binders, kopt, t) -> 
        TyconDefn(mkTyconInfo id binders kopt Kind_unknown, 
                  TyconCore_abbrev(desugar_typ env t, t.range),
                  id.idRange)
    | TyconRecord(id, binders, kopt, fields) -> 
        TyconDefn(mkTyconInfo id binders kopt Kind_star, 
                  TyconCore_recd(List.map mkRecdField fields, id.idRange), 
                  id.idRange)
    | TyconVariant(id, binders, kopt, constructors) -> 
        TyconDefn(mkTyconInfo id binders kopt Kind_star, 
                  TyconCore_union(List.map mkConstructor constructors, id.idRange), 
                  id.idRange)

let desugar_tycons is_data env tcs = 
  let ids = tcs |> List.collect 
      (function 
         | TyconAbstract(id, _, _)
         | TyconAbbrev(id, _, _, _) 
         | TyconRecord(id, _, _, _)  -> [id]
         | TyconVariant(id, _, _, constrs) ->
             if is_data 
             then id::(List.map (fun (c:ident, _) -> ident(c.idText^"_is", c.idRange)) constrs)
             else [id]) in 
  let env = {env with curmod=ids@env.curmod} in 
    List.map (desugar_tycon env) tcs, env
            
let desugar_decl env (d:decl) : list<ModuleImplDecl> * env = match d.decl with 
  | Open lid -> [Def_open(lid, d.range)], {env with open_mods=lid::env.open_mods}
  
  | Tycon(quals, tcs) -> 
      let priv = false in 
      let is_data = match quals with 
        | Some (LogicTag (Some Logic_data)) -> true
        | _ -> false in
      let tcs,env = desugar_tycons is_data env tcs in 
      let mimpls = match quals with 
        | Some (Extern id) -> 
            tcs |> List.map (fun tc -> Def_extern_typ(ExternRefId id, tc, d.range))
        | _ -> 
            let logic_tags = match quals with
              | Some (LogicTag l) -> listOfOpt l
              | _ -> [] in 
              [Def_tycon(tcs, false, priv, logic_tags, d.range)] in 
        mimpls, env
          
  | ToplevelLet(isrec, lets) -> 
      [Def_let(isrec, List.map (desugar_binding env) lets, d.range)], env

  | Main t -> 
      [Def_expr(desugar_exp' env t, d.range)], env

  | Assume(atag, id, t) -> 
      let f = desugar_formula env t in 
        [begin match atag with 
           | AssumeTag -> Def_assume(Some id, f, Assumption, d.range)
           | DefinitionTag -> Def_assume(Some id, f, Definition, d.range)
           | QueryTag -> Def_query(Absyn.asLid [id], f, d.range) 
         end], env
          
  | Val(None, id, t) -> 
      [Def_val(id, desugar_typ env t, d.range)], env

  | Val(Some (LogicTag None), id, t) -> 
      [Def_logic_function(id, desugar_typ env t, d.range)], env

  | Val(Some (Extern eref), id, t) -> 
      [Def_extern_val(ExternRefId eref, id, desugar_typ env t, d.range)], env

  | Val(Some q, _, _) -> error "Unexpected qualifier on val-declaration" q d.range
      
  | ExternRef(id, eref) -> 
      [(match mkExternRefOpt d.range eref with 
          | None -> error "Invalid extern reference" eref d.range
          | Some e -> Def_extern_ref(id, e, d.range))], env
        
let desugar_modul env (m:modul) : ParsedImplFileFragment * env = match m with 
  | Module(mname, decls) -> 
      let decls, env = List.fold_left (fun (out, env) d -> 
                                         let ds,env = desugar_decl env d in 
                                           ds::out, env) ([], env) decls in 
      let decls = List.flatten <| List.rev decls in
      let env = {env with 
                   curmod=[];
                   mods={mname=mname;types=env.curmod}::env.mods;
                   open_mods=[Const.prims_lid]} in 
        NamedTopModuleImpl(ModuleOrNamespaceImpl(mname, None, decls, Sugar.range_of_lid mname)), env
          
let desugar_moduls =
  let envcarry = ref initial_env in 
    fun ms -> 
      let env = !envcarry in
      let mods, env = List.fold_left 
        (fun (out,env) m -> 
           let m, env = desugar_modul env m in 
             (m::out, env)) ([], env) ms in 
        envcarry := env;
        List.rev mods

let desugar_pragma = function
  | Monadic(l1,l2,l3) -> PRAGMA_MONADIC(Type_lid(l1, range_of_lid l1), 
                                        Type_lid(l2, range_of_lid l2), 
                                        Type_lid(l3, range_of_lid l3))
  
let desugar_file (pragmas, ms) =
  let ms = desugar_moduls ms in 
    ParsedImplFileWithPragmas(ms, List.map desugar_pragma pragmas)

            

