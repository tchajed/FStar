#light "off"
module Microsoft.FStar.Parser

open System

open FParsec
open FParsec.Error
open FParsec.Primitives
open FParsec.CharParsers
open Microsoft.FStar.Util
open Microsoft.FStar.Absyn
open Microsoft.FStar.Sugar
open Microsoft.FStar.Lexer
open Microsoft.FStar.Range
open Microsoft.FStar.Profiling

//let rec todo x = todo x
let monadic_mode = ref false
(* Unifying top-level bindings with local bindings *)
type BindingSet = BindingSet of range * bool * binding list
let mkLocalBindings wholem (BindingSet(_,isRec,decls)) body = 
   Expr_let (isRec,false,decls,body,wholem) 
let mkDefnBindings wholem (BindingSet(_,isRec,decls))  = 
   Def_let (isRec,decls,wholem) 
let mkEqTyp t1 t2 r = 
  let opeq = Type_lid(Const.eq_lid, r) in
  let eqpred = Type_app(opeq, [Type_anon(r);t1;t2], r) in
    eqpred
let rec isConstructorApp = function
  | Type_lid(lid, _) 
  | Type_app(Type_lid(lid, _), _, _) -> not (Sugar.lid_equals lid Const.eq_lid)
  | Type_paren(t, _) -> isConstructorApp t
  | _ -> false
let mkPrecedence phi and_or phi' r = match phi' with 
  | Form_paren _ -> and_or(phi, phi', r)
  | Form_impl(phi1, phi2, r') -> Form_impl(and_or(phi, phi1, r), phi2, union_ranges r r')
  | Form_iff(phi1, phi2, r') -> Form_iff(and_or(phi, phi1, r), phi2, union_ranges r r')
  | _ -> and_or(phi, phi', r)
let rec unparen = function
  | Form_paren(phi, _) -> unparen phi
  | phi -> phi
let ifNextTokenNot p q r = ifNextToken p (fun _ -> r) q

let bindOpt (p:Parser<option<'a -> 'a>, 'b>) (a:'a) : Parser<'a,'b> = 
    p >>= (function None -> preturn a
                  | Some mkA -> preturn (mkA a))

let bindOptDisj (p:Parser<option<'a -> 'a>, 'b>) (a:'a) : Parser<Disj<'a,'a>,'b> = 
    p >>= (function None -> preturn (Inl a)
                  | Some mkA -> preturn (Inr (mkA a)))

(* Restoring left-associativity of type applications, tuples, and term applications *)
let flatten_tyapp t = match t with 
  | Type_app(t, tl, _) -> t::tl
  | _ -> [t]

let flatten_tuple_typ t = match t with 
  | Type_tuple(tl, _) -> tl
  | _ -> [(None, t)]

let flatten_tuple_pat p = match p with 
  | Pat_tuple(pats, _) -> pats
  | _ -> [p]

let flatten_tuple e = match e with 
  | Expr_tuple(el, _) -> el
  | _ -> [e]

let rec flatten_app e = match e with 
    | Expr_app(e1, e2, r) -> 
         let out = flatten_app e1 in
           out@[(e2, range_of_synexpr e2)]
    | _ -> [e, range_of_synexpr e]


let warn =
  let ranges = ref [] in
    fun r i j -> 
      let sr = string_of_range r in 
        if List.exists (fun sr' -> sr=sr') !ranges then j
        else (ranges := sr::!ranges;
              Util.warn "%s: %s is deprecated; use %s instead\n" sr i j; 
              j)
        
(* See grammar.txt for a BNF of the grammar parsed by this module *)
let ident : Parser<ident, 'a> = fun s -> s |>
begin
   (rhs >>= (fun r1 ->      
    IDENT_NOWS >>= (fun i -> rhs >>= 
                   (fun r2 ->  ws >>.
                    let r = union_ranges r1 r2 in
                    let i = match i with 
                      | "true_prop" -> warn r i "True"
                      | "false_prop" -> warn r i "False"
                      | _ -> i in 
                      preturn (ident(i,r))))))
end

(* See grammar.txt for a BNF of the grammar parsed by this module *)
let ident_nows : Parser<ident, 'a> = fun s -> s |>
begin
   (rhs >>= (fun r1 ->      
    IDENT_NOWS >>= (fun i -> rhs >>= 
                 (fun r2 -> 
                    let r = union_ranges r1 r2 in
                      preturn (Sugar.ident(i,r))))))
end

let rec path_nows : Parser<lident,'a> = fun s -> s |>
begin
  ident_nows >>= (fun i -> 
  ifNextToken DOT 
    (fun _ -> path_nows >>= (fun p -> preturn (asLid <| (i::p.lid))))
    (preturn (asLid <| [i])))
end

let path = fun s -> s |> (path_nows .>> ws)

let ident_colon = fun s -> s |>
  (ident >>= (fun id -> 
   COLON >>. preturn id))

let logic_tycon = fun s -> s |>
begin
     LOGIC >>.
    ((DATA_TAG >>. preturn Logic_data)
 <|> (TFUN_TAG >>. preturn Logic_tfun)
 <|> (ARRAY_TAG >>. LPAREN >>. ident >>= (fun sel -> 
                COMMA >>.  ident >>= (fun upd -> 
                COMMA >>.  ident >>= (fun emp -> 
                COMMA >>.  ident >>= (fun indom -> 
                RPAREN >>. preturn (Logic_array({array_sel=asLid [sel]
                                                ;array_upd=asLid [upd]
                                                ;array_emp=asLid [emp]
                                                ;array_indom=asLid [indom]}))))))))
end

let typeWithMeta = fun s -> s |>
begin
    (btOpt "" logic_tycon) >>= (fun lopt -> 
     TYPE |>> (fun _ ->  match lopt with 
                 | None -> [] 
                 | Some l -> [l]))
end
    
let qual = fun s -> s |> PRIVATE 

let tvar = fun s -> s |>
   (rhs >>= (fun r1 -> 
    TVAR >>= (fun tv -> rhs |>> (fun r2 -> Sugar.ident(tv,union_ranges r1 r2)))))

let twild = fun s -> s |>
    (rhs >>= (fun r1 -> 
     QUOTE >>. UNDERSCORE |>> (fun _ -> Pat_uvar r1)))

let arrowOrStar = fun s -> s |>
begin
    (RARROW >>. preturn (fun idOpt t1 t2 r -> Type_fun((idOpt, t1), t2, r)))
<|> (STAR >>. preturn (fun idOpt t1 t2 r -> let t2l = flatten_tuple_typ t2 in 
                                          Type_tuple((idOpt, t1)::t2l, r)))
<|> (GTGT >>. preturn (fun idOpt t1 t2 r -> Type_affine(Type_fun((idOpt, t1), t2, r), r)))
end 

let frameCount () = 
  let st = new System.Diagnostics.StackTrace() in 
    pr "Stack trace frame count=%d\n" st.FrameCount

(* Parsing sequences *)
let sequenceMod delim p = 
  p >>= (fun first -> 
           let pp = (delim >>.  p) in 
           many pp  |>> (fun rest -> first::rest))

let sequence delim p = 
  p >>= (fun first -> 
           let pp = (delim >>. p) in 
           many pp  |>> (fun rest -> first::rest))

let rec seqBind delim p = 
    p >>= (fun hd -> 
    ifNextToken (delim hd) 
        (fun _ -> seqBind delim p |>> (fun tl -> hd::tl))
        (preturn [hd]))

(* Expression language *)

let firstConstant = firstIDENT
let firstAtomicPattern = fun s -> s |>
  (UNDERSCORE <|> QUOTETOK <|> firstIDENT <|> LBRACE <|> LBRACK <|> LPAREN <|> firstConstant)

let constant = fun s -> s |>
begin
    (TRUE >>. preturn (Const_bool true))
<|> (FALSE >>. preturn (Const_bool false))
<|> (UNIT_VAL >>. preturn Const_unit)
<|> ((bt "int" ((pint32 >>= (fun r -> 
                               peekIfNextToken DOT 
                                  pfail 
                                 (preturn r)))) .>> ws) |>> (fun f -> Const_int32 f))
<|> ((bt "float" (pfloat .>> ws)) |>> (fun f -> Const_float f))
<|> (STRING_BYTES >>= (fun str -> rhs |>> (fun p -> Const_string (str,p))))
end

(* Let bindings *)

(* Pattern language (factored) 
bindingPattern1:
  | atomicPattern
  | path (seq ws atomicPattern)

bindingPattern:
  | bindingPattern1
  | bindingPattern1 bindingPattern'

bindingPattern':
  | COLON_COLON (seq COLON_COLON bindingPattern)
  | COMMA (seq COMMA bindingPattern)

atomicPattern:
  | UNDERSCORE 
  | path
  | constant
  | FALSE
  | TRUE
  | LBRACE (seq SEMI_COLON fieldPattern)recordPatternElements RBRACE
  | LBRACK (seq SEMI_COLON bindingPattern) RBRACK
  | LPAREN bindingPattern RPAREN 
  | LPAREN bindingPattern AS ident RPAREN 
  | LPAREN bindingPattern COLON typ RPAREN 

fieldPattern: 
 | pat EQUALS bindingPattern *)

let rec bindingPattern1 : Parser<synpat, 'c> = fun s -> s |>
begin
    (bt "constrPattern 1.1" 
        (path >>= (fun constr -> rhs >>= (fun r1 -> 
        (sequence (wsUntil firstAtomicPattern) atomicPattern) >>= (fun args -> rhs |>> (fun r2 ->
          Pat_lid(constr, args, r1)))))))
<|>
     atomicPattern 
end

and bindingPattern = fun s -> s |>
begin
    bindingPattern1 >>= (fun p1 -> rhs >>= fun r ->
    btOpt "bindingPattern' 2" bindingPattern' |>> (function None -> p1 | Some mkPat -> mkPat r p1))
end

and bindingPattern' : Parser<range -> synpat -> synpat, 'a> = fun s -> s |>
begin
    (COLON_COLON >>.
    (sequence COLON_COLON bindingPattern) >>= (fun pats -> rhs |>> (fun r2 r1 hd ->
       let r = union_ranges r1 r2 in
       let cons = mksyn_constr r Const.cons_str in
       let pats, tl = Util.pfx pats in
       List.fold_right (fun hd tl -> Pat_lid (cons, [hd; tl], r)) (hd::pats) tl)))
<|> (COMMA >>.
     bindingPattern >>= (fun pat -> rhs |>> (fun r2 r1 hd -> 
        let pats = flatten_tuple_pat pat in
          Pat_tuple(hd::pats, union_ranges r1 r2))))
end

and atomicPattern = fun s -> s |>
begin
   (path >>= (fun lid -> rhs |>> fun r ->
        if List.length lid.lid > 1 || (let c = (List.hd lid.lid).idText.[0] in Char.IsUpper(c) && not (Char.IsLower c)) 
        then mksyn_pat_maybe_var lid r (* from Sugar *)
        else mksyn_pat_var (List.hd lid.lid)))
<|> (tvar >>= (fun tv -> 
    (opt (COLON_COLON >>. kind)) >>= (fun kopt ->
                                        rhs |>> (fun r -> 
                                                   match kopt, tv.idText with 
                                                     | None, "'_" -> Pat_uvar r
                                                     | _ -> Pat_tvar(Typar(tv, kopt), r)))))
<|> 
    (UNDERSCORE >>. rhs |>> Pat_wild)
<|>
    (constant >>= (fun c -> rhs |>> fun r -> Pat_const(c, r)))
<|>
    (LBRACE >>.
    (sequence SEMICOLON fieldPattern) >>= (fun fpats -> 
    RBRACE >>. rhs |>> (fun r -> Pat_recd(fpats, r))))
<|> 
    (LBRACK >>.
    (btOptList "emptyList" (sequence SEMICOLON bindingPattern)) >>= (fun lpats -> 
    RBRACK >>. rhs |>> (fun r -> 
        match lpats with 
            | [] -> Pat_lid(Const.nil_lid, [], r)
            | _ -> Pat_array_or_list(false, lpats, r))))
<|>
    (LPAREN >>.
    bindingPattern >>= (fun pat -> 
    (btOpt "as x 3" (AS >>. ident)) >>= (fun idOpt -> rhs >>= (fun rid ->
    (btOpt ": t 4" (COLON >>. typ)) >>= (fun topt -> rhs >>= (fun rt -> //pr "Maybe parsed (: t 4) %A\n" topt;
    (btOpt "{phi} 4.1" (LBRACE >>. formula .>> RBRACE)) >>= (fun phiOpt -> rhs >>= (fun rphi ->
    RPAREN >>. rhs >>= (fun r -> 
        let pat = match idOpt with 
            | Some id -> Pat_as(pat, id, false, rid)
            | None -> pat in
         match topt with 
            | Some t -> 
                (match phiOpt with 
                     | None -> preturn (Pat_paren (Pat_typed(pat, t, rt), r))
                     | Some phi -> 
                        (match pat with 
                            | Pat_as(Pat_wild _, id, _, _) ->
                                let t = Type_refinement(id, t, phi, true, union_ranges id.idRange rphi) in
                                preturn (Pat_paren (Pat_typed(pat, t, rt), r))
                            | _ -> //pr "Unexpected refinement: pattern is %A\n" pat; 
                                   perr "Unexpected refinement in pattern"))
            | None -> 
                 match phiOpt with
                    | None -> preturn (Pat_paren(pat, r))
                    | Some _ -> perr "Unexpected refinement in pattern")))))))))
end

and fieldPattern = fun s -> s |>
begin
    (path >>= (fun field -> 
     EQUALS >>.
     bindingPattern |>> (fun pat -> (let x,y = Util.pfx field.lid in (asLid x, y), pat))))
end

and atomicPatterns = fun s -> s |> (sequence (wsUntil firstAtomicPattern) atomicPattern)

(* Expression language, inlcuding top-level let-bindings *)
and localBinding : Parser<binding, 'a> = fun s -> s |>
begin
    (bindingPattern >>= (fun pat -> 
    (btOpt ": t 5" (COLON >>. typ >>= fun t -> rhs |>> (fun r -> (t, r)))) >>= (fun trOpt -> 
    EQUALS >>.
    exp >>= (fun e -> rhs |>> (fun r -> mksyn_binding pat (r, (), trOpt, e, ()))))))
end

(* Expression language (left-factored)
exp1 ::=
 | path
 | constant
 | defnBindings IN exp
 | MATCH exp WITH (opt BAR) (seq BAR patternClause)
 | IF exp THEN exp ELSE exp 
 | FUN atomicPatterns RARROW exp
 | ASSUME formula
 | LPAREN exp RPAREN
 | LPAREN exp COLON typ RPAREN
 | LBRACE fieldExpList RBRACE
 | LBRACK (seq SEMICOLON exp) RBRACK
 | minusExpr %prec expr_prefix_plus_minus { $1 }

exp ::= 
 | exp1 
 | exp1 exp'

exp' ::=
 | (seq COMMA exp)
 | LESS (seq COMMA typ) GREATER
 | SEMICOLON exp
 | infix_op exp 
 | DOT path
 | exp  --normalized to be left-associative 

patternClause ::=
 | bindingPattern RARROW exp
 | bindingPattern WHEN exp RARROW exp
*)

and value1 = fun s -> s |>
begin
  rhs >>= fun r1 -> 
begin
    (pathExp r1)
<|> (constantExp r1)
<|> (lambdaExp r1)
<|> (parenOrUnitExp r1 value)
<|> (recordExp r1 value)
<|> (listExp r1 value)
end
end

and pathExp r1 = fun s -> s |>
  (path >>= (fun lid -> rhs |>> (fun r2 -> 
     Expr_lid_get(false, lid, union_ranges r1 r2))))

and pathOrTyAppExp r1 : Parser<Sugar.synexpr, 'a>  = fun s -> s |>
  (path_nows >>= (fun lid -> rhs >>= (fun r2 -> 
   let e = Expr_lid_get(false, lid, union_ranges r1 r2) in
   ifNextToken LESS
     (fun _ -> 
        ((sequence COMMA typOrFormula) >>= (fun tl -> 
         GREATER >>. rhs >>= (fun r ->
          preturn (Expr_tyapp(e, tl, r))))))
     (ws >>. preturn e))))

and constantExp r1 = fun s -> s |>
 (constant >>= (fun sc -> rhs |>> (fun r2 -> 
     Expr_const(sc, union_ranges r1 r2))))

and lambdaExp r1 = fun s -> s |> 
begin
  (FUN >>. 
   atomicPatterns >>= (fun pats -> 
   RARROW >>.
   exp >>= (fun body -> rhs |>> fun r2 -> 
    let r = union_ranges r1 r2 in
    mksyn_match_lambdas false r pats body)))
end

and parenOrUnitExp r1 v_or_e = fun s -> s |>
begin
  (LPAREN >>.
   btOpt "maybe unit" (v_or_e >>= (fun e -> 
   btOpt ":t 7" (COLON >>. typ) |>> (fun topt -> (e, topt)))) >>= (fun etopt_opt -> 
   RPAREN >>. rhs |>> (fun r2 -> 
     let r = union_ranges r1 r2 in
       match etopt_opt with 
         | None -> Expr_const(Const_unit, r)
         | Some (e, Some t) -> Expr_paren(Expr_typed(e, t, r), r)
         | Some (e, None) -> Expr_paren(e,r))))
<|> (BEGIN >>. 
     v_or_e >>= (fun e -> 
     END >>. rhs |>> (fun r2 -> Expr_paren(e, union_ranges r1 r2))))
end

and recordExp r1 v_or_e = fun s -> s |>
    (LBRACE >>. rhs >>= (fun r1 ->
     btOpt "e with 8" (v_or_e .>> WITH) >>= (fun eopt -> 
     (sequence SEMICOLON (fieldExp v_or_e)) >>= (fun flds -> 
     RBRACE >>. rhs |>> (fun r2 ->
        Expr_recd(eopt, flds, union_ranges r1 r2))))))

and listExp r1 v_or_e = fun s -> s |>
begin
  (LBRACK >>.
  (btOptList "emptyList" (sequence SEMICOLON v_or_e)) >>= (fun el -> 
   RBRACK >>. rhs |>> (fun r2 -> 
     Expr_list(el, union_ranges r1 r2))))
end

and value = fun s -> s |>
  let r1 = rangeOfPos s.Position in
begin 
   value1 >>= (fun e -> 
   (btOpt "value 9" value') >>= (function None -> preturn e | Some mkE -> rhs |>> fun r2 -> 
      mkE r1 (union_ranges r1 r2) e))
end

and argValue = fun (s:State<'a>) -> s |>
  let r1 = rangeOfPos s.Position in
begin 
   value1 >>= (fun e -> 
   (btOpt "argValue 10" argValue') >>= (function None -> preturn e | Some mkE -> rhs |>> fun r2 -> 
      mkE r1 (union_ranges r1 r2) e))
end

and value' = fun s -> s |>
begin
    (COMMA >>. value |>> fun e _ r hd -> 
        let el = flatten_tuple e in 
            Expr_tuple(hd::el, r))
<|>
    (argValue >>= (fun e2 -> 
    (btOpt "exp' 10.1" value') >>= (fun mkRestOpt -> rhs |>> (fun r2 -> 
        fun r1 r e1 ->
         let e2l = flatten_app e2 in 
         let appExp, rApp = List.fold_left (fun (e1, r1) (e2, r2) -> 
                                  let r = union_ranges r1 r2 in 
                                  (Expr_app(e1, e2, r), r)) (e1, r1) e2l in
            match mkRestOpt with 
                | None -> appExp
                | Some mkRest -> mkRest rApp (union_ranges rApp r2) appExp))))
end

and argValue' = fun s -> s |>
begin
    (argValue |>> (fun e2 r1 r e1 -> 
        let e2l = flatten_app e2 in 
        fst <| List.fold_left (fun (e1, r1) (e2, r2) -> 
                                  let r = union_ranges r1 r2 in 
                                  (Expr_app(e1, e2, r), r)) (e1, r1) e2l)) 
end

and fieldExp v_or_e = fun s -> s |>
begin
    path >>= (fun fld -> 
    EQUALS >>.
    v_or_e |>> (fun e -> (let x,y = Util.pfx fld.lid in (asLid x, y), e)))
end

and atomicExp1 : Parser<Sugar.synexpr, 'a> = fun s -> s |>
begin
  rhs >>= fun r1 -> 
begin
    (pathOrTyAppExp r1)
<|> (constantExp r1)
<|> (parenOrUnitExp r1 exp)
<|> (listExp r1 exp1)
end
end

and firstAtomicExp1 = fun s -> s |>
    (firstIDENT <|> LPAREN <|> LBRACK)

and exp1 = fun s -> s |>
begin
  rhs >>= fun r1 -> 
begin
   ((atomicExp1) >>= (fun e1 -> rhs >>= (fun r -> 
    (btOptList "maybe args" (sequence (wsUntil firstAtomicExp1) atomicExp1)) |>> (fun args -> 
     match args with 
       | [] -> e1
       | _ -> List.fold_left (fun out arg -> 
                                let r = union_ranges (range_of_synexpr out) (range_of_synexpr arg) in
                                  Expr_app(out, arg, r)) e1 args))))
<|> 
    (BANG >>. atomicExp1 >>= (fun e -> rhs |>> (fun r -> 
      if !monadic_mode 
      then Expr_app(Expr_lid_get(false, Const.unqual_read_lid, r), e, r)
      else Expr_app(Expr_lid_get(false, Const.op_Dereference_lid, r), e, r))))

<|> (UNARY_PREFIX_OP >>= (fun op -> 
     atomicExp1 >>= (fun e -> rhs |>> (fun r ->
     mksyn_prefix r op  e))))
<|> (recordExp r1 exp1)
<|> (lambdaExp r1)
<|> (letBindings >>= (fun bindings -> 
     IN >>.
     exp >>= (fun body -> rhs |>> (fun r2 -> 
        mkLocalBindings (union_ranges r1 r2) bindings body))))
<|> (MATCH >>.
     exp >>= (fun e -> 
     WITH >>.
     (btOpt "| 6" BAR) >>.
     (sequence BAR patternClause) >>= (fun clauses -> rhs |>> (fun r2 -> 
        Expr_match(e, clauses, false, union_ranges r1 r2)))))
<|> (FUNCTION >>.
    (btOpt "| 6" BAR) >>.
    (sequence BAR patternClause) >>= (fun clauses -> rhs |>> (fun r2 -> 
       mksyn_match_lambda(false, false, union_ranges r1 r2, clauses))))
<|> (IF >>. 
     exp >>= (fun e -> 
     THEN >>.
     exp >>= (fun e2 -> rhs >>= (fun r2 ->
     ELSE >>. 
     exp >>= (fun e3 -> rhs |>> fun r3 -> 
        Expr_cond(e, e2, Some e3, union_ranges r1 r2, union_ranges r1 r3))))))
<|> (ASSUME >>.
     formula >>= (fun phi -> rhs |>> (fun r2 -> 
       let alid = Const.assume_lid in 
       let r = union_ranges r1 r2 in
         Expr_app(Expr_tyapp(Expr_lid_get(false, alid, r1), 
                             [Type_formula(phi, r2)], 
                             r), 
                  Expr_const(Const_unit, r), 
                  r))))
<|> (ASSERT >>.
     formula >>= (fun phi -> rhs |>> (fun r2 -> 
       let alid = Const.assert_lid in 
       let r = union_ranges r1 r2 in
         Expr_app(Expr_tyapp(Expr_lid_get(false, alid, r1), 
                             [Type_formula(phi, r2)], 
                             r), 
                  Expr_const(Const_unit, r), 
                  r))))

(* <|> (BANG >>.  *)
(*      atomicExp1 >>= (fun e -> rhs |>> (fun r2 ->  *)
(*        let r = union_ranges r1 r2 in *)
(*          Expr_app(Expr_lid_get(false, Const.read_lid, r1),  *)
(*                   e,  *)
(*                   r)))) *)

(* <|> (REF >>.  *)
(*      atomicExp1 >>= (fun e -> rhs |>> (fun r2 ->  *)
(*        let r = union_ranges r1 r2 in *)
(*          Expr_app(Expr_lid_get(false, Const.newref_lid, r1),  *)
(*                   e,  *)
(*                   r)))) *)
end
end

and exp = fun s -> s |>
  let r1 = rangeOfPos s.Position in
begin 
   exp1 >>= (fun e -> 
   (btOpt "exp' 9" exp') >>= (function None -> preturn e | Some mkE -> rhs |>> fun r2 -> 
      mkE r1 (union_ranges r1 r2) e))
end

and argExp = fun (s:State<'a>) -> s |>
  let r1 = rangeOfPos s.Position in
begin 
   atomicExp1 >>= (fun e -> //pr "parsed arg expression %A\n" e;
   (btOpt "argExp' 10" argExp') >>= (function None -> preturn e | Some mkE -> rhs |>> fun r2 -> 
      mkE r1 (union_ranges r1 r2) e))
end

and exp' = fun s -> s |>
begin
    (COMMA >>. exp |>> fun e _ r hd -> 
        let el = flatten_tuple e in 
            Expr_tuple(hd::el, r))
<|> 
    (COLON_EQUALS >>. atomicExp1 |>> (fun rhs _ r lhs -> 
      if !monadic_mode
      then Expr_app(Expr_app(Expr_lid_get(false, Const.unqual_write_lid, r), lhs, r), rhs, r)
      else Expr_app(Expr_app(Expr_lid_get(false, Const.op_ColonEquals_lid, r), lhs, r), rhs, r)))
    
(* <|>  *)
(*     (LESS >>. *)
(*     (sequence COMMA typOrFormula) >>= (fun tl ->  *)
(*      GREATER >>. *)
(*      (btOpt "exp' 10.0" exp') >>= (fun mkRestOpt -> rhs |>> (fun r2 r1 r e ->  *)
(*         let tapp = Expr_tyapp(e, tl, r) in *)
(*         match mkRestOpt with  *)
(*             | None -> tapp *)
(*             | Some mkRest -> mkRest r (union_ranges r1 r2) tapp)))) *)
<|> 
    (SEMICOLON >>. 
     exp |>> (fun e2 _ r e1 -> Expr_seq(true, e1, e2, r)))
<|> 
    (INFIX_OP >>= (fun op -> 
     exp |>> fun e2 _ r e1 -> mksyn_infix r r e1 op e2))
<|> 
    (DOT >>.
     path |>> (fun lid r1 r2 e1 -> 
                 Expr_lvalue_get(e1, lid, Range.union_ranges r1 r2)))
<|>
    (argExp >>= (fun e2 -> //pr "parsed args as app: %A\n" e2;
    (btOpt "exp' 10.1" exp') >>= (fun mkRestOpt -> rhs |>> (fun r2 -> 
        fun r1 r e1 ->
         let e2l = flatten_app e2 in 
         let appExp, rApp = List.fold_left (fun (e1, r1) (e2, r2) -> 
                                  let r = union_ranges r1 r2 in 
                                  (Expr_app(e1, e2, r), r)) (e1, r1) e2l in
            match mkRestOpt with 
                | None -> appExp
                | Some mkRest -> mkRest rApp (union_ranges rApp r2) appExp))))
end

and argExp' = fun s -> s |>
begin
    (argExp |>> (fun e2 r1 r e1 -> 
        let e2l = flatten_app e2 in 
        fst <| List.fold_left (fun (e1, r1) (e2, r2) -> 
                                  let r = union_ranges r1 r2 in 
                                  (Expr_app(e1, e2, r), r)) (e1, r1) e2l)) 
end

and patternClause = fun s -> s |>
begin 
    rhs >>= (fun r1 -> 
    bindingPattern >>= (fun pat -> 
    btOpt "when e 11" (WHEN >>. exp) >>= (fun eopt -> 
    RARROW >>.
    exp >>= (fun body -> rhs |>> (fun r2 -> 
        Clause(pat, eopt, body, union_ranges r1 r2))))))  
end 

and letBindings = fun s -> s |>
begin
    LET >>. rhs >>= (fun r ->
    (btOpt "rec 12" REC) >>= (fun recOpt -> 
    localBindingList |>> (fun bindings -> 
        BindingSet(r, recOpt <> None, bindings))))
end

and localBindingList = fun s -> s |> (sequence AND localBinding)


(* Type language *)
//typ1 ::=   (* left recursion *)
//  | UNDERSCORE  
//  | tyvar  
//  | path  
//  | ident COLON typ RARROW typ  
//  | ident COLON typ LBRACE formula RBRACE RARROW typ  
//  | ident COLON typ LBRACE formula RBRACE  
//  | LBRACE ident COLON typ BAR formula RBRACE  
//  | BACKSLASH c_tfun_binders DOT typ  
//  | BANG typ  
//  | FORALL tyvar opt_colon_colon_kind DOT typ 
//  | LPAREN typ opt_colon_colon_kind RPAREN  
//  | LPAREN typ STAR typ RPAREN
//  | LPAREN ident COLON typ STAR typ RPAREN
//
// typ ::= typ1 typ'
// 
// typ' ::=
//  | 
//  | typ typ'
//  | value typ'
//  | RARROW typ 
//  | STAR typ

and typ1 : Parser<Sugar.typ,'a> = fun s -> s |>
begin
    (UNDERSCORE >>. rhs |>> (fun r -> Type_anon(r)))
<|> (META_TID >>. pint32 >>= (fun i -> rhs |>> (fun r -> Type_tid(i, r))))
<|> (META_NAMED >>. STRING_BYTES >>= (fun s -> typ1 >>= (fun t -> rhs |>> (fun r -> Type_named(Util.unicodeEncoding.GetString(s), t, r)))))
<|> (tvar >>= (fun tv -> (* 'a::k -> t *)
    (ifNextTokenNot COLON_COLON (prestore "try tvar" s)
       (kind >>= (fun k -> 
        RARROW >>. typ >>= (fun t -> rhs |>> (fun r -> 
        Type_qtyp([Typar(tv, Some k)], t, r))))))))
<|> (tvar >>= (fun tv -> rhs |>> (fun r -> (* pr "Parsed type var %A\n" tv; *) Type_var(Typar(tv, None),r))))
<|> (* id:t -> t'   OR    id:t{phi} -> t'  OR   id:t{phi}  OR  
       id:t * t'    OR    id:t{phi} * t'                      *)
    (ident >>= (fun id -> (* pr "Parsed id %A\n" id; *)
    (ifNextTokenNot COLON (prestore "try path" s) 
        (noarrow_typ >>= (fun t -> (* pr "Parsed no_arrow %A\n" t; *)
           ifNextToken arrowOrStar 
             (fun mkT -> typ >>= (fun t' -> rhs |>> fun r -> mkT (Some id) t t' r))
             (LBRACE >>. formula >>= (fun phi -> rhs >>= (fun phi_r -> (* pr "parsed formula: %A\n" phi; *)
              RBRACE >>. 
              let refType = Type_refinement(id, t, phi, true, phi_r) in
              ifNextToken arrowOrStar
              (fun mkT -> typ >>= (fun t' -> rhs |>> (fun r -> mkT (Some id) refType t' r)))
              (preturn refType)))))))))
<|> 
    (path >>= (fun lid -> rhs |>> (fun r -> Type_lid(lid, r))))
<|> (* { x:t | phi } *)
    (LBRACE >>.
     ident >>= (fun id -> 
     COLON >>.
     typ >>= (fun t -> 
     BAR >>.
     formula >>= (fun phi -> 
     RBRACE >>. rhs |>> (fun r -> 
        Type_refinement(id, t, phi, false, r))))))
<|> ifNextToken (FUN >>. tfun_binders .>> RRARROW)
      (fun binders -> 
         typOrFormula >>= (fun t -> rhs |>> fun r -> 
         List.fold_right (fun binder out -> match binder with 
                            | Inr(tv,k) -> Type_tlam(Typar(tv,Some k), out, r)
                            | Inl(id,t) -> Type_lam (id, t, out, r)) binders t))
      (prestore "not a type-level lambda" s)
<|> (BANG >>.
     typ >>= (fun t -> rhs |>> (fun r -> Type_affine(t, r))))
<|> (LPAREN >>. rhs >>= (fun r1 ->
     typ >>= (fun t -> 
     btOpt "::k 13" (COLON_COLON >>. kind) >>= (fun kopt -> 
     RPAREN >>. rhs |>> (fun r2 -> 
        let r = union_ranges r1 r2 in
        match kopt with 
         | None -> Type_paren(t, r)
         | Some k -> Type_paren(Type_ascribed(t, k, r), r))))))
end

and typOrFormula = fun s -> s |>
begin
    (bt "typ 13.1" typ) 
<|> (formula >>= (fun f -> rhs >>= (fun r -> preturn (Type_formula(f, r)))))
end 

and typ = fun s -> s |>
begin
   typ1 >>= (fun t ->  (* pr "Typ parsed type %A\n" t; *)
   bindOptDisj (btOpt "typ' 14" (typ')) t >>= 
    (function Inl t -> (* pr "Typ returning  %A\n" t;  *)preturn t
            | Inr t1 -> bindOpt (btOpt "->t, *t 15" arrowOrStarAndType) t1)) 
end

and typ' = fun s -> s |>
    let r1 = rangeOfPos s.Position in
begin
    arrowOrStarAndType
<|> (typArgs >>= (fun tl -> rhs |>> (fun r2 -> (fun t1 -> Type_app(t1, tl, union_ranges r1 r2)))))
end

and arrowOrStarAndType = fun s -> s |>
begin
   (arrowOrStar >>= (fun mkT -> 
    typ >>= (fun t2 -> rhs |>> (fun r -> (fun t1 -> mkT None t1 t2 r)))))
end

and typArgs : Parser<list<Sugar.typ>, 'a> = fun s -> s |>
begin
    (bt "typArgs 16.1" (typ1 >>= (fun t -> 
        (btOpt "more args 16.2" typArgs) |>> (function None -> [t] | Some ts -> t::ts))))
<|>
    (atomicExp1 >>= (fun e -> let t = Type_term_index(e, range_of_synexpr e) in
     (btOpt "more args 16.3" typArgs) |>> (function None -> [t] | Some ts -> t::ts)))
end

and noarrow_typ = fun s -> s |>
begin
   rhs >>= (fun r1 ->
   typ1 >>= (fun t -> 
   (btOpt "typArgs 17" typArgs) >>= (fun tlOpt -> rhs |>> fun r2 ->
    match tlOpt with 
        | None -> t
        | Some tl -> Type_app(t, tl, union_ranges r1 r2))))
end

//and noarrow_typ' = fun s -> s |>
//begin
//    (bt "noarrow_typ 18" noarrow_typ >>= (fun t2 -> rhs |>> (fun r -> (fun t1 -> Type_app(t1, flatten_tyapp t2, r)))))
//<|> (exp1 >>= (fun e -> rhs |>> (fun r -> (fun t -> Type_app(t, [Type_term_index(e, r)], r))))) 
//end


and tfun_binder = fun s -> s |>
begin
    (ident >>= (fun id -> rhs |>> (fun r -> Inl (id, Type_anon(r)))))
<|> (tvar >>= (fun tv -> rhs |>> (fun r -> Inr(tv, Kind_unknown))))
<|> (bt "value binder" 
        (LPAREN >>.
         ident >>= (fun id -> 
         COLON >>.
         typ >>= (fun t -> 
         RPAREN >>. preturn (Inl (id,t))))))
<|> (LPAREN >>.
     tvar >>= (fun tv -> 
     COLON_COLON >>.
     kind >>= (fun k -> 
     RPAREN >>. preturn (Inr (tv, k)))))
end 

and tfun_binders = fun s -> s |> 
    (sequence (wsUntil (firstIDENT <|> LPAREN)) tfun_binder)

//Left-factored formula language
//formula1 ::=
// | FORALL tfun_binders DOT formula
// | EXISTS tfun_binders DOT formula
// | NOT formula
// | LPAREN formula RPAREN
// | exp EQUALS exp
// | typ
//
//formula ::= 
// | formula1 formula'
// | formula1
//
//formula' ::=
// | AMP_AMP formula
// | BAR_BAR formula
// | RRARROW formula
// | IFF formula

and formula1 : Parser<Sugar.formula, 'a> = fun s -> s |> 
begin
   (forall >>= (fun isAffine -> rhs >>= (fun r1 ->
     bindersThenFormula >>= (fun (binders, pats, phi) -> rhs |>> (fun r2 ->
       let r = union_ranges r1 r2 in
       snd <| List.fold_right (fun binder (pats,out) -> match binder with 
                                 | Inr (tvar, k) -> [], Form_quant(Typar(tvar, Some k), out, r)
                                 | Inl (id,t) -> [], Form_all(id, t, out, r, pats, isAffine)) binders (pats, phi))))))
<|>
   (exists >>= (fun isAffine -> rhs >>= (fun r1 ->
     bindersThenFormula >>= (fun (binders, pats, phi) -> rhs |>> (fun r2 ->
       let r = union_ranges r1 r2 in
       snd <| List.fold_right (fun binder (pats, out) -> match binder with 
                                 | Inr (tvar, k) -> [], Form_quant(Typar(tvar, Some k), out, r)
                                 | Inl (id,t) -> [], Form_exists(id, t, out, r, pats, isAffine)) binders (pats, phi))))))
<|> (LBL >>. 
     STRING_BYTES >>= (fun s -> 
     rhs >>= (fun r -> 
     formula1 |>> (fun f -> Form_labeled(s, f, r)))))
<|>
   (NOT >>. rhs >>= (fun r1 ->
    formula1 >>= (fun phi -> rhs |>> (fun r2 -> 
        Form_not(phi, union_ranges r1 r2)))))
<|> 
   (LPAREN >>= (fun _ -> //pr "parsed LPAREN\n";
    formula >>= (fun phi -> 
    RPAREN >>= (fun _ -> rhs |>> (fun r ->  Form_paren(phi, r))))))
<|>
    (BAR >>= (fun _ -> rhs >>= (fun r1 ->
     formula >>= (fun phi -> rhs >>= (fun r2 ->
     BAR >>. preturn (Form_relational(phi, union_ranges r1 r2)))))))
<|> (IF >>= (fun _ -> rhs >>= (fun r1 -> 
     formula >>= (fun phi ->
     THEN >>. formula >>= (fun phi1 ->               
     ELSE >>. formula >>= (fun phi2 -> rhs |>> (fun r2 -> 
                             Form_ite(phi, phi1, phi2, union_ranges r1 r2))))))))
<|>
    (rhs >>= (fun r -> (* pr "Trying to parse atom at %s\n" (Range.string_of_range r); *)
     atom >>= (fun a -> rhs |>> (fun r -> Form_atom(a, r)))))

end

and forall = fun s -> s |>
begin
    (FORALL >>. preturn false)
<|> (FORALL_A >>. preturn true)
end

and exists = fun s -> s |>
begin
    (EXISTS_A >>. preturn true)
<|> (EXISTS >>. preturn false)
end

and atomEnd = fun s -> s |> 
    (peekIfNextTokenMsg (ws >>. (atom_infix))
       (fun str -> 
          pr "EQUALS matched ^%s...!\n" str;
          (peekIfNextTokenMsg (ws >>. RRARROW)
             (fun str -> pr "RRARROW matched ^%s...!\n" str; preturn ())
             (fun str -> pr "EQ but not RRARROW at ^%s...\natom end fails\n" str; perr "not atom end")))
       (fun str -> pr "EQUALS did not match ^%s...\natom end success\n" str; preturn ()))

and atom_infix = fun s -> s |> 
    begin 
      GREATER_OR_EQ  <|> LESS_OR_EQ  <|> LTGT <|> EQUALS <|> LESS <|> GREATER
    end

and parseOp r = function
  | "=" -> Const.eq_lid, true, (fun x -> x)
  | "<>" -> Const.eq_lid, true, (fun x -> Form_not(x, r))
  | "<" -> Const.lt_lid, false, (fun x -> x)
  | ">" -> Const.gt_lid, false, (fun x -> x)
  | "<=" -> Const.lte_lid, false, (fun x -> x)
  | ">=" -> Const.gte_lid, false, (fun x -> x) 

and parseOpForAtom = function
  | "=" -> Const.eq_lid, true
  | "<>" -> Const.neq_lid, true
  | "<" -> Const.lt_lid, false
  | ">" -> Const.gt_lid, false
  | "<=" -> Const.lte_lid, false
  | ">=" -> Const.gte_lid, false

and atom : Parser<Sugar.atom, 'a> = fun s -> s |>
begin 
   (bt "typ_19" typ) >>= (fun t -> preturn (Atom_pred t))
   (* (bt "typ 19" (typ >>= (fun t -> pr "Parsed a type %A\n" t;  *)
   (*                                 peekIfNextTokenMsg atomEnd *)
   (*                                      (fun str -> pr "atom ended at ^%s...\n" str; preturn (Atom_pred t)) *)
   (*                                      (fun str -> pr "atom not ended at ^%s...;backtracking!\n" str; perr "not a type")))) *)
<|>
   (fun s -> s |> ( (* pr "Trying equality ... \n";  *)
   (exp1 >>= (fun e1 -> rhs >>= (fun r1 ->
    atom_infix >>= (fun op -> rhs >>= (fun r -> 
    exp1 >>= (fun e2 -> rhs >>= (fun r2 -> 
          let oplid, needsTarg = parseOpForAtom op in 
          let args = [Type_term_index (e1, r1);
                      Type_term_index (e2, r2)] in 
          let r12 = union_ranges r1 r2 in
          let args = if needsTarg then Type_anon(r)::args else args in 
            preturn (Atom_pred(Type_app(Type_lid(oplid, r), args, r12))))))))))))
end
    
and formula : Parser<Sugar.formula, 'a> = fun s -> s |>
begin
   formula1 >>= (fun phi -> 
   (btOpt "formula' 20" formula') >>= (function 
                                         | None -> preturn phi
                                         | Some mkphi -> mkphi phi))
end

and formula' : Parser<Sugar.formula -> Parser<Sugar.formula, 'a>, 'a> = fun s -> s |>
begin
    (AMP_AMP >>. rhs >>= (fun r -> 
     formula |>> (fun phi' -> fun phi -> preturn (mkPrecedence phi Form_conj phi' r))))
<|>
    (BAR_BAR >>. rhs >>= (fun r -> 
     formula |>> (fun phi' -> fun phi -> preturn (mkPrecedence phi Form_disj phi' r))))
<|>
    (RRARROW >>.
     rhs >>= (fun r -> 
     formula |>> (fun phi' -> fun phi -> preturn (Form_impl(phi, phi', r)))))
<|>
    (LONG_RRARROW >>.
     rhs >>= (fun r -> 
     formula |>> (fun phi' -> fun phi -> preturn (Form_impl(phi, phi', r)))))
<|> 
    (IFF >>. 
     rhs >>= (fun r -> //pr "Parsed IFF\n";
     formula |>> (fun phi' -> fun phi -> preturn (Form_iff(phi, phi', r)))))
<|> 
    (LONG_IFF >>. 
     rhs >>= (fun r -> //pr "Parsed IFF\n";
     formula |>> (fun phi' -> fun phi -> preturn (Form_iff(phi, phi', r)))))
(* (Form_conj(Form_impl(phi, phi', r),  *)
(*                                                             Form_impl(phi', phi, r), r))))) *)
<|> (atom_infix >>= (fun op -> rhs >>= (fun r1 -> 
     exp1 >>= (fun e2 -> rhs >>= (fun r2 -> 
        let r = union_ranges r1 r2 in
        let v2 = Type_term_index(e2, r) in 
        let oplid, needsTarg, maybeneg = parseOp r op in 
        (btOpt "formula' 21" formula') |>> 
            (fun mkPhiOpt phi ->  (* grammar is ambiguous here. Predicates and constructore overlap. *)
               match unparen phi with        (* will be resolved during desugaring. *)
                 | Form_atom(Atom_pred v1, _) when isConstructorApp v1 -> 
                     let args = [v1;v2] in 
                     let args = if needsTarg then Type_anon(r)::args else args in 
                     let pred = Form_atom(Atom_pred(Type_app(Type_lid(oplid, r), args, r)), r) in 
                     let pred = maybeneg pred in 
                       (match mkPhiOpt with
                          | None -> preturn pred
                          | Some mkPhi -> mkPhi pred)
                 | xx -> perr (spr "Infix operators (=,<>,<,>,>=,<=) only apply to expressions; \
                                    here, got a formula and an expression.\n%A\n" xx)))))))

(* <|> (LTGT >>. rhs >>= (fun r1 ->  *)
(*      exp1 >>= (fun e2 -> rhs >>= (fun r2 -> let r = union_ranges r1 r2 in *)
(*     (btOpt "formula' 21" formula') |>> (fun mkPhiOpt phi ->  (\* grammar is ambiguous here. Predicates and constructore overlap. *\) *)
(*                                           match unparen phi with        (\* will be resolved during desugaring. *\) *)
(*                                             | Form_atom(Atom_pred t1, _) when isConstructorApp t1 ->  *)
(*                                                 let neqpred = Form_not(Form_atom(Atom_pred(mkEqTyp t1 (Type_term_index(e2, r)) r), r), r) in  *)
(*                                                   (match mkPhiOpt with *)
(*                                                      | None -> preturn neqpred *)
(*                                                      | Some mkPhi -> mkPhi neqpred) *)
(*                                             | xx -> perr (spr "Equality only applies to expressions; \ *)
(*                                                               here, equating a formula and an expression.\n%A\n" xx)))))) *)

end
     
and bindersThenFormula = fun s -> s |>
begin
    tfun_binders >>= (fun binders -> 
    DOT >>.
    (opt inst_pattern) >>= (fun pats -> 
    (formula) |>> (fun (phi:formula) -> 
                   let pats :pattern list = match pats with 
                     | None -> []
                     | Some p -> p in 
                      (binders, pats, phi))))
end

and inst_pattern = fun s -> s |>
begin
  LBRACE >>. COLON >>. PATTERN >>.
  (sequence SEMICOLON atom) >>= (fun ps -> 
  RBRACE >>. preturn ps)
end

//Left-factored kind language
//kind1 ::=
// | STAR
// | ident (* A E P *)
// | tyvar COLON_COLON kind RRARROW kind
// | ident COLON typ RRARROW kind
// | typ RRARROW kind
// | LPAREN kind RPAREN
//
//kind ::= 
// | kind1 
// | kind1 RRARROW kind

and kind1 = fun s -> s |>
begin
    baseKind
<|>
   (tvar >>= (fun tv -> rhs >>= (fun r ->
    ifNextToken COLON_COLON
        (fun _ -> kind1 >>= (fun k1 -> (* pr "Parsed %A :: %A\n" tv k1; *)
                  RRARROW >>.
                  kind |>> (fun k2 -> Kind_tcon(Some tv, k1, k2))))
        (prestore "not a tcon" s))))
<|> 
   (ident >>= (fun id ->
    ifNextToken (COLON >>. typ .>> RRARROW)
        (fun t -> kind |>> (fun k -> Kind_dcon(Some id, t, k)))
        (prestore "not a dependent dcon" s)))
<|>
   (bt "not dcon" 
      (typ >>= (fun t ->  (* pr "Parsed type %A\n" t; *) flush stdout;
       RRARROW >>.
      (kind |>> (fun k ->  Kind_dcon(None, t, k))))))
<|>
   (LPAREN >>. kind .>> RPAREN)
end

and kind = fun s -> s |>
begin
    kind1 >>= (fun k1 -> 
    btOpt "=> k 21" (RRARROW >>. kind) |>> (fun k2opt -> 
      match k2opt with 
        | None -> k1
        | Some k2 -> Kind_tcon(None, k1, k2)))
end

and baseKind = fun s -> s |>
begin
    (STAR >>. preturn Sugar.Kind_star)
<|> (IDENT >>= (fun i -> 
        match i with 
            | "A" -> preturn Sugar.Kind_affine
            | "E" -> preturn Sugar.Kind_erasable
            | "P" -> preturn Sugar.Kind_prop 
            | _ -> prestore "Unexpected base kind; expect {*, A, E, P, _}" s))
<|> (UNDERSCORE |>> (fun _ -> Sugar.Kind_unknown))
end 

(* Module-level definitions *)

let typeOrTermParWithAnnot = fun s -> s |>
begin
    ifNextToken tvar
        (fun tv -> COLON_COLON >>. kind |>> (fun k -> TyparDecl(Typar(tv, Some k))))
        (ident >>= (fun id -> 
         COLON >>. 
         typ |>> (fun t -> TermparDecl(id, t))))
end

let firstTpDecl = fun s -> s |> (QUOTE <|> (a2u firstIDENT) <|> (a2u LPAREN))
let typParamDecl = fun s -> s |> 
begin
    ((bt "tvar" tvar) |>> (fun tv -> TyparDecl(Typar(tv, None))))
<|> 
    ((bt "ident" ident) >>= (fun id -> rhs |>> fun r -> TermparDecl(id, Type_anon r)))
<|> 
    (LPAREN >>= (fun _ -> 
     typeOrTermParWithAnnot >>= (fun tpdecl -> 
     RPAREN >>. preturn tpdecl)))
end

let typParamDeclList = fun s -> s |> (seqBind (fun tpd -> 
                                               wsUntil firstTpDecl) typParamDecl)

let quantTypParams = fun s -> s |>
begin
    LESS >>.
    (sequence COMMA typParamDecl) >>= (fun tpdecls -> 
    GREATER >>. 
    let allTypes = List.for_all (function TermparDecl _ -> false | _ -> true) tpdecls in
    if allTypes 
    then preturn (List.map (function TyparDecl(t) -> t) tpdecls)
    else perr "Expected only type parameters; found a term parameter")
end

(* Type definitions *)
let typeNameTyparsAndKind = fun s -> s |>
begin
   path >>= (fun lid -> rhs >>= fun r1 -> 
   btOptList "tpdeclList 22" typParamDeclList >>= (fun tps -> 
   btOpt "::k 23" (COLON_COLON >>. kind) |>> (fun kopt -> 
    let k = match kopt with None -> Sugar.Kind_star | Some k -> k in 
    Tycon(lid, k, tps, false, r1))))
  
end

let recordFieldDecl = fun s -> s |>
begin
    ident >>= (fun id -> rhs >>= fun r1 -> 
    COLON >>. 
    typ >>= (fun t -> rhs |>> fun r2 -> Field(id, t, union_ranges r1 r2)))
end

let recordFieldDeclList = fun s -> s |> (sequence SEMICOLON recordFieldDecl)

let recordTypeDefn = fun s -> s |>
begin
    LBRACE >>. rhs >>= (fun r -> 
    recordFieldDeclList >>= (fun fdl -> 
    RBRACE >>.
        preturn (TyconCore_recd(fdl, r))))
end

let variantCaseDecl = fun s -> s|>
begin
    ident >>= (fun id -> rhs >>= (fun r -> //pr "Parsed identifier: %A\n" id;
    COLON >>. 
    typ |>> (fun t -> 
        UnionConstr(id, ConstrType t, r))))
end

let variantCaseDecls = fun s -> s |> (seqBind (fun vcd -> (* pr "Parsed vcd: %A\n" vcd; *) BAR) variantCaseDecl)

let variantTypeDefn = fun s -> s |>
begin
    (btOpt "| 24" BAR) >>. variantCaseDecls >>= (fun constrs -> 
        rhs |>> fun r -> 
        TyconCore_union(constrs, r))
end

let tyconDefnRhs = fun s -> s |>
begin
    (bt "typ 25" typ >>= (fun t -> rhs |>> fun r -> TyconCore_abbrev(t, r)))
<|>
    (bt "recordTypeDefn 26" recordTypeDefn)
<|> 
    variantTypeDefn
end

let tyconDefn = fun s -> s |>
begin
   typeNameTyparsAndKind >>= (fun tci -> rhs >>= (fun r1 -> 
   ifNextToken EQUALS 
    (fun _ -> tyconDefnRhs |>> (fun tcdef -> TyconDefn(tci, tcdef, r1)))
    (preturn (TyconDefn(tci, TyconCore_repr_hidden(r1), r1)))))
end

let tyconDefnList = fun s -> s |> (sequence AND tyconDefn)

(* Value declarations *)
let valDecl = fun s -> s |>
begin
    ident >>= (fun name -> 
    btOpt "valDecl tparams 27" quantTypParams >>= (fun params -> 
    COLON >>.
    typ >>= (fun t -> rhs |>> fun r -> 
        match params with 
            | None -> (name, t)
            | Some pars -> (name, Type_qtyp(pars, t, r)))))
end

let assumeQual = fun s -> s |>
begin
  (* (opt GHOST) >>. *)
    ((ASSUME >>. preturn Assumption)
 <|> (DEFINE >>. preturn Definition))
end

(* Module definitions top level *)
let moduleDefn = fun s -> s |>
begin
    (OPEN >>. 
     path >>= (fun lid -> rhs |>> (fun r -> Def_open(lid, r))))
<|> ((bt "extern reference" (EXTERN >>. REFERENCE)) >>.
     ident >>= (fun id -> rhs >>= (fun r1 -> 
     (recordExp r1 value) >>= (fun expr -> rhs >>= (fun pos -> 
      match Sugar.exprRecdAsExternRefOpt pos expr with 
        | Some eref -> preturn (Def_extern_ref(id, eref, union_ranges r1 pos))
        | None -> perr (spr "Malformed extern reference at %s" (Range.string_of_range pos)))))))
<|> 
   (EXTERN >>. rhs >>= (fun r1 -> 
     ident >>= (fun id -> 
     ifNextToken TYPE 
        (fun _ -> tyconDefn >>= (fun td -> rhs |>> (fun r2 -> Def_extern_typ(ExternRefId id, td, union_ranges r1 r2))))
        (VAL >>. valDecl >>= (fun (v_id, t) -> rhs |>> (fun r2 -> Def_extern_val(ExternRefId id, v_id, t, union_ranges r1 r2)))))))
<|> 
   (btOpt "access qual 28" qual >>= (fun qopt -> rhs >>= (fun r1 -> 
     let isPrivate = match qopt with None -> false | _ -> true in 
     ifNextToken typeWithMeta
        (fun meta -> 
            tyconDefn >>= (fun td ->
            btOptList "AND tds 29" (AND >>. tyconDefnList) >>= (fun tds -> rhs |>> fun r2 -> 
                Def_tycon(td::tds, false, isPrivate, meta, Range.union_ranges r1 r2))))
    (ifNextToken VAL
       (fun _ -> valDecl >>= fun (v_id, t) -> rhs |>> fun r2 -> Def_val(v_id, t, Range.union_ranges r1 r2))
       (assumeQual >>= (fun atag -> rhs >>= (fun r1 -> 
        btOpt "id: 30" (ident_colon) >>= (fun id_opt -> 
        formula >>= (fun phi -> rhs |>> (fun r2 -> Def_assume(id_opt, phi, atag, union_ranges r1 r2)))))))))))
<|>
   (LOGIC >>. rhs >>= (fun r1 -> VAL >>. 
     ident >>= (fun id -> 
     COLON >>. 
     typ >>= (fun t -> rhs |>> (fun r2 -> Def_logic_function(id, t, union_ranges r1 r2))))))
<|>
   (rhs >>= fun r1 -> 
    letBindings >>= (fun bindings -> 
    rhs |>> fun r2 -> mkDefnBindings (union_ranges r1 r2) bindings))      
end

let mainExpr = fun s -> s |>
    (rhs >>= (fun r1 -> 
     SEMICOLON_SEMICOLON >>.
     exp >>= (fun e -> rhs |>> (fun r2 -> 
      Def_expr(e, union_ranges r1 r2)))))

let firstModuleDefn = fun s -> s |> 
   (OPEN <|> EXTERN <|> PRIVATE <|> TYPE <|> 
    PROP  <|> VAL <|> ASSUME <|> DEFINE <|> LET <|> GHOST <|> LOGIC)
let moduleDefns = fun s -> s |> (sequenceMod (wsUntil firstModuleDefn) moduleDefn)
(* let moduleDefns = fun s -> s |> (seqBind (fun md -> (\* pr "Parsed: %A\n" md; *\) wsUntil firstModuleDefn) moduleDefn) *)

let moduleDefnsOrExpr : Parser<ModuleImplDecls,'a> = fun s -> s |>
begin
    moduleDefns >>= (fun decls -> 
   (btOpt "main" mainExpr) |>> (function None -> decls | Some main -> decls@[main]))
end 

let amodule = fun s -> s |> 
begin
    MODULE >>. 
    path >>= (fun lid -> rhs >>= (fun p1 ->  
    (btOpt ": Ext" (COLON >>. path)) >>= (fun extendsOpt -> 
    moduleDefnsOrExpr >>= (fun defs -> 
    btOpt "end 31" END >>. rhs >>= (fun p2 -> 
      let r = Range.union_ranges p1 p2 in 
      preturn (NamedTopModuleImpl(ModuleOrNamespaceImpl(lid, extendsOpt, defs, r))))))))
end

let rec module_list : Parser<list<ParsedImplFileFragment>, 'a> = fun s -> s |>
begin
  (ws >>. amodule >>= (fun m -> 
                         peekIfNextToken MODULE 
                           (module_list |>> (fun ms -> m::ms))
                           (EOF >>. preturn [m])))
end

let parse_verbose (filename:string) = raise (Failure "verbose syntax is no longer supported")

let pragma : Parser<pragma, 'a> = fun s -> s |> 
begin
 ((LIGHT >>. (opt STRING_BYTES)) >>= (fun x -> preturn PRAGMA_LIGHT))
<|>
 (MONADIC >>. 
  LPAREN >>. 
  (sequence COMMA typ) >>= (fun tl -> 
  RPAREN >>= (fun _ -> 
                match tl with 
                  | [mtyp; mrettx; mbindtx] -> preturn (PRAGMA_MONADIC(mtyp, mrettx, mbindtx))
                  | _ -> perr (spr "#monadic pragma expects three arguments; got %d" (List.length tl)))))
end

let pragmas : Parser<list<pragma>, 'a> = 
  fun s -> sequence (wsUntil POUND) pragma s

let parse_pragmas : Parser<ParsedImplFile, 'a> = fun s -> s |>
begin
  (opt pragmas) >>= (fun psopt -> 
    let _ = match psopt with 
      | None -> monadic_mode := false;
      | Some l -> monadic_mode := List.exists (function MONADIC -> true | _ -> false) l in 
    module_list >>= (fun x -> 
      match psopt with
        | None -> preturn (ParsedImplFile x)
        | Some ps -> preturn (ParsedImplFileWithPragmas(x,ps))))
end

let parse filenameOrSource = 
  let fileAsString, fn = match filenameOrSource with 
    | Inr s -> s, "<input>"
    | Inl fn -> 
      let stream = new System.IO.FileStream(fn, System.IO.FileMode.Open, System.IO.FileAccess.Read) in
      let reader = new System.IO.StreamReader(stream) in
      let fileAsString = reader.ReadToEnd() in
      stream.Close();fileAsString,fn in 
  if fileAsString.StartsWith("#light") || !Options.light
  then 
    let _ = pr "running light parser on %s\n" fn in
    let result = runParserOnString parse_pragmas () fn fileAsString in
    match result with 
      | Success(sugar, _, _) -> sugar
      | _ -> raise (Failure (spr "Parsing failed!\n%A" result))
  else 
    parse_verbose fn 

(* let parse fn =  *)
(*   let stream = new System.IO.FileStream(fn, System.IO.FileMode.Open) in *)
(*   let reader = new System.IO.StreamReader(stream) in *)
(*   let line = reader.ReadLine() in *)
(*   stream.Close();  *)
(*   if line = "#light"  *)
(*   then  *)
(*     let _ = pr "running light parser\n" in *)
(*     let result = runParserOnFile parse_light () fn System.Text.Encoding.Default in *)
(*         match result with  *)
(*         | Success(sugar, _, _) -> sugar *)
(*         | _ -> raise (Failure (spr "Parsing failed!\n%A" result)) *)
(*   else  *)
(* //    let _ = pr "Read first line <%s>\n" line in *)
(*       parse_verbose fn  *)
