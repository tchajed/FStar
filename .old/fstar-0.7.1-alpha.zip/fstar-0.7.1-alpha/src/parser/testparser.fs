#light "off"
module Microsoft.FStar.TestParser

open Microsoft.FStar
open Microsoft.FStar.Lexhelp

(* let parse (filename:string) =  *)
(*   let trim(filename:string) = *)
(*     let pos = filename.LastIndexOf "/" in *)
(*       if pos = -1 then filename *)
(*       else  filename.Substring (pos + 1) in *)
(*   let lb = (Microsoft.FSharp.Text.Lexing.LexBuffer<char>.FromTextReader(new System.IO.StreamReader(filename))) in *)
(*     lb.StartPos <- {lb.StartPos with pos_fname = (trim filename)}; *)
(*     let ast =  *)
(*       try ParseFStar.moduleList (LexFStar.token (mkLexargs ("", filename, [], (new LightSyntaxStatus(false)),  (new LexResourceManager()), lb *)
(*       with e -> *)
(*         let pos = lb.EndPos in *)
(*           Util.pr "ERROR: Syntax error near line %d, character %d in file %s\n" (pos.pos_lnum+1) (pos.pos_cnum - pos.pos_bol) filename; *)
(*           exit 0 in *)
(*       ast  *)

let parse (filename:string) = 
  Sugar.warningHandler := (function 
    | Lexhelp.ReservedKeyword(m,s) -> Util.pr "%s:%s" (Range.string_of_range s) m
    | e -> Util.pr "Warning: %A\n" e);
  let lexbuf = Microsoft.FSharp.Text.Lexing.LexBuffer<char>.FromTextReader(new System.IO.StreamReader(filename)) in
  resetLexbufPos filename lexbuf;
  let lightSyntaxStatus = LightSyntaxStatus (false) in
  let warnOnFirstToken = false in
  let lexargs = mkLexargs ((fun () -> "."), filename, [], lightSyntaxStatus,(new Lexhelp.LexResourceManager()), ref []) in
  let lexer = LexFStar.token lexargs true in 
    try
      let ast = ParseFStar.file lexer lexbuf in ParseAST.desugar_file ast 
        (* Util.pr "%A" ast *)
    with 
      | Sugar.Error(msg, r) when (Util.pr "ERROR %s: %s\n" (Range.string_of_range r) msg; false) -> 
          Util.pr "ERROR %s: %s\n" (Range.string_of_range r) msg;
          exit 0 
      (* | e ->  *)
      (*     let pos = lexbuf.EndPos in *)
      (*       Util.pr "ERROR: Syntax error near line %d, character %d in file %s\n" (pos.pos_lnum+1) (pos.pos_cnum - pos.pos_bol) filename; *)
      (*       exit 0  *)
  
let _ = 
  let _ = Util.pr "Trying to parse %s\n" (Sys.argv.(1)) in 
    parse Sys.argv.(1)
        
  
