#light "off"
module Microsoft.FStar.Parse

open Microsoft.FStar
open Microsoft.FStar.Lexhelp
open Util

let print_error msg r = 
  Printf.printf "ERROR %s: %s\n" (Range.string_of_range r) msg

let parse fn =
  Sugar.warningHandler := (function 
    | Lexhelp.ReservedKeyword(m,s) -> Printf.printf "%s:%s" (Range.string_of_range s) m
    | e -> Printf.printf "Warning: %A\n" e);

  let filename,sr = match fn with 
    | Inl (filename:string) -> filename, new System.IO.StreamReader(filename) :> System.IO.TextReader
    | Inr (s:string) -> "<input>", new System.IO.StringReader(s) :> System.IO.TextReader in
  let lexbuf = Microsoft.FSharp.Text.Lexing.LexBuffer<char>.FromTextReader(sr) in
  resetLexbufPos filename lexbuf;
  let lightSyntaxStatus = LightSyntaxStatus (false) in
  let warnOnFirstToken = false in
  let lexargs = mkLexargs ((fun () -> "."), filename, [], lightSyntaxStatus,(new Lexhelp.LexResourceManager()), ref []) in
  let lexer = LexFStar.token lexargs true in 
    try
      let ast = ParseFStar.file lexer lexbuf in 
#if TEST
      if filename.StartsWith("test.") then 
        (Printf.printf "%A\n**********************\n" ast);
#endif
      let sugar = ParseAST.desugar_file ast in 
      #if TEST
          (if filename.StartsWith("test.") then 
              Printf.printf "%A\n" sugar);
      #endif
        sugar
    with 
      | Sugar.Error(msg, r) -> 
        print_error msg r;
        exit 0 
      | e ->
        let pos = lexbuf.EndPos in
        Printf.printf "ERROR: Syntax error near line %d, character %d in file %s\n" (pos.pos_lnum) (pos.pos_cnum - pos.pos_bol) filename;
        exit 0

#if TEST
let _ =
  Sys.argv |> Array.iteri (fun i file ->
                             if i = 0 then ()
                             else
                               let _ = Printf.printf "Trying to parse %s\n" (Sys.argv.(1)) in
                                 ignore (parse (Util.Inl file)))

#endif
