#light "off"

module Microsoft.FStar.Pretty
open Microsoft.FStar
open Absyn
open Util
open Options
open Const

exception PrettyBad
let verb = ref false
let pr = Printf.printf
let spr = Printf.sprintf

let is_marked e = ((e.p < (int64 0)) && (e.p > (int64 -1500)))

let strLanguage = function
    FSharp -> "F#"
  | CSharp -> "C#"
  | Fine -> "Fine"
  | F7 -> "F7"
  | FStar -> "F*"
let rec unrefine t = match t.v with 
  | Typ_refine(x, t, _, _) -> unrefine t
  | _ -> t 
let rec unascribe e = match e.v with
  | Exp_ascribed (e, _, _) -> unascribe e
  | _ -> e
let sli (x:lident) =  x.str
let str_of_lident (x:lident) = match x.lid with 
  | m::rest when m.idText = "Prims" -> String.concat "." (rest |> List.map (fun x -> x.idText)) 
  | _ -> sli x
let strBvd bvd =
  if !Options.print_real_names then bvd.realname.idText else bvd.ppname.idText

let flattenTypAppsAndDeps : typ -> typ * (Disj<typ,exp>) list =
  let rec aux acc t = let t = unrefine t in match t.v with
    | Typ_dep(t1,e) -> aux (Inr e::acc) t1
    | Typ_app(t1,t2) -> aux (Inl t2::acc) t1
    | _              -> t, acc in
    (fun t -> aux [] t)

let normalize t =
  let t = compress t in
    (* if !Options.print_real_names *)
    (* then t *)
    (* else *) whnf t

let rec strTypParen parenFlag affineArrow tt =
  let paren result = if parenFlag then spr "(%s)" result else result in
  let arrow = if affineArrow then ">>" else "->" in
  let tt = normalize tt in
    match tt.v with
  | Typ_record(_, Some t) -> strTyp t
  | Typ_record(l, None) ->
      let sl = List.map (fun (li,t) -> spr "%s:%s" (str_of_lident li) (strTyp t)) l in
      spr "{ %s }" (String.concat "; " sl)
  | Typ_dtuple [(nopt, t1); (_,t2)] ->
      let s1 = match nopt with
          None -> strTyp t1
        | Some bvd -> spr "%s:%s" (strBvd bvd) (strTyp t1) in
        spr "(%s * %s)" s1 (strTyp t2)
  | Typ_refine(bvd,t,f,ghost) -> 
      if ghost 
      then spr "%s:%s{%s}" (strBvd bvd) (strTyp t) (strTypAsFormula f) 
      else spr "{%s:%s | %s}" (strBvd bvd) (strTyp t) (strTypAsFormula f) 
        (* let r = bvd.ppname.idRange in *)
        (*     let ident = Sugar.ident("this", r) in *)
        (*     let x = mkbvd (ident, ident) in *)
        (*     let newf = freshen_type f [Inr (bvd, x)] in *)
        (*       if ghost  *)
        (*       then spr "this:%s{%s}" (strTyp t) (strTypAsFormula newf)  *)
        (*       else spr "{this:%s | %s}" (strTyp t) (strTypAsFormula newf) *)
  | Typ_affine ({v=Typ_univ _} as t) 
  | Typ_affine ({v=Typ_fun _} as t) -> 
      strTypParen parenFlag true t
  | Typ_affine t -> 
      paren (spr "!(%s)" (strTypParen false true t))
  | Typ_univ(bvd,k,[],t) -> 
      let result = spr "%s::%s %s %s" 
        (strBvd bvd)
        (strKind k)
        arrow
        (strTyp t) in 
        paren result
  | Typ_univ(bvd,k,formulas,t) -> 
      let result = spr "%s::%s (%s) ==> %s %s" 
        (strBvd bvd)
        (strKind k)
        (formulas |> List.map strTyp |> String.concat " AND")
        arrow
        (strTyp t) in 
        paren result
  | Typ_btvar(bv) -> strBtvar bv 
  | Typ_const(x, _) -> str_of_lident x.v
  | Typ_fun(None, t1,t2) -> paren (spr "%s %s %s" (strTypParen true false t1) arrow (strTyp t2))
  | Typ_fun(Some bvd, {v=Typ_refine(y, t1, phi, _)},t2) -> 
      let phi = substitute_exp_l phi [y, bvd_to_exp bvd t1] in
        paren (spr "%s:%s{%s} %s %s" (strBvd bvd) (strTypParen true false t1) (strTyp phi) arrow (strTyp t2))
  | Typ_fun(Some bvd, t1,t2) -> 
      paren (spr "%s:%s %s %s" (strBvd bvd) (strTypParen true false t1) arrow (strTyp t2))
  | Typ_uvar(u,_) -> spr "'_U%d" (Unionfind.uvar_id u) 
  (* | Typ_uvar(u,_) -> spr "('_u%d :: %s)" (Unionfind.uvar_id u) (strKind tt.sort) *)
  | Typ_lam(bvd,t,t') when !verb -> paren (spr "(fun (%s:%s) => %s)" (strBvd bvd) (strTyp t) (strTyp t'))
  | Typ_tlam(bvd,k,t) when !verb -> paren (spr "(fun ('%s::%s) => %s)" (strBvd bvd) (strKind k) (strTyp t))
  | Typ_lam(bvd,t,t') -> paren (spr "(fun %s => %s)" (strBvd bvd)  (strTyp t'))
  | Typ_tlam(bvd,k,t) -> paren (spr "(tfun %s => %s)" (strBvd bvd) (strTyp t))
  | Typ_app _
  | Typ_dep _ -> 
      let t, args = flattenTypAppsAndDeps tt in 
      let result = spr "%s %s" (strTyp t) (String.concat " " (List.map (function 
                                                                          | Inl t -> strTypParen true false t
                                                                          | Inr e -> strExp e) args)) in
        paren result
  | Typ_ascribed(t, k) -> spr "(%s :: %s)" (strTyp t) (strKind k)
  | Typ_unknown -> "Typ_unknown" 
  | Typ_meta(Meta_pattern(t, ps)) -> 
      spr "{:pattern %s} %s" (String.concat ", " (ps |> List.map (function Inl t -> strTyp t | Inr e -> strExp e))) (strTyp t)
  | Typ_meta(Meta_alpha t) -> spr "(Meta_alpha %s)" (strTyp t)
  | Typ_meta (Meta_PrePost(pre,t,post)) -> 
      spr "Meta_PrePost(%s, %s, %s)" (strTyp pre) (strTyp t) (strTyp post)
  | Typ_meta (Meta_cases tl) -> 
      spr "(Cases [%s])" (String.concat ";\n" (List.map strTypAsFormula tl))
  | Typ_meta (Meta_tid i) -> 
      spr "(Meta_tid %d)" i
  | Typ_meta (Meta_named(s,t)) -> 
      spr "(Meta_named \"%s\" %s)" s (strTyp t)
  | _ -> "UNKNOWN TYPE"

and strTyp t = strTypParen false false t

and strTypAsFormula f =
  let is_constructor t lid = match t.v with
    | Typ_const(tc, _) -> str_of_lident tc.v = str_of_lident lid
    | _ -> false in
  let strip_pf_typ t = match t.v with
    | Typ_app(tc, t') when is_constructor tc Const.pf_lid -> t' 
        (*  || *)
        (* is_constructor tc Const.e2p_lid) *)
    | _ -> t in
  let rec collect_u_quants out t = 
    let t' = strip_pf_typ t in
      match (normalize t') with 
        | {v = Typ_fun(Some x, t1, t2)} -> collect_u_quants ((x, t1)::out) t2
        | t' -> 
            (match flattenTypAppsAndDeps t' with 
               | {v=Typ_const(tc,_)}, [Inl t1; Inl {v=Typ_lam(x, _, t2)}] when Const.is_forall tc.v -> 
                   collect_u_quants ((x, t1)::out) t2
               | _ -> List.rev out, t) in
  let rec collect_e_quants out t = 
    let t' = strip_pf_typ t in
      match t'.v with 
        | Typ_dtuple([(Some x, t1); (_, t2)]) -> collect_e_quants ((x, t1)::out) t2
        | _ -> List.rev out, t in
  let rec try_split f (lid, arity) = match f.v, arity with 
    | Typ_app(t1, t2), 1 -> if is_constructor t1 lid then Some (lid, [Inl t2]) else None
    | Typ_dep(t1, e), 1 ->  if is_constructor t1 lid then Some (lid, [Inr e]) else None
    | Typ_app(t1, t2), n  when n>1-> 
        (match try_split t1 (lid, (n-1)) with 
           | Some (lid, args) -> Some (lid, args@[Inl t2])
           | _ -> None)
    | Typ_dep(t1, e), n when n>1 -> 
        (match try_split t1 (lid, (n-1)) with 
           | Some (lid, args) -> Some (lid, args@[Inr e])
           | _ -> None) 
    | _ -> None in
  let rec try_split_some f = function
    | arg::tl -> (match try_split f arg with 
                    | None -> try_split_some f tl 
                    | Some x -> Some x)
    | _ -> None in 
  let strConnective a = 
    if a = and_lid then "&&\n"
    else if a = or_lid then "||\n\t"
    else if a = not_lid then "not"
    else if a = implies_lid then "\n==>\n\t"
    else if a = iff_lid then "<==>\n\t"
    else if a = eq_lid then "=" 
    else "--unexpected connective--" in
  let format_transformer t = 
    let rec body out t1 = match (normalize t1) with 
      | {v=Typ_lam(x, _, t)} -> body (Inr x::out) t
      | {v=Typ_tlam(a, _, t)} -> body (Inl a::out) t
      | t -> List.rev out, t in 
    let args, body = body [] t in 
      match args with 
        | [] -> (strTypAsFormula body) 
        | _ -> spr "(fun %s => %s)" (String.concat " " (List.map (function Inl x -> strBvd x | Inr x -> strBvd x) args)) (strTypAsFormula body) in
  let rec is_formula_kind k = match k(* .u *) with
    | Kind_unknown 
    | Kind_star 
    | Kind_affine -> false
    | Kind_prop
    | Kind_erasable -> true
    | Kind_dcon(_, _, k)
    | Kind_tcon(_, _, k) -> is_formula_kind k 
    | _ -> pr "Unexpected kind %A" k; raise Impos in 
  let format_connective = function 
    | (a, [Inl t1]) when Sugar.lid_equals a js_function_lid ->
        spr "(Function %s)" (format_transformer t1)
    | (a, [Inl t1; Inl t2]) when Sugar.lid_equals a Const.eqTyp_lid -> spr "(EqTyp (%s) %s)" (strTypAsFormula t1) (strTypAsFormula t2)
    | (a, [Inl t1; Inl t2]) -> spr "((%s) %s (%s))" (strTypAsFormula t1) (strConnective a) (strTypAsFormula t2)
    | (a, [Inl t1]) -> spr "%s(%s)" (strConnective a) (strTypAsFormula t1)
    | (a, [Inr e1; Inr e2]) -> spr "(%s) %s (%s)" (strExp (unascribe e1)) (strConnective a) (strExp (unascribe e2))
    | (a, [Inl _; Inr e1; Inr e2]) -> spr "(%s) %s (%s)" (strExp (unascribe e1)) (strConnective a) (strExp (unascribe e2))
    | _ -> spr "--unexpected formula--" in
  let flattenTypDeps : typ -> typ * exp list =
    let rec aux acc t = let t = unrefine t in match t.v with
      | Typ_dep(t1,e) -> aux (e::acc) t1
      | _              -> t, acc in
      (fun t -> aux [] t) in
  let flattenTypApps : typ -> typ list =
    let rec aux acc t = let t = unrefine t in match t.v with
      | Typ_app(t1,t2) -> aux (t2::acc) t1
      | _              -> t::acc in
      (fun t -> aux [] t) in
  let f = normalize f in 
  let f = strip_pf_typ f in
    match f.v with 
      | Typ_fun _  -> 
          let quants, t2 = collect_u_quants [] f in 
          let qstr = String.concat " " (List.map (fun (x,t1) -> spr "(%s:%s)" ((pp_name x).idText) (strTyp t1)) quants) in
            spr "forall %s.\n %s" qstr (strTypAsFormula t2)
      | Typ_dtuple _ -> 
          let quants, t2 = collect_e_quants [] f in 
          let qstr = String.concat " " (List.map (fun (x,t1) -> spr "(%s:%s)" ((pp_name x).idText) (strTyp t1)) quants) in
            spr "exists %s.\n %s" qstr (strTypAsFormula t2)
      | Typ_lam _
      | Typ_tlam _ when is_formula_kind f.sort -> format_transformer f
      | _ -> 
          match try_split_some f [(and_lid, 2);(or_lid, 2);(not_lid, 1);(implies_lid, 2);(iff_lid, 2);(eq_lid, 3);(js_function_lid, 1);(eqTyp_lid, 2)] with 
            | Some (lid, args) -> 
                if lid = and_lid then 
                  let [Inl arg1;Inl arg2] = args in 
                    match (try_split (strip_pf_typ arg1) (implies_lid, 2)), (try_split (strip_pf_typ arg2) (implies_lid, 2)) with 
                      | Some (_, [Inl lhs; Inl rhs]), Some(_, [Inl rhs'; Inl lhs']) -> 
                          let lhs = strTypAsFormula lhs in 
                          let lhs' = strTypAsFormula lhs' in
                          let rhs = strTypAsFormula rhs in
                          let rhs' = strTypAsFormula rhs' in
                            if (lhs=lhs' && rhs=rhs') then spr "(%s) <=> (%s)" lhs rhs 
                            else format_connective (lid, args)
                      | _ -> format_connective (lid, args)
                else format_connective (lid, args)
            | None -> 
                (match flattenTypAppsAndDeps f with 
                   | {v=Typ_const(tc,_)}, _  when Const.is_forall tc.v -> 
                       let quants, t2 = collect_u_quants [] f in 
                       let qstr = String.concat " " (List.map (fun (x,t1) -> spr "%s" (strBvd x)) quants) in
                         spr "(forall %s.\n %s)" qstr (strTypAsFormula t2)
                   | {v=Typ_const(tc,_)}, [Inl {v=Typ_tlam(tx, _, body)}]  when Sugar.lid_equals tc.v Const.exists_tx_lid -> 
                       spr "(existsTx %s.\n %s)" (strBvd tx) (strTypAsFormula body)
                   | {v=Typ_const(tc,_)}, [Inl t]  when Sugar.lid_equals tc.v Const.tag_lid -> 
                       (match flattenTypAppsAndDeps t with 
                          | tvar, [Inr arg1; Inr arg2; Inl post; Inr heap] -> 
                              spr "(Tag (%s %s %s %s %s))" (strTyp tvar) (strExp arg1) (strExp arg2) (format_transformer post) (strExp heap)
                          | _ -> spr "(Tag (%s))" (strTypAsFormula t))
                   | prop, args -> 
                       let prop_s = strTyp prop in
                         (match args with
                            | [] -> prop_s
                            | _ ->
                                let rec omit_leading_targs = function  
                                  | Inl t::rest -> omit_leading_targs rest 
                                  | _ -> args in 
                                  spr "%s %s" prop_s (String.concat " " (List.filter
                                                                           (fun x -> x <> "")
                                                                           (List.map (function 
                                                                                        | Inl t when is_formula_kind t.sort -> strTypAsFormula t
                                                                                        | Inl t -> strTypParen true false t  
                                                                                        | Inr e -> strExp (unascribe e)) args)))))
                  
and strTypsAsFormulas fs = 
  String.concat ", " (List.map (fun f -> strTypAsFormula f) fs)

and freshen_type t benv : typ = freshen_bvars_typ None false t benv 
and strEv = function
  | [] -> ""
  | ev -> spr "{%s}" (String.concat ";" (List.map (function Inl _ -> "ignoring type evidence" | Inr (e, e') -> spr "%s=%s" (strExp (unascribe e)) (strExp (unascribe e'))) ev))
  | ev -> "ignoring type evidence"
and strExp' e = 
  let needs_paren e = match e.v with 
    | Exp_bot
    | Exp_constant _
    | Exp_bvar _
    | Exp_fvar _ 
    | Exp_constr_app _ ->  false
    | _ -> true in
  let strLetHelp (x,t,e) = 
    let t = match t.v with Typ_unknown -> "" | _ -> spr ": %s" (strTyp t) in 
      spr "%s %s = %s" (strBvd x) t (strExp e) in
  let e = unascribe e in 
    match e.v with
  | Exp_bvar(x) -> strBvar x
  | Exp_fvar(x, _) -> spr "%s" (str_of_lident x.v)
  | Exp_app(e1,e2) when needs_paren e2 -> spr "%s (%s)" (strExp e1) (strExp e2)
  | Exp_app(e1,e2) -> spr "%s %s" (strExp e1) (strExp e2)
  | Exp_tabs(bvd, k, _, e) -> spr "(fun (%s::%s) -> %s)"  (strBvd bvd) (strKind k) (strExp e)
  | Exp_tapp (e, t) -> 
      let rec collect_typs out e = match e.v with 
        | Exp_tapp(e, t) -> collect_typs (t::out) e
        | _ -> e, out in
      let e, ts = collect_typs [t] e in 
        spr "%s<%s>" (strExp e) (String.concat ",\n " (List.map strTyp ts))
  | Exp_match (e, branches, def) -> 
      let strBranch (Pat_variant(lid, tl, _, xl, _), exp) = 
        spr "\n\t| (%s <%s> %s) -> %s" 
          (Sugar.text_of_lid lid) 
          (String.concat ", " (List.map strTyp tl))
          (String.concat " " (List.map strBvar xl)) (strExp exp) in
      let brstr = String.concat " " (List.map strBranch branches) in
        spr "(match %s with %s \n | _ -> %s)" (strExp e) brstr (strExp def)
  | Exp_cond (e1, e2, e3) -> 
      spr "if %s then %s \n else %s" (strExp e1) (strExp e2) (strExp e3)
  | Exp_recd(_, _, _, l) ->
      let l2 = List.map (fun (fn,e) -> spr "%s=%s" (str_of_lident fn) (strExp e)) l in
      spr "{ %s }" (String.concat "; " l2)
  | Exp_proj(e,fn) -> spr "(%s).%s" (strExp e) (str_of_lident fn)
  | Exp_ascribed(e,t,ev) ->
      let ev_s = (let ev_s = strEv ev in if ev_s = "" then "" else spr " %s" ev_s) in
        spr "((%s) : %s%s)" (strExp e) (strTyp t) ev_s
  | Exp_constr_app(dc,[], _, []) -> str_of_lident dc.v
  | Exp_constr_app(dc,ts,_,es) -> 
      let s1 = str_of_lident dc.v in
      let s2 = String.concat ", " (List.map strTyp ts) in
      let s3 = String.concat " " (List.map (fun e -> if needs_paren e then spr "(%s)" (strExp e) else strExp e) es) in
      let s2spacedbracketed = if s2 = "" then "" else spr " <%s>" s2 in
      (* let s2spacedbracketed = if List.length ts = 0 then "" else "<_>" in *)
      let s3spaced = if s3 = "" then "" else spr " %s" s3 in
        spr "(%s%s%s)" s1 s2spacedbracketed s3spaced
          (*         spr "(%s %s)" s1 s3 *)
  | Exp_primop(op, el) -> 
      spr "%s(%s)" op.idText (String.concat ", " (List.map strExp  el))
  | Exp_let(false,[x,t,e1],e2) ->
      spr "\nlet %s in\n%s" (strLetHelp (x,t,e1)) (strExp e2)
  | Exp_let(true,lbs,e) ->
      let hd::tl = List.map strLetHelp lbs in 
      let tl = String.concat "\nand " tl in 
        spr "let rec %s\n%s in\n%s" hd tl (strExp e)
  | Exp_abs(bvd,{v=Typ_unknown},e) -> spr "(fun %s -> %s)" (strBvd bvd) (strExp e)
  | Exp_abs(bvd,t,e) -> spr "(fun (%s:%s) -> %s)" (strBvd bvd) (strTyp t) (strExp e)
  | Exp_constant(Sugar.Const_bool b) -> spr "%b" b
  | Exp_constant(c) -> strConst c
  | Exp_gvar(i) -> spr "{#%d}" i
  | Exp_bot -> "Exp_bot"
  | Exp_extern_call (_, id, t, ts, es) ->
    spr "ext call %s[%s]%s" (id.idText)
      (String.concat "," (List.map strTyp ts)) 
      (String.concat "," (List.map strExp es))
  | _ -> "UNKNOWN EXPRESSION"
and strConst = function
  | Sugar.Const_unit -> "()"
  | Sugar.Const_bool b -> if b then "true" else "false"
  | Sugar.Const_string (bytes, _) -> spr "\"%s\"" (Util.unicodeEncoding.GetString(bytes))
  | Sugar.Const_int32 i -> spr "%d" i
  | Sugar.Const_float f -> spr "%f" f 
  | c -> spr "\"%s\"" (c.ToString ())
and strExp e = 
  if not (is_marked e) then 
    strExp' e
      (* let s1 = strExp' e in  *)
      (*   match e.v with  *)
      (*     | Exp_match _ -> spr "<ann>%s<type>%s</type></ann>" s1 (strTyp e.sort) *)
      (*     | _ -> s1  *)
      (* if not (is_marked e) then if !Util.print_real_names then spr "(%s:%s)" (strExp' e) (strTyp e.sort) *)
      (*                           else strExp' e *)
  else spr "<MARKED-%d> %s </MARKED-%d>" e.p (strExp' e) e.p
    
and strKind k = match k(* .u *) with
  | Kind_boxed k  -> (spr "boxed(%s)" (strKind k))
  | Kind_star -> "*"
  | Kind_affine -> "A"
  | Kind_prop -> "P"
  | Kind_erasable -> "E"
  | Kind_tcon(None, k1, k2) -> spr "(%s => %s)" (strKind k1) (strKind k2)
  | Kind_tcon(Some x, k1, k2) -> spr "('%s::%s => %s)" (strBvd x) (strKind k1) (strKind k2)
  | Kind_dcon(None, t,k) -> spr "(%s => %s)" (strTyp t) (strKind k)
  | Kind_dcon(Some x, t, k) -> spr "(%s:%s => %s)" (strBvd x) (strTyp t) (strKind k)
  | Kind_unknown -> "Kind_unknown"
      
      
and strBvar bv = if !Options.print_real_names then (bvar_real_name bv).idText else (bvar_ppname bv).idText
and strBtvar bv = 
  if !Options.print_real_names 
  then spr "'%s" (bvar_real_name bv).idText 
  (* then spr "%s :: %s" (bvar_real_name bv).idText (strKind bv.sort)   *)
  else spr "'%s" (bvar_ppname bv).idText
  
let strTparam = function
  | Tparam_typ(x,k) -> spr "%s::%s" (strBvd x) (strKind k)
  | Tparam_term(x,t) -> spr "%s:%s" (strBvd x) (strTyp t)

let strTparamList = function
  | [] -> ""
  | l -> spr "<%s>" (String.concat "," (List.map strTparam l))

let rec nameOfSigelt = function
  | Sig_query(li, _)
  | Sig_logic_function(li, _, _)
  | Sig_ghost_assume(li, _, _)
  | Sig_tycon_kind(li,_,_,_,_,_)  
  | Sig_record_typ(li,_,_,_,_) 
  | Sig_typ_abbrev(li,_,_,_) 
  | Sig_datacon_typ(li,_,_,_,_,_,_,_) 
  | Sig_value_decl(li,_) 
  | Sig_extern_value (_, li, _) -> str_of_lident li
  | Sig_extern_typ(_, s) -> nameOfSigelt s
 
let rec strSigelt = function
  | Sig_tycon_kind(li,l,k, false,_,_) ->
      spr "type %s%s :: %s" (str_of_lident li) (strTparamList l) (strKind k)
  | Sig_tycon_kind(li,l,k, true,_,_) ->
      spr "type %s%s :: %s" (str_of_lident li) (strTparamList l) (strKind k)
  | Sig_record_typ(li,l,_,t, _) ->
      spr "type %s %s %s" (str_of_lident li) (strTparamList l) (strTyp t)
  | Sig_typ_abbrev(li,l,_,t) ->
      spr "type %s %s %s" (str_of_lident li) (strTparamList l) (strTyp t)
  | Sig_datacon_typ(li,l,t,Some Assumption,_,_,_,_) ->
      spr "assume %s%s : %s" (str_of_lident li) (strTparamList l) (strTyp t)
  | Sig_datacon_typ(li,l,t,Some Definition,_,_,_,_) ->
      spr "define %s%s : %s" (str_of_lident li) (strTparamList l) (strTyp t)
  | Sig_datacon_typ(li,l,t,_,_,_,_,_) ->
      spr "datacon %s%s : %s" (str_of_lident li) (strTparamList l) (strTyp t)
  | Sig_value_decl(li,t) ->
      let _, i = Util.pfx li.lid in 
        spr "val %s : %s" (i.idText) (strTyp t)
  | Sig_extern_value (eref, li, t) -> 
      spr "extern val %s.%s : %s" eref.dll (str_of_lident li) (strTyp t)
  | Sig_extern_typ (eref, s) -> 
      spr "extern %s.%s %s" eref.dll (str_of_lident eref.classname) (strSigelt s)
  | Sig_query(lid, t) ->         
      spr "query %s:  %s" (str_of_lident lid) (strTyp t)
  | Sig_ghost_assume(lid, t, _aq) ->         
      spr "ghost assume %s:  %s" (str_of_lident lid) (strTyp t)
  | Sig_logic_function(lid, t, _) -> 
      spr "logic function %s:  %s" (str_of_lident lid) (strTyp t)
let printTyp t = pr "%s" (strTyp t)

let strLet lb = 
  String.concat " " (List.flatten (List.map
                                     (fun (bindings, isRec) -> 
                                        (List.map
                                           (fun (bvd,t,e) -> spr "\nlet %s %s %s = \n %s\n" 
                                              (if isRec then "rec" else "")  
                                              (bvd.ppname.idText) 
                                              (match t.v with 
                                                 | Typ_unknown -> ""
                                                 | _ -> spr ": %s" (strTyp t))
                                              (strExp e)) bindings)) lb))
    
let strModule (m:modul) =
  verb := true;
  let res = spr "%s\nmodule %s\n %s \n%s\n %s" 
    (String.concat "\n" (m.pragmas |> List.map (function PRAGMA_MONADIC(t1, t2, t3) -> spr "#monadic(%s,%s,%s)" (strTyp t1) (strTyp t2) (strTyp t3) | _ -> "")))
    (str_of_lident m.name)
    (String.concat "\n" (List.map strSigelt m.signature))
    (strLet m.letbindings)
    (match m.main with
       | Some e -> spr ";; (* main exp *) \n %s" (strExp e)
       | _ -> "") in
    verb := false;
    res
  
let printModule m = print_string (strModule m)
let dumpModule fh m = fpr fh "%s" (strModule m)
  

