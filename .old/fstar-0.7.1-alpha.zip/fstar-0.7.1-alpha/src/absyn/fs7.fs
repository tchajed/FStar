// (c) Microsoft Corporation 2009.
#light "off"
module Microsoft.FStar.Fs7

open Microsoft.FSharp.Compatibility
open Microsoft.FStar.Util
exception Impos

let string_of_int (i:int) = i.ToString()
let int_of_string (s:string) = int32 s

let debug = ref false
let nsdebug = ref false
let ask = ref false

type pos = string
let emptyPos = ""

type typevar = string
type lvar = string
type var = (string list)

let typevarToString (v:typevar):string = "'"^v
let lvarToString (v:lvar) :string = v
let varToString (v:var):string = String.concat "." v


let listminus l1 l2 = List.filter (fun x -> not (List.mem x l2)) l1
let union l1 l2 = l1 @ (listminus l2 l1)
let listunion ll = List.fold_left union [] ll
let intersect l1 l2 = List.filter (fun x -> List.mem x l2) l1

type pub = Private | Public | Default 
type usage = Function | Predicate | Constructor | Value
type Qual = {pub : pub; usage : usage}

type Constant =
    String of string
  | Int of int
  | Bool of bool
  | Float of float

type Message = 
    MVar of var * pos
  | Wild of pos
  | Literal of Constant 
  | Tuple of Message list
  | Term of var * Message
  | Recd of (var * Message) list
  | Lookup of Message * var
and Pattern = Message 
let nopat = []

type Formula =
    True
  | False
  | Not of Formula 
  | Iff of Formula * Formula
  | Imp of Formula * Formula
  | Conj of Formula * Formula
  | Disj of Formula * Formula
  | Says of Message * Formula
  | All of lvar * Type * Formula * Pattern list
  | Ex of  lvar * Type * Formula * Pattern list
  | Pred of var * Message list
  | Eq of Message * Message
  | NEq of Message * Message
and Type =
    TVar of typevar
  | TApp of Type list * Message list * var
  | TTuple of (lvar * Type) list * Formula
  | TFun of lvar * Type * Formula * lvar * Type * Formula
  | TTop
  | TUvar of Uvar_basis Unionfind.uvar
and Uvar_basis = 
  | FreeVars of typevar list * var list * bool
  | Fixed of Type

type constType = CFun | CPred | CUnknown

type Sigma = (var * Type * constType) list

type Kind = Plus | Minus | Zero

type 'a parType = (typevar * Kind) list * (lvar * Type) list * var * 'a


type TypeDef = 
    TAbs of (typevar * Kind) list * (lvar * Type) list * var       
  | TAlg of (typevar * Kind) list * (lvar * Type) list * var * (var * Type * constType) list 
   (*  type ('a:+/-/0...;            x:T1,...)            F =    C1 of T1 | C2 of T2 ... *)

  | TAbbrv of (typevar * Kind) list * (lvar * Type) list * var * Type
  | TRecd of (typevar * Kind) list * (lvar * Type) list * var * (var * Type) list

type Decl = 
    Val of Qual * var * (typevar * Kind) list * (lvar * Type) list * Type
  | Form of pub * var * Formula
  | Query of pub * var * Formula
  | AbsType of (typevar * Kind) list * (lvar * Type) list *  var
  | ConcType of Qual * (typevar * Kind) list * (lvar * Type) list * var * Sigma  
  | TypeAbbrv of (typevar * Kind) list * (lvar * Type) list * var * Type
  | TypeRecd of (typevar * Kind) list * (lvar * Type) list * var * (var * Type) list
  | RecType of Qual * TypeDef list
  | Exn of var * Type
  | Open of var
  | Kind of Type * Kind  
  | SubTy of Type * Type

type fs7 = FS7 of var * string * Decl list	

// reporting errors (roughly as in f#)
let error s : 'a = failwith (sprintf "ERROR: %s\n" s)
let errorPos s r : 'a = 
  printf "ERROR at file %s: %s\n" r s;
  failwith (sprintf "ERROR at file %s: %s\n" r s)
let warn s = printf "WARNING: %s\n" s
let warnPos s r = printf "WARNING at file %s: %s\n" r s

let rec compress t = match t with
  | TUvar (uv) -> 
      begin
        match Unionfind.find uv with 
            FreeVars _ -> t
          | Fixed t' -> compress t'
      end
  | _ -> t


let rec fvars_message (mm:Message) = match mm with
    MVar(v,p) -> [v]
  | Wild(p) -> []
  | Literal(_) -> []
  | Tuple(ml) -> List.concat (List.map fvars_message ml)
  | Term(v,mm) -> fvars_message mm
  | Recd(vml) -> failwith "recds should be eliminated"
  | Lookup(m,v) -> failwith "recd lookups should be eliminated"

let rec fvars_formula (f:Formula) = match f with
    True -> []
  | False -> []
  | Iff(f1,f2) -> (fvars_formula f1) @ (fvars_formula f2)
  | Imp(f1,f2) -> (fvars_formula f1) @ (fvars_formula f2)
  | Conj(f1,f2) -> (fvars_formula f1) @ (fvars_formula f2)
  | Disj(f1,f2) -> (fvars_formula f1) @ (fvars_formula f2)
  | Says(m,f) -> (fvars_message m) @ (fvars_formula f)
  | Not(f) ->  (fvars_formula f)
  | All(l,tt,f,_) -> listminus (fvars_formula f) [[l]]
  | Ex(l,tt,f,_) ->  listminus (fvars_formula f) [[l]] 
  | Pred(v,ml) -> List.concat (List.map fvars_message ml)
  | Eq(m1,m2) -> (fvars_message m1) @ (fvars_message m2)
  | NEq(m1,m2) -> (fvars_message m1) @ (fvars_message m2)

let rec fvars_type t = match compress t with
    TApp(tl,ml,f) -> (List.concat (List.map fvars_type tl)) @ (List.concat (List.map fvars_message ml))
  | TFun(x1,t1,c1,x2,t2,c2) ->
      (fvars_type t1) @ (listminus ((fvars_formula c1)@(fvars_type t2)@(listminus (fvars_formula c2) [[x2]])) [[x1]])
  | TTuple(ltl,f) ->
      let fvs,bvs = List.fold_left (fun (fvs,bvs) (l,t) -> (listminus (fvars_type t) bvs)@fvs,[l]::bvs) ([],[]) ltl in
	fvs@(listminus (fvars_formula f) bvs)
  | TUvar (uv) ->
      (match Unionfind.find uv with
	   FreeVars(_, fvs, _ ) -> fvs
	 | _ -> [])
  | _ -> []

let rec tnames_type = function
    TApp(tl,ml,f) -> f::(List.concat (List.map tnames_type tl))
  | TFun(x1,t1,c1,x2,t2,c2) ->
      (tnames_type t1) @ (tnames_type t2)
  | TTuple(ltl,f) ->
      List.concat (List.map (fun (l,t) -> tnames_type t) ltl)
  | _ -> []




(* Printing *)

let printPub = ref false

let tvarToString x = if !printPub then "Un" else sprintf "%s" (typevarToString x) 

let pvarToString x = 
  match x with
//      ["Pi";y] -> y
    | v -> varToString v

let rec messageToString msg =
	match msg with
   	    MVar (id,r) -> let s = pvarToString id in
	      if s = "" then (Printf.printf "ERROR: empty variable at %s \n" r; s)
	      else s
	  | Literal(l) ->  (match l with String(s) -> sprintf "\"%s\"" s | Int(i) -> i.ToString() | Float(f) -> f.ToString() | Bool(true) -> "True" | Bool(false) -> "False")
	  | Tuple msgs -> sprintf "(%s)" (messageListToString msgs)
	  | Term(id, msg) -> sprintf "%s %s" (pvarToString id) (messageToString msg)
	  | Recd(vml) -> sprintf "{%s}" (String.concat ";"
					   (List.map (fun (v,m) -> sprintf "%s=%s" (pvarToString v) 
							(messageToString m)) vml))
	  | Lookup(m,v) -> sprintf "%s.%s" (messageToString m) (pvarToString v)
	  | Wild(p) -> "_"
	  	  
and messageListToString msgList = 
	match msgList with
	    [] -> ""
	  | x::xs -> messageToString x ^ (List.fold_left (fun b m -> b ^ ", " ^ (messageToString m)) "" xs)

let rec formulaToString form =
	match form with
    	    True -> "true"
    	  | False -> "false"
	  | Iff(f1, f2) -> formulaToString f1 ^ " <=> " ^ formulaToString f2
	  | Imp(f1, f2) -> formulaToString f1 ^ " => " ^ formulaToString f2
	  | Not(f) -> "not " ^(formulaToString f)
	  | Conj(f1, f2) -> formulaToString f1 ^ " /\ " ^ formulaToString f2
	  | Disj(f1, f2) -> formulaToString f1 ^ " \/ " ^ formulaToString f2
	  | Says(msg, f) -> messageToString msg ^ " says " ^ formulaToString f
	  | All(id, t, f, pats) -> "(!" ^ lvarToString id ^ ". " ^ formulaToString f ^ ")"
	  | Ex(id, t, f, pats) -> "(?" ^ lvarToString id ^ ". " ^ formulaToString f ^ ")"
	  | Pred(id, mlst) -> pvarToString id ^ "(" ^ messageListToString mlst ^ ")"
	  | Eq(m1, m2) -> messageToString m1 ^ " = " ^ messageToString m2
	  | NEq(m1, m2) -> messageToString m1 ^ " <> " ^ messageToString m2
and patToString = function 
      | [] -> ""
      | pats -> spr "{:pats %s}" (messageListToString pats)
and typeToString t =
	match (compress t) with
	  | TVar id -> tvarToString id
	  | TUvar (uv) -> "`Uvar" ^ (string_of_int (Unionfind.uvar_id uv))
	  | TTop -> "Top"
	  | TApp([], [], id) -> pvarToString id
	  | TApp([t], [], id) -> (typeToString t) ^ " " ^ (pvarToString id)
	  | TApp(tlist, [], id) -> "(" ^ typeListToString tlist ^ ") " ^  pvarToString id
	  | TApp([], mlist, id) -> "(;" ^ messageListToString mlist ^ ") " ^  pvarToString id
	  | TApp(tlist, mlist, id) -> "(" ^ typeListToString tlist ^ ";" ^ messageListToString mlist ^ ") " ^  pvarToString id
	  | TTuple([], True) -> "unit"
	  | TTuple([], f) -> "unit{" ^ formulaToString f ^"}"
	  | TTuple([(id,t)], True) -> sprintf "%s" (typeToString t) 
	  | TTuple(idtl, f) -> 
	      sprintf "(%s)%s" 
		(let (s,vs) = List.fold_right (fun (id,t) (s,vs)  -> 
						 let ns = 
						   if List.mem [id] vs then 
						     (lvarToString id)^":"^(typeToString t)
						   else (typeToString t) in
						   if s = "" then 
						     (ns,(fvars_type t)@vs)
						   else
						     (ns^" * "^s,(fvars_type t)@vs))
		   idtl ("",fvars_formula f) in s)
		(if f = True then "" else sprintf "{%s}" (formulaToString f))
	  | TFun(x, t1, pre, r, t2, post) ->
	      let vs = (fvars_type t2)@(fvars_formula pre)@(fvars_formula post) in
		if List.mem [x] vs then 
		  if pre = True then 
		    sprintf "(%s:%s -> %s)" (lvarToString x) (typeToString t1) (typeToString (TTuple([r,t2],post)))
		  else
		    sprintf "((%s:%s){%s} -> %s)" (lvarToString x) (typeToString t1) (formulaToString pre) (typeToString (TTuple([r,t2],post)))
		else
		  if pre = True then 
		    sprintf "(%s -> %s)" (typeToString t1) (typeToString (TTuple([r,t2],post)))
		  else 
		    sprintf "(%s{%s} -> %s)" (typeToString t1) (formulaToString pre) (typeToString (TTuple([r,t2],post)))

and typeListToString typeList = 
	match typeList with 
		[] -> ""
	  | x::xs -> typeToString x ^ (List.fold_left (fun b t -> b ^ ", " ^ typeToString t) "" xs)


let ntypeToString t = 
  let p = !printPub in
    printPub := false;
    let s = typeToString t in
      printPub := p;
      s

let sigmaToString'(id, t, _) = sprintf "%s of %s" (pvarToString id) (ntypeToString t)
								
let sigmaToString sigmaList = sigmaToString'(List.hd sigmaList) ^ " " ^ 
				  List.fold_left (fun s sigma -> s ^ "| " ^ sigmaToString' sigma ^ " ") "" (List.tl sigmaList)

let pubToString k = 
    match k with
	Public -> "public"
      | Private -> "private"
      | Default -> ""      

let usageToString k = 
    match k with
	Function -> "function"
      | Predicate -> "predicate"
      | Constructor -> ""      
      | Value -> ""      

let qualToString q = 
  let ps = pubToString q.pub in
  let us = usageToString q.usage in
    if ps = "" then us
    else if us = "" then ps 
    else ps ^ " " ^ us

let kindToString = function
    Plus -> "+"
  | Minus -> "-"
  | Zero -> "0"

let tvarKToString (x,k) = sprintf "%s::%s" (typevarToString x) (kindToString k)

let lvarTyToString (l,t) = sprintf "%s:%s" (lvarToString l) (ntypeToString t)

let parListToString tlst vlst = 
	match tlst,vlst with
            [],[] -> ""
	  | [x],[] -> sprintf "%s" (tvarKToString x)
	  | xs,[] -> sprintf "(%s)" (String.concat "," (List.map tvarKToString xs))
	  | [],vs -> sprintf "(%s)" (String.concat "," (List.map lvarTyToString vs))
	  | xs,vs -> sprintf "(%s,%s)" (String.concat "," (List.map tvarKToString xs)) (String.concat "," (List.map lvarTyToString vs))

let rec strcat d sl = 
  match sl with
      [] -> ""
    | [h] -> h
    | ""::t -> strcat d t
    | h::t -> let s = strcat d t in 
	if s = "" then h else h^d^s

let typedefToString q td = match td with
  | TAbs(tlst, vlst, id) -> 
      sprintf "%s %s" (parListToString tlst vlst) (pvarToString id) 
  | TAlg(tlst, vlst, id, sigma) -> 
      if !printPub && q.pub = Private then 
	sprintf "%s %s" (parListToString tlst vlst) (pvarToString id) 
      else
	sprintf "%s %s = %s" (parListToString tlst vlst) (pvarToString id) (sigmaToString sigma)
  | TAbbrv(tlst, vlst, c, t2) -> 
      sprintf "%s %s = %s" (parListToString tlst vlst) (pvarToString c) (ntypeToString t2)
  | TRecd(tlst, vlst, c, vtl) -> 
      sprintf "%s %s = { %s }" (parListToString tlst vlst) (pvarToString c) 
	(String.concat "; " (List.map (fun (v,t) -> 
					 sprintf "%s:%s" (varToString v) (ntypeToString t)) vtl))

let declToString decl =
	match decl with 
    	    Val(q, id, tlst, vlst, t) -> 
	      if !printPub && q.pub = Private then ""
	      else if tlst = [] && vlst = [] then 
		sprintf "%s %s : %s" (strcat " " [qualToString q;"val"]) (pvarToString id) (typeToString t)
	      else
		sprintf "%s %s : !%s. %s" (strcat " " [qualToString q;"val"]) (pvarToString id) (parListToString tlst vlst) (typeToString t)
	  | Form (p,v,form) -> 
	      sprintf "%s assume %s" (pubToString p) (formulaToString form)
          | RecType(q,tdl) ->
	      sprintf "type %s" (String.concat "\nand " (List.map (typedefToString q) tdl))
		
	  | AbsType(tlst, vlst, id) -> 
	      sprintf "%s %s" (strcat " " ["type";parListToString tlst vlst]) (pvarToString id) 
	  | ConcType(q, tlst, vlst, id, sigma) -> 
	      if !printPub && q.pub = Private then sprintf "%s %s" (strcat " " ["type";parListToString tlst vlst]) (pvarToString id) 
	      else
		sprintf "%s %s = %s" (strcat " " [qualToString q;"type";parListToString tlst vlst]) (pvarToString id) (sigmaToString sigma)
	  | TypeAbbrv(tlst, vlst, c, t2) -> 
	      sprintf "%s %s = %s" (strcat " " ["type";parListToString tlst vlst]) (pvarToString c) (ntypeToString t2)
	  | TypeRecd(tlst, vlst, c, vtl) -> 
	      sprintf "%s %s = { %s }" (strcat " " ["type";parListToString tlst vlst]) (pvarToString c) 
		(String.concat "; " (List.map (fun (v,t) -> 
						 sprintf "%s:%s" (varToString v) (ntypeToString t)) vtl))
	  | Query (_,_,f) -> sprintf "ask %s" (formulaToString f)
	  | Exn(v, t) -> sprintf "exception %s of %s" (pvarToString v) (typeToString t)
	  | Open v -> sprintf "open %s" (varToString v)
	  | Kind _ 
	  | SubTy _ -> ""

let declListToString = List.fold_left (fun s d -> 
					 let ss = declToString d  in
					   if ss = "" then s else 
					     s ^ ss ^ "\n") ""

let moduleToString n = if n = [""] then "" else "module " ^ (varToString n) ^ "\n"
let coqmoduleToString n = if [n] = [""] then "" else "coqproofs " ^ (varToString [n]) ^ "\n"

let toString ast = 
	match ast with 
		FS7(n, c, decls) -> (moduleToString n) ^ "\n" ^ 
		(coqmoduleToString c) ^ "\n" ^ 
		(declListToString decls)


let rec pubType t =
	match t with
	    TVar _
	  | TTop 
	  | TApp _ -> TApp([t],[],["Data";"pub"])
	  | TTuple (ltl,f) -> TTuple (List.map (fun (l,t) -> (l,pubType t)) ltl, f)
	  | TFun(x, t1, pre, r, t2, post) -> TFun(x, pubType t1, pre, r, pubType t2, post)

let pubDecl decl =
	match decl with 
    	    Val(q, id, tlst, vlst, t) when q.pub = Public || q.pub = Default ->
	      Val(q, id, tlst, vlst, pubType t)
	  | d -> d

let toPubFs7 ast = 
  match ast with 
      FS7(n, c, decls) -> 
	(moduleToString n) ^ "\n" ^ 
	(coqmoduleToString c) ^ "\n" ^ 
	(declListToString (List.map pubDecl decls))
  
(* Name Qualification *)

let rec last xl = match xl with
    [] -> failwith "last got empty list"
  | [x] -> [],x
  | h::t ->
      let (f,l) = last t in
	h::f,l

let primTypes = 
  ["list";
   "ref";
   "int";
   "bool";
   "string";
   "unit";
   "option";
   "Un"
  ]

let mkPrimType t = [t]

let primConsts = 
  ["op_ColonColon";
   "cons";
   "op_Nil";
   "nil";
   "True";
   "False";
   "Some";
   "None"]

let primFuns = 
  ["op_Equals";
   "assume";
   "expect"]

let rec mkPrimVal l = [l]

(*
  if l = "cons" then mkPrimVal "op_ColonColon"
  else if l = "nil" then mkPrimVal "op_Nil"
  else if l = "[]" then mkPrimVal "op_Nil"
  else ["PrimTypes";l]
*)


let rec find_app (f:'a -> 'b) (l:'a list) : 'b =
  match l with
      [] -> raise Not_found
    | h::t -> (try f h with _ -> find_app f t)

let curr_lvar = ref 0
let new_lvar () =
    curr_lvar := !curr_lvar + 1;
    "l"^(string_of_int !curr_lvar)

let new_nvar x =
    curr_lvar := !curr_lvar + 1;
    x^(string_of_int !curr_lvar)

let new_labelvar (v:var) :lvar = 
  let x = List.hd (List.rev v) in 
    curr_lvar := !curr_lvar + 1;  
    x^(string_of_int !curr_lvar)

let new_tvar () =
    curr_lvar := !curr_lvar + 1;
    "t"^(string_of_int !curr_lvar)


let rec nlist n = 
  if n = 0 then []
  else (nlist (n-1))@[n]
let label_list vl = 
  let cmp (v1:var,_) (v2:var,_) = compare v1 v2 in
  let svl = List.sortWith cmp vl in
  let len = List.length svl in
  let il = nlist len in
  let inl = List.map (fun i -> (i,len)) il in
    List.combine inl svl


type Elim = Label of lvar * int * int * Message | Forall of lvar | Exists of lvar

let rec tvars_type t = match compress t with 
    TVar t -> [t]
  | TUvar (uv) -> 
      (match Unionfind.find uv with
	   FreeVars (ftvs, _, _) -> ftvs
	 | _ -> [])
  | TTop -> []
  | TApp(tl,ml,v) -> listunion (List.map tvars_type tl)
  | TTuple(ltl,f) -> listunion (List.map (fun (l,t) -> tvars_type t) ltl)
  | TFun(x1,t1,c1,x2,t2,c2) -> 
      let tvs1 = tvars_type t1 in
      let tvs2 = tvars_type t2 in
	union tvs2 tvs1 


and dtvars_type_aux tvs b t = match compress t with 
    TVar t when b && (not (List.mem t tvs)) -> [t]
  | TVar t when not b && (not (List.mem t tvs)) -> [t]
  | TVar t -> []
  | TUvar (uv) -> 
      (match Unionfind.find uv with
	   FreeVars (ftvs, _, _) -> ftvs
	 | _ -> [])
  | TTop -> []
  | TApp(tl,ml,v) -> listunion (List.map (dtvars_type_aux tvs b) tl)
  | TTuple([],f) -> []
  | TTuple((l,t)::ltl,f) -> 
      let d = dtvars_type_aux tvs b t in
      let t = union tvs (tvars_type t) in
	union d (dtvars_type_aux t (not b) (TTuple(ltl,f)))
  | TFun(x1,t1,c1,x2,t2,c2) -> 
      let dtvs1 = dtvars_type_aux tvs b t1 in
      let tvs1 = tvars_type t1 in
      let dtvs2 = dtvars_type_aux (union tvs tvs1) (not b) t2 in
	union dtvs1 (listminus dtvs2 tvs1)

and dtvars_type t = dtvars_type_aux [] true t

and all_tvars_type t = match compress t with
    TVar t -> [t]
  | TUvar _ 
  | TTop -> []
  | TApp(tl,ml,v) -> listunion (List.map all_tvars_type tl)
  | TTuple(ltl,f) -> listunion (List.map (fun (l,t) -> all_tvars_type t) ltl)
  | TFun(x1,t1,c1,x2,t2,c2) -> union (all_tvars_type t1) (all_tvars_type t2)

and tvars_env = function
    [] -> []
  | (Val(k,v,tl,vpl,t))::r -> 
      let tvl,tkl = List.split tl in
	union (listminus (tvars_type t) tvl) (tvars_env r)
  | _::r -> (tvars_env r)

let uvars_type t = 
  let rec uvars l t = match compress t with
      TVar _
    | TTop -> l
    | TUvar _ as t -> if List.mem t l then l else (t::l)
    | TApp(tl, ml, v) -> List.fold_left uvars l tl 
    | TTuple(ltl, f) -> List.fold_left (fun l (_, t) -> uvars l t) l ltl
    | TFun(x1, t1, c1, x2, t2, c2) -> let l' = uvars l t1 in uvars l' t2
  in uvars [] t	

let fresh_uvar = function
    TUvar(uv) -> 
      begin
	match Unionfind.find uv with
	    FreeVars (ftvs,fvs,b) -> 
	      let uv' = Unionfind.fresh (FreeVars (ftvs,fvs,b)) in
		TUvar (uv')
	  | _ -> raise Impos
      end
  | _ -> raise Impos
      
 // simplifying formula construction
let conj = function
  | False,_ | _,False -> False
  | True,x | x,True -> x
  | Eq(x,y),z when x = y -> z
  | z,Eq(x,y) when x = y -> z
  | x,y -> Conj(x,y)

let imp = function
  | False,_ -> True
  | True,x -> x
  | Eq(x,y),z when x = y -> z
  | x,y -> Imp(x,y)

let disj = function
  | True,_ | _,True -> True
  | False,x | x,False -> x
  | x,y -> Disj(x,y)

let notf = function
  | True -> False
  | False -> True
  | x -> Not x

let ex (v,t,f) = 
  if List.mem [v] (fvars_formula f) then 
    Ex(v,t,f,[])
  else f

let all (v,t,f) = 
  if List.mem [v] (fvars_formula f) then 
    All(v,t,f,[])
  else f
