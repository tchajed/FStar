// Adapted from sources of F#
// See LICENSE-fsharp.txt for terms and conditions
// (c) Microsoft Corporation. All rights reserved

#light 

module Microsoft.FStar.Sugar
open Microsoft.FSharp.Compiler
open Microsoft.FStar.Range
open Microsoft.FStar.Options
open Microsoft.FStar.Util
open Profiling

(*------------------------------------------------------------------------
 * General error recovery mechanism
 *-----------------------------------------------------------------------*)

/// Thrown when want to add some range information to some .NET exception
exception WrappedError of exn * range

/// Thrown when immediate, local error recovery is not possible. This indicates
/// we've reported an error but need to make a non-local transfer of control.
/// Error recovery may catch this and continue (see 'errorRecovery')
exception ReportedError

/// Thrown when we stop processing the F# Interactive interactive entry or #load.
exception StopProcessing


(* common error kinds *)
exception Error of string * range
exception InternalError of string * range
exception OCamlCompatibility of string * range
exception LibraryUseOnly of range
exception Deprecated of string * range
exception Experimental of string * range
exception PossibleUnverifiableCode of range


// Range\NoRange Duals
exception UnresolvedReferenceNoRange of (*assemblyname*) string 
exception UnresolvedReference of (*assemblyname*) string * range
exception UnresolvedPathReferenceNoRange of (*assemblyname*) string * (*path*) string
exception UnresolvedPathReference of (*assemblyname*) string * (*path*) string * range

// Attach a range if this is a range dual exception.
let rec AttachRange m (exn:exn) = 
    if m = range0 then exn
    else 
        match exn with
        // Strip TargetInvocationException wrappers
        | :? System.Reflection.TargetInvocationException -> AttachRange m exn.InnerException
        | UnresolvedReferenceNoRange(a) -> UnresolvedReference(a,m)
        | UnresolvedPathReferenceNoRange(a,p) -> UnresolvedPathReference(a,p,m)
        | Failure(msg) -> InternalError(msg^" (Failure)",m)
(*         | InvalidArgument(msg) -> InternalError(msg^" (InvalidArgument)",m) *)
        | notARangeDual -> notARangeDual

let diagnosticsLog = ref (if !Options.silent then None else Some stderr)
let dflushn () = match !diagnosticsLog with None -> () | Some d -> d.WriteLine(); flush d
let dflush () = match !diagnosticsLog with None -> () | Some d -> flush d
let dprintn s = 
  match !diagnosticsLog with None -> () | Some d -> output_string d s; output_string d "\n"; dflush()
let dprint s = 
  match !diagnosticsLog with None -> () | Some d -> output_string d s; dflush()

let dprintf (fmt: (_,_,_,_) format4) = 
    Printf.kfprintf dflush (match !diagnosticsLog with None -> System.IO.TextWriter.Null | Some d -> d) fmt

let dprintfn (fmt: (_,_,_,_) format4) = 
    Printf.kfprintf dflushn (match !diagnosticsLog with None -> System.IO.TextWriter.Null | Some d -> d) fmt

let setDiagnosticsChannel s = diagnosticsLog := s

let warningHandler = ref (fun (e:exn) -> dprintf "no warning handler installed\n" ; ())
let errorHandler = ref (fun (e:exn) -> dprintf "no warning handler installed\n" ; ())  
let errorAndWarningCount = ref 0
let errorR  exn = incr errorAndWarningCount; match exn with StopProcessing | ReportedError -> raise exn | _ -> !errorHandler exn
let warning exn = incr errorAndWarningCount; match exn with StopProcessing | ReportedError -> raise exn | _ -> !warningHandler exn
let error   exn = errorR exn; raise ReportedError


let errorRecovery (exn:exn) (m:range) =
  match exn with
  (* Don't send ThreadAbortException down the error channel *)
  |  :? System.Threading.ThreadAbortException 
  |  WrappedError((:? System.Threading.ThreadAbortException),_) ->  ()
  | ReportedError | WrappedError(ReportedError,_) -> ()
  | StopProcessing | WrappedError(StopProcessing,_) -> raise exn
  | e -> errorR (AttachRange m exn)

let stopProcessingRecovery (exn:exn) (m:range) =
  match exn with
  // This is the only catch handler for StopProcessing
  | StopProcessing | WrappedError(StopProcessing,_) -> ()
  | e -> errorRecovery exn m


let errorRecoveryNoRange (exn:exn) =
    errorRecovery exn range0

let report f = 
    f() 

let deprecated s m = warning(Deprecated(s,m))
let deprecatedWithError s m = errorR(Deprecated(s,m))
let libraryOnlyWarning m = warning(LibraryUseOnly(m))
let deprecatedOperator m = deprecated "the treatment of this operator is now handled directly by the F# compiler and its meaning may not be redefined" m
let ocamlCompatWarning s m = warning(OCamlCompatibility(s,m))


//----------------------------------------------------------------------------
//Watch the count of user-visible errors reported to ensure we only 
//save things in caches when no user-visible errors have been reported as the 
//side effect of an operation.
//--------------------------------------------------------------------------

type errorCountReporter = ErrorCountReporter of (unit -> int)

// This verstion of WatchForErrors lets the caller indicate the count of errors
// to use. The Language Service API does this w.r.t. errors reported to the use
// rather than just any errors going through the above error channel.
let WatchForErrors operation (inp,ErrorCountReporter(errorCountReporter))  = 
    let numErrorsBefore = errorCountReporter()
    let res = operation(inp) 
    let numErrorsAfter = errorCountReporter()
    let numNewErrors = max (numErrorsAfter - numErrorsBefore) 0
    res,numNewErrors

// This one watches all errors going through the error/errorR/warning error channels.
let WatchForErrorsAndWarnings f = WatchForErrors f ((),ErrorCountReporter (fun () -> !errorAndWarningCount))

(*------------------------------------------------------------------------
 *  Errors as data: Sometimes we have to reify errors as data, e.g. if backtracking 
 *-----------------------------------------------------------------------*)

(* type warning = exn *)
(* type error = exn *)
type 'a OperationResult = 
    | OkResult of exn list * 'a
    | ErrorResult of exn list * exn
    
type ImperativeOperationResult = unit OperationResult

let CommitOperationResult res = 
    match res with 
    | OkResult (warns,res) -> List.iter warning warns; res
    | ErrorResult (warns,err) -> List.iter warning warns; error err

let RaiseOperationResult res : unit = CommitOperationResult res

let ErrorD err = ErrorResult([],err)
let WarnD err = OkResult([err],())
let CompleteD = OkResult([],())
let ResultD x = OkResult([],x)
let GaveNoErrors res = match res with OkResult _ -> true | ErrorResult _ -> false

(* The bind in the monad. Stop on first error. Accumulate warnings and continue. *)
let (++) res f = 
    match res with 
    | OkResult([],res) -> (* tailcall *) f res 
    | OkResult(warns,res) -> 
        begin match f res with 
        | OkResult(warns2,res2) -> OkResult(warns@warns2, res2)
        | ErrorResult(warns2,err) -> ErrorResult(warns@warns2, err)
        end
    | ErrorResult(warns,err) -> 
        ErrorResult(warns,err)
        
        

(* Stop on first error. Accumulate warnings and continue. *)
let rec IterateD f xs = match xs with [] -> CompleteD | h :: t -> f h ++ (fun () -> IterateD f t)

(* Stop on first error. Report index *)
let IterateIdxD f xs = 
    let rec loop xs i = match xs with [] -> CompleteD | h :: t -> f i h ++ (fun () -> loop t (i+1))
    loop xs 0

(* Stop on first error. Accumulate warnings and continue. *)
let rec Iterate2D f xs ys = 
    match xs,ys with 
    | [],[] -> CompleteD 
    | h1 :: t1, h2::t2 -> f h1 h2 ++ (fun () -> Iterate2D f t1 t2) 
    | _ -> failwith "Iterate2D"

let TryD f g = 
    match f() with
    | ErrorResult(warns,err) ->  (OkResult(warns,())) ++ (fun () -> g err)
    | res -> res

let rec WhileD gd body = if gd() then body() ++ (fun () -> WhileD gd body) else CompleteD
let rec RepeatWhileD body = body() ++ (function true -> RepeatWhileD body | false -> CompleteD) 
let rec AtLeastOneD f l = match l with [] -> ResultD(false) | h::t -> f h ++ (fun res1 -> AtLeastOneD f t ++ (fun res2 -> ResultD (res1 || res2)))

/// The prefix of the names used for the fake namespace path added to all dynamic code entries in FSI.EXE
let DynamicModulePrefix = "FSI_"

(*------------------------------------------------------------------------
 *  AST: main ast definitions
 *-----------------------------------------------------------------------*)

type SyntaxVec<'a> = 'a list
  
// PERFORMANCE: consider making this a struct.
[<System.Diagnostics.DebuggerDisplay("{idText}")>]
[<Sealed>]
type ident (text,range) = 
    class
(*         interface System.IComparable *)
        member x.idText = text
        member x.idRange = range
        override x.ToString() = text
(*         override x.CompareTo(y:ident) = String.compare x.idText y.idText *)
    end

type ValueId = ident 
type UnionCaseId = ident 
type RecdFieldId = ident 

type LongIdent = {lid:ident list; str:string}
type RecdFieldPath = LongIdent * RecdFieldId 

(* Term language *)
type 
  [<StructuralEquality; StructuralComparison>]
  sconst = 
  | Const_unit
  | Const_bool of bool
  | Const_int8 of sbyte
  | Const_uint8 of byte
  | Const_int16 of int16
  | Const_uint16 of uint16
  | Const_int32 of int32
  | Const_uint32 of uint32
  | Const_int64 of int64
  | Const_uint64 of uint64
  | Const_nativeint of int64
  | Const_unativeint of uint64
  | Const_float32 of single
  | Const_float of double
  | Const_char of char
  | Const_decimal of System.Decimal
  | Const_bigint of byte[] (* in unicode *)
  | Const_bignum of byte[] (* in unicode *)
  | Const_string of byte[] * range (* unicode encoded, F#/Caml independent *)
  | Const_bytearray of byte[] * range 
  | Const_uint16array of uint16[] 
with override x.ToString() = match x with 
  | Const_unit -> "()"
  | Const_bool b -> if b then "true" else "false"
  | Const_int8 x -> spr "%A" x
  | Const_uint8 x -> spr "%A" x
  | Const_int16 x -> spr "%A" x
  | Const_uint16 x -> spr "%A" x
  | Const_int32 x ->  spr "%A" x
  | Const_uint32 x -> spr "%A" x
  | Const_int64 x -> spr "%A" x
  | Const_uint64 x -> spr "%A" x
  | Const_nativeint x -> spr "%A" x
  | Const_unativeint x -> spr "%A" x
  | Const_float32 x -> spr "%A" x
  | Const_float x -> spr "%A" x
  | Const_char x -> spr "'%A'" x
  | Const_decimal x -> spr "'%A'" x
  | Const_string(bytes, _) -> spr "\"%s\"" (Util.unicodeEncoding.GetString(bytes))
  | Const_bigint _
  | Const_bignum _ 
  | Const_bytearray _  
  | Const_uint16array _ ->  "<array>"
end


let const_eq c1 c2 = match c1,c2 with
  | Const_string (ba1,_),  Const_string (ba2, _) ->  ba1=ba2
  | Const_bytearray (ba1,_),  Const_string (ba2, _) ->  ba1=ba2
  | c1, c2 -> c1=c2

type SimplePat =
  | SPat_as of ValueId * range
  | SPat_typed of SimplePat * typ * range

and SimplePats =
  | SPats of list<SimplePat> * range
  | SPats_typed of SimplePats * typ * range

and  
(*   [<StructuralEquality(false); StructuralComparison(false)>] *)
  synpat =
  | Pat_const of sconst * range
  | Pat_lid of LongIdent * synpat list  * range

  | Pat_wild of range
  | Pat_as of synpat * ValueId * bool (* true if 'this' variable *)  * range (* access option * range *)
 
  | Pat_array_or_list of  bool * synpat list * range (* TODO: Change this to Pat_list *)
  
  | Pat_tuple of synpat list * range
  | Pat_recd of (RecdFieldPath * synpat) list * range
  | Pat_paren of synpat * range  (* What's this for? *)
  | Pat_typed of synpat * typ * range 
  | Pat_tvar of typar * range
  | Pat_uvar of range
      (*   | Pat_disj of synpat * synpat * range *)
      
and  
(*   [<StructuralEquality(false); StructuralComparison(false)>] *)
  synexpr =
    | Expr_typed of synexpr * typ * range
    | Expr_const of sconst * range
    | Expr_id_get of ident (* = Expr_lid_get(false,[id],id.idRange) *)
    | Expr_lid_get of bool * LongIdent * range (* = Expr_lid_get(false,[id],id.idRange) *)
    | Expr_lvalue_get of synexpr * LongIdent * range
    | Expr_paren of synexpr * range  (* parenthesized expressions kept in AST to distinguish A.M((x,y)) from A.M(x,y) *)
    | Expr_tuple of synexpr list * range
    | Expr_list of list<synexpr> * range 
    | Expr_recd of synexpr option * (RecdFieldPath * synexpr) list * range
    | Expr_lambda of SimplePats * synexpr * range (* bool indicates if lambda originates from a method. Patterns here are always "simple" *)
    | Expr_match of synexpr * list<matching> * bool * range (* bool indicates if this is an exception match in a computation expression which throws unmatched exceptions *)
    | Expr_app of synexpr * synexpr * range
    | Expr_tyapp of synexpr * typ list * range
    | Expr_let of bool * bool * binding list * synexpr * range
    | Expr_seq of bool * synexpr * synexpr * range (* false indicates "do a then b then return a" *)
    | Expr_cond of synexpr * synexpr * synexpr option * range * range

and matching = Clause of synpat * synexpr option *  synexpr * range  (* pattern X where clause option X branch *)

and BindingKind = 
  | StandaloneExpression
  | NormalBinding
  
and binding = 
  | Binding of 
      BindingKind *  
      synpat * 
      bindingExpr *
      range 

and bindingExpr = 
    BindingExpr of (typ * range) option *  synexpr 

(* Type language *)
and 
(*   [<StructuralEquality(false); StructuralComparison(false)>] *)
    typ =
  | Type_lid of LongIdent * range
  | Type_app of typ * list<typ> * range
  | Type_tuple of list<(option<ident> * typ)> * range   
  | Type_fun of (option<ident> * typ) * typ * range
  | Type_var of typar * range
  | Type_term_index of synexpr * range (* not strictly a type on its own, can only appear as an index *)
  | Type_refinement of ident * typ * formula * bool * range  (* boolean: true => ghost *)
  | Type_affine of typ * range
  | Type_qtyp of list<typar> * typ * range
  | Type_lam of ident * typ * typ * range
  | Type_tlam of typar * typ * range
  | Type_formula of formula * range
  | Type_ascribed of typ * kind * range
  | Type_anon of range
  | Type_tid of int * range
  | Type_named of string * typ * range
  | Type_paren of typ * range (* used to restore left-associativity of type application *)

and typar = 
  | Typar of ident * option<kind>

and formula = 
  | Form_atom of atom * range
  | Form_not of formula * range
  | Form_conj of formula * formula * range
  | Form_disj of formula * formula * range
  | Form_all of ident * typ * formula * range * pattern list * bool
  | Form_exists of ident * typ * formula * range * pattern list * bool
  | Form_impl of formula * formula * range
  | Form_iff of formula * formula * range
  | Form_ite of formula * formula * formula * range 
  | Form_quant of typar * formula * range 
  | Form_texists of typar * formula * range 
  | Form_paren of formula * range
  | Form_relational of formula * range
  | Form_labeled of byte[] * formula * range
(*   | Form_equals of synexpr * synexpr * range *)

and atom = 
  | Atom_true
  | Atom_false
  | Atom_pred of typ

and pattern = atom

and kind =
  | Kind_unknown
  | Kind_star               (* ::* *)
  | Kind_affine             (* ::A *)
  | Kind_prop
  | Kind_erasable 
  | Kind_tcon of option<ident> * kind * kind       (* 'a::k -> k *)
  | Kind_dcon of option<ident> * typ * kind (* x:t -> k *)

type language = 
  | FSharp 
  | CSharp 
  | Fine
  | F7
  | FStar
  | JavaScript
type externqual = | Nullary 
type externref = {language:language;
                  dll:string;
                  namespce:LongIdent;
                  classname:LongIdent;
                  innerclass:string option;
                  extqual:option<externqual>}
type externreference = 
  | ExternRefId of ident
  | ExternRef of externref

let extern_id = ident("__Extern", 0L)
let mk_extern_ref l d ns c icn eq = {language=l;dll=d;namespce=ns;classname=c;innerclass=icn;extqual=eq}

type logic_array = {array_sel:LongIdent;
                    array_upd:LongIdent;
                    array_emp:LongIdent;
                    array_indom:LongIdent}
type logic_tag =
  | Logic_data 
  | Logic_tfun
  | Logic_array of logic_array
  | Logic_discriminator
  | Logic_projector


type atag = 
  | Assumption
  | Definition
  | ConcreteAssumption

type 
(*   [<StructuralEquality(false); StructuralComparison(false)>] *)
    ModuleImplDecl =
    | Def_open  of LongIdent * range
    | Def_tycon of tyconDefn list * bool * bool * logic_tag list * range (* first bool signals a proposition, second a private type *)
    | Def_let   of bool * binding list * range (* first flag recursion *)
    | Def_expr  of synexpr * range 
    | Def_assume of option<ident> * formula * atag * range (* bool signals ghost *)
    | Def_val    of ident * typ * range
    | Def_extern_val of externreference * ident * typ * range
    | Def_extern_typ of externreference * tyconDefn * range
    | Def_extern_ref of ident * externref * range
    | Def_query of LongIdent * formula * range
    | Def_logic_function of ident * typ * range

and ModuleImplDecls = ModuleImplDecl list

and tyconDefn =
  | TyconDefn of tyconInfo * tyconDefnRepr * range

and 
(*   [<StructuralEquality(false); StructuralComparison(false)>] *)
  tyconDefnRepr = 
  | TyconCore_union of list<funionConstrDecl> * range
  | TyconCore_recd of list<fieldDecl> * range
  | TyconCore_abbrev of typ * range
  | TyconCore_repr_hidden of range

and fieldDecl = 
  | Field of RecdFieldId * typ * range
      
and funionConstrDecl = 
  | UnionConstr of UnionCaseId * unionConstrTypeDecl * range

and unionConstrTypeDecl = 
    (* Normal ML-style declaration *)
  | ConstrFields of list<fieldDecl>
  | ConstrMLType of typ
    (* Fine-style with explicit type constructor notation *)
  | ConstrType of typ

and tyconInfo = 
  | Tycon of LongIdent * kind * TyparDecl list * bool * range
      (* bool is to indicate pretty printing prefer postfix *)

and TyparDecl = 
  | TyparDecl of typar
  | TermparDecl of ident * typ



(* Parser result *)
type pragma = 
  | PRAGMA_LIGHT
  | PRAGMA_MONADIC of typ * typ * typ

type moduleImpl = 
  | ModuleOrNamespaceImpl of LongIdent * option<LongIdent> * ModuleImplDecls *  (* access option *  *)range 

type ParsedImplFileFragment = 
  | AnonTopModuleImpl of ModuleImplDecls * range
  | NamedTopModuleImpl of moduleImpl

type ParsedImplFile = 
  | ParsedImplFile of list<ParsedImplFileFragment> 
  | ParsedImplFileWithPragmas of (list<ParsedImplFileFragment> * list<pragma>)

type QualifiedNameOfFile = 
  | QualifiedNameOfFile of ident 
    member x.Text:string = (let (QualifiedNameOfFile(t)) = x in t.idText)
    member x.Id:ident = (let (QualifiedNameOfFile(t)) = x in t)
    member x.Range:range = (let (QualifiedNameOfFile(t)) = x in t.idRange)


(*----------------------------------------------------------------------
 * AST and parsing utilities.
 *-----------------------------------------------------------------------*)
let _ = Profiling.new_counter "lidOps"
type path = string list 
let ident (s,r) = new ident(s,r)
let text_of_id (id:ident) = id.idText
let path_of_lid lid = List.map text_of_id lid.lid
let lid_of_path path pos = 
  let lid = List.map (fun s -> ident(s,pos)) path in 
    {lid=lid; str=String.concat "." path}
let arr_path_of_lid lid = Array.of_list (List.map text_of_id lid.lid)
let text_of_path path = String.concat "." path
let path_of_text text = String.split ['.'] text 
let text_of_arr_path path = 
    String.concat "." (List.of_array path)
let text_of_lid lid = lid.str
let lid_equals l1 l2 = l1.str = l2.str
let module_name = function 
    ParsedImplFile [NamedTopModuleImpl (ModuleOrNamespaceImpl(lid, _, _, _))] -> Some (text_of_lid lid)
  | _ -> None

(*----------------------------------------------------------------------
 * Construct syntactic AST nodes
 *-----------------------------------------------------------------------*)

let mksyn_id m s = ident(s,m)
let path_to_lid m p = let lid = List.map (mksyn_id m) p in {lid=lid; str=text_of_path p}
let text_to_id0 n = mksyn_id range0 n

(* REVIEW: get rid of this name generator, which is used for the type inference *)
(* variables implicit in the #C syntax *)
let mksyn_new_uniq = let i = ref 0 in fun () -> incr i; !i
let mksyn_item m n = Expr_lid_get(false, lid_of_path [n] m, m)

(* REVIEW: get rid of this state *)
let new_arg_uniq_ref = ref 0 
let mksyn_new_arg_uniq () = incr new_arg_uniq_ref; !new_arg_uniq_ref
let mksyn_spat_var isOpt id = SPat_as (id,id.idRange)

let range_of_synpat p = 
  match p with 
    | Pat_typed(_, _, m) 
    | Pat_lid(_, _, m) 
    | Pat_paren(_,m) 
    | Pat_const(_,m) 
    | Pat_wild m 
    | Pat_as (_,_,_,m)  
    | Pat_array_or_list(_,_,m) 
    | Pat_tuple (_,m) 
    | Pat_recd (_,m) -> m
      
let range_of_syntype ty = 
  match ty with 
  | Type_lid(_,m) | Type_app(_,_,m) 
  | Type_tuple(_,m) | Type_fun(_,_,m)
  | Type_var(_,m) | Type_term_index(_,m) 
  | Type_refinement(_,_,_,_,m) 
  | Type_affine(_, m) | Type_qtyp(_, _, m) 
  | Type_lam(_, _, _, m) | Type_tlam(_, _, m)
  | Type_formula(_, m)
  | Type_ascribed(_, _, m) | Type_paren(_, m) 
  | Type_anon m  -> m

let range_of_synconst c dflt = 
  match c with 
  | Const_string (c,m0) | Const_bytearray (c,m0) -> m0 
  | _ -> dflt
  
let range_of_synexpr = function
    | Expr_paren(_,m) 
    | Expr_const(_,m) 
    | Expr_typed (_,_,m)
    | Expr_tuple (_,m)
    | Expr_list (_,m)
    | Expr_recd (_,_,m)
    | Expr_lambda (_,_,m)
    | Expr_match (_,_,_,m)
    | Expr_app (_,_,m)
    | Expr_tyapp (_,_,m)
    | Expr_let (_,_,_,_,m)
    | Expr_seq (_,_,_,m)
    | Expr_cond (_,_,_,_,m) 
    | Expr_lid_get (_, _, m) 
    | Expr_lvalue_get (_, _, m)  -> m
    | Expr_id_get id -> id.idRange      

let range_of_synformula = function
  | Form_labeled(_, _, m)
  | Form_atom(_, m)
  | Form_paren(_, m)
  | Form_not(_, m)
  | Form_conj(_, _, m)
  | Form_disj(_, _, m)
  | Form_all(_, _, _, m, _, _)
  | Form_exists(_, _, _, m, _, _)
  | Form_impl(_, _, m)
  | Form_iff(_, _, m)
  | Form_ite(_, _, _, m)
  | Form_relational(_, m)
  | Form_quant(_, _, m) -> m

let range_of_syndecl d = 
  match d with 
    | Def_let(_,_,m) 
    | Def_expr(_,m) 
    | Def_tycon(_,_,_,_,m)
    | Def_open (_,m) 
    | Def_assume(_, _, _, m)
    | Def_val(_, _, m)
    | Def_extern_val(_, _, _, m)
    | Def_extern_typ(_, _, m)
    | Def_extern_ref(_, _, m)
    | Def_query(_, _, m) 
    | Def_logic_function(_, _, m) -> m

(* -------------------------------------------------------------------------------- *)


let mksyn_pat_var (id:ident) = Pat_as (Pat_wild id.idRange,id,false,id.idRange)
let mksyn_this_pat_var (id:ident) = Pat_as (Pat_wild id.idRange,id,true,id.idRange)
let mksyn_pat_maybe_var lid m =  Pat_lid (lid,[],m)

let new_arg_name() =
  ("_arg"^string (mksyn_new_arg_uniq()))

let mksyn_new_arg_var m  =
  let nm = new_arg_name()
  let id = mksyn_id m nm
  mksyn_pat_var id, mksyn_item m nm

(* Push non-simple parts of a patten match over onto the r.h.s. of a lambda *)
let rec spat_of_pat p =
  match p with
(*   | Pat_typed(p',ty,m) -> *)
(*       let p2,laterf = spat_of_pat p' *)
(*       SPat_typed(p2,ty,m), *)
(*       laterf *)
  | Pat_as (Pat_wild _,v,_, m) ->
      SPat_as (v, m), (fun e -> e)
  | Pat_paren (p,m) -> spat_of_pat p
  | _ ->
      let m = range_of_synpat p
      (* 'nm' may be a real variable. Maintain its name. *)
      let nm = (match p with Pat_lid({lid=[id]},[],_) -> id.idText | _ -> new_arg_name())
      let id = mksyn_id m nm
      let item = mksyn_item m nm
      mksyn_spat_var false id,
      (fun e -> Expr_match(item,[Clause(p,None,e,m)],false,m))

let rec spats_of_pat p =
    match p with
    | Pat_paren(Pat_typed(p',ty,m), _) 
    | Pat_typed(p',ty,m) ->
        let p2,laterf = spats_of_pat p' in
          (match p2 with 
               (SPats([p], r)) ->  SPats([SPat_typed(p, ty, m)], r), laterf
             | _ ->  failwith "Unhandled composite typed pattern")
            (* //    | Pat_paren (p,m) -> spats_of_pat p *)
(* NS 7/19/11: Multiple patterns are not supported. Tuple patterns are handled by spat_of_pat *)
(*     | Pat_tuple (ps,m) *)
(*     | Pat_paren(Pat_tuple (ps,m),_) -> *)
(*         let ps2,laterf = *)
(*           List.fold_right *)
(*             (fun (p',rhsf) (ps',rhsf') -> *)
(*               p'::ps', *)
(*               (fun x -> rhsf (rhsf' x))) *)
(*             (List.map spat_of_pat ps) *)
(*             ([], (fun x -> x)) *)
(*         SPats (ps2,m), *)
(*         laterf *)
    | Pat_paren(Pat_const (Const_unit,m),_)
    | Pat_const (Const_unit,m) ->
        SPats ([],m),
        (fun e -> e)
    | _ ->
        let m = range_of_synpat p
        let sp,laterf = spat_of_pat p
        SPats ([sp],m),laterf

let push_one_pat (* isMember *) pat rhs =
    let nowpats,laterf = spats_of_pat pat in
      nowpats, Expr_lambda (nowpats, laterf rhs, range_of_synexpr rhs)
  
(* "fun (UnionConstr x) (UnionConstr y) -> body" ==> "fun tmp1 tmp2 -> let (UnionConstr x) = tmp1 in let (UnionConstr y) = tmp2 in body" *)
let PushMultiplePatternsToExpr wholem (* isMember *) pats rhs =
    let nowf,spatsl,rhs2 =
        List.fold_right
            (fun arg (nowf,spatsl,body) ->
              let nowpats,laterf = spats_of_pat arg
              (fun e -> Expr_lambda (nowpats, nowf e,wholem)),
              nowpats::spatsl,
              laterf body)
          pats
          ((fun e -> e),[],rhs)
    spatsl,nowf rhs2

let new_unit_uniq_ref = ref 0
let new_unit_uniq () = incr new_unit_uniq_ref; !new_unit_uniq_ref

(*------------------------------------------------------------------------
 * Inline IL
 *-----------------------------------------------------------------------*)

(* // Helper for parsing the inline IL fragments. *)
(*  let parse_il_instrs s m = *)
(*     try Ilpars.top_instrs Illex.token (Microsoft.FSharp.Text.UnicodeLexing.StringAsLexbuf (Bytes.unicode_bytes_as_string s)) *)
(*     with Parsing.RecoverableParseError -> *)
(*       errorR(Error("error while parsing embedded IL",m)); [| |] *)

(* // Helper for parsing the inline IL fragments. *)
(*  let parse_il_typ s m = *)
(*     try Ilpars.top_typ Illex.token (Microsoft.FSharp.Text.UnicodeLexing.StringAsLexbuf (Bytes.unicode_bytes_as_string s)) *)
(*     with Parsing.RecoverableParseError -> *)
(*       errorR(Error("error while parsing embedded IL type",m)); Il.ecma_mscorlib_refs.Il.typ_Object *)

(*------------------------------------------------------------------------
 * Operator name compilation
 *-----------------------------------------------------------------------*)

let lbrack_get = ".[]"
let lbrack_get2 = ".[,]"
let lbrack_get3 = ".[,,]"
let lbrack_set = ".[]<-"
let lbrack_set2 = ".[,]<-"
let lbrack_set3 = ".[,,]<-"
let lparen_get = ".()"
let lparen_get2 = ".(,)"
let lparen_get3 = ".(,,)"
let lparen_set = ".()<-"
let lparen_set2 = ".(,)<-"
let lparen_set3 = ".(,,)<-"

let opNameTable =
 [ ("-", "op_Subtraction");
   ("[]", "op_Nil");
   ("::", "op_ColonColon");
   ("+", "op_Addition");
   ("~%", "op_Splice");
   ("~%%", "op_SpliceUntyped");
   ("~++", "op_Increment");
   ("~--", "op_Decrement");
   ("*", "op_Multiply");
   ("**", "op_Exponentiation");
   ("/", "op_Division");
   ("@", "op_Append");
   ("^", "op_Concatenate");
   ("%", "op_Modulus");
   ("&&&", "op_BitwiseAnd");
   ("|||", "op_BitwiseOr");
   ("^^^", "op_ExclusiveOr");
   ("<<<", "op_LeftShift");
   ("~~~", "op_LogicalNot");
   (">>>", "op_RightShift");
   ("~+", "op_UnaryPlus");
   ("~-", "op_UnaryNegation");
   ("<=", "op_LessThanOrEqual");
   ("=", "op_Equality");
   (">=", "op_GreaterThanOrEqual");
   ("<", "op_LessThan");
   (">", "op_GreaterThan");
   ("|>", "op_PipeRight");
   ("<|", "op_PipeLeft");
   ("!", "op_Dereference");
   (">>", "op_ComposeRight");
   ("<<", "op_ComposeLeft");
   ("<< >>", "op_TypedQuotationUnicode");
   ("<<| |>>", "op_ChevronsBar");
   ("<@ @>", "op_Quotation");
   ("<@@ @@>", "op_QuotationUntyped");
   ("+=", "op_AdditionAssignment");
   ("-=", "op_SubtractionAssignment");
   ("*=", "op_MultiplyAssignment");
   ("/=", "op_DivisionAssignment");
   ("..", "op_Range");
   (".. ..", "op_RangeStep");
   (lbrack_get, "op_IndexedLookup");
   (lbrack_get2, "op_IndexedLookup2");
   (lbrack_get3, "op_IndexedLookup3");
   (lbrack_set, "op_IndexedAssign");
   (lbrack_set2, "op_IndexedAssign2");
   (lbrack_set3, "op_IndexedAssign3");
   (lparen_get, "op_ArrayLookup");
   (lparen_get2, "op_ArrayLookup2");
   (lparen_get3, "op_ArrayLookup3");
   (lparen_set, "op_ArrayAssign");
   (lparen_set2, "op_ArrayAssign2");
   (lparen_set3, "op_ArrayAssign3");
   ]

let InOpNameTable id = 
  List.exists (fun (_, id') -> id = id') opNameTable

let opCharTranslateTable =
  [ ( '>', "Greater");
    ( '<', "Less");
    ( '+', "Plus");
    ( '-', "Minus");
    ( '*', "Multiply");
    ( '=', "Equals");
    ( '~', "Twiddle");
    ( '%', "Percent");
    ( '.', "Dot");
    ( '$', "Dollar");
    ( '&', "Amp");
    ( '|', "Bar");
    ( '@', "At");
    ( '#', "Hash");
    ( '^', "Hat");
    ( '!', "Bang");
    ( '?', "Qmark");
    ( '/', "Divide");
    ( '.', "Dot");
    ( ':', "Colon");
    ( '(', "LParen");
    ( ',', "Comma");
    ( ')', "RParen");
    ( ' ', "Space");
    ( '[', "LBrack");
    ( ']', "RBrack"); ]

let IsOpName =
  let t = Zset.addL  (List.map fst opCharTranslateTable) (Zset.empty compare)
  fun n ->
    let r = ref false
    for i = 0 to String.length n - 1 do
      if Zset.mem n.[i] t then r := true;
    done;
    !r

let CompileOpName' opNameTable =
  let t = Map.ofList opNameTable
  let t2 = Map.ofList opCharTranslateTable
  fun n ->
      match t.TryFind(n) with
      | Some(x) -> x
      | None ->
          if IsOpName n then
            let r = ref []
            for i = 0 to String.length n - 1 do
              let c = n.[i]
              let c2 = match t2.TryFind(c) with Some(x) -> x | None -> String.make 1 c
              r := c2 :: !r
            done;
            "op_"^(String.concat "" (List.rev !r))
          else n

let CompileOpName = CompileOpName' opNameTable
let CompilePrefixOpName = CompileOpName' (List.tl opNameTable)
let IsMangledOpName (n:string) = n.Length >= 3 && String.sub n 0 3 = "op_"
                         
let rec first f = function
  | [] -> None
  | hd::tl -> match f hd with 
      | Some x -> Some x
      | _ -> first f tl
  
let DecompileOpName =
  let t = Map.ofList (List.map (fun (x,y) -> (y,x)) opNameTable)
  let t2 = Map.ofList (List.map (fun (x,y) -> (y,x)) opCharTranslateTable)
  fun n ->
      match t.TryFind(n) with
      | Some(x) -> x
      | None ->
          if n.Length >= 3 && String.sub n 0 3 = "op_" then
            let rec loop (remaining:string) =
                let l = remaining.Length
                if l = 0 then Some(remaining) else
                let choice =
                  opCharTranslateTable |> first (fun (a,b) ->
                      let bl = b.Length
                      if bl <= l && String.sub remaining 0 bl = b then
                        Some(String.make 1 a, String.sub remaining bl (l - bl))
                      else None)
                    
                match choice with
                | Some (a,remaining2) ->
                    match loop remaining2 with
                    | None -> None
                    | Some a2 -> Some(a^a2)
                | None -> None (* giveup *)
            match loop (String.sub n 3 (n.Length - 3)) with
            | Some res -> res
            | None -> n
          else n

let opname_Cons = CompileOpName "::"
let opname_Nil = CompileOpName "[]"
let opname_Equals = CompileOpName "="

(*------------------------------------------------------------------------
 * AST constructors
 *-----------------------------------------------------------------------*)

let lbrack_set_opname  = (CompileOpName lbrack_set)
let lbrack_set2_opname  = (CompileOpName lbrack_set2)
let lbrack_set3_opname  = (CompileOpName lbrack_set3)
let lparen_set_opname  = (CompileOpName lparen_set)
let lparen_set2_opname = (CompileOpName lparen_set2)
let lparen_set3_opname = (CompileOpName lparen_set3)
let lbrack_get_opname  = (CompileOpName lbrack_get)
let lbrack_get2_opname  = (CompileOpName lbrack_get2)
let lbrack_get3_opname  = (CompileOpName lbrack_get3)
let lparen_get_opname  = (CompileOpName lparen_get)
let lparen_get2_opname = (CompileOpName lparen_get2)
let lparen_get3_opname = (CompileOpName lparen_get3)
(* let mksyn_lid_get m path n = Expr_lid_get(false,path_to_lid m path @ [mksyn_id m n],m) *)
(* let mksyn_mod_item m modul n = mksyn_lid_get m [modul] n *)
let mk_oper opm oper = mksyn_item opm (CompileOpName oper)
let mk_prefix_oper opm oper = mksyn_item opm (CompilePrefixOpName oper)
let mksyn_infix opm m l oper r = Expr_app (Expr_app (mk_oper opm oper,l,m), r,m)
let mksyn_bifix m oper l r = Expr_app (Expr_app (mk_oper m oper,l,m), r,m)
let mksyn_trifix m oper  x1 x2 x3 = Expr_app (Expr_app (Expr_app (mk_oper m oper,x1,m), x2,m), x3,m)
let mksyn_quadfix m oper  x1 x2 x3 x4 = Expr_app (Expr_app (Expr_app (Expr_app (mk_oper m oper,x1,m), x2,m), x3,m),x4,m)
let mksyn_quinfix m oper  x1 x2 x3 x4 x5 = Expr_app (Expr_app (Expr_app (Expr_app (Expr_app (mk_oper m oper,x1,m), x2,m), x3,m),x4,m),x5,m)
let mksyn_prefix m oper x = Expr_app (mk_prefix_oper m oper, x,m)
let mksyn_constr m n = lid_of_path [(CompileOpName n)] m 

let mksyn_dot_lbrack_set  m a b c = mksyn_trifix m lbrack_set a b c
let mksyn_dot_lbrack_set2  m a b c = mksyn_trifix m lbrack_set2 a b c
let mksyn_dot_lbrack_set3  m a b c = mksyn_trifix m lbrack_set3 a b c
let mksyn_dot_lparen_set  m a b c = mksyn_trifix m lparen_set a b c
let mksyn_dot_lparen_set2  m a b c = mksyn_trifix m lparen_set2 a b c
let mksyn_dot_lparen_set3  m a b c = mksyn_trifix m lparen_set3 a b c
(* let mksyn_dot_lbrack_get  m mDot a b   = Expr_lbrack_get(a,[b],mDot,m) *)

(* let mksyn_dot_lbrack_slice_get  m mDot arr (x,y) =  *)
(*     Expr_lbrack_get(arr,[x;y],mDot,m) *)

(* let mksyn_dot_lbrack_slice2_get  m mDot arr (x1,y1) (x2,y2) =  *)
(*     Expr_lbrack_get(arr,[x1;y1;x2;y2],mDot,m) *)

let mksyn_dot_lparen_get  m a b   =
  match b with
  | Expr_tuple ([_;_],_)   -> mksyn_infix m m a lparen_get2 b
  | Expr_tuple ([_;_;_],_) -> mksyn_infix m m a lparen_get3 b
  | _ -> mksyn_infix m m a lparen_get b
let mksyn_unit m = Expr_const(Const_unit,m)
let mksyn_unit_pat m = Pat_const(Const_unit,m)
let mksyn_delay m e = Expr_lambda (SPats ([mksyn_spat_var false (mksyn_id m ("_delay"^string(new_unit_uniq())))],m), e, m)

let (|Expr_lid_or_id_get|_|) inp =
    match inp with
    | Expr_lid_get(isOpt,lid, m) -> Some (isOpt,lid,m)
(*     | Expr_id_get(id) -> Some (false,[id], id.idRange) *)
    | _ -> None

let (|Expr_single_id_get|_|) inp =
    match inp with
    | Expr_lid_get(false,{lid=[id]}, _) -> Some id.idText
(*     | Expr_id_get(id) -> Some id.idText *)
    | _ -> None
    
(* let rec mksyn_assign m l r = *)
(*     let m = union_ranges (range_of_synexpr l) (range_of_synexpr r) *)
(*     match l with *)
(*     //| Expr_paren(l2,m2)  -> mksyn_assign m l2 r *)
(*     | Expr_lid_or_id_get(false,v,_)  -> Expr_lid_set (v,r,m) *)
(*     | Expr_lvalue_get(e,v,_)  -> Expr_lvalue_set (e,v,r,m) *)
(*     | Expr_lbrack_get(e1,e2,mDot,_)  -> Expr_lbrack_set (e1,e2,r,mDot,m) *)
(*     | Expr_constr_field_get (x,y,z,_) -> Expr_constr_field_set (x,y,z,r,m) *)
(*     | Expr_app (Expr_app(Expr_single_id_get(nm), a, _),b,_) when nm = lparen_get_opname -> *)
(*         mksyn_dot_lparen_set m a b r *)
(*     | Expr_app (Expr_app(Expr_single_id_get(nm), a, _),b,_) when nm = lparen_get2_opname -> *)
(*         mksyn_dot_lparen_set2 m a b r *)
(*     | Expr_app (Expr_app(Expr_single_id_get(nm), a, _),b,_) when nm = lparen_get3_opname -> *)
(*         mksyn_dot_lparen_set3 m a b r *)
(*     | Expr_app (Expr_app(Expr_single_id_get(nm), a, _),b,_) when nm = lbrack_get_opname -> *)
(*         mksyn_dot_lbrack_set m a b r *)
(*     | Expr_app (Expr_app(Expr_single_id_get(nm), a, _),b,_) when nm = lbrack_get2_opname -> *)
(*         mksyn_dot_lbrack_set2 m a b r *)
(*     | Expr_app (Expr_app(Expr_single_id_get(nm), a, _),b,_) when nm = lbrack_get3_opname -> *)
(*         mksyn_dot_lbrack_set3 m a b r *)
(*     | Expr_app (Expr_lid_get(false,v,_),x,_)  -> Expr_lid_indexed_set (v,x,r,m) *)
(*     | Expr_app (Expr_lvalue_get(e,v,_),x,_)  -> Expr_lvalue_indexed_set (e,v,x,r,m) *)
(*     |   _ -> errorR(Error("invalid expression on left of assignment",m));  Expr_const(Const_unit,m) *)

let dot_lid lid id = {lid=lid.lid@[id]; str=lid.str ^"."^id.idText}
let rec mksyn_dot m l r =
    match l with
      | Expr_lid_get(isOpt,lid,_) -> Expr_lid_get(isOpt,dot_lid lid r,m) 
      | Expr_lvalue_get(e,lid,_) -> Expr_lvalue_get(e,dot_lid lid r,m)
      | expr -> Expr_lvalue_get(expr, lid_of_path [r.idText] m,m)
          
(* let rec mksyn_dotn m l r = *)
(*   match l with *)
(*       //| Expr_paren(l2,m2)  -> mksyn_dotn m l2 r *)
(*     | Expr_app (Expr_app(Expr_single_id_get(nm), a, _),Expr_lid_get (false,cid,_),_) when nm = lparen_get_opname-> *)
(*         Expr_constr_field_get (a,cid, r,m) *)
(*     |   _ -> errorR(Error("array access or constructor field access expected",m));  Expr_const(Const_unit,m) *)
        
let mksyn_match_lambda (isMember,isExnMatch,wholem,mtch) =
  let p,pe = mksyn_new_arg_var wholem in
  let _,e = PushMultiplePatternsToExpr wholem  [p] (Expr_match(pe,mtch,isExnMatch,wholem)) in
    e

let mksyn_match_lambdas isMember wholem ps e =
    let _,e =  PushMultiplePatternsToExpr wholem  ps e
    e

let mksyn_cons x y =
    let xm = range_of_synexpr x
    Expr_app(Expr_id_get(mksyn_id xm opname_Cons),Expr_tuple([x;y],xm),xm)

let mksyn_list m l =
    List.fold_right mksyn_cons l (Expr_id_get(mksyn_id m opname_Nil))

let mksyn_cons_pat x y =
    let xm = range_of_synpat x
    Pat_lid (mksyn_constr xm opname_Cons, [Pat_tuple ([x;y],xm)], xm)

let mksyn_list_pat m l =
    List.fold_right mksyn_cons_pat l (Pat_lid(mksyn_constr m opname_Nil,  [], m))

(*------------------------------------------------------------------------
 * Arities of members
 * Members have strongly syntactically constrained arities.  We must infer
 * the arity from the syntax in order to have any chance of handling recursive
 * cross references during type inference.
 *
 * So we record the arity for:
   StaticProperty --> [1]               -- for unit arg
   this.StaticProperty --> [1;1]        -- for unit arg
   StaticMethod(args) --> map InferArgSynInfoFromSimplePat args
   this.InstanceMethod() --> 1 :: map InferArgSynInfoFromSimplePat args
   this.InstanceProperty with get(argpat) --> 1 :: [InferArgSynInfoFromSimplePat argpat]
   StaticProperty with get(argpat) --> [InferArgSynInfoFromSimplePat argpat]
   this.InstanceProperty with get() --> 1 :: [InferArgSynInfoFromSimplePat argpat]
   StaticProperty with get() --> [InferArgSynInfoFromSimplePat argpat]
   
   this.InstanceProperty with set(argpat)(v) --> 1 :: [InferArgSynInfoFromSimplePat argpat; 1]
   StaticProperty with set(argpat)(v) --> [InferArgSynInfoFromSimplePat argpat; 1]
   this.InstanceProperty with set(v) --> 1 :: [1]
   StaticProperty with set(v) --> [1]
 *-----------------------------------------------------------------------*)

(* module SynInfo = begin *)
(*     let unnamedTopArg1 = ArgSynInfo([],false,None) *)
(*     let unnamedTopArg = [unnamedTopArg1] *)
(*     let unitArgData = unnamedTopArg *)
(*     let unnamedRetVal = ArgSynInfo([],false,None) *)
(*     let selfMetadata = unnamedTopArg *)

(*     let HasNoArgs (ValSynInfo(args,_)) = isNil args *)
(*     let HasOptionalArgs (ValSynInfo(args,_)) = List.exists (List.exists (fun (ArgSynInfo(_,isOptArg,_)) -> isOptArg)) args *)
(*     let IncorporateEmptyTupledArg (ValSynInfo(args,retInfo)) = ValSynInfo([]::args,retInfo) *)
(*     let IncorporateSelfArg (ValSynInfo(args,retInfo)) = ValSynInfo(selfMetadata::args,retInfo) *)
(*     let IncorporateSetterArg (ValSynInfo(args,retInfo)) = ValSynInfo(args@[unnamedTopArg],retInfo) *)
(*     let NumCurriedArgs(ValSynInfo(args,_)) = List.length args *)
(*     let AritiesOfArgs (ValSynInfo(args,_)) = List.map List.length args *)
(*     let AttribsOfArgData (ArgSynInfo(attribs,_,_)) = attribs *)
(*     let IsOptionalArg (ArgSynInfo(_,isOpt,_)) = isOpt *)
(*     let rec InferArgSynInfoFromSimplePat attribs p = *)
(*         match p with *)
(*         | SPat_as(nm,_,isOpt,_) -> *)
(*            (\* if List.length attribs <> 0 then dprintf "List.length attribs = %d\n" (List.length attribs); *\) *)
(*            ArgSynInfo(attribs, isOpt, Some nm) *)
(*         | SPat_typed(a,_,_) -> InferArgSynInfoFromSimplePat attribs a *)
(*         | SPat_attrib(a,attribs2,_) -> InferArgSynInfoFromSimplePat (attribs @ attribs2) a *)
      
(*     let rec InferArgSynInfoFromSimplePats x = *)
(*         match x with *)
(*         | SPats(ps,_) -> List.map (InferArgSynInfoFromSimplePat []) ps *)
(*         | SPats_typed(ps,_,_) -> InferArgSynInfoFromSimplePats ps *)

(*     let InferArgSynInfoFromPat p = *)
(*         let sp,_ = spats_of_pat p *)
(*         InferArgSynInfoFromSimplePats sp *)

(*     // Curried members (e.g. "this.f x1 x2 x3 = ...") are currently compiled and called as *)
(*     // members returning functions, (e.g. "this.f x1 = (fun x2 x3 -> ...)") *)
(*     // That is, before adding the 'this' pointer the arities of members are limited to [], [_], and also *)
(*     // [_;_] in the indexed property setter case *)
(*     // *)
(*     // REVIEW: we have a design choice here.  Curried members could be given arity N (where N is the number of curried *)
(*     // arguments).  This would allow us to compile them as non-curried, as with modules. Since curried members are in *)
(*     // many ways the natural way to write code in F# there could be considerable advantages here. Of course signatures *)
(*     // would have to reveal the "curriedness" of the member just as with module values. The consistence with modules *)
(*     // is very appealing. *)
(*     let TrimMemberArgs memFlags infosForArgs = *)
(*         match infosForArgs with *)
(*         // Transform a property declared using '[static] member P = expr' to a method taking a "unit" argument *)
(*         | [] when memFlags=MemberKindMember -> [] :: infosForArgs *)
(*         | [] -> infosForArgs *)
(*         // Maintain the arity of a property declared using '[static] member P with set v1 v2 = expr' *)
(*         | [h1;h2] when memFlags=MemberKindPropertySet -> infosForArgs *)
(*         | h1 :: _ -> [h1] *)

(*     let InferLambdaArgs origRhsExpr = *)
(*         let rec loop e = *)
(*             match e with *)
(*             | Expr_lambda(false,spats,rest,_) -> *)
(*                 InferArgSynInfoFromSimplePats spats :: loop rest *)
(*             | _ -> [] *)
(*         loop origRhsExpr *)

(*     let InferSynReturnData retInfo = *)
(*         match retInfo with *)
(*         | None -> unnamedRetVal *)
(*         | Some((_,retInfo),_) -> retInfo *)

(*     let emptyValSynInfo = ValSynInfo([],unnamedRetVal) *)
(*     let emptyValSynData = ValSynData(None,emptyValSynInfo,None) *)

(*     let InferValSynData memberFlagsOpt pat retInfo origRhsExpr = *)

(*         let infosForExplicitArgs = *)
(*             match pat with *)
(*             | Some(Pat_lid(_,_,curriedArgs,_,m)) -> List.map InferArgSynInfoFromPat curriedArgs *)
(*             | _ -> [] *)

(*         let retInfo = InferSynReturnData retInfo *)

(*         match memberFlagsOpt with *)
(*         | None -> *)
(*             let infosForLambdaArgs = InferLambdaArgs origRhsExpr *)
(*             let infosForArgs = infosForExplicitArgs @ infosForLambdaArgs *)
(*             // Make sure only the first argument has unit elimination *)
(*             let infosForArgs = infosForArgs |> List.mapi (fun i x -> match x with [] when i > 0 -> unitArgData | _ -> x) *)
(*             ValSynData(None,ValSynInfo(infosForArgs,retInfo),None) *)
(*         | Some memFlags  -> *)
(*             let infosForObjArgs = *)
(*                 if memFlags.memFlagsInstance then [ selfMetadata ] else [] *)

(*             let infosForArgs = TrimMemberArgs memFlags.memFlagsKind infosForExplicitArgs *)
            
(*             let argInfos = infosForObjArgs @ infosForArgs *)
(*             ValSynData(Some(memFlags),ValSynInfo(argInfos,retInfo),None) *)
(* end *)


let mksyn_binding_rhs rhsExpr retInfo =
  let rhsExpr,retTyOpt =
    match retInfo with
      | Some (ty, tym) -> Expr_typed(rhsExpr,ty,tym), Some(ty,tym)
      | None -> rhsExpr,None in
    rhsExpr, retTyOpt

let mksyn_binding headPat (bindm,wholem,retInfo,origRhsExpr,rhsRange) =
    let rhsExpr,retTyOpt = mksyn_binding_rhs origRhsExpr retInfo in
      Binding (NormalBinding, headPat, BindingExpr(retTyOpt,rhsExpr), bindm)

(* let NonVirtualMemberFlags q k =  *)
(*   { memFlagsKind=k; memFlagsOverloadQualifier=q;  memFlagsInstance=true;  memFlagsVirtual=false;  *)
(*     memFlagsAbstract=false; memFlagsOverride=false; memFlagsFinal=false } *)
(* let CtorMemberFlags q =      { memFlagsOverloadQualifier=q;memFlagsKind=MemberKindConstructor; memFlagsInstance=false; memFlagsVirtual=false; memFlagsAbstract=false; memFlagsOverride=false;  memFlagsFinal=false } *)
(* let ClassCtorMemberFlags =      { memFlagsOverloadQualifier=None;memFlagsKind=MemberKindClassConstructor; memFlagsInstance=false; memFlagsVirtual=false; memFlagsAbstract=false; memFlagsOverride=false;  memFlagsFinal=false } *)
(* let OverrideMemberFlags q k =   { memFlagsKind=k; memFlagsOverloadQualifier=q;  memFlagsInstance=true;  memFlagsVirtual=false;  memFlagsAbstract=false; memFlagsOverride=true;  memFlagsFinal=false } *)
(* let AbstractMemberFlags q k =   { memFlagsKind=k; memFlagsOverloadQualifier=q;  memFlagsInstance=true;  memFlagsVirtual=false;  memFlagsAbstract=true;  memFlagsOverride=false;  memFlagsFinal=false } *)
(* let StaticMemberFlags q k = { memFlagsKind=k; memFlagsOverloadQualifier=q;  memFlagsInstance=false; memFlagsVirtual=false; memFlagsAbstract=false; memFlagsOverride=false;  memFlagsFinal=false } *)

(* let inferredTyparDecls = ValTyparDecls([],true,[]) *)
(* let noInferredTypars = ValTyparDecls([],false,[]) *)

(*------------------------------------------------------------------------
!* Lexer args: status of #if/#endif processing.
 *-----------------------------------------------------------------------*)
  
type ifdefStackEntry = IfDefIf | IfDefElse
type ifdefStack = ifdefStackEntry list ref

(*------------------------------------------------------------------------
 * The parser defines a number of tokens for whitespace and
 * comments eliminated by the lexer.  These carry a specification of
 * a continuation for the lexer when used in scenarios where we don't
 * care about whitespace.
 *-----------------------------------------------------------------------*)

type lexcont =
    | AT_hashif of ifdefStackEntry list * range
    | AT_token of ifdefStackEntry list
    | AT_ifdef_skip of ifdefStackEntry list * int * range
    | AT_string of ifdefStackEntry list *range
    | AT_vstring of ifdefStackEntry list * range
    | AT_comment of ifdefStackEntry list * int * range
    | AT_comment_string of ifdefStackEntry list * int * range
    | AT_camlonly of ifdefStackEntry list * range
    
    member x.IfdefStack
        with get() =
            match x with
            | AT_hashif (ifd,_)
            | AT_token (ifd)
            | AT_ifdef_skip (ifd,_,_)
            | AT_string (ifd,_)
            | AT_vstring (ifd,_)
            | AT_comment (ifd,_,_)
            | AT_comment_string (ifd,_,_)
            | AT_camlonly (ifd,_) -> ifd

(* (\*------------------------------------------------------------------------ *)
(*  * XML doc pre-processing *)
(*  *-----------------------------------------------------------------------*\) *)

(* // chop leading spaces (well, this isn't very efficient, is it?)  *)
(* let rec trimSpaces str = if has_prefix str " " then trimSpaces (drop_prefix str " ") else str *)
     
(* let rec processLines lines = *)
(*     match lines with  *)
(*     | [] -> [] *)
(*     | (lineA::rest) as lines -> *)
(*         let lineAT = trimSpaces lineA *)
(*         if lineAT = "" then processLines rest *)
(*         else if has_prefix lineAT "<" then lines *)
(*         else ["<summary>"] @ lines @ ["</summary>"]  *)

(* let ProcessXMLDoc (XMLDoc lines) =  *)
(*     let lines = processLines (Array.to_list lines) *)
(*     if lines.Length = 0 then emptyXMLDoc  *)
(*     else XMLDoc (Array.ofList lines) *)


(*------------------------------------------------------------------------
 * Parser/Lexer state
 *-----------------------------------------------------------------------*)

exception SyntaxError of obj * string * range 

type ConcreteSyntaxSink =
    { MatchPair: (range -> range -> unit);
      StartName: (range -> unit);
      QualifyName: (range -> range -> unit);
      StartParameters: pos -> unit;
      NextParameter: pos -> unit;
      EndParameters: pos -> unit;  }

let pos_of_lexpos (p:Microsoft.FSharp.Text.Lexing.Position) =
    mk_pos p.Line p.Column

let mksyn_range (p1:Microsoft.FSharp.Text.Lexing.Position) p2 =
    mk_file_idx_range (decode_file_idx p1.FileName) (pos_of_lexpos p1) (pos_of_lexpos p2)

let GetLexerRange (lexbuf:Microsoft.FSharp.Text.Lexing.LexBuffer<char>) = (* UnicodeLexing.Lexbuf) = *)
  mksyn_range lexbuf.StartPos lexbuf.EndPos

let GetParserLexbuf (parseState: Microsoft.FSharp.Text.Parsing.IParseState) =
(*   assert (parseState.ParserLocalStore.ContainsKey("LexBuffer")); *)
(*   assert (parseState.ParserLocalStore.["LexBuffer"] :? UnicodeLexing.Lexbuf); *)
  (parseState.ParserLocalStore.["LexBuffer"] :?> Microsoft.FSharp.Text.Lexing.LexBuffer<char>)
    
(* The key into the ParserLocalStore and BufferLocalStore used to hold the concreateSyntaxSink *)
let concreteSyntaxSinkKey = "ConcreteSyntaxSink"
  
let GetConcreteSyntaxSink (parseState: Microsoft.FSharp.Text.Parsing.IParseState) =
  if parseState.ParserLocalStore.ContainsKey(concreteSyntaxSinkKey) then
    (parseState.ParserLocalStore.[concreteSyntaxSinkKey] :?> ConcreteSyntaxSink option)
  else
    let lexbuf = GetParserLexbuf parseState in
    let res =
      if lexbuf.BufferLocalStore.ContainsKey(concreteSyntaxSinkKey) then
        (assert (lexbuf.BufferLocalStore.[concreteSyntaxSinkKey] :? ConcreteSyntaxSink);
         Some (lexbuf.BufferLocalStore.[concreteSyntaxSinkKey] :?> ConcreteSyntaxSink) )
      else
        None in
      parseState.ParserLocalStore.[concreteSyntaxSinkKey] <- res;
      res

let SetConcreteSyntaxSink (lexbuf:Microsoft.FSharp.Text.Lexing.LexBuffer<char> (*UnicodeLexing.Lexbuf*)) (concreteSyntaxSink: ConcreteSyntaxSink option) =
  match concreteSyntaxSink with
    | None ->
        ()
    | Some r ->
        lexbuf.BufferLocalStore.[concreteSyntaxSinkKey] <- r

(* Get the range corresponding to the result of a grammar rule while it is being reduced *)
let lhs (parseState: Microsoft.FSharp.Text.Parsing.IParseState) =
  let p1,p2 = parseState.ResultRange in
    mksyn_range p1 p2

(* Get the position corresponding to the start of one of the r.h.s. symbols of a grammar rule while it is being reduced *)
let rhspos (parseState: Microsoft.FSharp.Text.Parsing.IParseState) n =
  pos_of_lexpos (fst (parseState.InputRange(n)))

(* /// Get the range covering two of the r.h.s. symbols of a grammar rule while it is being reduced *)
let rhs2 (parseState: Microsoft.FSharp.Text.Parsing.IParseState) n m =
    let p1 = parseState.InputRange(n) |> fst
    let p2 = parseState.InputRange(m) |> snd
    mksyn_range p1 p2

(* /// Get the range corresponding to one of the r.h.s. symbols of a grammar rule while it is being reduced *)
let rhs (parseState: Microsoft.FSharp.Text.Parsing.IParseState) n =
    let p1,p2 = parseState.InputRange(n)
    mksyn_range p1 p2

let MatchPair parseState p1 p2 =
    match GetConcreteSyntaxSink(parseState) with
    | None -> ()
    | Some snk -> snk.MatchPair (rhs parseState p1) (rhs parseState p2)

let StartName parseState m =
    match GetConcreteSyntaxSink(parseState) with
    | None -> ()
    | Some snk -> snk.StartName m

let QualifyName parseState m1 m2 =
    match GetConcreteSyntaxSink(parseState) with
    | None -> ()
    | Some snk -> snk.QualifyName m1 m2

(* // "System.   Name"  counts as two long names, "System.Name" counts as one  *)
(* // This gives better intellisense  *)
let qualifyNameIfAlongside parseState m1 m2 =
    if pos_geq (end_of_range m1) (start_of_range m2) then
        QualifyName parseState m1 m2
    else
        QualifyName parseState m1 m1;
        StartName parseState m2
         
let StartParameters parseState p =
    match GetConcreteSyntaxSink(parseState) with
    | None -> ()
    | Some snk -> snk.StartParameters p

let NextParameter parseState p =
    match GetConcreteSyntaxSink(parseState) with
    | None -> ()
    | Some snk -> snk.NextParameter p

let EndParameters parseState p =
    match GetConcreteSyntaxSink(parseState) with
    | None -> ()
    | Some snk -> snk.EndParameters p

(*------------------------------------------------------------------------
 * XMLDoc F# lexer/parser state (thread local)
 *-----------------------------------------------------------------------*)
type xmlDoc = XMLDoc of string[]
let emptyXMLDoc = XMLDoc[| |]

// The key into the BufferLocalStore used to hold the current accumulated XmlDoc lines
let xmlDocKey = "XmlDoc"

let ClearXMLDoc (lexbuf:Microsoft.FSharp.Text.Lexing.LexBuffer<char> (*UnicodeLexing.Lexbuf*)) =
    lexbuf.BufferLocalStore.[xmlDocKey] <- box<string list>([])

let SaveXMLDoc (lexbuf:Microsoft.FSharp.Text.Lexing.LexBuffer<char> (*UnicodeLexing.Lexbuf*)) line =
    let prev =
        if lexbuf.BufferLocalStore.ContainsKey(xmlDocKey) then
            unbox<string list>(lexbuf.BufferLocalStore.[xmlDocKey])
        else
            []
    lexbuf.BufferLocalStore.[xmlDocKey] <- box(line :: prev)

let GrabXML (lexbuf:Microsoft.FSharp.Text.Lexing.LexBuffer<char> (*UnicodeLexing.Lexbuf*))  =
    let revXMLs =
           if lexbuf.BufferLocalStore.ContainsKey(xmlDocKey) then
               unbox<string list>(lexbuf.BufferLocalStore.[xmlDocKey])
           else
               []
    ClearXMLDoc lexbuf;
    XMLDoc (Array.ofList (List.rev revXMLs))

let DumpXMLDoc note (XMLDoc lines) =
    printf "\nXMLDoc: %s\n" note;
    Array.iter (printf "  %s\n") lines;
    XMLDoc lines

let MergeXmlDoc (XMLDoc lines) (XMLDoc lines') = XMLDoc (Array.append lines lines')

(* /// Name generators.  It is hard to generate names that are stable, nice *)
(* /// and unique (where stable means they tend not to change as you make modifications *)
(* /// to the source code,and nice means you use simple identifiers where possible, *)
(* /// and unique means they are unique across the a compilation unit). *)
(* /// *)
(* /// In general these should only be used in the backend. *)

(* //NOTE: this code needs to be rewritten *)
(* // *)
(* // First: For a given basename, create unique names for each uniq. *)
(* // State: unames = (basename,(uniq,basename^suffix) table,nextN) *)
(* // *)
(* // For efficiency: *)
(* // - storing the final string so it is not built on each lookup. *)
(* // - lookups for existing entries do not modify tables. *)
(* //  *)
(* // For basename, Given uniq. *)
(* // If uniq is known, get it's uname. *)
(* // Otherwise, *)
(* //   generate the next uname, update (mutate) state, and have uname. *)
   
type StableNiceNameGenerator() =
    let newUniqueNames basename = (basename,Hashtbl.create 10,ref 0)      (* NB: creates state *)
    let suffixOfN = function 0 -> "" | n -> "_" ^ string n
    let unameForUnique (basename,unamesHT,nextR) uniq =                  (* NB: unamesHT, nextR may mutate *)
        if Hashtbl.mem unamesHT uniq then
            let uname = Hashtbl.find unamesHT uniq
            uname
        else
            (* create fresh uname for (basename,uniq) *)
            let n = !nextR
            let uname = basename ^ suffixOfN n
            (* mutate state (which is associated with basename) *)
            nextR := n+1;
            Hashtbl.add unamesHT uniq uname;
            uname

    // Second: Extend to (basename -> unames) table.
    // basenameHT - (basename,unames) table, NB: "unames" mutates.
    let basenameHT = Hashtbl.create 100
    let unameForBasenameUnique basename uniq =
        let unames =
            if not (basenameHT.ContainsKey basename) then
                basenameHT.[basename] <- newUniqueNames basename;  // NB: log it against basename
            basenameHT.[basename]

        unameForUnique unames uniq

    member x.Reset () = Hashtbl.clear basenameHT

    // Third: actually basenames come from combining (base,mopt : range option)
    member x.Apply basicName mopt uniq =
        let basename =
            match mopt with
            | Some m -> basicName ^ "_"^ string (start_line_of_range m)
            | None   -> basicName
        unameForBasenameUnique basename uniq
   
type NiceNameGenerator() =

    let newId = let i = ref 0 in fun () -> incr i; !i
    let StableNiceNameGenerator =  StableNiceNameGenerator()
    member x.Apply basicName m = StableNiceNameGenerator.Apply basicName (Some m) (newId())
    member x.Reset() = StableNiceNameGenerator.Reset ()

let nng = NiceNameGenerator()

let _ =  
  errorHandler :=
    (fun (e:exn) -> 
       match e with
         | SyntaxError (ctx, msg, r) -> 
             let msg = sprintf "Syntax error %s: %s\n" (string_of_range r) msg in
               raise (Util.Failure msg)
         | Error(s,m) -> 
             let msg = sprintf "Syntax error %s: %s\n" s (string_of_range m) in
               raise (Util.Failure msg)
         | _ -> 
             let msg = "no error handler installed\n" in
               (printfn "%A" e; raise (Util.Failure msg)))
      
let range_of_lid (lid:LongIdent) = 
  let rec last = function
      [tl] -> tl
    | hd::tl -> last tl in
  let hd = List.hd lid.lid in
  let tl = last lid.lid in
    tl.idRange
    (* Range.union_ranges (hd.idRange) (tl.idRange) *)

let lid_with_range lid r = 
  let p = path_of_lid lid in 
    lid_of_path r

open Util    
exception LocalFail
let lid_of_text = (lid_of_path -<- path_of_text)
let mkExternRefOpt pos (map:list<string * string>) = 
  try
    let find_opt id = 
      match Util.findOpt (fun (id',_) -> id=id') map with 
        | None -> None
        | Some(_,x) -> Some x in 
    let find id = match find_opt id with 
      | None -> raise LocalFail
      | Some x -> x in 
    let lang = find "language" in
    let dll = find "dll" in
    let ns = lid_of_text (find "namespace") pos in
    let cn = lid_of_text (find "classname") pos in
    let icn = find_opt "innerclass" in 
    let eq = match (find_opt "externqual") with 
        None -> None
      | Some "nullary" -> Some Nullary in
    let lang = match lang with 
      | "F#" -> FSharp
      | "C#" -> CSharp
      | "Fine" -> Fine
      | "F7" -> F7
      | "F*" -> FStar
      | "JavaScript" -> JavaScript
      | _ -> raise LocalFail in
    Some (mk_extern_ref lang dll ns cn icn eq)
  with 
      LocalFail -> None

let fieldsAsExternRefOpt pos fields = 
  try
    let map = fields |> List.map (fun ((_, (id:ident)), e) -> match e with 
      | Expr_const(Const_string(f, _), _) -> id.idText, Util.unicodeEncoding.GetString(f)
      | _ -> raise LocalFail) in 
    mkExternRefOpt pos map
  with 
      LocalFail -> None

let exprRecdAsExternRefOpt pos = function 
  | Expr_recd(None, fields, _) -> fieldsAsExternRefOpt pos fields
  | _ -> None
