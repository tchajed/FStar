#light "off"

module Microsoft.FStar.KindAbbrevs
open Absyn

let Kind_prop = withhash Kind_prop
let Kind_star = withhash Kind_star
let Kind_erasable = withhash Kind_erasable
let Kind_unknown = withhash Kind_unknown
let Kind_affine = withhash Kind_affine
let Kind_tcon x = withhash (Kind_tcon x)
let Kind_dcon x = withhash (Kind_dcon x)
let Kind_boxed x = withhash (Kind_boxed x)

