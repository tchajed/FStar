#light "off"
// (c) Microsoft Corporation. All rights reserved
module Microsoft.FStar.AbsynUtils

open Absyn
open Util
open Profiling
open KindAbbrevs

let unbox = function
  | Kind_boxed k -> k
  | k -> k

let is_lid_equality x = 
  (Sugar.lid_equals x Const.eq_lid) ||
    (Sugar.lid_equals x Const.eq2_lid) ||
    (Sugar.lid_equals x Const.eqA_lid) ||
    (Sugar.lid_equals x Const.eqTyp_lid)

let is_equality x = is_lid_equality x.v

let is_tuple_constructor dc = 
  (Sugar.lid_equals dc.v Const.tuple_UU_lid) ||
  (Sugar.lid_equals dc.v Const.tuple_UA_lid) ||
  (Sugar.lid_equals dc.v Const.tuple_AU_lid) ||
  (Sugar.lid_equals dc.v Const.tuple_AA_lid)

let lid_is_connective = 
  let lst = [Const.and_lid; Const.or_lid; Const.not_lid; 
             Const.iff_lid; Const.implies_lid; Const.pf_lid] in (* ; Const.e2p_lid] in *)
  let lst = List.map Pretty.str_of_lident lst in 
    fun lid -> List.mem (Pretty.str_of_lident lid) lst
  
let warn_empty_ev = function 
  | [] -> ()
  | ev -> pr "Discarding evidence: %A\n" ev 

let is_operator s = (Sugar.IsMangledOpName s) && (s <> "op_Equality")

let wrap_pf_typ'_r r t = Typ_app (Const.pf_typ, twithinfo t Kind_prop r)
let wrap_pf_typ_r r t = twithinfo (Typ_app (Const.pf_typ, t)) Kind_prop r
(* let wrap_e2p_typ'_r r t = Typ_app (Const.e2p_typ, withinfo t Kind_erasable r) *)
(* let wrap_e2p_typ_r r t = withinfo (Typ_app (Const.e2p_typ, t)) Kind_prop r *)
let wrap_typ_r r t1 t = twithinfo (Typ_app (t1, t)) Kind_unknown r

let wrap_pf_typ' t = wrap_pf_typ'_r dummyRange t
let wrap_pf_typ t = wrap_pf_typ_r dummyRange t
(* let wrap_e2p_typ' t = wrap_e2p_typ'_r dummyRange t *)
(* let wrap_e2p_typ t = wrap_e2p_typ_r dummyRange t *)
let wrap_typ t1 t = wrap_typ_r dummyRange t1 t

let is_pf_wrapper x = (Sugar.lid_equals x.v Const.pf_lid)
  (* || (Sugar.lid_equals x.v Const.e2p_lid)  *)

let is_constructor t lid = 
  match (unascribe_typ t).v with
    | Typ_const(tc, _) -> Sugar.lid_equals tc.v lid 
    | _ -> false

let rec is_constructed_typ t lid = match t.v with 
  | Typ_const _ -> is_constructor t lid
  | Typ_app(t, _)
  | Typ_dep(t, _)
  | Typ_refine(_, t, _, _) 
  | Typ_ascribed(t, _) -> is_constructed_typ t lid
  | _ -> false

let is_pf_typ t = match t.v with
  | Typ_app(tc, t') -> is_constructor tc Const.pf_lid
  | _ -> false

let try_strip_pf_typ t = match t.v with
  | Typ_app({v=Typ_const(tc, _);sort=_}, t') ->
      if is_pf_typ t then t'
      else failwith (Printf.sprintf "strip_pf_t %s" (Pretty.strTyp t))
  | _ -> t

let strip_pf_typ t = match t.v with
  | Typ_app({v=Typ_const(tc, _);sort=_}, t') when is_pf_typ t -> t'
  | _ -> t

let strip_typ l t = match t.v with 
  | Typ_app(t1, t2) when is_constructor t1 l -> t2
  | _ -> failwith (Printf.sprintf "strip_typ %s %s" (Pretty.str_of_lident l) (Pretty.strTyp t))

let Wt t = twithsort t Kind_unknown
let Wtr t r = twithinfo t Kind_unknown r
let W e = ewithsort e (Wt Typ_unknown)
let Wfv fv = fvwithsort fv (Wt Typ_unknown)
let Wftv fv = fvwithsort fv Kind_unknown
let Wr e r = ewithinfo e (Wtr Typ_unknown r) r

let rctr = ref (int64 -1)
let Wmark e =
  let v = !rctr in 
    rctr := v - (int64 1);
    ewithinfo e (Wt Typ_unknown) v

let is_marked e = ((e.p < (int64 0)) && (e.p > (int64 -1500)))
let get_marker e = Printf.sprintf "%d" e.p

let btvar_to_typ bv = twithsort (Typ_btvar bv) bv.sort
let bvar_to_exp bv = ewithsort (Exp_bvar bv) bv.sort

let bvd_to_exp bvd t = bvar_to_exp (bvd_to_bvar_s bvd t)
let bvd_to_typ bvd k = btvar_to_typ (bvd_to_bvar_s bvd k)

let hoistexp e (mkBody:exp->exp) p : exp = 
  let id = genident (Some (e.p)) in
  let ppname = new Sugar.ident(Pretty.strExp e, e.p) in 
  let bvd = mkbvd (ppname,id) in
  let body = mkBody (ewithinfo (Exp_bvar (bvd_to_bvar_s bvd e.sort)) e.sort e.p) in
    ewithinfo (Exp_let(false, [(bvd, e.sort, e)], body)) body.sort p

let hoist e (body:exp->exp) : exp' = 
  let id = genident (Some (e.p)) in
  let ppname = new ident(Pretty.strExp e, e.p) in 
  let bvd = mkbvd (ppname,id) in
    Exp_let(false, [(bvd, e.sort, e)],
            body (ewithinfo (Exp_bvar (bvd_to_bvar_s bvd e.sort)) e.sort e.p))

let mk_eqtest e1 e2 = 
  let eq = W (Exp_fvar (fvwithsort Const.op_Eq (Wt Typ_unknown), None)) in  
    W (Exp_app(W (Exp_app(eq, e1)), e2))
      
//let proof_counter = ref 0
//let proof_stats_file = new System.IO.StreamWriter ("queries/proofstats.txt")
let proof_stats_flag = ref false
//
//let compute_proof_stats proofs = 
//  let rec final_typ t = match t.v with
//    | Typ_univ (_,_,t) 
//    | Typ_fun (_,_,t) -> final_typ t
//    | _ -> t in
//  let compute_proof_stats proof = 
//    let count_proof_rule i e = match e with
//      | Exp_constr_app(v, _, _, _) -> 
//          let t = v.sort in
//          let ft = final_typ t in
//          let i' = match ft.v with 
//            | Typ_app({v=Typ_const(v, _); sort=_; p=_}, _) when Sugar.lid_equals v.v Const.pf_lid -> i+1
//          | _ -> i in
//            (i', e)
//      | _ -> (i, e) in
//    let noop i t = (i,t) in
//    let count, _ = descend_exp_map noop count_proof_rule 0 proof in
//      proof_counter := !proof_counter + 1;
//      Printf.fprintf proof_stats_file "Proof %d uses %d proof rules\n" !proof_counter count;
//      flush proof_stats_file in
//    List.iter compute_proof_stats proofs


let rec is_value e = 
  let is_val e = match e.v with 
    | Exp_bot
    | Exp_constant _
    | Exp_bvar _
    | Exp_fvar _ 
    | Exp_abs _ 
    | Exp_tabs _ -> true
    | Exp_primop(id, el) -> 
        if (id.idText = "op_AmpAmp" ||
            id.idText = "op_BarBar" ||
            id.idText = "_dummy_op_Negation")
        then List.for_all is_value el
        else false
    | Exp_constr_app (_, _, _, el) -> List.for_all is_value el
    | Exp_ascribed(e, _, _) 
    | Exp_proj (e, _) -> is_value e
    | Exp_recd (_, _, _, fn_e_l) -> List.for_all (fun (_,e) -> is_value e) fn_e_l
    | _ -> false in 
    (is_val e) || (is_logic_function e)

and is_logic_function e = match (unascribe e).v with
  (* | Exp_tapp(e1, _) -> is_logic_function e1 *)
  | Exp_app(e1, e2) -> is_value e2 && is_logic_function e1
  | Exp_fvar(v, _) ->
      Sugar.lid_equals v.v Const.op_And_lid ||
        Sugar.lid_equals v.v Const.op_Or_lid ||
        Sugar.lid_equals v.v Const.op_Not_lid ||
        Sugar.lid_equals v.v Const.op_Add_lid ||
        Sugar.lid_equals v.v Const.op_Subtraction_lid ||
        Sugar.lid_equals v.v Const.op_Multiply_lid
  | _ -> false       
      
let rec unrefine t = match t.v with 
  | Typ_refine(x, t, _, _) -> unrefine t
  | _ -> t

let rec get_tycon t = match t.v with 
  | Typ_const (tc, _) -> Some t.v
  | Typ_app(t, _)
  | Typ_dep(t, _)
  | Typ_refine(_, t, _, _) -> get_tycon t 
  | Typ_btvar _ -> Some t.v
  | _ -> None

let fold_app_tapp = 
  List.fold_left (fun e -> function 
                    | Inl t -> W (Exp_tapp(e, t))
                    | Inr e' -> W (Exp_app(e, e')))

let base_kind = function
  | Kind_star | Kind_affine | Kind_prop | Kind_erasable -> true
  | _ -> false

let rec affineFreeKind k = match k(* .u *) with
   | Kind_affine -> false
   | Kind_prop
   | Kind_erasable
   | Kind_star 
   | Kind_unknown -> true
   | Kind_boxed k
   | Kind_dcon(_, _, k) -> affineFreeKind k
   | Kind_tcon(_, k1, k2) -> affineFreeKind k1 && affineFreeKind k2

let rec affineFreeTyp t = 
   (affineFreeKind t.sort) &&
   match t.v with 
    | Typ_fun(_, t1, t2) -> affineFreeTyp t1 && affineFreeTyp t2 
    | Typ_univ(_, k, _, t) -> affineFreeKind k && affineFreeTyp t
    | _ -> true
 
type binders = list<Disj<btvdef, bvvdef>>
type mapper<'env, 'k, 't, 'e, 'm, 'n> =
    ('env -> binders -> kind -> ('k * 'env))
 -> ('env -> binders -> typ -> ('t * 'env))
 -> ('env -> binders -> exp -> ('e * 'env))
 -> 'env -> binders -> 'm -> ('n * 'env)

let push_tbinder binders = function 
  | None -> binders
  | Some a -> (Inl a)::binders
let push_vbinder binders = function 
  | None -> binders
  | Some a -> (Inr a)::binders

let rec reduce_kind 
    (map_kind': mapper<'env, 'k, 't, 'e, kind, 'k>)
    (map_typ': mapper<'env, 'k, 't, 'e, typ, 't>)
    (map_exp': mapper<'env, 'k, 't, 'e, exp, 'e>)
    (combine_kind: (kind -> ('k list * 't list * 'e list) -> 'env -> ('k * 'env)))
    (combine_typ: (typ -> ('k list * 't list * 'e list) -> 'env -> ('t * 'env)))
    (combine_exp: (exp -> ('k list * 't list * 'e list) -> 'env -> ('e * 'env))) (env:'env) binders kind : ('k * 'env) =
    let rec visit_kind env binders k =
        let kl, tl, el, env =   
          (match k(* .u *) with 
             | Kind_boxed k -> 
                 let k, env  = map_kind env binders k in
                   [k], [], [], env
             | Kind_star 
             | Kind_affine
             | Kind_prop
             | Kind_erasable
             | Kind_unknown -> [], [], [], env
             | Kind_tcon (aopt, k1, k2) -> 
                 let k1, env = map_kind env binders k1 in
                 let k2, env = map_kind env (push_tbinder binders aopt) k2 in
                   [k1;k2], [], [], env
             | Kind_dcon (xopt, t, k) -> 
                 let t, env = map_typ env binders t in
                 let k, env = map_kind env (push_vbinder binders xopt) k in
                   [k],[t],[],env) in
          combine_kind k (kl, tl, el) env 
    and map_kind env binders k = map_kind' visit_kind map_typ map_exp env binders k
    and map_typ env binders t = reduce_typ map_kind' map_typ' map_exp' combine_kind combine_typ combine_exp env binders t 
    and map_exp env binders e = reduce_exp map_kind' map_typ' map_exp' combine_kind combine_typ combine_exp env binders e
    in
      map_kind env binders kind
                            
and reduce_typ 
    (map_kind': mapper<'env, 'k, 't, 'e, kind, 'k>)
    (map_typ': mapper<'env, 'k, 't, 'e, typ, 't>)
    (map_exp': mapper<'env, 'k, 't, 'e, exp, 'e>)
    (combine_kind: (kind -> ('k list * 't list * 'e list) -> 'env -> ('k * 'env)))
    (combine_typ: (typ -> ('k list * 't list * 'e list) -> 'env -> ('t * 'env)))
    (combine_exp: (exp -> ('k list * 't list * 'e list) -> 'env -> ('e * 'env))) (env:'env) binders typ : ('t * 'env) =
  let rec map_typs env binders tl = 
    let tl, _, env = List.fold_left (fun (out, binders, env) (xopt, t) -> 
                                       let t, env = map_typ env binders t in
                                       let binders = push_vbinder binders xopt in 
                                         t::out, binders, env) ([], binders, env) tl in
      List.rev tl, env 
  and visit_typ env binders t = 
    let kl, tl, el, env =   
      (match (compress t).v with 
         | Typ_unknown
         | Typ_btvar _   
         | Typ_const _ -> [],[],[], env
         | Typ_record(fnt_l, topt) -> 
             let tl, env = map_typs env binders (List.map (fun (_, t) -> (None,t)) fnt_l) in
               (match topt with 
                  | None -> [], tl, [], env
                  | Some t -> 
                      let t, env = map_typ env binders t in 
                        [], t::tl, [], env)
         | Typ_app(t1, t2) -> 
             let tl, env = map_typs env binders [(None, t1); (None, t2)] in 
               [], tl, [], env 
         | Typ_lam(x, t1, t2)
         | Typ_refine(x, t1, t2,_) -> 
             let tl, env = map_typs env binders [(Some x, t1); (None, t2)] in 
               [], tl, [], env 
         | Typ_fun(xopt, t1, t2) -> 
             let tl, env = map_typs env binders [(xopt,t1);(None, t2)] in
               [], tl, [], env 
         | Typ_univ(a, k, [], t) 
         | Typ_tlam(a, k, t) ->
             let k, env = map_kind env binders k in
             let t, env = map_typ env (push_tbinder binders (Some a)) t in
               [k], [t], [], env
         | Typ_dtuple (xt_l) ->
             let tl, env = map_typs env binders xt_l in 
               [], tl, [], env
         | Typ_dep(t, e) -> 
             let t, env = map_typ env binders t in
             let e, env = map_exp env binders e in
               [], [t], [e], env 
         | Typ_meta(Meta_alpha t) 
         | Typ_affine t ->
             let t, env = map_typ env binders t in
               [], [t], [], env 
         | Typ_uvar(_, k) -> 
             let k, env = map_kind env binders k in
               [k], [], [], env
         | Typ_meta(Meta_cases tl) -> 
             let tl, env = map_typs env binders (List.map (fun t -> (None, t)) tl) in 
               [], tl, [], env
         | Typ_meta(Meta_pattern(t,ps)) -> 
             let t,env = map_typ env binders t in 
             let tpats, vpats, env = List.fold_left (fun (tpats, vpats, env) -> function
               | Inl t -> let t, env = map_typ env binders t in (t::tpats, vpats, env)
               | Inr e -> let e, env = map_exp env binders e in (tpats, e::vpats, env)) ([], [], env) ps in 
             [], t::tpats, vpats, env)
    in 
      combine_typ t (kl, tl, el) env 
  (* and visit_typ env binders t =  *)
  (*   (try visit_typ' env binders t *)
  (*    with e -> pr "visit_typ failed on type %s\n" (Pretty.strTyp t); raise e) *)
  and map_kind env binders k = reduce_kind map_kind' map_typ' map_exp' combine_kind combine_typ combine_exp env binders k 
  and map_typ env binders t = map_typ' map_kind visit_typ map_exp env binders t
  and map_exp env binders e = reduce_exp map_kind' map_typ' map_exp' combine_kind combine_typ combine_exp env binders e  
  in
    map_typ env binders typ
      
and reduce_exp 
    (map_kind': mapper<'env, 'k, 't, 'e, kind, 'k>)
    (map_typ': mapper<'env, 'k, 't, 'e, typ, 't>)
    (map_exp': mapper<'env, 'k, 't, 'e, exp, 'e>)
    (combine_kind: (kind -> ('k list * 't list * 'e list) -> 'env -> ('k * 'env)))
    (combine_typ: (typ -> ('k list * 't list * 'e list) -> 'env -> ('t * 'env)))
    (combine_exp: (exp -> ('k list * 't list * 'e list) -> 'env -> ('e * 'env))) (env:'env) binders exp : ('e * 'env) =
  let rec map_exps env binders el = 
    let el, env = List.fold_left (fun (out, env) e -> 
                                    let e, env = map_exp env binders e in
                                      e::out, env) ([], env) el in
      List.rev el, env 
  and map_exps_with_binders env el = 
    let el, env = List.fold_left (fun (out, env) (b,e) -> 
                                    let e, env = map_exp env b e in
                                      e::out, env) ([], env) el in
      List.rev el, env 
  and map_typs env binders tl = 
    let tl, env = List.fold_left (fun (out, env) t -> 
                                    let t, env = map_typ env binders t in
                                      t::out, env) ([], env) tl in
      List.rev tl, env 
  and map_kind env binders k = reduce_kind map_kind' map_typ' map_exp' combine_kind combine_typ combine_exp env binders k 
  and map_typ env binders t = reduce_typ map_kind' map_typ' map_exp' combine_kind combine_typ combine_exp env binders t 
  and map_exp env binders e = map_exp' map_kind map_typ visit_exp env binders e
  and visit_exp env binders e = 
    let kl, tl, el, env = 
      (match e.v with 
         | Exp_gvar _
         | Exp_bot   
         | Exp_bvar _  
         | Exp_fvar _ 
         | Exp_constant _ -> [], [], [], env
         | Exp_constr_app(_, tl, el1, el2) -> 
             let tl, env = map_typs env binders tl in 
             let el, env = map_exps env binders (el1@el2) in 
               [], tl, el, env 
         | Exp_abs(x, t, e) -> 
             let tl, env = map_typs env binders [t] in
             let e, env = map_exp env (push_vbinder binders (Some x)) e in
               [], tl, [e], env
         | Exp_tabs(a, k, formulas, e) ->
             let k, env = map_kind env binders k in
             let binders = push_tbinder binders (Some a) in
             let formulas, env = map_typs env binders formulas in 
             let e, env = map_exp env binders e in
               [k], formulas, [e], env
         | Exp_app(e1, e2) -> 
             let el, env = map_exps env binders [e1;e2] in
               [], [], el, env 
         | Exp_tapp(e, t) -> 
             let tl, env = map_typs env binders [t] in 
             let e, env = map_exp env binders e in
               [], tl, [e], env
         | Exp_match(e1, pl, e2) -> 
             let branches = List.map (fun (Pat_variant(_, ts, _, xs, _), branch) -> 
                                             let b = List.fold_left (fun b t -> match t.v with Typ_btvar a -> push_tbinder b (Some a.v) | _ -> b) binders ts in 
                                             let b = List.fold_left (fun b x -> push_vbinder b (Some x.v)) b xs in 
                                               (b, branch)) pl in 
             let el, env = map_exps_with_binders env (((binders, e1)::branches)@[(binders,e2)]) in
               [], [], el, env 
         | Exp_cond(e1, e2, e3) -> 
             let el, env = map_exps env binders [e1;e2;e3] in 
               [], [], el, env 
         | Exp_recd(_, tl, el, fne_l) ->
             let tl, env = map_typs env binders tl in
             let el, env = map_exps env binders (el@(List.map snd fne_l)) in
               [], tl, el, env
         | Exp_proj (e, _) -> 
             let e, env = map_exp env binders e in
               [], [], [e], env
         | Exp_ascribed(e, t, _) ->
             let tl, env = map_typs env binders [t] in
             let e, env = map_exp env binders e in
               [], tl, [e], env
         | Exp_let(false, [x,t,e1], e2) -> 
             let tl, env = map_typs env binders [t] in
             let el, env = map_exps_with_binders env [(binders, e1); (push_vbinder binders (Some x), e2)] in 
               [], tl, el, env 
         | Exp_let(true, bvdt_tl, e) ->
             let tl = List.map (fun (_, t, _) -> t) bvdt_tl in
             let el = List.map (fun (_, _, e) -> e) bvdt_tl in
             let tl, env = map_typs env binders tl in
             let binders = List.fold_left (fun binders (x, _, _) -> push_vbinder binders (Some x)) binders bvdt_tl in 
             let el, env = map_exps env binders (el@[e]) in
               [], tl, el, env 
         | Exp_extern_call(_, _, t, tl, el) -> 
             let tl, env = map_typs env binders (t::tl) in
             let el, env = map_exps env binders el in 
               [], tl, el, env
         | Exp_primop(_, el) ->
             let el, env = map_exps env binders el in
               [], [], el, env) in
      combine_exp e (kl, tl, el) env in
    map_exp env binders exp
      
let combine_kind k (kl, tl, el) env = 
  let k' = match k(* .u *) with 
    | Kind_boxed k -> Absyn.Kind_boxed(List.hd kl)
    | Kind_star 
    | Kind_affine
    | Kind_prop
    | Kind_erasable
    | Kind_unknown as k -> k
    | Kind_tcon (aopt, k1, k2) -> let [k1;k2] = kl in Absyn.Kind_tcon(aopt, k1, k2)
    | Kind_dcon (xopt, t, k) -> Absyn.Kind_dcon(xopt, List.hd tl, List.hd kl) in
    k', env
      
let combine_typ t (kl, tl, el) env =
  let t' = match (compress t).v with 
    | Typ_unknown
    | Typ_btvar _   
    | Typ_const _ -> t.v
    | Typ_record(fnt_l, None) -> 
        let fnt_l' = List.map2 (fun (fn, _) t -> (fn, t)) fnt_l tl in
          Typ_record(fnt_l',None)
    | Typ_record(fnt_l, Some _) -> 
        let (t::tl) = tl in 
        let fnt_l' = List.map2 (fun (fn, _) t -> (fn, t)) fnt_l tl in
          Typ_record(fnt_l', Some t)
    | Typ_lam(x, t1, t2) -> let [t1';t2'] = tl in Typ_lam(x, t1', t2')
    | Typ_app(t1, t2) -> let [t1';t2'] = tl in Typ_app(t1',t2')
    | Typ_refine(x, t1, t2, ghost) -> let [t1';t2'] = tl in Typ_refine(x, t1', t2', ghost)
    | Typ_fun(x, t1, t2) -> let [t1';t2'] = tl in Typ_fun(x, t1', t2')
    | Typ_tlam(a, k, t) -> Typ_tlam(a, List.hd kl, List.hd tl)
    | Typ_univ(a, k, formulas, t) -> 
        let t'::formulas' = tl in 
          Typ_univ(a, List.hd kl, formulas', t')
    | Typ_dtuple (xt_l) -> let xt_l' = List.map2 (fun (x, _) t -> (x,t)) xt_l tl in Typ_dtuple(xt_l')
    | Typ_dep(t, e) -> Typ_dep(List.hd tl, List.hd el)
    | Typ_affine t -> Typ_affine(List.hd tl)
    | Typ_uvar(x, k) -> Typ_uvar(x, List.hd kl)
    | Typ_meta(Meta_cases _) -> Typ_meta(Meta_cases tl) 
    | Typ_meta(Meta_alpha _) -> Typ_meta(Meta_alpha (List.hd tl))
    | Typ_meta(Meta_pattern _) -> Typ_meta(Meta_pattern(List.hd tl, (List.tl tl |> List.map Inl)@(el |> List.map Inr))) in
  twithinfo t' t.sort t.p, env

let combine_exp e (kl,tl,el) env = 
  let e' = match e.v with 
    | Exp_gvar _
    | Exp_bot   
    | Exp_bvar _  
    | Exp_fvar _ 
    | Exp_constant _ -> e.v
    | Exp_constr_app(v, _, el1, el2) ->
        let el1', el2' = Util.firstN (List.length el1) el in
          Exp_constr_app(v, tl, el1', el2') 
    | Exp_abs(x, t, e) -> Exp_abs(x, List.hd tl, List.hd el)
    | Exp_tabs(a, k, formulas, e) -> Exp_tabs(a, List.hd kl, tl, List.hd el)
    | Exp_app(e1, e2) -> let [e1';e2'] = el in Exp_app(e1', e2')  
    | Exp_tapp(e, t) -> Exp_tapp(List.hd el, List.hd tl)
    | Exp_match(e1, pl, e2) -> 
        let e1'::el = el in 
        let el, [e2'] = Util.firstN (List.length pl) el in
        let pl' = List.map2 (fun (p, _) e -> (p, e)) pl el in
          Exp_match(e1', pl', e2')
    | Exp_cond(e1, e2, e3) ->
        let [e1';e2';e3'] = el in
          Exp_cond(e1', e2', e3')
    | Exp_recd(r, ts, es, fne_l) ->
        let es', rest = Util.firstN (List.length es) el in
        let fne_l' = List.map2 (fun (fn, _) e -> fn,e) fne_l rest in
          Exp_recd(r, tl, es', fne_l')
    | Exp_proj (e, f) -> Exp_proj(List.hd el, f)
    | Exp_ascribed(e, t, x) -> Exp_ascribed(List.hd el, List.hd tl, x)
    | Exp_let(x, bvdt_tl, e) ->
        let el, [e'] = Util.firstN (List.length bvdt_tl) el in
        let bvdt_tl' = List.map3 (fun (bvd, _, _) t e -> (bvd, t, e)) bvdt_tl tl el in
          Exp_let(x, bvdt_tl', e') 
    | Exp_extern_call(x, y, t, ts, es) ->
        let t'::ts' = tl in
          Exp_extern_call(x, y, t', ts', el)
    | Exp_primop(x, es) -> Exp_primop(x, el) in
    ewithinfo e' e.sort e.p, env

(* ************************************************************************ *)
(* Absyn constructors and destructors                                       *)
(* Moved here from proofCombinators.fs --- see LICENSE.txt                  *)
(* ************************************************************************ *)

let liOfSl sl = asLid <| List.map (function s -> new ident(s,dummyRange)) sl
let slOfLi (x:lident) = List.map (function (id:ident) -> id.idText) x.lid

let mkId (s:string) : ident               = new ident(s,dummyRange)
let mkTypKind (t:typ') (k:kind) : typ     = twithsort t k
let mkTypStar (t:typ') : typ              = mkTypKind t Kind_star
let mkTyp (t:typ') : typ                  = mkTypKind t Kind_unknown
let dummyTyp                              = mkTyp Typ_unknown

let mkExpTyp (e:exp') (t:typ) : exp       = ewithsort e t
let mkExp (e:exp') : exp                  = mkExpTyp e dummyTyp
let mkTagExp p (e:exp') : exp             = ewithinfo e dummyTyp (int64 p)
let dummyExp                              = mkExp Exp_bot

let mkVarTTyp li (t:typ) : var<typ>       = fvwithsort li t
let mkVarT li : var<typ>                  = mkVarTTyp li dummyTyp
let dummyVarT : var<typ>                  = mkVarT (Sugar.lid_of_path ["Nada"] dummyRange)

let mkVarKKind li (k:kind) : var<kind>    = fvwithsort li k
let mkVarK li : var<kind>                 = mkVarKKind li Kind_unknown

let mkTypConst li : typ                   = mkTyp (Typ_const (mkVarK li, None))

let bvdToExp x (t:typ) : exp              = mkExpTyp (Exp_bvar (bvwithsort x t)) t

let idToExp x (t:typ) : exp               = bvdToExp (mkbvd (x,x)) t

let bvdOfString s = mkbvd (mkId s, genident None)

let stringToBvdExp s t = 
  let bvd = bvdOfString s in 
  let e   = bvdToExp bvd t in
    (bvd,t), e

let mkDconApp dc typs exps       = mkExp (Exp_constr_app (dc, typs, [], exps))
let mkTagDconApp p dc typs exps  = mkTagExp p (Exp_constr_app (dc, typs, [], exps))
let mkExpApp e1 e2               = mkExp (Exp_app (e1, e2))
let mkExpAbs e1 t e2             = mkExp (Exp_abs (e1, t, e2))
let mkTagExpAbs p e1 t e2        = mkTagExp p (Exp_abs (e1, t, e2))

let liToExp li                   = mkDconApp (mkVarT li) [] []

let mkFvarTyp li (t:typ)         = mkExpTyp (Exp_fvar (mkVarTTyp li t, None)) t
let mkFvar li                    = mkFvarTyp li dummyTyp

let expTrue  = mkExpTyp (Exp_constant (Sugar.Const_bool true)) Const.bool_typ
let expFalse = mkExpTyp (Exp_constant (Sugar.Const_bool false)) Const.bool_typ

let mkRecd fields es  = mkExp (Exp_recd (None, [], [], List.zip fields es))
let mkProj e f        = mkExp (Exp_proj (e, f))

let mkTup t1 t2 e1 e2 = mkDconApp (mkVarT Const.tuple_UU_lid) [t1;t2] [e1;e2]
let mkProj1 e         = mkProj e Const.tuple_proj_one
let mkProj2 e         = mkProj e Const.tuple_proj_two
let isTupleProj       =
  let p1 = Pretty.sli Const.tuple_proj_one in
  let p2 = Pretty.sli Const.tuple_proj_two in
    fun fn -> let fn = Pretty.sli fn in fn=p1 || fn=p2

let mkInt i           = mkExp (Exp_constant (Sugar.Const_int32 (int32 i)))
let proofTrue         = liToExp (Sugar.lid_of_path ["Prims";"T"] dummyRange)

let mkPfT         = wrap_pf_typ
let stripPfT      = strip_pf_typ

(* Apply a list of typs and exps to type constructor. *)
let mkTypApp tc typs exps = 
  let rec f ts es = match ts, es with
    | _, e::es'  -> mkTyp (Typ_dep (f ts es', e))
    | t::ts', [] -> mkTyp (Typ_app (f ts' [], t))
    | [], []     -> tc 
  in f (List.rev typs) (List.rev exps)

let mkNot t = mkTypApp Const.not_typ     [t]   []
let mkPfNot = mkPfT -<- mkNot

let mkOr t u = mkTypApp Const.or_typ      [t;u] []
let mkPfOr  t u   = mkPfT (mkOr t u)

let mkAnd t u = mkTypApp Const.and_typ      [t;u] []
let mkPfAnd  t u   = mkPfT (mkAnd t u)

let mkImp t u = mkTypApp Const.implies_typ      [t;u] []
let mkPfImp  t u   = mkPfT (mkImp t u)

let mkIff t u   = mkTypApp Const.iff_typ     [t;u] []
let mkPfIff t u = mkPfT (mkIff t u)

let mkEq tc e f = (mkTypApp tc [] [e;f])
let mkPfEq tc e f = mkPfT (mkEq tc e f)


(* Takes n types (already wrapped with pf) and creates a nested sequence of
   binary ors. *)
let rec mkPfOr_n n ts = match n, ts with
  | 2, [t;u] -> mkPfOr t u
  | n, h::tl when n = List.length ts -> mkPfOr h (mkPfOr_n (n-1) tl)
  | _ -> raise Impos 

let rec mkPfAnd_n n ts = match n, ts with
  | 2, [t;u] -> mkPfAnd t u
  | n, h::tl when n = List.length ts -> mkPfAnd h (mkPfAnd_n (n-1) tl)
  | _ -> raise Impos

let destructDepArrow t = match t.v with
  | Typ_fun(Some bv,t1,t2) -> bv,t1,t2
  | _                      -> failwith "destructDepArrow"

let rec mkDepArrow binders body =
  match binders with
    | (bvd,t)::tl -> mkTyp (Typ_fun (Some bvd, t, mkDepArrow tl body))
    | []          -> body

let mkArrow t1 t2 = mkTyp (Typ_fun (None, t1, t2))

let rec mkArrowL = function
  | []      -> raise Impos
  | t::[]   -> t
  | t::rest -> mkTyp (Typ_fun (None, t, mkArrowL rest))

(* More specific than mkDepArrow, since it wraps the outer type and all
   inner range types of arrows with pf<>. Note that body should already
   be pf-wrapped though. *)
let rec mkPfDepArrow binders body =
  match binders with
    | []          -> body
    | (bvd,t)::tl -> mkPfT (mkTyp (Typ_fun (Some bvd, t, mkPfDepArrow tl body)))

let rec mkPfDepTuple binders body =
  match binders with
    | []          -> body
    | (bvd,t)::tl -> mkPfT (mkTyp (Typ_dtuple ([(Some(bvd),t);(None, mkPfDepTuple tl body)])))

(* Apply a list of typs to an exp. *)
let rec applyTyps e = function
  | []    -> e
  | t::ts -> applyTyps (mkExp (Exp_tapp (e, t))) ts

(* Apply a list of exps to an exp. *)
let rec applyExps e = function
  | []    -> e
  | f::fs -> applyExps (mkExp (Exp_app (e, f))) fs

(* Applies type and value parameters to a function expression.
   Typechecker doesn't currently allow explicitly creating Exp_tapps. *)
let mkCall1 funexp typs exps =
  applyExps (applyTyps funexp typs) exps


(* If the input type is a Typ_app, walks the Typ_app tree and
   flattens the type parameters. Does not recursively drill into
   other kinds of types. *)
let flattenTypApps : typ -> typ list =
  let rec foo acc t = let t = unrefine t in match t.v with
    | Typ_app(t1,t2) -> foo (t2::acc) t1 
    | _              -> t::acc in
    (fun t -> foo [] t)

let flattenExpTapps : exp -> (exp * list<typ>) = 
  let rec aux acc e = match e.v with
    | Exp_tapp(e,t) -> aux (t::acc) e
    | _              -> e, acc in
    (fun e -> aux [] e)

let flattenApps : exp -> (exp * list<exp>) = 
  let rec aux acc e = match e.v with 
    | Exp_app(e, v) -> aux (v::acc) e
    | _ -> e, acc in 
  (fun e -> aux [] e)

(* If the input type is a Typ_app, walks the Typ_app tree and
   flattens the type parameters. Does not recursively drill into
   other kinds of types. *)
let flattenTypAppsAndDeps : typ -> typ * (Disj<typ,exp> list) =
  let rec aux acc t = let t = unrefine t in match t.v with
    | Typ_app(t1,t2) -> aux (Inl t2::acc) t1 
    | Typ_dep(t1, v) -> aux (Inr v::acc) t1
    | _              -> t, acc in
    (fun t -> aux [] t)

(* Return the argument types, the final return type, and the bvdefs for all
   type abstractions. *)
let flattenArrowTyp : typ -> typ list * typ * btvdef list =
  let rec f (acc1,acc2) t = match t.v with
    | Typ_fun(_,t1,t2)    -> f ((t1::acc1),acc2) t2
    | Typ_univ(bvd,_,_,t1)  -> f (acc1,(bvd::acc2)) t1
    | _                   -> (t::acc1),acc2 in
  fun t ->
    let l, bvds = f ([],[]) t in
    List.rev (List.tl l), List.hd l, List.rev bvds

(* Returns type parameters from a dependent type constructor. *)
let typArgsOfKind : kind -> typ list =
  let rec f acc k = match k(* .u *) with
    | Kind_erasable
    | Kind_prop
    | Kind_affine
    | Kind_star       -> acc
    | Kind_dcon(_, t,k') -> f (t::acc) k'
    | _               -> failwith (spr "typArgsOfKind: %s" (Pretty.strKind k))
  in fun k -> List.rev (f [] k)

let rec tconOfTyp (t:typ) : lident =
  match t.v with
    | Typ_app(t1,_)      -> tconOfTyp t1
    | Typ_dep(t1,_)      -> tconOfTyp t1
    | Typ_refine(_,t1,_,_) -> tconOfTyp t1
    | Typ_const(x, _)       -> x.v
    | _                  -> failwith (spr "tconOfTyp: %s" (Pretty.strTyp t))
  
let sortByFieldName (fn_a_l:list<fieldname * 'a>) = 
  fn_a_l |> List.sortWith 
      (fun (fn1, _) (fn2, _) -> 
         String.compare 
           (Pretty.str_of_lident fn1)
           (Pretty.str_of_lident fn2))

let rec is_prop k = match k(* .u *) with
  | Kind_prop 
  | Kind_erasable -> true
  | Kind_star
  | Kind_affine -> false
  | Kind_tcon(_, _, k) 
  | Kind_dcon(_, _, k) -> is_prop k
  | _ -> false

let closeTyp tps t = 
  t |> (tps |> List.fold_right (
          fun tp out -> match tp with 
            | Tparam_typ (a,k) -> twithsort (Typ_univ (a,k,[],out)) Kind_star
            | Tparam_term (x,t) -> twithsort (Typ_fun (Some x,t,out)) Kind_star))


let mkTlam xopt t1 t2 = match xopt with 
  | None -> 
      let x = new_bvd None in
        twithinfo (Typ_lam(x, t1, t2)) (Kind_dcon(Some x, t1, t2.sort)) t2.p 
  | Some x-> 
      twithinfo (Typ_lam(x, t1, t2)) (Kind_dcon(Some x, t1, t2.sort)) t2.p 

let mkRefinedUnit formula = 
  let bvd = new_bvd None in 
  let t = twithinfo (Typ_refine(bvd, Const.unit_typ, formula, true)) Kind_star formula.p in 
    t, bvd.realname

let findValDecl (vds:list<sigelt>) bvd : option<sigelt> = 
  vds |> Util.findOpt (function 
                         | Sig_value_decl(lid, t) -> 
                            let _, name = Util.pfx lid.lid in 
                                name.idText = (pp_name bvd).idText
                         | _ -> false) 

let findValDecls (vds:list<sigelt>) ((lb, _): (letbinding * bool)) : list<sigelt> = 
  List.fold_right 
    (fun (bvd, _, _) out -> 
       match vds |> Util.findOpt (function 
                                    | Sig_value_decl(lid, t) -> let _, name = Util.pfx lid.lid in 
                                        name.idText = (pp_name bvd).idText
                                    | _ -> false) with 
         | None -> out
         | Some vd -> vd::out) lb []

let rec typs_of_letbinding = function
  | (_, t, e)::tl -> t::typs_of_letbinding tl
  | _ -> []
      

let rec normalizeRefinement' x t = match t.v with 
  | Typ_refine(bvd, t', phi, ghost) -> 
      let t', conc_opt, ghost_opt = normalizeRefinement' x t' in
      let phi = substitute_exp phi bvd x in 
      let conc_opt, ghost_opt = 
        if ghost then conc_opt, mk_conj ghost_opt phi
        else mk_conj conc_opt phi, ghost_opt in
        t', conc_opt, ghost_opt 
  | _ -> t, None, None
and mk_conj phi1 phi2 = match phi1 with 
  | None -> Some phi2
  | Some phi1 -> 
      let app1 = (twithsort (Typ_app(Const.and_typ, mkPfT phi1)) (Kind_tcon(None, Kind_erasable, Kind_prop))) in
      let and_t = twithsort (Typ_app(app1, mkPfT phi2)) Kind_prop in
        Some and_t

let normalizeRefinement t = match t.v with 
  | Typ_refine(bvd, tt', phi, ghost) -> 
      let tt = unrefine tt' in
        if (tt === tt') then t
        else 
          (* let _ = pr "Normalizing refinement: %s\n" (Pretty.strTyp t) in *)
          let x = ewithsort (Exp_bvar (bvd_to_bvar_s bvd tt)) tt in
          let t, conc_opt, ghost_opt = normalizeRefinement' x t in
          let conc_opt, ghost_opt = 
            if ghost then conc_opt, mk_conj ghost_opt phi
            else mk_conj conc_opt phi, ghost_opt in
          let t = match conc_opt with 
            | None -> t
            | Some phi -> twithinfo (Typ_refine(bvd, t, phi, false)) t.sort t.p in
          let t = match ghost_opt with 
            | None -> t
            | Some phi -> twithinfo (Typ_refine(bvd, t, phi, true)) t.sort t.p in
            t
  | _ -> t

let forall_kind = 
  let a = new_bvd None in 
  let atyp = bvd_to_typ a Kind_star in 
    Kind_tcon(Some a, Kind_star, 
              Kind_tcon(None, Kind_dcon(None, atyp, Kind_erasable), 
                        Kind_erasable))
      (* forall x:a. body *)
let mkForall (x:bvvdef) (a:typ) (body:typ) : typ =
  let forall_typ = twithsort (Typ_const(fvwithsort Const.forall_lid forall_kind, None)) forall_kind in 
  let f_kind = Kind_dcon(Some x, a, Kind_erasable) in
  let f = twithsort (Typ_lam(x, a, body)) f_kind in
  let app1_kind = Kind_tcon(None, f_kind, Kind_erasable) in
  let forall_app1 = twithsort (Typ_app(forall_typ, a)) app1_kind in
    twithsort (Typ_app(forall_app1, f)) Kind_erasable

let unForall t = match t.v with 
  | Typ_app({v=Typ_app({v=Typ_const({v=lid}, _)}, _)}, {v=Typ_lam(x, t, body)}) when Const.is_forall lid -> 
      Some (x, t, body)
  | _ -> None


let open_typ_with_typs_or_exps t l = 
  List.fold_left (fun t l -> match l with 
                    | Inl t' -> open_typ_with_typ t t'
                    | Inr v -> open_typ_with_exp t v) t l
    
let collect_u_quants t = 
  let rec aux out t = 
    let t' = strip_pf_typ t in
      match flattenTypAppsAndDeps (Pretty.normalize t') with 
        | {v = Typ_fun(Some x, t1, t2)}, _ -> aux ((x, t1)::out) t2
        | {v=Typ_const(tc,_)}, [Inl t1; Inl {v=Typ_lam(x, _, t2)}] 
            when Const.is_forall tc.v -> 
            aux ((x, t1)::out) t2
        | _ -> List.rev out, t'
  in aux [] t

let collect_forall_xt t = 
  let rec aux out t = 
    let t' = strip_pf_typ t in
    match flattenTypAppsAndDeps (Pretty.normalize t') with 
      | {v = Typ_fun(Some x, t1, t2)}, _ -> aux (Inr(x, t1)::out) t2
      | {v=Typ_const(tc,_)}, [Inl t1; Inl {v=Typ_lam(x, _, t2)}] 
        when Const.is_forall tc.v -> 
        aux (Inr(x, t1)::out) t2
      | {v=Typ_univ(a, k, _, t)}, _ ->  aux (Inl(a,k)::out) t
      | _ -> List.rev out, t'
  in aux [] t

let collect_exists_xt t = 
  let rec aux out t = 
    let t' = strip_pf_typ t in
      match flattenTypAppsAndDeps (Pretty.normalize t') with 
        | {v=Typ_dtuple([(Some x, t1); (_, t2)])}, _ -> aux (Inr(x, t1)::out) t2
        | {v=Typ_const(tc,_)}, [Inl t1; Inl {v=Typ_lam(x, _, t2)}] 
          when (Sugar.lid_equals tc.v Const.exists_lid ||
                Sugar.lid_equals tc.v Const.existsA_lid) -> 
          aux (Inr(x, t1)::out) t2
        | {v=Typ_const(tc,_)}, [Inl {v=Typ_tlam(a, k, t2)}]
          when (Sugar.lid_equals tc.v Const.existsTyp_lid) -> 
          aux (Inl(a,k)::out) t2
        | _ -> List.rev out, t'
  in aux [] t

  
let collect_e_quants t = 
  let rec aux out t = 
    let t' = strip_pf_typ t in
      match flattenTypAppsAndDeps (Pretty.normalize t') with 
        | {v=Typ_dtuple([(Some x, t1); (_, t2)])}, _ -> aux ((x, t1)::out) t2
        | {v=Typ_const(tc,_)}, [Inl t1; Inl {v=Typ_lam(x, _, t2)}] 
            when (Sugar.lid_equals tc.v Const.exists_lid ||
                  Sugar.lid_equals tc.v Const.existsA_lid) -> 
            aux ((x, t1)::out) t2
        | _ -> List.rev out, t'
  in aux [] t


(* ******************************************************************************** *)
let hkey_kind = ref "hashkey-kind-0"
let hkey_type = ref "hashkey-type-0"
let incr_phase = 
  let ctr = ref 0 in 
    fun () -> 
      incr ctr;
      hkey_kind := spr "%s-%d" !hkey_kind !ctr;
      hkey_type := spr "%s-%d" !hkey_type !ctr

let get_khashkey k f = f k
  (* match !k.khashkey with  *)
  (*   | None ->  *)
  (*       let key = f k in  *)
  (*         k.khashkey := Some key;  *)
  (*         key  *)
  (*   | Some key -> key *)
        
let get_hashkey a f = f a
  (* match !a.hashkey with  *)
  (*   | None ->  *)
  (*       let key = f a in  *)
  (*         a.hashkey := Some key;  *)
  (*         key  *)
  (*   | Some key -> key *)

let hashkey_var v = 
  get_hashkey v (fun v -> (Sugar.text_of_lid (v.v)).GetHashCode() * 151)
    
let rec hashkey_kind k =
  let rec aux = fun k -> match k(* .u *) with
    | Kind_boxed k -> 13 * (hk k)
    | Kind_star -> 171
    | Kind_affine -> 173
    | Kind_prop -> 177
    | Kind_erasable -> 187
    | Kind_tcon(_, k1, k2) -> 13 * (13 * (hk k1) + (hk k2)) + 191
    | Kind_dcon(_, t, k) ->  13 * (13 * (hashkey_typ t) + (hk k)) + 207
    | Kind_unknown -> 197 
  and hk k = get_khashkey k aux in 
    hk k

and hashkey_typ t = 
  let rec aux = fun t -> match t.v with
    | Typ_btvar _ -> 59
    | Typ_const(v, _) -> hashkey_var v
    | Typ_record(fnt_l, Some t) -> 
        23 * (23 * (hkl (List.map snd fnt_l)) + (hk t)) + 67
    | Typ_record(fnt_l, None) -> 
        23 * (23 * (hkl (List.map snd fnt_l)) + 1) + 71
    | Typ_fun(_, t1, t2) -> 
        23 * (23 * (hk t1) + (hk t2)) + 73
    | Typ_univ(_, _, _, t) -> 
        23 * (hk t) + 79
    | Typ_dtuple(tl) -> 
        23 * (hkl (List.map snd tl)) + 83
    | Typ_refine(_, t1, t2, _) -> 
        23 * (23 * (hk t1) + (hk t2)) + 89
    | Typ_app(t1, t2) -> 
        23 * (23 * (hk t1) + (hk t2)) + 97
    | Typ_dep(t, e) -> 
        23 * (23 * (hk t) + (hashkey_exp e)) + 101
    | Typ_affine t -> 
        23 * (hk t) + 103
    | Typ_lam(_, t1, t2) -> 
        23 * (23 * (hk t1) + (hk t2)) + 107
    | Typ_tlam(_, _, t) -> 
        23 * (hk t) + 109     
    | Typ_ascribed(t, _) -> 
        23 * (hk t) + 113     
    | Typ_unknown _ -> 127
    | Typ_uvar _  ->
        (match compress t with 
           | {v=Typ_uvar(uv, _)} ->  23 * (Unionfind.uvar_id uv) + 131
           | t -> hashkey_typ t)
    | Typ_meta (Meta_alpha t) -> 23 * (hk t) + 157
    | Typ_meta (Meta_tid i) -> 23 * i + 137
    | Typ_meta (Meta_cases tl) -> 23 * (hkl tl) + 139
    | Typ_meta (Meta_PrePost(t1, t2, t3)) -> 
        23 * (23 * 23 * (hk t1) + 23 * (hk t2) + (hk t3)) + 149 
    | Typ_meta (Meta_named(s,t)) -> 23 * (hk t) + 151
    | Typ_meta (Meta_pattern(t, tl)) -> 23 * (hk t) + 157
  and hk t = get_hashkey t aux 
  and hkl l = hashkey_l l hk in 
    hk t

and hashkey_l l f = match l with 
  | [] -> 17
  | hd::tl -> 17 * ((f hd) + (hashkey_l tl f)) + 1

and hashkey_exp e = 0

(* let set_hashkeys t = *)
(*   "set_hashkeys" ^^ lazy *)
(*     (fst <| reduce_typ  *)
(*          (fun rk rt re () k ->  *)
(*             let k', _ = rk () k in  *)
(*               {k' with khashkey=hashkey_kind k'.u}, ()) *)
(*          (fun rk rt re () t ->  *)
(*             let k, _ = rk () t.sort in  *)
(*             let t, _ = rt () {t with sort=k} in *)
(*               {t with hashkey=hashkey_typ t.v}, ()) *)
(*          (fun rk rt re () e ->  *)
(*             let e', _ = re () e in *)
(*               {e' with hashkey=hashkey_exp e'.v}, ()) *)
(*          combine_kind *)
(*          combine_typ *)
(*          combine_exp () t) *)

let check_bvar_identity t : bool = 
  let check_btv flag benv btv =
    let f = function Inr _ -> false | Inl btv' -> btv'.realname.idText = btv.realname.idText in
      match Util.findOpt f benv with 
        | Some(Inl btv') -> 
            if not (btv.instantiation === btv'.instantiation)
            then (pr "Btvar identity is broken for %s\n" (strBvd btv); false)
            else flag              
        | _ -> pr "Btvar is free %s\n" (strBvd btv); flag in 
  let check_bvv flag benv btv =
    let f = function Inl _ -> false | Inr btv' -> btv'.realname.idText = btv.realname.idText in
      match Util.findOpt f benv with 
        | Some(Inr btv') -> 
            if not (btv.instantiation === btv'.instantiation)
            then (pr "Bvar identity is broken for %s\n" (strBvd btv); false)
            else flag
        | _ -> pr "Bvar is free %s\n" (strBvd btv); flag in 
  let fold_t flag benv t = match t with
    | Typ_btvar bv -> check_btv flag benv bv.v, t, None
    | _ -> flag, t, None in
  let fold_e flag benv e = match e with 
      Exp_bvar bv -> check_bvv flag benv bv.v, e
    | _ -> flag, e in
  let ext benv = function 
    | Inl btv -> 
        (Inl btv.v)::benv, Inl btv.v
    | Inr bxv -> 
        (Inr bxv.v)::benv, Inr bxv.v in 
    fst (typ_fold_map fold_t fold_e (fun _ e -> e) ext true [] t)

(*********************************************************************************)
type subst = (list<btvdef*typ> * list<bvvdef*exp>)
type env = subst * bool
let applySubst s x =
  findOpt (function (bvd, _) -> bvd.instantiation === x.v.instantiation) s

let remove_tvar ((tsubst, vsubst), isalpha) a = 
  let tsubst = List.filter (fun (x, _) -> not (bvd_eq x a)) tsubst in 
    ((tsubst, vsubst), isalpha)
      
let remove_xvar ((tsubst, vsubst), isalpha) a = 
  let vsubst = List.filter (fun (x, _) -> not (bvd_eq x a)) vsubst in 
    ((tsubst, vsubst), isalpha)

let rec rt<'a> ((subst:subst, isalpha:bool) as env) (t:typ) (cont:typ -> 'a) : 'a =
  let (tsubst, vsubst) = subst in
  let cont' (s:typ') : 'a = cont (twithinfo s t.sort t.p) in
  let alpha x t1 t2 cont =
    rt env t1
      (fun t1 ->
         let newname = genident None in
         let y = mkbvd (newname, newname) in
         let vsubst = (x,ewithsort (Exp_bvar (bvd_to_bvar_s y t1)) t1)::vsubst in
           rt ((tsubst,vsubst), isalpha) t2
             (fun t2 ->
                cont y t1 t2)) in 
  let alpha_k a k t cont = 
    rk env k
      (fun k ->
         let newname = genident None in
         let b = mkbvd (newname, newname) in
         let tsubst = (a,twithsort (Typ_btvar (bvd_to_bvar_s b k)) k)::tsubst in
           rt ((tsubst,vsubst),isalpha) t
             (fun t -> cont b k t)) in
  let t0 = t in 
  (* let _ = pr "Before compression: %s\n" (Pretty.strTyp t0) in  *)
  (*   if exists_sub_term (fun t -> match t.v with Typ_tlam(a, _, _) when (Pretty.strBvd a = "x_245") -> pr "Pred found(0): %s\n" (Pretty.strTyp t); true | _ -> false) t0 *)
  (*   then raise Impos; *)
  let t = compress t in
  (* let _ =  *)
  (*   let fvs = freevarsTyp t in  *)
  (*     if List.exists (fun x -> Pretty.strBvd x.v = "x_245") (fst fvs) *)
    (*     then (pr "Compressed type %s\n with fvs=%s\n" (Pretty.strTyp t) (sprFvs fvs); raise Impos) in  *)
    match t.v with
      | Typ_btvar x ->
          (match applySubst tsubst x with
             | Some (_, y) -> rt env y cont
             | _ -> cont t)
            
      | Typ_lam(x,t1,body) ->
          if isalpha then
            alpha x t1 body (fun y t1 body -> cont' (Typ_lam(y, t1, body)))
          else
            rts env [(Some x, t1);(None, body)]
              (fun [t1;body] -> cont' (Typ_lam(x,t1,body)))
            
      | Typ_fun (nopt, t1, t2) ->
          (match nopt with 
             | Some x when isalpha -> 
                 alpha x t1 t2 (fun x t1 t2 -> cont' (Typ_fun(Some x, t1, t2)))
             | _ -> 
                 rts env [(nopt,t1);(None,t2)]
                   (fun [t1;t2] -> cont' (Typ_fun(nopt, t1, t2))))
            
      | Typ_dtuple([(nopt,t1);(_,t2)]) ->
          (match nopt with 
             | Some n when isalpha -> 
                 alpha n t1 t2 (fun n t1 t2 -> cont' (Typ_dtuple([(Some n,t1);(None,t2)])))
             | _ -> 
                 rts env [(nopt,t1);(None,t2)]
                   (fun [t1;t2] -> cont' (Typ_dtuple([(nopt,t1);(None,t2)]))))
            
      | Typ_refine (bvd, t, form, b) ->
          if isalpha then 
            alpha bvd t form (fun bvd t form -> cont' (Typ_refine (bvd, t, form, b)))
          else
            rts env [(Some bvd, t);(None, form)] (fun [t;form] -> cont' (Typ_refine (bvd, t, form, b)))
              
      | Typ_tlam(a,k,body) ->
          if isalpha then
            alpha_k a k body (fun b k body -> cont' (Typ_tlam(b, k, body)))
          else
            (rk env k
               (fun k ->
                  let env = remove_tvar env a in 
                    rt env body (fun body -> cont' (Typ_tlam(a,k,body)))))
              
      | Typ_univ(bvd, k, [], t) ->
          if isalpha then 
            alpha_k bvd k t (fun bvd k t -> cont' (Typ_univ(bvd,k,[],t)))
          else
            rk env k
              (fun k ->
                 let env = remove_tvar env bvd in 
                   rt env t (fun t -> cont' (Typ_univ(bvd,k,[],t))))

      | Typ_uvar _
      | Typ_const _
      | Typ_unknown -> cont t
      | Typ_record(fnt_l, topt) ->
          let fnl, t_l = List.unzip fnt_l in
            rts env (List.map (fun t -> (None, t)) t_l)
              (fun tl ->
                 let fnt_l = List.zip fnl t_l in
                   match topt with
                     | None -> cont' (Typ_record(fnt_l, None))
                     | Some s ->
                         rt env s
                           (fun s ->
                              cont (twithinfo (Typ_record(fnt_l, Some s)) t.sort t.p)))

      | Typ_app(t1,t2) ->
          rts env [(None, t1); (None, t2)]
            (fun [t1;t2] -> cont' (Typ_app(t1,t2)))

      | Typ_dep (t, e) ->
          rt env t
            (fun t ->
               re env e (fun e ->
                             cont' (Typ_dep(t,e))))

      | Typ_affine t ->
          rt env t (fun t -> cont' (Typ_affine(t)))
            
      | Typ_ascribed(t, k) ->
          rt env t cont
            
      | Typ_meta (Meta_cases tl) ->
          rtspar env tl
            (fun tl -> cont' (Typ_meta(Meta_cases tl)))
            
      | Typ_meta (Meta_tid i) ->
          cont t

      | Typ_meta (Meta_named(s,t)) ->
          rt env t (fun t -> cont' (Typ_meta(Meta_named(s,t))))
            
      | Typ_meta (Meta_alpha t) ->
          rt env t (fun t -> cont' (Typ_meta (Meta_alpha t)))

      | Typ_meta (Meta_pattern(t, ps)) -> 
        let ts, es = ps |> List.partition (function Inl _ -> true | _ -> false) in 
        let ts = ts |> List.map (function Inl t -> (None, t)) in 
        let es = es |> List.map (function Inr e -> e) in 
        rts env ((None, t)::ts) (fun (t::ts) -> 
          res env es (fun es -> 
            cont' (Typ_meta(Meta_pattern(t, (ts |> List.map Inl) @ (es |> List.map Inr))))))

      | _ -> pr "Unexpected %s" (t.ToString()); raise Impos

and rtspar<'a> (env:env) (ts:typ list) (cont: typ list -> 'a) : 'a =
  (Seq.ofList ts
  |> Seq.map (fun t ->
                async {
                  return (rt<typ> env t (fun t -> t))
                })
  |> Async.Parallel
  |> Async.RunSynchronously
  |> List.ofArray
  |> cont)

(* and rts_maybe_par<'a> (env:env) (t1:typ) (t2:typ) (cont: typ -> typ -> 'a) : 'a = *)
(*   let t2 = compress t2 in *)
(*     match t2.sort.u with  *)
(*       | Kind_dcon(_, _, {u=Kind_dcon(_, _, _)}) ->  *)
(*           (match t2.v with *)
(*              | Typ_btvar _ *)
(*              | Typ_const _ -> rts env [t1;t2] (fun [t1;t2] -> cont t1 t2) *)
(*              | _ -> rtspar env [t1;t2] (fun [t1;t2] -> cont t1 t2)) *)
(*       | _ -> rts env [t1;t2] (fun [t1;t2] -> cont t1 t2) *)
          
and rts<'a> (env:env) (ts:(option<bvvdef> * typ) list) (cont: typ list -> 'a) : 'a = 
  match ts with
    | [] -> cont []
    | (xopt,t)::tl -> rt env t (fun t -> 
                                  let env = match xopt with 
                                    | None -> env
                                    | Some x -> remove_xvar env x in 
                                    rts env tl (fun tl -> cont (t::tl)))
      
and re<'a> ((subst, _) as env:env) (e:exp) (cont:exp -> 'a) : 'a =
  let cont' f = cont (ewithinfo f e.sort e.p) in
    match e.v with
      | Exp_bvar x ->
          (match applySubst (snd subst) x with
             | Some (_, y) -> re env y cont
             | _ -> cont e)
            
      | Exp_bot
      | Exp_fvar _
      | Exp_constant _ -> cont e

      | Exp_constr_app (v, tl, [], el) -> 
          rts env (List.map (fun t -> None, t) tl)
            (fun tl ->
               res env el
                 (fun el ->
                    cont' (Exp_constr_app(v, tl, [], el))))

      | Exp_primop(op, el) ->
          res env el (fun el -> cont' (Exp_primop(op,el)))
            
      | Exp_abs (bvd, t, e) ->
          rt env t
            (fun t ->
               re (remove_xvar env bvd) e
                 (fun e -> cont' (Exp_abs(bvd, t, e))))
            
      | Exp_tabs(bvd, k, [], e) ->
          rk env k
            (fun k ->
               let env = remove_tvar env bvd in 
                 re env e
                   (fun e ->
                      cont' (Exp_tabs(bvd, k, [], e))))
            
      | Exp_app (e1, e2) ->
          res env [e1;e2]
            (fun [e1;e2] -> cont' (Exp_app(e1,e2)))
            
      | Exp_tapp (e, t) ->
          re env e
            (fun e ->
               rt env t
                 (fun t -> cont' (Exp_tapp(e,t))))
            
      | Exp_match(e, eqns, def) ->
          re env e
            (fun e ->
               let pats, branches = List.unzip eqns in
               let env = List.fold_left (fun env (Pat_variant(_, tvs, _, xvs, _)) ->
                                           let env = List.fold_left (fun env t -> match t.v with Typ_btvar a -> remove_tvar env a.v | _ -> env) env tvs in 
                                             List.fold_left (fun env x -> remove_xvar env x.v) env xvs) env pats in 
                 respar env branches
                   (fun branches ->
                      re env def
                        (fun def ->
                           cont' (Exp_match(e, List.zip pats branches, def)))))
            
            
      | Exp_cond (e1, e2, e3) ->
          respar env [e1;e2;e3]
            (fun [e1;e2;e3] -> cont' (Exp_cond(e1, e2, e3)))
            
      | Exp_recd (lidopt, tl, [], fn_e_l) ->
          rts env (List.map (fun t -> None, t) tl)
            (fun tl ->
               let fn, el = List.unzip fn_e_l in
                 res env el (fun el -> cont' (Exp_recd(lidopt, tl, [], List.zip fn el))))
            
      | Exp_proj (e, fn) ->
          re env e (fun e -> cont' (Exp_proj(e, fn)))
            
      | Exp_ascribed (e,t,ev) ->
          re env e cont

      | Exp_let (b, bvd_t_e_l, e) ->
          let xs,tl,el = List.unzip3 bvd_t_e_l in
            rts env (List.map (fun t -> None, t) tl)
              (fun tl ->
                 let env = List.fold_left remove_xvar env xs in 
                 res env el
                   (fun el ->
                      re env e (fun e -> cont' (Exp_let(b, List.zip3 xs tl el, e)))))
              
      | Exp_gvar _ -> raise Impos
          
      | Exp_extern_call(eref, id, t, tl, el) ->
          rts env (List.map (fun t -> None, t) (t::tl))
            (fun (t::tl) ->
               res env el
                 (fun el -> cont' (Exp_extern_call(eref, id, t, tl, el))))
            
      | e -> failwith (spr "Unhandled case %A:" e)

and respar<'a> (env:env) (es:exp list) (cont: exp list -> 'a) : 'a = 
  (Seq.ofList es
  |> Seq.map (fun e ->
                async {
                  return (re<exp> env e (fun e -> e))
                })
  |> Async.Parallel
  |> Async.RunSynchronously
  |> List.ofArray
  |> cont)
  
and res<'a> (env:env) (es:exp list) (cont: exp list -> 'a) : 'a = 
  match es with
    | [] -> cont []
    | e::el -> re env e (fun e -> res env el (fun el -> cont (e::el)))
        
and rk<'a> (((tsubst,vsubst), isalpha) as env:env) (k:kind) (cont:kind -> 'a) : 'a =
  let alpha x t k cont =
    rt env t
      (fun t ->
         let newname = genident None in
         let y = mkbvd (newname, newname) in
         let vsubst = (x,ewithsort (Exp_bvar (bvd_to_bvar_s y t)) t)::vsubst in
           rk ((tsubst,vsubst), isalpha) k
             (fun k ->
                cont y t k)) in 
  let alpha_k a k1 k2 cont = 
    rk env k1
      (fun k1 ->
         let newname = genident None in
         let b = mkbvd (newname, newname) in
         let tsubst = (a,twithsort (Typ_btvar (bvd_to_bvar_s b k)) k)::tsubst in
           rk ((tsubst,vsubst), isalpha) k2
             (fun k2 -> cont b k1 k2)) in
  let cont' l :'a = cont (withhash l) in
    match k(* .u *)with
      | Kind_boxed k -> rk env k cont
      | Kind_star
      | Kind_affine
      | Kind_prop
      | Kind_erasable
      | Kind_unknown -> cont k
      | Kind_tcon (aopt, k1, k2) ->
          (match aopt with 
             | Some a when isalpha -> 
                 alpha_k a k1 k2 (fun b k1 k2 -> cont' (Kind_tcon(Some b, k1, k2)))
             | _ -> 
                 rk<'a> env k1
                   (fun k1 ->
                      let env = match aopt with 
                        | None -> env
                        | Some a -> remove_tvar env a in 
                      rk<'a> env k2 (fun k2 -> cont' (Kind_tcon(aopt, k1, k2)))))
      | Kind_dcon (xopt, t, k) ->
          (match xopt with 
             | Some x when isalpha -> 
                 alpha x t k (fun y t k -> cont' (Kind_dcon(Some y, t, k)))
             | _ -> 
                 let env = match xopt with 
                   | None -> env
                   | Some x -> remove_tvar env x in 
                   rt<'a> env t
                     (fun t ->
                        rk<'a> env k (fun k -> cont' (Kind_dcon(xopt, t, k)))))
            
            
let alpha_fast t = rt (([],[]),true) t (fun t -> t)
let subst_fast substs t = 
  (* let _ = List.iter (fun (x,t) -> pr "['%s -> %s]\n" (Pretty.strBvd x) (Pretty.strTyp t)) (fst substs) in  *)
  (* let _ = List.iter (fun (x,e) -> pr "[%s -> %s]\n" (Pretty.strBvd x) (Pretty.strExp e)) (snd substs) in  *)
  (* let fvs = freevarsTyp t in  *)
  (*   pr "%s\n" (sprFvs fvs); *)
    (* substitute_l_typ_or_exp t ((List.map Inl (fst substs))@(List.map Inr (snd substs))) *)
    rt (substs,false) t (fun t -> t)
      (* let subst_fast substs t = rt (substs,false) t (fun t -> t) *)

let replace_subterm (t:typ) (replk:kind -> option<kind>) (replt:typ -> option<typ>) (replv:exp -> option<exp>) : typ =
  fst <| (reduce_typ 
            (fun vk rt re () binders k -> 
              match replk k with 
                | None -> vk () binders k
                | Some k -> k, ())
            (fun rk vt re () binders t -> 
              match replt t with 
                | None -> vt () binders t
                | Some t -> t, ())
            (fun rk rt ve () binders e -> 
              match replv e with 
                | None -> ve () binders e
                | Some e -> e, ())
            combine_kind
            combine_typ
            combine_exp () [] t)

let substitute_proj_l typ lrvs : typ =
  let reple e = Util.find_map lrvs (fun (lr,v) -> 
    match lr.v, e.v with
      | (Exp_constr_app(lr_lid, _, _, [{v=Exp_bvar bv}]), 
         Exp_constr_app(lr_lid', _, _, [{v=Exp_bvar bv'}])) 
          when (Sugar.lid_equals lr_lid.v lr_lid'.v && bvar_eq bv bv') -> 
        Some v
      | _ -> None) in 
  replace_subterm typ (fun k -> None) (fun t -> None) reple
      
let substitute_proj typ (lr:exp, v:exp) = substitute_proj_l typ [(lr,v)]
            
let destruct typ lid = 
  match flattenTypAppsAndDeps typ with 
    | {v=Typ_const(tc,_)}, args when Sugar.lid_equals tc.v lid -> Some args
    | _ -> None
