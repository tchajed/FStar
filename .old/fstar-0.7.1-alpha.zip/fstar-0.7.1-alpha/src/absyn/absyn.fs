#light "off"
module Microsoft.FStar.Absyn

open Util
open Profiling 

exception Err of string
exception Error of string * Range.range

type ident = Sugar.ident
type lident = Sugar.LongIdent
let rec sli (l:lident) : string = match l.lid with 
  | hd::tl when hd.idText="Prims" -> String.concat "." (tl |> List.map (fun x -> x.idText))
  | _ -> l.str
let asLid ids = {Sugar.lid=ids; Sugar.str=String.concat "." (ids |> List.map (fun x -> x.idText))}

(* type hk = ref<option<int32>> *)
type withinfo<'a,'t> = {
  v: 'a; 
  sort: 't;
  p: Range.range; 
  (* hashkey:hk; *)
} with override x.ToString() = 
    let s = x.v.ToString() in 
      if !Options.verbosity = 17
      then spr "(%s:%s)" s (x.sort.ToString())
      else s
end


(* type withhash<'a> = { *)
(*   u:'a; *)
(*   (\* khashkey:hk; *\) *)
(* } with override x.ToString() = x.u.ToString() end *)

type var<'t>  = withinfo<lident,'t>
  (* Bound vars have a name for pretty printing, 
     and a unique name generated during desugaring. 
     Only the latter is used during type checking.  *)
type fieldname = lident

type inst<'a> = ref<option<'a>>

type bvdef<'a> = {ppname:ident; realname:ident; instantiation:inst<'a>}
type bvar<'a,'t> = withinfo<bvdef<'a>,'t> 

let range_of_bvd x = x.ppname.idRange
let strBvd x = 
    if !Options.print_real_names
    then x.realname.idText
    else x.ppname.idText

type typ' =  
  | Typ_btvar  of btvar
  | Typ_const  of var<kind> * option<Sugar.externref>
  | Typ_record of list<fieldname * typ> * option<typ>
  | Typ_fun    of option<bvvdef> * typ * typ (* stash the formal param for pp *)
  | Typ_univ   of btvdef * kind * list<formula> * typ (* formulas are instantiation constraints *)
  | Typ_dtuple of list<option<bvvdef> * typ>
  | Typ_refine of bvvdef * typ * formula * bool (* bool => ghost *)
  | Typ_app    of typ * typ
  | Typ_dep    of typ * exp
  | Typ_affine of typ
  | Typ_lam    of bvvdef * typ * typ   (* fun (x:t) => T *)
  | Typ_tlam   of btvdef * kind * typ  (* fun ('a::k) => T *) 
  | Typ_ascribed of typ * kind
  | Typ_unknown
  | Typ_uvar   of Unionfind.uvar<uvar_basis> * kind
  | Typ_meta   of meta

and typ = withinfo<typ', kind>
and btvdef = bvdef<typ>
and bvvdef = bvdef<exp>
and btvar = bvar<typ,kind>
and bvvar = bvar<exp,typ>

and meta = 
  | Meta_PrePost of formula * typ * formula
  | Meta_cases of list<typ>
  | Meta_tid of int
  | Meta_alpha of typ
  | Meta_named of string * typ
  | Meta_pattern of typ * list<formula_pat>
    //  | Meta_RefinedPrePost of formula * typ * formula * typ

and uvar_basis = 
  | Uvar of (typ -> kind -> bool) (* A well-formedness check to ensure that all names are in scope *)
  | Fixed of typ
  | Delayed of typ
      
and exp' =
  | Exp_bvar       of bvvar
  | Exp_fvar       of var<typ> * option<Sugar.externref>
  | Exp_constant   of Sugar.sconst
  | Exp_constr_app of var<typ> * list<typ> * list<exp> * list<exp>  (* D [t1;..;tn] [] [e1;..;em] ignore the first list<exp>; its for phantoms. for most purposes, it is always [] *)
  | Exp_abs        of bvvdef * typ * exp 
  | Exp_tabs       of btvdef * kind * list<formula> * exp            (* formulas are instantiation constraints *)
  | Exp_app        of exp * exp
  | Exp_tapp       of exp * typ                                     (* produced during type checking *)
  | Exp_match      of exp * list<pat * exp> * exp                   (* always includes a default case *)
  | Exp_cond       of exp * exp * exp       
  | Exp_recd       of option<lident> * list<typ> * list<exp> * list<fieldname * exp>  (* let r' = {r with f=1} *)
  | Exp_proj       of exp * fieldname 
  | Exp_ascribed   of exp * typ * evidence                 (* evidence is needed in translation to bytecode *)
  | Exp_let        of bool * list<bvvdef * typ * exp> * exp (* let (rec?) x1 = e1 AND ... AND xn = en in e *)
  | Exp_gvar       of int (* only for internal use by proof extraction. unbound variable deBruijn index *) 
  | Exp_extern_call of Sugar.externref * ident * typ * list<typ> * list<exp>
  | Exp_primop     of ident * list<exp>
  | Exp_bot                                 (* error case *)

and exp = withinfo<exp',typ>      

and formula_pat = Disj<typ,exp>

and pat = 
  | Pat_variant of lident * list<typ> * list<exp> * list<bvvar> * bool (* flag=true => list<typ> are fresh existential variables *)
with override x.ToString() =  match x with 
  | Pat_variant(lid, tl, el, xs, _) -> spr "%s %s" (sli lid) (String.concat " " (List.map (fun (x:bvvar) -> (x.v.ppname.idText)) xs))
end

and evidence=list<Disj<typ*typ, exp*exp>>
      
and kind =
  | Kind_boxed of kind (* B_* or B_A *)
  | Kind_star
  | Kind_affine
  | Kind_prop
  | Kind_erasable
  | Kind_tcon of option<btvdef> * kind * kind (* 'a::* => k, 'a::(t => k) => k, 'a::$A => k, etc. *)
  | Kind_dcon of option<bvvdef> * typ * kind (* x:t => k *)
  | Kind_unknown
with override x.ToString() = match x with 
      | Kind_boxed k -> k.ToString()
      | Kind_star -> "*"
      | Kind_affine -> "A"
      | Kind_prop -> "P"
      | Kind_erasable -> "E"
      | Kind_tcon(Some x, k, k') -> spr "(%s::%s => %s)" (strBvd x) (k.ToString()) (k'.ToString())
      | Kind_tcon(_, k, k') -> spr "(%s => %s)" (k.ToString()) (k'.ToString())
      | Kind_dcon(Some x, t, k) -> spr "(%s:%s => %s)" (strBvd x) (t.ToString()) (k.ToString())
      | Kind_dcon(_, t, k) -> spr "(%s => %s)" (t.ToString()) (k.ToString())
      | Kind_unknown -> "_"
end

(* and kind = withhash<kind'> *)

and formula = typ

type uvar = Unionfind.uvar<uvar_basis>

type tparam =
  | Tparam_typ  of btvdef * kind (* idents for pretty printing *)
  | Tparam_term of bvvdef * typ

type aqual = Private | Public

type sigelt =
  | Sig_tycon_kind   of lident * list<tparam> * kind * bool * list<lident> * list<Sugar.logic_tag> (* bool is for a prop, list<lident> identifies mutuals *)
  | Sig_typ_abbrev   of lident * list<tparam> * kind * typ
  | Sig_record_typ   of lident * list<tparam> * kind * typ * option<Sugar.externref>
  | Sig_datacon_typ  of (lident * list<tparam> * typ * option<Sugar.atag> * aqual *        (* lident identifies type name *)
                         option<lident> * option<Sugar.externref> * list<formula_pat>) 
  | Sig_value_decl   of lident * typ 
  | Sig_extern_value of Sugar.externref * lident * typ
  | Sig_extern_typ   of Sugar.externref * sigelt (* lident * typ * kind *)
  | Sig_query        of lident * formula
  | Sig_ghost_assume of lident * formula * aqual
  | Sig_logic_function of lident * typ * list<Sugar.logic_tag>

type signature = list<sigelt>
type sigelts = list<sigelt>
type letbinding = list<bvvdef * typ * exp> (* let recs may have more than one element *)
type pragma = 
  | PRAGMA_MONADIC of typ * typ * typ
  | PRAGMA_RELATIONAL

type modul = {
  name: lident;
  extends: option<lident>;
  pos: Range.range;
  signature: signature;
  letbindings: list<letbinding * bool>; (* the boolean signals a let rec *)
  main:option<exp>;
  exports: signature;
  pragmas: list<pragma>
}

(* ************************Utilities*************************************** *)
let dummyRange = 0L
let string2ident str = Sugar.ident(str, dummyRange)

let inst () = ref None
let mkbvd (x,y) = {ppname=x;realname=y;instantiation=inst()}
let setsort w t = {v=w.v; sort=t; p=w.p; (* hashkey=w.hashkey *)}
let withhash k = k
(* let withhash k = {u=k; khashkey=ref None}(\* hashkey_kind k} *\) *)


let ewithinfo e s r = {v=e; sort=s; p=r(* ; hashkey=ref None *)}(* hashkey_exp e} *)
let twithinfo t s r = {v=t; sort=s; p=r(* ; hashkey=ref None *)}(* hashkey_typ t} *)
let fvwithinfo (v:lident) s r = {v=v; 
                                 sort=s; 
                                 p=r; 
                                 (* hashkey=ref None *)}(* (Sugar.text_of_lid v).GetHashCode()*151} *)
let bvwithinfo t s r = {v=t; sort=s; p=r; (* hashkey=ref None *)}

let ewithsort v s = ewithinfo v s dummyRange
let twithsort t s = twithinfo t s dummyRange
let fvwithsort v s = fvwithinfo v s dummyRange
let bvwithsort v s = bvwithinfo v s dummyRange

let kunknown = withhash Kind_unknown
let tunknown = twithsort Typ_unknown kunknown
let ewithpos e r =  ewithinfo e tunknown r
let twithpos t r = twithinfo t kunknown r
let fvwithpos fv r = fvwithinfo fv tunknown r
let ftvwithpos fv r = fvwithinfo fv kunknown r
let bvwithpos bv r = bvwithinfo bv tunknown r
let btvwithpos bv r = bvwithinfo bv kunknown r

(* let new_bvar ppn rn r = bvwithpos (mkbvd (ppn, rn)) r *)
let pp_name bvd = bvd.ppname
let real_name bvd = bvd.realname
let bvar_ppname bv = bv.v.ppname 
let bvar_real_name bv = bv.v.realname

let bvar_eq (bv1:bvar<'a,'b>) (bv2:bvar<'a,'b>) = 
  (bvar_real_name bv1).idText = (bvar_real_name bv2).idText
let bvd_eq bvd1 bvd2 = bvd1.realname.idText= bvd2.realname.idText
let fvar_eq fv1 fv2 = Sugar.lid_equals fv1.v fv2.v

(* let bvd_to_bvar (bvd:bvdef<'a>) = *)
(*   {v=bvd; pos=bvd.ppname.idRange; sort=tunknown; hashkey=ref None} *)
    
let bvd_to_bvar_s bvd sort =
  let pos = bvd.ppname.idRange in
    {v=bvd; sort=sort; p=pos; (* hashkey=ref None *)}

let bvar_to_bvd bv = bv.v

let bvd_to_typ bvd k = 
  let bvar = bvd_to_bvar_s bvd k in
  let t' = Typ_btvar bvar in 
    twithsort t' k
let bvd_to_exp bvd t = 
  let bvar = bvd_to_bvar_s bvd t in
  let e = Exp_bvar bvar in 
    ewithsort e t
      (* let bvar_index bv = let (ix, _, _) = bv.v in ix *)

let gensym r : string = match r with 
    None -> Sugar.nng.Apply "x" dummyRange
  | Some r -> Sugar.nng.Apply "x" r

let genproofsym r = match r with 
    None -> Sugar.nng.Apply "__proofsym" dummyRange
  | Some r -> Sugar.nng.Apply "__proofsym" r
      
let rec gensyms = function 
    0 -> []
  | n -> (gensym None)::gensyms (n-1)

let genident r = 
  let sym = gensym r in
    match r with 
        None -> Sugar.ident(sym, dummyRange)
      | Some r -> Sugar.ident(sym, r)
          
let new_bvd ropt = let id = genident ropt in mkbvd (id,id)
let gen_bvar sort = let bvd = (new_bvd None) in bvd_to_bvar_s bvd sort
let gen_bvar_p r sort = let bvd = (new_bvd (Some r)) in bvd_to_bvar_s bvd sort
let new_proof_bvd () = 
  let id = Sugar.ident(genproofsym None, dummyRange) in 
    mkbvd (id,id)
let is_proof_bvd x = x.realname.idText.StartsWith("__proofsym")
  
let bvdef_of_str s = let id = Sugar.ident(s, dummyRange) in mkbvd(id, id)
                                                              (* type bvar_maps = ((int->int->bvar<kind>->typ) * (int->int->bvar<typ>->exp'))     *)

let lbl_lid = Sugar.path_to_lid dummyRange ["Prims"; "LBL"] 
let rec compress' typ' = match typ' with
  | Typ_uvar (uv,k) -> 
      begin
        match Unionfind.find uv with 
          | Delayed _
          | Uvar _ -> typ'
          | Fixed typ -> compress' typ.v
      end
  | _ -> typ' 
and compress t = 
  let t' = compress' t.v in
    if LanguagePrimitives.PhysicalEquality t' t.v then t
    else twithinfo t' t.sort t.p

let rec compress_hard' typ' = match typ' with
  | Typ_uvar (uv,k) -> 
      begin
        match Unionfind.find uv with 
          | Uvar _ -> typ'
          | Delayed typ
          | Fixed typ -> compress' typ.v
      end
  | _ -> typ' 
and compress_hard t = 
  let t' = compress_hard' t.v in
    if LanguagePrimitives.PhysicalEquality t' t.v then t
    else twithinfo t' t.sort t.p

let rec kind_fold_map'
    (f: 'env -> 'benv -> typ' -> ('env * typ' * option<kind>))
    (g: 'env -> 'benv -> exp' -> ('env * exp'))
    (l: 'env -> exp -> exp)
    (ext: 'benv -> Disj<btvar, bvvar> -> ('benv * Disj<btvdef,bvvdef>))
    (env:'env) (benv:'benv) (k:kind) (cont: ('env * kind) -> 'res) : 'res =
  match k(* .u *) with
    | Kind_prop
    | Kind_erasable
    | Kind_star
    | Kind_unknown
    | Kind_affine as k' -> cont (env, withhash <| k')
    | Kind_tcon(aopt, k, k') ->
        kind_fold_map' f g l ext env benv k
          (fun (env, k) ->
             let benv, aopt = match aopt with
               | None -> benv, None
               | Some a ->
                   let benv, (Inl bvd) = ext benv (Inl(bvwithsort a k)) in
                     benv, Some bvd in (* Note: previously, with qkind, we were extending the benv before folding over k *)
               kind_fold_map' f g l ext env benv k'
                 (fun (env, k') ->
                    cont (env, withhash <| Kind_tcon(aopt, k, k'))))
    | Kind_dcon(xopt, t, k') ->
        typ_fold_map' f g l ext env benv t
          (fun (env, t) ->
             let benv, xopt = match xopt with
               | None -> benv, None
               | Some x -> let benv, (Inr bvd) = ext benv (Inr(bvwithsort x t)) in benv, Some bvd in
               kind_fold_map' f g l ext env benv k'
                 (fun (env, k') ->
                    cont (env, withhash <| Kind_dcon(xopt, t, k'))))

    | Kind_boxed k ->
        kind_fold_map' f g l ext env benv k
          (fun (env, k) ->
             cont (env, withhash <| Kind_boxed k))

and typs_fold_map'
    (f: 'env -> 'benv -> typ' -> ('env * typ' * option<kind>))
    (g: 'env -> 'benv -> exp' -> ('env * exp'))
    (l: 'env -> exp -> exp)
    (ext: 'benv -> Disj<btvar, bvvar> -> ('benv * Disj<btvdef,bvvdef>))
    (env:'env) (benv:'benv) (ts:list<typ>) (cont:('env * list<typ>) -> 'res) : 'res =

  let rec aux env tl cont = match tl with
    | [] -> cont (env, [])
    | t::tl -> typ_fold_map' f g l ext env benv t (fun (env,t') -> aux env tl (fun (env, accum) -> cont (env, t'::accum)))
  in
    aux env ts cont 

and exps_fold_map'
    (f: 'env -> 'benv -> typ' -> ('env * typ' * option<kind>))
    (g: 'env -> 'benv -> exp' -> ('env * exp'))
    (l: 'env -> exp -> exp)
    (ext: 'benv -> Disj<btvar, bvvar> -> ('benv * Disj<btvdef,bvvdef>))
    (env:'env) (benv:'benv) (es:list<exp>) (cont:('env * list<exp>) -> 'res) : 'res =
  
  let rec aux env tl cont = match tl with
    | [] -> cont (env, [])
    | e::tl -> exp_fold_map' f g l ext env benv e (fun (env,t') -> aux env tl (fun (env, accum) -> cont (env, t'::accum)))
  in
    aux env es cont
      
      
      
and typ_fold_map'
    (f: 'env -> 'benv -> typ' -> ('env * typ' * option<kind>))
    (g: 'env -> 'benv -> exp' -> ('env * exp'))
    (l: 'env -> exp -> exp)
    (ext: 'benv -> Disj<btvar, bvvar> -> ('benv * Disj<btvdef,bvvdef>))
    (env:'env) (benv:'benv) (t:typ) (contorig:('env * typ) -> 'res) : 'res =
  let t_top = compress t in
  let t = t_top.v in
  let cont (env, t', k) = contorig (env, twithinfo t' k t_top.p) in
    match t with
      | Typ_uvar (_,k) ->
          let env, t', kopt = f env benv t in
            (match t' with
               | Typ_uvar(uv, k) ->
                   kind_fold_map' f g l ext env benv k
                     (fun (env, k) ->
                        cont (env, Typ_uvar(uv, k), k))
               | _ ->
                   let k = match kopt with
                     | None -> t_top.sort
                     | Some k -> k in
                     kind_fold_map' f g l ext env benv k
                       (fun (env, k) ->
                          cont (env, t', k)))
      | Typ_btvar btv -> 
          (match !btv.v.instantiation with 
             | None -> 
                 let env, t', kopt = f env benv t in
                   (match kopt with
                      | None ->
                          kind_fold_map' f g l ext env benv t_top.sort
                            (fun (env, k) -> cont (env, t', k))
                      | Some k -> cont (env, t', k))
             | Some t -> 
                 typ_fold_map' f g l ext env benv t contorig)

          
      | Typ_const _
      | Typ_unknown ->
          let env, t', kopt = f env benv t in
            (match kopt with
               | None ->
                   kind_fold_map' f g l ext env benv t_top.sort
                     (fun (env, k) -> cont (env, t', k))
               | Some k -> cont (env, t', k))
      | _ ->
          let cont (env, t') =
            kind_fold_map' f g l ext env benv t_top.sort
              (fun (env,k) -> cont (env, t', k)) in

            match t with
              | Typ_record(fnt_l, topt) ->
                  typs_fold_map' f g l ext env benv (List.map snd fnt_l)
                    (fun (env, tl) ->
                       let fnt_l' = List.map2 (fun (fn, _) t' -> (fn,t')) fnt_l tl in
                         match topt with
                           | None -> cont (env, Typ_record (fnt_l', None))
                           | Some t ->
                               typ_fold_map' f g l ext env benv t
                                 (fun (env, t) ->
                                    cont (env, Typ_record (fnt_l', Some t))))
                    
              | Typ_fun (nopt, t1, t2) ->
                  typ_fold_map' f g l ext env benv t1
                    (fun (env, t1') ->
                       let benv', nopt' = match nopt with
                         | None -> benv, nopt
                         | Some bvd ->
                             let benv, (Inr bvd') = ext benv (Inr (bvwithsort bvd t1)) in
                               benv, Some bvd' in
                         typ_fold_map' f g l ext env benv' t2
                           (fun (env, t2') ->
                              cont (env, Typ_fun(nopt', t1', t2'))))
                    
              | Typ_univ (bvd, k, formulas, t) ->
                  let benv', (Inl bvd') = ext benv (Inl (bvwithsort bvd k)) in
                    typ_fold_map' f g l ext env benv' t
                      (fun (env, t') ->
                         kind_fold_map' f g l ext env benv' k
                           (fun (env, k') ->
                              typs_fold_map' f g l ext env benv' formulas
                                (fun (env, formulas) ->
                                   cont (env, Typ_univ(bvd', k', formulas, t')))))
                      
              | Typ_dtuple([(nopt,t1);(_,t2)]) ->
                  typ_fold_map' f g l ext env benv t1
                    (fun (env, t1') ->
                       let benv', nopt' = match nopt with
                         | None -> benv, nopt
                         | Some bvd ->
                             let benv, (Inr bvd') = ext benv (Inr (bvwithsort bvd t1)) in
                               benv, Some bvd' in
                         typ_fold_map' f g l ext env benv' t2
                           (fun (env, t2') ->
                              cont (env, Typ_dtuple([(nopt', t1'); (None, t2')]))))
                    
              | Typ_refine (bvd, t, form, b) ->
                  typ_fold_map' f g l ext env benv t
                    (fun (env, t') ->
                       let benv', (Inr bvd') = ext benv (Inr (bvwithsort bvd t)) in
                         typ_fold_map' f g l ext env benv' form
                           (fun (env, form') ->
                              cont (env, Typ_refine(bvd', t', form', b))))

              | Typ_app(t1, t2) ->
                  typ_fold_map' f g l ext env benv t1
                    (fun (env, t1') ->
                       typ_fold_map' f g l ext env benv t2
                         (fun (env, t2') ->
                            cont (env, Typ_app(t1', t2'))))

              | Typ_dep(({v=Typ_const(v, _)} as lbl), str) 
                  when Sugar.lid_equals lbl_lid v.v -> 
                  cont (env, Typ_dep(lbl, l env str))
                    
              | Typ_dep (t, e) ->
                  typ_fold_map' f g l ext env benv t
                    (fun (env, t') ->
                       exp_fold_map' f g l ext env benv e
                         (fun (env, e') ->
                            cont (env, Typ_dep(t', e'))))

              | Typ_lam(x, t, t') ->
                  typ_fold_map' f g l ext env benv t
                    (fun (env, t) ->
                       let benv', (Inr bvd') = ext benv (Inr (bvwithsort x t)) in
                         typ_fold_map' f g l ext env benv' t'
                           (fun (env, t') ->
                              cont (env, Typ_lam(bvd', t, t'))))

              | Typ_tlam(bvd, k, t) ->
                  let benv', (Inl bvd') = ext benv (Inl (bvwithsort bvd k)) in
                    typ_fold_map' f g l ext env benv' t
                      (fun (env, t') ->
                         kind_fold_map' f g l ext env benv' k
                           (fun (env, k') ->
                              cont (env, Typ_tlam(bvd', k', t'))))
                      
              | Typ_affine t ->
                  typ_fold_map' f g l ext env benv t
                    (fun (env, t') -> cont (env, Typ_affine t' ))
                    
              | Typ_ascribed(t, k) ->
                  typ_fold_map' f g l ext env benv t
                    (fun (env, t') ->
                       kind_fold_map' f g l ext env benv k
                         (fun (env, k') ->
                            cont (env, Typ_ascribed(t,k))))

              | Typ_meta (Meta_cases tl) ->
                  typs_fold_map' f g l ext env benv tl
                    (fun (env, tl') -> cont (env, Typ_meta(Meta_cases tl')))

              | Typ_meta (Meta_tid i) ->
                  cont (env, Typ_meta(Meta_tid i))

              | Typ_meta (Meta_named(s, t)) ->
                  typ_fold_map' f g l ext env benv t 
                    (fun (env, t') -> cont (env, Typ_meta(Meta_named(s, t'))))

              | Typ_meta (Meta_alpha t) -> 
                  typ_fold_map' f g l ext env benv t
                    (fun (env, t') -> cont (env, Typ_meta (Meta_alpha t')))

              | Typ_meta (Meta_pattern(t, ps)) -> 
                let rec aux env ps cont = match ps with 
                  | [] -> cont (env, [])
                  | Inl t::tl ->  typ_fold_map' f g l ext env benv t (fun (env, t') -> 
                    aux env tl (fun (env, accum) -> cont (env, Inl t'::accum)))
                  | Inr v::tl ->  exp_fold_map' f g l ext env benv v (fun (env, e') -> 
                    aux env tl (fun (env, accum) -> cont (env, Inr e'::accum))) in 
                typ_fold_map' f g l ext env benv t 
                  (fun (env, t') -> aux env ps (fun (env, ps) -> cont (env, Typ_meta(Meta_pattern(t', ps)))))

              | _ -> pr "Unexpected %s" (t.ToString()); raise Impos


and exp_fold_map'
    (f: 'env -> 'benv -> typ' -> ('env * typ' * option<kind>))
    (g: 'env -> 'benv -> exp' -> ('env * exp'))
    (l: 'env -> exp -> exp)
    (ext: 'benv -> Disj<btvar, bvvar> -> ('benv * Disj<btvdef,bvvdef>))
    (env:'env) (benv:'benv) (e:exp) (contorig : ('env * exp) -> 'res) : 'res =
  let cont (env, exp') =
    typ_fold_map' f g l ext env benv e.sort
      (fun (env, sort') -> contorig (env, ewithinfo exp' sort' e.p)) in
    match e.v with
      | Exp_bvar bv -> 
          (match !bv.v.instantiation with 
             | None -> cont (g env benv e.v)
             | Some e -> exp_fold_map' f g l ext env benv e contorig)
      | Exp_bot
      | Exp_fvar _
      | Exp_constant _ -> cont (g env benv e.v)
      | Exp_constr_app (v, tl, el1, el) -> (* change v to an expression instead of a var? *)
          let env, _ = g env benv (Exp_fvar (v, None)) in
            typs_fold_map' f g l ext env benv tl
              (fun (env, tl) ->
                 exps_fold_map' f g l ext env benv el1
                   (fun (env, el1) ->
                      exps_fold_map' f g l ext env benv el
                        (fun (env, el) ->
                           cont (env, Exp_constr_app(v,tl,el1,el)))))

      | Exp_primop(op, el) ->
          exps_fold_map' f g l ext env benv el
            (fun (env, el) ->
               cont (env, Exp_primop(op, el)))
            
      | Exp_abs (bvd, t, e) ->
          typ_fold_map' f g l ext env benv t
            (fun (env, t') ->
               let benv', (Inr bvd') = ext benv (Inr (bvwithsort bvd t)) in
                 exp_fold_map' f g l ext env benv' e
                   (fun (env, e') ->
                      cont (env, Exp_abs(bvd', t', e'))))
            
      | Exp_tabs(bvd, k, formulas, e) ->
          kind_fold_map' f g l ext env benv k
            (fun (env, k') ->
               let benv', (Inl bvd') = ext benv (Inl (bvwithsort bvd k)) in
                 exp_fold_map' f g l ext env benv' e
                   (fun (env, e') ->
                      typs_fold_map' f g l ext env benv' formulas
                        (fun (env, formulas') ->
                           cont (env, Exp_tabs(bvd', k', formulas', e')))))
            
      | Exp_app (e1, e2) ->
          exp_fold_map' f g l ext env benv e1
            (fun (env, e1') ->
               exp_fold_map' f g l ext env benv e2
                 (fun (env, e2') ->
                    cont (env, Exp_app(e1', e2'))))
            
      | Exp_tapp (e, t) ->
          exp_fold_map' f g l ext env benv e
            (fun (env, e') ->
               typ_fold_map' f g l ext env benv t
                 (fun (env, t') ->
                    cont (env, Exp_tapp(e',t'))))
            
      | Exp_match(e, eqns, def) ->
          let rec binders_fold_map env benv bvl cont = match bvl with
            | [] -> cont (env, benv, [])
            | bv::rest ->
                typ_fold_map' f g l ext env benv bv.sort
                  (fun (env, bvt') ->
                     let benv', (Inr bvd') = ext benv (Inr (bvwithsort (bvar_to_bvd bv) bv.sort)) in
                       binders_fold_map env benv' rest
                         (fun (env, benv, rest) ->
                            let all = (bvd_to_bvar_s bvd' bvt')::rest in
                              cont (env, benv', all))) in

          let rec pats_fold_map env benv eqns cont = match eqns with
            | [] -> cont (env, [])
            | (Pat_variant (lid, tl, phantoms, bvl, is_exvar), branch)::rest ->
                typs_fold_map' f g l ext env benv tl
                  (fun (env, tl') ->
                     exps_fold_map' f g l ext env benv phantoms
                       (fun (env, phantoms) ->
                          binders_fold_map env benv bvl (fun (env, benv', bvl') ->
                                                           let pat = Pat_variant(lid, tl', phantoms, bvl', is_exvar) in
                                                             exp_fold_map' f g l ext env benv' branch
                                                               (fun (env, branch) ->
                                                                  let eqn = (pat, branch) in
                                                                    pats_fold_map env benv rest
                                                                      (fun (env, eqns) -> cont (env, eqn::eqns)))))) in
            exp_fold_map' f g l ext env benv e
              (fun (env, e) ->
                 exp_fold_map' f g l ext env benv def
                   (fun (env, def) ->
                      pats_fold_map env benv eqns
                        (fun (env, eqns) ->
                           cont (env, Exp_match(e, eqns, def)))))
              
              
      | Exp_cond (e, e1, e2) ->
          exp_fold_map' f g l ext env benv e
            (fun (env1, e') ->
               exp_fold_map' f g l ext env1 benv e1
                 (fun (env2, e1') ->
                    exp_fold_map' f g l ext env2 benv e2
                      (fun (env3, e2') ->
                         cont (env3, Exp_cond(e',e1',e2')))))
            
      | Exp_recd (lidopt, tl, phantoms, fn_e_l) ->
          typs_fold_map' f g l ext env benv tl
            (fun (env, tl) ->
               exps_fold_map' f g l ext env benv phantoms
                 (fun (env, phantoms) ->
                    exps_fold_map' f g l ext env benv (List.map snd fn_e_l)
                      (fun (env, el) ->
                         let fn_e_l = List.map2 (fun (fn, _) e -> (fn,e)) fn_e_l el in
                           cont (env, Exp_recd(lidopt, tl, phantoms, fn_e_l)))))
            
      | Exp_proj (e, fn) ->
          exp_fold_map' f g l ext env benv e
            (fun (env, e') ->
               cont (env, Exp_proj(e', fn)))
            
      | Exp_ascribed (e,t,ev) ->
          let rec ev_fold_map env ev cont = match ev with
            | [] -> cont (env, [])
            | (Inl (t1, t2))::rest ->
                typ_fold_map' f g l ext env benv t1
                  (fun (env, t1') ->
                     typ_fold_map' f g l ext env benv t2
                       (fun (env, t2') ->
                          ev_fold_map env rest (fun (env, out) ->
                                                  cont (env, (Inl(t1',t2')::out)))))
            | (Inr (bv, e))::rest ->
                exp_fold_map' f g l ext env benv bv
                  (fun (env, bv') ->
                     exp_fold_map' f g l ext env benv e
                       (fun (env, e') ->
                          ev_fold_map env rest (fun (env, out) ->
                                                  cont (env, (Inr(bv',e'))::out)))) in
            
            exp_fold_map' f g l ext env benv e
              (fun (env, e') ->
                 typ_fold_map' f g l ext env benv t
                   (fun (env, t') ->
                      ev_fold_map env ev
                        (fun (env, ev') ->
                           cont (env, Exp_ascribed(e',t', ev')))))
              
      | Exp_let (false, bvd_t_e_l, e) ->
          let rec binders_fold_map env benv bvd_t_e_l cont = match bvd_t_e_l with
            | [] -> cont (env, benv, [])
            | (bv,t,e)::rest ->
                exp_fold_map' f g l ext env benv e
                  (fun (env, e') ->
                     typ_fold_map' f g l ext env benv t
                       (fun (env, t') ->
                          let benv', (Inr bv') = ext benv (Inr (bvwithsort bv t)) in
                            binders_fold_map env benv' rest (fun (env, benv, accum) ->
                                                               cont (env, benv, (bv',t',e')::accum)))) in
            binders_fold_map env benv bvd_t_e_l
              (fun (env, benv', bvd_t_e_l) ->
                 exp_fold_map' f g l ext env benv' e
                   (fun (env, e') -> cont (env, Exp_let(false, bvd_t_e_l, e'))))
              
      | Exp_let (true, bvd_t_e_l, e) ->
          let benv', bvd_t_e_l' = List.fold_left
            (fun (benv, out) (bv,t,e) ->
               let benv', (Inr bv') = ext benv (Inr (bvwithsort bv t)) in
                 benv', (bv', t, e)::out) (benv,[]) bvd_t_e_l in
          let bvs, typs, exps = List.unzip3 bvd_t_e_l' in
            typs_fold_map' f g l ext env benv' typs
              (fun (env, tl) ->
                 exps_fold_map' f g l ext env benv' exps
                   (fun (env, el) ->
                      let bvd_t_e_l' = List.zip3 bvs typs exps in
                        exp_fold_map' f g l ext env benv' e
                          (fun (env, e') ->
                             cont (env, Exp_let(true, bvd_t_e_l', e')))))
              
      | Exp_gvar _ -> raise Impos
          
      | Exp_extern_call(eref, id, t, tl, el) ->
          typs_fold_map' f g l ext env benv (t::tl)
            (fun (env, (t::tl)) ->
               exps_fold_map' f g l ext env benv el
                 (fun (env, el) ->
                    cont (env, Exp_extern_call(eref, id, t, tl, el))))
            
      | e -> failwith (spr "Unhandled case %A:" e)
          
let typs_fold_map f g l ext env benv t = typs_fold_map' f g l ext env benv t (fun x -> x)
let typ_fold_map f g l ext env benv t = typ_fold_map' f g l ext env benv t (fun x -> x)
let exp_fold_map f g l ext env benv t = exp_fold_map' f g l ext env benv t (fun x -> x)
let kind_fold_map f g l ext env benv t = kind_fold_map' f g l ext env benv t (fun x -> x)

(*********************************************************************************)
  
let rec descend_typ_map 
    (f: 'env -> typ' -> ('env * typ'))
    (g: 'env -> exp' -> ('env * exp'))
    (env:'env) (t:typ) : ('env * typ) =
  let t_top = compress t in
  let env, t = f env t_top.v in
  let env', t' = match t with 
    | Typ_uvar _ 
    | Typ_unknown -> env, t

    | Typ_btvar bv -> 
        let env', bvsort = descend_kind_map f g env bv.sort in
        let bv' = setsort bv bvsort in
          env', Typ_btvar bv'

    | Typ_const (fv, eref) -> 
        let env', fvsort = descend_kind_map f g env fv.sort in
        let fv' = setsort fv fvsort in
          env', Typ_const (fv', eref)

    | Typ_record (fnt_l, topt) -> 
        let env', fnt_l' = List.fold_left 
          (fun (env',out) (fn, t) -> 
             let env',t' = descend_typ_map f g env t in
               env', (fn,t')::out) (env, []) fnt_l in
        let env', topt = match topt with 
          | None -> env', None 
          | Some t -> let env, t = descend_typ_map f g env t in env, Some t in
          env', Typ_record (List.rev fnt_l', topt)
            
    | Typ_fun (nopt, t1, t2) -> 
        let env', t1' = descend_typ_map f g env t1 in
        let env', t2' = descend_typ_map f g env' t2 in
          env', Typ_fun(nopt, t1', t2')
            
    | Typ_univ (bvd, k, formulas, t) -> 
        let env', t' = descend_typ_map f g env t in
        let env', k' = descend_kind_map f g env k in 
        let env', formulas' = descend_typs_map f g env formulas in
          env', Typ_univ(bvd, k', formulas', t')
            
    | Typ_dtuple nt_l -> 
        let env', nt_l' = List.fold_left 
          (fun (env, out) (n, t) -> 
             let env', t' = descend_typ_map f g env t in
               env', (n,t')::out) (env, []) nt_l in
          env', Typ_dtuple (List.rev nt_l')
            
    | Typ_refine (bvd, t, form, b) -> 
        let env', t' = descend_typ_map f g env t in
        let env'', form' = descend_typ_map f g env' form in
          env'', Typ_refine(bvd, t', form', b)

    | Typ_lam(x, t, t') ->
        let env', t = descend_typ_map f g env t in
        let env'', t' = descend_typ_map f g env' t' in
          env'', Typ_lam(x, t, t')

    | Typ_tlam (bvd, k, t) -> 
        let env', t' = descend_typ_map f g env t in
        let env', k = descend_kind_map f g env' k in 
          env', Typ_tlam(bvd, k, t')

    | Typ_app(t1, t2) -> 
        let env', t1' = descend_typ_map f g env t1 in
        let env'', t2' = descend_typ_map f g env' t2 in
          env'', Typ_app(t1', t2')
            
    | Typ_dep (t, e) -> 
        let env', t' = descend_typ_map f g env t in
        let env'', e' = descend_exp_map f g env' e in
          env'', Typ_dep(t', e')
            
    | Typ_affine t -> 
        let env', t' = descend_typ_map f g env t in
          env', Typ_affine t' 

    | Typ_ascribed(t, k) -> 
        let env', t' = descend_typ_map f g env t in
        let env'', k' = descend_kind_map f g env' k in 
          env'', Typ_ascribed(t', k')

    | Typ_meta (Meta_alpha t) -> 
        let env', t' = descend_typ_map f g env t in 
          env', Typ_meta(Meta_alpha t')
    | Typ_meta (Meta_cases tl) -> 
        let env, tl = descend_typs_map f g env tl in 
          env, Typ_meta(Meta_cases tl)
    | Typ_meta (Meta_tid i) -> 
        env, Typ_meta(Meta_tid i)
    | Typ_meta (Meta_named(s,t)) -> 
        let env', t' = descend_typ_map f g env t in 
          env', Typ_meta(Meta_named(s,t'))
    | Typ_meta (Meta_pattern(t, ps)) -> 
      let env', ps = ps |> ((env, []) |> List.fold_left 
          (fun (env, out) -> function
              | Inl t -> let env', t' = descend_typ_map f g env t in (env', Inl t'::out)
              | Inr e -> let env', e' = descend_exp_map f g env e in (env', Inr e'::out))) in 
      let env', t = descend_typ_map f g env' t in 
      env', Typ_meta(Meta_pattern (t, List.rev ps))
      

  in
  let env'', tsort = descend_kind_map f g env' t_top.sort in
    env'', twithsort t' tsort 

and descend_typs_map 
    (f: 'env -> typ' -> ('env * typ'))
    (g: 'env -> exp' -> ('env * exp'))
    (env:'env) (ts:list<typ>) : ('env * list<typ>) = 
  let env, ts' = List.fold_left 
    (fun (env, out) t -> 
       let env, t' = descend_typ_map f g env t in 
         env, t'::out) (env, []) ts in 
    env, List.rev ts'
      
and descend_exp_map 
    (f: 'env -> typ' -> ('env * typ'))
    (g: 'env -> exp' -> ('env * exp'))
    (env:'env) (e_top:exp) : ('env * exp) = 
  let env, e = g env e_top.v in
  let env', exp' = match e with
    | Exp_bot 
    | Exp_constant _ -> env, e
    | Exp_bvar bv -> 
        let env', sort' = descend_typ_map f g env bv.sort in
          env', Exp_bvar(setsort bv sort')
    | Exp_fvar (fv, eref) -> 
        let env', sort' = descend_typ_map f g env fv.sort in
          env', Exp_fvar(setsort fv sort', eref)
    | Exp_constr_app (v, tl, el1, el) -> 
        let env, vsort = descend_typ_map f g env v.sort in
        let v = setsort v vsort in
        let env', tlrev = List.fold_left 
          (fun (env, out) t -> 
             let env', t' = descend_typ_map f g env t in
               env', t'::out) (env, []) tl in
        let env', el1rev = List.fold_left 
          (fun (env', out) e -> 
             let env'', e' = descend_exp_map f g env' e in
               env'', e'::out) (env', []) el1 in
        let env'', elrev = List.fold_left 
          (fun (env', out) e -> 
             let env'', e' = descend_exp_map f g env' e in
               env'', e'::out) (env', []) el in
          env'', Exp_constr_app(v, List.rev tlrev, List.rev el1rev, List.rev elrev)
    | Exp_primop(id, el) -> 
        let env', elrev = List.fold_left 
          (fun (env', out) e -> 
             let env'', e' = descend_exp_map f g env' e in
               env'', e'::out) (env, []) el in
          env', Exp_primop(id, List.rev elrev)
    | Exp_abs (bvd, t, e) ->
        let env', t' = 
          try 
            descend_typ_map f g env t 
          with Impos -> let _ = pr "Failed to expand types in (%A)\n" e_top in failwith "die" in 
        let env'', e' = descend_exp_map f g env' e in
          env'', Exp_abs(bvd, t', e')
            
    | Exp_tabs(bvd, k, formulas,  e) -> 
        let env', e' = descend_exp_map f g env e in
        let env', k' = descend_kind_map f g env' k in 
        let env', formulas' = descend_typs_map f g env' formulas in 
          env', Exp_tabs(bvd, k', formulas', e')
            
    | Exp_app (e1, e2) -> 
        let env', e1' = descend_exp_map f g env e1 in
        let env'', e2' = descend_exp_map f g env' e2 in
          env'', Exp_app(e1', e2')
            
    | Exp_tapp (e, t) -> 
        let env', e' = descend_exp_map f g env e in
        let env'', t' = descend_typ_map f g env' t in
          env'', Exp_tapp(e',t')
            
    | Exp_match(e, eqns, def) -> 
        let env', e' = descend_exp_map f g env e in
        let env'', eqnsrev = List.fold_left 
          (fun (env', eqns) (p, e) -> 
             let env', p' = match p with 
                 (*                | Pat_constant _ -> env', p *)
               | Pat_variant (lid, tl, phantoms, bvl, is_exvar) -> 
                   let env', tl' = List.fold_left (fun (env', out) t -> 
                                                     let env', t' = descend_typ_map f g env' t in
                                                       env', t'::out) (env', []) tl in
                   let env', phantoms' = List.fold_left (fun (env', out) e -> 
                                                           let env', e' = descend_exp_map f g env' e in
                                                             env', e'::out) (env', []) phantoms in
                   let env', bvl' = 
                     List.fold_left (fun (env', bvl) bv -> 
                                       let env', bvt' = descend_typ_map f g env' bv.sort in
                                         env', (setsort bv bvt')::bvl) (env', []) bvl in
                     env', Pat_variant(lid, List.rev tl', List.rev phantoms', List.rev bvl', is_exvar) in
             let env', e' = descend_exp_map f g env' e in
               env', (p',e')::eqns) (env', []) eqns in
        let env'', def' = descend_exp_map f g env'' def in
          env'', Exp_match(e', List.rev eqnsrev, def')
            
    | Exp_cond (e, e1, e2) -> 
        let env1, e' = descend_exp_map f g env e in
        let env2, e1' = descend_exp_map f g env1 e1 in
        let env3, e2' = descend_exp_map f g env2 e2 in
          env3, Exp_cond(e',e1',e2')
            
    | Exp_recd(lidopt, tl, el1, fn_e_l) -> 
        let env', tlrev = List.fold_left 
          (fun (env, out) t -> 
             let env', t' = descend_typ_map f g env t in
               env', t'::out) (env, []) tl in
        let env', el1rev = List.fold_left 
          (fun (env', out) e -> 
             let env'', e' = descend_exp_map f g env' e in
               env'', e'::out) (env', []) el1 in
        let env', fn_e_l_rev = List.fold_left 
          (fun (env, out) (fn, e) -> 
             let env', e' = descend_exp_map f g env e in
               env', (fn,e')::out) (env', []) fn_e_l in
          env', Exp_recd(lidopt, List.rev tlrev, List.rev el1rev, List.rev fn_e_l_rev)
            
    | Exp_proj (e, fn) -> 
        let env', e' = descend_exp_map f g env e in
          env', Exp_proj(e', fn)
            
    | Exp_ascribed (e,t,ev) -> 
        let env', e' = descend_exp_map f g env e in
        let env'', t' = descend_typ_map f g env' t in
        let env'', ev' =  List.fold_left 
          (fun (env, out) -> function
             | Inl (t1, t2) -> 
                 let env', t1' = descend_typ_map f g env t1 in
                 let env'', t2' = descend_typ_map f g env' t2 in
                   (env'', (Inl(t1',t2'))::out)
             | Inr (bv, e) -> 
                 let env', bv' = descend_exp_map f g env bv in
                 let env'', e' = descend_exp_map f g env' e in
                   (env'', (Inr(bv',e'))::out)) (env'',[]) ev in
          env'', Exp_ascribed(e',t', List.rev ev')
            
    | Exp_let (b, bvd_t_e_l, e) -> 
        let env', bvd_t_e_l_rev = List.fold_left 
          (fun (env, out) (bv,t,e) -> 
             let env', e' = descend_exp_map f g env e in
             let env'', t' = descend_typ_map f g env' t in
               (env', (bv, t', e')::out)) (env,[]) bvd_t_e_l in
        let env'', e' = descend_exp_map f g env' e in
          env'', Exp_let(b, List.rev bvd_t_e_l_rev, e')
            
    | Exp_gvar _ -> raise Impos in
  let env'', sort' = descend_typ_map f g env' e_top.sort in
    env'', ewithinfo exp' sort' e_top.p 

and descend_kind_map 
    (f: 'env -> typ' -> ('env * typ'))
    (g: 'env -> exp' -> ('env * exp'))
    (env:'env) (k_top:kind) : ('env * kind) = 
  let env, k' = match k_top(* .u *) with
    | Kind_boxed _
    | Kind_prop
    | Kind_erasable
    | Kind_star 
    | Kind_affine as k' -> env, k'
    | Kind_tcon(aopt, k, k') -> 
        let env, k = descend_kind_map f g env k in
        let env', k' = descend_kind_map f g env k' in
          env', Kind_tcon(aopt, k, k')
    | Kind_dcon(xopt, t, k) -> 
        let env', t' = descend_typ_map f g env t in
        let env'', k' = descend_kind_map f g env' k in
          env'', Kind_dcon(xopt, t', k')
    | _ -> raise Impos in 
    env, withhash k'

      
let rec range_of_sigelt = function              
  | Sig_tycon_kind (lid, _, _, _, _, _)    
  | Sig_typ_abbrev  (lid, _, _, _)
  | Sig_record_typ  (lid, _, _, _, _)
  | Sig_datacon_typ (lid, _, _, _, _, _, _, _) 
  | Sig_extern_value(_, lid, _)
  | Sig_query(lid, _)
  | Sig_ghost_assume(lid, _, _)
  | Sig_logic_function(lid, _, _)
  | Sig_value_decl (lid, _) -> Sugar.range_of_lid lid
  | Sig_extern_typ(_, se) -> range_of_sigelt se

let rec lid_of_sigelt = function              
  | Sig_tycon_kind (lid, _, _, _, _, _)    
  | Sig_typ_abbrev  (lid, _, _, _)
  | Sig_record_typ  (lid, _, _, _, _)
  | Sig_datacon_typ (lid, _, _, _, _, _, _, _) 
  | Sig_extern_value(_, lid, _)
  | Sig_query(lid, _)
  | Sig_ghost_assume(lid, _, _)
  | Sig_logic_function(lid, _, _)
  | Sig_value_decl (lid, _) -> lid
  | Sig_extern_typ(_, se) -> lid_of_sigelt se 


let rec_compress t = 
    let bvdOfDisj (xx:Disj<btvar, bvvar>) = match xx with Inl x -> Inl x.v | Inr x -> Inr x.v in
  typ_fold_map  
    (fun () () t -> (), compress' t, None)
    (fun () () x -> (), x) 
    (fun _ e -> e)
    (fun () x -> ((), bvdOfDisj x)) () () t
    
(* collect unification variables in a type *)
let uvars_in_typ t = 
  let collect_uvars uvs () t = match t with 
    | Typ_uvar (uv, k) -> 
        (match List.tryFind (fun uv' -> Unionfind.equivalent uv' uv) uvs with 
           | Some _ -> uvs, t, None
           | None ->  uv::uvs, t, None)
    | _ -> uvs, t, None in
  let exp_folder_noop env () e = (env,e) in
  let ext_benv_noop () = function Inl x -> (), Inl x.v | Inr x -> (), Inr x.v in
  let uvs, tsub = typ_fold_map collect_uvars exp_folder_noop (fun _ e -> e) ext_benv_noop [] () t in
    uvs

let rec uvars_in_uvar uv = match Unionfind.find uv with 
    Uvar _ -> [uv]
  | Delayed t
  | Fixed t -> 
      let uvt = uvars_in_typ t in
      let uvs = List.concat (List.map uvars_in_uvar uvt) in
        uv::uvs

let rec freevarsKind (k:kind) : (list<btvar> * list<bvvar>) =
  fst (kind_fold_map fv_fold_t fv_fold_e (fun _ e -> e) ext_fv_env ([], []) ([], []) k)
and freevarsTyp (t:typ) : (list<btvar> * list<bvvar>) = 
  fst (typ_fold_map fv_fold_t fv_fold_e (fun _ e -> e) ext_fv_env ([], []) ([], []) t)
and freevarsExp (e:exp) : (list<btvar> * list<bvvar>) =
  fst (exp_fold_map fv_fold_t fv_fold_e (fun _ e -> e) ext_fv_env ([], []) ([], []) e)
and fv_fold_t ((ftvs, fxvs) as out) benv t = match t with
  | Typ_btvar bv -> 
      if is_bound_tv benv bv then out, t, None
      else (bv::ftvs, fxvs), t, None
  | _ -> out, t, None
and fv_fold_e ((ftvs, fxvs) as out) benv e = match e with
  | Exp_bvar bv ->
      if is_bound_xv benv bv then 
        (* let _ = pr "Bvar %s is bound, where env is %s\n" (strBvar bv) (strBenv benv) in *)
          out, e
      else 
        (* let _ = pr "Bvar %s is free, where env is %s\n" (strBvar bv) (strBenv benv) in *)
          (ftvs, bv::fxvs), e
  | _ -> out, e
and ext_fv_env ((btvs, bxvs):list<btvdef>*list<bvvdef>) = function 
    Inl tv -> (tv.v::btvs, bxvs), Inl tv.v
  | Inr xv -> (btvs, xv.v::bxvs), Inr xv.v
and is_bound_tv (ftvs, fxvs) bv = 
  List.exists (fun (bvd') -> bvd_eq bvd' bv.v) ftvs 
and is_bound_xv (ftvs, fxvs) bv = 
  List.exists (fun (bvd') -> bvd_eq bvd' bv.v) fxvs 
and strBenv (btvs, bxvs) = 
  spr "(BTVS=%s,\n BXVS=%s)\n" 
    (String.concat ", " (List.map strBvd btvs))
    (String.concat ", " (List.map strBvd bxvs))
and strBvar b = b.v.realname.idText

type smap = list<Disj<(btvdef*typ), (bvvdef*exp)>>
(* all bvar names in a kind, type, exp are expected to be unique *)
let rec substitute_kind_l kind smap : kind =
    snd (kind_fold_map (fold_t_typ smap) (fold_e_typ smap) (fun _ e -> e) ignore_env () () kind)
and substitute_kind_typ_or_exp_l kind (smap:list<Disj<(btvdef*typ), (bvvdef*exp)>>) : kind = 
    snd (kind_fold_map (fold_t_typ_or_exp smap) (fold_e_typ_or_exp smap) (fun _ e -> e) ignore_env () () kind)
and substitute_kind_exp_l kind smap : kind = 
    snd (kind_fold_map (fold_t_exp smap) (fold_e_exp smap) (fun _ e -> e) ignore_env () () kind)
and substitute_l typ (smap:list<btvdef * typ>) : typ =
    snd (typ_fold_map (fold_t_typ smap) (fold_e_typ smap) (fun _ e -> e) ignore_env () () typ)

and substitute_l_typ_or_exp typ smap : typ =
    snd (typ_fold_map (fold_t_typ_or_exp smap) (fold_e_typ_or_exp smap) (fun _ e -> e) ignore_env () () typ)
and substitute_exp_l typ smap : typ =
    snd (typ_fold_map (fold_t_exp smap) (fold_e_exp smap) (fun _ e -> e) ignore_env () () typ)
and substitute_exp_val_l exp (smap:list<bvvdef * exp>) : exp =
    snd (exp_fold_map (fold_t_exp smap) (fold_e_exp smap) (fun _ e -> e) ignore_env () () exp)
and substitute_exp_typ_l exp (smap:list<btvdef * typ>) : exp =
    snd (exp_fold_map (fold_t_typ smap) (fold_e_typ smap) (fun _ e -> e) ignore_env () () exp)
and substitute_exp_typ_or_exp_l exp smap : exp = 
    snd (exp_fold_map (fold_t_typ_or_exp smap) (fold_e_typ_or_exp smap) (fun _ e -> e) ignore_env () () exp)
and fold_t_typ_or_exp smap () () t = match t with
    | Typ_btvar bv -> 
        let bvn = (bvar_real_name bv).idText in
        (match List.tryFind (function Inr _ -> false | Inl(bvd, _) -> bvn = (real_name bvd).idText) smap with
            Some (Inl(_,with_t)) -> (), with_t.v, Some (with_t.sort)
          | _ -> let sort' = substitute_kind_typ_or_exp_l bv.sort smap in (),  (Typ_btvar (setsort bv sort')), None)
    | _ -> (), t, None
and fold_t_typ smap () () t = match t with
    | Typ_btvar bv -> 
        let bvn = (bvar_real_name bv).idText in
        (match List.tryFind (function (bvd, _) -> bvn = (real_name bvd).idText) smap with
            Some (_, with_t) -> (), with_t.v, Some (with_t.sort)
          | _ -> let sort' = substitute_kind_l bv.sort smap in (),  (Typ_btvar (setsort bv sort')), None)
    | _ -> (), t, None
and fold_t_exp smap () () t = match t with 
    | Typ_btvar bv ->  let sort' = substitute_kind_exp_l bv.sort smap in (), (Typ_btvar(setsort bv sort')), None
    | _ -> (), t, None 
and fold_e_typ_or_exp smap () () e = match e with 
    | Exp_bvar bv -> 
         let bvn = (bvar_real_name bv).idText in
               (match List.tryFind (function Inl _ -> false | Inr (bvd, _) -> bvn=(real_name bvd).idText) smap with
                 | Some (Inr (_, e')) -> (), e'.v
                 | _ -> let sort' = substitute_l_typ_or_exp bv.sort smap in (), (Exp_bvar (setsort bv sort')))
    | _ -> (), e

and fold_e_typ smap () () e = match e with 
    | Exp_bvar bv -> let sort' = substitute_l bv.sort smap in (), (Exp_bvar (setsort bv sort'))
    | _ -> (), e 
and fold_e_exp smap () () e = match e with
    | Exp_bvar bv -> 
         let bvn = (bvar_real_name bv).idText in
           (match List.tryFind (fun (bvd, _) -> bvn=(real_name bvd).idText) smap with
             | Some (_, e') -> (), e'.v
             | None -> let sort' = substitute_exp_l bv.sort smap in (), (Exp_bvar (setsort bv sort')))
    | _ -> (), e

and ignore_env () = function Inl x -> (), Inl x.v | Inr x -> (), Inr x.v

let substitute_kind kind bvd with_t = substitute_kind_l kind [bvd,with_t]
let substitute_kind_exp kind bvd with_e  = substitute_kind_exp_l kind [bvd, with_e] 
let substitute typ bvd with_t = substitute_l typ [bvd, with_t]
let substitute_exp typ bvd with_e = substitute_exp_l typ [bvd, with_e]
let substitute_exp_val (exp:exp) bvd with_e = substitute_exp_val_l exp [bvd, with_e]

let open_kind kind typ : kind = match kind(* .u *) with 
    | Kind_tcon(Some a, ka, k) -> substitute_kind k a typ 
    | Kind_tcon(None, _, k) -> k
    | _ -> pr "open_kind got %A" kind; raise Impos
let open_kind_with_exp kind v : kind = match kind(* .u *) with 
    | Kind_dcon(Some x, t, k) -> substitute_kind_exp k x v 
    | Kind_dcon(None, _, k) -> k
    | _ -> pr "open_kind_with_exp got kind %A" kind; raise Impos

let e_substitute_exp_l exp (subst:list<(bvvdef*exp)>) = 
  let fold_e () () e = match e with
      Exp_bvar bv -> 
        let bvn = (bvar_real_name bv).idText in
          (match List.tryFind (fun (bvd:bvvdef, e) -> (real_name bvd).idText=bvn) subst with
               None -> (), e
             | Some (_, e') -> (), e'.v)
    | _ -> (), e in
  let fold_t () () t = (), t, None in
    snd (exp_fold_map fold_t fold_e (fun _ e -> e) ignore_env () () exp)

let e_substitute_l exp (subst:list<btvdef*typ>) = snd (exp_fold_map (fold_t_typ subst) (fold_e_typ subst) (fun _ e -> e) ignore_env () () exp)
 
let rec open_typ_with_exp typ exp = 
  match (compress typ).v with 
      Typ_fun(None, targ, tret) -> tret
    | Typ_lam(bvd, targ, tret)
    | Typ_fun(Some bvd, targ, tret) -> substitute_exp tret bvd exp
    | Typ_affine t -> open_typ_with_exp t exp
    | _ -> raise Impos
        
let rec open_typ_with_typ tuniv targ : typ = 
  match (compress tuniv).v with 
    | Typ_tlam(bvd, k, t)
    | Typ_univ(bvd, k, [], t) -> substitute t bvd targ 
    | Typ_affine t -> open_typ_with_typ t targ
    | _ -> raise Impos

let instantiate_tparams t tps (targs:list<typ>) (eargs:list<exp>) = 
  let close t = 
    t |> (tps |> List.fold_right (
            fun tp out -> match tp with 
              | Tparam_typ (a,k) -> twithsort (Typ_tlam (a,k,out)) Kind_star
              | Tparam_term (x,t) -> twithsort (Typ_lam (x,t,out)) Kind_star)) in 
  let t = List.fold_left open_typ_with_typ (close t) targs in 
    List.fold_left open_typ_with_exp t eargs 

let rec open_constrained_typ_with_typ tuniv targ : (list<formula> * typ) = 
  match (compress tuniv).v with 
    | Typ_univ(bvd, k, constraints, t) -> 
        let t' = substitute t bvd targ  in
        let constraints = List.map (fun c -> substitute c bvd targ) constraints in 
          constraints, t'
    | Typ_affine t -> open_constrained_typ_with_typ t targ
    | _ -> raise Impos

let rec unascribe e = match e.v with 
  | Exp_ascribed (e, _, _) -> unascribe e 
  | _ -> e

let freshen_label ropt = match ropt with 
  | None -> (fun _ e -> e)
  | Some r -> 
      let rstr = Range.string_of_range r in
        (fun _ str -> 
           (match unascribe str with
              | {v=Exp_constant(Sugar.Const_string(bytes, p))} -> 
                  let bytes =  Util.unicodeEncoding.GetBytes(Util.unicodeEncoding.GetString(bytes) ^ " : " ^ rstr) in 
                    ewithinfo (Exp_constant(Sugar.Const_string(bytes, p))) str.sort str.p
              | _ -> str))
          
let freshen_bvars_typ, 
    freshen_bvars_kind =
  let fail (rn:ident) benv = 
    pr "Tried to freshen type\n Reached Bvar %s\n Not in benv %A\n" rn.idText benv;
    raise Impos in
  let map_btv fail_not_found benv btv =
    let rn = bvar_real_name btv in
    let f = function Inr _ -> false | Inl (bv, bv') -> bv.realname.idText = rn.idText in
      match Util.findOpt f benv with 
        | Some(Inl (_,bv')) -> bvd_to_bvar_s bv' btv.sort
        | None when fail_not_found -> fail rn benv
        | _ -> btv in 
 let map_bvv fail_not_found benv (bv:bvvar) = 
    let rn = bvar_real_name bv in
    let f = function Inl _ -> false | Inr (bv, bv') -> bv.realname.idText = rn.idText in
      match Util.findOpt f benv with 
        | Some(Inr (_,bv')) -> bvd_to_bvar_s bv' bv.sort
        | None when fail_not_found -> fail rn benv 
        | _ -> bv in 
  let fold_t fail_not_found () benv t = match t with
    | Typ_btvar bv -> let bv' = map_btv fail_not_found benv bv in (), Typ_btvar bv', None
    | _ -> (), t, None in
  let fold_e fail_not_found () benv e = match e with 
      Exp_bvar bv -> let bv' = map_bvv fail_not_found benv bv in (), Exp_bvar bv'
    | _ -> (), e in
  let ext benv = function 
    | Inl btv -> 
        let newname = genident None in
        let bvd' = mkbvd (newname, newname) in
          (Inl (btv.v,bvd'))::benv, Inl bvd' 
    | Inr bxv -> 
        let newname = genident None in
        let bvd' = mkbvd (newname, newname) in
          (Inr (bxv.v,bvd'))::benv, Inr bvd' in 
    ((fun ropt fail_not_found t benv -> 
        snd (typ_fold_map (fold_t fail_not_found) (fold_e fail_not_found) (freshen_label ropt) ext () benv t)), 
     (fun fail_not_found k benv -> 
        snd (kind_fold_map (fold_t fail_not_found) (fold_e fail_not_found) (fun _ e -> e) ext () benv k)))

let freshen_typ t benv : typ = freshen_bvars_typ None true t benv 
let alpha_convert t : typ = freshen_bvars_typ None false t [] 
let alpha_convert_kind k : kind = freshen_bvars_kind false k [] 
let alpha_fresh_labels r t : typ = "alpha_fresh_labels" ^^ lazy freshen_bvars_typ (Some r) false t [] 

let rec ascribe_t t k = match t.v with 
    Typ_ascribed (t', _) -> ascribe_t t' k
  | _ -> twithsort (Typ_ascribed(t, k)) k
      
let rec ascribe e t ev = match e.v with 
    Exp_ascribed (e, _, ev') -> ascribe e t (ev'@ev)
  | _ -> ewithsort (Exp_ascribed(e, t, ev)) t
      
      
let rec unascribe_typ t = match t.v with 
  | Typ_ascribed (t, _) -> unascribe_typ t
  | _ -> t

let rec unname_typ t = match t.v with 
  | Typ_meta(Meta_named(_, t)) -> unname_typ t
  | Typ_meta(Meta_pattern(t, _)) -> unname_typ t
  | _ -> t

let equalsExp e1 e2 = (* only implemented for non-function values *)
  let rec same_exp e1 e2 = 
    match (unascribe e1).v, (unascribe e2).v with
      | Exp_bvar bv1, Exp_bvar bv2 -> (bvar_real_name bv1).idText = (bvar_real_name bv2).idText
      | Exp_fvar (fv1, eref1), Exp_fvar (fv2, eref2) -> 
          ((Sugar.text_of_lid fv1.v) = (Sugar.text_of_lid fv2.v)) &&
            (eref1 = eref2)
      | Exp_constant c1, Exp_constant c2 -> c1 = c2 
      | Exp_constr_app (v1, tl, elp1, el), Exp_constr_app (v2, tl2, elp2, el2) ->  
          let rec same_exp_list = function
            | [] -> true
            | (e1, e2)::tl -> (same_exp e1 e2) && same_exp_list tl in
            ((List.length tl) = (List.length tl2) &&
                (List.length elp1) = (List.length elp2) &&
                (List.length el) = (List.length el2) &&
                (Sugar.lid_equals v1.v v2.v) &&
                (same_exp_list (List.zip (elp1@el) (elp2@el2))))
              
      | Exp_recd (_, _, _, fne_l_1), Exp_recd (_, _, _, fne_l_2) -> 
          let rec same_fn_lists = function
              [] -> true
            | ((f1, e1), (f2,e2))::tl -> 
                (Sugar.lid_equals f1 f2) && (same_exp e1 e2) && (same_fn_lists tl) in
            (List.length fne_l_1 = List.length fne_l_2) &&
              (same_fn_lists (List.zip fne_l_1 fne_l_2))
              
      | _ -> false in    
    same_exp e1 e2

let whnf t = 
  let rec aux ctr t = 
    let t' = 
      match (compress t).v with 
        | Typ_dep(t1, e) -> 
            let t1,ctr = aux (ctr+1) t1 in
              (match t1.v with 
                 | Typ_lam(x, t1_a, t1_r) -> 
                     let t1_r' = substitute_exp t1_r x e in 
                       aux (ctr+1) t1_r'
                 | _ -> twithinfo (Typ_dep(t1, e)) t.sort t.p, ctr)
        | Typ_app(t1, t2) -> 
            let t1,ctr = aux (ctr+1) t1 in
            let t2,ctr = aux (ctr+1) t2 in
              (match t1.v with 
                 | Typ_tlam(a, t1_a, t1_r) -> 
                     let t1_r' = substitute t1_r a t2 in
                       aux (ctr+1) t1_r'
                 | _ -> twithinfo (Typ_app(t1, t2)) t.sort t.p, ctr)
        | _ -> t,ctr in
      t' in 
    fst (aux 0 t)

let whnf' = 
  if !Options.print_real_names 
  then fun t -> t 
  else fun t -> (whnf (twithpos t dummyRange)).v 


let p2l l = Sugar.path_to_lid dummyRange l
let forall_lid = p2l ["Prims"; "Forall"]
  
type typ' 
with override x.ToString() = match whnf' x with 
      | Typ_btvar btv -> 
          (match !btv.v.instantiation with 
             | None -> 
                 if !Options.print_real_names then btv.v.realname.idText else btv.v.realname.idText
             | Some x -> x.ToString())
      | Typ_const ({v=lid}, _) -> spr "%s" (sli lid)
      | Typ_record (_, Some t) -> t.ToString() 
      | Typ_record (fnt_l, None) -> spr "{%s}" (String.concat "; " (List.map (fun (fn,t) -> spr "%s:%s" (sli fn) (t.ToString())) fnt_l)) 
      | Typ_fun(Some x, t1, t2) -> spr "%s:%s -> %s"  (strBvd x) (t1.ToString()) (t2.ToString())
      | Typ_fun(None, t1, t2) -> spr "%s -> %s"  (t1.ToString()) (t2.ToString())
      | Typ_univ(a, k, _, t) -> spr "%s::%s -> %s" (strBvd a) (k.ToString()) (t.ToString())
      | Typ_dtuple([(Some x, t1); (_, t2)]) -> spr "(%s:%s * %s)" (strBvd x) (t1.ToString()) (t2.ToString())
      | Typ_dtuple([(_, t1); (_, t2)]) -> spr "(%s * %s)" (t1.ToString()) (t2.ToString())
      | Typ_refine(x, t, f, _) -> spr "%s:%s{%s}" (strBvd x) (t.ToString()) (f.ToString())
      | Typ_app({v=Typ_const({v=lid}, _)}, t2) when Sugar.lid_equals lid forall_lid -> "Forall"
      | Typ_app(t1, t2) -> spr "(%s %s)" (t1.ToString()) (t2.ToString())
      | Typ_dep(t, v) -> spr "(%s %s)" (t.ToString()) (v.ToString())
      | Typ_affine t -> spr "!%s" (t.ToString())
      | Typ_lam(x, t1, t2) -> spr "(fun %s => %s)"  (strBvd x) (* (t1.ToString()) *) (t2.ToString())
      | Typ_tlam(a, k, t) -> spr "(tfun %s => %s)"  (strBvd a) (* (k.ToString()) *) (t.ToString())
      | Typ_ascribed(t, k) -> spr "%s" (t.ToString()) 
      | Typ_unknown -> "_"
      | Typ_uvar(uv, _) -> (match Unionfind.find uv with 
                              | Delayed t
                              | Fixed t -> t.ToString()
                              | Uvar _ -> spr "'U%d" (Unionfind.uvar_id uv))
      | Typ_meta meta -> spr "(Meta %s)" (meta.ToString())
      | _ -> "Unexpected type" 
end

type exp'
with override x.ToString() = match x with 
      | Exp_bvar bvv -> 
          (match !bvv.v.instantiation with 
             | None -> 
                 if !Options.print_real_names then bvv.v.realname.idText else bvv.v.realname.idText
             | Some x -> x.ToString())
      | Exp_fvar({v=lid}, _) ->  sli lid
      | Exp_constant c -> c.ToString()
      | Exp_constr_app({v=lid}, tl, _, el) -> spr "(%s %s %s)" (sli lid) (String.concat " " (List.map (fun t -> t.ToString()) tl)) (String.concat " " (List.map (fun t -> t.ToString()) el))
      | Exp_abs(x, t, e) -> spr "(fun (%s:%s) -> %s)" (strBvd x) (t.ToString()) (e.ToString())
      | Exp_tabs(a, k, _, e) -> spr "(fun (%s::%s) -> %s)" (strBvd a) (k.ToString()) (e.ToString())
      | Exp_app(e1, e2) -> spr "(%s %s)" (e1.ToString()) (e2.ToString())
      | Exp_tapp(e, t) -> spr "(%s %s)" (e.ToString()) (t.ToString())
      | Exp_match(v, pats, e) -> spr "(match %s with %s | _ -> %s)" (v.ToString()) (String.concat "\n\t" (List.map (fun (p,e) -> spr "%s -> %s" (p.ToString()) (e.ToString())) pats)) (e.ToString())
      | Exp_cond(e1, e2, e3) -> spr "(if %s then %s else %s)" (e1.ToString()) (e2.ToString()) (e3.ToString())
      | Exp_recd(None, _, _, fnv_l) -> spr "{%s}" (String.concat "; " (List.map (fun (fn,t) -> spr "%s=%s" (sli fn) (t.ToString())) fnv_l))
      | Exp_recd(Some e, _, _, fnv_l) -> spr "{%s with %s}" (e.ToString()) (String.concat "; " (List.map (fun (fn,t) -> spr "%s=%s" (sli fn) (t.ToString())) fnv_l))
      | Exp_proj(e, f) -> spr "(%s.%s)" (e.ToString()) (sli f)
      | Exp_ascribed(e, t, _) -> spr "%s" (e.ToString())
      | Exp_let(r, lbs, e) -> spr "let %s %s in %s" (if r then "rec" else "") (String.concat "\n and" (lbs |> List.map (fun (x, t, e) -> spr "%s:%s = %s" (strBvd x) (t.ToString()) (e.ToString())))) (e.ToString())
      | Exp_gvar _ -> "GVAR"
      | Exp_extern_call(_, id, _, _, el) 
      | Exp_primop(id, el)-> spr "(%s %s)" (id.idText) (String.concat " " (List.map (fun e -> e.ToString()) el))
      | Exp_bot -> "(fail ())" 
end


type meta 
with override x.ToString() = match x with 
  | Meta_PrePost(f, t, g) -> spr "Meta{pre=%s;\n\t typ=%s;\n\t post=%s::%s}" (f.ToString()) (t.ToString()) (g.ToString()) (g.sort.ToString())
  | Meta_cases tl -> spr "\n\tMetaCases [%s]\n" (String.concat ";\n" (List.map (fun t -> t.ToString()) tl))
  | Meta_tid i -> spr "(Meta_tid %d)" i
  | Meta_named(s,t) -> spr "(Meta_named %s %s)" s (t.ToString())
  | Meta_alpha t -> spr "(Meta_alpha %s)" (t.ToString())
  | Meta_pattern(t,ps) -> spr "{:pattern %s} %s" (String.concat ", " (ps |> List.map (function Inl t -> t.ToString() | Inr e -> e.ToString()))) (t.ToString())
end


