#light "off"

module Microsoft.FStar.Const

open Sugar
open Absyn
open Util 
let p2l l = path_to_lid dummyRange l
let Kind_prop = withhash Kind_prop
let Kind_star = withhash Kind_star
let Kind_erasable = withhash Kind_erasable
let Kind_unknown = withhash Kind_unknown
let Kind_tcon x = withhash (Kind_tcon x)
let Kind_dcon x = withhash (Kind_dcon x)
let Kind_boxed x = withhash (Kind_boxed x)


let prims_lid = p2l ["Prims"]
let prooflib_lid = p2l ["ProofLib"]
  
let mk_typ path k = 
  let tc = p2l path in
  let tycon = twithsort (Typ_const (fvwithsort tc k, None)) k in
    tc, tycon

let extern_id = Sugar.extern_id
let has_type_lid = p2l ["Prims"; "GetType"]
let tag_lid, tag_typ = mk_typ ["Prims"; "Tag"] (Kind_tcon(None, Kind_erasable, Kind_erasable))
let heap_lid, heap_typ = mk_typ ["Prims"; "heap"] Kind_star
let init_heap_lid = p2l ["Prims"; "init_heap"]
let object_lid, object_typ = mk_typ ["Prims"; "object"] Kind_star
let bool_lid, bool_typ = mk_typ ["Prims"; "bool"] Kind_star
let exp_true_bool = ewithsort (Exp_constant (Sugar.Const_bool true)) bool_typ
let exp_false_bool = ewithsort (Exp_constant (Sugar.Const_bool false)) bool_typ
let unit_lid, unit_typ = mk_typ ["Prims"; "unit"] Kind_star
let string_lid, string_typ = mk_typ ["Prims"; "string"] Kind_star
let bytes_lid, bytes_typ = mk_typ ["Prims"; "bytes"] Kind_star
let int_lid, int_typ = mk_typ ["Prims"; "int"] Kind_star
let num_lid, num_typ = mk_typ ["Prims"; "number"] Kind_star
let float_lid, float_typ = mk_typ ["Prims"; "float"] Kind_star
let true_lid, true_typ = mk_typ ["Prims"; "True"] Kind_prop
let false_lid, false_typ = mk_typ ["Prims"; "False"] Kind_prop

let reln_lid, reln_typ = mk_typ ["Prims"; "Relational"]  (Kind_tcon(None, Kind_erasable, Kind_erasable))
let doublesided_lid, doublesided_typ = mk_typ ["Prims"; "DoubleSided"]  (Kind_tcon(None, Kind_erasable, Kind_erasable))
let spec_only_lid, spec_only_typ = mk_typ ["Prims"; "SPEC_ONLY"] (Kind_tcon(None, Kind_erasable, Kind_erasable))
let typeof_lid, typeof_typ = mk_typ ["Prims"; "TypeOf"] Kind_unknown
let kindof_lid, kindof_typ = mk_typ ["Prims"; "KindOf"] Kind_unknown

let lproj_lid = p2l ["Prims"; "L"]
let rproj_lid = p2l ["Prims"; "R"]

(* Integer comparison relations *)
let lt_lid = p2l ["Prims"; "LT"]
let gt_lid = p2l ["Prims"; "GT"]
let lte_lid = p2l ["Prims"; "LTE"]
let gte_lid = p2l ["Prims"; "GTE"]

let eq_lid = p2l ["Prims"; "Eq"]
let eq2_lid = p2l ["Prims"; "Eq2"]
let eqA_lid = p2l ["Prims"; "EqA"]
let eqTyp_lid = p2l ["Prims"; "EqTyp"]
let neq_lid = p2l ["Prims"; "neq"]
let neq2_lid = p2l ["Prims"; "neq2"]

let withpatterns_lid = p2l ["Prims"; "WithPatterns"]
let exists_lid = p2l ["Prims"; "Exists"]
let exists_typ = twithsort (Typ_const(fvwithsort exists_lid Kind_unknown, None)) Kind_unknown
let forall_lid = p2l ["Prims"; "Forall"]
let forall_typ = twithsort (Typ_const(fvwithsort forall_lid Kind_unknown, None)) Kind_unknown
let existsP_lid = p2l ["Prims"; "ExistsP"]
let existsP_typ = twithsort (Typ_const(fvwithsort existsP_lid Kind_unknown, None)) Kind_unknown
let forallP_lid = p2l ["Prims"; "ForallP"]
let forallP_typ = twithsort (Typ_const(fvwithsort forallP_lid Kind_unknown, None)) Kind_unknown
let existsA_lid = p2l ["Prims"; "ExistsA"]
let existsA_typ = twithsort (Typ_const(fvwithsort existsA_lid Kind_unknown, None)) Kind_unknown
let forallA_lid = p2l ["Prims"; "ForallA"]
let forallA_typ = twithsort (Typ_const(fvwithsort forallA_lid Kind_unknown, None)) Kind_unknown
let existsTyp_lid = p2l ["Prims"; "ExistsTyp"]
let is_forall lid = 
  Sugar.lid_equals lid forallP_lid ||
    Sugar.lid_equals lid forall_lid || 
    Sugar.lid_equals lid forallA_lid
let is_exists lid = 
  Sugar.lid_equals lid existsP_lid || 
    Sugar.lid_equals lid exists_lid || 
    Sugar.lid_equals lid existsA_lid
    
let is_qlid lid = is_forall lid || is_exists lid


let assume_lid = p2l ["Prims"; "Assume"]
let assert_lid = p2l ["Prims"; "Assert"]
let composeClassic_lid = p2l ["Prims"; "composeClassic"]

let reflexivity_lid = p2l ["Prims"; "Reflexivity"]
let symmetry_lid = p2l ["Prims"; "Symmetry"]
let transitivity_lid = p2l ["Prims"; "Transitivity"]
let eqiff_lid = p2l ["Prims"; "EqIff"]
let eqmono_lid = p2l ["Prims"; "EqMono"]
let monoprop_lid = p2l ["Prims"; "MonoProp"]
let tupproj1_lid = p2l ["Prims"; "TupleProj1"]
let tupproj2_lid = p2l ["Prims"; "TupleProj2"]
let tupeq1_lid = p2l ["Prims"; "TupleEq1"]
let tupeq2_lid = p2l ["Prims"; "TupleEq2"]
let tupmonoeq_lid = p2l ["Prims";  "TupleMonoEq"]
let ifftrans_lid = p2l ["ProofLib"; "_Trans"]
let nfa_exnot_lid = p2l ["Prims"; "NotAll_existsNot"]

(* types for logical connectives and proofs *)
let kun k k' = Kind_tcon(None, k, k')
let kbin k k' = Kind_tcon(None, k, Kind_tcon(None, k, k')) 

let kbin_connective = (kbin Kind_erasable Kind_prop)
let and_lid, and_typ = mk_typ ["Prims"; "l_and"] kbin_connective
let or_lid, or_typ = mk_typ ["Prims"; "l_or"] kbin_connective
let not_lid, not_typ = mk_typ ["Prims"; "l_not"] (kun Kind_erasable Kind_prop)
let lbl_lid, lbl_typ = mk_typ ["Prims"; "LBL"] (Kind_dcon(None, string_typ, Kind_tcon(None, Kind_erasable, Kind_erasable)))
let implies_lid, implies_typ = mk_typ ["Prims"; "l_implies"] kbin_connective
let iff_lid, iff_typ = mk_typ ["Prims"; "l_iff"] kbin_connective
let ifthenelse_lid = p2l ["Prims"; "IfThenElse"] 
let pf_lid, pf_typ = mk_typ ["Prims"; "pf"] (kun Kind_prop Kind_prop)
let list_lid, list_typ = mk_typ ["List"; "list"] (kun Kind_star Kind_star)

let mutable_lid, mutable_typ = mk_typ ["Prims"; "mutable"] Kind_star

let w t = twithsort t Kind_star

let op_Eq = p2l ["Prims"; "op_Equality"]

(* Arithmetic operators *)
let add_lid = p2l ["Prims"; "Add"]
let sub_lid = p2l ["Prims"; "Sub"]
let mul_lid = p2l ["Prims"; "Mul"]
let div_lid = p2l ["Prims"; "Div"]
let minus_lid = p2l ["Prims"; "Minus"]
let modulo_lid = p2l ["Prims"; "Modulo"]

(* Some common constructors and free variables. *)
let cons_str = "Cons"      
let nil_str = "Nil"      
let cons_lid = p2l ["Prims"; "Cons"]
let nil_lid = p2l ["Prims"; "Nil"]
let DST_lid = p2l ["Prims"; "DST"]
let ST_lid = p2l ["Prims"; "ST"]
let ST_typ = twithsort (Typ_const(fvwithsort ST_lid Kind_unknown, None)) Kind_unknown
let returnTX_lid = p2l ["Prims"; "returnTX"]
let bindTX_lid = p2l ["Prims"; "bindTX"]
let write_lid = p2l ["Prims"; "write"]
let read_lid = p2l ["Prims"; "read"]
let unqual_write_lid = p2l ["write"]
let unqual_read_lid = p2l ["read"]
let unqual_ref_lid = p2l ["ref"]
let bind_st_lid = p2l ["Prims"; "bind_st"]
let return_st_lid = p2l ["Prims"; "return_st"]
let return_refined_st_lid = p2l ["Prims"; "return_refined_st"]
let array_lid = p2l ["Prims"; "array"]
let newArray_lid = p2l ["Prims"; "newArray"]
let readArray_lid = p2l ["Prims"; "readArray"]
let writeArray_lid = p2l ["Prims"; "writeArray"]
let ref_lid = p2l ["Prims"; "ref"]
let newref_lid = p2l ["Prims"; "newref"]
let and_data_lid = p2l ["Prims"; "AndCons"]
let or_data_lid  = p2l ["Prims"; "OrCons"]
let not_data_lid = p2l ["Prims"; "NotCons"]
let ntuple_lid =  p2l ["Prims"; "NTuple"]
let tuple_UU_lid =  p2l ["Prims"; "Tuple_UU"]
let tuple_UA_lid =  p2l ["Prims"; "Tuple_UA"]
let tuple_AU_lid =  p2l ["Prims"; "Tuple_AU"]
let tuple_AA_lid =  p2l ["Prims"; "Tuple_AA"]
let tuple_PP_lid =  p2l ["Prims"; "Tuple_PP"]
let tuple_UP_lid =  p2l ["Prims"; "Tuple_UP"]
let tuple_PU_lid =  p2l ["Prims"; "Tuple_PU"]
let tuple_PA_lid =  p2l ["Prims"; "Tuple_PA"]
let tuple_AP_lid =  p2l ["Prims"; "Tuple_AA"]
let dcil_tuple_UU_name = ["Prims"; "Tuple_UU"]
let dcil_tuple_UA_name = ["Prims"; "Tuple_UA"]
let dcil_tuple_AU_name = ["Prims"; "Tuple_AU"]
let dcil_tuple_AA_name = ["Prims"; "Tuple_AA"]
let dcil_tuple_PP_name = ["Prims"; "Tuple_PP"]
let dcil_tuple_PA_name = ["Prims"; "Tuple_PA"]
let dcil_tuple_AP_name = ["Prims"; "Tuple_AP"]
let dcil_tuple_UP_name = ["Prims"; "Tuple_UP"]
let dcil_tuple_PU_name = ["Prims"; "Tuple_PU"]
let dcil_tuple_UU_namestring = "Prims.Tuple_UU"
let dcil_tuple_UA_namestring = "Prims.Tuple_UA"
let dcil_tuple_AU_namestring = "Prims.Tuple_AU"
let dcil_tuple_AA_namestring = "Prims.Tuple_AA"
let dcil_tuple_PP_namestring = "Prims.Tuple_PP"
let dcil_tuple_PA_namestring = "Prims.Tuple_PA"
let dcil_tuple_AP_namestring = "Prims.Tuple_AP"
let dcil_tuple_UP_namestring = "Prims.Tuple_UP"
let dcil_tuple_PU_namestring = "Prims.Tuple_PU"

let name_proj_one = "One"
let tuple_proj_one = p2l ["Prims"; name_proj_one]
let name_proj_two = "Two"
let tuple_proj_two = p2l ["Prims"; name_proj_two]

(* Juan: hard-wired field names for projections of tuples!! *)
(* If the translation uses different strategies to generate target field names, *)
(* then the following two need to be changed *)
let dcil_proj_one_name = "Prims_One"
let dcil_proj_two_name = "Prims_Two"

let bind_pf_lid = p2l ["Prims"; "BindPf"]
let modus_ponens_lid = p2l ["Prims"; "ModusPonens"]
let and_elim_1_lid = p2l ["Prims"; "AndElim1"]
let and_elim_2_lid = p2l ["Prims"; "AndElim2"]
let and_intro_lid = p2l ["Prims"; "AndIntro"]

let implies_intro_lid = p2l ["Prims"; "ImpliesIntro"]
let or_intro1_lid = p2l ["Prims"; "OrIntro1"]

let op_And_lid = p2l ["Prims"; "_dummy_op_AmpAmp"]
let op_Or_lid = p2l ["Prims";"_dummy_op_BarBar"]
let op_Not_lid = p2l ["Prims";"_dummy_op_Negation"]

let op_Add_lid = p2l ["Prims";"_dummy_op_Addition"]
let op_Subtraction_lid = p2l ["Prims";"_dummy_op_Subtraction"]
let op_Multiply_lid = p2l ["Prims";"_dummy_op_Multiply"]
let op_Division_lid = p2l ["Prims";"_dummy_op_Division"]
let op_Modulus_lid = p2l ["Prims";"_dummy_op_Modulus"]
let op_Dereference_lid = p2l ["Prims";"_dummy_op_Dereference"]
let op_ColonEquals_lid = p2l ["Prims";"_dummy_op_ColonEquals"]
let op_lte_lid = p2l ["Prims";"_dummy_op_LessThanOrEqual"]
let op_gte_lid = p2l ["Prims";"_dummy_op_GreatherThanOrEqual"]
let op_lt_lid = p2l ["Prims";"_dummy_op_LessThan"]
let op_gt_lid = p2l ["Prims";"_dummy_op_GreatherThan"]

let op_read_lid = p2l ["Prims"; "read"]
let op_write_lid = p2l ["Prims"; "write"]

let foreach_lid = p2l ["foreach"]

let op_GreaterThanOrEqual_lid = p2l ["Prims";"_dummy_op_GreaterThanOrEqual"]
let unfold_lid = p2l ["Prims"; "Unfold"]

(* JS-specific stuff *)
let unname_lid = p2l ["JSVerify"; "Unname"]
let tx_as_e_lid = p2l ["JSVerify"; "TxAsE"]
let js_function_lid = p2l ["JSVerify"; "Function"]
let exists_tx_lid = p2l ["JSVerify"; "existsTx"]
let select_obj_lid = p2l ["JSVerify"; "SelectObj"]
let select_lid = p2l ["JSVerify"; "Select"]
let allocd_lid = p2l ["JSVerify"; "Allocd"]
let update_lid = p2l ["JSVerify"; "Update"]
let alloc_lid = p2l ["JSVerify"; "Alloc"]
let select_typ_lid = p2l ["JSVerify"; "SelectTyp"]
let get_type_lid = p2l ["JSVerify"; "GetType"]
let indomain_lid = p2l ["JSVerify"; "InDomain"]
let dyn_lid = p2l ["JSVerify"; "dyn"]
let initial_heap_lid = p2l ["DOM"; "initial_heap"]
let jsver_lid = p2l ["JSVerify"]
let dom_lid = p2l ["DOM"]

let is_tuple_data_lid lid = match path_of_lid lid with 
  | ["Prims"; "Tuple_PP"]
  | ["Prims"; "Tuple_PU"]
  | ["Prims"; "Tuple_UP"]
  | ["Prims"; "Tuple_AP"]
  | ["Prims"; "Tuple_PA"]
  | ["Prims"; "Tuple_UU"]
  | ["Prims"; "Tuple_UA"]
  | ["Prims"; "Tuple_AU"]
  | ["Prims"; "Tuple_AA"] -> true
  | _ -> false

let tuple_data_lid k1 k2 = match (unbox k1)(* .u *), (unbox k2)(* .u *) with
  | Kind_star, Kind_star -> tuple_UU_lid
  | Kind_prop, Kind_star -> tuple_PU_lid
  | Kind_star, Kind_prop -> tuple_UP_lid
  | Kind_prop, Kind_prop -> tuple_PP_lid
  | Kind_prop, Kind_affine -> tuple_PA_lid
  | Kind_affine, Kind_prop -> tuple_AP_lid
  | Kind_star, Kind_affine -> tuple_UA_lid
  | Kind_affine, Kind_star -> tuple_AU_lid
  | Kind_affine, Kind_affine -> tuple_AA_lid 
  | _ -> raise Impos

