#light "off"
module Microsoft.FStar.GateKeeperPass

open Absyn
open Util

exception Impos

let quoteStr str = "\"" ^ str ^ "\""

type loc = string 
let dummyLoc = quoteStr "dummyLoc"

type stack = loc list
let locStack = ref ([]: stack)
let pushLoc loc = locStack := loc::(!locStack)
let topLoc () = match !locStack with 
                  | loc::rest -> loc
                  | _ -> Printf.printf "topLoc: empty stack"; 
                  raise Impos
let popLoc () = match !locStack with 
                  | loc::rest -> locStack := rest; loc
                  | _ -> Printf.printf "popLoc: empty stack"; 
                  raise Impos

let dummyString = ""

let curry exp =
  let rec aux exp = 
    let unascribed = unascribe exp in
    match unascribed.v with
      | Exp_app(efun, earg) -> 
        let efun', eargs' = aux efun in
        efun', earg::eargs'
      | _ -> unascribed, [] in
  let efun, eargs = aux exp in
  efun, List.rev eargs

type Fact =
  (* Constructors starting with T_ are temporary ones, no need to output *)
  | T_GetField of exp * string
  | T_NewObject of loc * exp * (string * Fact) list  (* loc, constr, fname_value_map *)
  | T_Constr of loc * exp * exp list              (* loc, constr, args *)
  | T_Call of loc * exp * exp list
  (* The rest are facts for Datalog *)
  | Value of string
  | Const of Sugar.sconst                       (* constant, including string *)
  | UpdateField of exp * string * Fact          (* obj, fname, newvalue *)
  | Assign of exp * exp                         (* dest, src *)
  | LetBinding of bvvdef * Fact
  | Formal of loc * string * bvvdef              (* formal("0", x) *)
  | AllocFunc of loc * bvvdef                    (* loc, temp name for function *)
  | FormalRet of loc * Fact                     (* loc, return value *)

let prettyExp e = match (unascribe e).v with
    | Exp_fvar(fvar, _) -> quoteStr(Sugar.text_of_lid fvar.v)
    | Exp_bvar bvar -> quoteStr(Sugar.text_of_id(bvar.v.realname))
    | Exp_constant c -> Pretty.strConst c
    | _ -> "" 

let prettyBvdef bvdef = quoteStr(Sugar.text_of_id(bvdef.realname))

let constProp facts =
  let eqName bvd fname = fname = prettyBvdef bvd in
  let substFact bvdConsMap fact =
    match fact with
      | LetBinding(x, T_GetField(e, fname)) -> 
        (match List.tryFind (fun (bvd, cons) -> eqName bvd fname) bvdConsMap with
          | Some (bvd, cons) -> LetBinding(x, T_GetField(e, Pretty.strConst cons))
          | _ -> fact)
      | LetBinding(x, UpdateField(e, fname, newv)) ->
        (match List.tryFind (fun (bvd, cons) -> eqName bvd fname) bvdConsMap with
          | Some (bvd, cons) -> LetBinding(x, UpdateField(e, Pretty.strConst cons, newv))
          | _ -> fact)
      | _ -> fact in
  let rec aux map facts = 
    match facts with
      | [] -> []
      | LetBinding(bvd, Const c)::rest ->
        aux ((bvd, c)::map) rest
      | fact::rest -> (substFact map fact)::(aux map rest) in
  aux [] facts

let rec unwrapExp exp: exp =
  let exp = unascribe exp in
  match exp.v with
    | Exp_constr_app(vfun, _, _, es) ->
      (match Sugar.text_of_lid vfun.v, es with
        | "JSBuiltIns.PrimInt'", [v] 
        | "JSBuiltIns.PrimNum'", [v] 
        | "JSBuiltIns.PrimString'" , [v]
        | "JSBuiltIns.PrimBool'", [v]
        | "JSBuiltIns.PrimRegexp'", [v] -> unwrapExp v
        | "JSBuiltIns.PrimObject'", [v] 
        | "JSBuiltIns.PrimRef'", [v] 
        | "JSBuiltIns.PrimReturn'", [v]  
        | "JSBuiltIns.PrimBreak'", [v] -> unwrapExp v
        | _ -> AbsynUtils.W(Exp_constr_app(vfun, [], [], List.map unwrapExp es)))
    | Exp_app(efun, earg) ->
       let efun = unwrapExp efun in
       (match efun.v with
        | Exp_fvar(fvar, _) ->
          (match Sugar.text_of_lid fvar.v with
             | "JSBuiltIns.toint32'"
             | "JSBuiltIns.toNumber'"
             | "JSBuiltIns.toObject'"
             | "JSBuiltIns.toString'"
             | "JSBuiltIns.primDeref'"
             | "JSBuiltIns.primString'"
             | "JSBuiltIns.primToBool'"
             | "JSBuiltIns.primToFunction'"
             | "JSBuiltIns.primToNum'"
             | "Prims.ref" 
             | "Prims.read" -> unwrapExp earg
             | _ -> AbsynUtils.W(Exp_app(efun, unwrapExp earg)))
        | _ -> AbsynUtils.W(Exp_app(efun, unwrapExp earg)))
    | Exp_tapp(e, _) -> unwrapExp e
    | _ -> exp


let rec prettyFact fact =
  let rec prettyList prettyOne ls =
    match ls with
      | [] -> ""
      | [one] -> prettyOne one
      | hd::tl -> (prettyOne hd) ^ ", " ^ (prettyList prettyOne tl) in
  match fact with
    | Value str -> str
    | LetBinding(bvdef, Value str) -> "Bind(" ^ (prettyBvdef bvdef) ^ ", " ^ str ^ ")."
    | LetBinding(bvdef, Const str) -> "BindConst(" ^ (prettyBvdef bvdef) ^ ", " ^ (Pretty.strConst str) ^ ")."
    | LetBinding(_, UpdateField(e, fname, newe)) ->
      "Store(" ^ (prettyExp e) ^ ", " ^ fname ^ ", " ^ (prettyFact newe) ^ ")."
    | LetBinding(bvdef, T_GetField(e, fname)) ->
      "Load(" ^ (prettyBvdef bvdef) ^ ", " ^ (prettyExp e) ^ ", " ^ fname ^ ")."
    | LetBinding(x, T_NewObject(loc, constr, fname_value_list)) ->
      let prettyFnameValue (fname, v) = "\nStore(" ^ (prettyBvdef x) ^ ", " ^ fname ^ ", " ^ (prettyFact v) ^ ")." in
      "Alloc(" ^ loc ^ ", " ^ (prettyBvdef x) ^ ", " ^ (prettyExp constr) ^ ")." ^
      (String.concat "\n" (List.map prettyFnameValue fname_value_list))
    | Formal(loc, index, x) -> "Formal(" ^ loc ^ ", " ^ (index.Trim([|'"'|])) ^ ", " ^ (prettyBvdef x) ^ ")."
    | AllocFunc(loc, x) -> "AllocFunc(" ^ loc ^ ", " ^ (prettyBvdef x) ^ ")."
    | LetBinding(bvdef, T_Call(loc, efun, args)) ->
      let rec prettyArgs index args =
        match args with
          | [] -> ""
          | arg::rest -> "\nArgument(" ^ loc ^ ", " ^ index.ToString() ^ ", " ^ (prettyExp arg) ^ ")." ^ (prettyArgs (index+1) rest) in
       "Call(" ^ loc ^ ", " ^ (prettyExp efun) ^ ")." ^
       "\nActualRet(" ^ loc ^ ", " ^ (prettyBvdef bvdef) ^ ")." ^
        (prettyArgs 0 args)

    | LetBinding(bvdef, T_Constr(loc, efun, args)) -> 
      let rec prettyArgs index args =
        match args with
          | [] -> ""
          | arg::rest -> "\nArgument(" ^ loc ^ ", " ^ index.ToString() ^ ", " ^ (prettyExp arg) ^ ")." ^ (prettyArgs (index+1) rest) in
      "Constr(" ^ loc ^ ", " ^ (prettyExp efun) ^ ")." ^
       "\nActualRet(" ^ loc ^ ", " ^ (prettyBvdef bvdef) ^ ")." ^
      (prettyArgs 0 args)
    | LetBinding(_, Assign(dest, src)) -> "Assign(" ^ (prettyExp dest) ^ ", " ^ (prettyExp src) ^ ")."
    | FormalRet(loc, fact) -> "FormalRet(" ^ loc ^ ", " ^ (prettyFact fact) ^ ")."
    | _ -> "" (* TODO *)

let prettyValue fact =
  match fact with
    | Value str -> str
    | Const cons -> Pretty.strConst cons
    | _ -> Printf.printf "\nexpect a value, but got %s" (prettyFact fact); 
    raise Impos

let rec getList exp : exp list =
  let exp = unascribe exp in
  match exp.v with
    | Exp_constr_app(vfun, _, _, es) ->
      (match Sugar.text_of_lid vfun.v, es with
        | "Prims.Nil", [] -> []
        | "Prims.Cons", [hd; tl] -> (unwrapExp hd) :: (getList tl)
        | _ -> Printf.printf "getList: not Nil/Cons in %s" (Pretty.strExp exp);
          raise Impos)
    | _ -> Printf.printf "getList: %s" (Pretty.strExp exp); 
    raise Impos

let getTuple exp : exp * exp =
  match (unascribe exp).v with
    | Exp_constr_app(vfun, _, _, [e1; e2]) -> 
      (match Sugar.text_of_lid vfun.v with
        | "Prims.Tuple_UU"  
        | "Prims.Tuple_UA" 
        | "Prims.Tuple_AA"
        | "Prims.Tuple_AU" -> unwrapExp e1, unwrapExp e2
        | _ -> Printf.printf "getTuple: not a Tuple constr in %s" (Pretty.strExp exp);
          raise Impos)
    | _ -> Printf.printf "getTuple: %s" (Pretty.strExp exp); 
    raise Impos


let rec doExp exp : Fact * Fact list = (* the first one is for the exp return value *)
  let exp = unwrapExp exp in
  match exp.v with
    | Exp_constant cons -> Const(cons),  []    
    | Exp_constr_app(vfun, _, _, es) ->
      (match Sugar.text_of_lid vfun.v, es with
        | "JSBuiltIns.PrimFunction'", [loc_func] -> (* define a function *)        
           let loc, func = getTuple loc_func in
           let newf = Absyn.new_bvd None in
           let loc = prettyExp loc in     
           let _ = pushLoc loc in
           let ret, facts = doExp func in (* lambda *)
           let _ = popLoc() in
           Value(prettyBvdef newf), (AllocFunc(loc, newf) :: facts) @ [ret]
           
        | "JSBuiltIns.PrimUndefined'",  _ -> Value(quoteStr "Undefined"),  []
        | "JSBuiltIns.PrimNaN'", _ -> Value(quoteStr "NaN"), []
        | "JSBuiltIns.PrimInfinity'", _ -> Value(quoteStr "Infinity"), [] 
        | "JSBuiltIns.PrimNull'", _ -> Value(quoteStr "Null"), []
        | _ -> Printf.printf "doExp: constr_app: %s" (Pretty.strExp exp);
         raise Impos)
    | Exp_abs (bvd, t, e) -> doExp e  (* TODO *)
    | Exp_app _  -> (* TODO *)
      let efun, eargs = curry exp in
      let efun = unwrapExp efun in
      let eargs = List.map unwrapExp eargs in
      let doApp args = (* return loc, func, args *)
        List.hd args, List.hd(List.tl args), List.tl (List.tl args) in
      (match efun.v with
        | Exp_fvar(fvar, _) ->
          (match Sugar.text_of_lid fvar.v, eargs with
             | "JSBuiltIns.primToFunctionApp'", _ -> (* normal call *)
               let loc, func, args = doApp eargs in
                 T_Call(prettyExp loc, func, args),  []
             | "JSBuiltIns.primToFunctionNew'", _ -> (* constructor call *)
               let loc, func, args = doApp eargs in
               T_Constr(prettyExp loc, func, args), []
             | "Prims.write", [v1; v2] ->
               Assign(unwrapExp v1, unwrapExp v2), []
             | "JSBuiltIns.jsGetField'", [v1; v2] ->
              (* get field *)
               let fname, facts2 = doExp v2 in
               T_GetField(v1, prettyValue fname), facts2
             | "JSBuiltIns.jsUpdateField'", [v1; v2; v3] ->
               let fname, facts2 = doExp v2 in
               let newv3, facts3 = doExp v3 in
               UpdateField(v1, prettyValue fname, newv3), facts2@facts3
             | "JSBuiltIns.jsNewObject'", [loc; constr; fname_value_map] ->
               let fname_value_list = getList fname_value_map in
               let fname_fact_list, facts = 
                 List.fold (fun name_fact_list_facts fname_value -> 
                   let name_fact_list, facts = name_fact_list_facts in
                   let fname, value = getTuple fname_value in
                   let fact_v, facts_v = doExp value in
                   (prettyValue(fst(doExp fname)), fact_v)::name_fact_list, facts_v@facts)
                    ([], []) fname_value_list in
               T_NewObject(prettyExp loc, constr, List.rev fname_fact_list), List.rev facts
             | _ -> T_Call(dummyLoc, efun, eargs), [] (* TODO *)
             )
        | _ -> let (_, facts_f) = doExp efun in
               let facts_arg = List.fold (fun facts e -> facts@(snd (doExp e))) [] eargs in
               T_Call(dummyLoc, efun, eargs), facts_f@facts_arg
       )
    | Exp_match (e, pes, edefault) ->
      let doPattern pe =
        let pat, ebranch = pe in
        snd(doExp ebranch) in
      let e', facts_e = doExp e in
      FormalRet(topLoc(), e'), facts_e
//      let facts_pe = List.fold (fun facts pe -> facts @ (doPattern pe)) facts_e pes in
//      let _, facts_edefault = doExp edefault in
//      Value(dummyString), facts_pe @ facts_edefault
    | Exp_cond(eb, et, ef) ->
      let _, facts_eb = doExp eb in
      let _, facts_et = doExp et in
      let _, facts_ef = doExp ef in
      Value(dummyString), facts_eb @ facts_et @ facts_ef
    | Exp_primop (op, es) ->
      Value(dummyString), List.fold (fun facts e -> facts@(snd (doExp e))) [] es
    | Exp_let(_, letbindings, e') -> (* let x1:t1 = e1, ...., xn:tn = en in e *)
      let facts_bs = doLetBindings letbindings in
      let v', facts' = doExp e' in
      v', facts_bs@facts'
    | Exp_fvar (fvar, _) -> Value(quoteStr(Sugar.text_of_lid fvar.v)), []
    | Exp_bvar bvar -> Value(quoteStr(Sugar.text_of_id bvar.v.realname)), []
    | Exp_bot -> Value(dummyString), []
    | Exp_tapp (e, _) -> doExp e  (* ignoring type appliation *)
    | _ -> Printf.printf "doExp: %s" (Pretty.strExp exp); 
    raise Impos    

    (* UpdateField'*)

and doLetBindings letbindings : Fact list = (* x1: t1 = e1, ..., xn:tn = en *)
  List.fold (fun facts (x, t, e) ->
                 let v, facts_e = doExp e in 
                 match v with
                   | Const(cons) ->
                     (match cons with
                       | Sugar.Const_string _ -> facts@facts_e@[LetBinding(x, v)]
                       | _ -> facts @ facts_e)  (* drop constants other than string *)
                   | T_GetField(obj, fname) ->
                     (match obj.v with
                        | Exp_bvar bvar ->
                          if Sugar.text_of_id(bvar.v.ppname) = "arguments'" then
                          facts@facts_e@[Formal(topLoc(), fname, x)]
                          else facts@facts_e@[LetBinding(x, v)]
                        | _ -> facts@facts_e@[LetBinding(x, v)])
                   | _ -> facts@facts_e@[LetBinding(x, v)])
                  [] letbindings

let rec lookupFact facts e =
  match facts with
   | [] -> None
   | LetBinding(x, fact_x) :: rest -> if (prettyBvdef x = prettyExp e) then Some fact_x else lookupFact rest e
   | _ :: rest -> lookupFact rest e

      
let doMod (tmod:modul) =
  let name = Sugar.text_of_lid tmod.name in
  if (name.Equals("Prims") || name.StartsWith("Prooflib") ||
      name.Equals("JSBuiltIns") || name.Equals("List")) then []
  else let facts = List.fold (fun facts_m (bds, _) -> 
                      let facts_bds = doLetBindings bds in
                      facts_m@(facts_bds)) [] (tmod.letbindings) in
       match tmod.main with
         | Some e -> let _, facts_e = doExp e in facts @ facts_e
         | _ -> facts

(* Transforming Absyn using information from GateKeeper analysis *)
let trans tmods = 
  let facts = List.fold (fun facts tmod -> facts @(constProp (doMod tmod))) [] tmods in
  let _ = List.map (fun fact -> Printf.printf "\n%s" (prettyFact fact)) facts in
  facts, tmods

