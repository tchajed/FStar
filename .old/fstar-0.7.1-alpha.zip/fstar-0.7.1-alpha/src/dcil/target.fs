#light "off"
// (c) Microsoft Corporation. All rights reserved
module Microsoft.FStar.Target

open Util
open Const

type tIdent = string          (* identifier *)
type tLident = tIdent list    (* long identifier *)
type tBvDef = tIdent * tIdent (* pretty-printing name and real name *)

type tVar<'t> = tIdent * 't   (* variables, including type var and value var *)
type tName<'t> = tLident * 't (* names [for external types, etc] *)
type tClassName = tLident     (* full name of a class *)
type tFieldName = string
type tMethodName = string

type tPrimop = | AND | OR | ADD | SUB | MUL | DIV | NOT  (* primitive operators *)

type tFieldRef = tFieldName

type tMethodRef = tMethodName * tType list  (* method instantiations *)

and tKvar =tVar<unit>              (* kind variables *)

and tKind =
  | TKind_star                     (* normal kind *)
  | TKind_affine                   (* affine kind *)
  | TKind_erasable                 (* erasable kind *)
  | TKind_prop                     (* kind for propositions *)
  | TKind_arrow of tType * tKind   (* t -> k where t cannot be an affine type unless k ends with E *)
  | TKind_karrow of tKind * tKind  (* k1 -> k2 *)
  | TKind_var of tKvar             (* kind variable *)

and tType =
  | TType_index of uint16                       (* debruijn index *)
  | TType_var of tVar<tKind>                    (* type variable *)
  | TType_name of tName<tKind> * option<Sugar.externref> (* type names [for external types] *)
  | TType_fun of option<tBvDef> * tType * tType (* dependent type function *)
  | TType_tfun of tBvDef * tKind * tType        (* \a::k.t *)
  | TType_dep of tType * tValue                 (* dependent type function application *)
  | TType_tapp of tType * tType                 (* type application *)
  | TType_concrete of tTypeConcrete             (* data class *)
  | TType_affine of tType                       (* affine type *)
  | TType_refine of tBvDef * tType * tFormula * string * list<tClassName * list<tType>>  (* x:t{phi} *)
  | TType_inferred of Unionfind.uvar<tUvar_inferred>     (* place holder for inferrable types, currently used only for let bindings *)

and tFormula = tType

(* type unification for inferred types*)
and tUvar_inferred = 
  | TUvar
  | TFixed of tType

and Arg =
  | Targ of tType
  | Varg of tValue

and tTypeConcrete = tClassName * tKind list * Arg list * option<Sugar.externref>(* abstract/data class *)

and tValue = 
  | TVal_var of tVar<tType>                 (* variable *)
  | TVal_obj of tTypeConcrete * tValue list (* object *)
  | TVal_constant of Sugar.sconst           (* constant *)
  | TVal_ldfld of tValue * tFieldRef
  | TVal_uvar of Unionfind.uvar<tUvar_castVal> 
  | TVal_logic_fun of tName<tType> * tValue list  (* apply a logic function to a list of values *)

and tUvar_castVal =
  | TUval of tValue
  | TUcast of tType * tValue              (* cast<t> v *)

and tPat =                                (* patterns used in isinst *)
  | Ptype of tType                        (* type variables *)
  | Pvar of tVar<tType>                   (* value variables *)
  | Pfield of tVar<tType>                 (* fields *)

type tExp =
  | TExp_val of tValue                                  (* value *)
  | TExp_name of tName<tType> * option<Sugar.externref> (* external name *) 
  | TExp_ldfld of tValue * tFieldRef                    (* field access *)
  | TExp_call of tValue * tValue list * tMethodRef      (* function call *)
  | TExp_extern_call of Sugar.externref * tMethodRef * tValue list (* call to an external function *)
  | TExp_let of tVar<tType> * tExp * tExp * bool ref    (* let x = e in e'. x's type may be TType_inferred (when the flag is false) *)
  | TExp_isinst of tValue * (tClassName * tKind list * tPat list * bool * tExp) list * tExp * tType (* type test, the flag indicates GADT when set *)
  | TExp_cond of tExp * tExp * tExp                     (* conditional exp *)
  | TExp_primop of tPrimop * list<tValue>               (* n-ary primitive op *)
  | TExp_ascribed of tExp * tType                       (* ascribed with type *)
  | TExp_bot                                            (* error exp, for Exp_bot in FStar *)
                                                        (* translates to exception in MSIL *)
(* visibility qualifier *)
type tVisibility = 
  | TVis_public
  | TVis_internal

(* instance field declaration *)
type tFieldDecl = tFieldName * tType

(* static field declaration, with optional initialization value *)
type tStaticFieldDecl = tFieldName * tType * tExp option 

(* still keep the list representation to minimize the change *)
(* will change later to options instead of lists for type/value parameters *)
type tMethodDecl = tType * tMethodName * tVar<tKind> list * tVar<tType> list * tExp option
    (* t m<a:k>(x:t) {e} *)

(* evidences *)
type tEvidence =
  | TEv_val of tVar<tType> * tValue (* value equivalence *)
  | TEv_type of tVar<tKind> * tType (* type equivalence *)

type tEvidences = tEvidence list (* same as the target variable environment *)

(* whether the class decl comes from a source axiom or prop *)
type tAttr =
  | Axiom
  | Prop
  | NoAttr

type Var =
  | Tvar of tVar<tKind>
  | Vvar of tVar<tType>

type tClassDecl = {
  (* C<a1:k1, ..., am:km, x1:t1, ..., xn:tn> : B {methods} *)
  visibility: tVisibility;
  attr: tAttr;
  name: tClassName;
  namestring: string;
  kvars: tKvar list;
  vars: Var list; (* type variables and value variables. Support non-prenext forms *)
  (* ptvars: tVar<tKind> list; (* DCIL kinds of first-order tvars appear as custom attrs on ILGenericParameterDef *)
  tvars: tVar<tKind> list;  (* DCIL kinds for higher-order tvars appear as custom attrs on enclosing ILTypeDef *)
  vvars: tVar<tType> list; (* DCIL types and vvar marker appear as custom attr on ILFieldDecl *) *)
  evidences: tEvidences; (* Attribute on ILTypeDef *)
  extends: tType option; (* Attribute on ILTypeDef *)
  fields: tFieldDecl list; (* DCIL Types appear as attrs on ILFieldDecl *)
  staticFields: tStaticFieldDecl list; (* DCIL Types appear as attrs on ILFieldDecl *)
  methods: tMethodDecl list;
  kind: tKind option; (* Kind appears as optional attr on ILTypeDef *)
  externref: option<Sugar.externref>;
  hasTag:bool; (* only base-level inductive types have this flag set *)
  tagNum:option<int>; (* every data constructor of an inductive has a unique tag *)
}

type tCdecls = (string, tClassDecl) Hashtbl.t

let createTCdecls cdecls : tCdecls =
  let env = Hashtbl.create 100 in
  List.map (fun cdecl -> Hashtbl.add env (cdecl.namestring) cdecl) cdecls;
  env

type tExternMethodDecl = {extref:Sugar.externref; methodname:tMethodName; formalargs:list<tType>; ret:tType}

type tModule = {
  name: tLident;          (* module name *)
  extends: tLident option; (* extends module name *)
  modCdecl: tClassDecl;   (* the class for module itself *)
  decls: tCdecls;         (* class declarations *)
  externs: tCdecls; (* references to extern F# classes *)
  entry : option<tExp>;   (* entry point *)
  externMethods : list<tExternMethodDecl> 
}

(* ================= utilities ======================== *)

let objType = TType_name((["System"; "object"], TKind_star), None) (* this eref could be mscorlib *)

let newSym = (* create a new symbol *)
  fun() -> Microsoft.FStar.Sugar.nng.Apply "y" Absyn.dummyRange

(* create a new kind variable *)
let newKvar() : tKvar = (newSym(), ())

(* create a new type variable with kind knd *)
let newTvar (k: tKind): tVar<tKind> = (newSym(), k)

(* create a new value variable with type typ *)
let newVvar (t: tType): tVar<tType> = (newSym(), t)
  
(* check if an expression is a value *)
let isval (e: tExp) : bool =
  match e with
    | TExp_val _ -> true
    | _ -> false

let coerceEToVals (e: tExp) : tValue list =
  match e with
    | TExp_val v -> [v]
    | _ -> []


(* ================= built-in class declarations =========== *)

let is_abstract = function
    ["DepArrow"] -> true
  | _ -> false

(* Deparrow<k1, k2, a1:k1, a2: a1 -> k2> { *)
(*   public a2<x> App (a1 x);              *)
(* }                                       *)
let tClassDepArrow: tClassDecl =
  let kvar1, kvar2 = newKvar(), newKvar() in
  let tvar1: tVar<tKind> = newTvar (TKind_var kvar1) in
  let type1 = TType_var tvar1 in
  let tvar2: tVar<tKind> = newTvar (TKind_arrow(type1, TKind_var kvar2)) in
  let type2 = TType_var tvar2 in
  let x = newVvar type1 in
  let method_app: tMethodDecl = (
    TType_dep(type2, TVal_var(x)),
    "Invoke",
    [],
    [x],
    None
  ) in
  {externref=None;
  visibility = TVis_public;
  attr = NoAttr;
  name = ["DepArrow"];
  namestring = "DepArrow";
  kvars = [kvar1; kvar2]; 
  vars = [Tvar tvar1; Tvar tvar2];
  evidences = [];
  extends = Some (TType_concrete(["Microsoft";"FSharp";"Core";"FSharpFunc`2"], [], [Targ type1; Targ type2], None));
  fields = [];
  staticFields = [];
  methods = [method_app];
  kind = None;  
  hasTag=false;
  tagNum=None
  }

(* Arrow<k1, k2, a1:k1, a2 k2> { *)
(*   public a2 App (a1 x);       *)
(* }                             *)
let tClassArrow: tClassDecl =
  let kvar1, kvar2 = newKvar(), newKvar() in
  let tvar1, tvar2 = newTvar (TKind_var kvar1), newTvar(TKind_var kvar2) in 
  let type1, type2 = TType_var tvar1, TType_var tvar2 in
  let x = newVvar type1 in
  let method_app: tMethodDecl = (
    type2,
    "Invoke",
    [],
    [x],
    None
  ) in
  {externref=None;
  visibility = TVis_public;
  attr = NoAttr;
  name = ["Arrow"];
  namestring = "Arrow";
  kvars = [kvar1; kvar2]; 
  vars = [Tvar tvar1; Tvar tvar2];
  evidences = [];
  extends = Some (TType_concrete(["Microsoft";"FSharp";"Core";"FSharpFunc`2"], [], [Targ type1; Targ type2],  None));
  fields = [];
  staticFields = [];
  methods = [method_app];
  kind = None;
  hasTag=false;
  tagNum=None
  }

(* class DepTuple<k1, k2, a1::k1, a2::a1->k2> {} *)
let tClassDepTuple =
  let kvar1, kvar2 = newKvar(), newKvar() in
  let tvar1 = newTvar(TKind_var kvar1) in
  let type1 = TType_var tvar1 in
  let tvar2 = newTvar(TKind_arrow(type1, TKind_var kvar2)) in
  {externref = None;
  visibility = TVis_public;
  attr = NoAttr;
  name = ["DepTuple"];
  namestring = "DepTuple";
  kvars = [kvar1; kvar2];
  vars = [Tvar tvar1; Tvar tvar2];
  evidences = [];
  extends = None;
  fields = [];
  staticFields = [];
  methods = [];
  kind = None; 
  hasTag=true;
  tagNum=None
}

(* class Tuple<k1, k2, a1::k1, a2::k2> {} *)
let tClassTuple =
  let kvar1, kvar2 = newKvar(), newKvar() in
  let tvar1, tvar2 = newTvar(TKind_var kvar1), newTvar(TKind_var kvar2) in
  {externref = None;
  visibility = TVis_public;
  attr = NoAttr;
  name = ["Tuple"];
  namestring = "Tuple";
  kvars = [kvar1; kvar2];
  vars = [Tvar tvar1; Tvar tvar2];
  evidences = [];
  extends = None;
  fields = [];
  staticFields = [];
  methods = [];
  kind = None; 
  hasTag=true;
  tagNum=None
}

(* DconDepTuple<k1, k2, a1::k1, a2::a1->k2, fst:a1, snd: a2 fst>: DepTuple<k1, k2, a1, a2> {} *)
let tClassDconDepTuple =
  let kvar1, kvar2 = newKvar(), newKvar() in
  let tvar1 = newTvar(TKind_var kvar1) in
  let type1 = TType_var tvar1 in
  let tvar2 = newTvar(TKind_arrow(type1, TKind_var kvar2)) in
  let fst = ("fst", type1) in
  let type2 = TType_dep(TType_var tvar2, TVal_var fst) in
  let snd = ("snd", type2) in
  let super = TType_concrete(tClassDepTuple.name, [TKind_var kvar1; TKind_var kvar2],
                             [Targ(TType_var tvar1); Targ(TType_var tvar2)],
                             None) in
  {externref = None;
  visibility = TVis_public;
  attr = NoAttr;
  name = ["DconDepTuple"];  
  namestring = "DconDepTuple";
  kvars = [kvar1; kvar2];
  vars = [Tvar tvar1; Tvar tvar2; Vvar fst; Vvar snd];
  evidences = [];
  extends = Some super;
  fields = [];
  staticFields = [];
  methods = [];
  kind = None;
  hasTag=false;
  tagNum=Some 1
}

(* class DconTuple<k1, k2, a1::k1, a2::k2, fst: a1, snd: a2>:Tuple<k1, k2, a1, a2> {} *)
let tClassDconTuple =
  let kvar1, kvar2 = newKvar(), newKvar() in
  let tvar1, tvar2 = newTvar(TKind_var kvar1), newTvar(TKind_var kvar2) in
  let type1, type2 = TType_var tvar1, TType_var tvar2 in
  let fst, snd =  ("fst", type1), ("snd", type2) in
  let super = TType_concrete(tClassTuple.name, [TKind_var kvar1; TKind_var kvar2],
                             [Targ(TType_var tvar1); Targ(TType_var tvar2)],
                             None) in
  {externref = None;
  visibility = TVis_public;
  attr = NoAttr;
  name = ["DconTuple"];
  namestring = "DconTuple";
  kvars = [kvar1; kvar2];
  vars = [Tvar tvar1; Tvar tvar2; Vvar fst; Vvar snd];
  evidences = [];
  extends = Some super;
  fields = [];
  staticFields = [];
  methods = [];
  kind = None;
  hasTag=false;
  tagNum=Some 1
}

(* the class for polymorphic types forall a::k. t *)
(* All<ka, kt, b:ka => kt> {(b a) TyApp<a::ka>; } *)
let tClassAll: tClassDecl =
  let kvar : tKvar = newKvar() in
  let kvart : tKvar = newKvar() in
  let ka: tKind = TKind_var kvar in
  let kb: tKind = TKind_karrow(ka, TKind_var kvart) in
  let tvar_a: tVar<tKind> = newTvar ka in
  let tvar_b: tVar<tKind> = newTvar kb in
  let tyapp: tMethodDecl = (
    TType_tapp(TType_var tvar_b, TType_var tvar_a), (* return type *)
    "TyApp",         (* name *)
    [tvar_a],        (* type variables *)
    [],              (* value parameters *)
    None             (* method body *)
  ) in
  {externref = None;
   visibility = TVis_public;
   attr = NoAttr;
   name = ["All"];
   namestring = "All";
   kvars = [kvar; kvart];
   vars = [Tvar tvar_b];
   evidences = [];
   extends = None;
   fields = [];
   staticFields = [];
   methods = [tyapp];
   kind = Some (TKind_var kvart);
   hasTag=false;
   tagNum=None
}

let predefined_classes = 
  [tClassDepArrow; 
   tClassArrow; 
   tClassDepTuple; 
   tClassTuple; 
   tClassDconDepTuple; 
   tClassDconTuple;
   tClassAll]

let predefined = (* predefined class declarations *)
  createTCdecls predefined_classes

(*================== base types  ===========*)
(* Should be the same as the translation of the prim absyn types *)
let intType = TType_name((["Prims"; "int"], TKind_star), None)
let boolType = TType_name((["Prims"; "bool"], TKind_star), None)
let stringType = TType_name((["Prims"; "string"], TKind_star), None)
let unitType = TType_name((["Prims"; "unit"], TKind_star), None)
let bytesType = TType_name((["Prims"; "bytes"], TKind_star), None)
let botType = TType_name((["Prims"; "bot"], TKind_star), None)

let trueVal = TVal_constant(Sugar.Const_bool true)
let falseVal = TVal_constant(Sugar.Const_bool false)
