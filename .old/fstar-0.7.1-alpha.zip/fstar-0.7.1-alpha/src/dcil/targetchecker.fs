#light "off"
// (c) Microsoft Corporation. All rights reserved
module Microsoft.FStar.TargetChecker

(* type checker for the target language DCIL *)

open Target
open TargetUtil
open Util
open PrettyTarget
open Profiling 

exception TargetCheckerErr of string
let err msg = (Printf.printf "%s" msg; raise (TargetCheckerErr msg))

let pr = Printf.printf
let spr = Printf.sprintf

let useTeq = ref false

(*=================Environments==============*)

(* most typing environments are defined in TargetUtil.fs *)

let extNotFound eref mn = raise (TargetCheckerErr (spr "Extern method %A. %s not found" eref mn))  
let erefEquals (e1:Sugar.externref) (e2:Sugar.externref) = 
    let sli       = Pretty.str_of_lident in
    let result = (sli e1.classname)=(sli e2.classname) && 
                 (e1.innerclass=e2.innerclass) in
      result
let lookupExtMethod exts eref mn = 
    match List.tryFind (fun emd -> erefEquals emd.extref eref && 
                                    emd.methodname=mn) exts with  
          Some emd -> emd.formalargs, emd.ret
        | _ -> extNotFound eref mn
let lookupExternMethod env eref (mn, _) = match !env.currentModule with 
   | None -> extNotFound eref mn
   | Some e -> lookupExtMethod e.externMethods eref mn 

(* get the super class of a type concrete. Returns itself if no super class *)
let getSuper env (sub: tTypeConcrete) : tType =
  let (subName, ks, args, _) = sub in
  (*let _ = pr "\n getSuper %s" (strTypeConcrete sub) in*)
  let subdecl = lookupCdeclByName env.cenv subName in
  match subdecl.extends with
    | Some supert -> 
      instantiateType subdecl ks args supert 
    | None -> TType_concrete sub
      (*let errmsg = spr "class %s has no super class" (strClassName subName) in
              raise (TargetCheckerErr errmsg) *)

(* find out if a class declaration declares an affine class *)
(* check if Affine is a superclass of cdecl *)
let getKind cdecl =
  match (cdecl.kind) with
    | Some k -> k
    | _ -> TKind_star

(* affine env: list of in-scope affine value variables *)
type tAenv = tVar<tType> list
let emptyAenv: tAenv = []

(* add an affine value variable *)
(* report error if var is already in env *)
let addAvar (aenv: tAenv) (var: tVar<tType>): tAenv =
  (* check if var exists in env *)
  if (List.exists (fun (avar: tVar<tType>) -> eqVvar avar var) aenv) then
    err (spr "addAvar: %s already exists" (fst var))
  else var::aenv

(* remove a var from aenv. Return the original aenv if var not found *)
let rec removeAvar (aenv:tAenv) var : tAenv = 
  match aenv with
    | [] -> []
    | (v::rest) -> if (eqVvar v var) then rest
                 else v::(removeAvar rest var)

(* union two affine envs, duplication disallowed *)
let rec unionAenv isNormalMode (aenv1:tAenv) (aenv2:tAenv) = 
    if isNormalMode then
      match aenv2 with
        | [] -> aenv1 
        | var::rest -> unionAenv isNormalMode (addAvar aenv1 var) rest
    else emptyAenv (* don't track affine values in erasure mode *)

(* union aenvs for branches, duplication allowed *)
let rec unionBranchAenvNormal aenv1 aenv2 =
  match aenv2 with
    | [] -> aenv1
    | var::rest -> if (List.exists (fun v -> eqVvar v var) aenv1) then
                     unionBranchAenvNormal aenv1 rest
                   else var :: (unionBranchAenvNormal aenv1 rest) 

let rec unionBranchAenv isNormalMode aenv1 aenv2 =
  if isNormalMode then unionBranchAenvNormal aenv1 aenv2
  else emptyAenv

let unionBranchAenvs isNormalMode aenvs =
  if isNormalMode then List.fold_left unionBranchAenvNormal emptyAenv aenvs
  else emptyAenv

(* test if aenv1 is a superset of aenv2 *)
let contains aenv1 aenv2 =
  let rec test aev2 =
    match aev2 with
      | [] -> true
      | (var::rest) -> (List.exists (fun avar -> eqVvar avar var) aenv1 &&
                        test rest)
  in test aenv2

(* add a variable to env and aenv if affine *)
let addVar (env:env) (aenv: tAenv) kind var : env * tAenv =
  let newenv = addVvar env var in
  let newAenv = 
    match kind with
      | TKind_affine -> addAvar aenv var
      | _ -> aenv in
  (newenv, newAenv)

(*==================== Utilities ===================*)
(* get equivalence class of a type variable or a value variable *)
(* TODO: should compute a fixpoint *)
let getEqclass (var:'a) (eq: 'a -> 'a -> bool) (eqs: ('a*'a) list) : 'a list =
  let rec aux eqs eqc =
    match eqs with
      | [] -> eqc
      | ((l,r)::rest) ->
        if (eq var l || eq var r) then aux rest (l::r::eqc)
        else aux rest eqc in
  aux eqs [var]

(* Unify t1 with t2 to add equivalences to env *)
let rec unifyType env t1 t2 : env = 
  (*let _  = pr "\n unifyType: %s vs %s" (strType t1) (strType t2) in *)
  if (t1 = t2) then env else
  match t1, t2 with
    | TType_var tvar, _ -> (*pr "\n   %s -> %s" (strTvar tvar) (strType t2);*) addTeq env tvar t2
    | _, TType_var tvar -> (*pr "\n   %s -> %s" (strTvar tvar) (strType t1);*) addTeq env tvar t1
    | TType_fun(bvd1, targ1, tbody1), TType_fun(bvd2, targ2, tbody2) -> 
      let env = unifyType env targ1 targ2 in
      (match bvd1, bvd2 with
         | Some var1, Some var2 ->
           let tmap = [VvarMap((snd var1, targ1), TVal_var(snd var2, targ2))] in
           unifyType env (substType tmap tbody1) tbody2
         | _ -> unifyType env tbody1 tbody2) 
    | TType_tfun(bvd1, k1, tbody1), TType_tfun(bvd2, k2, tbody2) ->
      if (eqKind env k1 k2) then
        let tvar1, tvar2 = (snd bvd1, k1), (snd bvd2, k2) in
        let tmap = [TvarMap(tvar1, TType_var tvar2)] in
        unifyType env (substType tmap tbody1) tbody2 
      else err (spr "unify: kind mismatch: %s vs. %s" (strType t1) (strType t2))
    | TType_dep(tfun1, v1), TType_dep(tfun2, v2) ->
      let env = unifyType env tfun1 tfun2 in unifyVal env v1 v2
    | TType_tapp(tfun1, targ1), TType_tapp(tfun2, targ2) ->
      let env = unifyType env tfun1 tfun2 in unifyType env targ1 targ2
    | TType_concrete tc1, TType_concrete tc2 -> unifyTconcrete env tc1 tc2
    | TType_affine t1, TType_affine t2
    | TType_refine(_, t1, _, _, _), TType_refine(_, t2, _,  _, _) ->
      unifyType env t1 t2 (* ignore formula *)
    | _ -> err (spr "unifyType: failed to unify %s and %s" 
                    (strType t1) (strType t2)) 

(* Unify v1 and v2 to add equivalences to env *)
and unifyVal env v1 v2 : env =
  (*let _ = pr "\n unifyVal: %s vs %s" (strVal v1) (strVal v2) in *)
  let v1, v2 = unwrapVal v1, unwrapVal v2 in
  if (v1 = v2) then env
  else match (v1, v2) with
    | TVal_var var, _ -> (*pr "\n   %s => %s" (strVvar var) (strVal v2);*) addEq env var v2
    | _, TVal_var var -> (*pr "\n   %s => %s" (strVvar var) (strVal v1);*) addEq env var v1
    | TVal_obj (tc1, vs1), TVal_obj(tc2, vs2) ->
      let env = unifyTconcrete env tc1 tc2 in
      List.fold_left (fun env (v1, v2) -> unifyVal env v1 v2) env (List.zip vs1 vs2)
    | TVal_ldfld(v1, f1), TVal_ldfld(v2, f2) ->
      if (f1 = f2) then unifyVal env v1 v2 
      else err (spr "unifyVal: failed to unify %s and %s" (strVal v1) (strVal v2))
    | TVal_logic_fun(fname1, vs1), TVal_logic_fun(fname2, vs2) ->
      if (fname1 = fname2) then List.fold_left (fun env (v1, v2) -> unifyVal env v1 v2) env (List.zip vs1 vs2)
      else err (spr "unifyVal: failed to unify %s and %s" (strVal v1) (strVal v2))
    | _ -> err (spr "unifyVal: failed to unify %s and %s" (strVal v1) (strVal v2))

and unifyArg env args =
  let (arg1, arg2) = args in
  match arg1, arg2 with
    | Targ t1, Targ t2 -> unifyType env t1 t2
    | Varg v1, Varg v2 -> unifyVal env v1 v2
    | _ -> env

and unifyTconcrete env tc1 tc2 =
  let (cname1, ks1, args1, _), (cname2, ks2, args2, _) = tc1, tc2 in
  if (cname1 = cname2 && ks1 = ks2) then  (* require kinds to be the same *)
    List.fold_left unifyArg env (List.zip args1 args2)
  else  err (spr "unifyTconcrete: failed to unify %s and %s" 
                 (strTypeConcrete tc1) (strTypeConcrete tc2))

(* check if two types are equivalent *)
and isEqType env t1 t2 = "dcil eqtype" ^^ lazy
  (*let _ = pr "\n isEqType : %s ,\n!! %s" (strType t1) (strType t2) in*)
  let _ = 
    if ((strType t1).StartsWith("Env.ex")) then
    pr ""
    else () in
  if (t1 = t2) then true
  else  
    let type1 = normalize t1 in
    let type2 = normalize t2 in
    (*let  _ = pr "\n isEqType, after normalization : %s ,\n!! %s" (strType type1) (strType type2) in*)
    if (type1 = type2) then true else
    let isInEqclass tvar t = (* check if t in tvar's equivalence class *)
      let eqt tl tr = tl = tr (* TODO: expand this to structural type equivalence *) in
      let eqc = getEqclass (TType_var tvar) eqt (getAllTeqs env) in
      (*let _ = if ((strTvar tvar).StartsWith("gensym_107")) then 
        (List.map (fun t -> pr "\n!! = %s" (strType t)) eqc; ()) in*)
      let rec test ts =
         (match ts with
           | [] -> false
           | (TType_var var')::rest -> 
             (match t with TType_var var'' -> eqTvar var' var'' | _ -> false) || test rest
           | ti::rest -> (isEqType env ti t) || test rest) in
      let result = test eqc in
      if (result) then useTeq := true; result in
    match (type1, type2) with
    | (TType_var tvar, _) -> isInEqclass tvar type2
    | (_, TType_var tvar) -> isInEqclass tvar type1
    | (TType_fun(bvd1, targ1, tbody1), TType_fun(bvd2, targ2, tbody2)) -> 
      if (isEqType env targ1 targ2)
      then (match (bvd1, bvd2) with
        | (Some var1, Some var2) ->
          let tmap = [VvarMap((snd var1, targ1), TVal_var(snd var2, targ2))] in
          isEqType env (substType tmap tbody1) tbody2
        | _ -> isEqType env tbody1 tbody2)
      else false
    | (TType_tfun(bvd1, kind1, tbody1), TType_tfun(bvd2, kind2, tbody2)) ->
      (* alpha equivalence of type functions *)
      if (eqKind env kind1 kind2) then
        let tvar1, tvar2 = (snd bvd1, kind1), (snd bvd2, kind2) in
        let tmap = [TvarMap(tvar1, TType_var tvar2)] in
        isEqType env (substType tmap tbody1) tbody2
      else false
    | (TType_concrete tconcrete1, TType_concrete tconcrete2) ->
      isEqTypeConcrete env tconcrete1 tconcrete2
    | (TType_dep(tfun1, v1), TType_dep(tfun2, v2)) ->
      isEqType env tfun1 tfun2 && isEqVal env v1 v2
    | (TType_tapp(tfun1, targ1), TType_tapp(tfun2, targ2)) ->
      isEqType env tfun1 tfun2 && isEqType env targ1 targ2
    | (TType_affine t1, TType_affine t2) -> isEqType env t1 t2
    | (TType_name(cname1, eref1), TType_concrete(cname2, [], [], eref2)) -> (fst cname1) = cname2 && (eref1=eref2)
    | (TType_concrete(cname1, [], [], eref1), TType_name(cname2, eref2)) -> cname1=(fst cname2) && (eref1=eref2)
    | TType_refine(bvd1, t1, f1, _, _), TType_refine(bvd2, t2, f2, _, _) ->
      if (isEqType env t1 t2) then
        (* t1 == t2 && f1[bvd2/bvd1] == f2 *)
        let tmap = addVvarMap emptyTyMap (snd bvd1, t1) (TVal_var (snd bvd2, t2)) in
        isEqType env (substType tmap f1) f2
      else false
    | _ -> type1 = type2

and eqKind env kind1 kind2 = 
  if (kind1 = kind2) then true
  else match kind1, kind2 with
    | TKind_arrow(t1, k1), TKind_arrow(t2, k2) ->
      isEqType env t1 t2 && eqKind env k1 k2
    | TKind_karrow(kfun1, karg1), TKind_karrow(kfun2, karg2) ->
      eqKind env kfun1 kfun2 && eqKind env karg1 karg2
    | _ -> false

and subKind env kind1 kind2 =
  if kind1 = kind2 then true
  else match kind1, kind2 with
    | TKind_prop, TKind_erasable
    | TKind_affine, TKind_erasable 
    | TKind_star, TKind_erasable -> true
    | TKind_arrow(t1, k1), TKind_arrow(t2, k2) ->
      isSubtype env t2 t1 && subKind env k1 k2
    | TKind_karrow(k1, k1'), TKind_karrow(k2, k2') ->
      subKind env k2 k1 && subKind env k1' k2'
    | _ -> false

(* check if two values are equivalent *)
(* v1: I == v2: I if I has no fields *)
and isEqVal (env: env) v1 v2 = "dcil eqval" ^^ lazy
  let v1, v2 = unwrapVal v1, unwrapVal v2 in
  if (v1 = v2) then true
  else
    match (v1, v2) with
      | (TVal_var var1, TVal_var var2) -> 
        isEqVvar env var1 var2 || (!Options.rdcil_z3eq  && (ProofDCIL.prove_eq env v1 v2))
      | (TVal_var var, _) -> isEq env var v2 || (!Options.rdcil_z3eq && (ProofDCIL.prove_eq env v1 v2))
      | (_, TVal_var var) -> isEq env var v1 || (!Options.rdcil_z3eq && (ProofDCIL.prove_eq env v1 v2))
      | (TVal_obj(t1, vs1), TVal_obj(t2, vs2)) ->
        if (isEqTypeConcrete env t1 t2) then
          let rec matchvs vls1 vls2 =
            match (vls1, vls2) with
              | ([], []) -> true
              | (v1::rest1, v2::rest2) ->
                isEqVal env v1 v2 && matchvs rest1 rest2
              | _ -> false in
          matchvs vs1 vs2
        else false
      | (TVal_constant cons1, TVal_constant cons2) -> isEqCons env cons1 cons2
      | (TVal_ldfld(v1, f1), TVal_ldfld(v2, f2)) -> isEqVal env v1 v2 && (f1 = f2)
      | TVal_logic_fun(fname1, vs1), TVal_logic_fun(fname2, vs2) ->
        fname1 = fname2 && (List.forall2 (isEqVal env) vs1 vs2)
      | _ -> false 

and isEq (env:env) var vl = 
  let rec comp tenv =
    match tenv with
      | [] -> false
      | (x, v) :: rest ->
        let eqObj val1 val2 = 
          match (val1, val2) with
            | (TVal_obj _, TVal_obj _) -> isEqVal env val1 val2
            | _ -> val1 = val2 in          
        if (isEqVvar env var x && eqObj vl v) then true else comp rest
  in (*pr "\n isEq: %s, %s" (strVvar var) (strVal vl);
     List.map (fun (v, binding) -> pr "\n    %s == %s" (strVvar v) (strVal binding)) tenv; *)
  comp env.tenv

and isEqCons env cons1 cons2 =
  match (cons1, cons2) with
    | (Sugar.Const_decimal d1, Sugar.Const_decimal d2) -> d1.Equals(d2)
    | (Sugar.Const_bigint i1, Sugar.Const_bigint i2) -> isEqByteArray i1 i2
    | (Sugar.Const_bignum n1, Sugar.Const_bignum n2) -> isEqByteArray n1 n2
    | (Sugar.Const_string(a1, _), Sugar.Const_string(a2, _)) -> isEqByteArray a1 a2
    | (Sugar.Const_bytearray(a1, _), Sugar.Const_bytearray(a2, _)) -> isEqByteArray a1 a2
    | (Sugar.Const_uint16array a1, Sugar.Const_uint16array a2) -> isEqUint16Array a1 a2
    | _ -> false

and isEqByteArray a1 a2 = 
 (Bytes.compare a1 a2 = 0)

and isEqUint16Array a1 a2 = a1.Equals(a2)

(* check if two type concrete are equivalent *)
and isEqTypeConcrete env (cname1, ks1, args1,eref1) (cname2, ks2, args2, eref2) =
  (*let _ = if (!fdebug) then (pr "\n !!!!!isEqTypeConcrete: args1 = ";
               print_any args1;
               pr "\n    args2 ="; print_any args2;) in *)
  let rec isEqKinds ks1 ks2 =
    match (ks1, ks2) with
      | ([], []) -> true
      | (k1::rest1, k2::rest2) ->
        (eqKind env  k1 k2) && (isEqKinds rest1 rest2)
      | _ -> false in
  let rec isEqArgs args1 args2 =
    match args1, args2 with
      | ([], []) -> true
      | (Targ t1)::rest1, (Targ t2)::rest2 -> (isEqType env t1 t2) && (isEqArgs rest1 rest2)
      | (Varg v1)::rest1, (Varg v2)::rest2 -> (isEqVal env v1 v2) && (isEqArgs rest1 rest2)
      | _ -> false in
  (eref1=eref2) && (cname1 = cname2) (*&& (isEqKinds ks1 ks2)*) && (isEqArgs args1 args2) 

(* return if type1 is a subtype of type2 TODO *)
and isSubtype env (type1:tType) (type2:tType) = 
  if (isEqType env type1 type2) then true
  else if (type1 = botType) then true
  else
    let type1 = normalize type1 in
    let type2 = normalize type2 in
    match (type1, type2) with
    | (TType_fun(bvd1, targ1, tbody1), TType_fun(bvd2, targ2, tbody2)) ->
      (match (bvd1, bvd2) with
        | (None, None) ->
          (isSubtype env targ2 targ1) &&
          (isSubtype env tbody1 tbody2)
        | (Some var1, Some var2) ->
          if (isSubtype env targ2 targ1) then
            let tmap = [VvarMap((snd var1, targ1), TVal_var(snd var2, targ2))] in
            isSubtype env (substType tmap tbody1) tbody2
          else false
        | _ -> false)
    | (TType_affine t1, TType_affine t2) -> isSubtype env t1 t2
    | t1, TType_refine (bvd, t2, formula, _, insts) -> 
        if isSubtype env t1 t2 then 
            let env = addVvar env (snd bvd, t1) in
            (*pr "\nREFINEMENT FORMULAS IN DCIL CHECKER: %s <: %s!!!" (strType type1) (strType type2); *)
            ProofDCIL.prove_dcil_formula env formula insts
        else false
    | TType_refine(bvd, t1, formula, _, _), t2 -> isSubtype env t1 t2
    | TType_concrete(name1, _, args1, _), TType_concrete(name2, _, args2, _) when isDepArrowName name1 && isDepArrowName name2 ->
      (* function subtype*)
      (match getTys args1, getTys args2 with
         | [_; tfun1], [_; tfun2] -> isSubtype env tfun1 tfun2
         | _ -> false)
    | _ -> isEqType env type1 type2


and checkTypeInst env tmap (tvar, t) =
  let kind_t = kinding env t in
  let kind_var = substKind tmap (snd tvar) in
  if (subKind env kind_t kind_var) then addTvarMap tmap tvar t
  else
    err (spr "\ncheckTypeInst: expect %s \n  with kind %s, \nbut got %s \n  with kind %s"
      (strTvar tvar) (strKind kind_var) (strType t) (strKind kind_t)) 

(* check type/value instantiations *)
and checkInstantiation env (cdecl : tClassDecl) ks args =
  let checkValInst tmap (vvar, v) = 
    let (ty_v, _) = vTyping env v in 
    let ty_var = substType tmap (snd vvar) in
    let _ = checkValAgainstType env v ty_var in
    addVvarMap tmap vvar v 
  in
  (* Printf.printf "Kvars: %A\n%A\n" cdecl.kvars ks;
  Printf.printf "Tvars: %A\n%A\n" (cdecl.ptvars @ cdecl.tvars) ts;
  Printf.printf "vvars: %A\n%A\n" (cdecl.vvars) vs; *)
  let tmap = List.map KvarMap (List.zip cdecl.kvars ks) in 
  List.fold_left (fun tmap vararg -> match vararg with 
                                       | (Tvar tvar, Targ t) -> checkTypeInst env tmap (tvar, t)
                                       | (Vvar vvar, Varg v) -> checkValInst tmap (vvar, v)
                                       | _ -> err "checkInstantiation: unmatched vars and args")
                 tmap (List.zip (cdecl.vars) args)

(*============================== kinding ==========================*)
(* compute the kind of a type *)
and kinding (env:env) (t: tType) : tKind = 
  match t with
    | TType_var tv -> 
      (* type variable: it must exist in the kenv *)
      if (containsTvar env tv) then snd tv
      else let errmsg = spr "kinding: free tvar %s" (strType t) in
        err errmsg
    | TType_name (name, _) -> (snd name) (* TODO: check names *)
    | TType_fun (bvdopt, t1, t2) -> 
      (* [\x:]t1 -> t2 *)
      let k1 = kinding env t1 in
      let newenv = (match bvdopt with
                     | None -> env
                     | Some bvdef -> addVvar env (snd bvdef, t1)) in
      let k2 = kinding newenv t2 in
      let knd = TKind_arrow(t1, k2) in
      let _ = checkKind env knd in
      knd
    | TType_concrete tconcrete -> kindingTConcrete env tconcrete
    | TType_dep (tfun, v) -> 
      (match (kinding env tfun) with
        | TKind_arrow(t, knd) ->
          let (tyOfv, aenv_v) = vTyping (changeToErasureMode env) v in
          if (isSubtype env tyOfv t) then knd
          else err (spr "kinding: type mismatch: require %s given %s" (strType t) (strType tyOfv))
        | _ -> err (spr "kinding: invalid tfun in %s" (strType tfun)))
    | TType_affine ty ->
      (match (kinding env ty) with
        | TKind_star -> TKind_affine
        | _ -> err (spr "kinding: invalid affine %s" (strType t)))
    | TType_tfun (bvd, kind, body) -> 
      let tvar = (snd bvd, kind) in
      let env = if (containsTvar env tvar) then env  (* TODO: why are there duplicated tvars *)
                  else addTvar env tvar in
      TKind_karrow(kind, kinding env body)
    | TType_tapp (tfun, targ) -> 
        (match (kinding env tfun) with
         | TKind_karrow (k1, k2) ->
           let karg = kinding env targ in
           if subKind env k1 karg then k2
           else err (spr "kinding: kind mismatch: need %s but given %s" (strKind k1) (strKind karg))
         | _ -> err (spr "kinding: unexpected kind for %s in %s" (strType tfun) (strType t)))
    | TType_refine (bvd, t, formula, _, insts) ->
        let tk1 = kinding env t in
        let env = addVvar env (snd bvd, t) in 
        let tk2 = kinding env formula in 
        if (subKind env tk2 TKind_erasable) then tk1
        else err (spr "kinding: unexpected kinds for refinements: %s : %s, %s: %s"
                        (strType t) (strKind tk1) (strType formula) (strKind tk2))
    | TType_inferred _ -> TKind_star
    | _ -> err (spr "kinding: unexpected type %s" (strType t))

(* kinding of a concrete type  *)
and kindingTConcrete (env:env) (tc: tTypeConcrete) : tKind = 
  let Err msg = err (spr "kindingTConcrete: unexpected %s--%s" (strTypeConcrete tc) msg) in
  let (classname, ks, args, _) = tc in
  let tys, vls = getTys args, getVals args in
  (* let _ = Printf.printf "\nkindingTConcrete: %s" (PrettyTarget.strTypeConcrete tc) in *)
  let checkDepKinds ks tys =
    let isConcreteKind k =
      k = TKind_star or k = TKind_prop or k = TKind_affine or k = TKind_erasable in
    match ks, tys with
      | [k1; k2], [t1; t2] -> (* check t1::k1 && t2::t1->k2 *)
        if (isConcreteKind k1 && isConcreteKind k2 && subKind env (kinding env t1) k1) then
          (match kinding env t2 with
             | TKind_arrow(t1', k2') ->
               if (isEqType env t1' t1 && subKind env k2' k2) then k1, k2, t1, t2
               else Err "invalid dep kinds/types"
             | _ -> Err "expect an arrow kind")
        else Err "invalid kinds" 
      | _, _ -> Err "unexpected numbers of kinds or types" in

  if isArrowOrTupleName classname then
    let k1, k2, t1, t2 = checkDepKinds ks tys in
    if isDepArrowName classname then 
      if k2 = TKind_prop then k2 else TKind_star
    else let _ = if isDconDepTupleName classname then
                 match vls with
                   | [v1; v2] -> (* check v1:t1, v2: t2 v1 *)
                     let (vty1, _), (vty2, _) = vTyping env v1, vTyping env v2 in
                     if isEqType env vty1 t1 &&
                        isEqType env vty2 (TType_dep(t2, v1)) then ()
                     else Err "unmatched value types"
                   | _ -> Err "unexpected numbers of values" in
         if k1 = TKind_affine || k2 = TKind_affine then TKind_affine
         else match t2 with  
           (* hack hack: formula exists x. p is translated to deptuples now *)
           (* This hack will be removed once we use the Exists proof constr.*)
                | TType_fun(_, _, TType_concrete(tname, _, _, _)) ->
                  if isPf tname then TKind_prop
                  else TKind_star
                | _ -> TKind_star
  else (* normal type concretes *)
  let cdecl = lookupCdeclByName env.cenv classname in
  (* first check if the type arguments have the appropriate kinds *)
  (* let _ = Printf.printf "\n cdecl: %s" (PrettyTarget.strClassDecl cdecl) in 
  let _ = Printf.printf "\n tc : %s" (PrettyTarget.strTypeConcrete tc) in *)
  let tmap = List.map KvarMap (List.zip cdecl.kvars ks) in
  let rec checkArgs tmap vars args =
    match vars, args with
      | [], [] -> tmap
      | (Tvar tvar)::restvars, (Targ ty)::restargs ->
        let kind_ty = kinding env ty in
        let substKind_tvar = substKind tmap (snd tvar) in
        if (subKind env kind_ty substKind_tvar) then
          let newtmap = addTvarMap tmap tvar ty in
          checkArgs newtmap restvars restargs
        else err (spr "kindingTconcrete: %s has kind %s but expects %s" (strType ty) (strKind kind_ty) (strKind substKind_tvar))
      | (Vvar vvar)::restvars, (Varg v)::restargs ->
        let substTy_vvar = substType tmap (snd vvar) in
        let _ = checkValAgainstType env v substTy_vvar in
        let newtmap = addVvarMap tmap vvar v in
        checkArgs newtmap restvars restargs 
      | _ -> err "kindingTconcrete: unmatched vars and args" in
   let tmap = checkArgs tmap (cdecl.vars) args in
   let kind_tc = getKind cdecl in
   (*let _ = Printf.printf "finished checking %s\n" (PrettyTarget.strTypeConcrete tc) in*)
   substKind tmap kind_tc 

(* compute the type of a value and return affine variables used in the value*)
and vTyping (env:env) (v: tValue) : (tType * tAenv) = 
  (* DebugLog.Log(spr "\n vtyping: %s" (strVal v)); *)
  match v with
    | TVal_var var -> 
      let vtype = lookupVvarType env var in
      (* DebugLog.Log(spr "\n got var type %s" (strType vtype)); *)
      (match (kinding env vtype) with
         | TKind_affine -> (vtype, addAvar emptyAenv var)
         | _ -> (vtype, emptyAenv))
    | TVal_obj (tconcrete, vs) ->
        objectTyping env tconcrete vs 
    | TVal_constant cons -> (constTyping cons, emptyAenv)
    | TVal_ldfld(vobj, fieldRef) -> checkLdfld env vobj fieldRef 
    | TVal_uvar uvar ->
      (match Unionfind.find uvar with
         | TUval vl -> vTyping env vl
         | TUcast(t, vl) -> 
           let aenv = checkValAgainstType env vl t in
           (t, aenv))
    | TVal_logic_fun (fname, vs) ->
      let rec computeType aenv tarrow vs =
        match vs with
          | [] -> tarrow, aenv
          | v1::rest -> (match tarrow with
                          | TType_concrete(["DepArrow"], ks, [Targ t1; Targ t2], _)  -> 
                            let aenv' = checkValAgainstType env v1 t1 in
                            computeType (unionAenv true aenv aenv') (normalize(TType_dep(t2, v1))) rest
                          | _ -> err (spr "vTyping: unexpected type %s" (strType tarrow))) in
      computeType emptyAenv (snd fname) vs
(* check loading a field from an object *)
and checkLdfld env vobj fieldRef =
  let (tobject, newaenv) = vTyping env vobj in
  let check tconcrete =
    let (cname, ks, args, _) = tconcrete in
    if ((isDepTupleName cname) &&
       ((fieldRef = Const.dcil_proj_one_name) ||
        (fieldRef = Const.dcil_proj_two_name))) then
      (* project the first or second of a non-dependent tuple *)
      match args with
        | [Targ t1; Targ (TType_fun(_, _, t2))] -> 
          if (fieldRef = Const.dcil_proj_one_name) then (t1, newaenv)
          else (t2, newaenv)
        | _ -> err (spr "checkLdfld: unexpected targs for DepTuple2SS %s" 
                        (strType tobject))
    else let (fieldname, fieldtype) = lookupField env tconcrete fieldRef in
      (fieldtype, newaenv) in
  let rec removeRefinement t =
    match t with
      | TType_refine(_, tt, _, _, _) -> removeRefinement tt
      | _ -> t in
  match (removeRefinement tobject) with
    | TType_concrete tconcrete -> check tconcrete
    (* allow cname as tconcrete (cname, [], []), for external records *)
    | TType_name (cname, eref) -> check (fst cname, [], [], eref)   
    | _ -> err (spr "checkLdfld: unexpected obj type %s" (strType tobject))

(* check the type of an object. vls are the field values *)
and objectTyping env tconcrete vls =
(* pr "\nobjectTyping %s" (PrettyTarget.strTypeConcrete tconcrete); *)
 let (cname, ks, args, _) = tconcrete in
 let cdecl = lookupCdeclByName env.cenv cname in
 let tyMap = checkInstantiation env cdecl ks args in
 (* check constrains *)
 let rec checkObjEvidences evs =
   match evs with
     | [] -> ()
     | (TEv_type(tvar, t))::rest ->
       let newt1 = substTvar tyMap tvar in
       let newt2 = substType tyMap t in
       if (isEqType env newt1 newt2) then checkObjEvidences rest
       else err (spr "checkObjEvidences: unsatisfied %s (%s) = %s (%s)"
                     (strTvar tvar) (strType newt1) (strType t) (strType newt2))
     | (TEv_val(var, v))::rest ->
       let newv1 = substVvar tyMap var in
       let newv2 = substVal tyMap v in
       if (isEqVal env newv1 newv2)
       then checkObjEvidences rest
       else err (spr "objectTyping: check evidence %s = %s but got %s <> %s"
                     (strVvar var) (strVal v) (strVal newv1) (strVal newv2)) in
 let _ = checkObjEvidences cdecl.evidences in
 (* check fields *)
 let fields = List.map (fun f -> (fst f, substType tyMap (snd f))) cdecl.fields in
 let rec checkFields aev fs vs =
   match (fs, vs) with
     | ([], []) -> aev
     | (f::restfs, v::restvs) ->
       let fty = snd f in
       let (vty, aev_v) = vTyping env v in
       if (isSubtype env vty fty) 
       then checkFields (unionAenv true aev aev_v) restfs restvs
       else let errmsg = spr "objectTyping: tconcrete = %s, field has type %s but expects %s"
                             (strTypeConcrete tconcrete) (strType vty) (strType fty) in
            err errmsg
     | _ ->
      err (spr "objectTyping: mismatched types and values for class %A\nfs: %A\nvs: %A\n" cdecl.name fs vs) in
 let aenv = checkFields emptyAenv fields vls in
 (* get super *)
 match cdecl.extends with
   | Some super -> (substType tyMap super, aenv)
   | _ -> (TType_concrete tconcrete, aenv)

(* compute the type of a constant *)
(* currently support unit, bool, int32, and string only *)
and constTyping cons = 
  match cons with
    | Sugar.Const_unit -> unitType
    | Sugar.Const_bool _ -> boolType
    | Sugar.Const_int32 _ -> intType
    | Sugar.Const_string _ -> stringType
    | Sugar.Const_bytearray _ -> bytesType
    | _ ->
      let errmsg = spr "constTyping: unsupported const %s"
                   (cons.ToString()) in
      err errmsg
    (*| Sugar.Const_int8 _ ->
    | Sugar.Const_uint8 _ ->
    | Sugar.Const_int16 _->
    | Sugar.Const_uint16 _ ->
    | Sugar.Const_uint32 _ ->
    | Sugar.Const_int64 _ ->
    | Sugar.Const_uint64 _ ->
    | Sugar.Const_nativeint _ ->
    | Sugar.Const_unativeint _ ->
    | Sugar.Const_float32 _ ->
    | Sugar.Const_float _ ->
    | Sugar.Const_char _ ->
    | Sugar.Const_decimal _ ->
    | Sugar.Const_bigint _ ->
    | Sugar.Const_bignum _ ->
    | Sugar.Const_bytearray _ ->
    | Sugar.Const_uint16array _ -> *)

(* check if a kind is well-formed *)

and checkKind (env:env) (k: tKind) : tKind = 
  match k with
    | TKind_star 
    | TKind_affine
    | TKind_prop 
    | TKind_erasable -> k
    | TKind_var kvar ->
      if (foundKvar env kvar) then k (* ?? *)
      else err (spr "checkKind: %s not found" (fst kvar))
    | TKind_arrow (t, knd) ->
      let _ = kinding env t in
      checkKind env knd
    | TKind_karrow(k1, k2) ->
      let _ = checkKind env k1 in
      checkKind env k2
    | _ -> err (spr "checkKind: unexpected kind %s" (strKind k))

(*============================= typing ===========================*)
(* compute the type of an expression and update environments *)
(* Also return the free affine values used in e. *)
(* report error if there are duplicated affine values *)
and eTyping (env: env) (e: tExp) : (tType * tAenv) =
  let erre msg = 
    err (spr "eTyping: %s has error: %s" (strExp e) msg) in
  (* check method call arguments, return substituted return type and free affine vars used in args *)
  let rec checkArgs tymap params args retTy: tType * tAenv =
    let rec aux (aev: tAenv) tymap params args =
      (match (params, args) with
         | ([], []) -> 
           ((* DebugLog.Log(spr "\n: return type = %s, \n subst = %s"
            (strType retTy) (strType (substType tymap retTy))); *)
            (normalize(substType tymap retTy), aev))
         | (param::restps, arg::restas) ->
           let substParamTy = substType tymap (snd param) in
             let newaev = checkValAgainstType env arg substParamTy in
             let aev = unionAenv (isNormalMode env) aev newaev in
             let tymap = (match fst param with
                | Some id -> addVvarMap tymap (id, snd param) arg 
                | _ -> tymap) in
              aux aev tymap restps restas
          | _ -> erre (spr "mismatched params and args: params: %A\n args:%A\n" params args)) in
  aux emptyAenv tymap params args in
  (* DebugLog.Log (spr "\n eTyping %s" (strExp e)); *)
  match e with
    | TExp_val v -> vTyping env v
    | TExp_name(name, _) -> (snd name, emptyAenv) (* TODO: check names *)
    | TExp_ldfld (vobj, fieldRef) -> checkLdfld env vobj fieldRef
    | TExp_call (vobj, ags, methodRef) -> 
      let (tobj, aenv_obj) = vTyping env vobj in
      (match tobj with
        | TType_affine (TType_concrete tconcrete)
        | TType_concrete tconcrete ->
          let (cname, ks, args, _) = tconcrete in
          (* DebugLog.Log (spr "\n Call: %s" (String.concat " " (List.map (fun (v, binding) -> spr "\n    %s -> %s" 
                       (strVvar v) (strVal binding)) tenv))); *)
          let cdecl = lookupCdeclByName env.cenv cname in
          let (retTy, mname, tvars, ps, _) =
            List.find (fun (_, name, _, _, _) -> (name = fst methodRef)) cdecl.methods in
          let tmap = buildTyMap cdecl ks args in
          let tmap = List.fold_left (checkTypeInst env) tmap (List.zip tvars (snd methodRef)) in
          checkArgs tmap (List.map (fun(id, t) -> (Some id, t)) ps) ags retTy
        | _ -> erre (spr "%s has type %s, not a TType_concrete"
                     (strVal vobj) (strType tobj)))
    | TExp_extern_call (extref, mref, vals) ->
      (* check external calls: *)
      (* ptypes are the parameter types and rtype is the return type *)
      let ptypes, rtype = lookupExternMethod env extref mref in
      let tymap = [TindexMap(snd mref)] in
      checkArgs tymap (List.map (fun t -> (None, t)) ptypes) vals rtype
    | TExp_let (var, e1, e2, hasType) ->
      (* DebugLog.Log(spr "\n let %s: %s <- %s" (strVvar var) (strType (snd var)) (strType type1)); *)
      (*let (type1, aenv1) = eTyping env e1 in
      
      if true (* (isSubtype cenv tenv type1 (snd var)) *) then  
        let var, e2 = 
          (match (snd var) with
            | TType_inferred uvar ->  (* var's type can be inferred. create a new variable with type1 and substitute for var *)
              let _ = (match (Unionfind.find uvar) with
                         | TUvar -> Unionfind.change uvar (TFixed type1)
                         | _ -> ()) in
              let newvar = newVvar type1 in
              let tmap = addVvarMap emptyTyMap var (TVal_var newvar) in
              (newvar, substExp tmap e2)
            | _ -> (* set hasType to false if var's type = type1 *)
                (if (!hasType && isEqType env (snd var) type1) then 
                   (hasType := false; 
                    (*pr "Omitting type %s for var %s\n" (strType type1) (strVvar var)*))); 
                (var, e2)) in
        let newenv =
          let rec aux e =
            match e with
              | TExp_val vl -> let vl = unwrapVal vl in
                               (match vl with
                                  | TVal_var var1 -> addEqVvar env var var1
                                  | _ -> addEq env var vl)
              | TExp_name (name, _) -> addEq env var (name2Value name)
              | TExp_ascribed(e', _) -> aux e'
              | _ ->  addVvar env var in
           aux e1 in *)
        let newenv, aenv1, var, e2 = checkLetExp1 env var e1 e2 hasType in
        let (type2, aenv2) = eTyping newenv e2 in
        (type2, unionAenv (isNormalMode env) aenv1 (removeAvar aenv2 var))
      (*else err (spr "\n mismatch exp type %s with var type %s" (strType type1) (strType (snd var)))*)
    | TExp_isinst (v, tconcrete_es, edefault, finalTy) ->
      let (vty, aenv_v) = vTyping env v in
      (*let _ = pr "\n finalyTy in isinst = %s" (strType finalTy) in*)
      let _ = kinding env finalTy in  (* check well-formedness of the final type *)
      let v = unwrapVal v in
      (*let _ = pr "\n checking isinst: v = %s" (PrettyTarget.strVal v) in*)
      (* check one branch (cname, ks, ts, vars) -> e*)
      let checkBranch (cname, ks, pats, isGADT, e) =
        (* check well-formedness of ts !!*)
        let ts, vars, fields = getTysFromPats pats, getVarsFromPats pats, getFieldsFromPats pats in
        let tconc = (cname, ks, (List.map Targ ts) @ (List.map (fun var -> Varg(TVal_var var)) vars), None) in
        let env_v = 
          match v with
            | TVal_var var ->
              (* add var = TVal_obj((cname, ks, ts, List.map TVal_var vars, None), []) to env *)
              (*let _ = pr "\n isinst: adding %s == %s" 
                           (strVvar var) 
                           (strVal (TVal_obj(tconc, []))) in *)
              addEq env var (TVal_obj(tconc, []))
            | TVal_uvar uvar ->
              (match Unionfind.find uvar with
                | TUval (TVal_var var) ->
              (*let _ = pr "\n isinst: adding cast %s == %s" 
                           (strVvar var) 
                           (strVal (TVal_obj(tconc, []))) in *)
                 addEq env var (TVal_obj(tconc,[]))
                | _ -> (Util.warn "\n isinst: TUcast %s\n" (PrettyTarget.strVal v); env))
            | _ -> (Util.warn ("\n isinst exp on non-var s\n"); env) in
        let super = getSuper env tconc in
        let env_v = if isGADT then (* add type variables to the environments *)
            unifyType (List.fold_left (fun env t ->
                              match t with
                                | TType_var tvar -> addTvar env tvar                      
                                | _ -> env) env_v ts) super vty 
          else match super, vty with (* unify only values *)
            | TType_concrete(cname1, _, args1, _), TType_concrete(cname2, _, args2, _) ->
              (if cname1 = cname2 then
                 List.fold_left (fun env (arg1, arg2) -> match arg1, arg2 with 
                                                           | Varg v1, Varg v2 -> unifyVal env v1 v2 
                                                           | _ -> env) env_v (List.zip args1 args2)
               else err (spr "checkBranch: mismatched %s and %s" (strType super) (strType vty)))
            | _ -> env_v in
        (* add newly introduced variables to the environments *)
        let rec addVars tev vars =
          match vars with
            | [] -> tev
            | var::rest ->
              let newtev = if isInTenv tev var then tev
                           else addVvar tev var in
              addVars newtev rest in
        let newenv = addVars env_v (vars@fields) in
        let rec removeAvars aev vars =
          match vars with
            | [] -> aev
            | var::rest -> removeAvars (removeAvar aev var) rest in
        let aenv = match e with
          | TExp_val vl -> checkValAgainstType newenv vl finalTy
          | _ -> checkExpAgainstType newenv e finalTy in
        (removeAvars aenv vars) in
      let aenvs = List.map checkBranch tconcrete_es in 
      (* check the default branch *)
      let aenv_default = checkExpAgainstType env edefault finalTy in
      let aenvs = unionBranchAenvs (isNormalMode env) (aenv_default :: aenvs) in
      let newaenv = unionAenv (isNormalMode env) aenvs aenv_v in
      (finalTy, newaenv)
    | TExp_cond (eb, et, ef) ->
      let (tyb, aenv) = eTyping env eb in
      if (isSubtype env tyb boolType) then
        match eb with
          | TExp_ascribed(TExp_val vl, _)
          | TExp_val vl ->
            (match unwrapVal(vl) with
               TVal_var var ->
            let (type1, aenv1) = eTyping (addEq env var trueVal) et in
            let (type2, aenv2) = eTyping (addEq env var falseVal) ef in
            let isNmode = isNormalMode env in
            let newaenv = unionAenv isNmode (unionBranchAenv isNmode aenv1 aenv2) aenv in
            (if (isSubtype env type1 type2) then (type2,newaenv) 
             else if (isSubtype env type2 type1) then (type1,newaenv)
            else erre (spr "true branch has type %s and false has %s" 
                      (strType type1) (strType type2)))
            | _ -> erre (strExp eb))
          
          | _ -> erre (spr "%s not a var" (strExp eb))
      else erre (spr "%s not a bool" (strExp eb))
    | TExp_primop (bop, el) -> 
        let aenv, et_l_rev = 
          List.fold_left (fun (aenv, et_l) e -> 
                            let t_e, aenv = vTyping env e in
                              (aenv,  (e,t_e)::et_l)) (emptyAenv, []) el in
        let et_l = List.rev et_l_rev in
        let eqTrueFalse x trueFalseV = TType_concrete(["Prims"; "Eq"], [], [Varg x; Varg trueFalseV], None) in
        let andOrEq id trueFalse e1 andOr e2 = (* id = trueFalse => e1 = trueFalse andor e2 = trueFalse*)
          TType_concrete(["Prims"; "l_implies"], [],
                         [Targ (eqTrueFalse (TVal_var(id, boolType)) trueFalse);  (* id = trueFalse *)
                          Targ (TType_concrete(["Prims"; andOr], (* e1 = trueFalse andor e2 = trueFalse *)
                                               [],
                                               [Targ (eqTrueFalse e1 trueFalse); Targ (eqTrueFalse e2 trueFalse)],
                                               None))],
                          None) in 
          (match et_l with 
               [(e1,t1); (e2,t2)] -> 
                 (match bop with
                    | AND ->
                       if (isSubtype env t1 boolType && 
                           isSubtype env t2 boolType) then
                         (* x:bool{x = true => e1 = true && e2 = true} *)
                         let id = newSym() in
                         let bvd = (id, id) in
                         let f = andOrEq id trueVal e1 "l_and" e2 in
                         (TType_refine(bvd, boolType, f, "", []), aenv)
                       else erre (spr "%s or %s not a bool" (strVal e1) (strVal e2))
                    | OR -> 
                        if (isSubtype env t1 boolType && 
                            isSubtype env t2 boolType) then 
                          (* x:bool{(x = true => e1 = true || e2 = true) &&
                                    (x = false => e1 = false && e2 = false)} *)
                           let id = newSym() in
                           let bvd = (id, id) in
                           let f = TType_concrete(["Prims"; "l_and"], [],
                                                  [Targ(andOrEq id trueVal e1 "l_or" e2);
                                                   Targ(andOrEq id falseVal e1 "l_and" e2)],
                                                  None) in
                            (TType_refine(bvd, boolType, f, "", []), aenv)
                        else erre (spr "%s or %s not a bool" (strVal e1) (strVal e2))
                    | ADD 
                    | SUB
                    | MUL
                    | DIV -> if (t1 = intType && t2 = intType) then (intType, aenv)
                      else erre (spr "%s or %s not an int" (strVal e1) (strVal e2))
                    | _ -> erre ( "unexpected binary operator"))
             | [(e1,t1)] -> 
                 (match bop with 
                    | NOT -> 
                        if (isSubtype env t1 boolType) then (boolType, aenv)
                        else erre (spr "%s not a bool" (strVal e1))
                    | _ -> erre ( "unexpected unary operator"))
             | _ -> erre (spr "unexpected operator arity (%d)" (List.length et_l)))
    | TExp_ascribed (e, t) -> (t, checkExpAgainstType env e t)
    | TExp_bot -> (botType, emptyAenv)
    | _ -> erre "unexpected exp"

(* check the type of a value against a type t *)
and checkValAgainstType env v ty =
  let v = unwrapVal v in
  let vty, aenv = vTyping env v in
  (*let _ = pr "\n vty = %s \n ty = %s" (strType (normalize vty)) (strType (normalize ty)) in*)
  let aenv = if isEqType env ty vty then aenv
  else (match v, ty with
    | (*TVal_constant *) _, TType_affine t ->
      (* constants given affine types *)
      if isEqType env t vty then aenv 
      else err (spr "\ncheckValAgainstType: %s has type %s but expects %s" (strVal v) (strType vty) (strType ty))
    | _ ->
      
      let issubtype = (match ty with
        | TType_refine(bvd, t, formula, _, insts) ->
          if (isSubtype env vty t) then
            let tmap = addVvarMap emptyTyMap (snd bvd, vty) v in
            let formula = substType tmap formula in
            (*Util.warn "\n CheckValAgainstType: v=%s,\n ty= %s, \n formula %s\n" (strVal v) (strType ty) (strType formula);*)
            ProofDCIL.prove_dcil_formula env formula insts
          else false
        | _ -> isSubtype env vty ty) in
      if issubtype then aenv
      else
        (*print_any tenv;*)
        err (spr "\ncheckValAgainstType: %s has type %s but expects %s" (strVal v)
             (strType vty) (strType ty))) in
  (if !useTeq then
    (useTeq := false;
      match v with
      | TVal_uvar uvar -> (match Unionfind.find uvar with
                             | TUval vl -> (*pr " changing %s to cast<%s>" (strVal vl) (strType t);*)
                                           Unionfind.change uvar (TUcast(ty, vl))
                             | _ -> ())
      | _ -> ());
   aenv)
                          
 
 (* check the type of an exp against a type t *)
 and checkExpAgainstType env e ty = 
   match e with
     | TExp_val v -> checkValAgainstType env v ty
     | TExp_name (name, _) -> checkValAgainstType env (name2Value name) ty
     | TExp_let (var, e1, e2, hasType) ->
       let newenv, aenv1, var, e2 = checkLetExp1 env var e1 e2 hasType in
       let aenv2 = checkExpAgainstType newenv e2 ty in
       unionAenv (isNormalMode env) aenv1 (removeAvar aenv2 var)
     | TExp_cond (eb, et, ef) ->
        let (tyb, aenv) = eTyping env eb in
        if (isSubtype env tyb boolType) then
          (match eb with
            | TExp_ascribed(TExp_val vl, _)
            | TExp_val vl ->
                (match unwrapVal(vl) with
                   TVal_var var ->
                     let aenv1 = checkExpAgainstType (addEq env var trueVal) et ty in
                     let aenv2 = checkExpAgainstType (addEq env var falseVal) ef ty in
                     let isNmode = isNormalMode env in
                     unionAenv isNmode (unionBranchAenv isNmode aenv1 aenv2) aenv
                     | _ -> err (spr " expect a var but got %s" (strExp eb)))
             | _ -> err (spr "expect a var value but got %s" (strExp eb)))
          else err (spr "%s not a bool" (strExp eb))
     | _ -> let (ety, aenv) = eTyping env e in
       if (isSubtype env ety ty) then aenv
       else err (spr "\ncheckExpAgainstType: %s has type %s \nbut expects %s" (strExp e) (strType ety) (strType ty))
   aenv

and checkLetExp1 env var e1 e2 hasType =
      let (type1, aenv1) = eTyping env e1 in
      (*if true (* (isSubtype cenv tenv type1 (snd var)) *) then  *)
        let var, e2 = 
          (match (snd var) with
            | TType_inferred uvar ->  (* var's type can be inferred. create a new variable with type1 and substitute for var *)
              let _ = (match (Unionfind.find uvar) with
                         | TUvar -> Unionfind.change uvar (TFixed type1)
                         | _ -> ()) in
              let newvar = newVvar type1 in
              let tmap = addVvarMap emptyTyMap var (TVal_var newvar) in
              (newvar, substExp tmap e2)
            | _ -> (* set hasType to false if var's type = type1 *)
                (if (!hasType && isEqType env (snd var) type1) then 
                   (hasType := false; 
                    (*pr "Omitting type %s for var %s\n" (strType type1) (strVvar var)*))); 
                (var, e2)) in
        let newenv =
          let rec aux e =
            match e with
              | TExp_val vl -> let vl = unwrapVal vl in
                               (match vl with
                                  | TVal_var var1 -> addEqVvar env var var1
                                  | _ -> addEq env var vl)
              | TExp_name (name, _) -> addEq env var (name2Value name)
              | TExp_ascribed(e', _) -> aux e'
              | _ ->  addVvar env var in
           aux e1 in
  newenv, aenv1, var, e2

(*==================== class declarations ==================*)
(* check type variables in a class declaration or in a method declarations*)
(* Create a kind env that includes all the type variables *)
let rec checkTvars (env:env) tvars : env = 
  match tvars with
    | [] -> env 
    | tv :: rest -> 
      let (_, kind) = tv in
      let _ = checkKind env kind in
      checkTvars (addTvar env tv) rest

(* check value variables in a class declaration *)
(* Types of value variables can use type variables in kenv,
   and values introduced earlier *)
let checkVars (env:env) vars : env * tAenv =
  (* DebugLog.Log("\n checking variables"); *)
  let rec aux env aenv vars =
    (match vars with
      | [] -> (env, aenv)
      | (Tvar tvar)::rest ->
        let _, kind = tvar in
        let _ = checkKind env kind in
        aux (addTvar env tvar) aenv rest
      | (Vvar var)::rest ->
        let (_, varTy) = var in
        let kind = kinding env varTy in
        let (newenv, newAenv) = addVar env aenv kind var in
        aux newenv newAenv rest) in
  aux env emptyAenv vars

let rec checkClassEvidences (env:env) evidences =
  match evidences with
    | [] -> env
    | (TEv_type(tvar, t)):: rest -> 
      (* check well-formedness of tvar and t, add (tvar, t) to eenv *)
      let k1 = kinding env (TType_var tvar) in
      let k2 = kinding env t in
      if (subKind env k2 k1) then checkClassEvidences (addTeq env tvar t) rest
      else err (spr "checkClassEvidences: %s has kind %s but %s has kind %s"
                    (strTvar tvar) (strKind k1) (strType t) (strKind k2))
    | (TEv_val(var, v)) :: rest ->
      (* check that var is in scope and v is valid in scope *)
      let varty = lookupVvarType env var in
      let vty, _ = vTyping env v in
      if (isSubtype env vty varty) then
        checkClassEvidences (addEq env var v) rest 
      else err (spr "checkClassEvidences: mismatched types %s vs %s" (strType varty) (strType vty))

let checkStaticField (env:env) sf : env =
  let (name, ty, eopt) = sf in
  (* DebugLog.Log(spr "\n checking static field %s" name); *)
  let _ = match (kinding env ty) with
    | TKind_star
    | TKind_affine -> ()
    | k -> let errmsg = spr "checkStaticField: %s with unexpected kind %s"
                        (strStaticFieldDecl sf) (strKind k) in
           err errmsg in
  let env = addNameBinding env name (Some ty) in
  match eopt with
    | None -> env
    | Some e ->
      let ety, _ = eTyping env e in
      if (isSubtype env ty ety) then env
      else err (spr "checkStaticField: mismatched types %s vs %s" (strType ty) (strType ety))
       
(* check a field declaration in a class declaration *)
let checkField (env:env) field: env =
  let (name, ty) = field in
  (* DebugLog.Log(spr "\n checking field %s" name); *)
  let env = addNameBinding env name (Some ty) in
  match (kinding env ty) with
    | TKind_star
    | TKind_affine -> env
    | k ->
       let errmsg = spr "checkField: %s with unexpected kind %s" 
                    (strFieldDecl field) (strKind k) in
       err errmsg

(* check parameters of a method *)
(* Currently allow later parameters to use previous ones in their types
   although we don't need that at the moment *)
let checkParams (env:env) params: (env * tAenv) = 
  let rec check env aenv pars =
    match pars with
      | [] -> (env, aenv)
      | par::rest ->
        let knd = kinding env (snd par) in
        let (newenv, newaenv) = addVar env aenv knd par in
        check newenv newaenv rest in
  check env emptyAenv params

(* check a method declaration in a class declaration *)
(* The method can have its own type variables.
   The return type may depend on the parameters *)
let checkMethod (env:env) classAenv (m: tMethodDecl): unit =
  let (retType, name, tvars, params, body) = m in
  (* DebugLog.Log(spr "\n checking method %s " name); *)
  let env = checkTvars env tvars in
  (* DebugLog.Log(spr "\n checking params %s " name);  *)
  let (env, aenv) = checkParams env params in
  (* DebugLog.Log(spr "\n checking return type : %s " (strType retType));  *)
  (*let k_ret = kinding cenv newKenv tenv retType in*)
  (* DebugLog.Log(spr "\n checking body %s " name);  *)
  match body with
    | None -> ()
    | Some e ->
      let aenv_e = checkExpAgainstType env e retType in
      if (contains (unionAenv true aenv classAenv) aenv_e) then ()
      else err "checkMethod: free affine variables"

(* check a class declaration *)
(* Type variables introduced eariler can be used in types later in the class
   declaration. Value variables introduced earlier can be used in types of
   other value variables introduced later in the declaration. 
   Types of fields and methods can use the type variables introduced by the
   class, but not the value variables.
   TODO: check super
*)
let checkClassDecl (env:env) (c: tClassDecl) : unit = 
  let name = String.concat "." c.name in
  (*let _ = pr "\n checking class %s" name in *)
  let env, aenv = checkVars env c.vars in
  let env = checkClassEvidences env c.evidences in
  (* check (static) fields: currently those are not used in methods/other field decls, and thus not kept in env *)
  let env = List.fold_right (fun sf env -> checkStaticField env sf) c.staticFields env in
  (* pr "\n >>>>> checking fields"; *)
  let env = List.fold_right (fun f env -> checkField env f) c.fields env in
  (* pr "\n >>>>> checking methods"; *)
  let env = List.fold_right (fun m env -> let (_, name, _, _, _) = m in addNameBinding env name None) c.methods env in
  List.map (fun m -> checkMethod env aenv m) c.methods;
  if isTcon c then (* apply more restricted rules to kinds of type constructors *)
    let existsAffineTvar = List.exists (function | Tvar tv -> checkKind env (snd tv) = TKind_affine | _ -> false) c.vars in
    let existsAffineVvar = List.exists (function | Vvar var -> kinding env (snd var) = TKind_affine | _ -> false) c.vars in
    match c.kind with
      | Some k -> if (existsAffineTvar && k != TKind_affine && k != TKind_erasable ||
                      existsAffineVvar && k != TKind_erasable)
                  then err (spr "checkClassDecl: invalid kind for type constructor %s" name)
      | _ -> ();
  (* pr "\n <<<<<<< finished checking %s" name; *)
  ()

(*========================= module ========================*)
(* check a module *)
(* first check the class declarations in the module *)
(* then check the main expression *)
let checkModule imported (m: tModule) : tCdecls list =
  (*let _ = pr "\n dcil checking module %s" (String.concat "." m.name) in *)
  (*let _ = PrettyTarget.printModule m in*)
  let cdecls = m.decls in
  let moduleClass = m.modCdecl in
  let cenv = [cdecls; m.externs]@imported in
  let env = initial_env m cenv in
  let rec genGlobalEnv env gvals =
    match gvals with
      | [] -> env
      | (name, ty, _)::rest -> 
        let env = addVvar env (name, ty) in
        let qualified_name = String.concat "." (m.name@[name]) in
        let env = addVvar env (qualified_name, ty) in
        genGlobalEnv env rest in
  let env = genGlobalEnv env (moduleClass.staticFields) in
  let _ = ProofDCIL.process_cenv env in
  Hashtbl.iter (fun name cdecl -> checkClassDecl env cdecl) cdecls;
  (* DebugLog.Log("\n checking module body"); *)
  cenv
