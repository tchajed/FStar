#light "off"

// (c) Microsoft Corporation. All rights reserved
module Microsoft.FStar.TargetUtil

open Util
open Target
open PrettyTarget

exception TargetUtilErr of string
let err msg = raise (TargetUtilErr msg)

(* ======================== equalities =============== *)

(* kind variable equivalence *)
let eqKvar (kv1: tKvar) (kv2: tKvar)  = (fst kv1 = fst kv2)

(* type variable equivalence *)
(* NIK: Should we really be doing structural equality on the kind part? *)
(* This used to be:
   let eqTvar (tv1: tVar<tKind>) (tv2: tVar<tKind>) = (tv1 = tv2) *)
let eqTvar (tv1: tVar<tKind>) (tv2: tVar<tKind>) = (fst tv1) = (fst tv2) 

(* value variable equivalence *)
let eqVvar (vv1: tVar<tType>) (vv2: tVar<tType>) = (fst vv1 = fst vv2)

(* class declaration equivalence *)
let eqCdecl (cdecl1: tClassDecl) (cdecl2: tClassDecl) =
  cdecl1.name = cdecl2.name

(*======================== environment ========================*)

(* class env : list of class declarations *)
type tCenv = tCdecls list

type hashcenv = tCdecls list

(* lookup a class decl by name *)
let lookupCdeclByName (env: hashcenv) (name: tClassName) : tClassDecl =
  (*try *)
    let cname = String.concat "." name in
    (*let debug =  (cname = "CtGenSym_0_207") in
    let _ = if debug then (pr "\n looking in %d" (List.length env);
                           List.map (fun cds -> match Hashtbl.tryfind cds cname with
                                                | Some decl -> pr " \n ## found one %s" (strClassDecl decl)
                                                | None -> pr " \n ## not found here") env; ()) in *)
    let rec find ev =
      match ev with
        | [] ->
            pr "lookupCdeclByName: %s not found" cname;
            err(spr "lookupCdeclByName: %s not found" cname)
        | cdecls::rest -> (match Hashtbl.tryfind cdecls cname with
                             | Some decl -> decl
                             | None -> find rest) in
    find env
  (*with
    | :? System.Collections.Generic.KeyNotFoundException -> 
      (Printf.printf "Name %s not found in the environment" (strClassName name); raise Not_found)*)
    
let tryLookupCdeclByName (env: hashcenv) (name: tClassName) : tClassDecl option =
  (*try *)
    let cname = String.concat "." name in
    let rec find ev =
      match ev with
        | [] -> None
        | cdecls::rest -> (match Hashtbl.tryfind cdecls cname with
                             | Some decl -> Some decl
                             | None -> find rest) in
    find env


(* kind env: list of in-scope type variables *) 
type tKenv = tVar<tKind> list
let emptyKenv : tKenv = []

(* type env: list of in-scope value variables *)
type tTenv = (tVar<tType> * tValue) list
let emptyTenv: tTenv = []
let prettyTenv tenv =
  String.concat "\n" (List.map (fun (var, vl) -> spr "%s = %s, " 
                                          (PrettyTarget.strVvar var) 
                                          (PrettyTarget.strVal vl)) 
                         tenv)

                             
(* type eqivalence: list of in-scope type equivalence relations *)
type tEqenv = (tVar<tKind> * tType) list
let emptyEqenv: tEqenv = []

type tcMode = 
  | Erasure            (* erasure mode, used for value/exp typing *)
  | Normal             (* mode for non-erasure kinding/typing *)

type env = {
  currentModule: option<tModule> ref;
  cenv: tCdecls list;  (* class declarations *)
  kvars: tKvar list;   (* list of kind variables *)
  kenv: tKenv;         (* mapping from tvar to kind *)
  tenv: tTenv;         (* mapping from vvar to type *)
  eenv: tEqenv;        (* equivalence relations *)
  mode: tcMode;        (* mode of type checking *)
  nameBindings: (string * option<tType>) list; (* for bindings static fields/fields/methods *)
}

(* change the type checking mode to erasure *)
let changeToErasureMode env = 
  {env with mode = Erasure}

let isNormalMode env =
 env.mode = Normal

(* create an initial environment *)
let initial_env modu cdecls = {
  currentModule = ref (Some modu);
  cenv = cdecls;
  kvars = [];
  kenv = emptyKenv;
  tenv = emptyTenv;
  eenv = emptyEqenv;
  mode = Normal;
  nameBindings = [];
}

let foundKvar (env:env) kvar: bool=
  List.exists (fun var -> eqKvar var kvar) env.kvars

let addKvar (env:env) kvar : env =
  if (foundKvar env kvar) then
  err (spr "addKvar: %s already exists" (fst kvar))
  else {env with kvars = kvar::env.kvars}

(* utility functions for accessing kind env *)
(* add a new type variable to kind env *)
(* report error if tvar is already in env *)
let addTvar (env: env) (tvar: tVar<tKind>) : env =
  if (List.exists (fun (tv: tVar<tKind>) -> (eqTvar tv tvar)) env.kenv) then
    let errmsg = spr "addTvar: %s already exists" (fst tvar) in
    err errmsg
  else {env with kenv=tvar :: env.kenv}

(* see if a new type variables in the kenv *)
let containsTvar (env: env) (tvar: tVar<tKind>): bool =
  List.exists (fun (tv: tVar<tKind>) -> (eqTvar tv tvar)) env.kenv

(* add a value variable to type env *)
(* There might be more than one entry for the same variable because of *)
(* type cast. The first entry is the most accurate one *)
let addVvar (env: env) (var: tVar<tType>) : env = {env with tenv =(var, TVal_var var) :: env.tenv}

(* look up value variables *)
let lookupVvarType (env: env) (var: tVar<tType>) =
  let rec auxField nameBindings =
    match nameBindings with
      | [] -> err (spr "lookupVvarType: cannot find var %s \n" (strVvar var))
      | (name, tyOpt) :: rest ->
        if (fst var = name) then
          (match tyOpt with
             | None -> err (spr "lookupVvarType: no type for var %s\n" (strVvar var))
             | Some ty -> ty)
        else auxField rest in
  let rec aux tenv =
    match tenv with
      | [] -> auxField env.nameBindings
      | (vvar, _) :: rest ->
        if (eqVvar var vvar) then snd vvar else aux rest in
  aux env.tenv

(* check if a var is in env *)
let isInTenv (env: env) var =
  let rec aux tenv =
    match tenv with
      | [] -> false
      | (vvar, _) :: rest ->
        if (eqVvar var vvar) then true else aux rest in
  aux env.tenv

(* return the representative of var *)
let lookupVvarRep (env: env) var =
  let rec aux tenv =
    match tenv with
      | [] -> var
      | (vvar, TVal_var rep) :: rest ->
        if (eqVvar var vvar) then rep else aux rest
      | _ :: rest -> aux rest in
 aux env.tenv

let addEq (env:env) var vl = {env with tenv = (var, vl) :: env.tenv}

(* add var1 -> rep of var2 in tenv. *)
let addEqVvar (env:env) var1 var2 =
  let rep = lookupVvarRep env var2 in
  {env with tenv =(var1, TVal_var rep) :: env.tenv}

(* var equivalence taking into account the equivalence in env *)
let rec isEqVvar env var1 var2 =
  if (eqVvar var1 var2) then true
  else let rep1, rep2 = (lookupVvarRep env var1, lookupVvarRep env var2) in
  eqVvar rep1 rep2

let addNameBinding env name ty_opt =
  if (List.exists (fun(nm, _) -> nm = name) env.nameBindings) then err (spr "")
  else {env with nameBindings = (name, ty_opt)::env.nameBindings}

let addTeq env tvar t =
  {env with eenv = (tvar,t)::env.eenv}

let getAllTeqs env = List.map (fun (tvar, t) -> (TType_var tvar, t)) env.eenv
(*================= type substitution =============*)

type substMap =
  | KvarMap of tKvar * tKind        (* mapping a kind variable to a kind *)
  | TvarMap of tVar<tKind> * tType  (* mapping a type variable to a type *)
  | VvarMap of tVar<tType> * tValue (* mapping a value variable to a value *)
  | TindexMap of tType list         (* mapping from indices to types: !n -> nth element in the list *)

type tyMap = substMap list

let emptyTyMap: tyMap = []

let addKvarMap tmap kvar k = (KvarMap(kvar, k)) :: tmap

let addTvarMap tmap tvar ty = (TvarMap(tvar, ty)) :: tmap

let addVvarMap tmap vvar v = (VvarMap(vvar, v)) :: tmap

let rec substKvar tmap kvar: tKind =
  match tmap with
    | [] -> TKind_var kvar
    | KvarMap(kv, k) :: rest ->
        if (eqKvar kv kvar) then k else substKvar rest kvar
    | _ :: rest -> substKvar rest kvar

and  substTvar typemap tvar: tType =
  let rec aux tmap =
    match tmap with
      | [] -> 
          let tv, k = tvar in
            TType_var (tv, substKind typemap k)
      | TvarMap(tv, ty) :: rest ->
          if (eqTvar tv tvar) then ty else aux rest
      | _ :: rest -> aux rest in
  aux typemap
  

and substTindex tmap n: tType =
  match tmap with
    | [] -> TType_index n
    | (TindexMap ts) :: _ ->
       let nint = (int n) in 
       if (nint < List.length ts) then List.nth ts nint
       else err (spr "substTindex: cannot find %d" nint)
    | _ :: rest -> substTindex rest n

and substVvar typemap vvar: tValue =
  let rec aux tmap =
    match tmap with
      | [] -> 
          let vv, tt = vvar in
            TVal_var (vv, substType typemap tt)
      | VvarMap(var, v) :: rest ->
        if (eqVvar var vvar) then v else aux rest
      | _ :: rest -> aux rest in
 aux typemap

and substTConcrete tmap (cname, ks, args, eref) =
  (cname, List.map (substKind tmap) ks, 
   List.map (function | Targ t -> Targ(substType tmap t) | Varg v -> Varg(substVal tmap v)) args, 
   eref)

and substVal tmap v: tValue =
  match v with
    | TVal_var var -> substVvar tmap var
    | TVal_obj(tconcrete, vs) ->
      TVal_obj(substTConcrete tmap tconcrete, List.map (substVal tmap) vs)
    | TVal_ldfld (vobj, fld) -> TVal_ldfld(substVal tmap vobj, fld)
    | TVal_logic_fun (fname, vs) -> TVal_logic_fun(fname, List.map (substVal tmap) vs)
    | _ -> v

(* kind substitution *)
and substKind tmap k = 
  match k with
    | TKind_var kv -> substKvar tmap kv
    | TKind_arrow(t, k') -> TKind_arrow (substType tmap t, 
                                         substKind tmap k')
    | TKind_karrow(k1, k2) -> TKind_karrow(substKind tmap k1,
                                           substKind tmap k2)
    | _ -> k

(* type substitution *)
and substType tmap t = 
  match t with
    | TType_index n -> substTindex tmap n
    | TType_var tv -> substTvar tmap tv
    | TType_name (name, _) -> t
    | TType_fun (bvdopt, t1, t2) -> 
      TType_fun (bvdopt, substType tmap t1, substType tmap t2)
    | TType_concrete(cname, ks, args, eref) ->
      TType_concrete (substTConcrete tmap (cname, ks, args, eref))
    | TType_dep (tfun, v) ->
      TType_dep (substType tmap tfun, substVal tmap v)
    | TType_affine t -> TType_affine (substType tmap t)
    | TType_tfun(bvd, kind, body) -> TType_tfun(bvd, substKind tmap kind, substType tmap body)
    | TType_tapp(tfun, targ) -> TType_tapp(substType tmap tfun, substType tmap targ)
    | TType_refine(bvd, t, formula, sf, insts) -> TType_refine(bvd, substType tmap t, substType tmap formula, sf, insts)
    | TType_inferred _ -> t
    | _ -> err (spr "substType: unexpected type %s" (strType t))

let rec substExp tmap e =
  let substv = substVal tmap in
  let substMref (mname, ts) = (mname, List.map (substType tmap) ts) in
  let substvar (var:tVar<tType>) = (fst var, substType tmap (snd var)) in
  match e with
    | TExp_val v -> TExp_val (substv v)
    | TExp_ldfld(v, fref) -> TExp_ldfld(substv v, fref)
    | TExp_call(v, vs, mref) -> TExp_call(substv v, List.map substv vs, substMref mref)
    | TExp_extern_call(eref, mref, vs) -> TExp_extern_call(eref, substMref mref, List.map substv vs)
    | TExp_let(var, e1, e2, b) -> TExp_let(substvar var, substExp tmap e1, substExp tmap e2, b)
    | TExp_isinst(v, branches, defaulte, t) ->
      let substB (cname, ks, pats, isGADT, eb) =
        (cname, List.map (substKind tmap) ks, 
         List.map (function | Ptype t -> Ptype(substType tmap t)
                            | Pvar var -> Pvar(substvar var)
                            | Pfield f -> Pfield(substvar f)) pats, 
         isGADT, substExp tmap eb) in
      TExp_isinst(substv v, List.map substB branches, substExp tmap defaulte, substType tmap t)
    | TExp_cond(eb, e1, e2) -> TExp_cond(substExp tmap eb, substExp tmap e1, substExp tmap e2)
    | TExp_primop(op, vs) -> TExp_primop(op, List.map substv vs)
    | TExp_name _ 
    | TExp_bot -> e
    | _ -> err (spr "substExp: unknown exp %s" (strExp e))

let buildTyMap (cdecl:tClassDecl) ks args =
(*  pr "%A\n %A\n" (cdecl.vars) args; *)
  let kmap = List.map KvarMap (List.zip cdecl.kvars ks) in
  let tvmap = List.map (function | Tvar tvar, Targ t -> TvarMap(tvar, t)
                                 | Vvar vvar, Varg v -> VvarMap(vvar, v)
                                 | _ -> err "buildTyMap: unmatched vars and args")
                      (List.zip (cdecl.vars) args) in
  kmap @ tvmap

let instantiateType (cdecl: tClassDecl) ks args t : tType = 
  substType (buildTyMap cdecl ks args) t

(* look up a field from a type concrete *)
(* return a field declaration if found, and None otherwise *)
let lookupField env tconcrete fieldRef =
  let (cname, ks, args, eref) = tconcrete in
  let cdecl = lookupCdeclByName env.cenv cname in
  let field = List.find (fun f -> (fst f = fieldRef)) (cdecl.fields) in
  (fst field, instantiateType cdecl ks args (snd field))

  (* normalization of a type *)
(* beta reduction *)
let rec normalize ty =
  match ty with
    | TType_dep(TType_fun(bvd, targ, tbody), v) ->
      (match bvd with
         | Some var ->
           let tmap = [VvarMap((snd var, targ), v)] in
           normalize(substType tmap tbody)
         | _ -> normalize tbody)
    | TType_dep(tfun, v) -> 
      let tfun' = normalize tfun in
      (match tfun with
         | TType_fun _ -> normalize(TType_dep(normalize tfun, v))
         | _ -> TType_dep(tfun', v))
    | TType_tapp(TType_tfun(bvd, kind, tbody), targ) ->
      (* (\a::k.t)t' ==> t[a->t']*)
      let tmap = [TvarMap((snd bvd, kind), targ)] in
      normalize(substType tmap tbody)
    | TType_tapp(tfun, targ) -> 
      let tfun', targ' = normalize tfun, normalize targ in
      (match tfun' with
         | TType_tfun _ -> normalize(TType_tapp(normalize tfun, normalize targ))      
         | _ -> TType_tapp(tfun', targ')) 
    | TType_fun(bvd, targ, tbody) ->
      let targ, tbody = normalize targ, normalize tbody in
      (* "\x:t-> t'" => "t->t'" if x doesn't occur free in t' *)
      (match bvd with
         | None -> TType_fun(bvd, targ, tbody)
         | Some var -> 
           let rec isFreeInTy ty = (* check if var is free in ty*)
             (match ty with
                | TType_index _ -> false
                | TType_var tvar -> isFreeInKind (snd tvar)
                | TType_name(tname, _) -> isFreeInKind (snd tname)
                | TType_fun(bvd', targ', tbody') -> isFreeInTy targ' || isFreeInTy tbody'
                | TType_dep(tfun, v) -> isFreeInTy tfun || isFreeInVal v
                | TType_tapp(tfun, targ) -> isFreeInTy tfun || isFreeInTy targ
                | TType_concrete tconcrete -> isFreeInTconc tconcrete
                | TType_affine t -> isFreeInTy t
                | TType_refine(_, t, formula, _, insts) -> isFreeInTy t || isFreeInTy formula)
           and isFreeInKind k =
             (match k with
                | TKind_arrow(t, k') -> isFreeInTy t || isFreeInKind k'
                | TKind_karrow(k1, k2) -> isFreeInKind k1 || isFreeInKind k2
                | _ -> false)
           and isFreeInVal v =
             (match v with
                | TVal_var var' -> snd var = fst var'
                | TVal_obj(tconcrete, vs) -> isFreeInTconc tconcrete || (List.exists isFreeInVal vs)
                | TVal_ldfld(v', _) -> isFreeInVal v'
                | TVal_logic_fun(fname, vs) -> List.exists isFreeInVal vs
                | _ -> false)
           and isFreeInTconc (_, ks, args, _) =
             List.exists isFreeInKind ks || List.exists (function | Targ t -> isFreeInTy t | Varg v -> isFreeInVal v) args
           in if (isFreeInTy tbody) then TType_fun(bvd, targ, tbody)
           else TType_fun(None, targ, tbody)
      )
    | TType_tfun (bvd, k, t) -> TType_tfun(bvd, k, normalize t)
    | TType_affine(t) -> TType_affine(normalize t)
    | TType_refine(bvd, t, formula, str, nameTys) -> TType_refine(bvd, normalize t, formula, str, nameTys)
    | TType_concrete(name, ks, args, refopt) ->
      TType_concrete(name, ks, List.map (function | Targ t -> Targ(normalize t) | v -> v) args, refopt)
    | _ -> ty

(* transform to debruijn index for pretty-printing, to avoid alpha-renaming issues *)
(* the result type may not be well-formed *)
let printDebruijn ty : string =
  let dummyBvd = ("", "") in
  let tryFindTvar bvs (var: tVar<tKind>): tType =
      match Util.try_find_position (fun (bv:tIdent) -> (bv = (fst var))) bvs with
        | Some index -> TType_index index
        | _ -> TType_var var in
  let rec tryFindVvar bvs (var: tVar<tType>): tValue =
      match Util.try_find_position (fun (bv: tIdent) -> (bv = (fst var))) bvs with
        | Some index -> TVal_var (index.ToString(), auxTy bvs (snd var))
        | _ -> TVal_var var
  and auxTy bvs ty =
    match ty with
      | TType_index _ -> ty
      | TType_name _ -> ty
      | TType_var var -> tryFindTvar bvs var 
      | TType_fun(None, t1, t2) -> TType_fun(None, auxTy bvs t1, auxTy bvs t2)
      | TType_fun(Some bvd, t1, t2) -> TType_fun(None, auxTy bvs t1, auxTy ((snd bvd)::bvs) t2)
      | TType_tfun(bvd, k, t) -> TType_tfun(dummyBvd, auxKind bvs k, auxTy ((snd bvd)::bvs) t)
      | TType_dep(t, v) -> TType_dep(auxTy bvs t, auxVal bvs v)
      | TType_tapp(t1, t2) -> TType_tapp(auxTy bvs t1, auxTy bvs t2)
      | TType_concrete tconcrete -> TType_concrete(auxTconc bvs tconcrete)
      | TType_affine(t) -> TType_affine(auxTy bvs t)
      | TType_refine(bvd, t, f, sf, _) -> TType_refine (dummyBvd, auxTy bvs t, auxTy ((snd bvd)::bvs) f, sf, [])
      | TType_inferred uvar -> err "\n printDebruijn: TType_inferred"
      | _ -> err "\n printDebruijn: unexpected type"

  and auxTconc bvs tconcrete =
    let (name, ks, args, extref) = tconcrete in
    (name, List.map (auxKind bvs) ks, 
     List.map (function | Targ t -> Targ(auxTy bvs t) | Varg v -> Varg(auxVal bvs v)) args,  extref)

  and auxKind bvs k =
   match k with
     | TKind_arrow(t, k) -> TKind_arrow(auxTy bvs t, auxKind bvs k)
     | TKind_karrow(k1, k2) -> TKind_karrow(auxKind bvs k1, auxKind bvs k2)
     | _ -> k

  and auxVal bvs vl: tValue =
  match vl with
    | TVal_var var -> tryFindVvar bvs var 
    | TVal_obj (tconcrete, vs) ->
      TVal_obj(auxTconc bvs tconcrete, List.map (auxVal bvs) vs)
    | TVal_constant _ -> vl
    | TVal_ldfld (v, fref) -> TVal_ldfld(auxVal bvs v, fref)
    | TVal_logic_fun (fname, vs) -> TVal_logic_fun (fname, List.map (auxVal bvs) vs)
    | _ -> err "\n printDebruijn: unexpected value" 

  in strType(auxTy [] ty)


let unwrapVal v =
  match v with 
    | TVal_uvar uvar ->
      (match Unionfind.find uvar with
         | TUval vl
         | TUcast(_, vl) -> vl)
    | _ -> v

let getTvars cdecl =
  let rec aux vars result =
    match vars with
      | [] -> List.rev result
      | (Tvar tvar) :: rest -> aux rest (tvar :: result)
      | _ :: rest -> aux rest result
  in aux cdecl.vars []

let getVvars cdecl =
  let rec aux vars result =
    match vars with
      | [] -> List.rev result
      | (Vvar vvar)::rest -> aux rest (vvar::result)
      | _ :: rest -> aux rest result
  in aux cdecl.vars []

  let rec getTys args =
    match args with
      | [] -> []
      | (Targ t)::rest -> t :: (getTys rest)
      | _ :: rest -> getTys rest

let rec getVals args =
  match args with
    | [] -> []
    | (Varg v)::rest -> v::(getVals rest)
    | _ :: rest -> getVals rest


let rec getTysFromPats pats =
  match pats with
    | [] -> []
    | (Ptype t) :: rest -> t :: (getTysFromPats rest) 
    | _ :: rest -> getTysFromPats rest

let rec getVarsFromPats pats =
  match pats with
    | [] -> []
    | (Pvar var) :: rest -> var :: (getVarsFromPats rest)
    | _ :: rest -> getVarsFromPats rest

let rec getFieldsFromPats pats: tVar<tType> list =
  match pats with
    | [] -> []
    | (Pfield var) :: rest -> var :: (getFieldsFromPats rest)
    | _ :: rest -> getFieldsFromPats rest

(* check if a class declaration corresponds to a type constructor *)
let isTcon cdecl = cdecl.attr = NoAttr && cdecl.extends = None

let isDepArrowName cname = strLident cname = tClassDepArrow.namestring

let isDepTupleName cname = strLident cname = tClassDepTuple.namestring

let isDconDepTupleName cname = strLident cname = tClassDconDepTuple.namestring

let isArrowOrTupleName cname = 
  let namestring = strLident cname in
  namestring = tClassDepArrow.namestring ||
  namestring = tClassDepTuple.namestring ||
  namestring = tClassDconDepTuple.namestring

(* check if the class name is pf *)
let isPf cname =
  (strLident cname) = "Prims.pf"

let name2Value name: tValue =
  let var = (PrettyTarget.strLident (fst name), snd name) in
  TVal_var var


let isFsharpFunc cn = (cn = ["Microsoft";"FSharp";"Core";"FastFunc`2"])

(* ======= utilities for translation from Absyn/Coretyping to Dcil ============ *)
let rec wrapVal v = match v with
  | TVal_obj(tconcrete, vs) -> TVal_obj(tconcrete, List.map wrapVal vs)
  | TVal_ldfld(v, fref) -> TVal_ldfld(wrapVal v, fref)
  | TVal_uvar _ -> v (* no need to wrap again *)
  | TVal_logic_fun (vf, vs) -> TVal_logic_fun(vf, List.map wrapVal vs)
  | _ -> TVal_uvar(Unionfind.fresh (TUval v))

and wrapExp e =
  match e with
    | TExp_val v -> TExp_val (wrapVal v)
    | TExp_name _ -> e
    | TExp_ldfld(v, fref) -> TExp_ldfld(wrapVal v, fref)
    | TExp_call(v, vs, mref) -> TExp_call(wrapVal v, List.map wrapVal vs, mref)
    | TExp_extern_call(eref, mref, vs) -> TExp_extern_call(eref, mref, List.map wrapVal vs)
    | TExp_let(var, e1, e2, b) -> TExp_let(var, wrapExp e1, wrapExp e2, b)
    | TExp_isinst(v, branches, defaulte, t) ->
      let wrapBranch (cname, ks, pats, b, eb) =
         if b then let x = newVvar t in (* eb => let x = eb in cast<t>x *)
                   let wrappedx = TVal_uvar (Unionfind.fresh (TUcast(t, TVal_var x))) in
                  (cname, ks, pats, b, TExp_let(x, wrapExp eb, TExp_val wrappedx, ref true))
         else (cname, ks, pats, b, wrapExp eb) in 
      TExp_isinst(wrapVal v, List.map wrapBranch branches, wrapExp defaulte, t)
    | TExp_cond(ec, et, ef) -> TExp_cond(wrapExp ec, wrapExp et, wrapExp ef)
    | TExp_primop(pop, vs) -> TExp_primop(pop, List.map wrapVal vs)
    | TExp_ascribed(e, t) -> TExp_ascribed(wrapExp e, t)
    | TExp_bot -> e
    | _ -> err (spr "wrapExp: unexpected %s" (strExp e))

let wrapOpt eopt = match eopt with None -> None | Some e -> Some(wrapExp e)

let wrapStaticField (name, t, eopt) = (name, t, wrapOpt eopt)

let wrapCdecl (cdecl:tClassDecl) : tClassDecl =
  {cdecl with 
     staticFields = List.map wrapStaticField (cdecl.staticFields) ; 
     methods = List.map (fun (t, name, tvars, vars, eopt) -> (t, name, tvars, vars, wrapOpt eopt)) (cdecl.methods)} 
     
let dedupVars l = 
  let test (vv1,_) (vv2, _)= vv1=vv2 in
  let rec aux out = function
    | [] -> List.rev out
    | hd::tl -> 
        match List.tryFind (fun e -> test hd e) out with
            Some _ -> aux out tl
          | None -> aux (hd::out) tl in
    aux [] l 

(* environment for translation, including accumulated class declarations*)
type transEnv = (string, tClassDecl) Hashtbl.t * Tcenv.env

let getDecls (env: transEnv) = fst env
let getTcenv (env: transEnv) = snd env

let createTransEnv tcenv: transEnv = (Hashtbl.create 100, tcenv)

(* look up a class declaration in transenv, return None if not found and Some cdecl otherwise *)
let rec lookupTransEnv env cname : tClassDecl = 
  Hashtbl.find (fst env) cname

(* add a class declaration to env *)
let addToTransEnv envs cdecl : transEnv =
  let env, tcenv = envs in
  if (Hashtbl.mem env (cdecl.namestring)) then envs
  else (Hashtbl.add env cdecl.namestring ((* wrapCdecl *) cdecl); (env, tcenv))

(* filter evidences to find those for free variables *)
let filterEvidences (evidences:tEvidences) (fvs: tIdent list) =
  (*let _ = pr "\n: before filtering: %s, \n  fvs = %s " 
                 (PrettyTarget.strEvidence evidences)
                 (String.concat ", " fvs) in *)
  let rec filter evs : tEvidences =
    match evs with
      | [] -> []
      | (TEv_type(tvar, t))::rest ->
        if (List.exists (fun id -> id = fst tvar) fvs) 
        then (TEv_type(tvar, t)) :: (filter rest)
        else filter rest   
      | (TEv_val(vvar, v))::rest -> 
          if (List.exists (fun id -> id = fst vvar) fvs)
          then (TEv_val(vvar,v)) :: (filter rest)
          else filter rest in
    let result = filter evidences in
    (*let _ = pr "\n: after filtering: %s " 
                   (PrettyTarget.strEvidence evidences) in*)
    result

