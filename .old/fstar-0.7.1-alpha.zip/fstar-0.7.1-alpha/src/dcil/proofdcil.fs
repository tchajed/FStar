(*  Copyright (c) 2010, Microsoft Research *)
#light "off"

module Microsoft.FStar.ProofDCIL
open Util
open Absyn
open AbsynUtils
open ProofCommon
open ProofZZZ
open ProofCombinators
open ProofExp
open ProofSig
open Proof
open Target
open TargetUtil
open PrettyTarget
open Profiling

(* count for data constructors, used to differentiate data cons *)
let dcount = ref 0
let getDCount() = let c = !dcount in dcount := c+1; c

(****************************************************************************)
(* INTERFACE WITH DCIL TYPE CHECKER                                         *)
(****************************************************************************)

(* define the sorts for primitive types *)
let objectSort, boolSort, unitSort, PrimsIntSort, stringSort, bytesSort = 1,2,3,4,5,6 

let primsSortMap = [("Prims.object", objectSort);("Prims.bool", boolSort);("Prims.unit", unitSort);
                    ("Prims.int", PrimsIntSort);("Prims.string", stringSort);("Prims.bytes", bytesSort)]
let sortctr = ref 10

(* constructor for integers. Int_con: intSort -> PrimsIntSort *)
let stringIntCon = "Int_con"


let rec removeDepType t =
  match t with
    | TType_fun(bvdopt, t1, t2) -> (*TType_fun(bvdopt, removeDepType t1, removeDepType t2)*)
      removeDepType t2
    | TType_tfun(bvd, k, tbody) -> TType_tfun(bvd, removeDepKind k, removeDepType tbody)
    | TType_dep(tfun, v) -> removeDepType tfun
    | TType_tapp(t1, t2) -> TType_tapp(removeDepType t1, removeDepType t2)
    | TType_concrete tconcrete -> TType_concrete(removeDepTconcrete tconcrete)
    | TType_affine tt -> TType_affine(removeDepType tt)
    | TType_refine(bvd, t, tf, sf, insts) ->
      TType_refine(bvd, removeDepType t, removeDepType tf, sf, List.map (fun(name, tt) -> (name, List.map removeDepType tt)) insts)
    (*| TType_inferred uv -> TODO *)
    | _ -> t

and removeDepTconcrete (name, ks, args, ref) = (* ignore vs *)
  (name, List.map removeDepKind ks, 
   List.rev(List.fold_left (fun newargs arg -> 
                                (match arg with Targ t -> (Targ(removeDepType t)) :: newargs 
                                                | _ -> newargs)) [] args),
   ref)

and removeDepVal v =
  match v with
    | TVal_obj(tconcrete, vs) -> TVal_obj(removeDepTconcrete tconcrete, List.map removeDepVal vs)
    | TVal_logic_fun(name, vs) -> TVal_logic_fun(name, List.map removeDepVal vs)
    | TVal_ldfld(v, fref) -> TVal_ldfld(removeDepVal v, fref)
    | _ -> v

and removeDepKind k =
  match k with
    | TKind_arrow(t, k) -> TKind_arrow(removeDepType t, removeDepKind k)
    | TKind_karrow(k1, k2) -> TKind_karrow(removeDepKind k1, removeDepKind k2)
    | _ -> k

(* generate a name for a type concrete in the format of class_name<type arguments> *)
let genTConcreteName classname ts =
    let name = String.concat "." classname in
    let ts = List.map removeDepType ts in
    match ts with
      | [] -> name  (* no type arguments *)
      | _ -> spr "%s<%s>" name (String.concat "," (List.map printDebruijn ts)) 

type sortMapTy = list<string * int>

let lookupSortByName name sortMap: (string * int) option = 
   List.tryFind (fun (nm, _) -> nm = name) sortMap

let addSort name sort sortMap : sortMapTy = 
  (name, sort)::sortMap

(* name of the function that maps data constructors to integers *)
let tyconFuncName name = "func_" ^ name 

(* look for a name in sortMap, if found, return the old sortMap and ops. *)
(* Otherwise, create a new sort and add to sortMap a new mapping and to ops a new op DefSort. *)
(* In both cases, the sort corresponding to the name is returned as well. *)
let findAddSort name sortMap ops: int * list<string*int> * list<op> =
  match lookupSortByName name sortMap with
    | Some (_, sort) -> sort, sortMap, ops
    | None -> let newsort = incr sortctr; !sortctr in
              let sortMap = (name, newsort)::sortMap in
              let ops = (DefSort(newsort, Some name))::ops in
              newsort, sortMap, ops

(* see if name is already defined as a function or a predicate *)
let existsFun name ops =
  List.exists (fun op ->
                 match op with
                   DefFun(fun_name, _, _, _) -> name = fun_name 
                   | DefPred(pred_name, _, _) -> name = pred_name
                   | _ -> false)
              ops
  
let rec sortOfType t sortMap ops = 
  (*let _ = pr "\n before normalizing %s" (strType t) in*)
  let t = normalize t in
  (*let _ = pr "\n after normalizing %s" (strType t) in*)
  match t with
    | TType_concrete(name, _, args, _) ->
        let sort, sortMap, ops = findAddSort (genTConcreteName name (getTys args)) sortMap ops in
        sort, sortMap, ops
    | TType_name((name,_), _) -> 
        let sort, sortMap, ops = findAddSort (String.concat "." name) sortMap ops in
        sort, sortMap, ops
    | TType_refine(_, tt, formula, _, inst) -> sortOfType tt sortMap ops (* TODO: handle formula *)
    | _ -> (*pr "\nsortOfType: no sort for %s!!" (strType t);*)
           findAddSort (strType t) sortMap ops (*raise Impos*)  (* TODO: what to do with affine types *)

let instantiateCdecl env (name, ts): tClassDecl = 
  let cdecl = lookupCdeclByName (env.cenv) name in
  let tmap = List.map TvarMap (List.zip (getTvars cdecl) ts) in
  let instType = substType tmap in
  let super = match cdecl.extends with
    | None -> None
    | Some t -> Some (instType t) in
  {visibility = cdecl.visibility;
   attr = cdecl.attr;
   name = [];
   namestring = genTConcreteName name ts;
   kvars = [];
   vars = List.map (fun (name, t) -> Vvar (name, instType t)) (getVvars cdecl);
   evidences = [];
   extends = super;
   fields = [];
   staticFields = [];
   methods = [];
   kind = None;
   externref = None;
   hasTag=cdecl.hasTag;
   tagNum=cdecl.tagNum
  }

let gen_proj_fi_name tname fname = tname ^ fname

let rec value2term env bvs v sortMap ops =
  let err msg = pr "\n value2term: unexpected %s with %s" (strVal v) msg; raise Impos in
  let v = unwrapVal v in
  match v with
    | TVal_var var -> 
      let (sort, sortMap, ops) = sortOfType (snd var) sortMap ops in
      (match List.tryFindIndex (fun bv -> fst bv = fst var) bvs with
         | None -> (FreeV(fst var, sort), sortMap, ops)
         | Some index -> (BoundV(index, sort), sortMap, ops))
    | TVal_obj((name, _, args, _), vs') -> tconcrete2term env bvs name (getTys args) ((getVals args)@vs') sortMap ops
    | TVal_logic_fun(name, vs) ->
      let fname = String.concat "." (fst name) in
      let terms, sortMap, ops = genVs env bvs vs [] sortMap ops in
      let sortMap, ops = 
        if existsFun fname ops then sortMap, ops
        else let rec getArgRetSorts t argSorts sortMap ops =
          (match t with
            | TType_concrete(name, _, args, _) when isDepArrowName name ->
              (* t1 -> t2 -> ... -> tn -> t ==> DefFun(fname, [t1, t2, ..., tn], t) *)
              let ts = getTys args in
              (match ts with
                | [t1; TType_fun(_, _, t2)] ->
                  let sort1, sortMap, ops = sortOfType t1 sortMap ops in
                  getArgRetSorts t2 (sort1::argSorts) sortMap ops
                | _ -> pr "logic_fun: %s" fname; raise Impos)
            | _ -> let retSort, sortMap, ops = sortOfType t sortMap ops in
              List.rev argSorts, retSort, sortMap, ops) in
          let sorts, tsort, sortMap, ops = getArgRetSorts (snd name) [] sortMap ops in
          let newop = DefFun(fname, Array.ofList sorts, tsort, None) in
          sortMap, newop::ops in
      App(fname, List.toArray terms), sortMap, ops
    | TVal_constant(Sugar.Const_bool true) -> (termTrue, sortMap, ops)
    | TVal_constant(Sugar.Const_bool false) -> (termFalse, sortMap, ops)
    | TVal_constant(Sugar.Const_unit) -> (termUnit, sortMap, ops)
    | TVal_constant(Sugar.Const_int32 i) -> (App(stringIntCon, [|Integer i|]), sortMap, ops)
    | TVal_constant(Sugar.Const_string(b,_)) ->
      let s = System.Text.Encoding.Unicode.GetString(b, 0, b.Length) in
      let newops = 
        match ProofState.StringConstants.idOptOfString s with
          | Some _ -> []
          | _ ->
            let i = ProofState.StringConstants.addString s in
            let sym = ProofState.Z3Symbols.symOfString s in
            [DefFun(sym, [||], stringSort, None)] in
     (App(ProofState.Z3Symbols.symOfString s, [||]), sortMap, newops@ops)
    | TVal_ldfld(objv, fref) -> 
      let objv = unwrapVal objv in
      let rec getTerm t fld term = (* return type of t.fld and App("t.fld", term) *)
        (match t with
           | TType_refine(_, tt, _, _, _) -> getTerm tt fld term
           | _ ->
        let cname, fty =
          (match t with
             | TType_concrete tconcrete ->
               let (name, _, args, _) = tconcrete in
               genTConcreteName name (getTys args), snd(lookupField env tconcrete fld)
             | TType_name(name, _) ->
               String.concat "." (fst name), snd(lookupField env (fst name, [], [], None) fld)
             | _ -> err (spr " type %s" (strType t))) in
        let projName = gen_proj_fi_name cname fld in
        fty, App(projName, [|term|])) in
      let rec aux obj fld sortMap ops = (* compute term App(fieldname, term_obj), return type of obj.fld *)
        (match obj with
           | TVal_var var ->
             let term_obj, sortMap, ops = value2term env bvs obj sortMap ops in
             getTerm (snd var) fld term_obj, sortMap, ops
           | TVal_obj(tconcrete, _) ->
             let term_obj, sortMap, ops = value2term env bvs obj sortMap ops in
             getTerm (TType_concrete tconcrete) fld term_obj, sortMap, ops
           | TVal_ldfld(obj2, fref2) -> 
             let (fty2, term2), sortMap, ops = aux obj2 fref2 sortMap ops in
             (* App(fty2.fld, term2)*)
             getTerm fty2 fld term2, sortMap, ops
           | _ -> err(spr "aux: obj %s" (strVal obj))) in 
      let (_, term), sortMap, ops = aux objv fref sortMap ops in
      term, sortMap, ops
    | _ -> err ""

and genVs env bvs vs out sortMap ops =
  match vs with
    | [] -> List.rev out, sortMap, ops
    | v::rest ->
      let (term, sortMap, ops) = value2term env bvs v sortMap ops in
      genVs env bvs rest (term::out) sortMap ops

(* translate T<ts, vs> to App(name', [|vs|]) *)
and tconcrete2term env bvs name ts vs sortMap ops = 
  let instname = genTConcreteName name ts in
  let (terms, sortMap, ops) = genVs env bvs vs [] sortMap ops in
  let sortMap, ops =
    if existsFun instname ops
    then sortMap, ops  (* instantiation exists *)
    else (* create a new instantiation *)
      ((*pr "tconcrete2term: Generating ops for %s\n" instname;*)
      let newcdecl = instantiateCdecl env (name, ts) in
      (*let _ = pr "\n instantiated class: \n %s \n" (strClassDecl newcdecl) in*)
      genOps env newcdecl (sortMap, ops)) in
  App(instname, List.toArray (terms)), sortMap, ops

  and type2term env bvs t sortMap ops =
  let rec getArgs tfun args sortMap ops =
    match tfun with
      | TType_dep(tf, v) ->
        let term, sortMap, ops = value2term env bvs v sortMap ops in
        getArgs tf (term::args) sortMap ops
      | TType_var tvar -> 
        App(fst tvar, Array.ofList(args)), sortMap, ops
      | _ -> pr "type2term::getArgs: invalid tfun %s\n" (strType tfun);
             raise Impos in
   let rec aux tconcrete bvs sortMap ops =
     let strtconcrete = strTypeConcrete tconcrete in
     let genProp tname ts vs =
       let prop, sortMap, ops = tconcrete2term env bvs tname ts vs sortMap ops in
       prop, sortMap, ops in
     (* Forall(Exists)[t1;\bvd:t1.t2] -> forall(exists)(sort_t1, bvd, sort_t2 *)
     let genForallExists isForall ts bvs sortMap ops = 
       match ts with
         | [_; TType_fun(bvdopt, t1, (TType_concrete t2))] -> (* parameters *)
           let bvs, bvname = (match bvdopt with None -> bvs, "" | Some bvd -> (snd bvd, t1)::bvs, (fst bvd)) in
           let sort, sortMap, ops = sortOfType t1 sortMap ops in
           let term, sortMap, ops = aux t2 bvs sortMap ops in
           let op = if isForall then Forall([], [|sort|], [|bvname|], term) else Exists([], [|sort|], [|bvname|], term) in
           op, sortMap, ops
         | _ -> pr "form2term: %s\n" strtconcrete; raise Impos in
     match tconcrete with
       | (["Prims"; "pf"], _, [Targ(TType_concrete tconc)], _) ->
         (* remove pf, look at the type argument of pf *)
         aux tconc bvs sortMap ops 
       |  (["Prims"; "E2P"], _, [Targ t], _)
       | (["Prims"; "pf"], _, [Targ t], _) ->
         (* remove E2P/pf, look at the type argument *)
         type2term env bvs t sortMap ops
       | (["Prims"; "Forall"], _, args, _)
       | (["Prims"; "ForallA"], _, args, _) ->
         (*let _ = pr "Forall: %s\n" (strTypeConcrete tconcrete) in*)
         genForallExists true (getTys args) bvs sortMap ops
       | (["Prims"; "Exists"], _, args, _) 
       | (["Prims"; "ExistsA"], _, args, _) ->
         genForallExists false (getTys args) bvs sortMap ops
       | (tname, _, args, _) ->
         let ts, vs = getTys args, getVals args in
         let getBop Op tys =
             (match tys with
                | [TType_concrete t1; TType_concrete t2] ->
                  let term1, sortMap, ops = aux t1 bvs sortMap ops in
                  let term2, sortMap, ops = aux t2 bvs sortMap ops in
                  (Op(term1, term2)), sortMap, ops
                | _ -> pr " form2term: getBop %s\n" strtconcrete; raise Impos) in
           let getBopVs Op vs =
             (match vs with
                | [v1; v2] ->
                  let term1, sortMap, ops = value2term env bvs v1 sortMap ops in
                  let term2, sortMap, ops = value2term env bvs v2 sortMap ops in
                  (Op(term1, term2)), sortMap, ops
                | _ ->  pr " form2term: getBopVs %s\n" strtconcrete; raise Impos) in
           (match tname with
              | ["Prims";"l_implies"] -> getBop Imp ts
              | ["Prims"; "l_and"] -> getBop And ts
              | ["Prims"; "l_or"] -> getBop Or ts
              | ["Prims"; "l_iff"] -> getBop Iff ts
              | ["Prims"; "Eq"] -> getBopVs Eq vs
              | ["Prims"; "l_not"] ->
                (match ts with
                  | [TType_concrete t] ->
                    let prop, sortMap, ops = aux t bvs sortMap ops in
                    (Not prop), sortMap, ops
                  | _ ->  pr " form2term: %s, tname = %s \n" strtconcrete (String.concat "." tname); raise Impos)
              | _ -> (* final proposition, like "CanWrite<Admin, f>" *)
                genProp tname ts vs) in
  match t with
    | TType_concrete tconcrete -> aux tconcrete bvs sortMap ops
    | TType_dep _ -> getArgs t [] sortMap ops
    | TType_name(name, _) -> 
      (match (fst name) with
         | ["Prims"; "True"] -> True, sortMap, ops 
         | ["Prims"; "False"] -> False, sortMap, ops
         | _ -> pr "type2term: unexpected name %s\n" (strType t); raise Impos)
    | _ -> pr "type2term: %s\n" (strType t); raise Impos

  and doForm env form sortMap ops =
    (* example: pf<\f.pf<CanWrite<Admin, f>>>   *)
    (* => Forall([|fsort|], [| "f" |], App("FileAC.CanWrite", *)
    (*                                     [|FreeV("Authentication.Admin", psort); *)
    (*                                     BoundV(0, fsort) |])) *)
    let prop, sortMap, ops = type2term env [] form sortMap ops in
    sortMap, (Assume(prop, None, AOther))::ops

(* generate ops from a class declaration *)
and genOps env (tcdecl: tClassDecl) (sortMap_ops:list<string*int> * list<op>)
    : list<string*int> * list<op> =
  let (sortMap, ops) = sortMap_ops in
  let argSorts vvars sortMap ops =
      let rec aux sortMap ops out = function
          vv::tl -> let (sort, sortMap, ops) = sortOfType (snd vv) sortMap ops in
                    aux sortMap ops (sort::out) tl
        | _ -> List.rev out, sortMap, ops in
      aux sortMap ops [] vvars in
  if ((getTvars tcdecl) != []) then sortMap, ops (* polymorphic, no need to generate ops *)
  else let vvars = getVvars tcdecl in
  match tcdecl.attr with
    | Prop -> (* generate DefPred *)
      let (sorts, sortMap, ops) = argSorts vvars sortMap ops in
      sortMap, ((DefPred(tcdecl.namestring, Array.ofList sorts, None))::ops)
    | Axiom -> (* generate Assume from D<[], vvars>: T<ts, vs>*) 
      (match tcdecl.extends with
         | Some form -> doForm env form sortMap ops
         | None -> pr "GenOps(Axiom): %s" (tcdecl.namestring); raise Impos)
    | NoAttr ->
        let genFun name ts =
          let tcname = genTConcreteName name ts in
          let (tsort, sortMap, ops) = findAddSort tcname sortMap ops in
          let (sorts, sortMap, ops) = argSorts vvars sortMap ops in
          let newop = DefFun(tcdecl.namestring, Array.ofList sorts, tsort, None) in
          (*let _ = pr "\n new ops = %A\n" newop in*)
          let ops = newop::ops in
          let tcFuncName = tyconFuncName tcname in
          let ops = if (existsFun tcFuncName ops) then ops
                    else (DefFun(tcFuncName, [|tsort|], intSort, None))::ops in
          (* forall xs:sorts, kind_tc (tcdecl.namestring xs) = some new i *)
          (* for differentiating data constructors *)
          let n = List.length vvars in
          let ax = Assume(Forall([], Array.ofList sorts, Array.ofList(List.map fst vvars),
                          Eq(App(tcFuncName, 
                                 [|App(tcdecl.namestring, 
                                     Array.ofList(map1N n (fun z -> BoundV(n-z, List.nth sorts (z-1)))))|]), 
                             Integer (getDCount()))), 
                          None, AOther) in      
          tsort, sortMap, ax::ops in
        (match tcdecl.extends with
           | None -> (* types, generate DefSort *)
             if (List.length(tcdecl.fields) > 0) then
               genRecdAxioms tcdecl sortMap ops
             else let (_, sortMap, ops) = findAddSort tcdecl.namestring sortMap ops in
             sortMap, ops
           | Some (TType_concrete(name, ks, args, _)) -> (* data constructors, generate DefFun *)
             if (isDepArrowName name) then sortMap, ops  (* ignore C:DepArrow... *)
             else if (isDepTupleName name) then
               (* genearate special axioms for tuples *)
               let ts = getTys args in
               (match ts with
                  | [t1; t2] ->
                    let t2 =
                      (match t2 with
                         | TType_fun(_, _, tbody) -> tbody
                         | _ -> t2) in
                    let sort1, sortMap, ops = sortOfType t1 sortMap ops in
                    let sort2, sortMap, ops = sortOfType t2 sortMap ops in
                    let tupleName = genTConcreteName name ts in
                    let tsort, sortMap, ops = findAddSort tupleName sortMap ops in
                    let proj1Name = String.concat "_" [Const.dcil_proj_one_name; strType t1; strType t2] in
                    let proj2Name = String.concat "_" [Const.dcil_proj_two_name; strType t1; strType t2] in
                    let proj1 term = App(proj1Name, [|term|]) in
                    let proj2 term = App(proj2Name, [|term|]) in
                    let ax1 = (* eq(x, y) => eq(x.one, y.one) && eq (x.two, y.two) *)
                      let bv1, bv2 = BoundV(0, tsort), BoundV(1, tsort) in
                      Assume(Forall([], [|tsort; tsort|], [|"tup1";"tup2"|],
                                    Imp(Eq(bv1, bv2),
                                        And(Eq(proj1 bv1, proj1 bv2),
                                            Eq(proj2 bv1, proj2 bv2)))),
                              None,
                              AOther) in
                    let ax2 = (* x = tuple(x,y).proj_one && y = tuple(x,y).proj_two *)
                      let bvx, bvy = BoundV(0, sort1), BoundV(1, sort2) in
                      let tupleTerm = App(tcdecl.namestring, [|bvx; bvy|]) in
                      Assume(Forall([], [|sort1; sort2|], [|"x"; "y"|],
                                    And(Eq(proj1 tupleTerm, bvx),
                                        Eq(proj2 tupleTerm, bvy))),
                             None,
                             AOther) in                      
                    sortMap, ax1::ax2::
                             (DefFun(tcdecl.namestring, [|sort1; sort2|], tsort, None)) ::
                             (DefFun(proj1Name, [|tsort|], sort1, None)) :: 
                             (DefFun(proj2Name, [|tsort|], sort2, None)) ::
                             ops
                  | _ -> pr "genOps(datacon): %s" (tcdecl.namestring); raise Impos)
             else (* get the sort for the result type constructor *)
               let _, sortMap, ops = genFun name (getTys args) in
               sortMap, ops
           | Some (TType_name(tname, _)) -> let _, sortMap, ops = genFun (fst tname) [] in sortMap, ops
           | _ -> sortMap, ops)
    | _ -> raise Impos
 
(* generate record axioms and DefFuns *)
and genRecdAxioms tcdecl sortMap ops =
  (* for t{f1:t1, ..., fn:tn}: def sort *)
  let tsort, sortMap, ops  = findAddSort (tcdecl.namestring) sortMap ops in
  (* deffun for ctor record_name.ctor *)
  let ctorName = tcdecl.namestring in
  let getSorts flds =
    let rec aux result sortMap ops flds =
      match flds with
        | [] -> List.rev result, sortMap, ops 
        | ((_, t)::rest) -> let sort, sortMap, ops = sortOfType t sortMap ops in
                            aux (sort::result) sortMap ops rest in
    aux [] sortMap ops flds in
  let sortls, sortMap, ops = getSorts tcdecl.fields in
  let sorts = List.toArray sortls in
  let fieldSyms = Array.of_list (List.map fst (tcdecl.fields)) in
  let n = List.length (tcdecl.fields) in
  let fieldBvs = Array.of_list(map1N n (fun z -> BoundV(n-z, List.nth sortls (z-1)))) in (* !! *)
  let namels = List.map (fun (fname, _) -> gen_proj_fi_name (tcdecl.namestring) fname) tcdecl.fields in
  let ops = (DefFun(ctorName, sorts, tsort, None))::ops in
  (* deffun and axiom for each field projection *)
  let rec geni i ops =
    if (i < 0) then ops
    else (* define projection fun for the ith field *)
      let defFunOp = DefFun(namels.[i], [| tsort |], sortls.[i], None) in
      (* define the axiom forall x1..xn, proj_t_fi ({f1=x1..fn=xn}) = xi *)
      let axiomi = Assume(Forall([], sorts, fieldSyms,
                          Eq(App(namels.[i], [|App(ctorName, fieldBvs)|]),
                             fieldBvs.[i])),
                          None, AOther) in
      geni (i-1) (axiomi :: defFunOp :: ops)
  in 
  let ops = geni (n-1) ops in
  (* define the axiom forall r1, r2, r1 = r2 iff proj_t_fi(r1) = proj_t_fi(r2) forall fi *)
  let rec1, rec2 = BoundV(0, tsort), BoundV(1, tsort) in
  let axiomIff =    
    let eqs = map1N n (fun i -> Eq(App(namels.[i-1], [| rec1 |]), App(namels.[i-1], [| rec2 |]))) in
    List.fold_right (fun eqi form -> And(eqi, form)) eqs True
  in
  let ops = (Assume(Forall([], [|tsort; tsort|], [|"r1"; "r2"|],
                        Iff(Eq (rec1, rec2), axiomIff)),
                 None, AOther)) :: ops in                                    
  sortMap, ops

(* generate DefPred(tvar, [|t1, ..., tn|], None) for tvar: t1 => ... => tn => * *)
let genPreds env tvar sortMap_ops: List<string*int> * list<op> =
  let sortMap, ops = sortMap_ops in
  let rec getArgs args k sortMap ops =
    match k with
      | TKind_arrow(t, k') ->
        let sort, sortMap, ops = sortOfType t sortMap ops in
        getArgs (sort::args) k' sortMap ops
      | TKind_prop
      | TKind_erasable
      | TKind_star -> List.rev args, sortMap, ops
      | TKind_affine 
      | TKind_karrow _
      | TKind_var _ -> [], sortMap, ops  in
  match (getArgs [] (snd tvar) sortMap ops) with
    | ([], _, _) -> sortMap, ops
    | (args, sortMap, ops) -> (* generate a pred *)
      sortMap, (DefPred(fst tvar, Array.ofList args, None)::ops)

(* generate ops for "var = v" *)
let genEqOps env eq sortMap_ops: list<string*int> * list<op> =
  let var, v = eq in
  (*let _ = pr "--\n %s = %s" (strVvar var) (strVal v) in*)
  let v = unwrapVal v in
  let sortMap, ops = sortMap_ops in
  let genFun var = (*introducing a new var. DefFun(var_name, [||], sort, None)*)
    let sort, sortMap, ops = sortOfType (snd var) sortMap ops in
    let sortMap, ops = match (snd var) with
      | TType_refine (bvd, t, formula, _, insts) ->
        (* add formula to the context *)
        doForm env (substType (addVvarMap emptyTyMap (snd bvd, t) (TVal_var var)) formula) sortMap ops
      | _ -> sortMap, ops in
    sortMap, (DefFun(fst var, [||], sort, None))::ops in
  let genEq var v2 = (* generate Assume(Eq(FreeV(var), v2), None, AOther) *)
    let sortMap, ops = 
      if existsFun (fst var) ops then sortMap, ops
      else genFun var in
    let term1, sortMap, ops = value2term env [] (TVal_var var) sortMap ops in
    let term2, sortMap, ops = value2term env [] v2 sortMap ops in
    (sortMap, (Assume(Eq(term1, term2), None, AOther))::ops) in
  match v with
    | TVal_var var' ->
      if fst var = fst var' then      (* x=x, introducing a new var *)
        genFun var
      else genEq var v
    | _ -> genEq var v

let empty_info = {envn=Tcenv.empty_env; binders=[]}
let modSortMap: sortMapTy ref  = ref []
let modOps: List<op> ref = ref []

let primsOps = (DefFun(stringPrimsTrue,[||], boolSort, None)) ::
              (DefFun (stringPrimsFalse, [||], boolSort, None)) ::
              (Assume(Not (Eq (termTrue, termFalse)),
                          None,
                          ANeqBool)) ::
              (DefFun (stringPrimsUnit, [||], unitSort, None)) ::
              (Assume(Forall ([], [| unitSort; unitSort |], [| "x"; "y" |],
                                  Eq(BoundV(0, unitSort), BoundV(1, unitSort))), 
                          None, AOther)) ::
              (DefFun(stringIntCon, [|intSort|], PrimsIntSort, None)) ::
              (Assume(Forall([], [|intSort; intSort|], [|"i"; "j"|],
                                 Iff(Eq(App(stringIntCon, [|BoundV(0, intSort)|]), 
                                        App(stringIntCon, [|BoundV(1, intSort)|])),
                                     Eq(BoundV(0, intSort), BoundV(1, intSort)))),
                          None, AOther)) ::  (* (IntCon i = IntCon j) <=> (i  = j) *) 
           ( List.map (fun (name, sort) -> (DefSort(sort, Some name))) primsSortMap)

let process_cenv env = 
    (* handle class declarations in cenv *)
    let foldCdecls cdecls sortMap_ops = Hashtbl.fold (fun name -> genOps env) cdecls sortMap_ops in
    let sortMap, ops = List.fold_right foldCdecls (env.cenv) (primsSortMap, primsOps) in 
    modSortMap := sortMap; modOps := ops;
    ignore(assertOps empty_info ops "dcil")

let createOps env insts =
    (* handle instantiations *)
    let sortMap, ops = !modSortMap, !modOps in
    let instantiatedCdecls = List.map (instantiateCdecl env) insts in
    let sortMap, ops = (* get all ops from instantiated class declarations *)
      List.fold_right (genOps env) instantiatedCdecls (sortMap, ops) in
    let sortMap, ops = List.fold_right (genPreds env) (env.kenv) (sortMap, ops) in
    let sortMap, ops = List.fold_right (genEqOps env) (env.tenv) (sortMap, ops) in
    sortMap, ops

let check ops =
  "dcil z3" ^^ lazy
  let res = processOps empty_info (List.rev ops) "ProofDcil" in
  let _ = ProofState.pop () in 
  match res with
      | None -> false
      | Some(b, _) -> b

let prove_dcil_formula (env:env) 
    (form:tType) 
    (insts: list<tClassName * list<tType>>): bool = 
    "dcil formula" ^^ lazy (
    bumpQueryCount();
    let _ = ProofState.push () in //NIK: this makes everything a "Foreground" operation; i.e. no query carried state
    let sortMap, ops = createOps env insts in
    let prop, sortMap, ops = type2term env [] form sortMap ops in
    let ops = Query(prop)::ops in
    (*let _ = pr "*******************%s***************\n"; List.iter (fun op -> pr "%A\n" op) ops in *)
    check ops)

let prove_eq env v1 v2: bool =
  "dcil eq" ^^ lazy (
  try 
 bumpQueryCount();
  (*let _ = pr "\n Proving %s == %s" (strVal v1) (strVal v2) in*)
  let _ = ProofState.push() in
  let sortMap, ops = createOps env [] in
  (*let _ = pr " ************ assume *********\n"; List.iter(fun op -> pr "%A\n" op) ops in *)
  let t1, sortMap, ops = value2term env [] v1 sortMap ops in
  let t2, sortMap, ops = value2term env [] v2 sortMap ops in
  (*let _ = pr " *** need to approve %A \n " (Eq(t1, t2)) in*)
  let ops = Query(Eq(t1, t2))::ops in
  check ops
  with e -> (Util.warn "Failed to prove %s = %s\n" (strVal v1) (strVal v2); false) )
