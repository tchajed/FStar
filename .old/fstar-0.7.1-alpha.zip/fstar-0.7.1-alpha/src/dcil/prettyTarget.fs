#light "off"
// (c) Microsoft Corporation. All rights reserved
module Microsoft.FStar.PrettyTarget

(* pretty-printer of the target *)
open Sugar
open Microsoft.FStar.Target

let pr = Printf.printf
let spr = Printf.sprintf

(* ====================== utilities ================= *)
let strIdent id = id
let strLident lid = String.concat "." lid
let strBvdef bvdef = strIdent (snd bvdef)
let strClassName classname = if !Options.verbose_names then spr "<n>%s</n>" (strLident classname) else (strLident classname)
let strFieldName fieldname = fieldname
let strMethodName methodname = methodname
  
let strVisibility (vis: tVisibility) =
  match vis with
    | TVis_public -> "pub"
    | TVis_internal -> "intern"

let rec strTvar (tvar : tVar<tKind>) : string =
  let (id, k) = tvar in 
    spr "%s" (strIdent id) 

and strKvar (kvar: tKvar) =
  let (id, _) = kvar in
  strIdent id

and strVvar (vvar: tVar<tType>) =
  let (id, t) = vvar in 
  spr "%s" (strIdent id)

and strTname (tname: tName<tKind>) =
  let (lid, k) = tname in spr "%s" (strLident lid)
(*  spr "%s: %s" (strLident lid) (strKind k) *)

and strVname (vname: tName<tType>) =
  let (lid, ty) = vname in spr "%s" (strLident lid)
(*  spr "%s: %s" (strLident lid) (strType ty) *)

and strKind (knd: tKind) =
  match knd with
    | TKind_star -> "*"
    | TKind_affine -> "A"              
    | TKind_prop -> "P"
    | TKind_erasable -> "E"
    | TKind_arrow (t, knd') -> (strType t) ^ " -> " + (strKind knd')
    | TKind_karrow (k1, k2) -> (strKind k1) ^ " -> " + (strKind k2)
    | TKind_var kvar -> spr "Kvar(%s)" (strKvar kvar)
    | _ -> "unknown kind"

and strType (t: tType): string =
  match t with
    | TType_index u -> spr "!%d" u
    | TType_var tvar -> strTvar tvar
    | TType_name (name,_) -> strTname name
    | TType_fun (bvdopt, t1, t2) ->
      (match bvdopt with
        | None -> spr "%s -> %s" (strType t1) (strType t2)
        | Some bvd -> spr "\%s:%s -> %s" (strBvdef bvd) 
                      (strType t1) (strType t2) )
    | TType_tfun (bvd, kind, tbody) ->
        spr "\%s::%s. %s" (strBvdef bvd) (strKind kind) (strType tbody)
    | TType_concrete tconcrete ->
      let cname, _kinds, args, _ = tconcrete in
        (match cname with
        | ["DepArrowSS"] ->
          (match args with
             | [_; Targ targ] -> strType targ
             | _ -> raise ReportedError)
        | _ -> strTypeConcrete tconcrete)
    | TType_dep (tfun, v) -> spr "%s<%s>" (strType tfun) (strVal v)
    | TType_tapp (tfun, targ) -> spr "%s[%s]" (strType tfun) (strType targ)
    | TType_affine ty -> spr "!%s" (strType ty)
    | TType_refine (bvd, t, formula, src_formula, insts) -> spr "%s:%s{%s}%s" (strBvdef bvd) (strType t) (strType formula) (strInsts insts) 
    | TType_inferred _ -> "inferred"
    | _ -> "unknown type"

and strSmallType (t: tType): string =
  match t with
    | TType_index u -> spr "!%d" u
    | TType_var tvar -> strTvar tvar
    | TType_name (name,_) -> strTname name
    | TType_fun (bvdopt, t1, t2) ->
      (match bvdopt with
        | None -> spr "%s->%s" (strSmallType t1) (strSmallType t2)
        | Some bvd -> spr "\%s:%s->%s" (strBvdef bvd) 
                      (strSmallType t1) (strSmallType t2) )
    | TType_tfun (bvd, kind, tbody) ->
        spr "\%s::%s.%s" (strBvdef bvd) (strKind kind) (strSmallType tbody)
    | TType_concrete tconcrete ->
      let cname, _kinds, args, _ = tconcrete in
        (match cname, args with
           | ["DepArrowSS"], [Targ t1; Targ t2] 
           | ["DepArrowAS"], [Targ t1; Targ t2] 
           | ["DepArrowSA"], [Targ t1; Targ t2]  
           | ["DepArrowAA"], [Targ t1; Targ t2]  -> 
               (match t2 with 
                 | TType_fun(xopt, _, t2) -> 
                     (match xopt with 
                       | None -> spr "%s->%s"  (strSmallType t1) (strSmallType t2)
                       | Some x -> spr "%s:%s->%s" (strBvdef x) (strSmallType t1) (strSmallType t2))
                 | _ -> spr "%s->%s" (strSmallType t1) (strSmallType t2))
           | ["DepTuple2SS"], [Targ t1; Targ t2]  
           | ["DepTuple2AS"], [Targ t1; Targ t2]  
           | ["DepTuple2SA"], [Targ t1; Targ t2]  
           | ["DepTuple2AA"], [Targ t1; Targ t2]   -> 
               (match t2 with 
                  | TType_fun(xopt, _, t2) -> 
                      (match xopt with 
                         | None -> spr "(%s*%s)"  (strSmallType t1) (strSmallType t2)
                         | Some x -> spr "(%s:%s*%s)" (strBvdef x) (strSmallType t1) (strSmallType t2))
                  | _ -> spr "%s*%s" (strSmallType t1) (strSmallType t2))
           | _ -> strSmallTypeConcrete tconcrete)
    | TType_dep (tfun, v) -> spr "%s<%s>" (strSmallType tfun) (strSmallVal v)
    | TType_tapp (tfun, targ) -> spr "%s[%s]" (strSmallType tfun) (strSmallType targ)
    | TType_affine ty -> spr "!%s" (strSmallType ty)
    | TType_refine (bvd, t, formula, src_formula, insts) -> spr "%s:%s{%s}%s" (strBvdef bvd) (strSmallType t) (strSmallType formula) (* src_formula *) (strInsts insts)
    | TType_inferred _ -> "inferred"
    | _ -> "unknown type"

and strSmallTypeConcrete (tconcrete: tTypeConcrete) =
  let (classname, ks, args, _) = tconcrete in
  if (List.length ks = 0 && List.length args = 0) then strClassName classname
  else
  let strKinds = String.concat "," (List.map strKind ks) in
  let strArgs = String.concat "," (List.map (function |Targ t -> strSmallType t
                                                       |Varg v -> strSmallVal v) args) in
  if !Options.verbose_names then 
      spr "<ttc>%s<k>%s</k>%s</ttc>" 
          (strClassName classname) strKinds strArgs 
    else spr "%s[%s;%s]" (strClassName classname) strKinds strArgs

and strSmallVal v =
  match v with
    | TVal_var vvar -> strVvar vvar
    | TVal_obj (tconcrete, vs) ->
      let strVs = String.concat "," (List.map strSmallVal vs) in
      spr "%s(%s)" (strSmallTypeConcrete tconcrete) strVs
    | TVal_constant cons -> (cons.ToString())
    | TVal_ldfld (v, fname) -> spr "%s.%s" (strSmallVal v) fname
    | TVal_uvar uvar -> strUvar_castVal uvar
    | TVal_logic_fun(vf, vs) -> spr "%s(%s)" (strVname vf) (String.concat "," (List.map strSmallVal vs))
    | _ -> "unknown val"

and strInsts insts =
  String.concat ";\n" (List.map (fun (name, tys) -> spr "%s<%s>" (strClassName name) (String.concat "," (List.map strType tys))) insts)

and strTypeConcrete (tconcrete: tTypeConcrete) =
  let (classname, ks, args, _) = tconcrete in
  let strKinds = String.concat "," (List.map strKind ks) in
  let strArgs = String.concat "," (List.map (function |Targ t -> strSmallType t
                                                       |Varg v -> strSmallVal v) args) in
  if (List.length ks = 0 && List.length args = 0) then strClassName classname
  else if !Options.verbose_names then 
      spr "<ttc>%s<k>%s</k>%s</ttc>" 
          (strClassName classname) strKinds strArgs
    else spr "%s[ %s; %s]" (strClassName classname) strKinds strArgs

and strVal v =
  match v with
    | TVal_var vvar -> strVvar vvar
    | TVal_obj (tconcrete, vs) ->
      let strVs = String.concat "," (List.map strVal vs) in
      spr "%s(%s)" (strTypeConcrete tconcrete) strVs
    | TVal_constant cons -> (cons.ToString())
    | TVal_ldfld (v, fname) -> spr "%s.%s" (strVal v) fname
    | TVal_uvar uvar -> strUvar_castVal uvar
    | TVal_logic_fun (vf, vs) -> spr "%s(%s)" (strVname vf) (String.concat "," (List.map strVal vs))
    | _ -> "unknown val"

and strUvar_castVal uvar =
  match Unionfind.find uvar with
    | TUval v -> spr "uvar(%s)" (strVal v)
    | TUcast (t, v) -> spr "cast<%s>%s" (strType t) (strVal v)

let strMethodRef(mname, targs) =
  spr "%s<%s>" mname (String.concat "," (List.map strType targs))

let strPrimop bop =
  match bop with
    | AND -> "&&"
    | OR -> "||"
    | ADD -> "+"
    | SUB -> "-"
    | MUL -> "*"
    | DIV -> "/"
    | _ -> "unknown bop"

let rec strExp (e: tExp) =
  match e with
    | TExp_val v -> strVal v
    | TExp_name (n,_) -> strVname n
    | TExp_ldfld (vobj, fname) -> spr "%s.%s" (strVal vobj) fname
    | TExp_extern_call ((eref:externref), methodref, vargs) -> 
        let strVargs = String.concat "," (List.map strVal vargs) in
          spr "extern call %s::%s.%s (%s)"
            eref.dll
            (Sugar.text_of_lid eref.classname) 
            (strMethodRef methodref) strVargs 
    | TExp_call (vobj, eargs, mref) ->
      let strEargs = String.concat "," (List.map strVal eargs) in
      spr "call %s.%s(%s)" (strVal vobj) (strMethodRef mref) strEargs 
    | TExp_let (vvar, e1, e2, b) ->
      spr "\nlet (%s: %s)  = %s \n  in %s" (if !b then strVvar vvar else strIdent (fst vvar)) (strType (snd vvar)) (strExp e1) (strExp e2)
    | TExp_isinst (v, tconcrete_e_list, edefault, t) ->
      let rec prBranches tes =
        match tes with
          | [] -> spr "_ -> %s " (strExp edefault)
          | (cname, ks, pats, isGADT, e) :: rest ->
            spr "\n    %s<%s; %s> %s %s \n %s"
             (strClassName cname)
             (String.concat "," (List.map strKind ks))
             (String.concat "," (List.map (function | Ptype t -> strType t 
                                                    | Pfield var -> spr " %s:%s" (strVvar var) (strType (snd var))
                                                    | Pvar var -> spr " %s:%s" (strVvar var) (strType (snd var)))
                                 pats))
             (if isGADT then "-G->" else "->")
             (strExp e)
            (prBranches rest) in
      spr "\n %s isinst %s : %s \n" (strVal v) (prBranches tconcrete_e_list) (strType t)
    | TExp_cond(eb, et, ef) ->
      spr "if(%s) then %s else %s" (strExp eb) (strExp et) (strExp ef)
    | TExp_primop(bop, vl) -> 
      spr "%s (%s)" (strPrimop bop) (String.concat ", " (List.map strVal vl))
    | TExp_ascribed(e, t) -> spr "%s: %s" (strExp e) (strType t)
    | TExp_bot -> "bot"
    | _ -> "unknown exp"

let strFieldDecl fdecl = spr "%s: %s" (fst fdecl) (strType (snd fdecl))

let strStaticFieldDecl sfdecl =
  let (fname, t, expopt) = sfdecl in
  match expopt with
    | None -> spr "%s: %s" fname (strType t)
    | Some e -> spr "%s: %s = %s" fname (strType t) (strExp e)

let strMethodDecl (mdecl: tMethodDecl) =
  let (retTy, mname, tvars, mparams, body) = mdecl in
  let strBody =
    match body with
      | None -> ""
      | Some e -> strExp e in
  spr "%s %s<%s>(%s){%s}" 
  (strType retTy)
  mname
  (String.concat "," (List.map strTvar tvars))
  (String.concat "," (List.map strVvar mparams))
  strBody

let strEvidence evs =
  String.concat "," (List.map (fun ev -> 
                                 match ev with
                                   | TEv_val(var, v) -> spr "%s -> %s" (strVvar var) (strVal v)
                                   | TEv_type(tvar, t) -> spr "%s -> %s" (strTvar tvar) (strType t)) evs)
  
let strAttr attr =
  match attr with
    | Axiom -> "axiom"
    | Prop -> "prop"
    | _ -> ""

let strClassDecl (cdecl:tClassDecl) =
  let strExtends =
    match cdecl.extends with
      | None -> ""
      | Some tsuper -> ": " ^ (strType tsuper) in
  let strckind = 
    match cdecl.kind with
      | None -> ""
      | Some kind -> " :: " ^ (strKind kind) in
  spr "\n  === %s class name: %s:%s, %s \n    vars: %s \n  evidences: %s \n    extends: %s \n    fields: %s \n    staticFields: %s \n methods: %s :: %s\n externref: %A\n"  
  (strVisibility cdecl.visibility)
  (strAttr cdecl.attr)
  (strClassName cdecl.name) (cdecl.namestring)
  (String.concat "," (List.map (function | Tvar tv -> strTvar tv 
                                         | Vvar vv -> spr "%s:%s\n" (strVvar vv) (strType (snd vv))) cdecl.vars)) 
  (strEvidence cdecl.evidences)
  strExtends
  (String.concat "," (List.map strFieldDecl cdecl.fields))
  (String.concat ",\n" (List.map strStaticFieldDecl cdecl.staticFields))
  (String.concat "," (List.map strMethodDecl cdecl.methods))
  strckind
  cdecl.externref

let strLidentOpt lidOpt =
  match lidOpt with
    | None -> ""
    | Some lid -> strLident lid

let printModule (m:tModule) = 
  pr "\n======== module %s: %s ==========" 
     (strLident m.name) (strLidentOpt m.extends);
  Hashtbl.iter (fun _cn cdecl -> (pr "\n ====== class decl %s" (strClassDecl cdecl))) (m.decls);
  Hashtbl.iter (fun _cn cdecl -> (pr "\n >>>>>> extern class decl %s" (strClassDecl cdecl))) (m.externs);
  List.iter (fun mdecl -> (pr "\n ****** extern method decl %A" mdecl)) m.externMethods;
  pr "\n === module class = %s" (strClassDecl m.modCdecl);
  let _ = match m.entry with 
      None -> ()
    | Some e -> 
        pr "\n======== entry point ==========";
        printfn "%A" e;
        pr "\n%s" (strExp e) in
    pr "\n=========== end of %s ==========" (strLident m.name);

