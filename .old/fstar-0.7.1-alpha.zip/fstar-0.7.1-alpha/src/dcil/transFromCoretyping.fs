#light "off"
// (c) Microsoft Corporation. All rights reserved

// Translation from Coretyping types/values/terms to RDCIL
module Microsoft.FStar.TransFromCoretyping

open Util
open Target
open TargetUtil
open PrettyPrintCoretyping
open CoretypingUtil

let pr = Printf.printf
let spr = Printf.sprintf

exception TransCoreTypingErr of string
let err msg = raise (TransCoreTypingErr msg)
let errK msg k = err (spr "transKind: %s in translating %s" msg (prettyKind k))
let errT msg t = err (spr "transType: %s in translating %s" msg (prettyTyp t))
let errV msg v = err (spr "transValue: %s in translating %s" msg (prettyValue v))
let errE msg e = err (spr "transExp: %s in translating %s" msg (prettyExp e))

let genClassName () = ["C" ^ (newSym())]
  
let rec convertList (lst: Prims.list<'a>) : 'a list =
  match lst with
    | :? Prims.Nil<'a> -> []
    | :? Prims.Cons<'a> as cons ->
      let x, rest = cons.field_1, cons.field_2 in
      x::(convertList rest)

let rec transKind (transenv: transEnv) (k:Terms.kind): tKind * transEnv = match k with
  | K_Base bk ->
    (match bk with
       | BK_Comp -> TKind_star, transenv
       | BK_Prop -> TKind_prop, transenv
       | BK_Erase -> TKind_erasable, transenv
       | BK_Afn -> TKind_affine, transenv)
  | K_ProdK(bvar, k1, k2) -> (* ignored bvar *)
    let newK1, transenv = transKind transenv k1 in
    let newK2, transenv = transKind transenv k2 in
    TKind_karrow(newK1, newK2), transenv
  | K_ProdT(bvar, t, k2) -> (* ignored bvar *)
    let newT, transenv = transType transenv t in
    let newK2, transenv = transKind transenv k2 in
    TKind_arrow(newT, newK2), transenv
  | _ -> errK "unexpected kind" k

and transType transenv t: tType * transEnv = match t with
  | T_VApp(t1, v) ->
    let newT1, transenv = transType transenv t1 in
    let newV, transenv = transValue ([], []) transenv v in
    TType_dep(newT1, newV), transenv
  | T_App(t1, t2) ->
    let newT1, transenv = transType transenv t1 in
    let newT2, transenv = transType transenv t2 in
    TType_tapp(newT1, newT2), transenv
  | T_Prod(bvar, t1, t2) -> (* DepArrow *)
    let newT1, transenv = transType transenv t1 in
    let newT2, transenv = transType transenv t2 in
    let tfun = TType_fun(Some (bvar, bvar), newT1, newT2) in
    let newK1, transenv = match t1 with
      | T_Ascribe(_, k1) -> transKind transenv k1
      | _ -> TKind_star, transenv in
    let newK2, transenv = match t2 with
      | T_Ascribe(_, k2) -> transKind transenv k2
      | _ -> TKind_star, transenv in
    let tconc = tClassDepArrow.name, [newK1; newK2], [Targ newT1; Targ tfun], None in
    TType_concrete tconc, transenv
  | T_ProdK(tvar, k, t2) -> (* All *)
    let newK, transenv = transKind transenv k in
    let newK2, transenv = match t2 with
      | T_Ascribe(_, k2) -> transKind transenv k2
      | _ -> TKind_star, transenv in
    let newT2, transenv = transType transenv t2 in
    let tfun = TType_tfun((tvar, tvar), newK, newT2) in
    TType_concrete(tClassAll.name, [newK; newK2], [Targ tfun], None), transenv
  | T_Ref(bvar, t1, t2) ->
    let newT1, transenv = transType transenv t1 in
    let newT2, transenv = transType transenv t2 in
    TType_refine((bvar, bvar), newT1, newT2, "", []), transenv
  | T_Lam(bvar, t1, t2) ->  
    let newT1, transenv = transType transenv t1 in
    let newT2, transenv = transType transenv t2 in
    TType_fun(Some (bvar, bvar), newT1, newT2), transenv
  | T_Afn(t2) ->
    let newT2, transenv = transType transenv t2 in
    TType_affine(newT2), transenv
  | T_Ascribe(T_Var gvar, k) ->
    let newK, transenv = transKind transenv k in
    (match gvar with
      | GV_Bound bvar -> TType_var (bvar, newK), transenv
      | GV_Free fvar -> TType_name(([fvar], newK), None), transenv)
  | T_Ascribe(T_Ind name, k) -> 
    let newK, transenv = transKind transenv k in
    TType_name(([name], newK), None), transenv
  | T_Ascribe(t1, k2) -> transType transenv t1
  | T_Var _
  | T_Ind _
  | _ -> errT "unexpected type" t


and transValue (freevs: string list * string list) transenv v = match v with
  | V_Boxed(boxname, v) -> transValue freevs transenv v
  | V_Const(cname, ts, vs) ->
    let newTs, transenv =
      List.fold_left (fun (newts, transenv) t ->
                      let newt, transenv = transType transenv t in
                      newt::newts, transenv) ([], transenv) (convertList ts) in
    let newVs, transenv =
      List.fold (fun (newvs, transenv) v ->
                      let newv, transenv = transValue freevs transenv v in
                      newv::newvs, transenv) ([], transenv) (convertList vs) in
    let tconc = ([cname], [], (List.map Targ (List.rev newTs))@(List.map Varg (List.rev newVs)), None) in
    TVal_obj(tconc, []), transenv
  | V_Ascribe(v', tv) ->
    (match v', tv with
      | V_Fun(bvar, t, body), t_abs ->
        (match body with
          | E_Ascribe(e, t_body) ->
            let super, transenv = transType transenv t_abs in
            let transenv, ftvs, fvs, isAffine = getFreeVars freevs transenv v in
            let tParam, transenv = transType transenv t in
            let param = (bvar, tParam) in
            (* body *)
            let newE, transEnv = transExp (addFreev freevs bvar) transenv e in
            (* new class for function *)
            let fullname = genClassName() in
            let fullnamestr = String.concat "." fullname in
            let tRetType, transenv = transType transenv t_body in
            let appMethod = (
              tRetType,
              "Invoke",
              [],
              [param],
              Some newE) in
            let newclass = {
              externref = None;
              visibility = TVis_internal;
              attr = NoAttr;
              name = fullname;
              namestring = fullnamestr;
              kvars = [];
              vars = (List.map Tvar ftvs) @ (List.map Vvar fvs);
              evidences = []; (*filterEvidences (currentEvidences()) (ftvs @ fvs);*)
              extends = Some super;
              fields = [];
              staticFields = [];
              methods = [appMethod];
              kind = Some (if isAffine then TKind_affine else TKind_star);
              hasTag=false;
              tagNum=None
            } in
            let tconcrete = (fullname, [],
                             (List.map (fun ftv -> Targ(TType_var ftv)) ftvs)
                             @ (List.map (fun fv -> Varg(TVal_var fv)) fvs),
                             None) in
            TVal_obj(tconcrete, []), addToTransEnv transenv newclass
          | _ -> errV "unascribed function body" v)
      | V_FunT(bvar, k, body), t_tabs ->
        (match body with
          | E_Ascribe(e, t_body) ->
	        let super, transenv = transType transenv t_tabs in
	        let transenv, ftvs, fvs, isAffine = getFreeVars freevs transenv v in
	        let newE, transenv = transExp (addFreeTv freevs bvar) transenv e in
	        let fullname = genClassName() in
	        let fullnamestr = String.concat "." fullname in
	        let tret, transenv = transType transenv t_body in
	        let newK, transenv = transKind transenv k in
	        let tyappMethod = (
	          tret,
	          "TyApp",
	          [(bvar, newK)],
	          [],
	          Some newE
	        ) in
	        let newclass = {
	          externref = None;
	          visibility = TVis_internal;
	          attr = NoAttr;
	          name = fullname;
	          namestring = fullnamestr;
	          kvars = [];
	          vars = (List.map Tvar ftvs) @ (List.map Vvar fvs);
	          evidences = []; (*filterEvidences (currentEvidences()) (ftvs@fvs);*)
              extends = Some super;
	          fields = [];
	          staticFields = [];
	          methods = [tyappMethod];
	          kind = Some (if isAffine then TKind_affine else TKind_star);
	          hasTag = false;
	          tagNum = None
	         } in
	         let tconcrete = (fullname, [],
					          (List.map (fun tv -> Targ(TType_var tv)) ftvs)
					          @ (List.map (fun fv -> Varg(TVal_var fv)) fvs),
					          None) in
	        TVal_obj(tconcrete, []), addToTransEnv transenv newclass
         | _ -> errV "unascribed FunT body" v)
  
      | V_Var gvar, t ->
        let newT, transenv = transType transenv t in
        (match gvar with
          | GV_Bound bvar -> TVal_var(bvar, newT), transenv
          | GV_Free fvar -> TVal_var (fvar, newT), transenv)
      | v, t -> transValue freevs transenv v)
  | V_Var _
  | _ -> errV "unexpected value" v


and transExp freevs transenv e = match e with
  | E_Value v -> 
    let newV, transenv = transValue freevs transenv v in
    TExp_val newV, transenv
  | E_App(efun, earg) ->
    (match efun, earg with
       | E_Ascribe(e1, tfun), V_Ascribe(v, targ) ->
        let newfun, transenv = transExp freevs transenv e1 in
        let newarg, transenv = transValue freevs transenv v in
        let appRef = ("Invoke", []) in
        let argType, transenv = transType transenv targ in
        let newvar = newVvar argType in
        let newtfun, transenv = transType transenv tfun in
        let newvfun = newVvar newtfun in
        match newfun with
          | TExp_val vfun -> TExp_call(vfun, [newarg], appRef), transenv
          | _ -> TExp_let(newvfun, newfun, 
                          TExp_call(TVal_var newvfun, [newarg], appRef), ref false),
                 transenv
      | _ -> errE "unascribed E_App" e)
  | E_TApp(efun, t) ->
    (match efun with
       | E_Ascribe(e, tfun) ->
        let newfun, transenv = transExp freevs transenv e in
        let newtfun, transenv = transType transenv tfun in
        let newvfun = newVvar newtfun in
        let newtarg, transenv = transType transenv t in
        let tyappRef = ("TyApp", [newtarg]) in
        match newfun with
          | TExp_val funval -> TExp_call(funval, [], tyappRef), transenv
          | _ -> TExp_let(newvfun, newfun, 
                          TExp_call(TVal_var newvfun, [], tyappRef), ref true), transenv
        | _ -> errE "unascribed E_Tapp" e)
  | E_LetIn(bvar, e1, e2) ->
    let newE1, transenv = transExp freevs transenv e1 in
    let newE2, transenv = transExp (addFreev freevs bvar) transenv e2 in
    TExp_let((bvar, TType_inferred(Unionfind.fresh TUvar)), newE1, newE2, ref false), transenv
  | E_Ascribe(e, t) ->
    (match e, t with
      | E_Match(v, p, e1, e2), finalt ->
        let newV, transenv = transValue freevs transenv v in
        (match p with
          | MkPattern(name, bvars_t, bvars_v) ->
            let bvars_ts, bvars_vs = convertList bvars_t, convertList bvars_v in
            let newE1, transenv = transExp (addFreeTv_vs freevs bvars_ts bvars_vs) transenv e1 in
            (* TODO: kinds of ts and types of vars *)
            let ts = List.map (fun tvar -> TType_var(tvar, TKind_star)) bvars_ts in
            let vars = List.map (fun var -> var, TType_name ((["Prims"; "bool"], TKind_star), None)) bvars_vs in
            (*let env, ts = List.fold (fun (env, ts) (tvar, k) -> 
                                let k', env = transKind env k in
                                env, (TType_var(((tvar, tvar), k')))::ts) (env, []) bvars_t in
            let env, vars = List.fold (fun (env, vars) (var, t) ->
                                  let t', env = transType env t in
                                  env, (var, t')::vars) (env, []), bvars_v in *)
            (* TODO: isGADT *)
            let patterne = ([name], [], (List.map Ptype ts)@(List.map Pvar vars), false, newE1) in 
            let newE2, transenv = transExp freevs transenv e2 in
            let newfinalT, transenv = transType transenv finalt in
            TExp_isinst(newV, [(patterne)], newE2, newfinalT), transenv)
      | _, _ ->
        let newE, transenv = transExp freevs transenv e in
        let newT, transenv = transType transenv t in
        TExp_ascribed(newE, newT), transenv)
  | E_Assume _ (* don't expect assume *)
  | _ -> errE "unexpected exp" e

and getFreeVars freevs transenv v =
  let ftvs, fvs = getFreeVars_v [] [] v in
  let transenv, tvars =
    List.fold (fun (transenv, tvs) freev ->
                 match List.tryFind (fun ftv -> fst(ftv) = freev) ftvs with
                 | None -> transenv, tvs
                 | Some (bvar, k) ->
                   let newK, transenv = transKind transenv k in
                   transenv, (bvar, newK)::tvs) (transenv, []) (fst freevs) in
  let transenv, vars = 
    List.fold (fun (transenv, vs) freev ->
                match List.tryFind (fun fv -> fst(fv) = freev) fvs with
                  | None -> transenv, vs
                  | Some (bvar, t) -> 
                    let newT, transenv = transType transenv t in
                    transenv, (bvar, newT)::vs) (transenv, []) (snd freevs) in
  transenv,
  List.rev tvars,
  List.rev vars,
  false  (* TODO: isAffine *)

and getFreeVars_v btvs bvs v = 
  match v with
    | V_Ascribe(v, t) ->
      (match v with
         | V_Var gv ->
           (match gv with
             | GV_Bound bvar
             | GV_Free bvar ->
               if List.exists (fun var -> var = bvar) bvs then [], []
               else [], [(bvar, t)])
         | _ ->
           let ftvs_v, fvs_v = getFreeVars_v btvs bvs v in
           let ftvs_t, fvs_t = getFreeVars_t btvs bvs t in
           ftvs_v@ftvs_t, fvs_v@fvs_t)
    | V_Fun(bvar, t, e) ->
      let ftvs_t, fvs_t = getFreeVars_t btvs bvs t in
      let bvs = bvar::bvs in
      let ftvs_e, fvs_e = getFreeVars_e btvs bvs e in
      ftvs_t@ftvs_e, fvs_t@fvs_e
    | V_FunT(bvar, k, e) ->
      let ftvs_k, fvs_k = getFreeVars_k btvs bvs k in
      let btvs = bvar::btvs in
      let ftvs_e, fvs_e = getFreeVars_e btvs bvs e in
      ftvs_k@ftvs_e, fvs_k@fvs_e
    | V_Boxed(_, v) -> getFreeVars_v btvs bvs v
    | V_Const(_, ts, vs) ->
      let ftvs_ts, fvs_ts = List.fold (fun (ftvs, fvs) t ->
                                         let ftvs_t, fvs_t = getFreeVars_t btvs bvs t in
                                         ftvs_t@ftvs, fvs_t@fvs) ([], []) (convertList ts) in
      List.fold (fun (ftvs, fvs) v ->
                   let ftvs_v, fvs_v = getFreeVars_v btvs bvs v in
                   ftvs_v@ftvs, fvs_v@fvs) (ftvs_ts, fvs_ts) (convertList vs)
    | _ -> err (spr "getFreeVars_v: unexpected value: %s" (prettyValue v))

and getFreeVars_k btvs bvs k =
  match k with
    | K_Base _ -> [], []
    | K_ProdK(bvar, k1, k2) ->
      let ftvs_k1, fvs_k1 = getFreeVars_k btvs bvs k1 in
      let btvs = bvar::btvs in
      let ftvs_k2, fvs_k2 = getFreeVars_k btvs bvs k2 in
      ftvs_k1@ftvs_k2, fvs_k1@fvs_k2
    | K_ProdT(bvar, t, k2) ->
      let ftvs_t, fvs_t = getFreeVars_t btvs bvs t in
      let bvs = bvar::bvs in
      let ftvs_k2, fvs_k2 = getFreeVars_k btvs bvs k2 in
      ftvs_t@ftvs_k2, fvs_t@fvs_k2

and getFreeVars_t btvs bvs t =
   match t with
    | T_Ascribe(t, k) ->
      (match t with
        | T_Var gvar ->
          (match gvar with
            | GV_Bound bvar
            | GV_Free bvar ->
              if List.exists (fun var -> var = bvar) btvs then [], []
              else [(bvar, k)], [])
         | _ -> 
           let ftvs_t, fvs_t = getFreeVars_t btvs bvs t in
           let ftvs_k, fvs_k = getFreeVars_k btvs bvs k in
           ftvs_t@ftvs_k, fvs_t@fvs_k)
     | T_Ind _ -> [], []
     | T_VApp(t, v) ->
       let ftvs_t, fvs_t = getFreeVars_t btvs bvs t in
       let ftvs_v, fvs_v = getFreeVars_v btvs bvs v in
       ftvs_t@ftvs_v, fvs_t@fvs_v
     | T_App(t1, t2) ->
       let ftvs_t1, fvs_t1 = getFreeVars_t btvs bvs t1 in
       let ftvs_t2, fvs_t2 = getFreeVars_t btvs bvs t2 in
       ftvs_t1@ftvs_t2, fvs_t1@fvs_t2
     | T_Prod(bvar, t1, t2) ->
       let ftvs_t1, fvs_t1 = getFreeVars_t btvs bvs t1 in
       let bvs = bvar::bvs in
       let ftvs_t2, fvs_t2 = getFreeVars_t btvs bvs t2 in
       ftvs_t1@ftvs_t2, fvs_t1@fvs_t2
     | T_ProdK(bvar, k, t2) ->
       let ftvs_k, fvs_k = getFreeVars_k btvs bvs k in
       let btvs = bvar::btvs in
       let ftvs_t2, fvs_t2 = getFreeVars_t btvs bvs t2 in
       ftvs_k@ftvs_t2, fvs_k@fvs_t2
     | T_Ref(bvar, t1, t2)
     | T_Lam(bvar, t1, t2) ->
       let ftvs_t1, fvs_t1 = getFreeVars_t btvs bvs t1 in
       let bvs = bvar::bvs in
       let ftvs_t2, fvs_t2 = getFreeVars_t btvs bvs t2 in
       ftvs_t1@ftvs_t2, fvs_t1@fvs_t2
     | T_Afn(t) -> getFreeVars_t btvs bvs t
     | _ -> err (spr "getFreeVars_t: unexpected type: %s" (prettyTyp t))

and getFreeVars_e btvs bvs e =
   match e with
     | E_Value v -> getFreeVars_v btvs bvs v
     | E_App(e, v) ->
       let ftvs_e, fvs_e = getFreeVars_e btvs bvs e in
       let ftvs_v, fvs_v = getFreeVars_v btvs bvs v in
       ftvs_e@ftvs_v, fvs_e@fvs_v
     | E_TApp(e, t) ->
       let ftvs_e, fvs_e = getFreeVars_e btvs bvs e in
       let ftvs_t, fvs_t = getFreeVars_t btvs bvs t in
       ftvs_e@ftvs_t, fvs_e@fvs_t
     | E_LetIn(bvar, e1, e2) ->
       let ftvs_e1, fvs_e1 = getFreeVars_e btvs bvs e1 in
       let bvs = bvar::bvs in
       let ftvs_e2, fvs_e2 = getFreeVars_e btvs bvs e2 in
       ftvs_e1@ftvs_e2, fvs_e1@fvs_e2
     | E_Match(v, pat, e1, e2) ->
       let ftvs_v, fvs_v = getFreeVars_v btvs bvs v in
       let btvs', bvs' = addPatVars btvs bvs pat in
       let ftvs_e1, fvs_e1 = getFreeVars_e btvs' bvs' e1 in
       let ftvs_e2, fvs_e2 = getFreeVars_e btvs bvs e2 in
       ftvs_v@ftvs_e1@ftvs_e2, fvs_v@fvs_e1@fvs_e2
     | E_Assume(t) -> getFreeVars_t btvs bvs t
     | E_Ascribe(e, t) ->
       let ftvs_e, fvs_e = getFreeVars_e btvs bvs e in
       let ftvs_t, fvs_t = getFreeVars_t btvs bvs t in
       ftvs_e@ftvs_t, fvs_e@fvs_t

and addPatVars btvs bvs pat = match pat with
  | MkPattern(_, tvs, vs) -> (convertList tvs)@btvs, (convertList vs)@bvs

and addFreev freevs v =
  let ftvs, fvs = freevs in
  ftvs, v::fvs

and addFreeTv freevs tv =
  let ftvs, fvs = freevs in
  tv::ftvs, fvs

and addFreeTv_vs freevs tvs vs =
  let ftvs, fvs = freevs in
  ftvs@tvs, fvs@vs

(*let transDcon transenv dcon =
  match dcon with
    | MkConstructor(cname, t) ->
      let transT transenv t =
        match t with
          | T_ProdK(bvar, k, t2) ->
          | _ -> in
      let newclass = {
        externref = None;
        visibility = TVis_public; (* TODO: aqual *)
        attr = NoAttr; (* TODO: isAxiom *)
        name = [cname];
        namestring = cname;
        kvars = [];
        vars = vars;
        evidences = [];
        extends = Some super;
        fields = [];
        staticFields = [];
        methods = [];
        kind = None;
        hasTag = false;
        tagNum = tagOpt;
     } in
     let transenv, newclass = 
       if not !Util.extract_proofs then
         let transenv, newclass = addEqualityMethod transenv newclass in
           if cname.StartsWith("Prims") then transenv, newclass
           else addToStringMethod transenv newclass tys
        else transenv, newclass in
    addToTransEnv transenv newclass

let transInductive transenv ind =
  match ind with
    | MkIndType(name, k, dcons) ->
      let newclass: tClassDecl = 
        { externref = None;
          visibility = TVis_public;
          attr = NoAttr; (* TODO Prop or NoAttr *)
          name = [name];
          namestring = name;
          kvars = [];
          vars = vars;
          evidences = [];
          extends = None;
          fields = [];
          staticFields = [];
          methods = [];
          kind = Some knd;
          hasTag = true;
          tagNum = None;
        } in
        List.fold (fun transenv dcon -> transDcon transenv dcon) 
          (addToTransEnv tranenv newclass)
          dcons


*)