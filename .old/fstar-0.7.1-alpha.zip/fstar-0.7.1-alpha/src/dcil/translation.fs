#light "off"
// (c) Microsoft Corporation. All rights reserved
module Microsoft.FStar.Translation

(*
  NS: I put in several hacks to get the translation to go through to
  IL generation.
  
  1. In transTDApp: when translating a (T<e>) if the index expression
  is not a value, then I just drop it and translate the type as the
  translation of T. What we really should do is to establish an
  invariant that ensures that every source language value is
  translated to a target language value. Currently, this invariant
  does not hold true for record projections. (x.f in the source is
  translated to let y = x in y.f in the target.)

  2. Consider the following source program:

  module A
  type rec1 = {fld1:int; fld2:int}
  end
  module B 
  open A
  val foo: rec1 -> int
  let foo x = 0
  end

  The translation of A produces a class in

  A.dll
  class A_fld1-A_fld2 { ... }
  
  module B after type expansion includes
  val foo : {A.fld1:int; A.fld2:int} -> int

  When translating this type, we have to translate the record type
  {A.fld1:int; A.fld2:int}. But, we have to notice that this type is
  really an external record type and translate it as a 

  TType_name("A.A_fld1-A_fld2") 

  rather than producing a fresh class decl for it in B.dll.

  SO, I added an ugly hack to transRecordTyp that uses a bit of
  mutable state (!) to keep track of which module is currently being
  translated and then uses a trick based on the structure of the
  field names to figure out when to generate class decls for a record
  type and when to generate an external type name. 

  See curmodname:option<lident> ref and transRecordTyp

  3. Another related problem with the translation of record types is
  that after type expansion, every syntactic occurence of a record
  type is translated into a fresh class declaration. Ilgen has a hack
  to detect duplicates and suppress class generation appropriately.
  
  The real solution should address 2 and 3 together and generate
  record declarations or references to external record declarations as
  needed.

  Another problem with our current strategy for record translation is
  that it does not work for polymorphic record types---we will end up
  with name collisions and unnecessary code duplication.

  3. In transLetBinding, we have to produce static field declarations
  for all top-level bindings. 

  module A
  let rec foo x = foo x
  end
  module B 
  let bar x = foo x
  end

  Now in module A, the name foo is a top-level let binding, but in the
  body of foo the occurence of foo is a bound variable (Exp_bvar). In
  module B, the occurrence of foo is a free variable
  (Exp_fvar). Unfortunately, the source type checker binding rules
  cause the (Exp_bvar) in module A to be indexed using the
  bvar_real_name. Whereas, the Exp_fvar in module B uses the ppname.

  So, I included a hack in transLetBinding to generate static field
  declarations for both the realname and the pp_name. 

  The real solution is to sort out the source type checker and make
  sure that a consistent naming scheme is used for top-level let
  bindings.
*)
open Sugar
open Absyn
open Target
open Util
open TargetUtil
open Profiling
open Tcenv
open Tcutil
open KindAbbrevs

exception TransErr of string


let pr = Printf.printf
let spr = Printf.sprintf

let transType_ctr = new_counter "Trans Type"
let transExp_ctr = new_counter "Trans exp"
let transSig_ctr = new_counter "Trans sig"
let transAscribed_ctr  = new_counter "Trans ascribed"
let addtoTransEnv_ctr = new_counter "Add cdecl to transEnv"

let text_of_id = Microsoft.FStar.Sugar.text_of_id
let text_of_lid = Microsoft.FStar.Sugar.text_of_lid
let path_of_lid = Microsoft.FStar.Sugar.path_of_lid
let compare_lid (lid1: lident) (lid2: lident) = String.compare (text_of_lid lid1) (text_of_lid lid2)

let debug = ref false

let csp = new System.Security.Cryptography.MD5CryptoServiceProvider() 

let mk_affine t = match t with 
    TType_affine _ -> t
  | _ -> TType_affine t 

let strExp = Microsoft.FStar.PrettyTarget.strExp
  
(* translate a bound variable definition to a target identifier *)
let transBvDef (bvd: bvdef<'a>) : tBvDef =
  (text_of_id bvd.ppname, text_of_id bvd.realname)
let transBvDefId (bvd: bvdef<'a>) : tIdent = snd (transBvDef bvd)

let curmodname : (option<lident> ref) = ref None
let evidenceStack: (tEvidences list) ref = ref []

let newTvar = Target.newTvar
let newVvar = Target.newVvar

let genClassName() =
  let classname = "C" ^ (newSym()) in
  let fullname =
    match !curmodname with
      | Some (mname : lident) -> (List.map (fun (x : ident) -> x.idText) mname.lid) @ [classname]
      | None -> [classname] in
  fullname

let unbox = fun k -> match k(* .u *) with
    Kind_boxed k -> k
  | _ -> k

let mangled_op_to_pop (op:ident) = match op.idText with 
    "op_AmpAmp" -> AND
  | "op_BarBar" -> OR
  | "op_Addition" -> ADD
  | "op_Multiply" -> MUL
  | "op_Subtraction" -> SUB
  | "op_Divide" -> DIV
  | "op_Negation" -> NOT

  (* check if bvd occurs free in t*)
let isFreeInTyp (bvd: Absyn.bvvdef) (t : Absyn.typ) =
  let (ftvs, freevs) = Absyn.freevarsTyp t in
    List.exists (fun (fvar: Absyn.bvvar) -> (bvar_real_name fvar).idText = bvd.realname.idText) freevs

(* translation of kinds *)
let rec transKind (transenv: transEnv) (k: Absyn.kind) : tKind * transEnv =
  let err msg k = 
     let errmsg = Printf.sprintf "transKind: unexpected kind (%s) %s" msg 
        (Pretty.strKind k) in
       raise (TransErr errmsg) in
  match k(* .u *) with
    | Kind_boxed knd -> transKind transenv knd
    | Kind_star -> (TKind_star, transenv)
    | Kind_prop -> (TKind_prop, transenv)
    | Kind_erasable -> (TKind_erasable, transenv)
    | Kind_affine -> (TKind_affine, transenv)
    | Kind_tcon(_, k1, k2) -> (* k1 => k2 *)
        (*let _ = Printf.printf "\n translating %s" (Pretty.strKind k) in *)
        let newK1, transenv = transKind transenv k1 in
        let newK2, transenv = transKind transenv k2 in
        TKind_karrow(newK1, newK2), transenv
    | Kind_dcon (_, ty, knd) -> 
        let (newTy, transenv) = transType transenv ty in
        let (newKind, transenv) = transKind transenv knd in
          (TKind_arrow(newTy, newKind), transenv)
   
(* translation of bound type variable *)
and transBTvar transenv (tvar: btvar) : tVar<tKind> * transEnv = 
  let id = bvar_real_name tvar in 
  let (newKind, transenv) = transKind transenv (tvar.sort) in
    ((text_of_id id, newKind), transenv)

(* translation of external names *)
and transTvar transenv (tv: var<kind>) : tName<tKind> * transEnv = 
  let (newKind, transenv) = transKind transenv (tv.sort) in
    ((path_of_lid tv.v, newKind), transenv)

(* translation of types, return a list of new class declarations *) 
and transTypeWithEnv (env:list<ident>) (transenv: transEnv) (t: typ): tType * transEnv =  
  let rec transt trenv ot : tType * transEnv =
    let t = whnf ot in
    let t', trenv = (match (compress t).v with
       | Typ_btvar bv -> 
           let id = (bvar_real_name bv).idText in
             (match Util.try_find_position (fun (a:ident) -> a.idText=id) env with 
                  None ->
                    let (newvar, trenv) = transBTvar trenv bv in
                      (TType_var newvar, trenv)
                | Some i -> TType_index i, trenv)
       | Typ_const(var, eref) ->
           let (newvar, transenv) = transTvar trenv var in
             (TType_name(newvar,eref), trenv)
       | Typ_record(fts,_) -> transRecordType env trenv fts t
       | Typ_fun (bvd_opt, t1, t2) ->
           let (newt1, trenv) = transt trenv t1 in
           let (newt2, trenv) = transt trenv t2 in
           let tfun: tType =
             match bvd_opt with
               | None -> TType_fun (None, newt1, newt2)
               | Some bvd -> 
                   TType_fun((if (isFreeInTyp bvd t2) then Some (transBvDef bvd) else None), 
                             newt1, newt2) in
           let tconcrete: tTypeConcrete = 
             let newk1, _ = transKind trenv (unbox t1.sort) in
             let newk2, _ = transKind trenv (unbox t2.sort) in
             tClassDepArrow.name, [newk1; newk2], [Targ newt1; Targ tfun], None in
           let dcilTy = TType_concrete tconcrete in
             (dcilTy, trenv)
       | Typ_univ (bvd, k, _, body) -> transTPoly env trenv bvd k body (* NS: TODO! Dropping constraints *)
       | Typ_dtuple (bvd_opt_ts) -> transDTuple env trenv bvd_opt_ts t
       | Typ_app _ 
       | Typ_dep _ -> transTDApp env trenv t
       | Typ_affine (t') -> 
           let (tt, trenv) = transt trenv t' in
           let dcilTy = TType_affine tt in
             (dcilTy, trenv)  
       | Typ_refine (bvd, tt, f, ghost) when !Options.rdcil && ghost=true -> (* Nik: Note change here ... *)   
            let (newt, trenv) = transt trenv tt in
            let _ = if !debug then  pr "\n !!! refinement type %s" (Pretty.strTyp t) in
            let (newf, trenv) = transt trenv f in 
            let newt =  TType_refine(transBvDef bvd, newt, newf, Pretty.strTypAsFormula f, []) in
            let _ = if !debug then pr "\n   ===> %s" (PrettyTarget.strType newt) in
         newt, trenv
       | Typ_refine (bvd, t, f, ghost) -> 
           transt trenv t
       | Typ_lam (bvd, t1, t2) ->
           let (newt1, trenv) = transt trenv t1 in
           let (newt2, trenv) = transt trenv t2 in
             (TType_fun((if (isFreeInTyp bvd t2) then Some (transBvDef bvd) else None), 
                        newt1, newt2), trenv)
       | Typ_ascribed(t, _) ->  transt trenv t 
       | _ -> 
           let errmsg = Printf.sprintf "transType: unexpected type %s " 
             (Pretty.strTyp t) in
             raise (TransErr errmsg)) 
      in t', trenv 
  in transt transenv t 

and transType = "Trans Type" ^^ lazy (transTypeWithEnv [])

and transFieldTypes env trenv types =
  let rec transFs trenv srctypes ftypes =
    match srctypes with
      | [] -> (trenv, List.rev ftypes)
      | fty :: rest ->
          let (fty', trenv) = transTypeWithEnv env trenv fty in
            transFs trenv rest (fty' :: ftypes) in
    transFs trenv types [] 

(* translation of record type *)
(* sort the fields according to their names *)
and transRecordType env transenv fts origt: tType * transEnv =
  let fts = List.sortWith (fun (fname1, _) (fname2, _) -> compare_lid fname1 fname2) fts in
  let is_external_record_type nm = 
    let modname = List.hd nm.lid in
      match !curmodname with
        | Some x when not (Sugar.lid_equals x (asLid [modname])) -> Some (modname.idText)
        | _ -> None in
  let (fieldnames, types) = List.split fts in
  let concatenatedFieldNames =
    List.map (fun fname -> String.concat "_" (path_of_lid fname)) fieldnames in
  let newClassName = "Rec" ^ (newSym()) in
    match is_external_record_type (List.hd fieldnames) with
        Some extMod -> 
          let dcilTy = TType_name(([extMod; newClassName], TKind_star), None) in
            dcilTy, transenv
      | None -> 
          let (transenv, newtypes) = transFieldTypes env transenv types in
            (*             // create a new class that corresponds to the record type. *)
            (*             // The class name is the concatenation of field names. *)
            (*             // The fields of the class are the fields of the records *)
          let newFields = List.combine concatenatedFieldNames newtypes in
          let recordClassDecl : tClassDecl =
            { externref=None;
              visibility = TVis_public;
              attr = NoAttr;
              name = [newClassName];
              namestring = newClassName;
              kvars = [];
              vars = [];
              evidences = [];
              extends = None;
              fields = newFields;
              staticFields = [];
              methods = [];
              kind = Some TKind_star;
              hasTag=false;
              tagNum=None
            } in
          let newRecordType = TType_concrete([newClassName], [], [], None) in
            (newRecordType, addToTransEnv transenv recordClassDecl) 

(* ||forall a::k.t|| -> All<||k||, \a::||k||.||t||> *)
and transTPoly env transenv (bvd: btvdef) (knd: kind) (tbody: typ) =
  let (newbody,transenv) = transTypeWithEnv env transenv tbody in
  let (newKind, transenv) = transKind transenv knd in
  let (newKind2, transenv) = transKind transenv (tbody.sort) in
  let tfun = TType_tfun(transBvDef bvd, newKind, newbody) in
    (TType_concrete(tClassAll.name, [newKind; newKind2], [Targ tfun], None), transenv) 

(* translation of dependent tuple types *)
(* deal with (x:t1, t2) only at the moment *)
and transDTuple env transenv (bvdts) origt: tType * transEnv = 
  match bvdts with
    | (bvdef_opt, t1) :: [(None, t2)] ->
        let (newt1, transenv) = transTypeWithEnv env transenv t1 in
        let (newt2, transenv) = transTypeWithEnv env transenv t2 in
        let tfun = 
          match bvdef_opt with
            | Some bvdef -> TType_fun((if isFreeInTyp bvdef t2 then Some (transBvDef bvdef) else None), newt1, newt2)
            | None -> TType_fun(None, newt1, newt2) in
        let (newKind1, transenv) = transKind transenv t1.sort in
        let (newKind2, transenv) = transKind transenv t2.sort in
        let tconcrete =
          (tClassDepTuple.name, [newKind1; newKind2], [Targ newt1; Targ tfun], None) in
        let dcilTy = TType_concrete tconcrete in
          (dcilTy, transenv)
    | _ -> let errmsg = spr "transDTuple: unexpected tuple type %s" (bvdts.ToString()) in
        raise (TransErr errmsg)

(* translation of type and dependent application *)
(* Find the type constructor and all the type and value arguments *)
and transTDApp env transenv (t: typ) : tType * transEnv = 
  let rec applyArgs ty args =
    (match args with
       | [] -> ty
       | (Targ tvar)::rest -> applyArgs (TType_tapp(ty, tvar)) rest
       | (Varg arg)::rest -> applyArgs (TType_dep(ty, arg)) rest) in
  let rec transApp trenv ty args =
  let stringt = Pretty.strTyp ty in
  let _ = if !debug then pr "TransTDAPP: %s\n" stringt in 
    match (compress ty).v with
      | Typ_const(var,eref) -> 
           let tyconName = path_of_lid (var.v) in
          let tconcrete : tTypeConcrete = (tyconName, [], args, eref) in 
          let dcilTy = TType_concrete tconcrete in
            (dcilTy, trenv)
      | Typ_app (tfun, targ) ->
           let (new_targ, trenv) = transTypeWithEnv env trenv targ in
            transApp trenv tfun ((Targ new_targ) :: args)
      | Typ_dep (tdfun, earg) ->
          let (new_earg, trenv) = transExp trenv earg in
            (match new_earg with
               | TExp_val newv ->
                   transApp trenv tdfun ((Varg newv)::args)
               | TExp_name(name, _) -> (* convert the name to a variable *)
                   transApp trenv tdfun ((Varg (name2Value name))::args)
               | _ -> (* skip non-value arguments! *)
                   Util.warn "SKIPPING non-value argument %s in transTDAPP!\n" (PrettyTarget.strExp new_earg);
                   transApp trenv tdfun args
               | _ -> 
                   let errmsg = spr 
                     "transTDApp: %s not translated to a value \n (%s)"
                     (Pretty.strExp earg) (PrettyTarget.strExp new_earg) in
                     raise (TransErr errmsg))
      | Typ_btvar bvar ->
          (* 'a => 'a targs vargs *)
          let (newvar, trenv) = transBTvar trenv bvar in
          applyArgs (TType_var newvar) args, trenv
      | Typ_lam (bvd, t1, t2) ->
          let (newt1, trenv) = transType trenv t1 in
          let (newt2, trenv) = transType trenv t2 in
          let newf = TType_fun((if isFreeInTyp bvd t2 then Some (transBvDef bvd) else None), newt1, newt2) in
          applyArgs newf args, trenv
      | _ -> 
          let errmsg = spr "transTDApp: unexpected type %s in %s" 
            (Pretty.strTyp ty) (Pretty.strTyp t)
          in raise (TransErr errmsg) in
    transApp transenv t []

(* translation of bound value variable *)
(* Does not translate type *)
and transBVvar transenv (bvar: bvvar) : tVar<tType> * transEnv =
  let id = bvar_real_name bvar in
  let (newt, transenv) = transType transenv bvar.sort in
  let newvar = (text_of_id id, newt) in
    (newvar, transenv)

(* translate a bound variable with an explicit type annotation *)
and transBVvarWithType transenv (bvar: bvvar) t : tVar<tType> * transEnv =
  let id = bvar_real_name bvar in
  let (newt, transenv) = transType transenv t in
  let newvar = (text_of_id id, newt) in
    (newvar, transenv)

(* translation of a free value variable *)
and transVvar transenv (var: var<typ>): tName<tType> * transEnv =
  let (newt, transenv) = transType transenv var.sort in
  let newvar: tName<tType> = (path_of_lid (var.v), newt) in
    (newvar, transenv)

(* add and translate evidences (e1 = e2) to class declarations *)
and addEvidences env evidences =
  (* translate (exp * exp) to (tVar<tType> * TExp) *)
  let rec transEvidences ees ves =
    match ees with
      | [] -> List.rev ves
      | ev :: rest -> 
          match ev with 
            | Inl (t1, t2) -> 
              (match t1.v with
                 | Typ_btvar var -> (* var = t2 *)
                   let newtvar, _ = transBTvar env var in
                   let newt, _ = transType env t2 in
                   transEvidences rest (TEv_type(newtvar, newt) :: ves)
                 | _ -> transEvidences rest ves)
            | Inr (e1, e2) -> 
          (*Printf.printf "\n adding evidence %s = %s" 
                         (Pretty.strExp e1) (Pretty.strExp e2); *)
          (match e1.v with
             | Exp_bvar var
             | Exp_ascribed ({v=Exp_bvar var; sort = _; p = _}, _, _) -> 
                 (* translate var and e2, ignoring the new env and class *)
                 (* declarations because var and e2 should be translated already *)
                 let (newvar, _) = transBVvar env var in
                 let (newExp, _) = transExp env e2 in
                   (match newExp with
                      | TExp_val vl -> transEvidences rest (TEv_val(newvar, vl) :: ves)
                      | _ -> transEvidences rest ves)
             | _ -> transEvidences rest ves) in
  let newevs = transEvidences evidences [] in
    evidenceStack := newevs :: (!evidenceStack)

and removeEvidences() =
  match !evidenceStack with
    | _::rest -> evidenceStack := rest;
    | _ -> raise (TransErr " no evidences to remove")

and currentEvidences () = 
  match !evidenceStack with
    | cur :: rest -> cur 
    | _ -> []

(* translation of expressions returns the target expression and *)
(* a list of new class declarations *)
and transExp transenv (e: exp): tExp * transEnv = 
  "Trans exp" ^^ lazy (transE ([], []) transenv e)

(* add a free type variable to free variables list *)
and addFreeTv (freevs:ident list * ident list) tv =
  let (tvars, vars) = freevs in
  (tvars@[tv], vars)

(* add a free variable to free variables list *)
and addFreev (freevs:ident list * ident list) var =
  let (tvars, vars) = freevs in
  (tvars, vars@[var])

(* add a list of free type variables to free variables list *)
and addFreeTvs (freevs:ident list * ident list) tvs =
  let (tvars, vars) = freevs in
  (tvars@tvs, vars)

(* add a list of free variables to free variables list *)
and addFreevs (freevs:ident list * ident list) vs =
  let (tvars, vars) = freevs in
  (tvars, vars@vs)

(* add a list of free type and value variables to free variables list *)
and addFreeTv_vs (freevs:ident list * ident list) tvs vs =
  let (tvars, vars) = freevs in
  (tvars@tvs, vars@vs)

and transE (freevs:ident list*ident list) transenv (e: exp) : tExp * transEnv =
  match e.v with
    | Exp_bvar bv -> 
        let (newvar, transenv) = transBVvar transenv bv in
          (TExp_val (TVal_var newvar), transenv)
    | Exp_fvar(var,eref) ->
        let (newvar, transenv) = transVvar transenv var in
          (TExp_name(newvar,eref), transenv)
    | Exp_constant conste ->
        (TExp_val (TVal_constant conste), transenv)
    | Exp_constr_app (var, ts, phantom_es, es) ->
        if (Tcenv.is_logic_function (getTcenv transenv) var) then
        (*let _ = pr "Got logic fun: %s\n" (Pretty.str_of_lident var.v) in*)
        let newvar, transenv = transVvar transenv var in
        let rec findV newe = match newe with
            | TExp_val v -> v
            | TExp_ascribed (newe, _) -> findV newe
            | _ -> raise (TransErr ("argument of logic functions not a value: " ^ (Pretty.strExp e))) in
        let newvs, transenv =
          List.fold (fun (vs, transenv) e ->
                       let newe, transenv = transE freevs transenv e in
                       (findV newe)::vs, transenv) ([], transenv) es in
        TExp_val (TVal_logic_fun(newvar, (List.rev newvs))), transenv
        else if Const.is_tuple_data_lid var.v then 
          (match (ts, es) with
             | ([t1; t2], [e1; e2]) ->
                 transTuple2Constr freevs transenv var None t1 t2 e1 e2
             | _ -> let msg = Printf.sprintf "unexpected tuple constr %s" (Pretty.strExp e) in
                 raise (TransErr msg))
        else transConstrApp freevs transenv var ts phantom_es es 
    | Exp_abs _ -> (*pr "\n!! %s \n" (Pretty.strExp e);*) transAbs freevs transenv e
    | Exp_tabs (bvd, k, _, body) -> transTAbs freevs transenv e  (* NS: TODO! Dropping constraints *)
    | Exp_primop(op, args) -> 
        (*let _ = pr "\n translating primop %s" (Pretty.strExp e) in*)
        let targs_rev, transenv = List.fold_left 
          (fun (targs, env) e ->
             let texp, env = transE freevs env e in
             let texp = match texp with 
                 TExp_val v -> v
               | _ -> 
                   let msg = spr "Unexpected non-value in operator application: %s" (Pretty.strExp e) in
                     raise (TransErr msg) in
               texp::targs, env) ([], transenv) args in
        let pop = mangled_op_to_pop op in
          TExp_primop(pop, List.rev targs_rev), transenv
    | Exp_app (efun, earg) -> transApp freevs transenv efun earg
    | Exp_tapp (efun, targ) -> transTApp freevs transenv efun targ
    | Exp_match (em, pes, edefault) -> transMatch freevs transenv em pes edefault e.sort
    | Exp_cond (eb, et, ef) ->
        let (neweb, transenv) = transE freevs transenv eb in
        let (newet, transenv) = transE freevs transenv et in
        let (newef, transenv) = transE freevs transenv ef in
        let newe = TExp_cond(neweb, newet, newef) in
          (newe, transenv)
    | Exp_recd(lidopt, targs, phantoms, fes) -> (* TODO: handling targs *)
      transRecordExp freevs transenv fes e.sort
    | Exp_proj (erecord, fieldname) ->
        let (newerecord, transenv) = transE freevs transenv erecord in
        let newFieldName = 
          String.concat "_" (path_of_lid fieldname) in
          (match newerecord with
             | TExp_val v -> (TExp_val (TVal_ldfld(v, newFieldName)), transenv)
             | _ -> let (recordTy, transenv) = transType transenv erecord.sort in
               let newvar = newVvar recordTy in
                 (TExp_let(newvar, newerecord, 
                           TExp_ldfld(TVal_var newvar, newFieldName), ref true), transenv))
    | Exp_ascribed (e', t, evidences) -> 
        "Trans ascribed" ^^ lazy (match e'.v, (t.v) with
           | Exp_constr_app(dconvar, _, _, es), Typ_dtuple ttups ->
               let _ = addEvidences transenv evidences in
               let (newe, transenv) = transDtupleConstr freevs transenv dconvar es ttups e' in
                 removeEvidences(); (newe, transenv)
           | Exp_constr_app(dconvar, _, _, es), Typ_refine(_, {v=Typ_dtuple ttups; sort=_; p=_},_,_) ->
             (* handle refined tuples *)
               let _ = addEvidences transenv evidences in
               let newe, transenv = transDtupleConstr freevs transenv dconvar es ttups e' in
               let newt, transenv = transType transenv t in
               let newe = TExp_ascribed(newe, newt) in
               removeEvidences(); (newe, transenv)
           | Exp_bvar bvar, _ -> (* TODO: work around for a frond end issue with free vars in var.sort. see lookout *)
             let newvar, transenv = transBVvarWithType transenv bvar t in
             TExp_val(TVal_var newvar), transenv
           | _ -> 
               let _ = addEvidences transenv evidences in
               let newe, transenv = transE freevs transenv e' in
               let newe, transenv = 
                 (match t.v with
                    | Typ_refine _  
                    | Typ_affine _ ->
                      let (newt, transenv) = transType transenv t in
                      TExp_ascribed(newe, newt), transenv
                    | _ -> newe, transenv) in
               removeEvidences(); (newe, transenv))
    | Exp_let (is_rec, bvdtes, e2) -> transLet freevs transenv is_rec bvdtes e2
    | Exp_extern_call (eref, mn, t, tl, el) -> 
        let fail s = 
          let msg = spr "Error translating extern call %s.%s.%s: %s" eref.dll (text_of_lid eref.classname) mn.idText s in
            raise (TransErr msg) in
        let rec transArgs trenv args es =
          match args with
            | [] -> (List.rev es, trenv)
            | arg::rest -> 
                let (earg, trenv) = transE freevs trenv arg in
                  transArgs trenv rest (earg::es) in
        let (exps, transenv) = transArgs transenv el [] in
        let vals = List.map (function 
                               | TExp_val v -> v
                               | _ -> fail "Unexpected non-value in arguments") exps in
       
        let typInsts = List.map (fun t -> let (newt, _) = transType transenv t in newt) tl in
          TExp_extern_call(eref, (text_of_id mn,typInsts), vals), transenv
            
    | Exp_bot -> TExp_bot, transenv
    | _ -> 
        let errmsg = Printf.sprintf "transExp: unexpected exp %s" 
          (Pretty.strExp e) in
          raise (TransErr errmsg)

(* translate data constructor application *)
(*     S; G; A |- ei : ti ==> ei' forall i = 1..n
       -----------------------------------------------------------
       S; G; A |- D[t1, ..., tm]e1 ... en: t  ==>
       x1 = e1' in ... in xn = en' in
       x1 ... xn obj D<[|t1|], ..., [|tm|], x1, ..., xn>
*)
and transConstrApp freevs transenv var ts phantom_es es : (tExp * transEnv) = 
  let (dconvar, transenv) = transVvar transenv var in
  let rec transts trenv ts newts =
    match ts with 
      | [] -> (List.rev newts, trenv) 
      | (t::rest) ->
          let (newt, trenv) = transType trenv t in
            transts trenv rest (newt :: newts) in
  let (newts, transenv) = transts transenv ts [] in
  let rec getValues trenv es ves =
    match es with
      | [] -> (List.rev ves, trenv) 
      | e::rest ->
          let (newe, trenv) = transE freevs trenv e in
            match newe with
              | TExp_val v -> getValues trenv rest ((v,None)::ves)
              | _ -> let (newt, trenv) = transType trenv e.sort in
                let newvar = newVvar newt in
                  getValues trenv rest ((TVal_var newvar, Some newe)::ves) in
  let (newves, transenv) = getValues transenv es [] in
  let (newpves, transenv) = getValues transenv phantom_es []  in
  let vals = List.map fst (newpves@newves) in
  let tconcrete: tTypeConcrete = (fst dconvar, [], (List.map Targ newts) @ (List.map Varg vals), None) in
  let laste = TExp_val (TVal_obj(tconcrete,[])) in
  let rec buildExp ves laste =
    match ves with
      | [] -> laste
      | ((TVal_var var, Some e)::rest) ->
          TExp_let(var, e, buildExp rest laste, ref true)
      | (_::rest) -> buildExp rest laste in
    (buildExp (newpves@newves) laste, transenv)

and filterAndTransFvs transenv fvs_env fvs trans = 
  let rec aux transenv out env_vs = 
    let isEqId (vid:ident) bvar =
      let id = bvar_real_name bvar in
        (vid.idText = id.idText) in
      match env_vs with
        | [] -> List.rev out, transenv
        | (env_v::env_vs) ->
            match List.tryFind (fun fv -> isEqId env_v fv) fvs with 
              | None -> aux transenv out env_vs
              | Some bvar -> 
                  let (newvar, transenv) = trans transenv bvar in
                    aux transenv (newvar::out) env_vs in
    aux transenv [] fvs_env

and getFreeVars transenv freevs e: transEnv * tVar<tKind> list * tVar<tType> list * tVar<tType> list * bool =
  let (freetvs, freevs_e) = Absyn.freevarsExp e in
  (* let _ = pr "In source term : %s\n" (Pretty.strExp e) in *)
  (* let _ = pr "\n freetvs in = %s\n" *)
  (*   (String.concat "\n" (List.map (Pretty.strBtvar) freetvs)) in *)
  (* let _ = pr "\n freevs_e in = %s \n" *)
  (*   (String.concat "\n" (List.map (Pretty.strBvar) freevs_e)) in *)
  let freevs_ts = List.map (fun var -> Absyn.freevarsTyp(var.sort)) freevs_e in
  let _, pvss = List.split freevs_ts in
  (* remove those pvs that are also in freevs_e *)
  let pvs = List.filter (fun (var:bvvar) ->
                             not (List.exists (fun (vv:bvvar)->
                                               (var.v.realname).idText = (vv.v.realname).idText)
                                              freevs_e))
                        (List.concat pvss) in
  let isAffine = (* to test if affine *)
      List.exists (fun (v:bvvar) -> match (v.sort).sort(* .u *) with 
                     | Kind_affine -> true
                     | _ -> false ) freevs_e in
  (* check which vs appears in freevs_e and add in that order *)
  let (ftvs, transenv) = filterAndTransFvs transenv (fst freevs) freetvs transBTvar in 
  let (pvs, transenv) = filterAndTransFvs transenv (snd freevs) pvs transBVvar in
  let (fvs, transenv) = filterAndTransFvs transenv (snd freevs) freevs_e transBVvar in
  (* let _ = pr "\n after filtering: freevs in = %s" *)
  (*   (String.concat "\n" (List.map (fun var -> Printf.sprintf "%s" (PrettyTarget.strTvar var)) ftvs)) in *)
  (* let _ = pr "\n after filtering: freevs_e in = %s" *)
  (*   (String.concat "\n" (List.map (fun var -> Printf.sprintf "%s" (PrettyTarget.strVvar var)) fvs)) in *)
  let (ftvs, pvs, fvs) = (dedupVars ftvs, dedupVars pvs, dedupVars fvs) in
  transenv, ftvs, pvs, fvs, isAffine

(* translation of dependent functions
   (G; A) \\// x: t = (G'; A')
   S; G'; A' |- e: t' ==> e'
   class C<[|G|]_a, [|G|]_x >: [|\x:t -> t'|] {
   public override [|t'|] app([|t|] x) {e'}
   }
   -----------------------------------------------------------------
   S; G; A |- \x:t. e : \x:t -> t' ==>  
   obj C<dom([|G|]_a), dom([|G|]_x)>
*)
(* TODO: fixed the order of type variables as in transAbs *)
and transAbs freevs transenv e : (tExp * transEnv) = 
  match e.v with
    | Exp_abs (bvd, t, body) ->
        let (super, transenv) = transType transenv (e.sort) in
          (* get free type and value variables from the exp *)
        let transenv, ftvs, pvs, fvs, isAffine = getFreeVars transenv freevs e in
        (* x : t *)
        let id = bvd.realname in
        let (tParam, transenv) = transType transenv t in
        let param = (text_of_id id, tParam) in
          (* body *)
        let (newbody, transenv) = transE (addFreev freevs id) transenv body in
          (* new class for the function *)
        let fullname = genClassName() in
        let fullnamestr = String.concat "." fullname in
        let retTyp = body.sort in
        let (tRetType, transenv) = transType transenv retTyp in
        let _ = if (!debug) then
           pr "\n TRANS : \n src type = %s \n tgt type = %s \n src exp = %s \n tgt exp = %s \n src param type = %s \n tgt param type = %s \n src ret type = %s \n tgt ret type = %s"
           (Pretty.strTyp e.sort) (PrettyTarget.strType super)
           (Pretty.strExp body) (PrettyTarget.strExp newbody)
           (Pretty.strTyp t) (PrettyTarget.strType tParam)
           (Pretty.strTyp body.sort) (PrettyTarget.strType tRetType)
           in
       (* let _ = pr "\n current evidences = %s" (PrettyTarget.strEvidence (currentEvidences())) in*)
        let appMethod = (
          tRetType,    (* return type *)
          "Invoke",       (* method name *)
          [],          (* tvars *)
          [param],     (* params *)
          Some newbody (* body *) ) in
        let newclass = {
          externref=None;
          visibility = TVis_internal;
          attr = NoAttr;
          name = fullname;
          namestring = fullnamestr;
          kvars = [];
          vars = (List.map Tvar ftvs) @ (List.map Vvar (pvs@fvs));
          evidences = filterEvidences (currentEvidences()) ((List.map fst ftvs)@(List.map fst fvs));
          extends = Some super; 
          fields = [];
          staticFields = [];
          methods = [appMethod];
          kind = Some (if isAffine then TKind_affine else TKind_star);
          hasTag=false;
          tagNum=None
        } in
        let _ = DebugLog.Log(Printf.sprintf "\n %s " (PrettyTarget.strClassDecl newclass)) in
        (*let _ = pr "\n after filtering, evidences: %s" (PrettyTarget.strEvidence newclass.evidences) in*)
        let tconcrete = (fullname, [],
                         (List.map (fun ftv -> Targ(TType_var ftv)) ftvs)
                         @ (List.map (fun fv -> Varg(TVal_var fv)) (pvs@fvs)), 
                         None) in 
(*        let _ = Printf.printf "%s\n" (PrettyTarget.strClassDecl newclass) in *)
          (TExp_val (TVal_obj(tconcrete, [])), addToTransEnv transenv newclass)
    | _ ->
        let errmsg = Printf.sprintf "transAbs: unexpected exp %s" (Pretty.strExp e) in
          raise (TransErr errmsg)
            
(* translation of polymorphic functions 
   S, a:k; G; A |- e:t ==> e'
   class C<[|G|]_a, [|G|]_x>: [|forall a.t|] {
   public override [|t|] TyApp<a>() { e' }
   }
   -----------------------------------------------------------------
   S; G; A |- /\a::k.e : forall a.t ==> obj C<dom([|G|]_a), dom([|G|]_x)>
*)
and transTAbs outer_freevs transenv e : (tExp * transEnv) = 
  match e.v with
    | Exp_tabs(bvd, k, _, body) ->(* NS: TODO! Dropping constraints *)
        let (super, transenv) = transType transenv e.sort in
          (* free type and value variables in e *)
        let transenv, ftvs, pvs, fvs, isAffine = getFreeVars transenv outer_freevs e in 
          (* a: k *)
        let id = bvd.realname in
          (* body *)
        let (newbody, transenv) = transE (addFreeTv outer_freevs id) transenv body in
          (* new class for the polymorphic function *)
        let fullname = genClassName() in
        let fullnamestr = String.concat "." fullname in
        let (tret, transenv) = transType transenv body.sort in
        let (newKind, transenv) = transKind transenv k in
        let tyappMethod = (
          tret,                        (* return type *)
          "TyApp",                     (* method name *) 
          [(text_of_id id, newKind)],  (* type vars *)
          [],                          (* params *)
          Some newbody                 (* body *)
        ) in
        let newclass = {
          externref=None;
          visibility = TVis_internal;
          attr = NoAttr;
          name = fullname; 
          namestring = fullnamestr;
          kvars = [];
          vars = (List.map Tvar ftvs) @ (List.map Vvar (pvs@fvs));
          evidences = filterEvidences (currentEvidences()) ((List.map fst ftvs)@(List.map fst fvs));
          extends = Some (if isAffine then mk_affine super else super);
          fields = [];
          staticFields = [];
          methods = [tyappMethod];
          kind = Some (if isAffine then TKind_affine else TKind_star);
          hasTag=false;
          tagNum=None
        } in
        let tconcrete = (fullname, [],
                         (List.map (fun ftv -> Targ(TType_var ftv)) ftvs)
                         @ (List.map (fun fv -> Varg(TVal_var fv)) (pvs@fvs)), 
                         None) in
        let newexp = TExp_val (TVal_obj(tconcrete,[])) in
          (newexp, addToTransEnv transenv newclass) 
    | _ ->
        let errmsg = Printf.sprintf "transTabs: unexpected exp %s"
          (Pretty.strExp e) in
          raise (TransErr errmsg)

(* translation of function application 
   S; G; A |- e1: \x:t -> t' ==> e1'
   S; G; A |- e2: t ==> e2'
   --------------------------------------
   S; G; A |- e1 e2 : t' ==> 
   x1 = e1' in 
   x2 = e2' in
   x1 x2 call [|t'[x2/x]|] C::App([|t1|])
*)
and transApp freevs transenv efun earg : (tExp * transEnv) = 
  (*let _ = Printf.printf "\ntransApp: efun = %s \n with type %s \n and earg = %s \n with type %s" (Pretty.strExp efun) (Pretty.strTyp (efun.sort)) (Pretty.strExp earg) (Pretty.strTyp (earg.sort)) in *)
  let (newfun, transenv) = transE freevs transenv efun in
  let (newarg, transenv) = transE freevs transenv earg in
  let appRef = ("Invoke", []) in
  let (argType, transenv) = transType transenv (earg.sort) in
  let newvar = newVvar argType in
  let (newtfun, transenv) = transType transenv (efun.sort) in
  let newvfun = newVvar newtfun in
    match newfun with
      | TExp_val vfun ->
          (match newarg with
             | TExp_val varg -> TExp_call(vfun, [varg], appRef), transenv
             | _ -> 
                 let call = TExp_call(vfun, [TVal_var newvar], appRef) in
                   (TExp_let(newvar, newarg, call, ref true), transenv))
      | _ -> 
          (match newarg with
             | TExp_val varg ->
                 let call = TExp_call(TVal_var newvfun, [varg], appRef) in
                   (TExp_let(newvfun, newfun, call, ref true), transenv)
             | _ ->
                 let call = TExp_call(TVal_var newvfun, [TVal_var newvar], appRef) in
                   (TExp_let(newvar, newarg, TExp_let (newvfun, newfun, call, ref true), ref true), transenv))
            
(* translation of type application 
   S; G; A |- e: forall a.t' ==> e'
   ----------------------------------------------------------------
   S; G; A |- e[t] : t' ==> e' call [|t'[t/a]|] C::TyApp<[|t|]> 

*)
and transTApp freevs transenv efun targ : (tExp * transEnv) = 
  let (newfun, transenv) = transE freevs transenv efun in
  let (newtfun, transenv) = transType transenv (efun.sort) in
  let newvfun = newVvar newtfun in  
  let (newtarg, transenv) = transType transenv targ in
 (* let _ = pr "transTApp: Exp is %s\n Source sort is %s\n Type arg is %s\n" (Pretty.strExp efun) (Pretty.strTyp efun.sort)
          (Pretty.strTyp targ) in //(PrettyTarget.strType newtfun) (PrettyTarget.strType newtarg) in  *)
  let tyappRef = ("TyApp", [newtarg]) in
    match newfun with
      | TExp_val funval -> (TExp_call(funval, [], tyappRef), transenv)
      | _ ->
          (TExp_let(newvfun, newfun,
                    TExp_call(TVal_var newvfun, [], tyappRef), ref true), transenv)
            
(* translation of pattern match 

   -----------------------------------------------------------------
   S; G; A |- [|match e with pattern_exp_list edefault|]: t ==> 
   x = [|e|] in
   x isinst ([|pattern|] -> [|e|]) [|edefault|]
*)
and transMatch freevs transenv em pes edefault finalTy : (tExp * transEnv) = 
  let (newe, transenv) = transE freevs transenv em in
  let transPatternExp trenv (p, e) =
    match p with 
      | Pat_variant (lid, tys, phantoms, bvs, isGADT) -> (* TODO: handle phantoms in a pattern *)
          let e = (* for GADT, translate (\x:unit.e)() instead of e to build a method for the branch *)
            if isGADT then
              let id = genident None in
              let bvd = mkbvd(id, id) in
              let unite: exp = (ewithinfo (Exp_constant Sugar.Const_unit)
                                  Const.unit_typ
                                  e.p) in 
              let lamt: typ = (twithinfo (Typ_fun(None, Const.unit_typ, e.sort))
                                 Kind_star
                                 e.p) in 
              (match e.v with
                 | Exp_ascribed(ee, t, evidence) ->
                   (* ascrib(ee, t, evidence) => ascribe((\x:unit.e)(), t, evidence) *)
                     let lambe = ewithinfo (Exp_abs(bvd, Const.unit_typ, e)) lamt e.p in 
                     let neweapp = ewithinfo (Exp_app(lambe, unite)) e.sort e.p in
                       ewithinfo (Exp_ascribed(neweapp, t, evidence)) e.sort e.p
                 | _ -> (* e -> (\x:unit.e) () *)
                     let lambe = ewithinfo (Exp_abs(bvd, Const.unit_typ, e)) lamt e.p in 
                       ewithinfo (Exp_app(lambe, unite)) e.sort e.p)
            else e in
          let newftvs = List.rev (List.fold_left (fun ftvs t ->
                                          match t.v with
                                            | Typ_btvar bv -> (Absyn.bvar_real_name bv) :: ftvs
                                            | _ -> ftvs) [] tys) in
          let (newe, trenv) = transE (addFreeTv_vs freevs newftvs (List.map Absyn.bvar_real_name bvs)) trenv e in
          let rec transtys tenv ts newts =
            match ts with
              | [] -> (List.rev newts, tenv)
              | t::rest ->
                  let (newt, tenv) = transType tenv t in
                    transtys tenv rest (newt::newts) in
          let (cname, ks, newts, trenv) =
            if Const.is_tuple_data_lid lid 
            then (* construct the types for Tuple *)
              match bvs with
                | [var1; var2] ->
                    let (newt1, trenv) = transType trenv (var1.sort) in
                    let (newt2, trenv) = transType trenv (var2.sort) in
                    let id = (bvar_real_name var1).idText in
                    let tfun = TType_fun((if isFreeInTyp var1.v var2.sort then Some(id, id) else None), newt1, newt2) in
                    let k1, k2 = 
                      if Sugar.lid_equals lid Const.tuple_UU_lid then TKind_star, TKind_star
                      else if Sugar.lid_equals lid Const.tuple_UA_lid then TKind_star, TKind_affine
                      else if Sugar.lid_equals lid Const.tuple_AU_lid then TKind_affine, TKind_star
                      else if Sugar.lid_equals lid Const.tuple_AA_lid then TKind_affine, TKind_affine 
                      else if Sugar.lid_equals lid Const.tuple_UP_lid then TKind_star, TKind_prop
                      else if Sugar.lid_equals lid Const.tuple_PU_lid then TKind_prop, TKind_star
                      else if Sugar.lid_equals lid Const.tuple_PP_lid then TKind_prop, TKind_prop 
                      else if Sugar.lid_equals lid Const.tuple_AP_lid then TKind_affine, TKind_prop 
                      else if Sugar.lid_equals lid Const.tuple_PA_lid then TKind_prop, TKind_affine 
                      else raise Impos in 
                    (tClassDconDepTuple.name, [k1; k2], [newt1; tfun], trenv)
                | _ -> let msg = "transMatch: unexpected Tuple pattern" in
                    raise (TransErr msg)
            else let (newts, trenv) = transtys trenv tys [] in
              (path_of_lid lid, [], newts, trenv) in
          let rec transbvs tenv bvs newvs =
            match bvs with
              | [] -> (List.rev newvs, tenv) 
              | bv::rest ->
                  let (newv, tenv) = transBVvar tenv bv in
                    transbvs tenv rest (newv::newvs) in
          let (newvs, trenv) = transbvs trenv bvs [] in
          let patterne = (cname, ks, (List.map Ptype newts)@(List.map Pvar newvs), isGADT, newe) in
            (patterne, trenv) in
  let rec transPats trenv pes tces =
    match pes with
      | [] -> (List.rev tces, trenv) 
      | pe::rest ->
          let (tce, trenv) = transPatternExp trenv pe in
            transPats trenv rest (tce::tces) in
  let (tces, transenv) = transPats transenv pes [] in
  let (newedefault, transenv) = transE freevs transenv edefault in
  let (newFinalTy, transenv) = transType transenv finalTy in
  let finale = 
    match newe with
      | TExp_val ve -> TExp_isinst(ve, tces, newedefault, newFinalTy)
      | _ -> let (newt, transenv) = transType transenv (em.sort) in
        let newvar = newVvar newt in
          TExp_let (newvar, newe,
                    TExp_isinst(TVal_var newvar, tces, newedefault, newFinalTy), ref true) in
    (finale, transenv)

(* translation of a record expression *)
(* t is the type of the whole record expression *)
and transRecordExp freevs transenv fes t : (tExp * transEnv) = 
  let (tRecordType, transenv) = transType transenv t in
  let fes = (* sort the fields according to their names *)
    List.sortWith (fun (fname1, _) (fname2, _) -> compare_lid fname1 fname2) fes in
  let tconcrete =
    (match tRecordType with 
       | TType_concrete tconcr -> tconcr
       | TType_name ((n,_),eref) -> (n,[],[], eref)
       | _ ->
           let errmsg =
             Printf.sprintf "transRecordExp: unexpected src type %s and target type %s" 
               (Pretty.strTyp t)
               (PrettyTarget.strType tRecordType) in
             raise (TransErr errmsg)) in
  let rec transFes trenv fieldExps newvs =
    match fieldExps with
      | [] -> TExp_val(TVal_obj(tconcrete, List.rev newvs)), trenv
      | (_, e) :: rest ->
        let (newe, trenv) = transE freevs trenv e in
        (match newe with
           | TExp_val vl -> transFes trenv rest (vl::newvs)
           | _ -> let (newt, trenv) = transType trenv e.sort in
                  let newvar = newVvar newt in
                  let reste, trenv = transFes trenv rest ((TVal_var newvar)::newvs) in
                  TExp_let(newvar, newe, reste, ref true), trenv) in
  transFes transenv fes []

(* translation of dependent tuple constructor applications *)
(* Tuple_** <_>(e1, e2) : Typ_dtuple (x:t1, t2) => *)
(* obj(DconTuple_**<||t1||, \x:||t1||.||t2||, ||e1||, ||e2||>, [] []) *)
and transDtupleConstr freevs transenv dconvar es ttups orige =
  if Const.is_tuple_data_lid dconvar.v 
  then
    match (ttups, es) with
      | ((Some bvdef, t1) :: [(None, t2)], [e1; e2]) ->
          transTuple2Constr freevs transenv dconvar (Some bvdef) t1 t2 e1 e2
      | _ -> transE freevs transenv orige
  else transE freevs transenv orige

and transTuple2Constr freevs transenv dconvar bvdefopt t1 t2 e1 e2 =
  let (newt1, transenv) = transType transenv t1 in
  let (newt2, transenv) = transType transenv t2 in
  let bvar =
   match bvdefopt with
     | Some bvdef -> Some bvdef
     | None -> (match (Absyn.unascribe e1).v with | Exp_bvar bvar -> Some bvar.v | _ -> None) in
  let tfun = 
    match bvar with
      | Some bvdef -> TType_fun((if isFreeInTyp bvdef t2 then Some (transBvDef bvdef) else None), newt1, newt2)
      | _ -> TType_fun(None, newt1, newt2) in
  let (newe1, transenv) = transE freevs transenv e1 in
  let (newe2, transenv) = transE freevs transenv e2 in
  let newvar1 = newVvar newt1 in
  let (newval1, eopt1) =
    (match newe1 with | TExp_val val1 -> (val1, None)
       | _ -> (TVal_var newvar1, Some newe1)) in
  (* take care of the dependency in deptuple, substitute newvar1 for bvdef in newt2 *)
  let newvar2 = match bvdefopt with
    | Some bvdef -> let tmap = addVvarMap emptyTyMap (text_of_id(bvdef.realname), newt1) newval1 in
                    newVvar (substType tmap newt2)
    | None -> newVvar newt2 in
  let (newval2, eopt2) =
    (match newe2 with | TExp_val val2 -> (val2, None)
       | _ -> (TVal_var newvar2, Some newe2)) in
  let (newKind1, transenv) = transKind transenv t1.sort in
  let (newKind2, transenv) = transKind transenv t2.sort in
  let tconcrete =
    (tClassDconDepTuple.name, [newKind1; newKind2], 
     [Targ newt1; Targ tfun; Varg newval1; Varg newval2], None) in
  let constre = TExp_val(TVal_obj(tconcrete, [])) in
  let finale =
    match (eopt1, eopt2) with
      | (None, None) -> constre
      | (Some e, None) -> TExp_let (newvar1, e, constre, ref true)
      | (None, Some e) -> TExp_let (newvar2, e, constre, ref true)
      | (Some e1, Some e2) -> TExp_let (newvar1, e1, TExp_let (newvar2, e2, constre, ref true), ref true)
  in (finale, transenv)
       
(* translation of let binding *)
and transLet freevs transenv is_rec bvdtes e : (tExp * transEnv) = 
  let newfreevs = List.map (fun(bvd, _, _) -> bvd.realname) bvdtes in
  let finalFvs = addFreevs freevs newfreevs in
  let (newbody, transenv) = transE finalFvs transenv e in
  let rec transBvdtes fvs trenv bvdtes laste =
    match bvdtes with
      | [] -> (laste, trenv) 
      | bvdte :: rest ->
          let ((bvd:bvvdef), ty, exp) = bvdte in
          let newid = transBvDefId bvd in
          let (newt, trenv) = transType trenv ty in
          (*let _ = pr "transLet: src = %s \n and tgt = %s \n" (Pretty.strTyp ty) (PrettyTarget.strType newt) in*)
          let newvar = (newid, newt) in
          let newfvs = if is_rec then finalFvs else addFreev fvs (bvd.realname) in
          let (newe, trenv) = transE newfvs trenv exp in
            transBvdtes newfvs trenv rest (TExp_let(newvar, newe, laste, ref true)) in
    transBvdtes (if is_rec then finalFvs else freevs) transenv bvdtes newbody 

(* translation of let-bindings *)
(* Let-bindings are translated into static fields of the class corresponding *)
(* to the module, which has the same name as the module *)
(* type letbinding = list<bvdef * typ * exp> *)
let transLetbinding transenv (let_binding: letbinding) isrec : transEnv * tStaticFieldDecl list =
  let transBinding trenv (bvd: bvvdef, t: typ, e: exp): transEnv * list<tStaticFieldDecl>  = 
    let (external_name, internal_name) = bvd.ppname, bvd.realname in
    let (newt, trenv) = transType trenv t in
    (*let _ = debug:= (external_name.idText = "process_email") in *)
       (*let _ = Printf.printf "Translates source type %s in let binding for %s to %s\n" 
              (Pretty.strTyp t) (external_name.idText) (PrettyTarget.strType newt) in *)
    let (newe, trenv) = transExp trenv e in
      (* Nik: Ugly hack duplicates a static field; once at the
         external name and once at the internal name *)
    let sfdecls: list<tStaticFieldDecl> = [(text_of_id external_name, newt, Some newe)] in
    let sfdecls =
      if internal_name.idText = external_name.idText then sfdecls
      else (text_of_id internal_name, newt, Some newe)::sfdecls in
      (trenv, sfdecls) in
  let rec transBindings trenv bindings out_fdecls = 
    match bindings with
      | [] -> (trenv, out_fdecls)
      | binding::rest -> 
          let (trenv, fdecls) = transBinding trenv binding in
            transBindings trenv rest (out_fdecls@fdecls)
  in transBindings transenv let_binding []

(* translation of type parameters *)
(* type tparam =
   | Tparam_typ  of bvdef * kind (* idents for pretty printing *)
   | Tparam_term of bvdef * typ
*)
let transTParams transenv (tparams: tparam list) : (transEnv * Var list * typ list) =
  let rec transTps trenv tps vars tys =
    match tps with
      | [] -> (trenv, List.rev vars, List.rev tys)
      | (Tparam_typ (bvd, knd)) :: rest -> 
          let (newKind, trenv) = transKind trenv knd in
          let newTvar = (transBvDefId bvd, newKind) in
            transTps trenv rest ((Tvar newTvar) :: vars) tys
      | (Tparam_term (bvd, ty)) :: rest ->
          let (newty, trenv) = transType trenv ty in
          let newVvar = (transBvDefId bvd, newty) in
            transTps trenv rest ((Vvar newVvar) :: vars) (ty::tys) in
    transTps transenv tparams [] []

(* translation of kinds for type constructors *)
let transKindTc transenv (k: kind): (transEnv * Var list * tKind) =
  let rec transkTc trenv k vars =
    match k(* .u *) with 
      | Kind_boxed _ 
      | Kind_star
      | Kind_prop
      | Kind_erasable 
      | Kind_affine -> (trenv, List.rev vars,  fst(transKind trenv k)) 
      | Kind_tcon (None, Kind_affine, k2) ->
          let newTv = newTvar TKind_affine in
            transkTc trenv k2 ((Tvar newTv) :: vars)
      | Kind_tcon (aopt, k1, k2) -> 
          (match aopt with 
             | Some a -> 
                   let newKind, trenv = transKind trenv k1 in
                   let newTv = (text_of_id(a.realname), newKind) in
                      transkTc trenv k2 ((Tvar newTv) :: vars) 
             | None ->                  
                let (newK1, trenv) = transKind trenv k1 in
                let newTv = newTvar newK1 in
                    transkTc trenv k2 ((Tvar newTv) :: vars))
      | Kind_dcon (xopt, t, k2) -> 
          let (newt, trenv) = transType trenv t in
          let newvar = match xopt with 
            | None -> newVvar newt
            | Some x -> ((real_name x).idText, newt) in 
            transkTc trenv k2 ((Vvar newvar) :: vars)
      | _ ->
          let errmsg = Printf.sprintf "transKindTc: unexpected kind %s" 
            (Pretty.strKind k) in
            raise (TransErr errmsg)
  in transkTc transenv k []

(* translation of type constructor *)
(* Type parameters are translated to additional type/value parameters *)
(* in the result generic class *)
let transTycon transenv (lid: lident) (tparams: list<tparam>) (k: kind) (b: bool) 
    : transEnv = 
  let className = path_of_lid lid in
  let (transenv, vars_tp, _) = transTParams transenv tparams in
  let (transenv, vars_k, knd) = transKindTc transenv k in
  let attr_isProp = if b then Prop else NoAttr in
  let newclass: tClassDecl = 
    { externref=None;
      visibility = TVis_public;
      attr = attr_isProp;
      name = className;
      namestring = String.concat "." className;
      kvars = [];
      vars = vars_tp @ vars_k;
      evidences = [];
      extends = None;
      fields = [];
      staticFields = [];
      methods = [];
      kind = Some knd;
      hasTag = true;
      tagNum = None;
    } in
    addToTransEnv transenv newclass

(* translate the dependent type of a data constructor *)
(* Return a list of new value variables, a list of class declarations, *)
(* and the result type *)
let transDconDep transenv (dept: typ)
    : transEnv * tVar<tType> list * tType * typ list =
  let rec transDconDepfun count trenv dept vvars tys =
    match dept.v with 
      | Typ_fun (bvd_opt, t1, t2) -> 
          let (newt1, trenv) = transType trenv t1 in
          let newvar =
            match bvd_opt with
              | None -> 
                  let name = Printf.sprintf "field_%d" count in
                    (name, newt1)
              | Some bvd -> (transBvDefId bvd, newt1) in (* TODO: Maybe always generate a nice name for parameters *)
            transDconDepfun (count+1) trenv t2 (vvars @ [newvar]) (tys @ [t1])
      | t -> 
          let (newt, trenv) = transType trenv dept in
            (trenv, vvars,  newt, tys) in
    transDconDepfun 1 transenv dept [] []

(* translate the type of a data constructor to a list of variables, 
   a list of class declarations, and the result type (type constructor instantiation)
*)
let transDconType transenv (t: typ) : (transEnv * Var list * tType * typ list) =
  let rec transDconPoly trenv (ty: typ) tvars =
    match ty.v with
      | Typ_univ (bvd, knd, _, tbody) -> (* NS: TODO! Dropping constraints *)
          let (newKind, trenv) = transKind trenv knd in
          let newtvar = (transBvDefId bvd, newKind) in
            transDconPoly trenv tbody (tvars @ [newtvar])
      | dept -> 
          let (trenv, vvars,  resultType, tys) = transDconDep trenv ty in
            (trenv, (List.map Tvar tvars) @ (List.map Vvar vvars), resultType, tys) in
    transDconPoly transenv t []

let genericEqualityRef = 
  let eref = {Sugar.language=Sugar.FSharp; 
              Sugar.dll="FSharp.Core"; 
              Sugar.namespce=asLid [];
              Sugar.classname=Const.p2l ["Microsoft.FSharp.Core.LanguagePrimitives"];
              Sugar.innerclass=Some "HashCompare"; Sugar.extqual=None} in
    eref, "GenericEqualityIntrinsic"
let genericEqualityMethodDecl = 
   let eref, mn = genericEqualityRef in 
    {extref=eref; methodname=mn; 
     formalargs=[TType_index 0us; TType_index 0us];
     ret=boolType}

let printStringRef = 
  let eref = {Sugar.language=Sugar.FSharp; 
              Sugar.dll="FSharp.Core"; 
              Sugar.namespce=asLid [];
              Sugar.classname=Const.p2l ["Microsoft.FSharp.Core.LanguagePrimitives"];
              Sugar.innerclass=Some "HashCompare"; Sugar.extqual=None} in
    eref, "print_string"


let is_value_type = function
    TType_name (((["Prims"; "bool"], _)), _)
  | TType_name (((["Prims"; "unit"], _)), _)
  | TType_name (((["Prims"; "int"], _)), _)
  | TType_name (((["Prims"; "string"], _)), _) -> true
  | _ -> false 
      
let addToStringMethod trenv (cdecl:tClassDecl) tys =
  let pickler_eref = Some {language = FSharp;
                           dll = "runtime";
                           namespce = lid_of_path ["Microsoft";"FStar";"Runtime"] 0L;
                           classname = lid_of_path ["Pickler"] 0L;
                           innerclass = None;
                           extqual = None;} in
  let string_arrow_string_typ = (* string -> string *)
    TType_concrete(["DepArrow"], 
                   [TKind_star; TKind_star],
                   [Targ (stringType);
                    Targ (TType_fun
                            (None, 
                             stringType, 
                             stringType))], 
                   None) in
  let string_cat_typ = (* string -> string -> string *)
    TType_concrete(["DepArrow"], 
                   [TKind_star; TKind_star],
                   [Targ (stringType);
                    Targ (TType_fun
                            (None, 
                             stringType, 
                             string_arrow_string_typ))], 
                   None) in
  let string_cat = TExp_name((["Prims"; "strcat"], string_cat_typ), pickler_eref) in (* Prims.strcat *)
  let string_cat_var = newSym(), string_cat_typ in (* string_cat_var: string -> string -> string *)
  let string_cat_val = TVal_var(string_cat_var) in 
  let string_of_any_typ = (* 'a -> string *)
    TType_concrete(tClassAll.name, 
                   [TKind_star; TKind_star],
                   [Targ
                      (TType_tfun
                         (("'a", "'a"),TKind_star,
                          TType_concrete
                            (["DepArrow"], [TKind_star; TKind_star],
                             [Targ (TType_var ("'a", TKind_star));
                              Targ (TType_fun(None,
                                              TType_var ("'a", TKind_star),
                                              stringType))], None)))], 
                   None) in
  let string_of_any_afn_typ = (* ('a::A) -> string *)
    TType_concrete(tClassAll.name, 
                   [TKind_affine; TKind_star],
                   [Targ
                      (TType_tfun
                         (("'a", "'a"),TKind_affine,
                          TType_concrete
                            (["DepArrow"], [TKind_affine; TKind_star],
                             [Targ (TType_var ("'a", TKind_affine));
                              Targ (TType_fun(None,
                                              TType_var ("'a", TKind_affine),
                                              stringType))], None)))], 
                   None) in
  let string_of_any_p_typ = (* ('a::P) -> string *)
    TType_concrete(tClassAll.name, 
                   [TKind_prop; TKind_star],
                   [Targ
                      (TType_tfun
                         (("'a", "'a"),TKind_prop,
                          TType_concrete
                            (["DepArrow"], [TKind_prop; TKind_star],
                             [Targ (TType_var ("'a", TKind_prop));
                              Targ (TType_fun(None,
                                              TType_var ("'a", TKind_prop),
                                              stringType))], None)))], 
                   None) in
  let string_of_any = TExp_name((["Prims"; "string_of_any_for_coq"], string_of_any_typ), pickler_eref) in (* Prims.string_of_any_for_coq *)
  let string_of_any_afn = TExp_name((["Prims"; "string_of_any_for_coq_afn"], string_of_any_afn_typ), pickler_eref) in (* Prims.string_of_any_for_coq_afn *)
  let string_of_any_p = TExp_name((["Prims"; "string_of_any_for_coq_p"], string_of_any_p_typ), pickler_eref) in (* Prims.string_of_any_for_coq_p *)
  let string_of_any_var = newSym(), string_of_any_typ in (* string_of_any_var: 'a -> string *)
  let string_of_any_val = TVal_var(string_of_any_var) in 
  let string_of_any_afn_var = newSym(), string_of_any_afn_typ in (* string_of_any_afn_var: 'a -> string *)
  let string_of_any_afn_val = TVal_var(string_of_any_afn_var) in 
  let string_of_any_p_var = newSym(), string_of_any_p_typ in (* string_of_any_p_var: 'a -> string *)
  let string_of_any_p_val = TVal_var(string_of_any_p_var) in 
  let body =
    let cn = cdecl.name in
    let fields = ((getVvars cdecl)@cdecl.fields) in
    let fields_tys = List.zip fields tys in
    let stringOfField field_ty =  (* let tmp = string_of_any<field_typ>() in tmp(field) *)
      let (field, ty) = field_ty in
      let knd, string_of_any_val = match ty.sort(* .u *) with
                  | Kind_affine
                  | Kind_boxed Kind_affine -> TKind_affine, string_of_any_afn_val
                  | Kind_prop
                  | Kind_boxed Kind_prop -> TKind_prop, string_of_any_p_val
                  | _ -> TKind_star, string_of_any_val in
      let field_typ = snd field in 
      let tmp_typ = (* field_typ -> string *)
        TType_concrete(["DepArrow"], 
                       [knd; TKind_star],
                       [Targ (snd field);
                        Targ (TType_fun(None, field_typ, stringType))],
                       None) in
      let tmp = newSym(), tmp_typ in
        TExp_let(tmp, 
                 TExp_call(string_of_any_val, [], ("TyApp", [field_typ])), 
                 TExp_call(TVal_var tmp, [TVal_var field], ("Invoke", [])), 
                 ref true) in 
    let asString (s:string) = (* constant_string (bytes_of_s) *)
      TExp_val(TVal_constant (Sugar.Const_string (Util.unicodeEncoding.GetBytes s, 0L))) in 
    let fields = List.map stringOfField fields_tys in (* let tmp1 = string_of_any<field1_typ>() in tmp1(field1); ... *)
    let thisString = (* cdecl name *)
      let _, constrName = Util.pfx cdecl.name in 
        asString constrName in
    let callInstrs = match fields with 
      | [] -> [thisString]
      | _ -> 
          let instrs = List.fold_right (fun field out -> (asString " ")::field::out) (thisString::fields) [] in
            (asString "(")::instrs@([asString ")"]) in (* [(; constr; fields; )] *)
    let rec sequence = function (* let x = "(" in let y = rest in let z = string_cat_val(x) in z(y) *)
      | [last] -> last
      | hd::tl -> 
          let x = (newSym(), stringType) in
          let y = (newSym(), stringType) in
          let z = (newSym(), string_arrow_string_typ) in 
            TExp_let(x, 
                     hd, 
                     TExp_let(y, 
                              sequence tl, 
                              TExp_let(z, 
                                       TExp_call(string_cat_val, [TVal_var x], ("Invoke", [])), 
                                       TExp_call(TVal_var z, [TVal_var y], ("Invoke", [])), 
                                       ref true),
                              ref true), 
                     ref true) in
    (* let string_cat_var = let string_of_any_var = string_of_any in "(constr; fields)" *)
    let body = TExp_let(string_cat_var, string_cat,  
                        TExp_let(string_of_any_var, string_of_any, 
                                 TExp_let(string_of_any_afn_var, string_of_any_afn,
                                   TExp_let(string_of_any_p_var, string_of_any_p,
                                          sequence callInstrs, ref true), ref true), ref true), ref true) in 
      body in 
  let methodName = "ToString" in
  let md = (stringType, methodName, [], [], Some body) in
    trenv, {cdecl with methods=md::cdecl.methods}

let addEqualityMethod (cdecl:tClassDecl) = 
  let truev, falsev = TExp_val trueVal, TExp_val falseVal in
  let branch = 
    let cn = cdecl.name in
    let targs = List.map (fun t -> TType_var t) (getTvars cdecl) in
    let vars, fields = getVvars cdecl, cdecl.fields in
    let ovars, ofields = List.map (fun (fn, t) -> let loc = newSym () in (loc,t)) vars,
      List.map (fun (fn, t) -> let loc = newSym () in (loc,t)) fields in
    let eref, geneq_mname = genericEqualityRef in
    let rec mk_body xs fields locals = match fields, locals with
      | field::fields, local::locals ->
          let x = newSym(), boolType in
          let body = mk_body (x::xs) fields locals in
          let t = snd field in
          let this_eq = 
            TExp_extern_call(eref, (geneq_mname, [t]), [TVal_var field; TVal_var local]) in
            TExp_let(x, this_eq, body, ref true)
      | [], [] -> 
          List.fold_left (fun out x -> TExp_cond(TExp_val (TVal_var x), out, falsev)) truev xs in
    let body = mk_body [] (vars@fields) (ovars@ofields) in
      (cn, List.map TKind_var cdecl.kvars, (List.map Ptype targs) @ (List.map Pvar ovars) @ (List.map Pfield ofields), false, body) in
  let methodName = "Equals" in
  let tparams = [] in
  let argument = (newSym (), objType) in
  let newloc = newSym (), objType in 
  let body = TExp_let(newloc, TExp_val (TVal_var argument), TExp_isinst(TVal_var newloc, [branch], falsev, boolType), ref true) in
  let md = (boolType, methodName, tparams, [argument], Some body) in
    {cdecl with methods=md::cdecl.methods}

(* translation of data constructors *)
(* "tparams" are inherited from the enclosing type constructor *)
(* The type of data constructor is in curried format *)
let transDcon transenv (aq:aqual) (lid: lident) (tparams: list<tparam>) (t: typ) (b: bool) (tagOpt:option<int>)
    : transEnv  =
  let className = path_of_lid lid in
  let (transenv, vars_tp, tys_tp) = transTParams transenv tparams in
  let (transenv, vars_t, super, tys_t) = transDconType transenv t in
  let vis = match aq with Public -> TVis_public | _ -> TVis_internal in
  let attr_isAxiom = if b then Axiom else NoAttr in
  let vars = vars_tp @ vars_t in
  let newclass: tClassDecl = 
    { externref=None;
      visibility = vis;
      attr = attr_isAxiom;
      name = className;
      namestring = String.concat "." className;
      kvars = [];
      vars = vars;
      evidences = [];
      extends = Some super; 
      fields = [];
      staticFields = [];
      methods = [];
      kind = None;   (* data constructors have the same type as their tcon *)
      hasTag = false;
      tagNum = tagOpt;
    } in
  let isPrims cn = match cn with 
    | "Prims"::_ -> true
    | _ -> false in
  let transenv, newclass = 
    if not !Options.extract_proofs then 
      let newclass = addEqualityMethod newclass in
        if isPrims className then transenv, newclass 
        else addToStringMethod transenv newclass (tys_tp @ tys_t)
    else transenv, newclass in
    addToTransEnv transenv newclass

(* translation signelt *)
(* type sigelt =
   | Sig_tycon_kind   of lident * list<tparam> * kind * bool (* bool identifies a prop *)
   | Sig_typ_abbrev   of lident * list<tparam> * typ
   | Sig_typ_abstract of lident * list<tparam>
   | Sig_datacon_typ  of lident * list<tparam> * typ * bool (* bool identifies an assumption *)
   | Sig_value_decl   of lident * typ 
   | Sig_extern_value of lang * lident * typ
   | Sig_extern_typ   of Sugar.externref * sigelt (* lident * typ * kind *)
   | Sig_record_typ   of lident * list<tparam> * typ
   | Sig_ghost_assume of lident * formula * aqual
*)
let generateExternWrapper transenv eref extid top : transEnv * tStaticFieldDecl list * tExternMethodDecl = 
  let thisModuleName, methodName = Util.pfx extid in
  let rec transTref env argTypes t = match t.v with
    | Typ_univ(bvd, k, _, t) -> (* NS: TODO! Dropping constraints *)
        transTref (env@[real_name bvd]) argTypes t 
    | Typ_fun(_, targ, tret) -> 
        let tt, transenv = transTypeWithEnv env transenv targ in

        transTref env (tt::argTypes) tret
    | _ -> 
        let tret, transenv = transTypeWithEnv env transenv t in
        List.rev argTypes, tret in 
  let rec mk_fun tyargs args t = match t.v with
    | Typ_fun(bvd_opt, targ, tret) -> 
        let id = genident None in
        let bvd = (match bvd_opt with Some bvd -> bvd | None -> mkbvd(id, id)) in
        let bv = ewithsort (Exp_bvar (bvd_to_bvar_s bvd targ)) targ in
        let body = mk_fun tyargs (bv::args) tret in
          ewithsort (Exp_abs(bvd, targ, body)) t
    | Typ_univ(bvd, k, _, tret) -> (* NS: TODO! Dropping constraints *)
        let tyargs = match k(* .u *) with 
          | Kind_star -> let tbv = twithsort (Typ_btvar (bvd_to_bvar_s bvd k)) k in tbv::tyargs 
          | _ -> tyargs in
        let body = mk_fun tyargs args tret in
          ewithsort (Exp_tabs(bvd, k, [], body)) t (* NS: TODO! Dropping constraints *)
    | _ -> 
        let rec mk_call letvars = function
          | [] -> 
              ewithsort (Exp_extern_call(eref, methodName, top, List.rev tyargs, letvars)) t
          | arg::tl -> 
              let id = genident None in
              let bvd = mkbvd(id,id) in
              let bv = ewithsort (Exp_bvar (bvd_to_bvar_s bvd arg.sort)) arg.sort in
              let body = mk_call (bv::letvars) tl in
               ewithsort (Exp_let(false, [(bvd, arg.sort, arg)], body)) t in
          mk_call [] args in
  let wrapper = mk_fun [] [] top in
  let letbinding = [mkbvd(methodName, methodName), top, wrapper] in
  (*let _ = pr "wrapper = %s " (Pretty.strLet [(letbinding, false)]) in*)
  let transenv, sfields = transLetbinding transenv letbinding false in
  let tformals, tret = transTref [] [] top in
    transenv, sfields, {extref=eref; methodname=methodName.idText; formalargs=tformals; ret=tret}


let new_bvd_bvar t =  
  let x = new_bvd None in 
  let xx = bvd_to_bvar_s x t in 
    x, ewithsort (Exp_bvar xx) t

let w t = twithsort t Kind_star
let W t s = ewithsort t s 

let boolTyp = Const.bool_typ
let pf_typ t = w (Typ_app(Const.pf_typ, t))  (* pf<t> *)
let and_typ = Const.and_typ
let implies_typ = Const.implies_typ
let or_typ = Const.or_typ
let starStarKind = Kind_tcon(None, Kind_star, Kind_star)

let lookupDcon tcenv lid =
  let t = Tcenv.lookup_lid tcenv lid in
    fvwithsort lid t
let f_refl_var tcenv = Tcutil.reflexivity_var tcenv 
let f_and_intro_var tcenv = lookupDcon tcenv Const.and_intro_lid
let f_or_intro1_var tcenv = lookupDcon tcenv Const.or_intro1_lid
let f_implies_intro_var tcenv = lookupDcon tcenv Const.implies_intro_lid 
let f_tuple_var tcenv = lookupDcon tcenv Const.tuple_UU_lid
let f_eq_typ tcenv t e = (* Eq<t; e, e> *)
  w (Typ_dep(twithsort (Typ_dep(Tcutil.eqT_of_typ tcenv t, e))
               (Kind_dcon(None, t, Kind_star)),
             e)) 

let mkImpliesEqTy tcenv t1 t2 e1 e2 = (* l_implies<pf<Eq<t1; e1, e1>>, pf<Eq<t2; e2, e2>>> *)
  w (Typ_app(twithsort (Typ_app(implies_typ, pf_typ(f_eq_typ tcenv t1 e1))) starStarKind,
             pf_typ(f_eq_typ tcenv t2 e2)))
let mkImplies tcenv t1 t2 e1 e2 =
  (* ImpliesIntro<Eq<t1; e1, e1>, Eq<t2; e2, e2>> \x:pf<Eq<t1; e1, e1>>.(Reflexivity<t2> e2 *)
  (*                                             : pf<Eq<t2; e2, e2>>) *)
  (* : pf<l_implies<pf<Eq<t1; e1, e1>>, pf<Eq<t2; e2, e2>>>> *)
  let eqTy1, eqTy2 = f_eq_typ tcenv t1 e1, f_eq_typ tcenv t2 e2 in
  let pfEqTy1, pfEqTy2 = pf_typ eqTy1, pf_typ eqTy2 in
  let exp_fun =
    let body = W (Exp_constr_app(f_refl_var tcenv, [t2], [], [e2])) pfEqTy2 in
    let fun_typ = w (Typ_fun(None, pfEqTy1, pfEqTy2)) in
      W (Exp_abs(new_bvd None, pfEqTy1, body)) fun_typ in
    W (Exp_constr_app(f_implies_intro_var tcenv, [eqTy1; eqTy2], [], [exp_fun]))
      (pf_typ (mkImpliesEqTy tcenv t1 t2 e1 e2))

(* types/terms for proofs of boolean type*)
let f_eqBoolTyp tcenv = (* Eq<Bool; true, true> *)
  f_eq_typ tcenv boolTyp Const.exp_true_bool
let f_pfEqTyp tcenv = (* pf<Eq<Bool; true, true> *)
  pf_typ (f_eqBoolTyp tcenv)
let f_impliesPfEqTyp tcenv = (* l_imples(pf<Eq<bool>>, pf<Eq<bool>>) *)
  mkImpliesEqTy tcenv boolTyp boolTyp Const.exp_true_bool Const.exp_true_bool
let f_pfImpliesPfEqTyp tcenv = (* pf<l_imples(pf<Eq<bool>>, pf<Eq<bool>>)> *)
  pf_typ (f_impliesPfEqTyp tcenv)

let f_pfEq tcenv = (* reflexivity<boolTyp> Const.exp_true_bool : pf<Eq<bool; true; true>> *)
  W (Exp_constr_app(f_refl_var tcenv, [boolTyp], [], [Const.exp_true_bool])) (f_pfEqTyp tcenv)

let f_pfImpliesPfEq tcenv = mkImplies tcenv boolTyp boolTyp Const.exp_true_bool Const.exp_true_bool

(* add /\'a \x:'a \y:'a. call eq(x, y) as the body of Prims.op_Equality *)
let generateEqualityOp transenv top = match top.v with  
  | Typ_univ(tvar, knd, _, {v=Typ_fun(_, ttvar, {v=Typ_fun(_, t', result_t); sort=_; p=_}); sort=_; p=_}) ->  (* NS: TODO! Dropping constraints *)
      let eref = {Sugar.language=Sugar.FSharp;  
                  Sugar.dll="FSharp.Core";  
                  Sugar.namespce=asLid [];
                  Sugar.classname=Const.p2l ["Microsoft.FSharp.Core.LanguagePrimitives"]; 
                  Sugar.innerclass=Some "HashCompare"; Sugar.extqual=None} in 
      let (x, xx), (y, yy) = new_bvd_bvar ttvar, new_bvd_bvar ttvar in 
      let tv = new_bvd None in 
      let bv = w (Typ_btvar(bvd_to_bvar_s tv Kind_star)) in 
      let univ = w (Typ_univ(tv, Kind_star,  [], (* NS: TODO! Dropping constraints *)
                             w (Typ_fun(None, bv, w (Typ_fun(None, bv, Const.bool_typ)))))) in 
      let callExp = W (Exp_extern_call(eref, Sugar.text_to_id0 "GenericEqualityIntrinsic", univ, [ttvar], [xx;yy])) Const.bool_typ in
      let bodyExp = 
        if (not (!Options.extract_proofs)) then callExp
        else let tcenv = getTcenv transenv in
              let impliesBoolTvarTy = (* l_implies<pf<Eq<bool; true, true>>, pf<Eq<tvar; x, x>>> *)
                mkImpliesEqTy tcenv Const.bool_typ ttvar Const.exp_true_bool xx in
              let impliesTvarBoolTy = (* l_implies<pf<Eq<tvar; x, x>>, pf<Eq<bool; true, true>>> *)
                mkImpliesEqTy tcenv ttvar Const.bool_typ xx Const.exp_true_bool in
              let proofTy = pf_typ(w (Typ_app(twithsort (Typ_app(and_typ, pf_typ(impliesBoolTvarTy)))
                                                (Kind_tcon(None, Kind_star, Kind_star)),
                                              pf_typ(impliesTvarBoolTy)))) in
              let proofTerm = 
                (* AndIntro<l_implies<pf<Eq<bool; true, true>>, pf<Eq<tvar; x, x>>>, *)
                (*          l_implies<pf<Eq<tvar; x, x>>, pf<Eq<bool; true, true>>>> *)
                (*          (mkImplies bool tvar true x) *)
                (*          (mkImplies var bool x true)  *)
                (* : pf<l_and<pf<l_implies<pf<Eq<bool; true, true>>, pf<Eq<tvar; x, x>>>>, *)
                (*            pf<l_implies<pf<Eq<tvar; x, x>>, pf<Eq<boo; true, true>>>>>>> *)
                W 
                  (Exp_constr_app(f_and_intro_var tcenv, [impliesBoolTvarTy; impliesTvarBoolTy], [], 
                                  [mkImplies tcenv Const.bool_typ ttvar Const.exp_true_bool xx;
                                   mkImplies tcenv ttvar Const.bool_typ xx Const.exp_true_bool])) 
                  (proofTy) in
                (* tuple_UU<bool, proofTy> callExp proofTerm: Typ_dtuple(bool, proofTy) *)
                W (Exp_constr_app(f_tuple_var tcenv, [Const.bool_typ; proofTy], [],
                                  [callExp; proofTerm]))
                  (w(Typ_dtuple([(None, Const.bool_typ); (None, proofTy)]))) in
      let inner_fun = w (Typ_fun(None, ttvar, result_t)) in 
      let wrapper = W (Exp_abs(x, ttvar,  
                               (W (Exp_abs(y, ttvar, bodyExp))
                                  inner_fun))) 
        (w (Typ_fun(None, ttvar, inner_fun))) in 
      let polyWrapper = W (Exp_tabs(tvar, knd, [], wrapper)) top in (* NS: TODO! Dropping constraints *)
      let _, mname = Util.pfx (Const.op_Eq.lid) in 
      let letbinding = [mkbvd(mname, mname), top, polyWrapper] in 
        (* let _  = Printf.printf "Adding let bindnig for equality op %s at typ %s\n: %s" mname.idText (Pretty.strTyp top) 
           (Pretty.strExp polyWrapper) in *)
        transLetbinding transenv letbinding false 
  | _ -> transenv, [] 

let booleanAndMethodDecl, booleanOrMethodDecl = 
    let eref = {Sugar.language=Sugar.FSharp;  
                  Sugar.dll="FSharp.Core";  
                  Sugar.namespce=asLid [];
                  Sugar.classname=Const.p2l ["Microsoft.FSharp.Core.LanguagePrimitives"]; 
                  Sugar.innerclass=Some "IntrinsicOperators"; Sugar.extqual=None} in
    let band = {extref=eref; methodname="op_BooleanAnd"; formalargs=[boolType;boolType]; ret=boolType} in
    let bor = {extref=eref; methodname="op_BooleanOr"; formalargs=[boolType;boolType]; ret=boolType} in
        band, bor

let generateAndOrOp transenv top lid = match top.v with
  | Typ_fun(_, _, {v=Typ_fun(_, _, result_t); sort=_; p= _}) ->
      let eref = {Sugar.language=Sugar.FSharp;  
                  Sugar.dll="FSharp.Core";  
                  Sugar.namespce=asLid [];
                  Sugar.classname=Const.p2l ["Microsoft.FSharp.Core.LanguagePrimitives"]; 
                  Sugar.innerclass=Some "IntrinsicOperators"; Sugar.extqual=None} in 
      let (x, xx), (y, yy) = new_bvd_bvar Const.bool_typ, new_bvd_bvar Const.bool_typ in
      let externMethodDecl  = if (Sugar.lid_equals lid Const.op_And_lid) then booleanAndMethodDecl else booleanOrMethodDecl in 
      let funcName = externMethodDecl.methodname in
      let funcTyp = w (Typ_fun(None, boolTyp,
                               w (Typ_fun(None, boolTyp, boolTyp)))) in
      let callExp = W (Exp_extern_call(eref, Sugar.text_to_id0 funcName, funcTyp, [], [xx;yy])) boolTyp in
      let bodyExp =
        if (not (!Options.extract_proofs)) then callExp 
        else let tcenv = getTcenv transenv in
              let pfEqTyp = f_pfEqTyp tcenv in
              let eqBoolTyp = f_eqBoolTyp tcenv in
              let pfEq = f_pfEq tcenv in
              let andPfEqTyp = (* l_and pfEqTyp pfEqTyp *)
                w (Typ_app(twithsort (Typ_app(and_typ, pfEqTyp)) starStarKind, pfEqTyp)) in
              let orPfEqTyp = (* l_or pfEqTyp pfEqTyp *)
                w (Typ_app(twithsort (Typ_app(or_typ, pfEqTyp)) starStarKind, pfEqTyp)) in
                (* proof term for and: b=true => x=true &&  y=true *)
              let proofTyp_and = (*l_implies pfEqTyp (l_and pfEqTyp pfEqTyp) *)
                pf_typ (w (Typ_app(twithsort (Typ_app(implies_typ, pfEqTyp)) starStarKind, pf_typ andPfEqTyp))) in
              let proofTerm_and = (*impliesIntro<EqBoolTyp, l_and pfEqTyp pfEqTyp> \x:pfEqTyp.andIntro<eqBoolTyp, eqBoolTyp> pfEq pfEq*)
                W (Exp_constr_app(f_implies_intro_var tcenv, [eqBoolTyp; andPfEqTyp], [], 
                                  [W (Exp_abs(new_bvd None, pfEqTyp, 
                                              W (Exp_constr_app(f_and_intro_var tcenv, [eqBoolTyp; eqBoolTyp], [], [pfEq; pfEq]))
                                                (pf_typ andPfEqTyp)))
                                     (w (Typ_fun(None, pfEqTyp, pf_typ andPfEqTyp)))]))
                  proofTyp_and in

              (* proof term for or: (z=true => x=true ||  y=true) && (z=false => x=false &&  y=false) *)
              let impliesEqOrTyp = w (Typ_app(twithsort (Typ_app(implies_typ, pfEqTyp)) starStarKind, pf_typ orPfEqTyp)) in
              let impliesEqAndTyp = w (Typ_app(twithsort (Typ_app(implies_typ, pfEqTyp)) starStarKind, pf_typ andPfEqTyp)) in
              let proofTyp_or = (*pf<l_and pf<impliesEqOrTyp> pf<impliesEqAndTyp>> *)
                pf_typ (w (Typ_app(twithsort (Typ_app(and_typ, pf_typ impliesEqOrTyp)) starStarKind, pf_typ impliesEqAndTyp))) in
              let proofTerm_or = (* andIntro<impliesEqOrTyp, impliesEqAndTyp>  *)
                (*         (impliesIntro<eqBoolTyp, orPfEqTyp> \x:pfEqTyp.orIntro<eqBoolTyp, eqBoolTyp> pfEq) *)
                (*         (impliesIntro<eqBoolTyp, andpfEqTyp> \x:pfEqTyp.andIntro<eqBoolTyp, eqBoolTyp> pfEq pfEq) *)
                W (Exp_constr_app(f_and_intro_var tcenv, [impliesEqOrTyp; impliesEqAndTyp], [],
                                  [W (Exp_constr_app(f_implies_intro_var tcenv, [eqBoolTyp; orPfEqTyp], [],
                                                     [W (Exp_abs(new_bvd None, pfEqTyp, 
                                                                 W (Exp_constr_app(f_or_intro1_var tcenv, 
                                                                                   [eqBoolTyp; eqBoolTyp], 
                                                                                   [], [pfEq]))  
                                                                   (pf_typ orPfEqTyp)))
                                                        (w (Typ_fun(None, pfEqTyp, pf_typ orPfEqTyp)))]))
                                     (pf_typ impliesEqOrTyp);
                                   W (Exp_constr_app(f_implies_intro_var tcenv, [eqBoolTyp; andPfEqTyp], [],
                                                     [W (Exp_abs(new_bvd None, pfEqTyp, 
                                                                 W (Exp_constr_app(f_and_intro_var tcenv, [eqBoolTyp; eqBoolTyp], [], [pfEq; pfEq]))
                                                                   (pf_typ andPfEqTyp)))
                                                        (w (Typ_fun(None, pfEqTyp, pf_typ andPfEqTyp)))]))
                                     (pf_typ impliesEqAndTyp)]))
                  proofTyp_or in
              let proofTy, proofTerm = 
                if (Sugar.lid_equals lid Const.op_And_lid)
                then (proofTyp_and, proofTerm_and)
                else (proofTyp_or, proofTerm_or) in
                (* tuple_UU<bool, proofTy> callExp proofTerm: Typ_dtuple(bool, proofTy) *)
                W (Exp_constr_app(f_tuple_var tcenv, [Const.bool_typ; proofTy], [],
                                  [callExp; proofTerm]))
                  (w(Typ_dtuple([(None, Const.bool_typ); (None, proofTy)]))) in
      let inner_fun = w (Typ_fun(None, boolTyp, result_t)) in
      let wrapper = W (Exp_abs(x, boolTyp,
                               (W (Exp_abs(y, boolTyp, bodyExp))
                                  inner_fun)))
        (w (Typ_fun(None, boolTyp, inner_fun))) in
      let _, mname = Util.pfx lid.lid in
      let letbinding = [mkbvd(mname, mname), top, wrapper] in
        transLetbinding transenv letbinding false
  | _ -> transenv, []

let generateNotOp transenv top = match top.v with
  | Typ_fun(_, _, result_t) ->
      let (x, xx) = new_bvd_bvar boolTyp in
      let mainExp = (* Exp_cond(xx, Const.exp_false_bool, Const.exp_true_bool) *)
        W (Exp_cond(xx, Const.exp_false_bool, Const.exp_true_bool)) boolTyp in
      let bodyExp =
        if (not (!Options.extract_proofs)) then mainExp
        else let tcenv = getTcenv transenv in
              (* a proof term with type l_and<pf<l_implies(pf<Eq<bool>>, pf<Eq<bool>>)>, *)
              (*                              pf<l_implies(pf<Eq<bool>>, pf<Eq<bool>>)>> *)
              let pfImpliesPfEqTyp = f_pfImpliesPfEqTyp tcenv in
              let pfImpliesPfEq = f_pfImpliesPfEq tcenv in
              let impliesPfEqTyp = f_impliesPfEqTyp tcenv in
              let proofTy = pf_typ(w (Typ_app(twithsort (Typ_app(and_typ, pfImpliesPfEqTyp)) starStarKind, pfImpliesPfEqTyp))) in
              let proofTerm = (*andIntro<impliesPfEqTyp, impliesPfEqTyp>  pfImpliesPfEq pfImpliesPfEq*)
                W (Exp_constr_app(f_and_intro_var tcenv, [impliesPfEqTyp; impliesPfEqTyp], [], [pfImpliesPfEq; pfImpliesPfEq]))
                  proofTy
              in
                W (Exp_constr_app(f_tuple_var tcenv, [boolTyp; proofTy], [], [mainExp; proofTerm])) 
                  (w (Typ_dtuple([(None, boolTyp); (None, proofTy)])))
      in
      let funcTyp = w (Typ_fun(None, boolTyp, result_t)) in
      let wrapper = W (Exp_abs(x, boolTyp, bodyExp)) funcTyp in
      let _, mname = Util.pfx Const.op_Not_lid.lid in
      let letbinding = [mkbvd(mname, mname), top, wrapper] in
        (*let _  = Printf.printf "\nAdding let bindnig for negation op %s at typ %s\n: %s" mname.idText (Pretty.strTyp top) 
          (Pretty.strExp wrapper) in*)
        transLetbinding transenv letbinding false
  | _ -> transenv, []

let is_autogen = function
  | Sig_tycon_kind (lid, _, _, _, _, _) 
  | Sig_datacon_typ (lid, _, _, _, _, _, _, _) -> 
      let _, id = Util.pfx lid.lid in
      let id = id.idText in
        (String.length id) > 6 && (String.sub id 0 6) = "__AUTO" 
  | _ -> false
      
(* add this prefix to every extern class declaration *)
(* Should be the same as in Sugar.fs::extern_id *)
let exnDeclPrefix = "__Extern"

let is_primop_dummy (lid:lident) = match lid.lid with 
  | [prim;opname] when prim.idText="Prims" ->
      let opstr = opname.idText in
        opstr.Length >= 10 && String.sub opstr 0 10 = "_dummy_op_"
  | _ -> false

let getTagNumForDcon = 
  let tags = ref [] in 
    fun tlid dlid -> 
      match findOpt (fun (tlid', _) -> Sugar.lid_equals tlid tlid') !tags with 
        | None -> 
            tags := (tlid, ref [(dlid, 1)])::!tags;
            1
        | Some (_, tlid_tags) -> 
            match findOpt (fun (dlid', _) -> Sugar.lid_equals dlid dlid') !tlid_tags with 
              | None -> 
                  let ctr = List.length !tlid_tags in 
                    tlid_tags := (dlid, ctr+1)::!tlid_tags;
                    ctr+1
              | Some _ -> raise Impos

let rec transSigelt transenv (sige: sigelt): transEnv * tStaticFieldDecl list * tClassDecl list * option<tExternMethodDecl> =
  (*let _ = pr "\ntransSigelt: %s " (Pretty.strSigelt sige) in*)
  if is_autogen sige then transenv,[], [], None else
    match sige with
      | Sig_query _ -> transenv, [], [], None (* NIK: Dropping queries for now *)
      | Sig_tycon_kind (lid, tparams, knd, bl, _, _) ->
          let name = text_of_lid lid in 
            if name = "Prims.int" || name = "Prims.bool" || name= "Prims.string" || name = "Prims.unit" then 
              transenv, [], [], None
            else
              let _ = DebugLog.Log(Printf.sprintf "\n sigelt: tcon %s" (Pretty.str_of_lident lid)) in
              let transenv = transTycon transenv lid tparams knd bl in
                transenv, [], [], None
      | Sig_datacon_typ (lid, tparams, ty, atag, aq, parentOpt, _, _) ->  (* TODO: this ignores the eref *)
          let _ = DebugLog.Log(Printf.sprintf "\n sigelt: dcon %s" (Pretty.str_of_lident lid)) in
            if Const.is_tuple_data_lid lid then 
              transenv, [], [], None
            else 
              let tagOpt = match parentOpt with 
                | Some tlid -> 
                    let t = getTagNumForDcon tlid lid in
                    (* let _ = pr "Setting tag number for %s to %d" (Pretty.sli lid) t in *)
                      Some t
                | None -> 
                    if (atag <> None)
                    then Some (getTagNumForDcon (lid_of_path ["Prims";"pf"] dummyRange) lid)
                    else None in
              let transenv = transDcon transenv aq lid tparams ty (atag <> None) tagOpt in
              transenv, [], [], None
      | Sig_extern_value (lang, lid, t) -> 
          let _ = DebugLog.Log(Printf.sprintf "\n sigelt: exn value %s" (Pretty.str_of_lident lid)) in
          let transenv, sf, ext = generateExternWrapper transenv lang lid.lid t in
            transenv, sf, [], Some ext
              (* Just skip the operator decls in prims for now *)
      | Sig_value_decl(lid, t) -> 
          if (Sugar.lid_equals lid Const.op_Eq)
          then let transenv, sf = generateEqualityOp transenv t in transenv, sf, [], None
          else if (Sugar.lid_equals lid Const.op_And_lid or
                     Sugar.lid_equals lid Const.op_Or_lid)
          then let transenv, sf = generateAndOrOp transenv t lid in transenv, sf, [], None
          else if (Sugar.lid_equals lid Const.op_Not_lid)
          then let transenv, sf = generateNotOp transenv t in transenv, sf, [], None
          else if (Sugar.lid_equals lid Const.op_Add_lid or
                     Sugar.lid_equals lid Const.op_Subtraction_lid or
                     Sugar.lid_equals lid Const.op_Multiply_lid or
                     Sugar.lid_equals lid Const.op_GreaterThanOrEqual_lid)
          then transenv, [], [], None
          else let (newt, transenv) = transType transenv t in
          let lid' = (match lid.lid with 
                          [l] -> lid
                        | modname::lid -> asLid lid) in 
          let sf = [(text_of_lid lid', newt, None)] in
             transenv, sf, [], None
      | Sig_extern_typ(eref, Sig_typ_abbrev(lid, tps, _, typ)) -> 
          let _ = DebugLog.Log(Printf.sprintf "\n exn typ: tcon %s" (Pretty.str_of_lident lid)) in
            (if List.length tps <> 0 then 
               let errmsg = spr "transSigelt: unexpected parameterized type abbrev: %s" (Pretty.strSigelt sige) in
                 raise (TransErr errmsg));
            (match typ.v with 
               | Typ_record(fn_t_l, _) -> 
                   let fn_t_l = List.sortWith (fun (fname1, _) (fname2, _) -> compare_lid fname1 fname2) fn_t_l in
                   let fieldDecls = List.map 
                     (fun ((fn:lident), t) -> 
                        let tt, transenv = transType transenv t in
                        let fn = List.hd fn.lid in
                          (fn.idText, tt)) fn_t_l in
                   let cname = Sugar.path_of_lid eref.classname in
                   let record_decl = 
                     {externref=Some eref;
                      visibility=TVis_public;
                      attr = NoAttr;
                      name=cname;
                      namestring = String.concat "." cname;
                      kvars = [];
                      vars=[];
                      evidences = [];
                      extends=None;
                      fields=fieldDecls;
                      staticFields=[];
                      methods=[];
                      kind=None;
                      hasTag=false;
                      tagNum=None} in
                     transenv, [], [record_decl], None
               | _ -> raise (NYI "[Translation] External references to non-record types"))


      | Sig_extern_typ(eref, Sig_tycon_kind(lid, tparams, knd, bl, _, _)) when List.length tparams = 0 ->
                     (*let _ = DebugLog.Log(Printf.sprintf "\n sigelt: exn tcon %s" (Pretty.str_of_lident lid)) in 
                     let _ = Printf.printf "\n sigelt: exn tcon %s" (Pretty.str_of_lident lid) in *)
          let cname = Sugar.path_of_lid (*eref.classname*) lid in
          let rec newTyVar k = (match k(* .u *) with
                             | Kind_boxed k' -> newTyVar k'
                             | Kind_star -> newTvar TKind_star
                             | Kind_prop -> newTvar TKind_prop
                             | Kind_erasable -> newTvar TKind_erasable
                             | Kind_affine -> newTvar TKind_affine
                             | _ -> raise (TransErr (Printf.sprintf "unexpected kind %s" (Pretty.strKind knd)))) in
          let rec getTvars k = (match k(* .u *) with 
                         | Kind_tcon(_, k1, k2) -> (Tvar(newTyVar k1)) :: (getTvars k2)
                         | _ -> []) in
          let tcDecl = {externref=Some eref;
                        visibility=TVis_public;
                        attr = NoAttr;
                        name=cname;
                        namestring = String.concat "." cname;
                        kvars = [];
                        vars=getTvars knd;
                        evidences = [];
                        extends=None;
                        fields=[];
                        staticFields=[];
                        methods=[];
                        kind=None;
                        hasTag=false;
                        tagNum=None} in
            transenv, [], [tcDecl], None
              
      | Sig_extern_typ(eref, Sig_datacon_typ(constructorName, tparams, ty, bl, aq, Some tcn, _, _)) when List.length tparams=0 ->       
          (*           let _ = DebugLog.Log(Printf.sprintf "\n sigelt: exn dcon %s" (Pretty.str_of_lident lid)) in  *)
          (*             (match Sugar.lid_to_eref tcn, Sugar.lid_to_eref lid with *)
          (*                | Some(dll, variantClassName), Some(dll', constructorName) when dll=dll' ->
          *)
          let extends = TType_name((Sugar.path_of_lid tcn, TKind_star), Some eref) in
          let cname = Sugar.path_of_lid constructorName in 
          let rec mk_vvars (ix, out) t = match t.v with
            | Typ_univ _ -> raise (NYI "External polymorphic constructors")
            | Typ_fun(_, targ, t) -> 
                let tt, transenv = transType transenv targ in
                let vvar = (spr "_%s%d" (Sugar.text_of_path cname) ix, tt) in
                  mk_vvars (ix+1, vvar::out) t
            | _ -> List.rev out in
          let vvars = mk_vvars (1, []) ty in
          let constrDecl = {externref=Some eref;
                            visibility=TVis_public;
                            attr = NoAttr;
                            name=cname;
                            namestring = String.concat "." cname;
                            kvars = [];
                            vars= List.map Vvar (dedupVars vvars);
                            evidences = [];
                            extends=Some extends;
                            fields=[];
                            staticFields=[];
                            methods=[];
                            kind=None;
                            hasTag=false;
                            tagNum=None} in
             transenv, [] , [constrDecl], None

      | Sig_extern_typ(_, Sig_record_typ(lid, tps, _, t,_)) (* TODO: handle this case specially *)
      | Sig_record_typ(lid, tps, _, t,_) -> 
          (match t.v with
             | Typ_record(fn_t_l, _) ->
                 let fn_t_l = List.sortWith (fun (fname1, _) (fname2, _) -> compare_lid fname1 fname2) fn_t_l in
                 let transenv, vars_tps, tys_tp = transTParams transenv tps in
                 let (fnames, ftypes) = List.split fn_t_l in
                 let newfnames = List.map (fun fname -> String.concat "_" (path_of_lid fname)) fnames in
                 let transenv, newftypes = transFieldTypes [] transenv ftypes in
                 let newfields = List.combine newfnames newftypes in
                 let recCdecl: tClassDecl =
                   {externref = None;
                    visibility = TVis_public;
                    attr = NoAttr;
                    name = path_of_lid lid;
                    namestring = String.concat "." (path_of_lid lid);
                    kvars = [];
                    vars = vars_tps;
                    evidences = [];
                    extends = None;
                    fields = newfields;
                    staticFields = [];
                    methods = [];
                    kind = Some TKind_star;
                    hasTag=false;
                    tagNum=None
                   } in 
                 let newclass = addEqualityMethod recCdecl in
                 let transenv, newclass = addToStringMethod transenv newclass ftypes in 
                   (addToTransEnv transenv newclass, [], [], None)
             | _ -> raise (TransErr (Printf.sprintf "unexpected record type: %s" (Pretty.strSigelt sige))))

      | Sig_extern_typ(eref, Sig_tycon_kind(lid, tps, k, _, _,  _)) -> 
          let transenv, vars_tps, _ = transTParams transenv tps in
          let k, transenv = transKind transenv k in
            if (k <> TKind_star && k <> TKind_affine) then 
              raise (TransErr (Printf.sprintf "unexpected extern type with non-star kind or with value parameters: %s" (Pretty.strSigelt sige)));
            let cdecl = 
              {externref = Some eref;
               visibility = TVis_public;
               attr = NoAttr;
               name = path_of_lid lid;
               namestring = String.concat "." (path_of_lid lid);
               kvars = [];
               vars = vars_tps;
               evidences = [];
               extends = None;
               fields = [];
               staticFields = [];
               methods = [];
               kind = Some k;
               hasTag=false;
               tagNum=None} in
              (transenv, [], [cdecl], None)
      | Sig_ghost_assume(lid, formula, aq) ->
        let transenv = transDcon transenv aq lid [] formula true None in (* TODO: add a flag to tell the difference between normal assumptions from ghost ones *)
        transenv, [], [], None 
      | Sig_logic_function _ -> transenv, [], [], None
      | se -> 
          pr "Unhandled sigelt: %A\n" se;
          raise (NYI "[Translation] Unhandled sig elt")
            
(* translation of signature  *)
(* type signature = list<sigelt> *)
let transSignature transenv (sg: signature) : transEnv * tStaticFieldDecl list * tClassDecl list * tExternMethodDecl list =
  let rec transsigs trenv sigs fields externs extMethods =
    match sigs with
      | [] -> (trenv, fields, externs, extMethods)
      | sigelt :: rest ->
          let (trenv, flds, exts, emethodOpt) = transSigelt trenv sigelt in
          let extMethods = match emethodOpt with Some e -> e::extMethods | _ -> extMethods in
            transsigs trenv rest (fields@flds) (externs@exts) extMethods in
    transsigs transenv sg [] [] []

// Get the external type declarations from an absyn module.
// This is used to pass prefix to transModule
let getExterns (m:modul) : sigelt list = 
  List.filter (function 
                 | Sig_extern_typ _ -> true
                 | _ -> false) m.signature

(* translation of modules *)
(*  type modul = {
    name: lident;
    pos: Range.range;
    signature: signature;
    letbindings: list<letbinding * bool>; (* the boolean signals a let rec *)
    main:option<exp>;
    exports: signature;
    }
*) 
let transModule tcenv (externs:list<sigelt>)  (m: modul): tModule =
  (*if (Pretty.str_of_lident m.name <> "ProofLib") then Pretty.printModule m;*)
  curmodname := Some m.name;
  let newName = path_of_lid m.name in
  let scope, name = Util.pfx newName in
  //let _ = pr "\n translating module %s" name in
  let name = name ^ "_Container" in
  let containerClass = newName in(* scope@[name] in *)
  let transenv, sfields_signature, externs_signature, ext_methods = transSignature (createTransEnv tcenv) (externs@m.signature) in
  let rec transLetbindings cnt transenv letbds sfs =
    match letbds with
      | [] -> (transenv, sfs) 
      | (letbd, isrec) :: rest ->
          let _ = if name.Contains("Typing") && (cnt mod 8 = 0) then System.GC.Collect() in
          let (transenv, newsfs) = transLetbinding transenv letbd isrec in
            transLetbindings (cnt+1) transenv rest (sfs @ newsfs) in
  let (transenv, sfields) = transLetbindings 0 transenv m.letbindings [] in
  let sfields_signature = List.filter 
    (fun (name, t, _) -> not (List.exists (fun (name', _, _) -> name=name') sfields)) sfields_signature in
  let sfields = sfields_signature@sfields in 
    (*   let _ = List.iter (fun (name, tt, _) -> print_string ("Translation added static field " ^name^": "^(PrettyTarget.strType tt)^"\n")) sfields in *)
  let moduleClassDecl: tClassDecl = 
    (* the class corresponding to the module *)
    { externref=None;
      visibility = TVis_public;
      attr = NoAttr;
      name = containerClass;
      namestring = String.concat "." newName;
      kvars = [];
      vars = [];
      evidences = [];
      extends = None;
      fields = [];
      staticFields = List.map wrapStaticField sfields;
      methods = [];
      kind = Some TKind_star;
      hasTag=false;
      tagNum=None
    } in
    (* the target checker regards the static fields as globally visible *)
  let extendsName = match m.extends with
    | None -> None
    | Some lid -> Some (path_of_lid lid) in
  let basicExterns = [genericEqualityMethodDecl; booleanAndMethodDecl; booleanOrMethodDecl] in
  let result = match m.main with
      None -> 
        { name = newName;
          extends = extendsName;
          modCdecl = moduleClassDecl;
          decls = getDecls transenv;
          externs = createTCdecls(externs_signature);
          entry = None;
          externMethods = basicExterns@ext_methods;
        }
    | Some e -> 
        let tMain, transenv = transExp transenv e in
          { 
            name = newName;
            extends = extendsName;
            modCdecl = moduleClassDecl;
            decls = getDecls transenv;
            externs = createTCdecls(externs_signature);
            entry = Some (wrapExp tMain);
            externMethods = basicExterns@ext_methods;
          } in
    curmodname := None; 
    (*PrettyTarget.printModule result;*)
    result

