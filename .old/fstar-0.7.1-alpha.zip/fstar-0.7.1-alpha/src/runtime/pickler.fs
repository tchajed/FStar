(*
  To compile, run
  fsc -r FSharp.Compiler/FSharp.Compiler.dll -r main.dll -o out/runtime.dll -a runtime.fs 
*)
module Microsoft.FStar.Runtime.Pickler

open Microsoft.FStar
open Microsoft.FStar.PrettyTarget

open Microsoft.FStar.Runtime
open Microsoft.FStar.Runtime.Utils
open Microsoft.FStar.Runtime.DcilGen
open Microsoft.FStar.DcilAttrs
open Microsoft.FStar.Target
open Microsoft.FStar.TargetUtil

open Microsoft.FSharp.Compiler.AbstractIL
open Microsoft.FSharp.Compiler.AbstractIL.BinaryReader
open Microsoft.FSharp.Compiler.AbstractIL.BinaryWriter
open Microsoft.FSharp.Compiler.AbstractIL.IL
open System.Security.Cryptography

open Sugar
open System
open System.IO
open System.Reflection
open System.Net
open System.Net.Sockets

type Ref<'a> = 
  | MkRef of ref<'a>
let newref v = (MkRef (ref v))
let read (MkRef x) = !x
let write (MkRef x) v = ((x:=v); false)

type StreamReader = 
  | MkReader of System.IO.StreamReader
let StreamReaderCtor (fileName:string) = 
  MkReader(new System.IO.StreamReader(fileName))
let StreamReaderReadLine (stream: StreamReader) = 
  match stream with
    | MkReader strm -> strm.ReadLine()

let __ctr = ref 0 in 
let freshname (x:bool) : string = 
  let i = !__ctr in
  let _ = incr __ctr in
    spr "gs_%d" i

let throw (s:string) : 'a = 
  pr "%s\n" s; 
  flush stdout;
  failwith s
          
let inWfi = ref false

let startsWith (s:string) (s':string) = s.StartsWith s'
 
let rec string_of_any (x:'a) : string = (box x).ToString()

let set_icomp, test_icomp = 
  let icomp = ref None in
  (fun i -> icomp := Some i), 
  (fun j -> 
     match !icomp with 
       | Some i -> LanguagePrimitives.PhysicalEquality i j
       | _ -> false)

let set_gamma, test_gamma = 
  let gamma = ref None in
  (fun i -> gamma := Some i), 
  (fun j -> 
     match !gamma with 
       | Some i -> LanguagePrimitives.PhysicalEquality i j
       | _ -> false)

      
(* let togglePrintIndTypeDefs, *)
(*     printIndTypeDefs = *)
(*   let flag = ref false in  *)
(*     (fun () -> flag := not (!flag)),  *)
(*     (fun () -> !flag) *)

let boxToObject<'a> (x:'a): System.Object = box x

type WrappedObject(o:System.Object) =
  class
    member x.obj = o
    override x.GetHashCode() = x.obj.GetHashCode()
    override x.Equals(o':System.Object) = 
      match o' with | :? WrappedObject as wo' -> LanguagePrimitives.PhysicalEquality x.obj wo'.obj | _ -> false
  end

let map:HashMultiMap<WrappedObject, string> = Hashtbl.create 1000
let addBindings (b:System.Object) (name:string) = Hashtbl.add map (new WrappedObject(b)) name; true
let lookupBindings (b:System.Object) = Hashtbl.tryfind map (new WrappedObject(b))
let clearBindings (x:bool) = Hashtbl.clear map; true

let rec printIndType (x:System.Object) = 
#if CERTIFY
  let ind = x:?> Env.MkIndType in
  let constrs = ind.field_2 in 
  if (constrs.GetType().FullName.StartsWith("Prims+Nil`1")) then
   "(mkIndType " + (string_of_any_for_coq<System.Object> ind.field_1) + " [::])"
  else PrettyPrintCoretyping.indName (ind.field_1)
#else 
    "Printing of F* types not available in this build"
#endif 

(* pretty print a value for coq formalization. There are special handling for strings and lists. *)
(* Strings are inside quotes and Prims.list objects are printed as [x1; ...; xn] *)
and string_of_any_for_coq<'a> (y:'a) : string =
  let rec strList l = (* pretty print a list, without the outside brackets *)
    let ty = l.GetType() in
    let tyName = ty.FullName in
    (*let _ = Printf.printf "\n %s" tyName in*)
    if tyName.StartsWith("Prims+Nil`1") then ""
    else if tyName.StartsWith("Prims+Cons`1") then
      (let finfo1, finfo2 = ty.GetField("field_1") , ty.GetField("field_2") in
        let hd, tl = finfo1.GetValue(l), finfo2.GetValue(l) in
        if tl.GetType().FullName.StartsWith("Prims+Nil`1")
        then string_of_any_for_coq<System.Object> hd
        else (string_of_any_for_coq<System.Object> hd) + "; " + (strList tl))
      else raise Util.Impos in 
  let strVar v =
    let ty = v.GetType() in
    let f1 = ty.GetField("field_1").GetValue(v) in (* gvar *)
    let name = f1.GetType().GetField("field_1").GetValue(f1) in (* string *)
    let string_name = string_of_any_for_coq<System.Object> name in
    let tyName, fName = ty.FullName, f1.GetType().FullName in
    if tyName.StartsWith("Terms+T_Var") then
      begin
        if fName.StartsWith("Terms+GV_Bound") then "TVB " + string_name
        else "TVF " + string_name
      end
    else if fName.StartsWith("Terms+GV_Bound") then "VB " + string_name
    else "VF " + string_name in
  let strTuple v = 
    let ty = v.GetType() in
    let f1 = ty.GetField("fst").GetValue(v) in 
    let f2 = ty.GetField("snd").GetValue(v) in 
      spr "(%s, %s)" 
        (string_of_any_for_coq<System.Object> f1)
        (string_of_any_for_coq<System.Object> f2) in
  let strBaseKind v =
    let f1 = v.GetType().GetField("field_1").GetValue(v) in
    let name = f1.GetType().FullName in
    if (name.StartsWith("Terms+BK_Comp")) then "BKC"
    else if (name.StartsWith("Terms+BK_Prop")) then "BKP"
    else if (name.StartsWith("Terms+BK_Erase")) then "BKE"
    else "BKA" in
  let x = box y in 
  let tyName = x.GetType().FullName in
    if tyName = "System.String" then (* add "" around string *)
      Util.spr "\"%s\"" ((box x).ToString())
    else if (tyName.StartsWith("Env+LB_BvarTy") || tyName.StartsWith("Env+LB_BvarKind")) then (* bindings for bvars are lifted *) 
      (*string_of_any (x.GetType().GetField("field_1").GetValue(x))*) 
      match lookupBindings x with
        | Some name -> (*Util.pr "\n found %s" name;*) name
        | _ -> (*Util.pr "\nCannot find %s:%s" 
                 (string_of_any (x.GetType().GetField("field_1").GetValue(x)))
                 (string_of_any (x.GetType().GetField("field_2").GetValue(x)));
               raise Util.Impos*)
               string_of_any y
    else if (tyName.StartsWith("Env+MkIndType")) then printIndType x
    else if (tyName.StartsWith("Terms+K_Base")) then strBaseKind x
    else if (tyName.StartsWith("Prims+Cons`1[[Env+inductive") && test_icomp x) then "icomp"
    else if (tyName.StartsWith("Prims+Cons`1[[Env+fvbinding") && test_gamma x) then "gamma"
    else if tyName.StartsWith("Prims+Nil`1") || tyName.StartsWith("Prims+Cons`1") then (* lists *)
      Util.spr "[:: %s]" (strList x)  
    else if tyName.StartsWith("Terms+T_Var") || tyName.StartsWith("Terms+V_Var") then
      Util.spr "(%s)" (strVar x)
    else if tyName.StartsWith("Prims+DconDepTuple`2") then strTuple x
    else if tyName.StartsWith("Typing+WF_Weak") || tyName.StartsWith("Typing+WF_Nil") then ""
    (*else if tyName.StartsWith("Typing+WFE") || tyName.StartsWith("Typing+WFV") then  ""*)
    else string_of_any y
      
let string_of_any_for_coq_afn<'a> (y:'a) : string = string_of_any_for_coq y
let string_of_any_for_coq_p<'a> (y:'a) : string = string_of_any_for_coq y

let print_int (i:int) : bool = 
  Util.pr "%d" i; true

let print_string (s:string) : bool = 
  Util.pr "%s" s; true
  
let println (s:string) : bool = 
  Util.pr "%s\n" s; true

let debug_println (s:string) : bool = 
  if !Options.debug_certify then println s
  else true

let print_stderr (s:string) : bool = 
  Util.fpr stderr "%s\n" s; true

let fh_cache : (ref<list<(string * System.IO.FileStream * System.IO.StreamWriter)>>) = ref [] 
let findStream fn = 
  match List.tryFind (fun (fn', _, _) -> fn=fn') !fh_cache with 
    | Some (_, fs, _) -> fs
    | _ -> raise Not_found

let flushFiles () = 
  let _ = !fh_cache |>  
      List.iter (fun (fn, _, fh) -> 
                   (* Util.pr "Flushing file %s\n" fn; *)
                   fh.Flush(); fh.Close()) in 
    fh_cache := []
  
let print_aux (hasLn: bool) (fn:string) (str:string): bool = 
  let fh = match List.tryFind (fun (fn', _, _) -> fn=fn') !fh_cache with 
    | None -> 
        let f = System.IO.File.Create(fn) in 
        let fh = System.IO.StreamWriter(f) in 
          fh_cache := (fn,f,fh)::!fh_cache;
          fh
    | Some (_,_,fh) -> fh in
  let _ = if hasLn then Util.fpr fh "%s\n" str else Util.fpr fh "%s " str in 
    fh.Flush(); 
    true  
      
let printfile (fn:string) (str:string): bool = print_aux true fn str
let printfileNoLn (fn:string) (str:string) : bool =  print_aux false fn str

let getFields (ty: System.Type) = Array.toList (ty.GetFields(System.Reflection.BindingFlags.DeclaredOnly |||
                                          BindingFlags.Public ||| BindingFlags.Instance))

(* write definitions of subobj to file named fname, return the name of the whole object *)
let rec writeToFile<'a> (fname:string) (y:'a) : string =
  let isNil obj = (* test if all field of obj are Nil *)
  let objTy = obj.GetType() in
  let fields = getFields(objTy) in
  List.forall (fun (field: System.Reflection.FieldInfo) -> 
                  let fname = field.GetValue(obj).GetType().FullName in
                  fname.StartsWith("Prims+Nil`1") or (not (fname.StartsWith("Prims+Cons`1")))) fields in
  let rec isNilList obj = (* test if obj is a nil or a list consisting of nil *)
  let objTy = obj.GetType() in
  if (objTy.FullName.StartsWith("Prims+Nil`1")) then true
  else 
      let finfo1, finfo2 = objTy.GetField("field_1") , objTy.GetField("field_2") in
      let hd, tl = finfo1.GetValue(obj), finfo2.GetValue(obj) in
      hd.GetType().FullName.StartsWith("Prims+Nil`1") && isNilList tl in
  let x = box y in
  let printDefinition name opaque def =
   let kw = if opaque then "DLemma" else "Definition" in
   let _ = if name.Equals("gs_72786") then Util.pr "\nprintfile %s %s = %s" fname name def in
     printfile fname (kw ^ " " ^ name ^ " := " ^ def ^ ".") in
  let ty = x.GetType() in
  let tyName = ty.FullName in
  if (tyName = "System.String") then "\"" ^ (x.ToString()) ^ "\""
  else if (tyName.StartsWith("System")) then x.ToString()
  else if (tyName.StartsWith("Terms+T_Var") || tyName.StartsWith("Terms+V_Var")) then
    let gvar = ty.GetField("field_1").GetValue(x) in
    let gvar_ty = gvar.GetType() in
    let varName = gvar_ty.GetField("field_1").GetValue(gvar) in
    let str_name = Util.spr "\"%s\"" (string_of_any varName) in
    if tyName.StartsWith("Terms+T_Var") then
      begin
        if gvar_ty.FullName.StartsWith("Terms+GV_Bound") then "(TVB " + str_name + ")"
        else "(TVF " + str_name + ")"
      end
    else if gvar_ty.FullName.StartsWith("Terms+GV_Bound") then "(VB " + str_name + ")"
    else "(VF " + str_name + ")"
  else if (tyName.StartsWith("Env+MkIndType")) then printIndType x
  else if (tyName.StartsWith("Terms+T_Ind")) then
    (string_of_any (ty.GetField("field_1").GetValue(x))) + "I"
  else if (tyName.StartsWith("Terms+BK_Comp")) then "BK_Comp"
  else if (tyName.StartsWith("Terms+BK_Prop")) then "BK_Prop"
  else if (tyName.StartsWith("Terms+BK_Erase")) then "BK_Erase"
  else if (tyName.StartsWith("Terms+BK_Afn")) then "BK_Afn"
  else if (tyName.StartsWith("Terms+K_Base")) then
    (let fname = ty.GetField("field_1").GetValue(x).GetType().FullName in
    if (fname.StartsWith("Terms+BK_Comp")) then "BKC"
    else if (fname.StartsWith("Terms+BK_Prop")) then "BKP"
    else if (fname.StartsWith("Terms+BK_Erase")) then "BKE"
    else "BKA")
  else if (tyName.StartsWith("Typing+Term_level")) then "Term_level"
  else if (tyName.StartsWith("Typing+Type_level")) then "Type_level"
  else if (tyName.StartsWith("Typing+CK_Star")) then "CK_Star"
  else if (tyName.StartsWith("Typing+CK_Afn")) then "CK_Aff"
  else if (tyName.StartsWith("Typing+CK_Prop")) then "CK_Prop"
  else if (tyName.StartsWith("Typing+KC_AffErs")) then "KC_AffErs"
  else if (tyName.StartsWith("Typing+KC_AffAff")) then "KC_AffAff"
  else if (tyName.StartsWith("Typing+VKC_AffErs")) then "VKC_AffErs"
(*   else if (tyName.StartsWith("Typing+WF_Weak")) then "<omitted>" *)
(*   else if (tyName.StartsWith("Typing+WF_Nil")) then "<omitted>" *)
(*   else if (tyName.StartsWith("FiniteSet+Append_")) then "<omitted>" *)
(*   else if (tyName.StartsWith("FiniteSet+Flatten_")) then "<omitted>" *)
(*   else if (tyName.StartsWith("Typing+WFIG_")) then "<omitted>" *)
(*   else if (tyName.StartsWith("Env+BB_")) then "<omitted>" *)
  else if (tyName.StartsWith("FreeNames+TypeNameT")) then "TypeNameT"
  else if (tyName.StartsWith("Prims+Cons`1[[Env+inductive") && test_icomp x) then "icomp"
  else if (tyName.StartsWith("Prims+Cons`1[[Env+fvbinding") && test_gamma x) then "gamma"
(*   else if (tyName.StartsWith("Typing+WFI_") && not(!inWfi)) then "wfi" *)
  else if (tyName.StartsWith("Typing+WFIG_") && not(!inWfi)) then "wfig"
  else if (tyName.StartsWith("Prims+Nil`1")) then "[::]"
  else if (tyName.StartsWith("FiniteSet+Distinct_nil")) then "Distinct_nil"
  else if (tyName.StartsWith("FiniteSet+NotMem_tl")) 
  then 
    let finfo1::finfo2::finfo3::_ = getFields(ty) in
    let x, y, tl = finfo1.GetValue(x), finfo2.GetValue(x) , finfo3.GetValue(x) in
      Util.spr "(Dec.notmemP %s (%s::%s) (refl_equal true))" 
        (writeToFile fname x) 
        (writeToFile fname y) 
        (writeToFile fname tl) 
  else if (tyName.StartsWith("FiniteSet+Mem_tl")) 
  then
    let finfo1::finfo2::finfo3::_ = getFields(ty) in
    let x, y, tl = finfo1.GetValue(x), finfo2.GetValue(x) , finfo3.GetValue(x) in
      Util.spr "(Dec.memP %s (%s::%s) (refl_equal true))" 
        (writeToFile fname x) 
        (writeToFile fname y) 
        (writeToFile fname tl) 
  else if (tyName.StartsWith("FiniteSet+Disjoint_cons")) 
  then
    let finfo1::finfo2::finfo3::_ = getFields(ty) in
    let x, xs, ys = finfo1.GetValue(x), finfo2.GetValue(x) , finfo3.GetValue(x) in
      Util.spr "(Dec.disjointP (%s::%s) %s (refl_equal true))" 
        (writeToFile fname x) 
        (writeToFile fname xs) 
        (writeToFile fname ys) 
  else if (tyName.StartsWith("FiniteSet+Distinct_cons")) 
  then
    let finfo1::finfo2::_ = getFields(ty) in
    let hd, tl = finfo1.GetValue(x), finfo2.GetValue(x) in
      Util.spr "(Dec.distinctP (%s::%s) (refl_equal true))" 
        (writeToFile fname hd) 
        (writeToFile fname tl) 
  else if (tyName.StartsWith("FiniteSet+Append_Cons")) 
  then
    let finfo1::finfo2::finfo3::finfo4::_ = getFields(ty) in
    let x, tl, l2, tl_l2 = 
      finfo1.GetValue(x), finfo2.GetValue(x), 
      finfo3.GetValue(x), finfo4.GetValue(x) in
      //Util.spr "(Dec.appendP (%s::%s) %s (%s::%s))"
      Util.spr "(Dec.appendP (%s::%s) %s)"
        (writeToFile fname x) 
        (writeToFile fname tl) 
        (writeToFile fname l2) 
        //(writeToFile fname x) 
        //(writeToFile fname tl_l2) 
  else if (tyName.StartsWith("FiniteSet+Flatten_Cons")) 
  then
    let finfo1::finfo2::finfo3::finfo4::_ = getFields(ty) in
    let hds, tls, tl, hds_tl =
      finfo1.GetValue(x), finfo2.GetValue(x), 
      finfo3.GetValue(x), finfo4.GetValue(x) in
      Util.spr "(Dec.flattenP (%s::%s) )"
        (writeToFile fname hds) 
        (writeToFile fname tls) 
        //(writeToFile fname hds_tl) 
//      Util.spr "(Dec.flattenP (%s::%s) %s)"
  else if (tyName.StartsWith("Prims+Cons`1")) && (isNilList x) then string_of_any_for_coq<System.Object> x
  else match lookupBindings x with
    | Some name -> name
    | None -> 
        let name = freshname true in
        let _ = addBindings x name in
        let debug = name.Equals("gs_72786") in
        let _ = if debug then Util.pr "\n binding %s --- %s" name (x.ToString()) in
        if (tyName.StartsWith("Prims+Cons`1")) then
          let finfo1, finfo2 = ty.GetField("field_1") , ty.GetField("field_2") in
          let hd, tl = finfo1.GetValue(x), finfo2.GetValue(x) in
          let name_hd = writeToFile fname hd in
          let name_tl = writeToFile fname tl in
          let _ = printDefinition name false (name_hd ^ " :: " ^ name_tl) in
            name
        else if (tyName.StartsWith("Prims+DconDepTuple`2"))
          then
            let f1 = ty.GetField("y_0_22").GetValue(x) in 
            let f2 = ty.GetField("y_0_23").GetValue(x) in 
              printDefinition name false (spr "(%s, %s)" (writeToFile fname f1) (writeToFile fname f2)); name
          else 
            let getConstrName (tyName:string) = 
              let ctrName = 
                let startIndexOfConstr = tyName.IndexOf("+") in
                let endIndexOfConstr = tyName.IndexOf("`") in
                  if startIndexOfConstr = -1 then tyName 
                  else if endIndexOfConstr = -1 then tyName.Substring(startIndexOfConstr+1)
                  else tyName.Substring(startIndexOfConstr+1, endIndexOfConstr - startIndexOfConstr-1) in
                if ctrName = "System.String" then "String_eqType" else ctrName in
            let def = getConstrName tyName in
            let constrName = def in
            let _ = if debug then Util.pr "\n starting %s" constrName in
            let fields = getFields(ty) in
            let doField (fi: FieldInfo) = 
              let field = fi.GetValue(x) in
              let fieldName = field.GetType().FullName in
                (*let _ = Util.pr "\n    field %s" fieldName in*)
             
              if (not(!Options.hashcons_poly) &&
                      (fieldName.StartsWith("Util+Zip") ||
                       //fieldName.StartsWith("Util+Refl_eq") ||
                       //fieldName.StartsWith("FiniteSet+Mem") ||
                       //fieldName.StartsWith("FiniteSet+NotMem_nil") ||
                       fieldName.StartsWith("FiniteSet+Disjoint_nil") && isNil field ||
                       fieldName.StartsWith("FiniteSet+Part_Admit") && isNil field ||
                       fieldName.StartsWith("FiniteSet+Perm_Refl") && isNil field ||
                       fieldName.StartsWith("FiniteSet+Perm_Sym") && isNil field ||
                       fieldName.StartsWith("FiniteSet+Append_Nil") && isNil field)) then
                  //let _ = Util.pr "\n GOT %s" fieldName in
                    (string_of_any_for_coq<System.Object> field)
                else writeToFile fname field in
            let def = List.fold (fun def (fi:FieldInfo) -> def ^ " " ^ (doField fi)) def fields in
            let _ = if debug then Util.pr "\n  def = %s" def in
            let opaque =
              List.exists (fun x -> tyName.StartsWith(x))
                [ "Util+Zip_Nil"; "Util+Zip_Cons";
                  "FiniteSet+Mem_hd"; "FiniteSet+Mem_tl";
                  "FiniteSet+NotMem_nil"; "FiniteSet+NotMem_tl"; 
                  "FiniteSet+Disjoint_nil"; "FiniteSet+Disjoint_cons"; 
                  "FiniteSet+Distinct_nil"; "FiniteSet+Distinct_cons"; 
                  "FiniteSet+Append_Nil"; "FiniteSet+Append_Cons"; 
                  "FiniteSet+Flatten_Nil"; "FiniteSet+Flatten_Cons"; 
                  "FiniteSet+Part_Admit";
                  "FiniteSet+Perm_Refl"; "FiniteSet+Perm_Sym";
                  "FiniteSet+Perm_Trans"; "FiniteSet+Perm_Cons";
                  "Terms+CurryT_nil"; "Terms+CurryT_cons";
                  "Terms+CurryV_nil"; "Terms+CurryV_cons";
                  "Env+ICompBinds_ind"; "Env+ICompBinds_dcon"; 
                  "Env+VLN_Nil"; "Env+VLN_ConsV"; "Env+VLN_ConsT";
                  "Env+TYN_Nil"; "Env+TYN_ConsV"; "Env+TYN_ConsT";
                  "Env+BB_Nil"; "Env+BB_BVT"; "Env+BB_BTK"; "Env+BB_VlEq"; "Env+BB_TyEq";
                  "FreeNames+FBK"; "FreeNames+FBT"; "FreeNames+FBV"; "FreeNames+FBE";
                  "Binders+BNDK"; "Binders+BNDT"; "Binders+BNDV"; "Binders+BNDE";
                  "Subst+SubstK"; "Subst+SubstT"; "Subst+SubstV"; "Subst+SubstE"; 
                  "Typing+ConcreteKind"; "Typing+KC_"; "Typing+AC_"; "Typing+BT_";
                  "Typing+DI_Names"; "Typing+DC_Names"; "Typing+VKC_";
                  "Typing+KCE_"; "Typing+AL2M_"; "Typing+TE_"; "Typing+KE_";
                  "Typing+VE_"; "Typing+EE_"; "Typing+PE_"; "Typing+SK_";
                  "Typing+ST_"; "Typing+AQual_"; "Typing+StripQual_";
                  "Typing+Bindings_"; "Typing+PTM_"; 
                  "Typing+WFK_"; "Typing+WFT_"; "Typing+WFV_"; "Typing+WFE_";
                  "Typing+WFI_"; "Typing+WFIK_"; "Typing+WFC_"; "Typing+CA_";
                  "Typing+WFIG_"; "Typing+WF_Nil"; "Typing+WF_Weak";]
            in
            let _ = printDefinition name opaque def in
            let _ = if debug then Util.pr "\n writing %s = %s, finishing %s" name def constrName in
              name (* dummy return value for unit *)
     
let writeCertToFile f cert =
  if !Options.print_certs then writeToFile f cert 
  else "_dummy"

let writeWFI wfiName fstream wfig = 
  if !Options.print_certs then
    (inWfi := true; 
     fh_cache := (wfiName, fstream, System.IO.StreamWriter(fstream))::!fh_cache;
     let name = writeToFile wfiName wfig in 
       printfile wfiName (spr "DLemma wfig := %s.\n" name);
       inWfi := false)
  else ()

(*     let ty = wfis.GetType() in *)
(*     let fields = ty.GetFields(System.Reflection.BindingFlags.DeclaredOnly ||| *)
(*                               BindingFlags.Public ||| BindingFlags.Instance) in *)
(*     let wfi = (Array.get fields 0).GetValue(wfis) in *)
(*     inWfi := true;  *)
(*     writeToFile f wfi; *)
(*     inWfi := false;  *)
(*     () *)
(*   else () *)

let mkDTuple (a:'a) (b:'b) : Prims.DepTuple<'a,'b> = new Prims.DconDepTuple<'a,'b>(a,b) :> Prims.DepTuple<'a,'b>
let strcat (s1:string) (s2:string) = s1 ^ s2
let strStartsWith (s1:string) (s2:string) = s1.StartsWith(s2)
let intToString (i:int) = Convert.ToString(i)
let stringToInt (s:string) = Convert.ToInt32(s)
let strRmPfx (s:string) (pfx:string) = s.Substring (pfx.Length)
let strSplitByDelimiter (s:string) (d:string) : Prims.DepTuple<string, string> =
  let index = s.IndexOf(d) in
    if index = -1 
    then new Prims.DconDepTuple<string, string>("", s) :> Prims.DepTuple<string, string>
    else (new Prims.DconDepTuple<string, string>(s.Substring(0, index), s.Substring(index)) :> Prims.DepTuple<string, string>)

let intCheckRange (n:int) (low:int) (hi:int) = low <= n && n <= hi

type TCPListener =
  | MkListener of Sockets.TcpListener

let servers = ref ([]: Sockets.TcpListener list)
let stopAllServers (b: bool) : bool =
  let _ = List.map (fun (server: Sockets.TcpListener) -> server.Stop()) (!servers) in
  true
  
let createComm (portNum:int) : TCPListener =
  let addresses = Dns.Resolve("localhost").AddressList in
  let address = Array.get addresses 0 in
  let server = new Sockets.TcpListener(address, portNum) in
  let _ = servers:= server::(!servers) in
  let _ = server.Start() in
    MkListener server

let rec getRecv (listener: TCPListener) : byte[] =
  match listener with
    | MkListener server -> 
      let _ = Console.WriteLine("waiting for messages") in
      let client = server.AcceptTcpClient() in
      let stream = client.GetStream() in      
      let buf = Array.zeroCreate<byte> 4096 in
      let read numBytesToRead = (* block-reading until get numBytesToRead bytes *)
        let result : (byte[]) ref = ref (Array.zeroCreate<byte> 0) in
        let mutable sizeRead = 0 in 
        let _ =
          while (sizeRead < numBytesToRead) do
            if (stream.DataAvailable) then
              let nRead = //try 
                           stream.Read(buf, 0, numBytesToRead-sizeRead) in
                         //with :? System.Net.Sockets.SocketException as ex ->
                         //  let _ = Console.WriteLine(" exception: " + ex.ErrorCode.ToString()) in raise ex  in
              let _ = System.Console.WriteLine("    ---------------- got " + nRead.ToString()) in
              let _ = result := Array.append !result (Array.sub buf 0 nRead) in
              sizeRead <- sizeRead + nRead in
        !result in
      (*let totalSize = System.BitConverter.ToInt32(read 4, 0) in
      let message = read totalSize in*)
      let n = stream.Read(buf, 0, 4096) in
      let message = Array.sub buf 0 n in
      client.Close(); stream.Close();
      Console.WriteLine(" !!! Got message with: " + Array.length(message).ToString());
      message
  
let getSend (pn: int) (b: byte[]): bool = (* send to the principal with port num pn*)
  let _ = System.Console.WriteLine(" --------------- sending " + Array.length<byte>(b).ToString()) in
  let addresses = Dns.Resolve("localhost").AddressList in
  let address = Array.get addresses 0 in
  let client = new Sockets.TcpClient() in
  let _ = client.Connect(address, pn) in
  let stream = client.GetStream() in
  if stream.CanWrite
  then 
    let size = Array.length b in
    let sizeBytes = System.BitConverter.GetBytes(size) in
    (* add size of data in front of the data *)
    let _ = Console.WriteLine(" ^^^^^ sent") in
    //let _ = stream.Write(Array.append sizeBytes b, 0, Array.length sizeBytes + Array.length b) in true
    let _ = stream.Write(b, 0, Array.length b) in true
  else (System.Console.WriteLine "Cannot write to the stream"; raise Util.Impos)
    
//let keyGen b: string * string =
//  let rsa = new RSACryptoServiceProvider() in
//  rsa.ToXmlString(false), rsa.ToXmlString(true)

//NIK: I don't understand this function. It seems to split on the wrong thing. See interaction below. 
//> Pickler.processName di "FStar.baz`2";;
//  val it : Utils.depinfo * string list =
//    (map [("FStar.baz", set ["2"])], ["FStar.baz"; "2"])
let processName (curdeps : depinfo) (fullname : string)
  : depinfo * string list = 
  let longname = fullname.Split([|'+'; '`'|]) in
  let cname = if longname.Length > 1 then longname.[1] else longname.[0] in (* NIK: I don't understand this. If fullname=Baz`2, cname=2. *)
  if longname.Length > 1
    then
      let n = longname.[0] in
        if n.Equals("Microsoft.FSharp.Core.FSharpFunc")
           then (curdeps, [cname])
           else (add_depinfo curdeps n cname, [n; cname])
    else (curdeps, [cname])

let resolveKinds
  (origtys : tType list) (vars : tIdent list) (kinds : tKind list)
  : tType list =
  let rec replaceType (ty : tType) ((var, vark) : tVar<tKind>) (varty : tType) =
    match ty with
    | TType_index _ -> ty
    | TType_var (v, k) ->
      if v.Equals(var) then varty else ty
    | TType_name _ -> ty
    | TType_fun (def, t1, t2) ->
      TType_fun
        ( def
        , replaceType t1 (var, vark) varty
        , replaceType t2 (var, vark) varty )
    | TType_tfun (def, k, ty) ->
      TType_tfun
        ( def
        , replaceKind k (var, vark) varty
        , replaceType ty (var, vark) varty )
    | TType_dep (t, v) ->
      TType_dep
        ( replaceType t (var, vark) varty
        , v (* TODO *) )
    | TType_tapp (t1, t2) ->
      TType_tapp
        ( replaceType t1 (var, vark) varty
        , replaceType t2 (var, vark) varty)
    (* TODO *)
    | TType_concrete tc -> ty
    | TType_affine tc -> ty
    | TType_refine (def, ty, form,_, lst) -> ty
    | TType_inferred _ -> ty
  and replaceKind (k : tKind) ((var, vark) : tVar<tKind>) (varty : tType) =
    match k with
    | TKind_star | TKind_affine | TKind_prop | TKind_erasable -> k
    | TKind_arrow (t, k) ->
      TKind_arrow
        ( replaceType t (var, vark) varty
        , replaceKind k (var, vark) varty )
    | TKind_karrow (k1, k2) ->
      TKind_karrow
        ( replaceKind k1 (var, vark) varty
        , replaceKind k2 (var, vark) varty )
    | TKind_var _ -> k in
   List.fold
    (fun curtys (ty, kind) -> raise Undefined)
    origtys (List.zip origtys kinds)

(* Returns name space, class name, and a list of the type arguments. *)
let rec processObjType (curdeps :depinfo) (ty : Type) (kinds: tKind list)
    : depinfo * string list * tType list =
  let obj_includes, flname = processName curdeps ty.FullName in
  let included_classes, typeArgs =
    if ty.IsGenericType
      then
        (* Process generic arguments. *)
        let (genArgs : Type list) =
          List.rev
            (Array.fold (fun acc x -> x::acc) [] (ty.GetGenericArguments ())) in
        (* Get the formal kinds. *)
        (* TODO: Get the actual kinds. *)
        let argKinds =
          if genArgs.Length = List.length kinds
            then kinds
            else List.fold (fun acc _ -> TKind_star::acc) [] genArgs in 
        let includes, (args : tType list) =
          List.fold
            (fun (incacc, argacc) (arg, kind) ->
                let incacc', newty = processTypeName incacc arg kind in
                  (incacc', newty::argacc))
            (obj_includes, [])
            (List.zip genArgs argKinds) in
        let tyargs =
          let targs = List.rev args in
          match flname with
          | ["Prims"; "Tuple_UU"] | ["DepTuple2SS"] | ["DepArrowSS"] ->
            [ targs.[0]; TType_fun (None, targs.[0], targs.[1]) ]
          | _ -> targs in
          (includes, tyargs)
      else (curdeps, []) in (* NIK: should this be obj_includes? *)
        (obj_includes, flname, typeArgs) (* NIK: shouldn't we be returning included_classes? *)

(* Gets the name of an object.  Returns included classes and the name. *)
and processTypeName (curdeps : depinfo) (ty : Type) (kind : tKind)
  : depinfo * tType =
  let mkType tyname (argty, retty) =
    TType_concrete ([tyname], [], [Targ argty; Targ retty], None) in (* !! *)

  let mkTy name tykind = TType_name ((name, tykind), None) in
  
  let mkPrimInfo pname =
    (add_depinfo curdeps "Prims" pname, mkTy ["Prims"; pname] TKind_star) in
  
  (* Integer type. *)
  if ty.Equals(typeof<int>) then mkPrimInfo "int"
  elif ty.Equals(typeof<bool>) then mkPrimInfo "bool"
  (* String type *)
  elif ty.Equals(typeof<string>) then mkPrimInfo "string"
  (* unit type *)
  elif ty.Equals(typeof<Microsoft.FSharp.Core.Unit>) then mkPrimInfo "unit"
  (* byte array type *)
  elif ty.Equals(typeof<byte[]>) then mkPrimInfo "bytes"
  (* Function type - make functions into DepArrowSS. *)
  elif ty.Name.Equals("FSharpFunc`2") || ty.BaseType.Name.Equals("FSharpFunc`2") then
    let get_dep_arrow curdeps curty =
      let classes, _classname, typeArgs = processObjType curdeps curty [] in
      let procArgs =
        if (List.length typeArgs) = 2
          then (typeArgs.[0], TType_fun (None, typeArgs.[0], typeArgs.[1]))
          else Printf.printf "typeargs: %A\n" typeArgs; raise (Unexpected "Function with # of args != 2") in
      let fundata = mkType "DepArrowSS" procArgs in
        classes, fundata in

    let rec get_fun_type curdeps (ty : Type) (mchildty : Type option)
      : depinfo * tType =
      let new_deps, funty = get_dep_arrow curdeps ty in
      match funty with
      | TType_concrete (["DepArrowSS"], _, _, _) ->
        let retty =
          match mchildty with
          | Some childty -> SuperClassType.decode(childty, funty).getValue()
          | None -> funty in
          new_deps, retty
      | TType_name ((["System"; "object"], _), _) -> raise Undefined
      | _ -> get_fun_type curdeps ty.BaseType (Some ty) in

      let (deps, rty) =
        if ty.BaseType.Name.Equals("FSharpFunc`2")
          then get_fun_type curdeps ty.BaseType (Some ty)
          else get_fun_type curdeps ty None in
        Printf.printf "Got function type for %A\n" ty;
        (deps, rty)
  (* Tuple type. *)
  elif ty.Name.Equals("DepTuple2SS`2") then
    Printf.printf "Process tuple type: %A\n" ty;
    let class_kinds = ClassParamKinds.decode(ty).getValue() in
    Printf.printf "class kinds: %A\n" class_kinds;
    let classes, _classname, typeArgs = processObjType curdeps ty class_kinds in
    let procArgs =
        if (List.length typeArgs) = 2
          then
            let arg1 = typeArgs.[0] in
            let arg2 = typeArgs.[1] in
              match class_kinds.[1] with
              | TKind_star
              | _ ->
                let newvar = gensym () in
                  ( arg1
                  , TType_fun
                      ( Some (newvar, newvar)
                      , arg1
                      , TType_dep (arg2, (TVal_var (newvar, typeArgs.[0]))) ) )
          (* NOTE: The dependency will be fixed later. *)
          else raise (Unexpected "Function with # of args != 2") in
    let fundata = mkType "DepTuple2SS" procArgs in
      Printf.printf "Tuple type: %A\n" fundata;
      (classes, fundata)
  elif ty.Name.StartsWith("All") then
    let classes, name, tyargs = processObjType curdeps ty [] in
      (classes, TType_concrete (tClassAll.name, [], List.map Targ tyargs, None)) (* !! what kinds? *)
  else
    let deps', classname, typeArgs = processObjType curdeps ty  [] in
    match typeArgs with
    | [] ->
        let classes, name = processName deps' ty.FullName in
          (classes, mkTy name kind)
    | _ ->
      let cn = String.split ['+'] ((String.split ['`'] ty.FullName).[0]) in
        (deps', TType_concrete (cn, [], List.map Targ typeArgs, None))

(*********************)
(* OBJECT PROCESSING *)
(*********************)
(* Processing primitive expressions. *)
let processPrimitive (curdeps : depinfo) (v : 'a) : depinfo * tType * tValue =
  let vtype = v.GetType () in
    if vtype.Equals(typeof<int>)
      then
        let (intval : int) = Convert.ToInt32(v) in
            (curdeps, intType, TVal_constant (Const_int32 intval))
    else raise (Unimplemented "Non-integer primitive expression.")
(* Processing strings. *)
let processString (curdeps : depinfo) (v : string)
  : depinfo * tType * tValue =
  let strval =
    TVal_constant (Sugar.Const_string
          (System.Text.Encoding.Unicode.GetBytes(v), 1044855479211737092L)) in
   (curdeps, stringType, strval)
(* Processing byte arrays. *)
let processBytes (curdeps : depinfo) (v : byte[]) : depinfo * tType * tType * tExp =
  let _, strty, strval =
    processString curdeps (System.Convert.ToBase64String v) in
  let b64t = TType_concrete((["DepArrowSS"], 
                             [],
                             [Targ stringType; Targ(TType_fun(None, stringType, bytesType))], 
                             None)) in
  let primsFromB64 = TExp_name((["Prims";"FromBase64String"], b64t), None) in
    ( curdeps, bytesType, bytesType
    , hoist (primsFromB64, b64t) (fun v -> TExp_call(v, [strval], ("Invoke", []))) )

(* Processing objects. *)
(* Also, this function should figure out what x depends on... *)
let rec processObject (curdeps : depinfo) (v : 'a) : depinfo * tType * tType * tExp =
  Printf.printf "process object: %A\n" v;
  (* Get namespace, class, etc. *)
  let vtype : Type  = v.GetType () in (* NIK: expensive, pass in type from caller which already has it *)

  let class_kinds = ClassParamKinds.decode(vtype).getValue() in
  let _ = Printf.printf "class param kinds are: %A\n" class_kinds in 
  (* Get object type information. *)
  let (includes, lname, typeArgs) = processObjType curdeps vtype class_kinds in

  (* Get object fields. *)
  let vfields : FieldInfo [] = vtype.GetFields () in
  let (classes', argExpTyps') =
    Array.fold
      (fun (depacc, etacc) (field : FieldInfo) ->
        let (deps', par_ty, curty, curexp) =
          processValue depacc field.FieldType (field.GetValue (v)) in
        (* Get the attribute for the field type and unify it with the CIL type
           we find. *)
        (* let actual_ty = get_ftype_from_attribs par_ty field in *)
          (deps', (curexp, par_ty)::etacc))
      (includes, []) vfields in
  let argExpTyps = List.rev argExpTyps' in
  let argTypes = List.map snd argExpTyps in
  Printf.printf "Arg exp types: %A\n" argExpTyps;

  (* The actual type is the parent type because of the way variants are
     represented in DCIL. *)
  let parClasses, ty = processTypeName classes' vtype.BaseType TKind_star in
  let typeArgs' =
    match ty with
    | TType_concrete (["DepTuple2SS"], _, args, _) ->
      getTys args
    | _ -> typeArgs in
  Printf.printf "Type args: %A\n" typeArgs';

  (* Make an object with the appropriate type parameters. *)
  let objval =
    hoistList argExpTyps
      (fun argVals -> 
        TExp_val
          (TVal_obj
            ((lname, []
            , (List.map Targ typeArgs')@(List.map Varg argVals)
            , None), []))) in

  (* Get the type. *)
  let mtype =
    let rec get_type oval =
      match oval with
      | TExp_val (TVal_obj (cty, _)) ->
        (match ty with
        | TType_name _ -> TType_concrete cty
        | _ -> ty)
      | TExp_let (_, _, b, _) -> get_type b
      | _ -> Printf.printf "got objval: %A\n" objval; raise Undefined in
    get_type objval in

  (* let retty = get_superclassty_from_attribs mtype v in
    Printf.printf "Process object returning: %A\n" retty; *)
    (parClasses, ty, mtype, objval)
    
and processValue (curdeps : depinfo) (vtype : Type) (v : obj)
    : depinfo * tType * tType * tExp =
  if vtype.IsPrimitive
    then let a, ty, v = processPrimitive curdeps v in a, ty, ty, TExp_val(v)
    (* Strings. *)
  else if vtype.Equals(typeof<string>) then 
    let a, ty, v = processString curdeps (v :?> string) in
      a, ty, ty, TExp_val(v)
  else if vtype.Equals(typeof<byte[]>) then processBytes curdeps (v :?> (byte[]))
    (* F# functions. *)
        (*
  else if (vtype.BaseType.Name).Equals("FSharpFunc`2")
    then  Printf.printf "Processing function closure\n"; processFunction curdeps vtype.BaseType v *)
  (* Other classes. *)
  else if vtype.IsClass then processObject curdeps v
  else raise (Unimplemented "some other kind of value")
    
(* Steps for pickling:
    - Look through the references in x, look up the DLL's in the current
      directory, and include code for classes that are referenced.
*)
let pickle_with_name (cur_name : string) (x : 'a) : byte[] =
  Printf.printf "PICKLING %A\n" x;
  (* Use the reflection library to learn some things about this value. *)
  let (included_modules, retty, mtype, mbody) =
    processValue empty_depinfo (x.GetType ()) x in
    mkPickleDLL cur_name included_modules retty mbody

let pickle (x : 'a) : byte[] = pickle_with_name "" x

let load_assembly (s:string) : 'a =
  Printf.printf "Loading assembly: %s\n" s;
   let assm = Assembly.Load(System.IO.File.ReadAllBytes(s)) in
   let _ = Printf.printf "loaded\n" in
   let typ = assm.GetType("Pickle+Entry") in
   let _ = Printf.printf "got type\n" in
   let entry_object:System.Object = Activator.CreateInstance(typ) in
   let _ = Printf.printf "created instance\n" in
   let meth = typ.GetMethod("entry_point") in
   let _ = Printf.printf "got entry point\n" in
   let t = meth.Invoke(entry_object, ([||]:System.Object [])) in
   let _ = Printf.printf "invoked entry with type %A: %A\n" (t.GetType ()) t in
     (t :?> 'a)

(* Unpickle needs to be defined. *)
let unpickle_dll (file : string) (* TODO: take a type *) : 'a =
  (* Check the module. *)
  let m = read_module (Hashtbl.create 10) file in
  (* TODO: Use target checker's eTyping to check the type of the unpickled expression. *)
  let filert =
    (Options.get_fstar_home ()) + "\\bin\\" + file in
  let e = 
    try load_assembly (filert + ".dll")
    with e ->
      Printf.printf "error: %A\n" e;
      Printf.printf "Could not load DLL: %s.dll\n" filert;
      load_assembly (filert + ".exe") in
    e

let writeBytesToFile (b:byte[]) (f:string) : bool = 
  let _ = Printf.printf "writeBytesToFile: %s\n" f in
  let fs = new System.IO.FileStream(f, FileMode.Create, FileAccess.ReadWrite) in
  let bw = new BinaryWriter(fs) in
  let _ = bw.Write(b) in
  let _ = bw.Close() in 
    true

(* TODO: Target checker here. *)
let unpickle (s:byte []) =
  Printf.printf "calling unpickle";
   let assm = Assembly.Load(s) in
   let typ = assm.GetType("Pickle+Entry") in 
   let entry_object:System.Object = Activator.CreateInstance(typ) in
   let meth = typ.GetMethod("entry_point") in
   let t = meth.Invoke(entry_object, ([||]:System.Object [])) in
   (t :?> 'a)

type punit = MkPunit 

let Assume (x : Microsoft.FSharp.Core.Unit) : bool = false
let Assert (x : Microsoft.FSharp.Core.Unit) : bool = false
let PAssume (x:int) = MkPunit

let ToUnicodeString (b:byte[]): string = System.Text.Encoding.Unicode.GetString(b)
let FromUnicodeString (s:string) : byte[] = System.Text.Encoding.Unicode.GetBytes(s)
