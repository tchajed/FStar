#light "off"
// (c) Microsoft Corporation. All rights reserved

module Microsoft.FStar.Unionfind
(* A naive implementation of unionfind. *)


type cell<'a when 'a : not struct> = {mutable contents : contents<'a> }
and contents<'a when 'a : not struct> = 
  | Data of list<'a> * int
  | Fwd of cell<'a>
type uvar<'a when 'a : not struct> = 'a cell

exception Impos


let counter = ref 0

let fresh x = counter := !counter + 1; {contents = Data ([x], !counter) }
  
let rec rep cell = match cell.contents with 
    Data _ -> cell
  | Fwd cell' -> rep cell'

let find x = match (rep x).contents with
    Data ((hd::tl), _) -> hd
  | _ -> raise Impos

let uvar_id uv = match (rep uv).contents with
    Data (_, id) -> id
  | _ -> raise Impos

let union x y = 
  let cellX = rep x in
  let cellY = rep y in
    if LanguagePrimitives.PhysicalEquality cellX cellY then ()
    else match cellX.contents, cellY.contents with
        Data (dx, ctrx), Data (dy,ctry) -> 
          let newcell = {contents = Data ((dx@dy),ctrx) } in
            cellX.contents <- Fwd newcell;
            cellY.contents <- Fwd newcell
      | _ -> raise Impos
          
let change x a = 
  let cellX = rep x in
    match cellX.contents with 
	Data (_, ctrX) -> 
	  cellX.contents <- Data ([a],ctrX)
      | _ -> raise Impos


let equivalent x y =
  LanguagePrimitives.PhysicalEquality (rep x) (rep y)
