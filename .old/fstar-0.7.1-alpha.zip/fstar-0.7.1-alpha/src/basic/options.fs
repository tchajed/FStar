#light "off"

// (c) Microsoft Corporation. All rights reserved
module Microsoft.FStar.Options
open Getopt

let ts_star = ref false
let monadic_subtyping = ref false
let ncnb = ref (None : option<string>)
let double_only = ref false
let normalize_monadic_refinements = ref false
let generalize_monadic_types = ref false
let mbqi = ref false
let logic_function_typing = ref true
let delay_monadic_unification = ref false
let monadic_conv = ref false
let relax_order = ref false
let js_warnings_only = ref true
let use_type_constants = ref true
let relational = ref false
let parallel = ref false
let z3log = ref false
let restore = ref false
let separate_qops = ref false
let quiet = ref true
let writePrims = ref false 
let to_dcil = ref false
let cache = ref false
let read_prelude_cache = ref false
let write_prelude_cache = ref false
let cache_file = ref ".fstar.prelude.cache"
let prelude_cache_file () = !cache_file

let modulecache = ref false
let addGK = ref false  // flag to enable the GateKeeper pass
let spl = ref false
let eraseproofs = ref false
let profile_attribs = ref false
let silent=ref false
let verbosity = ref -1
let f7 = ref false
let f7backend = ref false
let ignore_queries = ref false
let outputAsm : option<string> ref = ref None
let trace_counter = ref 0
let inline_proof_term = ref false
let interleave_proof_principles = ref true
let extract_proofs = ref false
let typecheck_proofs = ref false
let skipUnit = ref false
let proof_term_errs = ref false
let skip_trans = ref false
let genIL = ref false
let verbose_names = ref false
let print_real_names = ref true
let mainmodule = ref false
let dump_module = ref None
let dump_src = ref false
let dump_tgt = ref false
let rdcil = ref false
let rdcil_z3eq = ref false
let skip_target_checker = ref false
#if RISE4FUN
let logQueries = ref true
let z3exe = ref true
let outputDir = ref (Some ".")
let encodingdt = ref true
let new_parser = ref true
#else
let logQueries = ref false
let z3exe = ref false
let outputDir : option<string> ref = ref None      
let encodingdt = ref false
let new_parser = ref false
#endif
let emulateContexts = ref false
let writeAttribs = ref false
(* TODO: Remove this option eventually when we aren't using the standard serializer at all anymore. *)
let prettyAttribs = ref false
let gadt = ref false
let suppress_trace = ref true
let light = ref true
let newZ3encoding = ref true
let certify = ref false
let cert_dir_opt = ref None
let print_certs = ref false
let debug_certify = ref false
let dcil_logicfun = ref false
let embed0 = ref false
let embed1 = ref false
let hashcons_poly = ref false
let monadic = ref false
let no_anf = ref false
let describe_queries = ref false
let skip_queries = ref (None : Option<int>)
let skipped_queries = ref 0
let fstar_home_opt = ref None
let _fstar_home = ref ""
let prims_ref = ref None
let prooflibvals_ref = ref None
let noprims = ref false
let __unsafe = ref false
let _metadata_version = ref "2.0.50727.0"
let dotnet4 = ref false
let allow_partially_trusted = ref false
let output_js : string option ref = ref None
let js_runtime () = match !output_js with 
  | None -> false
  | _ -> true
let z3timeout = ref None
let profiling = ref false

let set_fstar_home () = 
  let fh = match !fstar_home_opt with 
    | None ->
      let x = System.Environment.ExpandEnvironmentVariables("%FSTAR_HOME%") in
      _fstar_home := x;
      fstar_home_opt := Some x;
      x
    | Some x -> _fstar_home := x; x in
  fh
let get_fstar_home () = match !fstar_home_opt with 
    | None -> set_fstar_home(); !_fstar_home
    | Some x -> x
let get_cert_dir () = match !cert_dir_opt with 
  | Some x -> x
  | _ -> Printf.sprintf "%s/papers/ekind/formalizing/certify" (get_fstar_home())


#if RISE4FUN
 let _ =
   silent := true; 
   certify := false
#endif

#if RELEASE
 let _ = silent := true
#endif

let prims () = match !prims_ref with 
  | None -> 
#if RISE4FUN
      Printf.sprintf "%s/lib/prims-lighter.fst" (get_fstar_home())
#else
      if !noprims 
      then (Printf.sprintf "%s/lib/noprims.fst" (get_fstar_home()))
      else (Printf.sprintf "%s/lib/prims.fst" (get_fstar_home()))
#endif
  | Some x -> x

let prooflibvals () = match !prooflibvals_ref with 
  | None -> Printf.sprintf "%s/lib/noplv.fst" (get_fstar_home())
  | Some x -> x


let _signer = ref None
let set_signer path = match !_signer with
  | None -> _signer := Some (Microsoft.FSharp.Compiler.AbstractIL.BinaryWriter.signerOpenKeyPairFile path)
  | Some _ -> raise (Failure "--keyfile should only be specified once")

let get_signer () = !_signer

let set_dotnet4 () =
  (dotnet4 := true;
   _metadata_version := "4.0.30319")

let get_metadata_version () = !_metadata_version

let prependOutputDir fname = match !outputDir with
  | None -> fname
  | Some x -> x ^ "/" ^ fname 

let getZ3Timeout () = match !z3timeout with 
  | Some s -> s
  | _ -> "10000"

let skip_first_queries s =
  try
    let n = int_of_string s in
      if n < 0 then
        (System.Console.Error.Write("error: can't skip a negative number ('" + s + "') of queries\n");
         System.Environment.Exit(1))
      else
        (if n = 0 then ()
         else
           (Printf.printf "SKIPPING THE FIRST %d QUERIES!!!\n" n;
            skip_queries := Some n))
  with
    | :? System.Exception ->
      (System.Console.Error.Write("error: argument '" + s + "' of --UNSAFE_skip_first_queries is not a number\n");
       System.Environment.Exit(1))  

let rec specs : list<Getopt.opt> = 
[
  ( 'h', "help", ZeroArgs (fun x -> display_usage (); System.Environment.Exit(0)), "Display this information");
  ( 'v', "verbosity", OneArg ((fun x -> verbosity := int_of_string x; quiet := false), "v"), "");
  ( noshort, "z3log", ZeroArgs (fun () -> z3log := true), "Dump a detailed Z3 debugging log to z3.log");
  ( noshort, "z3exe", ZeroArgs (fun () -> logQueries := true; emulateContexts := true; z3exe := true), "Call z3.exe instead of via the .NET API (implies --logQueries)");
  ( noshort, "dtencoding", ZeroArgs (fun () -> encodingdt := true), "Use the new datatype encoding with Z3");
  ( noshort, "sep_qops", ZeroArgs (fun () -> separate_qops := true), "Defer quantified assumptions when generating Z3 models");
  ( noshort, "f7", ZeroArgs (fun () -> f7 := true), "");
  ( noshort, "f7backend", ZeroArgs (fun () -> f7 := true; f7backend := true), "");
  ( noshort, "trace", OneArg ((fun x -> verbosity := -(int_of_string x)), "v"), "");
  ( noshort, "fstar_home", OneArg ((fun x -> fstar_home_opt := Some x), "dir"), "Set the FSTAR_HOME variable to dir");
  ( noshort, "profile", ZeroArgs (fun () -> Printf.printf "Setting profiling flag!\n"; profiling := true), "");
  ( noshort, "silent", ZeroArgs (fun () -> silent := true), "");
  ( noshort, "prims", OneArg ((fun x -> prims_ref := Some x), "file"), "");
  ( noshort, "prooflibvals", OneArg ((fun x -> prooflibvals_ref := Some x), "file"), "");
  ( noshort, "prn", ZeroArgs (fun () -> print_real_names := true), "Print real names---you may want to use this in conjunction with logQueries");
  ( noshort, "dump_module", OneArg ((fun x -> dump_module := Some x), "module name"), "");
  ( noshort, "dump_src", ZeroArgs (fun () -> dump_src := true), "");
  ( noshort, "dump_tgt", ZeroArgs (fun () -> dump_tgt := true), "");
  ( noshort, "z3timeout", OneArg ((fun s -> z3timeout := Some s), "t"), "Set the Z3 soft timeout to t milliseconds");
  ( noshort, "logQueries", ZeroArgs (fun () -> logQueries := true; emulateContexts := true), "Log the Z3 queries in $FSTAR_HOME/bin/queries/, or in odir, if set; also see --prn");
  ( noshort, "gadt", ZeroArgs (fun () -> gadt := true), "");
  ( noshort, "trace_err", ZeroArgs (fun () -> suppress_trace := false), "");
  ( noshort, "js", OneArg ((fun js -> output_js := Some js), "dir"), "");
  ( noshort, "cert", ZeroArgs (fun js -> certify := true), "");
  ( noshort, "print_certs", ZeroArgs (fun js -> print_certs := true), "");
  ( noshort, "debug_cert", ZeroArgs (fun js -> debug_certify := true), "");
  ( noshort, "cert_dir", OneArg ((fun js -> cert_dir_opt := Some js), "dir"), "");
  ( noshort, "dcil_logicfun", ZeroArgs (fun js -> dcil_logicfun := true), "");
  ( noshort, "UNSAFE", ZeroArgs (fun () -> Printf.printf "UNSAFE MODE!\n"; __unsafe := true; skip_target_checker := true), "");
  ( noshort, "hashcons_poly", ZeroArgs (fun () -> hashcons_poly := true), "");
  ( noshort, "monadic", ZeroArgs (fun () -> monadic := true), "");
  ( noshort, "addGK", ZeroArgs (fun () -> addGK := true), "Use Gatekeeper");
  ( noshort, "describe_queries", ZeroArgs (fun () -> describe_queries := true), "Print the queried formula and its location");
  ( noshort, "UNSAFE_skip_first_queries", OneArg ((fun x -> skip_first_queries x), "n"), "Skip the first n queries");
  ( noshort, "restore", ZeroArgs (fun () -> restore := true), "");
  ( noshort, "parallel", ZeroArgs(fun () -> parallel := true), "Use multiple threads when calling Z3");
  ( noshort, "rrf", ZeroArgs(fun () -> relational := true), "Relational mode (RRF)");
  ( noshort, "writecache", ZeroArgs (fun () -> write_prelude_cache := true), "Write a cached prelude");
  ( noshort, "readcache", ZeroArgs (fun () -> read_prelude_cache := true), "Read the cached prelude");
  ( noshort, "rc", ZeroArgs (fun () -> read_prelude_cache := true), "Read the cached prelude");
  ( noshort, "cachefile", OneArg ((fun x -> cache_file := x), "file"), "Location of binary cache of prelude");
  ( noshort, "z3encode_binders", ZeroArgs (fun () -> use_type_constants := false), "Encode type-level binders in Z3 terms");
  ( noshort, "dotnet_warnings", ZeroArgs (fun () -> js_warnings_only := false), "Warn about .NET compilation limitations");
  ( noshort, "relax_order", ZeroArgs (fun () -> Printf.printf "Warning: checking let-bindings and value-declarations out of order.\n"; relax_order := true), "Allow out-of-order let/val");
  ( noshort, "monadic_conv", ZeroArgs (fun () -> monadic_conv := true), "Use an optimized monadic convertibility check");
  ( noshort, "delay_monadic_unification", ZeroArgs (fun () -> delay_monadic_unification := true), "Delay unification");
  ( noshort, "skip_logic_function_typing_triggers", ZeroArgs (fun () -> logic_function_typing := false), "Do not add hypothesis for the typing of logic functions");
  ( noshort, "MBQI", ZeroArgs (fun () -> mbqi := true), "Try Z3's MBQI mode if all else fails");
  ( noshort, "normalize_monadic_refinements", ZeroArgs (fun () -> normalize_monadic_refinements := true), "Push refinements into pre- and post-conditions");
  ( noshort, "generalize_monadic_types", ZeroArgs (fun () -> generalize_monadic_types := true), "Generalize let-bound monadic values");
  ( noshort, "double_only", ZeroArgs (fun () -> double_only := true), "No single-sided rules in relational mode");
  ( noshort, "ncnb", OneArg ((fun s -> ncnb := Some s), "file"), "Dump non-comment, non-blank lines of ANF'd code to the specified file");
  ( noshort, "monadic_subtyping", ZeroArgs (fun () -> monadic_subtyping := true), "In monadic mode, use the new implementation of refinement subtyping");
  ( noshort, "lighter", ZeroArgs (fun () -> new_parser := true), "Use the new, lighter syntax");
  ( noshort, "odir", OneArg ((fun x -> outputDir := Some x), "dir"), "Place output in directory dir");
  ( noshort, "ts*", ZeroArgs (fun () -> ts_star := true;
                                        new_parser := true;
                                        prims_ref := Some (Printf.sprintf "%s/lib/primsany.fst" (get_fstar_home()))), "TS* mode");
#if RISE4FUN
  
#else
  ( noshort, "skip_translation", ZeroArgs (fun () -> skip_trans := true), "");
  ( noshort, "to_dcil", ZeroArgs (fun () -> to_dcil := true), "");
  ( noshort, "rdcil", ZeroArgs (fun () -> rdcil := true; to_dcil := true), "");
  ( noshort, "rdcil_z3eq", ZeroArgs (fun () -> rdcil := true; to_dcil := true; rdcil_z3eq := true), "");
  ( noshort, "genIL", ZeroArgs (fun () -> genIL := true; to_dcil:=true; ), "");
  ( noshort, "writePrims", ZeroArgs (fun () -> writePrims := true; genIL:=true;to_dcil:=true), "");
  ( noshort, "o", OneArg ((fun x -> outputAsm := Some x), "file"), "");
  ( noshort, "pickle", ZeroArgs (fun () -> writeAttribs := true), "");
  ( noshort, "pretty_attribs", ZeroArgs (fun () -> prettyAttribs := true), "");
  ( noshort, "keyfile", OneArg ((fun x -> set_signer x), "file"), "");
  ( noshort, "profile_attribs", ZeroArgs (fun () -> profile_attribs := true), "");
  ( noshort, "dotnet4", ZeroArgs (fun () -> set_dotnet4 ()), "");
  ( noshort, "emulateContexts", ZeroArgs (fun () -> emulateContexts := true), "");
  ( noshort, "UNSAFE_skip_target_checker", 
    ZeroArgs (fun () -> 
                Printf.printf "SKIPPING TARGET CHECKER!!!\n";
                skip_target_checker := true),
		"Do not typecheck the generated code");
  ( noshort, "partially-trusted-callers", 
    ZeroArgs (fun () -> allow_partially_trusted := true), "");
#endif
]
and display_usage () =
  printfn "fstar [option] infile...";
  List.iter
    (fun (_, flag, p, doc) ->
       match p with
         | ZeroArgs _ ->
             if doc = "" then printfn "  --%s" flag
             else printfn "  --%s  %s" flag doc
         | OneArg (_, argname) ->
             if doc = "" then printfn "  --%s %s" flag argname
             else printfn "  --%s %s  %s" flag argname doc)
    specs
