#light "off"
// (c) Microsoft Corporation. All rights reserved
module Microsoft.FStar.Util

open System.Diagnostics
open System.IO
open System.IO.Compression
open Options
open Profiling

exception Impos
exception NYI of string
exception Not_found
exception Bad of string
exception Failure of string

let objSize (o:'a) = 
  let s = new System.IO.MemoryStream() in 
  let formatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter() in
    formatter.Serialize(s, box ([o]));
    s.Flush(); 
    let res = s.Length in 
      s.Close();
      res
  
let pr x = 
  if !silent then Printf.fprintf System.IO.TextWriter.Null x
  else Printf.printf x
let spr = Printf.sprintf 
let fpr = Printf.fprintf 
let ios = int_of_string
let soi = string_of_int
let iof = int_of_float
let foi = float_of_int

let err_out : option<System.IO.StreamWriter> ref = ref None 
let open_err_out (s:string) = (err_out := Some (new System.IO.StreamWriter(s)))
let flush_err_out () = match !err_out with None -> () | Some e -> (e.Flush(); e.Close())
let unicodeEncoding = new System.Text.UnicodeEncoding()
let asciiEncoding = new System.Text.ASCIIEncoding()

type DebugLog() =
  class
  [<Conditional("DEBUG")>]
  static member Log (s:string) = Printf.printf "%s" s 
end

let warn (x:Printf.TextWriterFormat<'a>) = pr "Warning: "; pr x
let err (x:Printf.TextWriterFormat<'a>) = Printf.printf x

let try_find_position matcher f = 
  let rec aux pos = function
    | [] -> None
    | a::tl -> if (matcher a) then Some pos else aux (pos+1us) tl
  in aux 0us f

let debug l s = 
  if (!verbosity > l) then 
    begin
      Printf.printf "\n<DEBUG>\n"; Printf.printf s ; Printf.printf "\n</DEBUG>\n"
    end
      
let debug_dump v s a = 
  if (!verbosity > v) then 
    begin
      debug v s; printfn "%A" a
    end

let bump_trace_counter () = trace_counter:=!trace_counter+1; !trace_counter
let trace n s a = 
  if (!verbosity = n) then 
    (let n = bump_trace_counter () in
       Printf.printf "\n%d<trace>:" n;
       print_string s; printfn "%A" a;
       Printf.printf "\n</trace>%d\n" n; flush stdout)
      
type Disj<'a,'b> =
  | Inl of 'a
  | Inr of 'b

type triVal =
  | Yes 
  | No
  | Maybe
      
let (-<-) f g x = f (g x)

let pfx l = 
  match List.rev l with 
      hd::tl -> List.rev tl, hd
    | _ -> raise Impos


          
(* lookup in associative list *)
let rec assocFind p = function
  | []       -> raise Not_found
  | (x,y)::t -> if p x then y else assocFind p t

(* get index of first occurrence of x in l, if any *)
let findIdx x l =
  let rec f k = function
    | [] -> None
    | y::tl -> if x = y then Some k else f (succ k) tl
  in
  f 0 l

let listOfOpt = function
  | None -> []
  | Some l -> [l]

let findOpt f l = 
  let rec aux = function 
    | [] -> None
    | hd::tl -> if f hd then Some hd else aux tl in 
    aux l
        
let rec intersect l1 l2 f = 
  List.fold_left (fun out l1elt -> 
                    if List.exists (fun l2elt -> f l1elt l2elt) l2 then
                      l1elt::out
                    else out) [] l1

let array0N n = Array.init (succ n) (fun i -> i)
let array1N n = Array.init n (fun i -> i + 1)

let list0N n = Array.to_list (array0N n)
let list1N n = Array.to_list (array1N n)

let map1N n f = List.map f (list1N n) 

let prefixUntil l f = 
  let rec aux out l = match l with
    | [] -> List.rev out, None, []
    | hd::tl -> 
        if f hd then List.rev out, Some hd, tl
        else aux (hd::out) tl in 
    aux [] l

let rec gatherUntil l f = match l with 
  | hd::tl when f hd -> 
      let more, rest = gatherUntil tl f in 
        hd::more, rest
  | _ -> [], l 

let interleave l1 l2 =
  if List.length l1 <> List.length l2 then failwith "interleave" else
  let rec f acc = function
    | [], []       -> acc
    | x::xs, y::ys -> f (y::x::acc) (xs,ys)
  in
  List.rev (f [] (l1,l2))

let firstN n l =
  let rec f acc i l =
    if i = n then List.rev acc,l else
    match l with
      | h::tl -> f (h::acc) (i+1) tl
      | _     -> failwith "firstN"
  in
  f [] 0 l

let nodups f l = 
  let rec aux = function 
    | hd::tl -> 
        let hds, tl' = List.partition (f hd) tl in 
          (match hds with 
             | [] -> aux tl' 
             | _ -> false)
    | _ -> true in
    aux l

let remove_dups f l = 
   let rec aux out = function 
   | hd::tl -> let _, tl' = List.partition (f hd) tl in aux (hd::out) tl'
   | _ -> out in
   aux [] l

let subtract f l1 l2 = 
  let rec aux out = function 
    | hd::tl -> if List.exists (f hd) l2 then aux out tl else aux (hd::out) tl 
    | [] -> List.rev out in
  aux [] l1

let findAndSub f l =
  let rec aux out = function 
    | hd::tl -> 
        if f hd 
        then Some hd, (List.rev out)@tl 
        else aux (hd::out) tl
    | [] -> None, List.rev out in
    aux [] l

let remove_tail m tl = 
    let rec aux out m = 
        if LanguagePrimitives.PhysicalEquality tl m then List.rev out
        else match m with [] -> [] | hd::tl_m -> aux (hd::out) tl_m in
    aux [] m 
     
let is_some = function
  | Some _ -> true
  | _ -> false

let must = function
    Some x -> x
  | None -> raise Impos

let rec any = function
  | [] -> None
  | hd::tl -> match hd() with 
      | Some r -> Some r
      | _ -> any tl

let bind_opt opt f = match opt with
    None -> None
  | Some x -> f x

let tensor_opt opt f = match opt with
    None -> None
  | Some x -> Some (f x)

let rec find_map l f = match l with 
    [] -> None 
  | x::tl -> match f x with 
        None -> find_map tl f
      | y -> y
          
let (=^^=>) m f = match m with 
  | None -> f ()
  | _ -> m

let (===) a b = LanguagePrimitives.PhysicalEquality a b

let existsNone l = List.exists (function None -> true | _ -> false) l

let projSomes l = List.map (function (Some x) -> x) l

let wrapSomes l = List.map (fun x -> Some x) l 

(* Serialization utils. *)
let typeFormatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter()

let deflate_compress (bytes : byte []) : byte [] =
  let (ms : MemoryStream) = new MemoryStream () in
  let (ds : DeflateStream) = new DeflateStream(ms, CompressionMode.Compress) in
    ds.Write(bytes, 0, bytes.Length);
    ds.Flush();
    ds.Close();
  let bytes = ms.ToArray () in
  let taggedBytes:byte[] = Array.zeroCreate (bytes.Length + 1) in
    bytes.CopyTo(taggedBytes, 1);
    taggedBytes.[0] <- 1uy;
    taggedBytes //first byte of a compressed stream must always be 1

(* Compression and decompression. *)
let standard_compress (bytes : byte []) : byte [] =
  let dbytes = deflate_compress bytes in 
  if (bytes.Length < dbytes.Length) then 
    (let r:byte[] = Array.zeroCreate (bytes.Length + 1) in
    bytes.CopyTo(r, 1); //uncompressed stream; so let first byte be tagged as 0
    r)
  else dbytes
let standard_decompress (bytes : byte []) : byte [] =
  if (bytes.[0] = 0uy) then bytes.[1..]
  else CompressionUtils.Decompress(bytes.[1..])

let serialize_string (str : string) : byte [] =
  let bytes = asciiEncoding.GetBytes (str) in
  let dbytes = deflate_compress (bytes) in 
  if (bytes.Length < dbytes.Length) then 
    (let r:byte[] = Array.zeroCreate (bytes.Length + 1) in
    bytes.CopyTo(r, 1); //uncompressed stream; so let first byte be tagged as 0
    r)
  else dbytes

let string_to_ascii_bytes: string -> byte [] = fun s -> asciiEncoding.GetBytes(s)
let ascii_bytes_to_string: byte [] -> string = fun b -> asciiEncoding.GetString(b)

let __temp_dot_net_marshall (x:'a) : byte [] =
  let os = new System.IO.MemoryStream () in 
    typeFormatter.Serialize(os, box [x]); 
    os.Flush(); 
    let bytes = os.GetBuffer(); in 
    os.Close(); 
    bytes 
let __temp_dot_net_unmarshall (bytes : byte []) : 'a =
  (* let str = asciiEncoding.GetString(bytes) in *)
  let s = new System.IO.MemoryStream(bytes) in
  let formatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter() in    
    let (vl: 'a list) = unbox (formatter.Deserialize(s))  in 
      match vl with 
      | [v] -> v
      | _ -> raise Impos

  
(* A simple state monad *)
type state<'s,'a> = ('s -> ('a*'s)) 
let get : state<'s,'s> = fun s -> s,s
let upd (f:'s -> 's) : state<'s, unit> = fun s -> (), f s 
let put (s:'s) : state<'s, unit> = fun _ -> (), s
let ret (x:'a) : state<'s,'a> = fun s -> x, s
let bind (sa:state<'s,'a>) (f : 'a -> state<'s,'b>) : state<'s,'b> = fun s1 -> 
  let a, s2 = sa s1 in (f a) s2
let (>>) s f = bind s f  
let runState init s = s init

let rec stmap (l:list<'a>) (f: 'a -> state<'s,'b>) : state<'s, list<'b>> = match l with 
    | [] -> ret []
    | hd::tl -> bind (f hd) 
                     (fun b -> 
                        let stl = stmap tl f in 
                        bind stl (fun tl -> ret (b::tl)))   

let stmapi (l:list<'a>) (f:int -> 'a -> state<'s,'b>) : state<'s, list<'b>> = 
  let rec aux i l = match l with
    | [] -> ret []
    | hd::tl -> 
      bind (f i hd) 
        (fun b -> 
          let stl = aux (i + 1) tl in 
          bind stl (fun tl -> ret (b::tl))) in 
  aux 0 l

let rec stiter (l:list<'a>) (f: 'a -> state<'s,unit>) : state<'s, unit> = match l with 
    | [] -> ret ()
    | hd::tl -> bind (f hd) (fun () -> stiter tl f)

let rec stfoldr_pfx (l:list<'a>) (f: list<'a> -> 'a -> state<'s,unit>) : state<'s,unit> = 
  match l with 
    | [] -> ret ()
    | hd::tl -> (stfoldr_pfx tl f) >> (fun _ -> f tl hd)

let rec stfold (init:'b) (l:list<'a>) (f: 'b -> 'a -> state<'s,'b>) : state<'s,'b> = 
  match l with 
    | [] -> ret init
    | hd::tl -> (f init hd) >> (fun next -> stfold next tl f)
                                 
(* Hashtbl as assoc list *)
let hashtbl_as_list h = 
    Hashtbl.fold (fun key value st -> (key,value)::st) h []

(* Query logging *)
let bumpQueryCount, 
    queryCount =
  let queryCount = ref 0 in
    (fun () -> 
       incr queryCount;
       pr "\n#############QUERY %d##################\n" !queryCount; !queryCount), 
  (fun () -> !queryCount)

let queries = ref ""
let set_queries () = 
  let q = spr "%s/bin/queries" (get_fstar_home()) in
    queries := q; q

let queryFile () = 
  match !outputDir with 
    | Some x -> spr "%s/query-%04d.smt2" x (queryCount())
    | None -> spr "%s/query-%04d.smt2" !queries (queryCount())

let streamQueries : option<System.IO.TextWriter> ref = ref None
let set_streamQueries ()    =
  let x = spr "%s/all.smt" !queries in
  let _ = if not (System.IO.Directory.Exists(!queries)) then
    ignore(System.IO.Directory.CreateDirectory(!queries)) in
  let y = 
    if !silent then System.IO.TextWriter.Null 
    else     
      (pr "%s\n" x;
       new System.IO.StreamWriter(spr "%s/all.smt" !queries) :> System.IO.TextWriter) in
    streamQueries := Some y
let stream_query f = (match !streamQueries with None -> () | Some s -> f s)

let writeFile (fn:string) s = 
  let fh = System.IO.StreamWriter(fn)  :> System.IO.TextWriter in
  fpr fh "%s" s;
  fh.Close()
  
let consOpt aopt al = match aopt with 
  | None -> al
  | Some a -> a::al


