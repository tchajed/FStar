#light "off"

// (c) Microsoft Corporation. All rights reserved

module Microsoft.FStar.Tc

open Absyn
open AbsynUtils
open Util
open Const
open Tcenv
open Profiling
open Tcutil
open KindAbbrevs

exception ErrorProofTerm of string * exp
let tc_ctr = new_counter "TC"
let tc_pf_ctr = new_counter "TC proofs"
let kinding_ctr = new_counter "Kinding" 
let kinding_type_index_ctr = new_counter "Kinding type index" 
let inst_ctr = new_counter "Instantiation"
let try_inst_ftyp_ctr = new_counter "Try Inst Final Type"


let contains_bvar l b = List.exists (bvar_eq b) l
  
(* let is_equality_op e = match e.v with *)
(*   | Exp_tapp({v=Exp_fvar (fv,_); sort=_;p=_}, _) -> Sugar.lid_equals fv.v Const.op_Eq  *)
(*   | _ -> false *)

let check_typ_convertible env exp t t' = 
  let sopt = TypeRelations.convertible_ev (set_range env exp.p) t t' in 
    match sopt with 
      | None -> terr env t' t exp
      | Some (subst, ev) -> 
          let _ = unify_subst_vars subst in  (* this has a side effect; changes uvar pointers in Unionfind *) 
            ()
              


let try_kind_convertible range env k k' = 
  match TypeRelations.kind_convertible_ev (set_range env range) k k' with 
    | None -> false
    | Some (subst, ev) -> 
        warn_empty_ev ev;
        let _ = unify_subst_vars subst in true //side-effect on uvar

let check_kind_convertible r msg_thunk env k k' = 
  match TypeRelations.kind_convertible_ev (set_range env r) k k' with 
    | None -> 
        let msg = spr "%s: has kind %s\nExpected kind %s" (msg_thunk()) (Pretty.strKind k) (Pretty.strKind k') in 
          raise (Error(msg, r))
    | Some (subst, ev) -> 
        warn_empty_ev ev;
        let _ = unify_subst_vars subst in () //side-effect on uvar

let check_kind_alt range msg_thunk alts env k = 
  if List.exists (fun alt -> try_kind_convertible range env k alt) alts then ()
  else let msg = spr "%s: has kind %s\nExpected one of {%s}" 
    (msg_thunk()) (Pretty.strKind k ) (String.concat ", " (List.map Pretty.strKind alts)) in
    raise (Error(msg, range))

let rec kinding_dep_list env (l:list<option<bvvdef>*typ*(env -> kind -> unit)>) : list<option<bvvdef> * typ * kind> = 
  let (_, result) = List.fold_left 
    (fun (env, out) (bvd_opt, t, check) -> 
       let t, k = kinding env t in
       let _ = check env k in 
       let env' = match bvd_opt with
         | Some bvd -> push_local_binding env (Binding_var(bvd.realname,t))
         | None -> env in
         (env', (bvd_opt, t, k)::out)) (env, []) l in
    List.rev result

and well_formed_kind (p: Range.range) env k = ok_kind p env k |> fst 

and ok_kind p env k : kind * kind = 
  let is_base_kind = function 
    | Kind_star 
    | Kind_affine
    | Kind_erasable
    | Kind_prop -> true 
    | _ -> false in
  let rec is_small_kind = fun k -> match k(* .u *)with
    | b when is_base_kind b -> true
    | Kind_dcon(xopt,t, k) -> is_small_kind k
    | _ -> false in
  let is_affine = fun k -> match k(* .u *)with 
    | Kind_affine -> true
    | _ -> false in
  let is_ekind = fun k -> match k(* .u *)with 
    | Kind_erasable -> true
    | _ -> false in
  let extend_env env x_or_a_opt t_or_k = match x_or_a_opt, t_or_k with 
    | None, _ -> env
    | Some x, Inl t -> push_local_binding env (Binding_var(real_name x, t)) 
    | Some a, Inr k -> push_local_binding env (Binding_typ(real_name a, k)) in
    match k(* .u *)with 
      | b when is_base_kind b -> k, k
      | Kind_tcon(aopt, k1, k2) -> 
          let k1, b1 = ok_kind p (clear_in_typ_decl env) k1 in 
          let env = extend_env env aopt (Inr k1) in 
          let k2, b2 = ok_kind p env k2 in            
          let k = Kind_tcon(aopt, k1, k2) in
            (match b1(* .u *), b2(* .u *)with 
               | Kind_affine, _ when is_affine b2 -> k, b2
               | _, Kind_erasable 
               | _, Kind_affine -> k, b2
               | _ -> 
                   #if JS
                     #else 
                       if   not (is_small_kind k1) 
                         && not (is_ekind b2)
                         && not !Options.js_warnings_only
                       then 
                         Util.warn "(%s) Got a concrete type with a higher-kinded parameter; may not be able to compile to .NET\n %s\n" 
                           (Range.string_of_range p)
                           (Pretty.strKind k);
                   #endif
                     k,b2)
      | Kind_dcon(xopt, t, k') -> 
          let t, tk = kinding (clear_in_typ_decl env) t in
          let env = extend_env env xopt (Inl t) in 
          let k', b = ok_kind p env k' in
          let k = Kind_dcon(xopt, t, k') in
            (match b(* .u *)with 
               | Kind_erasable -> k, b
               | _ when ((not (is_affine tk)) || not (in_typ_decl env)) -> k,b
               | _ -> raise (Error("Kinds with affine indices must finally be E-kinded", t.p)))

      | _ -> raise (Error (spr "Ill-formed kind: %s" (Pretty.strKind k), p))


and kinding env top : (typ * kind) = 
  let msg () = spr "In type %s" (Pretty.strTyp top) in
  let check_SA = check_kind_alt top.p msg [Kind_star; Kind_affine] in
  let check_SAP = check_kind_alt top.p msg [Kind_star; Kind_affine; Kind_prop] in
  let check_S = check_kind_alt top.p msg [Kind_star] in
  let check_E = check_kind_alt top.p msg [Kind_erasable] in  
  let check_E_or_heap_E = check_kind_alt top.p msg [Kind_erasable; Kind_dcon(None, Const.heap_typ, Kind_erasable)] in 
  let check_P = check_kind_alt top.p msg [Kind_prop] in 
  let rec do_kinding env top : (typ' * kind) = 
    match top.v with
      | Typ_btvar bv -> (* we include this case because we're not doing any opening of exps/typs unlike in Coq *)
          (match lookup_btvar env bv with 
             | Kind_unknown -> 
                 raise (Error ("Type variable with unknown kind", bv.p))
             | k -> 
                 let bv' = bvwithinfo (bv.v) k bv.p in
                   Typ_btvar bv', k)

      | Typ_const (fv,eref) -> 
          (match lookup_typ_const env fv with 
             | Kind_unknown -> 
                 let msg = spr "Type constant with unknown kind: %s (%s)\n" (Pretty.strTyp top) (Pretty.sli fv.v) in
                   raise (Error (msg, fv.p))
             | k -> 
                 let fv' = fvwithinfo (fv.v) k fv.p in
                   Typ_const(fv',eref), k)
            
      | Typ_univ (bvd, k, formulas, t) -> 
          let k, b = ok_kind top.p env k in 
          let _ = 
            if not (Tcutil.kind_abstractable top.p k) 
            then match b with 
              | Kind_erasable -> () 
              | _ -> raise (Error (spr "Cannot abstract over types of kind %s" (Pretty.strKind k), top.p)) 
            else () in
          let binding = Binding_typ (bvd.realname, k) in 
          let env' = push_local_binding env binding in
          let formulas, env' = typing_constraints env' formulas in 
          let t', k' = kinding env' t in
          let tt = Typ_univ(bvd, k, formulas, t') in
            (match k'(* .u *)with 
               | Kind_prop -> tt, Kind_prop
               | Kind_star 
               | Kind_affine -> tt, Kind_star
               | _ -> 
                   let msg = spr "Expected a {*,A,P}-kinded type.\n\
                                   Got type %s of kind %s" (Pretty.strTyp t) (Pretty.strKind k') in
                     raise (Err msg))
              
      | Typ_fun (bvd_opt, t1, t2) ->
          let dlist = [(bvd_opt,t1,check_SAP); (None,t2,check_SAP)] in
            (match kinding_dep_list env dlist with 
               | [(bvd_opt, t1', k1); (_, t2', k2)] -> 
                   let kk = match k2(* .u *)with 
                     | Kind_prop -> Kind_prop
                     | _ -> Kind_star in
                     Typ_fun (bvd_opt, t1', t2'), kk
               | _ -> raise Impos)

      | Typ_refine (bvd, t1, t2, ghost) -> 
          let check_form_kind = 
            if ghost 
            then (if env.object_invariants 
                  then check_E_or_heap_E
                  else check_E)
            else check_P in 
          let dlist = (Some bvd, t1, check_SAP)::[(None, t2, check_form_kind)] in 
            (match kinding_dep_list env dlist with 
                 [(Some bvd, t1', k1); (_, t2', k2)] -> Typ_refine (bvd, t1', t2', ghost), k1 (* Nik: this used to be (kind_lub k1 k2). Why? *)
               | _ -> raise Impos)

      | Typ_dtuple dlist -> 
          let dlistk = kinding_dep_list env (List.map (fun (x,t) -> (x,t,check_SAP)) dlist) in
          let k, dlistrev = List.fold_left (fun (k, out) (n, t, k') -> (kind_lub k k', (n,t)::out)) (Kind_star,[]) dlistk in
          let k = match k with 
            | Kind_prop -> Kind_star
            | _ -> k in 
            Typ_dtuple (List.rev dlistrev), k

      | Typ_app({v=Typ_app({v=Typ_const(qlid,_)} as t1lhs, t1arg)} as t1, t2) when Const.is_qlid qlid.v -> 
          let t2, k2 = kinding env t2 in 
            (match t2.v with 
               | Typ_lam(_, actual, _) -> 
                   let t1arg = match t1arg.v with 
                     | Typ_unknown -> actual
                     | _ -> t1arg in 
                   let t1lhs = match actual.sort with 
                     | Kind_star -> t1lhs
                     | Kind_prop -> if is_exists qlid.v then existsP_typ else forallP_typ
                     | Kind_affine -> if is_exists qlid.v then existsA_typ else forallA_typ in
                   let t1, k1 = kinding env (twithinfo (Typ_app(t1lhs, t1arg)) t1.sort t1.p) in
                     (match k1 with 
                        | Kind_tcon(_, k1', _) -> 
                            (match TypeRelations.force_kind_convertible_ev env t2.sort k1' with 
                               | None -> 
                                   let msg = spr "Expected a quantifier of kind %s but got %s" (Pretty.strKind k1') (Pretty.strKind t2.sort) in 
                                     raise (Error(msg, t2.p))
                               | Some _ -> 
                                   Typ_app(t1, t2), Kind_erasable)
                        | _ -> raise Impos)
               | _ -> 
                   let msg = spr "Expected a type function, but got a type of kind %s" (Pretty.strKind t2.sort) in 
                     raise (Error(msg, t2.p)))
              
      | Typ_app(t1, ({v=Typ_unknown; sort=_; p=_} as t2)) -> 
          let t1', k1 = kinding env t1 in
            (match k1(* .u *)with    
               | Kind_tcon(Some bvd, k, k') ->   (* Q: When is this path exercised? *)
                   let t2' = TypeRelations.new_uvar env k t2.p in
                   let k' = substitute_kind k' bvd t2' in
                     Typ_app(t1', t2'), k'
               | _ -> raise (Err "Missing type argument"))
              
      | Typ_app (t1, t2) -> 
          let t1, k1 = kinding env t1 in
            (match k1(* .u *)with 
               | Kind_tcon (aopt, k, k') -> 
                   let env = set_expected_kind env k in 
                   let t2, k2 = kinding env t2 in
                     (match aopt with 
                        | None -> Typ_app(t1, t2), k'                
                        | Some a -> let k' = substitute_kind k' a t2 in Typ_app(t1, t2), k')
               | _ -> 
                   let msg = spr "Expected a type-to-type constructor, but got a type (%s) of kind %s"
                     (Pretty.strTyp t1)
                     (Pretty.strKind k1) in
                     raise (Error(msg, top.p)))

      | Typ_dep (t, e) -> 
          let err t_e k = 
            let msg = 
              Printf.sprintf 
                "Expected a dependent-type constructor of kind %s -> k, but got a type of kind %s"
                (Pretty.strTyp t_e) (Pretty.strKind k) in
              raise (Error(msg, top.p)) in
            (if not (is_value e) then
               let msg = spr "Type-level terms mush be syntactic values or applications of logic functions; got %s" (Pretty.strExp e) in
                 raise (Error (msg, top.p)));
            let t, k = kinding env t in
            let t, k = TypeRelations.instantiate_kind env t k in
              (match k(* .u *)with 
                 | Kind_dcon (xopt, t', k') -> 
                     let env, _ = clear_expected_typ env in 
                       (* TRYING A HEURISTIC HERE. Type-level uvar's should be unified with unrefined types *)
                       (* First synth a type  t_e for e; 
                          see if the unrefined version of t_e is unificable with t';
                          if so, unify (unrefine t_e) with t' and and check e at t'
                          Otherwise check e at t' *)
                     let e', t_e, used_affines = typing env e in 
                     let t_e' = unrefine t_e in 
                     let _ = match TypeRelations.instantiable (set_range env t_e'.p) [] [] t' t_e' with
                       | Some (s, []) -> unify_subst_vars s              
                       | _ ->  () in
                     let e, t_e, _used_affines = typing (set_expected_typ env t') e in (* Don't care about affine usages in types *)
                     let k' = match xopt with 
                       | None -> k'
                       | Some x -> substitute_kind_exp k' x e in 
                       Typ_dep(t, e), k'
                 | _ -> 
                     let e, t_e, _ = typing env e in
                     let msg = 
                       Printf.sprintf 
                         "Expected a dependent-type constructor of kind %s -> k, but got a type of kind %s"
                         (Pretty.strTyp t_e) (Pretty.strKind k) in
                       raise (Error(msg, top.p)))
                
      | Typ_affine t -> 
          let t, k = kinding env t in
            (match k(* .u *)with
                 Kind_star -> Typ_affine t, Kind_affine
               | _ -> 
                   let msg = 
                     Printf.sprintf 
                       "The affine qualifier can only be applied to *-kinded types\n\
                     The type %s has %s-kind"
                       (Pretty.strTyp t) (Pretty.strKind k) in
                     raise (Err msg))

      | Typ_record(fn_t_l, topt) -> 
          let fn_t_e_l = fn_t_l |> List.map 
              (fun (fn,t) -> 
                 let t', k' = kinding env t in 
                   match k'(* .u *)with 
                     | Kind_star | Kind_prop | Kind_affine -> (fn, t', None)
                     | _ -> 
                         let msg = spr "Record fields must have ground types; %s has kind %s" 
                           (Sugar.text_of_lid fn) (Pretty.strKind k') in
                           raise (Err msg)) in 
            
          let rlid, targs, phantom, typ, fn_t_e_l = 
            typing_record top.p env fn_t_e_l in

          let _ = match topt with 
            | None -> ()
            | Some typ' -> 
                let typ', _ = kinding env typ' in
                  match TypeRelations.equivalent_with_evidence (set_range env typ'.p) typ typ' with
                    | Some [] -> ()
                    | _ ->
                        let msg = spr "Invalid record typing. Expected type %s got type %s"
                          (Pretty.strTyp typ) (Pretty.strTyp typ') in
                          raise (Err msg) in
            
          let fn_t_l = fn_t_e_l |> List.map (fun (fn,t,_) -> fn,t) in
            Typ_record (fn_t_l, Some typ), typ.sort

      | Typ_uvar (uv,k) as t -> 
          (match Unionfind.find uv with
               Uvar _ -> t, k
             | Delayed t
             | Fixed t -> 
                 let env = set_expected_kind env k in
                 let t', k' = kinding env t in
                   t'.v, k')

      | Typ_lam (x, t1, t2) -> 
          let dlist = [(Some x, t1, check_SAP); (None,t2,fun _ _ -> ())] in
            (match kinding_dep_list env dlist with 
               | [(Some x, t1', k1); (_, t2', k2)] -> 
                   let k = Kind_dcon(Some x, t1', k2) in
                   let k = well_formed_kind top.p env k in 
                     Typ_lam(x, t1', t2'), k
               | _ -> raise Impos)

      | Typ_tlam (a, k, t) -> 
          let k, b = ok_kind top.p env k in 
          let binding = Binding_typ(a.realname, k) in 
          let env' = push_local_binding env binding in 
          let t, kt = kinding env' t in 
          let kk = Kind_tcon(Some a, k, kt) in 
          let kk = well_formed_kind top.p env kk in
            Typ_tlam(a, k, t), kk

      | Typ_ascribed(t', k) ->
          let k, b = ok_kind top.p env k in
          let env = set_expected_kind env k in
          let t', _ = kinding env t' in
            Typ_ascribed(t', k), k

      | Typ_meta(Meta_pattern(t, ps)) -> 
        let t, k = kinding env t in 
        let env,_ = clear_expected_kind env in 
        let ps = (ps |> List.map (function 
          | Inl t -> Inl (fst (kinding env t))
          | Inr v -> let v, _, _ = typing env v in Inr v)) in 
        Typ_meta(Meta_pattern(t, ps)), k

      | Typ_meta(Meta_named(s,t)) -> 
          let t, k = kinding env t in 
            Typ_meta(Meta_named(s, t)), k
              
      | Typ_meta(Meta_alpha t) -> 
          do_kinding env (alpha_convert t)

      | Typ_meta (Meta_cases tl) ->
          let tl, kl = List.unzip (List.map (kinding env) tl) in 
            Typ_meta(Meta_cases tl), List.hd kl
              
      | Typ_unknown -> 
          let t = TypeRelations.new_uvar env Kind_star top.p in
            t.v, Kind_star 

      | _ -> failwith (spr "Unexpected type %s\n" (Pretty.strTyp top)) in
  let env = clear_current_value env in 
  let env, expected_kind = clear_expected_kind env in
  let env = set_kind_level env in 
  let typ', kind = 
    if !Options.monadic && env.skip_kinding
    then match top.sort(* .u *)with 
      | Kind_unknown -> do_kinding env top 
      | _ -> (top.v, top.sort)
    else do_kinding env top in
  let typ = twithinfo typ' kind top.p in 
    match kind(* .u *)with 
      | Kind_unknown -> let msg = spr "Got a type with an unknown kind %s\n" (Pretty.strTyp typ) in
          raise (Err msg)
      | _ -> 
          let _ =  match expected_kind with 
            | None -> ()
            | Some ek -> check_kind_convertible typ.p (fun () -> spr "Type %s" (Pretty.strTyp typ)) env kind ek in
            whnf typ, kind        
              
and instantiate_typ env typ t_actuals : (typ * list<typ>) = 
  let check_kind actual formal_kind = 
    let env = set_expected_kind env formal_kind in 
    let (actual', kind) = kinding env actual in
      actual' in
  let t, insts = match t_actuals with 
    | [] -> TypeRelations.instantiate_typ env typ 
    | _  -> TypeRelations.instantiate_typ_with_actuals env typ t_actuals check_kind in
    t, List.unzip insts |> snd 

and insert_tyapps p env exp t = 
  let t_inst, targs = instantiate_typ env t [] in
    match targs with
      | [] -> exp, t
      | _ -> 
          let tapp = List.fold_left 
            (fun lhs arg -> 
               let e = Exp_tapp (lhs, arg) in
               let t_e = match lhs.sort.v with
                 | Typ_univ(bvd,_,[],tret) -> 
                     substitute tret bvd arg
                 | _ -> (pr "Expected polymorphic type; got %s" (Pretty.strTyp lhs.sort); raise Impos) in
                 ewithinfo e t_e p) exp targs in
            tapp, t_inst

and typing_constraints env formulas : (list<typ> * env) = 
  let env' = set_expected_kind env Kind_erasable in 
  let formulas = List.map (fun f -> let f, _ = kinding env' f in f) formulas in
  let env = List.fold_left (fun env f -> 
                              let uf, x = AbsynUtils.mkRefinedUnit f in 
                              let env = push_local_binding env (Binding_var(x, uf)) in
                                env) env formulas in 
    formulas, env
      
and typing env top_exp : (exp*typ*list<bvvar>) =
  let rec do_typing env = function 
    | Exp_bvar bv -> 
        let t = lookup_bvar env bv in  (* TODO: freshen typ vars and introduce a type application here *)
        let bv = setsort bv t in
        let bvar = Exp_bvar bv in
        let used_affines = match t.sort(* .u *)with 
          | Kind_affine when not (is_kind_level env) -> [bv] (* Don't care about affine usages at the kind level *)
          | _ -> [] in
          if expect_tyapps env 
          then bvar, t, used_affines
          else (* introduce tyapps *)
            let bvar = ewithinfo bvar t top_exp.p in
            let tapp, t_inst = insert_tyapps top_exp.p env bvar t in 
              tapp.v, t_inst, used_affines 

    | Exp_fvar (fv, eref) -> (* TODO: add affine variable tracking *)
        if Tcenv.is_datacon env fv then
          let e, t, x = typing env (ewithpos (Exp_constr_app(fv, [], [], []))  top_exp.p) in
            e.v, t, x
        else
          let t = match lookup_fvar env fv with
              None -> raise (Err ("Variable not found: "^(Sugar.text_of_lid fv.v)))
            | Some t -> t in (* TODO: freshen typ vars and introduce type applications here *)
          let fv' = setsort fv t in
          let fvar = Exp_fvar(fv',eref) in
          let used_affines = match kinding env t with 
            | _, Kind_affine -> 
                let msg = 
                  Printf.sprintf "Free variable %s cannot have an affine type"  (Pretty.strExp (ewithpos fvar dummyRange)) in
                  raise (Err msg)
            | _ -> [] in
            if expect_tyapps env 
            then fvar, t, used_affines
            else
              let fvar = ewithinfo fvar t top_exp.p in
              let tapp, t_inst = insert_tyapps top_exp.p env fvar t in 
                tapp.v, t_inst, used_affines
                  
    | Exp_constant c -> 
        let t = typing_const env c in 
          Exp_constant c, t, []

    | Exp_constr_app (cvar, [], [], [e1;e2]) when Sugar.lid_equals cvar.v Const.tuple_UU_lid -> 
        (* special case: need to figure out the suitable variant of the tuple constructor
           based on the types of the arguments. Desugar just inserts tuple_UU_lid uniformly *)
        (* This case is also responsible for packing a dependent tuple *)
        let env, topt = clear_expected_typ env in 
        let packed_t, (e1, e2), (t1, t2), used_affines = match tensor_opt topt (Tcutil.reduce_typ_delta_beta env) with 
          | Some ({v=Typ_dtuple([(x1,t1);(_, t2)]); sort=_; p=_} as packed_t)-> 
              let env = set_expected_typ env t1 in
              let e1, t1, used_affines_1 = typing env e1 in
              let env' = match x1 with 
                | None -> set_expected_typ env t2
                | Some x -> 
                    if (is_value e1) then  (* pack dep tuple *)
                      let t2 = substitute_exp t2 x e1 in
                        set_expected_typ env t2
                    else env in
              let e2, t2, used_affines_2 = typing env' e2 in
                Some packed_t, (e1, e2), (t1, t2), (used_affines_1@used_affines_2)
          | _ -> 
              let e1, t1, used_affines_1 = typing env e1 in
              let e2, t2, used_affines_2 = typing env e2 in
                None, (e1, e2), (t1, t2), (used_affines_1@used_affines_2) in
        let _ = disjoint_affine_usages used_affines in
        let cname = Const.tuple_data_lid t1.sort t2.sort in 
        let ctyp = lookup_lid env cname in
        let cvar = fvwithsort cname ctyp in
        let inst_ctyp, _ = instantiate_typ env ctyp [t1;t2] in
        let constr_app_typ = List.fold_left 
          (fun out arg -> match out.v with 
             | Typ_fun (None, arg_typ, ret_typ) -> ret_typ
             | _ -> raise Impos) inst_ctyp [e1;e2] in
        let _ = kinding env constr_app_typ in
        let capp = Exp_constr_app(cvar, [t1;t2], [], [e1;e2]) in
          (match packed_t with 
               None -> capp, constr_app_typ, used_affines
             | Some t -> 
                 let capp = (ewithinfo capp constr_app_typ top_exp.p) in
                   Exp_ascribed(capp,t,[]), t, used_affines)
            
    | Exp_constr_app (cname, targs, _, vargs) ->
        (* TODO: Add module name check on cname *)
        let ctyp, tps = match lookup_fvar_with_params env cname with
            None -> raise (Err ("Variable not found: "^(Sugar.text_of_lid cname.v)))
          | Some t -> 
              t in (* TODO: constructors may have extraneous type and value params *)
        let inst_ctyp, targs' = instantiate_typ env ctyp targs in  (* reconstructs targs if targs = [] *)
        let env, topt = clear_expected_typ env in
        let inst_ctyp, subst = match topt, tps with
          (* | None, [] -> inst_ctyp, [] *)
          | None, [] -> inst_ctyp, []
          | None, _ -> let msg = spr "Cannot infer term indices for constructed type %s; a type annotation may help" (Pretty.strTyp ctyp) in
              raise (Error (msg, top_exp.p))
          | Some et, _ -> 
            match Tcenv.expand_typ_until_pred env et (function {v=Typ_app _} | {v=Typ_dep _} -> true | _ -> false) with
              | Some _ -> TypeRelations.try_instantiate_final_typ env tps inst_ctyp et 
              | _ -> inst_ctyp, [] in
        let vargs_rev, result_typ, used_affines = List.fold_left 
          (fun (arglist, ctyp, used_affines) arg -> match ctyp.v with 
               Typ_fun (bvd_opt, arg_typ, ret_typ) -> 
                 let env' = set_expected_typ env arg_typ in 
                 let arg', t', used_affines' = typing env' arg in 
                 let ret_typ' = match bvd_opt with 
                     None -> ret_typ
                   | Some bvd -> substitute_exp ret_typ bvd arg' in
                 let ret_typ', _ = kinding env {ret_typ' with p=top_exp.p} in (* ensure non-value expressions don't escape into types *)
                   (arg'::arglist, ret_typ', used_affines'@used_affines)
             | _ -> 
                 let msg = spr "Too many arguments to constructor %s, (e.g., %s is extra)" (Pretty.str_of_lident cname.v) (Pretty.strExp arg) in
                   raise (Error(msg, top_exp.p))) ([], inst_ctyp, []) vargs in
        let _ = match result_typ.v with 
            Typ_fun _ 
          | Typ_univ _ -> 
              raise (Error (spr "All data constructors must be fully-applied\n%s" (Pretty.strExp top_exp), top_exp.p))
          | _ -> () in
        let _ = disjoint_affine_usages used_affines in
        let ctyp = List.fold_left (fun ctyp (bvd, e) -> 
                                     substitute_exp ctyp bvd e) ctyp subst in
        let cname' = setsort cname ctyp in
        let phantomVargs = List.map (function 
                                       | Tparam_term(bvd, t) -> 
                                           (match Util.findOpt (fun (x, _) -> Absyn.bvd_eq x bvd) subst with 
                                              | None -> raise Impos
                                              | Some (_, y) -> y)
                                       |  _ -> raise Impos) tps in
        let vargs' = List.rev vargs_rev in
          Exp_constr_app(cname', targs', phantomVargs, vargs'), result_typ, used_affines

    | Exp_primop(op, args) -> 
        (match lookup_operator env op with
           | None -> raise (Err ("Unknown operator: "^op.idText))
           | Some t -> 
               let args_rev, result_typ, used_affines = List.fold_left 
                 (fun (args, t, affines) arg -> match t.v with 
                      Typ_fun(xopt, t_arg, t_ret) -> 
                        let env = set_expected_typ env t_arg in
                        let arg, t', used_affines = typing env arg in
                        let t_ret = match xopt with
                          | None -> t_ret
                          | Some x -> substitute_exp t_ret x arg in
                          arg::args, t_ret, used_affines@affines
                    | _ -> 
                        let msg = spr "Too many arguments to operator %s, (e.g., %s is extra)" op.idText (Pretty.strExp arg) in
                          raise (Err msg)) ([], t, []) args in
               let _ = disjoint_affine_usages used_affines in
               let _ = match result_typ.v with 
                 | Typ_fun _ -> 
                     raise (Error (spr "All operators must be fully-applied\n%s" (Pretty.strExp top_exp), top_exp.p))
                 | _ -> () in
                 Exp_primop(op, List.rev args_rev), result_typ, used_affines)
          
    | Exp_abs (bvd, t, body) -> 
        let env, topt = clear_expected_typ env in
        let env, t_formal, k_t = match t.v with 
          | Typ_unknown -> 
              (match topt with
                 | Some ({v=Typ_fun(bvdopt, t', bodyt); sort=_; p=_} as tt) -> 
                     let formalName = bvd_to_exp bvd t' in
                     let tret = open_typ_with_exp tt formalName in
                     let env = set_expected_typ env tret in
                       env, t', t'.sort 
                 | _ -> 
                     let t' = TypeRelations.new_uvar env Kind_star t.p in
                       env, t', Kind_star)
          | _ -> 
              let (t', k) = kinding env t in
                match k(* .u *)with 
                  | Kind_star 
                  | Kind_affine 
                  | Kind_prop -> env, t', k
                      (* (match topt with  *)
                      (*    | Some ({v=Typ_fun(_, t'', _)} as tt) ->  *)
                      (*        (match TypeRelations.equivalent_with_evidence (set_range env t'.p) t' t'' with *)
                      (*           | Some [] ->  *)
                      (*               let formalName = bvd_to_exp bvd t' in *)
                      (*               let tret = open_typ_with_exp tt formalName in *)
                      (*               let env = set_expected_typ env tret in *)
                      (*                 env, t', t'.sort  *)
                      (*           | _ -> raise (Error(spr "Annotated formal type %s does not match expected type %s" *)
                      (*                                 (Pretty.strTyp t') (Pretty.strTyp t''), top_exp.p))) *)
                      (*    | _ -> env, t', t'.sort) *)
                  | _ -> 
                      let msg = 
                        Printf.sprintf 
                          ("Bound term variables must always have {*, A, P}-kinded types.\n \
                          The formal parameter of type %s has %s kind")
                          (Pretty.strTyp t') (Pretty.strKind k) in
                        raise (Error (msg, top_exp.p)) in

        let binding = Binding_var (bvd.realname, t_formal) in
        let env' = push_local_binding env binding in
        let body', t_body, used_affines = typing env' body in
        let mk_affine t = match t.v with 
            Typ_affine _ -> t
          | _ -> twithsort (Typ_affine t) Kind_affine in
        let t_body' = match used_affines with 
          | [] -> t_body (* no constraints on body if it didn't use any affine assumptions *)
          | _ -> (* body captured affine assumptions, so it should be given an affine type *)
              let (t_body', k') = kinding env' t_body in
                match k'(* .u *)with 
                  | Kind_star when is_closure_typ env' t_body' -> mk_affine t_body' 
                  | _ -> t_body' in
        let typ = twithsort (Typ_fun (Some bvd, t_formal, t_body')) Kind_star in
        let exp' = Exp_abs (bvd, t_formal, body') in
        let minus = bvd_to_bvar_s bvd t_formal in
        let used_affines = subtract used_affines [minus] in
          exp', typ, used_affines
            
    | Exp_tabs (bvd, k, formulas, body) ->
        let binding = 
          if Tcutil.kind_abstractable top_exp.p k then 
            let k = well_formed_kind top_exp.p env k in
              Binding_typ (bvd.realname, k)
          else raise (Error ((spr "Abstraction over types of kind %s is not permitted" (Pretty.strKind k)), top_exp.p)) in
        let env' = push_local_binding env binding in
        let formulas, env' = typing_constraints env' formulas in 
        let env', topt = clear_expected_typ env' in
        let env' = match topt with
          | None -> env'
          | Some ({v=Typ_univ(bvd', k', _, tbody);sort=_;p=_}) -> env' (*TODO: propagate type annotation to body  *)
          | _ -> env' in
        let body', t_body, used_affines = typing env' body in
        let t_body = match used_affines with
            [] -> t_body 
          | _ -> 
              let (t_body', k') = kinding env' t_body in
                match k'(* .u *)with 
                  | Kind_star when is_closure_typ env' t_body' -> twithsort (Typ_affine t_body') Kind_affine
                  | _ -> t_body' in
        let res_exp = Exp_tabs (bvd, k, formulas, body') in
        let res_typ = twithsort (Typ_univ(bvd, k, formulas, t_body)) Kind_star in
          res_exp, res_typ, used_affines
            
    | Exp_app (e1, e2) -> (* TODO: signal for e1 to include type insantiations *)
        let env, expected_ret_typ = clear_expected_typ env in
        let e1', t1, used_affines_1 = typing env e1 in
        let t1 = Tcutil.reduce_typ_delta_beta env (unrefine t1) in 
        let e1', t1 = 
          if expect_tyapps env then e1', t1
          else insert_tyapps e1'.p env e1' t1 in 
        let tformal = match (compress t1).v with 
          | Typ_fun (_, tformal, _) 
          | Typ_affine ({v=Typ_fun(_, tformal, _)}) -> 
              let _ = match expected_ret_typ with
                | None -> ()
                | Some et ->
                    let _, s = TypeRelations.try_instantiate_final_typ (clear_current_value env) [] t1 et in
                      match s with
                        | [] -> ()
                        | _ -> raise Impos in
                tformal
          | _ -> 
              let tformal = TypeRelations.new_uvar env Kind_star e1.p in
              let tret = TypeRelations.new_uvar env Kind_star e1.p in
              let tt = twithsort (Typ_fun(None, tformal, tret)) Kind_star in
                match TypeRelations.convertible_ev (set_range env e1.p)  t1 tt with
                  | Some (subst, []) -> 
                      let _ = unify_subst_vars subst in  (* this has a side effect; changes uvar pointers in Unionfind *) 
                        tformal
                  | _ ->
                      let msg = Printf.sprintf "Expected a function typed term; got a term %s of type %s" (Pretty.strExp e1') (Pretty.strTyp t1) in
                        raise (Error (msg, e1'.p)) in
        let env' = set_expected_typ env tformal in
        let e2' = Absyn.ewithinfo (e2.v) (e2.sort) (top_exp.p) in
        let e2', t2', used_affines_2 = typing env' e2' in
        let used_affines = used_affines_1@used_affines_2 in
        let _ = disjoint_affine_usages used_affines in
        let tret = open_typ_with_exp t1 e2' in
        let typ_res, k = kinding env tret in (* Non-value expressions do not escape into types *)
        let exp_res = Exp_app(e1', e2') in
          exp_res, typ_res, used_affines 
            
    | Exp_tapp (e, targ) -> 
        let env, expected_ret_typ = clear_expected_typ env in (* TODO: propagate expected type? *)
        let e', t_e, used_affines = typing (set_expect_tyapps env) e in
        let targ', res_typ = match t_e.v with 
          | Typ_univ (bvd, k, formulas, tt) -> 
              let env = set_expected_kind env k in
              let targ', k' = kinding env targ in
              let formulas = List.map (fun f -> substitute f bvd targ') formulas in 
                if TypeRelations.formula_entailment (set_range env e.p) formulas 
                then targ', substitute tt bvd targ'
                else raise (Error("Failed to prove type instantiation constraints", top_exp.p))
          | _ -> 
              let msg = 
                Printf.sprintf 
                  "Type application expected a polymorphic function on the LHS. Got a term of type %s"
                  (Pretty.strTyp t_e) in
                raise (Error (msg, top_exp.p)) in
        let res_exp = Exp_tapp (e', targ') in
          res_exp, res_typ, used_affines

    | Exp_ascribed (e, t, ev) -> 
        let t', k = kinding env t in
        let env' = set_expected_typ env t' in 
        let e', res_t, used_affines = typing env' e in
        let res_e = match e'.v with (* collapse multiple ascriptions *)
          | Exp_ascribed _ -> e'.v
          | _ -> Exp_ascribed (e', t', []) in
          res_e, res_t, used_affines
            
    | Exp_match (e, eqns, def) -> 
        let env', _ = clear_expected_typ env in
        let e', t', used_affines_e = typing env' e in
        let check_branch_kind t_branch = match t_branch.sort(* .u *)with
          | Kind_prop -> 
              (match t'.sort(* .u *)with 
                 | Kind_prop -> () 
                 | _ -> raise (Error ("Cross-universe elimination on P-kinded types is not allowed", e.p)))
          | _ -> () in
        let expanded_t' = Tcutil.reduce_typ_delta_beta env t' in
        let def', t_def, used_affines_def = typing env def in
        let env = match expected_typ env with 
          | None -> 
              (* let _ = pr "Typing branch with expected type: %s\n" (Pretty.strTyp t_def) in  *)
              set_expected_typ env t_def 
          | Some texp ->
              (* let _ = pr "Typing branch with expected type: %s\n" (Pretty.strTyp texp) in  *)
              env in
        let typed_eqns, used_affines_l = List.unzip <|
            List.map
              (fun (pi, branchi) -> 
                 let pi', e_pi, bindings = typing_pat top_exp.p (set_expected_typ env expanded_t') pi in
                 let env_true, smapv, smapt =
                   List.fold_left (fun (env, smapv, smapt) binding ->
                                     let env = push_local_binding env binding in
                                       match binding with
                                         | Binding_var(x,t) ->
                                             let xbvd = mkbvd (x,x) in
                                             let vx = bvd_to_exp xbvd (twithpos Typ_unknown dummyRange) in
                                             let vx = ewithpos (Exp_ascribed(vx, t, [])) (x.idRange) in 
                                               env, (mkbvd(x,x), vx)::smapv, smapt
                                         | Binding_typ(a,k) ->
                                             let abvd = mkbvd (a,a) in 
                                             let ta = bvd_to_typ abvd Kind_unknown in
                                             let ta = twithpos (Typ_ascribed(ta, k)) a.idRange in 
                                               env, smapv, (abvd, ta)::smapt
                                         | _ -> env, smapv, smapt)
                     (env, [], []) bindings in
                 let branchi = substitute_exp_val_l branchi smapv in
                 let branchi = substitute_exp_typ_l branchi smapt in
                   (* let env_true = List.fold_left (fun env binding -> push_local_binding env binding) env bindings in *)
                 let env_true = push_local_binding env_true (Binding_match(e', e_pi)) in
                 let branchi', tbranchi, used_affines_i = typing env_true branchi in
                 let _ = List.iter (function 
                                      | Binding_var(x,t) -> 
                                          if is_xvar_free (mkbvd(x,x)) tbranchi
                                          then raise (Error (spr "Pattern-bound variable %s escapes its scope; insert an explicit type annotation" x.idText, 
                                                             branchi.p))
                                      | Binding_typ(a,k) -> 
                                          if is_tvar_free (mkbvd(a,a)) tbranchi
                                          then raise (Error (spr "Pattern-bound type-variable %s escapes its scope; insert an explicit type annotation" a.idText, 
                                                             branchi.p))) in 
                   (* let _ = pr "Computed type for branch: %s\n" (Pretty.strTyp tbranchi) in  *)
                 let _ = check_branch_kind tbranchi in
                 let used_affines_i = subtract used_affines_i (match pi' with 
                                                                 | Pat_variant (_, _, _, bvars, __GADT_FLAG_IGNORED) -> bvars (* NIK: Ignoring flag!! *)
                                                                 | _ -> []) in
                 let evidence = 
                   List.filter (function | Binding_match _ | Binding_tmatch _ -> true | _ -> false) bindings |> 
                       List.map (function Binding_tmatch(t1,t2) -> Inl(twithsort (Typ_btvar t1) t1.sort,t2) | Binding_match(e1, e2) -> Inr(e1,e2)) in
                 let branchi' = ascribe branchi' tbranchi evidence in
                   (* let _ = pr "Ascribed branch: %s\n" (Pretty.strExp branchi') in  *)
                   (pi', branchi'), used_affines_i) eqns in
        let used_affines_branches = List.fold_left union used_affines_def used_affines_l in
        let _ = disjoint_affine_usages (used_affines_e@used_affines_branches) in
        let res_exp = Exp_match(e', typed_eqns, def') in
          res_exp, t_def, union used_affines_e used_affines_branches
            
    | Exp_cond (e, e1, e2) -> 
        let e', t_e, used_affines_e = typing (set_expected_typ env bool_typ) e in
        let env_true, env_false = 
          if (is_value e') then 
            let b1 = Binding_match (e', Const.exp_true_bool) in
            let b2 = Binding_match (e', Const.exp_false_bool) in
              push_local_binding env b1, push_local_binding env b2 
          else env, env in
        let e1', t_branch_then, used_affines_1 = typing env_true e1 in
        let e2', t_branch_else, used_affines_2 = typing (set_expected_typ env_false t_branch_then) e2 in
        let e1', e2', t_branch = e1', e2', t_branch_then in 
          (*           match TypeRelations.convertible_ev env_false t_branch_else t_branch_then with  *)
          (*             | None ->  *)
          (*                 (match TypeRelations.convertible_ev env_true t_branch_then t_branch_else with  *)
          (*                    | None -> raise (Error ("Unable to compute type of conditional; provide an annotation", top_exp.p)) *)
          (*                    | Some (subst, ev) ->  *)
          (*                        let _ = unify_subst_vars subst in  (\* this has a side effect; changes uvar pointers in Unionfind *\)  *)
          (*                        let e1' = ascribe e1' t_branch_else ev in *)
          (*                          e1', e2', t_branch_else) *)
          (*             | Some (subst, ev) ->  *)
          (*                 let _ = unify_subst_vars subst in  (\* this has a side effect; changes uvar pointers in Unionfind *\)  *)
          (*                 let e2' = ascribe e2' t_branch_then ev in *)
          (*                   e1', e2', t_branch_then in  *)
        let used_affines = used_affines_e @ (union used_affines_1 used_affines_2) in
        let _ = disjoint_affine_usages used_affines in        
        let res_exp = Exp_cond(e', e1', e2') in
        let res_typ = t_branch in
          res_exp, res_typ, used_affines
            
    | Exp_let (isRec, bindings, body) when isRec=false -> 
        (match bindings with 
           | [(bvd, {v=Typ_unknown;sort=_;p=pos}, e)] -> 
               let env_orig = env in
               let env', _orig_expected_typ = clear_expected_typ env_orig in
               let e', t', used_affines_e = typing env' e in
               let forall_t', Lambda_e' = generalize env' t' e' in
               let binding = Binding_var (bvd.realname, forall_t') in
               let env_orig' = push_local_binding env_orig binding in 
               let bvv = bvwithsort bvd forall_t' in
               let bvexp = ewithsort (Exp_bvar bvv) forall_t' in
               let rec is_basic_typ t = match t.v with 
                 | Typ_fun _ 
                 | Typ_univ _ -> false
                 | Typ_refine(_, t, _, _) 
                 | Typ_ascribed(t, _) -> is_basic_typ t
                 | _ -> true in 
               let env_orig' = 
                 if is_value e' && is_basic_typ e'.sort 
                 then push_local_binding env_orig' (Binding_match(bvexp, e')) 
                 else env_orig' in
               let body', t_body, used_affines_body = typing env_orig' body in 
               (* Check that let-bound variable does not escape its scope *)
               if is_xvar_free bvd t_body then 
                 raise (Error (spr "Let-bound variable %s escapes its scope in type %s; insert an explicit type annotation. (expected type %s)" 
                                 (pp_name bvd).idText (Pretty.strTyp t_body) (match _orig_expected_typ with None -> "none" | Some t -> Pretty.strTyp t), 
                               (pp_name bvd).idRange));
               let used_affines = used_affines_e@(subtract used_affines_body [bvv]) in
               let _ = disjoint_affine_usages used_affines in
               let exp' = Exp_let(isRec, [(bvd, forall_t', Lambda_e')], body') in
               let _ = match t_body.sort(* .u *), forall_t'.sort(* .u *)with 
                 | Kind_prop, Kind_prop -> ()
                 | Kind_prop, _ -> 
                     raise (Error ("If body of let is in P-kind, then abstracted term must be in P-kind", (pp_name bvd).idRange))
                 | _ -> () in
                 exp', t_body, used_affines

           | [(bvd, t, e)] -> 
               let env_orig = env in
               let env, _ = clear_expected_typ env in
               let t, k = kinding env t in
               let env = set_expected_typ env t  in
               let e, _, used_affines_e = typing env e in
               let env' = push_local_binding env_orig (Binding_var (bvd.realname, t)) in
               let bvv = bvwithsort bvd t in
               let bvexp = ewithsort (Exp_bvar bvv) t in
               let env' = if is_value e then push_local_binding env' (Binding_match(bvexp, e)) else env' in
               let body, t_body, used_affines_body = typing env' body in 
               (* Check that let-bound variable does not escape its scope *)
               if is_xvar_free bvd t_body then 
                 raise (Error (spr "Let-bound variable %s escapes its scope in %s; insert an explicit type annotation." 
                                 (pp_name bvd).idText (Pretty.strTyp t_body), 
                               (pp_name bvd).idRange)); 
        let used_affines = used_affines_e@(subtract used_affines_body [bvv]) in
               let _ = disjoint_affine_usages used_affines in
               let exp' = Exp_let(isRec, [(bvd, t, e)], body) in
               let _ = match t_body.sort(* .u *), t.sort(* .u *)with 
                 | Kind_prop, Kind_prop -> ()
                 | Kind_prop, _ -> 
                     raise (Error("If body of let is in P-kind, then abstracted term must be in P-kind", (pp_name bvd).idRange)) 
                 | _ -> () in
                 exp', t_body, used_affines
                   
           | _ -> raise (NYI "Nested recursive let-bindings"))

    | Exp_let (isRec, bindings, body) when isRec -> 
        let env',bindings_rev = bindings |> 
            ((env, []) |> List.fold_left 
                 (fun (env, out) (bvd,t,e) -> 
                    let t, e = match t.v with 
                      | Typ_unknown -> (TypeRelations.new_uvar env Kind_star e.p), e
                      | _ -> t, e in 
                    let t, k = kinding env t in
                      match k(* .u *)with
                        | Kind_star -> 
                            let binding = Binding_var (bvd.realname, t) in
                            let env' = push_local_binding env binding in
                              env', (bvd,t,e)::out
                        | _ ->
                            raise (Err (spr "Recursive functions must have *-kinded types; got %s" (Pretty.strKind k))))) in
        let bindings' =  List.fold_left 
          (fun out (bvd,t,exp) -> 
             let env' = set_expected_typ env' t in
             let exp', t_exp, used_affines = typing env' exp in
               match used_affines with 
                 | [] -> (bvd, t, exp')::out
                 | _ -> raise (Error ("Recursive functions cannot use affine assumptions", exp'.p))) [] bindings_rev in
        let body', t_body, used_affines = typing env' body in
        let res_exp = Exp_let(isRec, bindings', body') in
        let res_typ = t_body in
          res_exp, res_typ, used_affines        

    | Exp_recd (_, _, _, (((fn,e)::tl) as fn_e_l)) -> 
        let env, _ = clear_expected_typ env in
        let used_affines, fn_t_e_l_rev = fn_e_l |> List.fold_left
          (fun (affines, fn_t_e_l) (fn,e) -> 
             let e', t', used_affines = typing env e in
               used_affines@affines, (fn, t', Some e')::fn_t_e_l) ([],[]) in
        let recd_lident, targs, phantoms, result_typ, fn_t_e_l = 
          typing_record top_exp.p env (fn_t_e_l_rev |> List.rev) in
        let fn_e_l = fn_t_e_l |> List.map (fun (fn, _, Some e) -> (fn, e)) in
        let _ = disjoint_affine_usages used_affines in
          Exp_recd(Some recd_lident, targs, phantoms, fn_e_l), result_typ, used_affines 
            
    | Exp_proj (e, fn) when Sugar.lid_equals fn Const.tuple_proj_one -> 
        let env, topt = clear_expected_typ env in
        let e', t, used_affines = typing env e in (* TODO: instead of synthesizing a type for e, can we check it? *)
        let t' = whnf <| expand_typ env t in 
        let err () = 
          let msg = spr "Expected a tuple expression; got %s" 
            (Pretty.strTyp t') in
            raise (Error(msg, top_exp.p)) in
        let fieldTyp =  match t'.v with 
          | Typ_dtuple [(_,t1);_] -> t1
          | _ -> err() in
          Exp_proj(e', fn), fieldTyp, used_affines                    
        
    | Exp_proj (e, fn) when Sugar.lid_equals fn Const.tuple_proj_two -> 
        let env, topt = clear_expected_typ env in
        let e', t, used_affines = typing env e in (* TODO: instead of synthesizing a type for e, can we check it? *)
        let t' = expand_typ env t in 
        let err () = 
          let msg = spr "Expected a non-dependent tuple expression; got %s" 
            (Pretty.strTyp t') in
            raise (Error(msg, top_exp.p)) in
        let fieldTyp =  match t'.v with 
          | Typ_dtuple [(_,t1);(_,t2)] -> 
              let _ = 
                try 
                  kinding env t2                 (* check to make sure that t2 is not dependent on t1 *)
                with 
                    _ -> err () in
                t2
          | _ -> err() in
          Exp_proj(e', fn), fieldTyp, used_affines
            
    | Exp_proj (e, fn) -> 
        let env, topt = clear_expected_typ env in
        let (_, t, tps, _) = Tcenv.lookup_record_typ env fn in
        let expected_t = match tps with 
          | [] -> Some t
          | _ -> 
              let rec aux args = function 
                | [] -> Some (List.fold_right (fun arg t -> 
                                                 twithsort (Typ_app(t, arg)) (open_kind t.sort arg)) args t)
                | Tparam_typ(a,k)::tl -> 
                    let arg = TypeRelations.new_uvar env k top_exp.p in 
                      aux (arg::args) tl
                        
                | Tparam_term _::_ -> None in 
                aux [] tps in 
        let e', t, used_affines = typing env e in (* synthesize a type for e first *)
        let t = match expected_t with 
          | None -> t
          | Some t' -> check_typ_convertible env top_exp t t'; t' in
        let fieldTyp = Tcutil.lookup_field_in_record_typ e.p env fn t in
        let fieldTyp = if is_value e' && not (is_kind_level env) then 
          let eqT = Tcutil.eqT_of_typ env fieldTyp in 
          let id = genident None in
          let bvd = mkbvd(id, id) in
          let eqf = Wt (Typ_dep(Wt (Typ_dep(eqT, W (Exp_bvar (bvd_to_bvar_s bvd fieldTyp)))), W (Exp_proj(e',fn)))) in
          let refined_t, _ = kinding env (Wt (Typ_refine(bvd, fieldTyp, eqf, false))) in
            refined_t
        else fieldTyp in
          Exp_proj(e', fn), fieldTyp, used_affines
            
    | Exp_bot -> 
        let t = match expected_typ env with 
          | Some t -> t 
          | _ -> TypeRelations.new_uvar env Kind_star top_exp.p in
          Exp_ascribed(ewithsort Exp_bot t, t, []), t, []
  in 
  //let do_typing () =     
   // try 
             (*let _ = if Sugar.text_of_lid (current_module env) = "Test2" then pr "\nTyping %s\n" (Pretty.strExp top_exp) in *)
      let env = set_current_value env top_exp in
      let exp', t, A = do_typing env top_exp.v in
      let env = set_current_value env (ewithsort exp' t) in 
      let t = compress t in
      let env, t_expected = clear_expected_typ env in
        match t_expected with
            None -> ewithinfo exp' t top_exp.p, t, A
          | Some t' -> 
              let t' = compress t' in
              let cv = ewithinfo exp' t top_exp.p in
                (* pr "For sub-term (%s), testing convertability of computed typ (%s) with expected typ (%s)\n" *)
                (*   (Pretty.strExp (W exp')) (Pretty.strTyp t) (Pretty.strTyp t'); *)
                let sopt = TypeRelations.convertible_ev (set_range env top_exp.p) t t' in (* TODO: stash the proof with e for later phase? *)
                  match sopt with 
                    | None -> terr env t' t top_exp
                    | Some (subst, ev) -> 
                        let _ = unify_subst_vars subst in  (* this has a side effect; changes uvar pointers in Unionfind *) 
                        let result = ewithinfo exp' t' top_exp.p in
                        let result = ascribe result t' ev in
                          (* match ev with *) (* ascription needed for coretyping *)
                          (* | [] -> result *)
                          (* | _ ->  *)
                          result, t', A
    //with
    //    Err msg -> 
    //      raise (Error(msg, top_exp.p)) in
    //profile do_typing tc_ctr
      

and typing_record p env (((fn,_,_)::_) as fn_t_e_l) 
   : (lident * list<typ> * list<exp> * typ * list<fieldname * typ * option<exp>>) = 
  (* Lookup record type using the field name *)
  let recd_lident, tabbrv, tps, expected_record_typ = 
    (try lookup_record_typ env fn 
     with Not_found_binding _ -> 
       let msg = spr "%s is not a valid field name" (Sugar.text_of_lid fn) in
         raise (Error(msg, p))) in             
   
  (* Freshen type and value arguments in the expected type *) 
  let ({v=Typ_record(expected_fn_t_l, _)}, t_x_vars_rev, abductibles) = tps |> List.fold_left 
      (fun (record, t_x_vars, abductibles) -> function
         | Tparam_typ (bvd, k) -> 
             let uv = TypeRelations.new_uvar env k p in
             let record' = substitute record bvd uv in
               record', Inl uv::t_x_vars, abductibles
         | Tparam_term (bvd, t) -> 
             let bv = bvd_to_bvar_s bvd t in
               record, Inr bv::t_x_vars, bv::abductibles)  
      (expected_record_typ, [], []) in

  (* Unify each field type of given and expected type, inferring type and value args *)
  let env, fn_t_e_l_rev, abductions = 
    fn_t_e_l |> (expected_fn_t_l |> ((env, [], []) |> List.fold_left2 
        (fun (env, fn_t_e_l, abducts) (fn', expected_t) (fn, t, eopt) -> 
           if not (Sugar.lid_equals fn fn') then 
             raise (Error ("Missing or duplicate fields in record", p));
           let sopt = TypeRelations.instantiable env abductibles [] t expected_t in         
             match sopt, eopt with 
               | None, None -> terr_p env expected_t t p
               | None, Some e' -> 
                   let sopt = TypeRelations.convertible_ev (set_current_value (set_range env e'.p) e') t expected_t in
                     (match sopt with 
                        | None -> terr env expected_t t e'
                        | Some (subst, ev) -> 
                            let _ = unify_subst_vars subst in
                            let e' = match ev with [] -> e' | _ -> ascribe e' expected_t ev in
                              env, ((fn, t, Some e')::fn_t_e_l), abducts)
               | Some (subst, abducts'), _ -> 
                   let _ = unify_subst_vars subst in 
                   let env' = List.fold_left push_local_binding env abducts' in
                     env', (fn,t,eopt)::fn_t_e_l, abducts'@abducts))) in
    
  let find_abductive_assumption e1 = 
     Util.find_map abductions (function 
                                 | Binding_match (e1', e2) when equalsExp e1 e1' -> Some e2
                                 | _ -> None) in 

  (* Build the resulting type by applying the record type constructor to each inferred arg *)
  let result_typ, targs, phantoms = 
    (tabbrv,[],[]) |> (t_x_vars_rev |> List.fold_right
        (fun tp (out_typ, targs, phantoms) -> match tp with
             Inl tv -> (match out_typ.sort(* .u *)with
                          | Kind_tcon _ -> 
                              let t = twithsort (Typ_app(out_typ, tv)) Kind_unknown in 
                              let env, _ = clear_expected_kind env in 
                              let result_typ, _  = kinding env t in 
                              let targs = tv::targs in
                                result_typ, targs, phantoms
                          | _ -> raise Impos)
           | Inr bv -> 
               let bvexp = ewithinfo (Exp_bvar bv) bv.sort bv.p in
                 (match out_typ.sort(* .u *)with
                    | Kind_dcon _ -> 
                        (match find_abductive_assumption bvexp with
                             None -> let msg = 
                               spr "Unable to infer witness for a dependent type index %s in type %s. An explicit annotation may help."
                                 (Pretty.strExp bvexp) (Pretty.strTyp tabbrv) in
                               raise (Error (msg, p))
                                 
                           | Some e' -> 
                               let t = twithsort (Typ_dep(out_typ, e')) Kind_unknown in
                               let env, _ = clear_expected_kind env in 
                               let result_typ, _ = kinding env t in 
                               let phantoms = e'::phantoms in
                                 result_typ, targs, phantoms)

                    | _ -> raise Impos))) in 

    recd_lident, targs, phantoms, result_typ, (List.rev fn_t_e_l_rev)
      
and typing_pat range env pat : (pat * exp * list<binding>) = 
   let etOpt = bind_opt (expected_typ env) (fun t ->  Some (unrefine (Tcutil.reduce_typ_delta_beta env t))) in    
   match pat, etOpt with 
      | Pat_variant(lid, targs, _, pat_bvars, _), Some ({v=(Typ_dtuple [(nopt, t1); (_,t2)]);sort=_;p=_} as et)->  
          (* Special case: pattern matching for unpacking a dependent tuple *)
          let lid' = Const.tuple_data_lid t1.sort t2.sort in
          let lid_t = lookup_lid env lid' in
          let datacon = fvwithinfo lid' lid_t (Sugar.range_of_lid lid) in
          let (fst, tfst), (snd, tsnd), pat_bindings = match targs, pat_bvars with 
            | [], [fst; snd] -> 
                let fst = setsort fst t1 in
                let snd, t2 = match nopt with 
                  | None -> setsort snd t2, t2
                  | Some x -> 
                      let t2' = substitute_exp t2 x (ewithsort (Exp_bvar fst) t1) in
                        setsort snd t2', t2' in
                  (fst, t1), (snd, t2), [Binding_var(bvar_real_name fst, t1); Binding_var(bvar_real_name snd, t2)]
            | _ -> raise (Error("Unexpected number of pattern variables when unpacking a dependent tuple", range)) in
          let pat_exp = ewithsort (Exp_constr_app(datacon, [tfst;tsnd], [], [ewithsort (Exp_bvar fst) tfst;
                                                                            ewithsort (Exp_bvar snd) tsnd])) et in 
          let pat' = Pat_variant(lid', [tfst;tsnd], [], [fst;snd], false) in
            pat', pat_exp, pat_bindings
          
      | Pat_variant(lid, targs, [](* no explicit phantoms in source*), pat_bvars, _), _  when not !Options.gadt -> 
          let t_d, phantom_params = match lookup_fvar_with_params env (Wfv lid) with
            | None -> raise (Error (spr "Constructor %s not found" (Pretty.str_of_lident lid), range))
            | Some (t,tps) -> t, tps in
          let datacon = fvwithinfo lid t_d (Sugar.range_of_lid lid) in
          let rec mk_targs targs t targs' bindings = match t.v, targs with
            | Typ_univ(b, k, [], t'), ({v=Typ_btvar btvar; sort=_; p=r} as targ)::rest ->
              //(try
              //  let _ = lookup_btvar env btvar in
              //  raise (Error("explicit type arguments in Pat_variant", range))
              //with _ -> (* introduce new type variables in the pattern *)
                  let t' = substitute t' b targ in
                  let binding = Binding_typ(bvar_real_name btvar, k) in
                  mk_targs rest t' ((setsort targ k)::targs') (binding::bindings)
            | Typ_univ _, _ -> raise (Error("Insufficient type arguments in Pat_variant", range))
            | _, [] -> targs', bindings in              
          let targs, bindings_tv = if List.length targs > 0 then mk_targs targs t_d []  [] else [], [] in
          let env = List.fold_right (fun binding env -> push_local_binding env binding) bindings_tv env in
          let inst_t_d, targs' = instantiate_typ env t_d (List.rev targs) in
          let rec mk_vargs (outb,outv) (vargs:list<bvvar>) inst_t = match inst_t.v, vargs with 
            | Typ_fun (formal_opt, targ, tres), bv::vrest -> 
                let bv' = setsort bv targ in
                let exp = ewithinfo (Exp_bvar bv') targ bv'.p in
                let trest = open_typ_with_exp inst_t exp in  (* open_typ ((x:t) -> t') e  subs e for x in t' *)
                let binding = Binding_var (bvar_real_name bv', targ) in
                  mk_vargs (binding::outb, bv'::outv) vrest trest
            | Typ_fun _, [] -> raise (Error("Insufficient pattern variables", range))
            | _, hd::tl -> raise (Error("Too many pattern variables", hd.p))
            | _, [] -> (outb,outv), inst_t in
          let (bindings_rev, pat_bvars_rev), final_typ = mk_vargs ([],[]) pat_bvars inst_t_d in
          let final_typ, bindings_rev, pat_bvars_rev, phantoms = match expected_typ env, phantom_params with 
            | _, [] -> final_typ, bindings_rev, pat_bvars_rev, []
            | Some expected_t, tps -> 
                let pat_exp = Exp_constr_app(datacon, 
                                             targs', [], 
                                             List.rev (List.map (fun bv -> ewithsort (Exp_bvar bv) bv.sort)
                                                         pat_bvars_rev)) in
                let env = set_current_value env (W pat_exp) in
                let env = List.fold_right (fun binding env -> push_local_binding env binding) bindings_rev env in
                let inst_final_typ, subst = TypeRelations.try_instantiate_final_typ env tps final_typ expected_t in
                let bindings_rev = List.map (fun (Binding_var (bv, t)) -> Binding_var(bv, substitute_exp_l t subst)) bindings_rev in
                let pat_bvars_rev = List.map (fun bv -> setsort bv (substitute_exp_l bv.sort subst)) pat_bvars_rev in
                let phantoms = List.map (function 
                                       | Tparam_term(bvd, t) -> 
                                            (match Util.findOpt (fun (x, _) -> Absyn.bvd_eq x bvd) subst with 
                                                | None -> raise Impos
                                                | Some (_, y) -> y)
                                       |  Tparam_typ(a,_) -> raise (Error("Unexpected type parameter", range_of_bvd a))) tps in
                  inst_final_typ, bindings_rev, pat_bvars_rev, phantoms in
          let pat' = Pat_variant(lid, targs', phantoms, List.rev pat_bvars_rev, false) in
          let pat_exp_args =  List.fold_left 
            (fun out bv -> 
               let ebv = ewithinfo (Exp_bvar bv) bv.sort ((bvar_ppname bv).idRange) in
                 ebv::out) [] pat_bvars_rev in 
          let pat_exp = Exp_constr_app(datacon, targs', phantoms, pat_exp_args) in
          let abducts = match expected_typ env with 
              None -> []
            | Some et -> 
                let ftvs, fxvs = freevarsTyp et in 
                let equatable_xvars = pat_bvars_rev@fxvs in 
                let env' = List.fold_left push_local_binding env (List.rev bindings_rev) in
                let sopt = TypeRelations.instantiable env' equatable_xvars [] et final_typ in
                  match sopt with 
                      None -> 
                        let sopt = TypeRelations.convertible_ev (set_current_value (set_range env' (Sugar.range_of_lid lid)) (ewithsort pat_exp final_typ)) et final_typ in
                          (match sopt with 
                             | None -> 
                                 let msg = spr "Expected a pattern of type \n\t %s \nBut got pattern of type \n\t%s" 
                                   (Pretty.strTyp et) (Pretty.strTyp final_typ) in
                                   raise (Error(msg, range))
                             | Some (subst, ev) -> 
                                 warn_empty_ev ev;
                                 let _ = unify_subst_vars subst in [])
                    | Some (subst, abducts) -> let _ = unify_subst_vars subst in abducts in
            pat', ewithsort pat_exp final_typ, (List.rev bindings_tv)@(List.rev bindings_rev)@abducts


      | Pat_variant(lid, targs, [], pat_bvars, _), _  when !Options.gadt -> 
          let t_d = match lookup_fvar_with_params env (Wfv lid), targs with
            | None, _ -> raise (Error (spr "Constructor %s not found" (Pretty.str_of_lident lid), range))
            | Some (t,[]), [] -> t 
            | _ -> raise (Error ("Phantom type parameters and explicit type args in patterns are not yet supported in --gadt mode", range)) in 
          let fresh_existential_tvars t = 
            let rec final_typ out t = match t.v with 
              | Typ_univ(bvd, k, [], t) -> final_typ ((bvd, k)::out) t
              | Typ_univ(bvd, k, _, t) -> raise (Error("Polymorphic data constructor types must be constraint free", range))
              | Typ_fun(_, _, t) -> final_typ out t
              | _ -> List.rev out, t in
            let formal_tvars, final_t = final_typ [] t in 
            let is_uniform = match flattenTypAppsAndDeps final_t with 
              | t, args -> 
                  let parametric = List.for_all (function 
                                                   | Inr _ -> true
                                                   | Inl targ -> (match targ.v with 
                                                                    | Typ_btvar _ -> true (* maximally parametric *)
                                                                    | _ -> false)) args in
                  let no_existentials = List.for_all (fun ((bvd:btvdef),k) -> List.exists (function 
                                                                                    | Inl {v=Typ_btvar bvar; sort=_; p=_} -> 
                                                                                        (bvar_real_name bvar).idText = (real_name bvd).idText
                                                                                    | _ -> false) args) formal_tvars in
                    parametric && no_existentials in 
            let ftvs, _ = freevarsTyp final_t in 
            let in_final_typ (bvd:btvdef) = List.exists (fun (bvar:btvar) -> (real_name bvd).idText = (bvar_real_name bvar).idText) ftvs in
            let rec mk_targs (args, bindings, tvars) t = match t.v with 
              | Typ_univ(b, k, [], t') -> 
                  if is_uniform 
                  then (* generate a unification variable for this *)
                    let t_uv = TypeRelations.new_uvar env k t.p in
                    let t' = substitute t' b t_uv in 
                      mk_targs (t_uv::args, bindings, tvars) t'
                  else (* generate a fresh existential variable *)
                    let b' = gen_bvar k in 
                    let t_k = twithinfo (Typ_btvar(b')) k t.p in
                    let t' = substitute t' b t_k in
                    let binding = Binding_typ(bvar_real_name b', k) in 
                      mk_targs (t_k::args, binding::bindings, b'::tvars) t'
              | Typ_univ(b, k, _, t') -> raise (Error("Polymorphic data constructor types must be constraint free", range))
              | _ -> List.rev args, List.rev bindings, List.rev tvars, is_uniform in 
              mk_targs ([], [], []) t  
          in (* -- end fresh_existential_tvars *)
          let datacon = fvwithinfo lid t_d (Sugar.range_of_lid lid) in
          let actuals, tvar_bindings, existential_vars, is_uniform = fresh_existential_tvars t_d in 
          let env = List.fold_left push_local_binding env tvar_bindings in 
          let inst_t_d, actuals = instantiate_typ env t_d actuals  in 
          let rec mk_vargs (outb,outv) (vargs:list<bvvar>) inst_t = match inst_t.v, vargs with 
            | Typ_fun (formal_opt, targ, tres), bv::vrest -> 
                let bv' = setsort bv targ in
                let exp = ewithinfo (Exp_bvar bv') targ bv'.p in
                let trest = open_typ_with_exp inst_t exp in  (* open_typ ((x:t) -> t') e  subs e for x in t' *)
                let binding = Binding_var (bvar_real_name bv', targ) in
                  mk_vargs (binding::outb, bv'::outv) vrest trest
            | Typ_fun _, [] -> raise (Error("Insufficient pattern variables", range))
            | _, hd::tl -> raise (Error("Too many pattern variables", hd.p))
            | _, [] -> (List.rev outb,outv), inst_t in
          let (xvar_bindings, pat_bvars_rev), final_typ = mk_vargs ([],[]) pat_bvars inst_t_d in
          let pat' = Pat_variant(lid, actuals, [], List.rev pat_bvars_rev, not is_uniform) in (* actuals tagged as existentials, if not is_uniform *)
          let pat_exp_args =  List.fold_left 
            (fun out bv -> 
               let ebv = ewithinfo (Exp_bvar bv) bv.sort ((bvar_ppname bv).idRange) in
                 ebv::out) [] pat_bvars_rev in 
          let pat_exp = Exp_constr_app(datacon, actuals, [], pat_exp_args) in
          let equations = match expected_typ env with 
              None -> []
            | Some et -> 
                let equatable_tvars, fxvs = freevarsTyp et in 
                let equatable_xvars = pat_bvars_rev@fxvs in 
                let env' = List.fold_left push_local_binding env xvar_bindings in
                let sopt = TypeRelations.instantiable env' equatable_xvars equatable_tvars et final_typ in
                  match sopt with 
                      None -> 
                        let sopt = TypeRelations.convertible_ev (set_current_value (set_range env' (Sugar.range_of_lid lid)) (ewithsort pat_exp final_typ)) et final_typ in
                          (match sopt with 
                             | None -> 
                                 let msg = spr "Expected a pattern of type \n\t %s \nBut got pattern of type \n\t%s" 
                                   (Pretty.strTyp et) (Pretty.strTyp final_typ) in
                                   raise (Error(msg, range))
                             | Some (subst, ev) -> 
                                 warn_empty_ev ev;
                                 let _ = unify_subst_vars subst in [])
                    | Some (subst, equations) -> let _ = unify_subst_vars subst in equations in
            pat', ewithsort pat_exp final_typ, tvar_bindings@xvar_bindings@equations
              
          
let annotate env exp t = 
  let rec aux exp t = 
    let texpand = Tcutil.reduce_typ_delta_beta env t in  
      match texpand.v with 
        | Typ_univ (bvd, k, formula, tret) -> 
            let exp' = (match exp.v with 
                          | Exp_tabs(a, _, [], body) -> 
                              let tret = 
                                let bv = bvwithinfo a k (range_of_bvd a) in 
                                let t = twithinfo (Typ_btvar bv) k (range_of_bvd a) in 
                                  substitute tret bvd t in
                              let body' = aux body tret in 
                                Exp_tabs(a, k, formula, body')
                          | _ -> 
                              let exp' = aux exp tret in
                                Exp_tabs (bvd, k, formula, exp')) in 
              ewithinfo exp' t exp.p
                
        | Typ_fun (bvd_opt, targ, tret) -> 
            let exp' = match exp.v with 
              | Exp_abs (x, t, body) -> (* val decls take precedence over inline type ascriptions, if any. *)
                  let tret = match bvd_opt with
                    | None -> tret 
                    | Some bvd' -> 
                        let bv =  (bvwithinfo x targ (range_of_bvd x)) in 
                        let e = ewithinfo (Exp_bvar bv) targ (range_of_bvd x) in 
                          substitute_exp tret bvd' e in
                  let body' = aux body tret in
                    Exp_abs (x, targ, body')
                      
              | _ -> Exp_ascribed(exp, texpand, []) in 
              ewithinfo exp' t exp.p
                
        | Typ_affine t' -> 
            let e = aux exp t' in
              ewithpos (Exp_ascribed (e, t, [])) e.p
                
        | _ -> ewithinfo (Exp_ascribed (exp, t, [])) t exp.p in 
    aux exp t

let rec check_sigelt env = 
  let check_tparams lid env tps = 
    let _, tps' = List.fold_left  (* NB: no functional dependences between tparams *)
      (fun (env, out) tp -> 
         let env, tp' = match tp with
           | Tparam_typ (i,k) -> 
               let k = well_formed_kind (Sugar.range_of_lid lid) env k in
               let env = push_local_binding env (Binding_typ (i.realname, k)) in
                 env, Tparam_typ (i,k)
           | Tparam_term (i,t) -> 
               let t,k = kinding env t in 
                 match k(* .u *)with 
                   | Kind_star -> 
                       let env = push_local_binding env (Binding_var(i.realname, t)) in
                         env, Tparam_term(i,t)
                   | _ -> 
                       let msg = 
                         Printf.sprintf 
                           "Types can only be indexed by *-kinded terms; %s has a %s-kinded argument"
                           (Sugar.text_of_lid lid) (Pretty.strKind k) in
                         raise (Error(msg, (Sugar.range_of_lid lid))) in
           env, tp'::out) (env, []) tps in
      List.rev tps' in
    function (* TODO: handle recursive type declarations *)
      | Sig_tycon_kind (lid, tps, k, isProp, muts, tags) -> 
          (* parameterized types can now appear in kinds; 
             e.g. prop Eq<'a>::'a => 'a => * IS allowed *)
          let tps =check_tparams lid env tps in
          let env = push_tparams env tps in
          let k, b = ok_kind (Sugar.range_of_lid lid) (set_in_typ_decl env) k in
          let isProp = match b(* .u *)with 
            | Kind_prop
            | Kind_erasable when not (lid_is_connective lid) -> true 
            | _ -> false in
          let result = Sig_tycon_kind(lid, tps, k, isProp, muts, tags) in
            result
              
      | Sig_datacon_typ (lid, tps, t, atag, aq, tcn, eref, pats) -> 
          let tps = check_tparams lid env tps in
          let env' = push_tparams env tps in 
          let t, k = kinding env' t in
          let t, _ = 
            if (atag <> None) then generalize env' t (ewithpos (Exp_bot) dummyRange) 
            else t, (ewithpos (Exp_bot) dummyRange) in 
          let pats = match pats with 
            | [] -> pats 
            | _ -> let env'' = patternEnv env' t in
                List.map (function 
                            | Inl t -> Inl (fst (kinding env'' t))
                            | Inr e -> let e, _, _  = typing env'' e in Inr e) pats in
            (match k(* .u *)with 
               | Kind_star
               | Kind_affine
               | Kind_prop -> Sig_datacon_typ (lid, tps, t, atag, aq, tcn, eref, pats)
               | Kind_erasable when (atag <> None) ->
                   Sig_datacon_typ (lid, tps, t, atag, aq, tcn, eref, pats)
               | _ -> 
                   let msg = 
                     Printf.sprintf 
                       "Data constructors must construct data of *- or A-kinded type; %s is given a %s-kinded type"
                       (Sugar.text_of_lid lid) (Pretty.strKind k) in
                     raise (Error(msg, (Sugar.range_of_lid lid))))

      | Sig_logic_function (lid, t, tags) ->
          let t, k = kinding env t in
            (match k(* .u *)with 
               | Kind_star 
               | Kind_prop -> Sig_logic_function (lid, t, tags)
               | _ -> 
                   let msg = 
                     Printf.sprintf 
                       "Logic functions must be given *- or P-kinded types; %s is given an %s-kinded type"
                       (Sugar.text_of_lid lid) (Pretty.strKind k) in
                     raise (Error(msg, (Sugar.range_of_lid lid))))
              
      | Sig_value_decl (lid, t) ->
          let _ = match Tcenv.lookup_fvar env (ewithsort lid t) with 
            | None -> ()
            | Some _ -> raise (Error(spr "Duplicate value declaration: %s\n" (Pretty.sli lid), Sugar.range_of_lid lid)) in
          let t, k = kinding env t in
            (match k(* .u *)with 
               | Kind_star 
               | Kind_affine 
               | Kind_prop -> Sig_value_decl (lid, t)
               | _ -> 
                   let msg = 
                     Printf.sprintf 
                       "Value declarations must be given *- or A-kinded types; %s is given a %s-kinded type"
                       (Sugar.text_of_lid lid) (Pretty.strKind k) in
                     raise (Error(msg, (Sugar.range_of_lid lid))))

      | Sig_record_typ (lid, tps, kk, t, eref) -> 
          let tps = check_tparams lid env tps in
          let kk = well_formed_kind (Sugar.range_of_lid lid) env kk in
          let env' = push_tparams env tps in
          let env' = push_sigelt env' (Sig_tycon_kind(lid, tps, kk, false, [], [])) in
            (*         let _ = pr "Kinding for type %s\n" (Pretty.strTyp t) in *)
            (match t.v with 
               | Typ_record(fn_t_l, None) -> 
                   let k, fn_t_l = fn_t_l |> ((Kind_star, []) |> List.fold_left 
                                                  (fun (k, out) (fn,t) -> 
                                                     let t', k' = kinding env' t in 
                                                       match k'(* .u *)with 
                                                         | Kind_star 
                                                         | Kind_prop -> (k, (fn, t')::out)
                                                         | Kind_affine -> (Kind_affine, (fn, t')::out)
                                                         | _ -> 
                                                             let msg = spr "Record fields must have ground types; %s has kind %s" 
                                                               (Sugar.text_of_lid fn) (Pretty.strKind k') in
                                                               raise (Error(msg, Sugar.range_of_lid lid)))) in 
                   let fn_t_l = List.rev fn_t_l in 
                   let t = match k(* .u *), kk(* .u *)with                   
                     | Kind_affine, Kind_star -> raise (Err (spr "Record with affine components must itself be affine")) 
                     | _, Kind_affine
                     | _, Kind_star -> twithsort (Typ_record(fn_t_l, None)) kk in
                     Sig_record_typ (lid, tps, kk, t, eref)
               | _ -> raise Impos)
              
      | Sig_typ_abbrev (lid, tps, kk, t) -> 
          let check_kind env k kk =
            match TypeRelations.equivalent_kinds_with_evidence (set_range env (Sugar.range_of_lid lid)) k kk with 
              | None -> 
                  let msg = spr "Expected a type of kind %s; got %s"
                    (Pretty.strKind k) (Pretty.strKind kk) in
                    raise (Error(msg, (Sugar.range_of_lid lid)))
              | Some ev -> warn_empty_ev ev; () in 
          let tps = check_tparams lid env tps in
          let env' = push_tparams env tps in
          let t, k = kinding env' t in
            begin
              match kk(* .u *), tps with 
                | Kind_unknown, [] -> Sig_typ_abbrev (lid, tps, k, t)
                | Kind_unknown, _ -> 
                    let r = t.p in
                    let t,k = List.fold_right (fun tp (t,k) -> match tp with 
                                                 | Tparam_typ (a, k1) -> 
                                                     let k = Kind_tcon(Some a, k1, k) in
                                                     let t = twithinfo (Typ_tlam(a, k1, t)) k r in
                                                       t,k
                                                 | Tparam_term (x, t1) -> 
                                                     let k = Kind_dcon(Some x, t1, k) in
                                                     let t = twithinfo (Typ_lam(x, t1, t)) k r in
                                                       t,k) tps (t,k) in
                      Sig_typ_abbrev(lid, [], k, t)
                | Kind_star, _
                | Kind_affine, _ 
                | Kind_prop, _
                | Kind_erasable, _->                     
                    check_kind env k kk; 
                    Sig_typ_abbrev (lid, tps, kk, t)
                | _, [] -> 
                    let kk = well_formed_kind (Sugar.range_of_lid lid) env kk in 
                      check_kind env k kk; 
                      Sig_typ_abbrev (lid, tps, kk, t)
                | _, _ -> 
                    let msg =  spr "Malformed type abbreviation: %s" (Sugar.text_of_lid lid) in
                      raise (Error(msg, (Sugar.range_of_lid lid)))
            end
              
      | Sig_extern_value (eref, lid, typ) -> 
          let _ = match Tcenv.lookup_fvar env (ewithsort lid typ) with 
            | None -> ()
            | Some _ -> raise (Error(spr "Duplicate value declaration: %s\n" (Pretty.sli lid), Sugar.range_of_lid lid)) in
          let typ,k = kinding env typ in
            Sig_extern_value(eref, lid, typ)
              
      | Sig_extern_typ (eref, s) as ss-> 
          let env' = set_extern_typ env in
          let se = check_sigelt env s in
            Sig_extern_typ(eref, se)

      | Sig_query(lid, t) -> 
          let t, _ = kinding env t in 
            (match Tcenv.get_solver env with 
               | Some solver when solver.solver_query env t -> 
                   Sig_query(lid, t)
               | _ -> 
                   let msg = spr "Failed to prove query %s\n" (Sugar.text_of_lid lid) in
                     raise (Error(msg, (Sugar.range_of_lid lid))))

      | Sig_ghost_assume(lid, t, _aq) -> 
          let t, _ = kinding env t in 
            Sig_ghost_assume(lid, t, _aq)
              
      | _ -> raise Impos

let check_sigelts env sigelts = sigelts |> List.map 
    (fun se -> 
       try check_sigelt env se
       with Error(msg, p) -> let msg = spr "Failed to check signature element: %s\n%s\n" (Pretty.sli (lid_of_sigelt se)) msg in 
         raise (Error(msg, p)))

let check_signature (env:env) (s:signature) : (env * signature) = 
  let env', outsig = List.fold_left 
    (fun (env, outsig) sigelt -> 
       try 
         let sigelt' = check_sigelt env sigelt in
         let env' = push_sigelt env sigelt' in
           env', sigelt'::outsig
       with 
           Err msg -> pr "TC failed while checking decl\n %s\n" (Pretty.strSigelt sigelt);  raise (Error(msg, range_of_sigelt sigelt))
         | e when (pr "TC Failed while checking decl\n %s\n" (Pretty.strSigelt sigelt); false) -> raise e)
    (env,[]) s in
    env', List.rev outsig

let check_let_binding vds env lb = match lb with
  | ([(bvd, t, exp)], isRec) when isRec=false -> 
      let qname = asLid <| (current_module env).lid @ [bvd.ppname] in (* the only case where the pp name is actually used *)
      let env = set_current_unit env qname in
      let exp, vd_exp, val_decl_t = 
        match AbsynUtils.findValDecls vds lb with
          | [] -> 
            (match t.v with 
              | Typ_unknown -> exp, None, None
              | _ -> annotate env exp t, None, None)
          | [Sig_value_decl(lid, t)] ->
              let vd_exp = ewithinfo (Exp_fvar(fvwithinfo lid t exp.p, None)) t exp.p in 
              (* let _ = pr "Found vd_exp %s for lb %s\n" (Pretty.strExp vd_exp) (Pretty.strExp exp) in  *)
                (annotate env exp t, 
                 Some vd_exp,
                 Some t)
          | _ -> raise Impos in 
        (* let _ = if (Pretty.str_of_lident m.name) <> "Prims" then  pr "Typing annotated expression: %s\n" (Pretty.strExp exp) in *)
      let exp', t_exp, used_affines = typing env exp in
        (* let _ = if (Pretty.str_of_lident m.name) <> "Prims" then  pr "Typed expression is %s\n" (Pretty.strExp exp' in *)
      let t_forall, Lambda_exp = generalize env t_exp exp' in
      let _ = match val_decl_t with 
        | None -> ()
        | Some t -> 
          (match TypeRelations.convertible_ev (set_range env (range_of_bvd bvd)) t_forall t with 
                       | Some(subst, ev) -> 
                           let _ = unify_subst_vars subst in 
                             warn_empty_ev ev; 
                             ()
                       | _ -> terr env t t_forall exp') in
      let _ = match used_affines with 
          hd::tl -> raise (Error ("Top-level expression cannot capture affine assumptions", exp'.p))
        | _ -> () in
      let binding = ([bvd, t_forall, Lambda_exp], isRec) in
      let rn = bvd.realname in 
      let env = push_local_binding env (Binding_var (rn, t_forall)) in
      let env = match vd_exp with 
        | None -> env 
        | Some e -> 
            let e' = bvd_to_exp bvd t_forall in 
            (* let _ = pr "Pushing equivalence: %s = %s\n" (Pretty.strExp e) (Pretty.strExp e') in  *)
              push_local_binding env (Binding_match(e, e')) in
        env, binding
          
  | (bindings, isRec) when isRec -> 
      let rec_env, bindings' = List.fold_left 
        (fun (env, bindings') ((bvd, t, exp) as lb) -> 
           let (pp, rn) = bvd.ppname, bvd.realname in
           let qname = asLid <| (current_module env).lid @ [pp] in (* again use ppname *)
           let env = set_current_unit env qname in
             match AbsynUtils.findValDecls vds ([lb], false) with
               | [Sig_value_decl(lid, t) as vd] -> 
                   let exp' = annotate env exp t in
                   let binding = Binding_var (rn, t) in
                   let env' = push_local_binding env binding in
                     (env', (bvd, t, exp')::bindings')
               | _ -> 
                   let t = TypeRelations.new_uvar env Kind_star exp.p in
                   let binding = Binding_var (rn, t) in
                   let env' = push_local_binding env binding in
                     (* let _ = pr "Binding %s, %s to type %s\n" (pp.idText) (rn.idText) (Pretty.strTyp t) in *)
                     (env', (bvd, t, exp)::bindings')) (env, []) bindings in
      let bindings' = List.rev bindings' in
      let typed_bindings = List.map 
        (fun (bv, t, exp) -> 
           let exp', t_exp, used_affines = typing (set_expected_typ rec_env t) exp in
           let _ = match used_affines with 
             | hd::tl -> raise (Error ("Top-level expressions cannot capture affine assumptions", exp'.p))
             | _ -> () in
             (bv, t, exp')) bindings' in
        rec_env, (typed_bindings, isRec)
          
  | _ -> raise Impos 

let typing_modul env m =       
  let typing_modul env m = 
    let _ = Tcutil.extractSignature env m in
    let signature = m.signature in 
    let _ = bind_opt env.solver (fun s -> s.solver_toggle_caching(); None) in
    let env, signature = check_signature env signature in 
    let _ = bind_opt env.solver (fun s -> s.solver_toggle_caching(); None) in
    let env, bindings' = List.fold_left 
      (fun (env, out) binding -> 
         let vds = AbsynUtils.findValDecls signature binding in
         let env', binding' = check_let_binding vds env binding in
           env', binding'::out) (env,[]) m.letbindings in
    let main' = match m.main with 
      | None -> None
      | Some main -> 
          let main', t_main, used_affines = typing env main in
            Some main' in
      {name=m.name; extends=m.extends; pos=m.pos; signature=signature;
       letbindings=List.rev bindings'; main=main'; exports=signature; pragmas=m.pragmas} 
        (* TODO: currently everything in a signature is exported; hide abstract symbols *)
  in
    try 
      let result = Some(typing_modul env m) in
        result
    with 
      | e when (handleable e) -> handle_err false None e
          
  
