#light "off"

module Microsoft.FStar.SimpleSolver

open Absyn
open Util
open Profiling 
open Tcenv
open AbsynUtils
open Tcutil
open KindAbbrevs

exception Simple_prover_failed
let disable = ref true
let debug = ref false
let lab = ref 0
let next_label () = incr lab; !lab
let next_proof_point () = spr "Lab%d" (next_label ())
  
let trivial_solver env goal = 
  match Tcenv.find env (function 
                          | Binding_var(id, t) -> 
                            (match TypeRelations.equivalent_with_evidence env goal t with 
                                | None -> false
                                | Some _ -> true)
                          | _ -> false) with
      Some (Binding_var(id, t)) -> 
        Some (ewithsort (Exp_bvar (bvd_to_bvar_s (mkbvd (id,id)) t)) t)
    | _ -> None

type eq_subst_t = (TypeRelations.equatables<exp,typ> * list<bvvdef*exp>)
type subgoals = list<int*typ>
type solns = list<int*typ*exp>
type gamma = list<option<exp>*binding>
let simple_solver env goal = 
  if !disable then None else
  let print_goal g = if !debug then Printf.printf "Trying simple proof for: %s\n" (Pretty.strTyp g) in 
  let print_eapply h = if !debug then Printf.printf "Trying eapply using hyp %s\n" (Pretty.strTyp h) in 
  let fail () = raise Simple_prover_failed in
  let gamma = Tcenv.fold_env env (fun out b -> (None, b)::out) [] in
  let gamma = List.rev gamma in
  let signature = List.fold_left (fun out (_,m) -> out@m.signature) env.e_signature env.modules in
  let gamma = List.fold_left (fun out se -> match se with 
                                  Sig_datacon_typ (lid, _, t, Some Sugar.Assumption, _, _, _, _) -> (* assumptions *)
                                    let eopt = Some (W (Exp_constr_app (Wfv lid, [],[],[]))) in
                                      (eopt, Binding_var(genident None, t))::out
                                | _ -> out) gamma signature in
  let rec eapply H_exp env (eqbs, subs) subgoals goal t : option<eq_subst_t * subgoals * (solns -> exp)>  = 
    print_eapply t;
    let solved = TypeRelations.equivalent_with_equations env eqbs t goal in
      match solved with
        | Some bindings -> 
            let subst = List.map (function 
                                    | Binding_match ({v=Exp_bvar bv; sort=_; p=_}, e2) -> (bvar_to_bvd bv, e2)
                                    | _ -> fail ()) bindings in
            let subst = subs@subst in
            let in_subst bv = List.exists (fun ((bv'), _) -> (bvar_real_name bv).idText = bv'.realname.idText) subst in
            let still_equatable = List.fold_left (fun out bv -> 
                                                    if in_subst bv then out
                                                    else bv::out) [] eqbs in
              (*             let subgoals = List.map (fun (n,sg) -> (n,substitute_exp_l sg subst)) subgoals in *)
              Some ((still_equatable, subst), subgoals, fun _ -> H_exp)
        | _ -> 
            match t.v with
              | Typ_app(pf_typ, {v=Typ_fun(Some bvd, t1, t2)}) when Tcutil.is_proof_typ_constr pf_typ -> 
                  let x = new_bvd None in
                  let x_exp = bvd_to_exp x t2 in
                  let uv = new_bvd None in
                  let uv_exp = bvd_to_exp uv t1 in
                  let t2 = substitute_exp t2 bvd uv_exp in
                    bind_opt 
                      (eapply x_exp env ((bvd_to_bvar_s uv t1)::eqbs, subs) subgoals goal t2)
                      (fun ((eqbs', subs'), subgoals, pf_x_goal) -> 
                         let f = new_bvd None in
                         let t', goal' = unwrap_pf t, unwrap_pf goal in
                         let body subg = W (Exp_let (false, [x, t2, W (Exp_app(bvd_to_exp f t, uv_exp))], pf_x_goal subg)) in
                         let pf_builder subg = W (Exp_constr_app(Wfv Const.bind_pf_lid, [t';goal'], [], [H_exp; W (Exp_abs(f, t', body subg))])) in
                           Some ((eqbs', subs'), subgoals, pf_builder))
              | _ -> 
                  if Tcutil.is_implication t then
                    bind_opt 
                      (Tcutil.destruct_implication t)
                      (fun (t1, t2) -> 
                         let g = new_bvd None in
                         let G_exp = bvd_to_exp g t2 in
                         let sg_name = next_label () in
                           bind_opt
                             (eapply G_exp env (eqbs, subs) ((sg_name, t1)::subgoals) goal t2)
                             (fun (unsubs, subgoals, pf_x_goal) -> 
                                let pf_builder solns = 
                                  match List.tryFind (fun (n, _, _) -> n=sg_name) solns with 
                                      Some (_, _, sg_soln) -> 
                                        let t1', t2' = unwrap_pf t1, unwrap_pf t2 in
                                        let mp = W (Exp_constr_app(Wfv Const.modus_ponens_lid, [t1';t2'], [], [sg_soln; H_exp])) in
                                          W (Exp_let(false, [g, t2, mp], pf_x_goal solns))
                                    | None -> fail () in
                                  Some (unsubs, subgoals, pf_builder)))
                      
                  else 
                    bind_opt 
                      (Tcutil.destruct_pf_binop Const.and_lid t)
                      (fun (p,q) -> 
                         let g = new_bvd None in
                         let mk_and_elim and_elim_var pq (unsubs, subgoals, g_to_goal) = 
                           let pf_builder subgoal_solns = 
                             let ae = W (Exp_constr_app (and_elim_var, [unwrap_pf p; unwrap_pf q], [], [H_exp])) in
                               W (Exp_let (false, [g, pq, ae], g_to_goal subgoal_solns)) in
                             Some (unsubs, subgoals, pf_builder) in
                           match eapply (bvd_to_exp g p) env (eqbs, subs) subgoals goal p with 
                             | None -> 
                                 bind_opt 
                                   (eapply (bvd_to_exp g q) env (eqbs, subs) subgoals goal q)
                                   (fun x -> mk_and_elim (Wfv Const.and_elim_2_lid) q x)
                             | Some x -> mk_and_elim (Wfv Const.and_elim_1_lid) p x) in

  let rec scang_new_goal (uns, subs) goal gamma : option<eq_subst_t * exp> = 
    print_goal goal; 
    let rec scang (uns, subs) goal = function
      | [] -> try_split (uns, subs) goal
      | (hopt, Binding_var(id, t))::tl when Tcutil.is_proof_typ t -> 
          if !debug then pr "Trying to apply hypothesis: %s\n" (Pretty.strTyp t);
          let H_exp = match hopt with 
            | None -> bvd_to_exp (mkbvd(id,id)) t
            | Some h -> h in
            (match eapply H_exp env (uns, subs) [] goal t with
               | None -> scang (uns, subs) goal tl
               | Some (unsubs', [], builder) -> 
                   if !debug then pr "Eapply succeeded producing no further subgoals!\n";  Some (unsubs', builder [])
               | Some (unsubs', subgoals, builder) -> 
                   let pp = next_proof_point () in
                     if !debug then pr "(ProofPoint: %s) Eapply produced %d subgoals.\n" pp (List.length subgoals);  
                     let rec handle_subgoals solns i (uns', subs')  = function
                       | [] -> Some ((uns', subs'), builder solns)
                       | (sgname, sg)::rest -> 
                           let sg = substitute_exp_l sg subs' in
                             if !debug then pr "(ProofPoint %s): Trying subgoal %d\n" pp i;
                             match (scang_new_goal (uns',subs') sg gamma) with 
                               | None -> scang (uns, subs) goal tl (* Premises of (id:t) were not solvable; continue to scan tl *)
                               | Some (unsub', soln) -> 
                                   if !debug then pr "(ProofPoint %s): Solved subgoal %d!\n" pp i;
                                   handle_subgoals ((sgname, sg, soln)::solns) (i+1) unsub' rest in
                       handle_subgoals [] 1 unsubs' subgoals)
      | (_, Binding_match(e1,e2))::tl when Tcutil.maybe_eq_proof_typ goal ->  (* to construct: (Refl_equal e1):Eq<e1,e2> *)
          let eqT = Tcutil.eqT_of_typ env e1.sort in
          let refl_var = Tcutil.reflexivity_var env in
          let eq_typ = twithsort (Typ_app(Const.pf_typ, 
                                         (twithsort (Typ_dep((twithsort (Typ_dep(eqT, e1)) 
                                                               (Kind_dcon(None, e1.sort, Kind_star))), e2)) Kind_star))) Kind_star in
            (match TypeRelations.equivalent_with_evidence env eq_typ goal with 
                | Some ev -> 
                  begin
                    if !debug then pr "Proved %s using match assumption %s=%s\n" (Pretty.strTyp goal) (Pretty.strExp e1) (Pretty.strExp e2);
                    let pf_term = ascribe (W (Exp_constr_app(refl_var, [e1.sort], [], [e1]))) goal [] in 
                      Some((uns, subs), pf_term)
                  end
                | _ -> scang (uns, subs) goal tl)
      | _::tl -> scang (uns, subs) goal tl 
          
    and try_split unsubs goal =
      if Tcutil.is_pf_binop Const.and_lid goal then 
        bind_opt 
          (Tcutil.destruct_pf_binop Const.and_lid goal)
          (fun (p,q) -> 
             bind_opt 
               (scang_new_goal unsubs p gamma)
               (fun ((uns, subs), pf_p) -> 
                  let q = substitute_exp_l q subs in
                    bind_opt
                      (scang_new_goal (uns, subs) q gamma)
                      (fun (unsub, pf_q) -> 
                         let pf = W (Exp_constr_app(Wfv Const.and_intro_lid, [p;q], [], [pf_p;pf_q])) in
                           Some (unsub, pf))))
      else (if !debug then pr "Failed proving sub goal: %s\n" (Pretty.strTyp goal); None) in
      scang (uns, subs) goal gamma in
    if !debug then TypeRelations.debug := true;
    let result = scang_new_goal ([],[]) goal gamma in
      TypeRelations.debug := false; result

let try_solve (env:Tcenv.env) (formula:typ) : option<exp> =
  match trivial_solver env formula with 
    | Some pf -> 
        let _ = if !debug then Printf.printf "Trivial prover succeeded in proving goal: %s\n" (Pretty.strTyp formula) in
          Some pf
    | _ ->  
        pr "Trying simple solver on: %s\n" (Pretty.strTyp formula);
        match simple_solver (Tcenv.clear_solver env) formula with (* set_solver_flag env false) t with *)
            Some ((eqbs, subst), pf) -> 
              if List.length eqbs <> 0 then (pr "\n****Unexpected unification variables left over by simple solver!***"; printfn "%A" eqbs;);
              let pf' = e_substitute_exp_l pf subst in
                (* let _ = if !debug then  *)
                pr "Simple prover succeeded in proving goal: %s\n" (Pretty.strTyp formula);
                Some pf'
          | _ -> None
              
let query_equiv = Solver.query_equiv

let query (env:Tcenv.env) (t:typ) : bool = 
  match try_solve env t with 
    | Some pf -> true
    | _ -> 
        let _ = if !debug then Printf.printf "Simple prover failed to prove a goal, trying Z3\n" in
          Solver.query env t
            
            
let discharge_proof env t : option<exp> = 
  match try_solve env t with 
    | Some pf -> Some pf 
    | _ -> 
        let _ = if !debug then Printf.printf "Simple prover failed to prove a goal, trying Z3\n" in
          Solver.discharge_proof env t
                
