#light "off"
// (c) Microsoft Corporation. All rights reserved

module Microsoft.FStar.Solver

open Microsoft.FStar
open Absyn
open Util
open Profiling 
open Tcenv

let ctrs = ref []
let count env = match !ctrs with
  | (mname, c)::tl when (current_module env)=mname -> ctrs := (mname, c+1)::tl
  | l -> ctrs := ((current_module env, 1)::l)
let print_ctrs () =
  List.iter (fun (mname, c) -> if !Options.silent then () else Printf.printf "Proof obls for module %s = %d\n" (Pretty.str_of_lident mname) c) !ctrs
    
let already_disposed = ref false
let dispose_proof_state () = ()

(* let solver_ctr = new_counter "Solver" *)

let DISABLE_SOLVER = ref false (* HACK! *)

let dump_match_assumptions env = 
  Tcenv.fold_env env (fun _ -> function
                          Tcenv.Binding_match(e1,e2) -> Printf.printf "(%s = %s)\n" (Pretty.strExp e1) (Pretty.strExp e2)
                        | _ -> ()) ()

#if MONO
let query (env:Tcenv.env) (formula:typ) : bool  = raise Impos
let query_equiv (env:Tcenv.env) (e1:exp) (e2:exp) : bool = raise Impos
#else
let query (env:Tcenv.env) (formula:typ) : bool  = 
   if !DISABLE_SOLVER then
     (Printf.printf "WARNING!!: When typing %s, admitted proof of refinement %s in a context with\n"
        (Sugar.text_of_lid (Tcenv.current_unit env)) (Pretty.strTyp formula);
      true)
   else    
     (count env; Z3Encoding.Encoding.query env formula)
       
let query_equiv (env:Tcenv.env) (e1:exp) (e2:exp) : bool =
   if !DISABLE_SOLVER then
     (Printf.printf "WARNING!!: When typing %s, admitted proof of term equivalence %s = %s in a context with\n" 
        (Sugar.text_of_lid (Tcenv.current_unit env)) (Pretty.strExp e1) (Pretty.strExp e2);
      true)
   else
     (count env;
      Z3Encoding.Encoding.query_equality env e1 e2)
#endif
      
let discharge_proof (env:Tcenv.env) (t:typ) : option<exp> = raise (NYI "Z3 proof extraction is no longer supported")

