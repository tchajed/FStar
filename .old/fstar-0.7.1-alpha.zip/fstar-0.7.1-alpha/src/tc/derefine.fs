#light "off"
// (c) Microsoft Corporation. All rights reserved
module Microsoft.FStar.Derefine

open Absyn
open AbsynUtils
open Util
open Tcenv
open Profiling
open Tcutil
open KindAbbrevs

exception Derefinement_failure of string
let fail msg = raise (Derefinement_failure msg)
let collect_ctr = new_counter "Collect evidence"  

let fet e texpected tgot =
  fail (spr "(At expression (%s) %s):\nExpected expression of type \n\n %s::%s\n\n but got\n\n %s::%s\n" 
          (Range.string_of_range e.p)
          (Pretty.strExp e)
          (Pretty.strTyp texpected) (Pretty.strKind texpected.sort)
          (Pretty.strTyp tgot) (Pretty.strKind tgot.sort)) 
  
let mk_tuple_constr env t1 t2 = 
  let tuple_cons = Const.tuple_data_lid t1.sort t1.sort in
  let tuple_cons_typ = Tcenv.lookup_lid env tuple_cons in
    fvwithsort tuple_cons tuple_cons_typ 
      
let mk_tuple_exp env e1 e2 tuple_typ = 
  let t1, t2 = e1.sort, e2.sort in
  let tcvar = mk_tuple_constr env t1 t2 in
  let etup = ewithsort (Exp_constr_app (tcvar, [t1; t2], [], [e1; e2])) tuple_typ in
  let ev = get_evidencel [e1;e2] in
    ascribe etup tuple_typ ev

let equivalent_kinds env k1 k2 = 
    match TypeRelations.equivalent_kinds_with_evidence env k1 k2 with
        | None -> false
        | Some ev -> warn_empty_ev ev; true
let force_kind_convertible env k1 k2 = 
    match TypeRelations.force_kind_convertible_ev env k1 k2 with
        | None -> false
        | Some ev -> warn_empty_ev ev; true
let equivalent env t1 t2 = 
    match TypeRelations.equivalent_with_evidence env t1 t2 with
        | None -> false
        | Some ev -> warn_empty_ev ev; true

let GADT_FLAG_IGNORED = false
  
let unpack_deptuple_names env (e:exp) (x1:bvvdef) (y1:bvvdef) (f: env -> bvvar -> bvvar -> (exp * 'a)) : exp * 'a = 
  let t_tup = e.sort in
    match t_tup.v with
        Typ_dtuple([(Some x0, t1); (_, t2)]) -> 
          let x1_bvar = bvd_to_bvar_s x1 t1 in
          let x1_exp = bvd_to_exp x1 t1 in
          let t2 = substitute_exp t2 x0 x1_exp in
          let y1_bvar = bvd_to_bvar_s y1 t2 in
          let y1_exp = bvd_to_exp y1 t2 in
          let pat_dc = Const.tuple_data_lid t1.sort t2.sort in
          let exp = mk_tuple_exp env x1_exp y1_exp t_tup in
          let bindings = [Binding_var(x1.realname, t1); 
                          Binding_var(y1.realname, t2);
                          Binding_match(e, exp)] in
          let bindings = match (unascribe e).v with
            | Exp_constr_app(_, _, _, [e_fst; e_snd]) -> bindings@[Binding_match(x1_exp, e_fst);Binding_match(y1_exp, e_snd)]
            | _ -> bindings in
          let env = List.fold_left push_local_binding env bindings in
          let k, a = f env x1_bvar y1_bvar in
          let ee = ewithsort (hoist e (fun e -> 
                                        ewithsort (Exp_match(e, 
                                                            [Pat_variant(pat_dc, [t1; t2], [], [x1_bvar; y1_bvar], GADT_FLAG_IGNORED), k],
                                                            bot k.sort)) k.sort)) k.sort in
          let ev = union_ev (subtract_ev_exact (subtract_ev (get_evidence e) [Inr (x1_exp);Inr y1_exp]) [Inr (e,exp)]) (get_evidence e) in
            ascribe ee k.sort ev, a
      | _ -> printfn "%A" ("Unpack dep tuple called with type", t_tup); raise Impos

let unpack_deptuple env (e:exp) (f: env -> bvvar -> bvvar -> (exp * 'a)) : exp * 'a = 
  unpack_deptuple_names env e (new_bvd None) (new_bvd None) f
          
let rec derefine_kind env kind : kind = 
  match kind(* .u *) with
    | Kind_star -> Kind_star
    | Kind_affine -> Kind_affine
    | Kind_tcon(aopt, k1, k2) -> 
        let k1 = derefine_kind env k1 in
        let env = match aopt with
            | None -> env
            | Some a -> push_local_binding env (Binding_typ(a.realname,k1)) in
        let k2 = derefine_kind env k2 in
            Kind_tcon(aopt, k1, k2)
    | Kind_dcon(xopt, t, k) -> 
        let t', _ = derefine_typ env t in 
        let env = match xopt with
            | None -> env
            | Some x -> push_local_binding env (Binding_var(x.realname, t')) in
        let k' = derefine_kind env k in
          Kind_dcon(xopt, t', k')
    | _ -> fail (spr "Unexpected kind: %s" (Pretty.strKind kind))
        
and discharge_proof env t_pf = 
  match SimpleSolver.discharge_proof env t_pf with
    | None -> fail (spr "Failed to derive proof term: %s" (Pretty.strTyp t_pf))
    | Some pf_term -> 
        if !Options.typecheck_proofs then 
          let env' = set_expected_typ env t_pf in
          let pf_term',_,_ = derefine_exp env pf_term in
            (*Printf.printf "Checked a proof term!\n";*) (*  (Pretty.strExp pf_term');  *)
            pf_term'  
        else
          (Printf.printf "Warning! Admitted a proof term without checking.\n";
           pf_term)
            
and derefine_typ env t : (typ * kind) = 
  let derefine_typ' env t' = match t' with
    | Typ_btvar bv -> 
        (match lookup_btvar env bv with 
           | Kind_unknown -> fail (spr "Type variable with unknown kind: %s" (Pretty.strTyp t))
           | k -> 
               let bv' = bvwithinfo (bv.v) k bv.p in
                 Typ_btvar bv', k)
    | Typ_const (fv, eref) -> 
        (match lookup_typ_const env fv with 
           | Kind_unknown -> 
               let msg = spr "Type constant with unknown kind: %s" (Pretty.strTyp t) in
                 fail msg
           | k -> 
               let fv' = fvwithinfo (fv.v) k fv.p in
                 Typ_const(fv',eref), k)
          
    | Typ_affine t -> 
        let t', k = derefine_typ env t in
          (match k(* .u *) with
             | Kind_star -> Typ_affine t', Kind_affine
             | Kind_boxed Kind_star -> Typ_affine t', Kind_boxed Kind_affine
             | _ -> 
                 let msg = 
                   spr "The affine qualifier can only be applied to *-kinded types\n\
                     The type %s has %s-kind"
                     (Pretty.strTyp t) (Pretty.strKind k) in
                   fail msg)
            
    | Typ_univ(bvd, k, formulas, t) when Tcutil.kind_abstractable t.p k -> 
        let k = derefine_kind env k in
        let binding = Binding_typ (bvd.realname, k) in 
        let env = push_local_binding env binding in
        let formulas = List.map (fun t -> fst (derefine_typ env t)) formulas in 
        let t', k' = derefine_typ env t in
          Typ_univ(bvd, k, formulas, t'), Kind_star
            
    | Typ_fun(xopt, t1, t2) -> 
        let t1', k1 = derefine_typ env t1 in
          begin
            match k1(* .u *) with
              | Kind_boxed k1 -> 
                  (match t1'.v with 
                     | Typ_dtuple([(Some x', t1_arg); (_, t1_proof)]) -> 
                         let x, t1_proof = match xopt with 
                           | None -> 
                               let x'_extrude = new_bvd None in
                               let bv_x'_extrude = bvd_to_exp x'_extrude t1_arg in
                               let t1_proof = substitute_exp t1_proof x' bv_x'_extrude in
                                 x'_extrude, t1_proof
                           | Some x -> 
                               let bv_x = ewithsort (Exp_bvar(bvd_to_bvar_s x t1_arg)) t1_arg in
                                 x, substitute_exp t1_proof x' bv_x in
                         let y = new_proof_bvd () in
                         let env = push_local_binding env (Binding_var (x.realname, t1_arg)) in
                         let env = push_local_binding env (Binding_var ((y.realname), t1_proof)) in
                         let t2', k2 = derefine_typ env t2 in
                         let tail = twithsort (Typ_fun(Some y, t1_proof, t2')) Kind_star in
                         let tail = match k1(* .u *) with 
                           | Kind_star -> tail
                           | Kind_affine -> twithsort (Typ_affine tail) Kind_affine in
                           Typ_fun (Some x, t1_arg, tail), Kind_star
                     | _ -> fail (spr "Unexpected boxed type: %s" (Pretty.strTyp t1')))
                    
              | _ -> 
                  let env = match xopt with 
                    | None -> env
                    | Some x -> push_local_binding env (Binding_var (x.realname, t1')) in
                  let t2', k2 = derefine_typ env t2 in
                    Typ_fun(xopt, t1', t2'), Kind_star
          end

    | Typ_dtuple([(xopt, t1); (None,t2)]) -> 
        let torig = t' in
        let t1', k1 = derefine_typ env t1 in
        let result = match k1(* .u *) with
              | Kind_boxed k1 -> 
                  (match t1'.v with 
                     | Typ_dtuple([(Some x', t1_arg); (_, t1_proof)]) -> 
                         let x, t1_proof = match xopt with 
                           | None -> 
                               let x'_extrude = new_bvd None in
                               let bv_x'_extrude = bvd_to_exp x'_extrude t1_arg in
                               let t1_proof = substitute_exp t1_proof x' bv_x'_extrude in
                                 x'_extrude, t1_proof
                           | Some x -> 
                               let bv_x = ewithsort (Exp_bvar(bvd_to_bvar_s x t1_arg)) t1_arg in
                                 x, substitute_exp t1_proof x' bv_x in
                         let y = new_proof_bvd () in
                         let env = push_local_binding env (Binding_var (x.realname, t1_arg)) in
                         let env = push_local_binding env (Binding_var ((y.realname), t1_proof)) in
                         let t2', k2 = derefine_typ env t2 in
                         let tail = twithsort (Typ_dtuple([(Some y, t1_proof); (None, t2')])) k2 in
                           Typ_dtuple [(Some x, t1_arg); (None, tail)], kind_lub k1 k2
                     | _ -> fail (spr "Unexpected boxed type: %s" (Pretty.strTyp t1')))
              | _ -> 
                  let env = match xopt with 
                    | None -> env
                    | Some x -> push_local_binding env (Binding_var (x.realname, t1')) in
                  let t2', k2 = derefine_typ env t2 in
                    Typ_dtuple([(xopt, t1'); (None, t2')]), kind_lub k1 k2 in
(*         let _ = pr "Desugared tuple typ : %s\n to %s\n" (Pretty.strTyp (Wt torig)) (Pretty.strTyp (Wt (fst result))) in *)
          result
            
    | Typ_app(t1, t2) -> 
        let t1, k1 = derefine_typ env t1 in
        let t2, kactual = derefine_typ env t2 in
          (match k1(* .u *) with 
             | Kind_tcon(aopt, kformal, k') when force_kind_convertible env kactual kformal -> 
                 let k' = open_kind k1 t2 in
                  Typ_app(t1, t2), k'
                   
             | _ -> fail (spr "Type application (%s) kind mismatch: %s, %s" (Pretty.strTyp t) (Pretty.strKind k1) (Pretty.strKind kactual)))

    | Typ_dep(t1, v) -> 
        let t1, k1 = derefine_typ env t1 in
          (match k1(* .u *) with 
             | Kind_dcon(xopt, t, k) -> 
                 let env = set_expected_typ env t in
                 let v, tv, _ = derefine_exp env v in
                 let k = open_kind_with_exp k1 v in
                   Typ_dep(t1, v), k
             | _ -> fail (spr "Unexpected kind in dependent type application: %s" (Pretty.strKind k1)))
            
    | Typ_refine(x, t, f, ghost) when ghost=false -> 
        let t, k = derefine_typ env t in
          (match k(* .u *) with 
             | Kind_star 
             | Kind_affine
             | Kind_prop -> 
                 let env = push_local_binding env (Binding_var(x.realname, t)) in
                 let f, k' = derefine_typ env f in
                   (match k'(* .u *) with 
                      | Kind_prop
                      | Kind_star ->  (* TODO: remove Kind_star from here *)
                          let proof_f = twithsort (Typ_app(Const.pf_typ, f)) Kind_star in
                            Typ_dtuple([(Some x, t); (None, proof_f)]), Kind_boxed Kind_star
                      | _ -> fail (spr "Concrete refinement formulas must have P kind: %s" (Pretty.strTyp f)))
                     
             | _ -> fail (spr "Nested refinements are not supported: %s" (Pretty.strTyp t)))

    | Typ_refine(x, t, f, ghost) when ghost=true -> 
        let t, k = derefine_typ env t in
          (match k(* .u *) with 
             | Kind_affine
             | Kind_prop
             | Kind_star -> 
                 let env = push_local_binding env (Binding_var(x.realname, t)) in
                 let f, k' = derefine_typ env f in
                   (match k'(* .u *) with 
                      | Kind_prop
                      | Kind_erasable -> Typ_refine(x, t, f, ghost), k
                      | _ -> fail (spr "Refinement formulas must have P or E-kind: %s" (Pretty.strTyp f)))
                     
             | _ -> fail (spr "Nested refinements are not supported: %s" (Pretty.strTyp t)))

    | Typ_record(fn_t_l, _ig) -> 
        let fn_t_l' = List.map (fun (fn,t) -> 
                                  let t', _ = derefine_typ env t  in
                                    fn, t') fn_t_l in
          Typ_record(fn_t_l', _ig), List.fold_left (fun k (_,t) -> kind_lub k t.sort) Kind_star fn_t_l

    | Typ_lam (x, t1, t2) -> 
        let t1', k1 = derefine_typ env t1 in
          begin
            match k1(* .u *) with
              | Kind_boxed k1 -> 
                  (match k1(* .u *) with 
                     | Kind_star -> 
                         (match t1'.v with 
                            | Typ_dtuple([(Some x', t1_arg); (_, t1_proof)]) -> 
                                let x, t1_proof = 
                                  let bv_x = ewithsort (Exp_bvar(bvd_to_bvar_s x t1_arg)) t1_arg in
                                    x, substitute_exp t1_proof x' bv_x in
                                let y = new_proof_bvd () in
                                let env = push_local_binding env (Binding_var ((x.realname), t1_arg)) in
                                let env = push_local_binding env (Binding_var ((y.realname), t1_proof)) in
                                let t2', k2 = derefine_typ env t2 in
                                let ktail = Kind_dcon(None, t1_proof, unbox k2) in
                                let tail = twithsort (Typ_lam(y, t1_proof, t2'))  ktail in
                                  Typ_lam(x, t1_arg, tail), Kind_dcon(None, t1_arg, ktail)
                            | _ -> fail (spr "Unexpected boxed type: %s" (Pretty.strTyp t1')))
                     | _ ->  fail (spr "Type function with unexpected non-star kinded argument: %s" (Pretty.strKind k1)))
              | _ -> 
                  let env = push_local_binding env (Binding_var (x.realname, t1')) in
                  let t2', k2 = derefine_typ env t2 in
                    Typ_lam(x, t1', t2'), Kind_dcon(None, t1', unbox k2)
          end

    | _ -> fail (spr "Unexpected type: %s" (Pretty.strTyp t)) in
  let maybe_box t (kopt: kind option) = match kopt with
    | None -> t, t.sort
    | Some (Kind_boxed k) when equivalent_kinds env k t.sort -> 
        let x = new_bvd None in
        let pf_true = twithsort (Typ_app(Const.pf_typ, Const.true_typ)) Kind_star in
        let t = twithsort (Typ_dtuple([(Some x, t); (None, pf_true)])) (Kind_boxed k) in
          t, Kind_boxed k
    | Some k when equivalent_kinds env k t.sort -> t, k
    | Some k ->
        fail (spr "Expected type of kind %s but got %s" (Pretty.strKind k) (Pretty.strKind t.sort)) in
  let env, kopt = clear_expected_kind env in
  let t', k = derefine_typ' (set_kind_level env) t.v in
  let t, k = maybe_box (twithsort t' k) kopt in
    whnf t, k

and derefine_match_default env def = match def.v with
  | Exp_ascribed({v=Exp_bot;sort=t';p=p} as ee, t, ev) -> 
      (* the only place Exp_bot is allowed is in the default case of a pattern match *)
      let t_def, k_def = derefine_typ env t in
      let def' = ascribe (setsort ee t_def) t_def ev in
        def', t_def, []
  | _ -> derefine_exp env def 

and derefine_exp env top_exp : (exp * typ * affines) = 
  let rec tc_app env ftyp arg : (list<exp*typ> * typ * affines) = match ftyp.v with 
    | Typ_affine ftyp' -> tc_app env ftyp' arg

    | Typ_fun (Some x, formal_typ, {v=Typ_fun(Some pf_x, pf_typ, rest_orig); sort=sort; p=_}) 
        when (is_proof_typ pf_typ && is_proof_bvd pf_x) -> 
        let arg', arg_typ, used_affines = derefine_exp (set_expected_typ env formal_typ) arg in (* should never be a boxed type *)
        let _ = if not (is_value arg') then fail (spr "Unexpected non-value in application: %s" (Pretty.strExp arg')) in
        let rest = substitute_exp rest_orig x arg' in
        let required_proof_typ = substitute_exp pf_typ x arg' in
        let pf_term = discharge_proof env required_proof_typ in
        let pf_term', pf_typ, pf_affines = pf_term, required_proof_typ, [] in          (* derefine_exp env' pf_term *) 
          if (pf_affines<>[]) then fail "Unexpected use of affine assumptions in a proof term"
          else [(arg', twithsort (Typ_fun(Some pf_x, required_proof_typ, rest)) sort); 
                (pf_term', rest)], rest, used_affines
    | Typ_fun (xopt, formal_typ, rest) -> 
        let arg', arg_typ, used_affines = derefine_exp (set_expected_typ env formal_typ) arg in (* should never be a boxed type *)
        let _ = if not (is_value arg') then 
          match xopt with 
            | None -> () (* ok, not a dependent function *)
            | Some x -> (* warning! this breaks A-normalization *)
                let _, xvs = freevarsTyp rest in
                  match List.tryFind (fun bv -> (bvar_real_name bv).idText = x.realname.idText) xvs with 
                      None -> ()
                    | _ -> fail (spr "Unexpected non-value in application: %s" (Pretty.strExp arg')) in
        let rest = match xopt with 
          | Some x -> substitute_exp rest x arg' 
          | None -> rest in
          [arg',rest], rest, used_affines
    | _ -> fail (spr "Expected function type in application; got %s" (Pretty.strTyp ftyp)) in
 let instantiate_datacon env cname targs phantoms = 
    if not (is_datacon env cname) then fail (spr "Expected a data constructor; got a free variable %s" (Pretty.str_of_lident cname.v));
    match lookup_fvar_with_params env cname with 
        None -> fail (spr "Constructor %s not found" (Pretty.str_of_lident cname.v))
      | Some (ctyp,tps) -> 
          let ctyp, a_targs' = 
            List.fold_left (fun (ctyp, targs) targ -> match ctyp.v with
                              | Typ_univ(a, k, _::_, t) -> raise Impos
                              | Typ_univ(a, k, [], t) -> 
                                  let targ', karg = derefine_typ env targ in
                                    if equivalent_kinds env karg k then
                                      let t' = substitute t a targ' in
                                        t', (a, targ')::targs
                                    else fail "Type argument kind mismatch") (ctyp, []) targs in
          let tps = List.map (function Tparam_term(bvd,t) ->
                                let t = substitute_l t a_targs' in
                                  Tparam_term(bvd, t)) tps in
          let ctyp, phantoms' = 
            List.fold_left2 (fun (ctyp, phantoms) (Tparam_term(bvd, t)) phantom -> 
                               let p, t', _ = derefine_exp env phantom in 
                               let ctyp' = if not (equivalent env t t') then 
                                 (fail (spr "Computed phantom argument has the wrong type"))
                               else substitute_exp ctyp bvd p in
                                 (ctyp', p::phantoms)) (ctyp,[]) tps phantoms in

          let cname = setsort cname ctyp in
            cname, ctyp, List.rev (snd (List.unzip a_targs')), List.rev phantoms' in
  let derefine_exp' cet env = function
    | Exp_bvar bv -> 
        let t = lookup_bvar env bv in
        let result = (match t.sort(* .u *) with 
                        | Kind_affine -> Exp_bvar (setsort bv t), t, [bv]
                        | _ -> Exp_bvar (setsort bv t), t, []) in
          cet result
            
    | Exp_fvar(fv,eref) -> 
        if Tcenv.is_datacon env fv then fail (spr "%s is a data constructor but is used as a free variable\n" (Pretty.str_of_lident fv.v));
        let t = match lookup_fvar env fv with
            Some t -> t 
          | None -> fail (spr "Free variable type not found: %s" (Pretty.str_of_lident fv.v)) in
          cet (Exp_fvar (setsort fv t, eref), t, [])

    | Exp_constant c -> cet (Exp_constant c, typing_const env c, [])
        
    | Exp_constr_app(cname, [t1;t2], [], [e1;e2]) 
        when Const.is_tuple_data_lid cname.v && 
          (is_some (recall_expected_typ env)) -> 
        let expected_typ = must (recall_expected_typ env) in
        let cname = match lookup_fvar env cname with 
            None -> raise Impos
          | Some t -> setsort cname t in
(*         let _ = Printf.printf "Reached tuple constructor with expected type = %s\n" (Pretty.strTyp expected_typ) in *)
(*         let _ = Printf.printf "Reached tuple constructor with expressions (%s, %s)\n" (Pretty.strExp e1)  (Pretty.strExp e2) in *)
        let e1', t1', used_affines_1 = derefine_exp env e1 in
        let e, (t, used_affines_2) = 
          match expected_typ.v with 
            | Typ_dtuple([(Some x, t1); (None, ({v=Typ_dtuple([(Some pf_x, pf_t); (_, rest)]); sort=_;p=_} as tinner))]) 
                when (is_proof_typ pf_t && is_proof_bvd pf_x) -> 
                let mk_nested_tuple env x1exp = (* TODO: A-normalize nested tuples? *)
                  let pf_typ = substitute_exp pf_t x x1exp in
                  let pf_term = discharge_proof env pf_typ in
                  let rest_typ = substitute_exp rest x x1exp in
                  let env = set_expected_typ env rest_typ in
                  let e2', t2', used_affines_2 = derefine_exp env e2 in
                  let einner = mk_tuple_exp env pf_term e2' tinner in
                  let e = mk_tuple_exp env x1exp einner expected_typ in
                    e, (expected_typ, used_affines_2) in
                  (match t1'.sort(* .u *), t1'.v with 
                     | Kind_boxed _, Typ_dtuple([(Some _x, _t1); (_, _pf_t)]) -> 
                         if equivalent env _t1 t1 then
                           unpack_deptuple env e1' (fun env x1 _ -> (mk_nested_tuple env (bvar_to_exp x1)))
                         else fet top_exp t1 _t1
                     | _ -> 
                         if equivalent env t1' t1 then mk_nested_tuple env e1'
                         else fet top_exp t1 t1')
            | Typ_dtuple([(bvd_opt, texp_1); (None, texp_2)]) -> 
                let mk_tuple env x1 = 
                  let texp_2 = match bvd_opt with 
                    | Some x when Tcutil.is_xvar_free x texp_2 ->
                        if not (is_value x1) then 
                          fail (spr "Unexpected non-value in packing dependent tuple: %s" (Pretty.strExp x1))
                        else substitute_exp texp_2 x x1
                    | _ -> texp_2 in
                  let e2', t2', used_affines_2 = derefine_exp (set_expected_typ env texp_2) e2 in
                  let e = mk_tuple_exp env x1 e2' expected_typ in
                    e, (expected_typ, used_affines_2) in
                  (match t1'.sort(* .u *), t1.v with 
                     | Kind_boxed _, Typ_dtuple([(Some _x, _t1); (_, _pf_t)]) -> 
                         if equivalent env _t1 t1 then
                           unpack_deptuple env e1' (fun env x1 _ -> (mk_tuple env (bvar_to_exp x1)))
                         else fet top_exp t1 _t1
                     | _ ->
                         if equivalent env t1' texp_1 then mk_tuple env e1'
                         else fet top_exp t1 texp_1)
            | _ -> fail (spr "Unexpected expected type! %s " (Pretty.strTyp expected_typ)) in
        let used_affines = used_affines_1 @ used_affines_2 in
        let _ = disjoint_affine_usages used_affines in
          cet (e.v, t, used_affines)
            
    | Exp_constr_app(cname, targs, phantoms, eargs) ->
        let cname, ctyp, targs', phantoms' = instantiate_datacon env cname targs phantoms in 
        let eargs', ret_typ, used_affines =
          List.fold_left (fun (eargs, ctyp, used_affines_l) arg -> 
                            let args', ret_type, used_affines = tc_app env ctyp arg in
                              eargs@args', ret_type, used_affines@used_affines_l) ([], ctyp, []) eargs in
        let _ = Tcutil.disjoint_affine_usages used_affines in
          (match ret_typ.v with 
               Typ_fun _
             | Typ_univ _ -> fail (spr "Data constructor is not fully applied: %s" (Pretty.strExp top_exp))
             | _ -> 
                 let eargs' = List.map fst eargs' in          
                   cet (Exp_constr_app(cname, targs', phantoms', eargs'), ret_typ, used_affines))
    
    | Exp_primop(op, args) -> 
        (match lookup_operator env op with
           | None -> raise (Err ("Unknown operator: "^op.idText))
           | Some t -> 
               let args, result_typ, used_affines = List.fold_left 
                 (fun (args, t, affines) arg -> 
                    let args', ret_typ, used_affines = tc_app env t arg in
                      args@args', ret_typ, used_affines@affines) ([], t, []) args in
               let _ = Tcutil.disjoint_affine_usages used_affines in
                 (match result_typ.v with 
                      Typ_fun _ -> fail (spr "Operator is not fully applied: %s" (Pretty.strExp top_exp))
                    | _ -> 
                        cet (Exp_primop(op, List.map fst args), result_typ, used_affines)))
          
    | Exp_abs(x, t_arg, body) -> 
        let t_arg, karg = derefine_typ env t_arg in
        let result = match karg(* .u *) with 
          | Kind_star
          | Kind_affine -> 
              let env' = push_local_binding env (Binding_var (x.realname, t_arg)) in
              let body, t_body, used_affines = derefine_exp env' body in 
              let t_body = match used_affines, t_body.sort(* .u *) with 
                | hd::tl, Kind_star when is_closure_typ env' t_body -> twithsort (Typ_affine t_body) Kind_affine
                | _  -> t_body in
              let used_affines = subtract used_affines [bvd_to_bvar_s x t_arg] in
              let typ = twithsort (Typ_fun (Some x, t_arg, t_body)) Kind_star in
                Exp_abs (x, t_arg, body), typ, used_affines
                  
          | Kind_boxed Kind_star -> 
              (match t_arg.v with 
                 | Typ_dtuple([(Some x', t_arg); (None, t_proof)]) -> 
                     let xvar = ewithsort (Exp_bvar (bvd_to_bvar_s x t_arg)) t_arg in
                     let t_proof = substitute_exp t_proof x' xvar in
                     let y = new_proof_bvd () in
                     let env' = push_local_binding env (Binding_var (x.realname, t_arg)) in
                     let env' = push_local_binding env' (Binding_var (y.realname, t_proof)) in
                     let body, t_body, used_affines = derefine_exp env' body in 
                     let body, t_body = match used_affines, t_body.sort(* .u *) with 
                       | hd::tl, Kind_star when is_closure_typ env' t_body -> 
                           let a_t_body = twithsort (Typ_affine t_body) Kind_affine in
                           let body = setsort body a_t_body in
                             body, a_t_body 
                       | _  -> body, t_body in
                     let used_affines = subtract used_affines [bvd_to_bvar_s x t_arg] in
                     let rest_t = twithsort (Typ_fun(Some y, t_proof, t_body)) Kind_star in
                     let rest_e = ewithsort (Exp_abs(y, t_proof, body)) rest_t in
                     let typ = twithsort (Typ_fun (Some x, t_arg, rest_t)) Kind_star in
                       Exp_abs (x, t_arg, rest_e), typ, used_affines
                 | _ -> raise Impos)
          | Kind_boxed Kind_affine -> raise (NYI "Special case of derefinement: affine refinement types") in
          cet result
            
    | Exp_tabs(a, k, formulas, body) -> 
        let k = 
          if Tcutil.kind_abstractable top_exp.p k then derefine_kind env k 
          else fail (spr "Abstraction over %s-kinded types is not supported" (Pretty.strKind k)) in
        let env' = push_local_binding env (Binding_typ (a.realname, k)) in
        let body, t_body, used_affines = derefine_exp env' body in
        let body, t_body = match used_affines, t_body.sort(* .u *) with 
          | hd::tl, Kind_star when is_closure_typ env' t_body -> 
              let a_t_body = twithsort (Typ_affine t_body) Kind_affine in
              let body = setsort body a_t_body in
                body, a_t_body 
          | _  -> body, t_body in
        let formulas = List.map (fun t -> fst (derefine_typ env' t)) formulas in
        let typ = twithsort (Typ_univ(a, k, formulas, t_body)) Kind_star in
          cet (Exp_tabs(a, k, formulas, body), typ, used_affines)

    | Exp_app(e1, e2) -> 
        let e1', t1, used_affines_1 = derefine_exp env e1 in
        let args, ret_typ, used_affines_2 = tc_app env t1 e2 in
        let app = List.fold_left (fun f (arg, rest_t) -> ewithsort (Exp_app(f, arg)) rest_t) e1' args in
        let used_affines = used_affines_1@used_affines_2 in
        let _ = disjoint_affine_usages used_affines in
          cet (app.v, ret_typ, used_affines)

    | Exp_tapp(e, targ) -> 
        let e', t_e, used_affines = derefine_exp env e in
        let targ', karg = derefine_typ env targ in
        let res_typ = match t_e.v with 
          | Typ_univ(a, k', _, t) 
          | Typ_affine({v=Typ_univ(a, k', _, t); sort=_; p=_}) when (equivalent_kinds env karg k') -> substitute t a targ' 
          | _ -> fail (spr "In (%s)\nEither type application does not respect kinds, or type application to a value with a non-quantified type\n"
                         (Pretty.strExp top_exp)) in
          cet (Exp_tapp(e', targ'), res_typ, used_affines)

    | Exp_match(e, eqns, def) when Tcutil.is_tuple_typ e.sort -> 
        let e', t_e, used_affines_e = derefine_exp env e in
        let def', t_def, used_affines_def = derefine_match_default env def in
        let eqn, used_affines_b = match t_e.v with 
          | Typ_dtuple ([(Some x, t1); (_, ({v=Typ_dtuple([(Some pf_x, pf_t); (_, rest)]); sort=_; p=_} as t2))]) 
              when (is_proof_typ pf_t && is_proof_bvd pf_x) -> 
              let [Pat_variant(lid, targs, [], [xx_var; yy_var], __GADT_FLAG_IGNORED), branch] = eqns in
              let xx_var = setsort xx_var t1 in
              let xx_exp = bvar_to_exp xx_var in
              let t2' = substitute_exp t2 x xx_exp in
              let xx_2 = new_bvd None in
              let xx_2_var = bvd_to_bvar_s xx_2 t2' in
              let xx_2_exp = bvd_to_exp xx_2 t2' in
              let exp = mk_tuple_exp env xx_exp xx_2_exp t_e in
              let bindings = [Binding_var (bvar_real_name xx_var, t1);
                              Binding_var (bvar_real_name xx_2_var, t2');
                              Binding_match (e', exp)] in
              let env = List.fold_left push_local_binding env bindings in
              let builder env pf_var rest_var =
                let env = set_expected_typ env t_def in
                let branch, tosub = match rest_var.sort.sort(* .u *) with 
                  | Kind_boxed _ -> (* special case of a tuple like (t * {x:t | P x}) which ends with a refinement *)
                      let builder env yy_var yy_pf_var = branch, [yy_pf_var] in
                      let branch, tosub = unpack_deptuple_names env (bvar_to_exp rest_var) (bvar_to_bvd yy_var) (new_bvd None) builder in
                        branch, tosub
                  | _ -> branch, [] in
                let branch', t_branch, used_affines_b = derefine_exp env branch in
                let used_affines_b = subtract used_affines_b (tosub@[pf_var; yy_var; xx_var]) in
                  branch', used_affines_b in
              let rhs_name = match rest.sort(* .u *)with 
                | Kind_boxed _ -> new_bvd None
                | _ -> bvar_to_bvd yy_var in
              let branch', used_affines_b = unpack_deptuple_names env xx_2_exp (new_bvd None) rhs_name builder in
              let pat = Pat_variant(lid, [t1;t2], [], [xx_var; xx_2_var], GADT_FLAG_IGNORED) in
                (pat, branch'), used_affines_b

          | Typ_dtuple([(xopt, t1); (_, t2)]) when is_boxed t2.sort -> 
              let [Pat_variant(lid, targs, [], [xx; yy], __GADT_FLAG_IGNORED), branch] = eqns in
              let xx = setsort xx t1 in
              let trhs = match xopt with 
                | None -> t2 
                | Some x -> substitute_exp t2 x (bvar_to_exp xx) in
              let zz = bvd_to_bvar_s (new_bvd None) trhs in
              let bindings = [Binding_var (bvar_real_name xx, t1);
                              Binding_var (bvar_real_name zz, zz.sort); 
                              Binding_match (e', mk_tuple_exp env (bvar_to_exp zz) (bvar_to_exp zz) e.sort)] in
              let env = List.fold_left push_local_binding env bindings in
              let builder env yy pf = 
                let branch', t_branch, used_affines_b = derefine_exp (set_expected_typ env t_def) branch in
                let used_affines_b = subtract used_affines_b [yy; pf; zz; xx] in
                  branch', used_affines_b in
              let branch', used_affines_b = unpack_deptuple_names env (bvar_to_exp zz) (bvar_to_bvd yy) (new_bvd None) builder in
              let pat = Pat_variant(lid, [t2; trhs], [], [xx;zz], GADT_FLAG_IGNORED) in
                (pat, branch'), used_affines_b
                  
          | Typ_dtuple([(xopt, t1); (_, t2)]) -> 
              let [Pat_variant(lid, targs, [], [xx; yy], __GADT_FLAG_IGNORED), branch] = eqns in
              let xx = setsort xx t1 in
              let yy = match xopt with 
                  None -> setsort yy t2
                | Some x -> 
                    let t2' = substitute_exp t2 x (bvar_to_exp xx) in
                      setsort yy t2'  in
              let pat_exp = mk_tuple_exp env (bvar_to_exp xx) (bvar_to_exp yy) e'.sort in
              let bindings = [Binding_var (bvar_real_name xx, t1);
                              Binding_var (bvar_real_name yy, yy.sort);
                              Binding_match (e', pat_exp)] in
              let env = List.fold_left push_local_binding env bindings in
              let branch, t_branch, used_affines_b = derefine_exp (set_expected_typ env t_def) branch in
              let used_affines_b = subtract used_affines_b [xx;yy] in
              let pat = Pat_variant(lid, targs, [], [xx;yy], GADT_FLAG_IGNORED) in
                (pat, branch), used_affines_b
          | _ -> fail ("Unexpected branches in tuple unpack") in
        let used_affines = used_affines_e @ (union used_affines_def used_affines_b) in
        let _ = disjoint_affine_usages used_affines in
        let mexp = Exp_match(e', [eqn], def') in
          cet (mexp, t_def, used_affines)
            
    | Exp_match(e, eqns, def) -> 
        let e', t_e, used_affines_e = derefine_exp env e in
        let def', t_def, used_affines_def = derefine_match_default env def in 
        let env = set_expected_typ env t_def in
        let eqns', used_affines_l = List.unzip
          (List.map
             (fun (Pat_variant(lid, targs, phantoms, bvars, __GADT_FLAG_IGNORED), branch) -> 
                let cname, ctyp, targs', phantoms' = instantiate_datacon env (Wfv lid) targs phantoms in
                let check_branch env =  
                  let branch', t_branch, used_affines_b = derefine_exp env branch in 
                    branch', (t_branch, used_affines_b) in
                let final_typ, bvars_rev, env, check_branch = List.fold_left 
                  (fun (ctyp, bvars, env, unpack) bv -> match ctyp.v with 
                     | Typ_fun (Some x, tformal, {v=Typ_fun(Some pf_x, pf_t, tret); sort=_; p=_}) 
                         when (is_proof_typ pf_t && is_proof_bvd pf_x) -> 
                         let _ = if is_boxed tformal.sort then fail "Unexpected boxed parameter" in
                         let bv = setsort bv tformal in
                         let bvexp = (bvar_to_exp bv) in
                         let pf_t' = substitute_exp pf_t x bvexp in
                         let bv' = bvd_to_bvar_s (new_bvd None) pf_t' in
                         let tret = substitute_exp tret x bvexp in
                         let bindings = [Binding_var (bvar_real_name bv, tformal);
                                         Binding_var (bvar_real_name bv', pf_t')] in
                         let env' = List.fold_left push_local_binding env bindings in
                           tret, bv'::bv::bvars, env', unpack
                     | Typ_fun (xopt, tformal, tret) -> 
                         if is_boxed tformal.sort then
                           let bv' = new_bvd None in
                           let bv'_exp = bvd_to_exp bv' tformal in
                           let tret = match xopt with 
                             | None -> tret 
                             | Some x -> substitute_exp tret x bv'_exp in
                           let env' = push_local_binding env (Binding_var (bv'.realname, tformal)) in
                           let unpack = (fun env -> 
                                           unpack_deptuple_names env bv'_exp (bvar_to_bvd bv) (new_bvd None) 
                                             (fun env _ _ -> unpack env)) in
                             tret, (bvwithsort bv' tformal)::bvars, env', unpack
                         else
                           (* TODO: if tformal is boxed, then rename x and insert an unpack in the branch *)
                           let bv = setsort bv tformal in
                           let tret = match xopt with 
                               None -> tret 
                             | Some x -> 
                                 let bvexp = ewithsort (Exp_bvar bv) tformal in
                                   substitute_exp tret x bvexp in
                           let env' = push_local_binding env (Binding_var (bvar_real_name bv, tformal)) in
                             tret, bv::bvars, env', unpack
                     | _ -> fail ("Insufficient pattern variables")) (ctyp, [], env, check_branch) bvars  in
                let bvars' = List.rev bvars_rev in
                let pat_exp = Exp_constr_app(cname, 
                                             targs', 
                                             phantoms', 
                                             List.map (fun bv -> ewithsort (Exp_bvar bv) bv.sort) bvars') in
                let env = match TypeRelations.equivalent_with_equations env bvars' final_typ t_e with
                  | None -> fail ("Unable to equate pattern type with type of scrutinee")
                  | Some equations -> 
                      let env = List.fold_left push_local_binding env equations in
                      let pat_exp = ewithsort pat_exp t_e in
                      let bn = Binding_match (e, pat_exp) in
                        push_local_binding env bn in
                let branch, (t_branch, used_affines_b) = check_branch env in
                let pat = Pat_variant(lid, targs', phantoms', bvars', GADT_FLAG_IGNORED) in
                  (pat, branch), (subtract used_affines_b bvars')) eqns) in
        let used_affines_branches = List.fold_left union used_affines_def used_affines_l in
        let _ = disjoint_affine_usages (used_affines_e@used_affines_branches) in
          cet (Exp_match(e', eqns', def'), t_def, used_affines_e@used_affines_branches)

    | Exp_cond (e1, e2, e3) -> 
        let e1', t1, used_affines_1 = derefine_exp (set_expected_typ env Const.bool_typ) e1 in
        let env_true = push_local_binding env (Binding_match(e1', Const.exp_true_bool)) in
        let env_false = push_local_binding env (Binding_match(e1', Const.exp_false_bool)) in
        let e2', t2, used_affines_2 = derefine_exp env_true e2 in
        let e3', t3, used_affines_3 = derefine_exp (set_expected_typ env_false t2) e3 in
        let used_affines = used_affines_1 @ (union used_affines_2 used_affines_3) in
        let _ = disjoint_affine_usages used_affines in        
          cet (Exp_cond(e1', e2', e3'), t2, used_affines)
            
    | Exp_recd (Some lid, targs, phantoms, fn_e_l) -> 
        let _, recname, tps, rectyp = lookup_record_typ_by_name env lid in
        let rect, targs' = List.fold_left 
          (fun (rect, targs') t -> 
             let t', k = derefine_typ env t in 
               match rect.sort(* .u *)with 
                 | Kind_tcon(aopt, k', k'') when force_kind_convertible env k k' -> 
                    let k'' = open_kind rect.sort t' in 
                      twithsort (Typ_app(rect, t')) k'', t'::targs'
                 | _ -> fail (spr "Expected argument to a type constructor of kind %s; got %s" 
                                (Pretty.strKind rect.sort) (Pretty.strKind k))) (recname,[]) targs in
        let rect, phantoms' = List.fold_left 
          (fun (rect, phantoms') e ->
             let e', t, _ = derefine_exp env e in
               match rect.sort(* .u *)with 
                 | Kind_dcon(xopt, t', k) when equivalent env t t' -> (* Q: Why not subtyping here? *)
                     let k = open_kind_with_exp rect.sort e' in
                        twithsort (Typ_dep(rect, e')) k, e'::phantoms'
                 | _ -> fail (spr "Expected a phantom arg to a type constructor of kind %s; got %s" 
                                (Pretty.strKind rect.sort) (Pretty.strTyp t))) (rect,[]) phantoms in
        let targs' = List.rev targs' in
        let phantoms' = List.rev phantoms' in
        let record = instantiate_tparams rectyp tps targs' phantoms' in
        let fn_e_l, used_affines = List.fold_left 
          (fun (fn_e_l, affines) (fn, e) -> 
             let t = Tcutil.lookup_field_in_record_typ e.p env fn record in
             let env = set_expected_typ env t in
             let e', t_e, used_affines = derefine_exp env e in 
               (fn, e')::fn_e_l, used_affines@affines) ([], []) fn_e_l in
        let _ = disjoint_affine_usages used_affines in
          cet (Exp_recd(Some lid, targs', phantoms', List.rev fn_e_l), rect, used_affines)
            
    | Exp_proj(e, fn) when (Sugar.lid_equals fn Const.tuple_proj_one) -> 
        let e', tuple_t, used_affines = derefine_exp env e in
        let result_typ = match tuple_t.v with 
          | Typ_dtuple[(_,t1);_] -> t1 
          | _ -> fail (spr "Expected a tuple type; got %s" (Pretty.strTyp tuple_t)) in
          cet (Exp_proj(e', fn), result_typ, used_affines)

    | Exp_proj(e, fn) when (Sugar.lid_equals fn Const.tuple_proj_two) -> 
        let e', tuple_t, used_affines = derefine_exp env e in
        let result_typ = match tuple_t.v with 
          | Typ_dtuple[(None, t1);(_, t2)] -> t2
          | Typ_dtuple[(Some x, _);(_, t2)] -> 
              let _, fvs = freevarsTyp t2 in
                (match List.tryFind (fun bv -> (bvar_real_name bv).idText = (x.realname).idText) fvs with
                     None -> t2
                   | _ -> fail (spr "Projection of second field of a dependent tuple is not allowed"))
          | _ -> fail (spr "Expected a tuple type; got %s" (Pretty.strTyp tuple_t)) in
          cet (Exp_proj(e', fn), result_typ, used_affines)
            
    | Exp_proj(e, fn) -> 
        let e', rectyp, used_affines_1 = derefine_exp env e in
        let field_typ = Tcutil.lookup_field_in_record_typ e.p env fn rectyp in
        let fst = Exp_proj(e', fn) in
        let genEq = not (is_kind_level env) && match recall_expected_typ env with
          | Some {v=_;sort=Kind_boxed _; p=_} -> true
          | _ -> false in
        let result = if genEq then 
          let eqT = Tcutil.eqT_of_typ env field_typ in
          let refl = reflexivity_var env in
          let eqT, k = derefine_typ env eqT in
          let k' = match k(* .u *)with 
            | Kind_dcon(_, t, k') -> k' 
            | _ -> raise Impos in
          let bvd = new_bvd None in 
          let eq_typ = twithsort (Typ_app(Const.pf_typ, 
                                         (twithsort (Typ_dep((twithsort (Typ_dep(eqT, bvd_to_exp bvd field_typ)) k'), 
                                                            (ewithsort (Exp_proj(e',fn)) field_typ))) Kind_star))) Kind_star in
          let tuple_t = twithsort (Typ_dtuple([(Some bvd, field_typ); (None, eq_typ)])) (Kind_boxed field_typ.sort) in
          let fst = ewithinfo fst field_typ top_exp.p in
          let snd = ewithsort (Exp_constr_app(refl, [field_typ], [], [fst])) eq_typ in
          let tuple_cons = Const.tuple_data_lid field_typ.sort eq_typ.sort in
          let tuple_cons_typ = Tcenv.lookup_lid env tuple_cons in
          let package = ewithsort (Exp_constr_app(fvwithsort tuple_cons tuple_cons_typ, 
                                                 [field_typ; eq_typ], [], [fst; snd])) tuple_t in
          let package = ascribe package tuple_t [] in
            package.v, tuple_t, used_affines_1
        else fst, field_typ, used_affines_1 in
          cet result

    | Exp_let (false, [(x, t_x, e)], body) -> 
        let t_x', k_x = derefine_typ env t_x in
        let e', t_e, used_affines_1 = derefine_exp (set_expected_typ env t_x') e in
        let result = match k_x(* .u *)with 
          | Kind_boxed _ -> 
              (match t_e.sort(* .u *)with
                 | Kind_boxed _ -> ()
                 | _ -> 
                     (printfn "%A" (spr "Unexpected kinds in Exp_let before derefinement: %s, %s" (Pretty.strTyp t_x) (Pretty.strExp e));
                      printfn "%A" (spr "Unexpected kinds in Exp_let after derefinement: %s, %s" (Pretty.strTyp t_e) (Pretty.strExp e'))));
              let builder env xvar pf_x = 
                let body, t_body, used_affines_2 = derefine_exp env body in
                  body, (t_body, subtract used_affines_2 [xvar; pf_x]) in
              let z = new_bvd None in
              let zexp = bvd_to_exp z t_e in
              let bindings = [Binding_var(z.realname, t_e);
                              Binding_match(zexp, e')] in
              let env = List.fold_left push_local_binding env bindings in
              let body', (t_body, used_affines_2) = unpack_deptuple_names env zexp x (new_proof_bvd()) builder in
              let used_affines = used_affines_1@used_affines_2 in
              let _ = disjoint_affine_usages used_affines in
                Exp_let(false, [(z, t_e, e')], body'), t_body, subtract used_affines [bvd_to_bvar_s z t_e]
          | _ -> 
              let xexp = bvd_to_exp x t_x' in
              let env = push_local_binding env (Binding_var (x.realname, t_x')) in
              let env = push_local_binding env (Binding_match (xexp, e')) in
              let body', t_body, used_affines_2 = derefine_exp env body in
              let used_affines= used_affines_1@(subtract used_affines_2 [bvd_to_bvar_s x t_x']) in
              let _ = disjoint_affine_usages used_affines in
                Exp_let(false, [(x, t_x', e')], body'), t_body, used_affines in
          cet result

(*     | Exp_bot  ->  Exp_bot, Typ_unknown, [] *)

(*     | Exp_ascribed({v=Exp_bot; sort=_; p=_}, t, _) -> *)
(*         let t', k = derefine_typ env t in *)
(*           cet (Exp_ascribed (withsort Exp_bot t', t', []), t', []) *)

    | Exp_ascribed(e, t, ev) -> 
        if List.length ev <> 0 then raise Impos;
        let env, topt = clear_expected_typ env in
        let t', k' = derefine_typ env t in
        let env = set_expected_typ env t' in
        let e', t_e, used_affines = derefine_exp env e in
          cet ((ascribe e' t' []).v, t', used_affines)

    | e -> printfn "%A" e; raise (Bad "Unexpected expression form in derefinement") in

  let env, topt = clear_expected_typ env in
  let cet (e', t, a) = 
    let is_boxed = function Kind_boxed _ -> true | _ -> false in
    let check_expected_typ env e te texpected = 
      match TypeRelations.equivalent_with_evidence env te texpected with 
        | Some ev -> ascribe e texpected ev 
        | _ -> 
            if not (is_boxed te.sort) && (is_boxed texpected.sort) then
             match texpected.v with 
                | Typ_dtuple([(xopt, te'); (_, t_pf)]) -> 
                    match TypeRelations.equivalent_with_evidence env te te' with
                        | Some ev -> 
                            (match xopt with 
                               | Some x -> 
                                  let e = ascribe e te' ev in
                                  let t_pf = substitute_exp t_pf x e in
                                  let pf_term = discharge_proof env t_pf in
                                    mk_tuple_exp env e pf_term texpected 
                               | None -> fet top_exp te' te)
            | _ -> raise Impos
        else if (is_boxed te.sort) && (is_boxed texpected.sort) then
        match te.v, texpected.v with
          | Typ_dtuple([(Some x1, t1); (_, pf1)]), Typ_dtuple([(Some x2, t2); (_, pf2)]) ->
              if equivalent env t1 t2 then
                let rebox env x y = 
                  let x_exp = bvar_to_exp x in
                  let y_exp = bvar_to_exp y in
                  let pf2' = substitute_exp pf2 x2 x_exp in 
                  let pf_term = discharge_proof env pf2' in
                  let box = mk_tuple_exp env x_exp pf_term texpected in
                    box, () in
                let ee, _ = unpack_deptuple env e rebox in
                  ee
              else fet top_exp t2 t1
          | _ -> raise Impos
        else fet top_exp texpected te in
    let e' = ewithsort e' t in
    let e' = profile (fun () -> collect_evidence e') collect_ctr in
      match topt with 
          None -> e', t, a
        | Some t' -> check_expected_typ (set_current_value env e') e' t t', t', a  in
  let top_exp = match topt with  (* remove redundant/stale type ascriptions, if any *)
      None -> top_exp
    | Some t -> unascribe top_exp in
    try 
      let res = derefine_exp' cet env top_exp.v in (* make this a tail call to prevent stack overflow on large proof terms? *)
        (if is_marked top_exp then 
           let _, t, _ = res in
             pr "Type of expression marked (%s): %s\n" (get_marker top_exp) (Pretty.strTyp t));
        res
    with 
      | ex when
          (if is_marked top_exp then (pr "Derefinement threw exception at expression with marker %s" (get_marker top_exp); false)
           else false) -> raise ex
          
let derefine_let_binding env (b:letbinding*bool) : env*(letbinding*bool) = match b with
  | [x,t,e], false -> 
      let t', k = derefine_typ env t in
      let qname = asLid <| (current_module env).lid @ [x.ppname] in (* the only case where the pp name is actually used *)
      let val_decl_t = lookup_lid env qname in
        if not (equivalent env val_decl_t t') then 
          fail (spr "Annotated type\n %s \nand inferred type\n %s\ndiffer!" (Pretty.strTyp val_decl_t) (Pretty.strTyp t'));
        (match k(* .u *)with 
           | Kind_boxed _ -> fail (spr "Top-level values cannot have refined types: %s" (x.realname).idText)
           | _ -> 
               let env = set_expected_typ env t' in
               let e', _, _ = derefine_exp env e in (* TODO: check that affines=[]? *)
               let env' = push_local_binding env (Binding_var (x.realname, t')) in
               let lb = [x, t', e'] in
                 env',(lb,false))

  | [x,t,e], true -> 
      let t', k = derefine_typ env t in
        (match k(* .u *)with 
           | Kind_star -> 
               let env = push_local_binding env (Binding_var(x.realname, t')) in
               let env = set_expected_typ env t' in
               let e', _, _ = derefine_exp env e in (* TODO: check that affines=[]? *)
               let lb = [x, t', e'] in
                 env, (lb,true)
           | _ -> fail (spr "Top-level recursive bindings cannot have refined or affine types: %s" (x.realname).idText))
          
  | lbs, true -> 
      let env, lbs' = List.fold_left 
        (fun (env, lbs) (x,t,e) -> 
           let t', k' = derefine_typ env t in
             match k'(* .u *)with 
               | Kind_star -> 
                   let env = push_local_binding env (Binding_var(x.realname, t')) in
                     env, (x,t',e)::lbs
               | _ -> 
                   fail (spr "Top-level recursive bindings cannot have refined or affine types: %s" (x.realname).idText))
        (env, []) lbs in
      let lbs' = List.rev lbs' in
      let lbs' = List.map (fun (x,t,e) ->
                             let env = set_expected_typ env t in
                             let e', _, _ = derefine_exp env e in
                               (x, t, e')) lbs' in
        env, (lbs', true)
          
let derefine_signature env s : env*signature = 
  let derefine_tparams env tps = 
    List.map (function
                | Tparam_typ(bvd,k) -> 
                    let k' = derefine_kind env k in
                      Tparam_typ(bvd, k')
                | Tparam_term(bvd,t) ->
                    let t', _ = derefine_typ env t in
                      Tparam_term(bvd, t')) tps in
  let rec derefine_sigelt env = function
    | Sig_tycon_kind (lid, tps, k, isProp, muts, tags) -> 
        let tps' = derefine_tparams env tps in
          (*         let _ = Printf.printf "About to derefine kind %s\n Environment is: " (Pretty.strKind k) in *)
          (*         let _ = printfn "%A" env in *)
        let env = Tcutil.push_tparams env tps' in
        let k' = derefine_kind env k in
          Sig_tycon_kind(lid, tps', k', isProp, muts, tags)
            
    | Sig_typ_abbrev (lid, tps, k, t) -> 
        let tps' = derefine_tparams env tps in
        let env = Tcutil.push_tparams env tps' in
        let k = derefine_kind env k in
        let t', k' = derefine_typ env t in
          if equivalent_kinds env k k' then 
            Sig_typ_abbrev(lid, tps', k, t')
          else (fail (spr "Expected kind %s; got %s\n" (Pretty.strKind k) (Pretty.strKind k')))

    | Sig_record_typ (lid, tps, k, t, eref) -> 
        let tps' = derefine_tparams env tps in
        let env = Tcutil.push_tparams env tps' in
        let k = derefine_kind env k in
        let t', k' = derefine_typ env t in
          if equivalent_kinds env k k' then 
            Sig_record_typ(lid, tps', k, t', eref)
          else (fail (spr "Expected kind %s; got %s\n" (Pretty.strKind k) (Pretty.strKind k')))

    | Sig_datacon_typ (lid, tps, t, b, a, tcn, eref, pats) -> (* TODO: Handle pats here *)
        let tps' = derefine_tparams env tps in
        let env = Tcutil.push_tparams env tps' in
        let t', _ = derefine_typ env t in
          Sig_datacon_typ(lid, tps', t', b, a, tcn, eref, pats)

    | Sig_value_decl (lid, t) -> 
        let t', _ = derefine_typ env t in
          Sig_value_decl(lid, t')

    | Sig_extern_value (eref, lid, t) -> 
        let t', _ = derefine_typ env t in
          Sig_extern_value (eref, lid, t')
            
    | Sig_extern_typ (eref, s) -> 
        let s' = derefine_sigelt env s in
          Sig_extern_typ (eref, s') in
  let env, sig' =
    List.fold_left (fun (env, outsig) sigelt -> 
                      let sigelt' = derefine_sigelt env sigelt in
                      let env' = push_sigelt env sigelt' in
                        env', sigelt'::outsig) (env, []) s in
    env, List.rev sig'
    
let derefine_modul env m : modul = 
  try  
(*     let _ = (if not (Sugar.lid_equals m.name Const.prims_lid) then (Printf.printf "Source typechecked module:\n"; Pretty.printModule m)) in *)
(*     let _ = (if not (Sugar.lid_equals m.name Const.prims_lid) then (Printf.printf "Raw source typechecked module:\n"; printfn "%A" m)) in *)
    Printf.printf "Derefining %s ..." (Pretty.str_of_lident m.name);
    let env = set_derefinement_phase env in
    let env, sig' = derefine_signature env m.signature in
    let env, bindings' = List.fold_left 
      (fun (env, out) binding -> 
         let env', binding' = derefine_let_binding env binding in
           env', binding'::out) (env,[]) m.letbindings in
    let main' = match m.main with 
      | None -> None
      | Some main -> 
          let env = set_expected_typ env Const.unit_typ in
          let main', t_main, used_affines = derefine_exp env main in
            Some main' in
    let m' = {name=m.name; extends=m.extends; pos=m.pos; signature=sig';
              letbindings=List.rev bindings'; main=main'; exports=sig'; pragmas=m.pragmas} in
(*     let _ = if (Pretty.str_of_lident m'.name <> "Prims") then Pretty.printModule m' in *)
      (*                printfn "%A" ("Type checked module", m')) in *)
      (* (Printf.printf "Source typechecked module:\n"; Pretty.printModule m')) in  *)
      Printf.printf "done.\n";
      m'
  with 
    | e when handleable e -> handle_err false () e; raise e
        
