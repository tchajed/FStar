#light "off"
// (c) Microsoft Corporation. All rights reserved

module Microsoft.FStar.Expandtyp

open Absyn
open KindAbbrevs

let expand_tparams env tps = 
  List.map (fun tp -> match tp with 
              | Tparam_typ _ -> tp
              | Tparam_term (bvd, t) -> 
                  let t = Tcenv.expand_typ_rec env t in
                    Tparam_term (bvd, t)) tps

let expand_typ env t = Tcenv.expand_typ_rec env t

let expand_exp env e = Tcenv.expand_exp_rec env e
  
let rec expand_kind env k = match k(* .u *) with
  | Kind_erasable
  | Kind_prop
  | Kind_star
  | Kind_affine -> k
  | Kind_tcon(aopt, k, k') -> 
      let k = expand_kind env k in 
      let env = match aopt with 
        | None -> env 
        | Some a -> Tcenv.push_local_binding env (Tcenv.Binding_typ(real_name a, k)) in
      let k' = expand_kind env k' in
        Kind_tcon(aopt, k, k')
  | Kind_dcon(xopt, t, k) -> 
      let t = expand_typ env t in 
      let env = match xopt with 
        | None -> env 
        | Some x -> Tcenv.push_local_binding env (Tcenv.Binding_var(real_name x, t)) in
      let k = expand_kind env k in
        Kind_dcon(xopt, t, k)
  | _ -> raise (Err (Util.spr "Unexpected bug: kind %s should not be present after type checking" (Pretty.strKind k)))

let rec expand_sigelt env = function
  | Sig_typ_abbrev _ -> 
      None

  | Sig_record_typ (lid, tps, kk, t, eref) -> 
      Some(Sig_record_typ(lid, expand_tparams env tps, expand_kind env kk, expand_typ env t, eref))

  | Sig_tycon_kind (lid, tps, k, b, muts, tags) -> 
      Some (Sig_tycon_kind(lid, expand_tparams env tps, expand_kind env k, b, muts, tags))
        
  | Sig_datacon_typ (lid, tps, t, b, aq, tcn, eref, pats) -> 
      Some (Sig_datacon_typ(lid, expand_tparams env tps, expand_typ env t, b, aq, tcn, eref, pats))

  | Sig_value_decl (lid, t) -> 
      Some (Sig_value_decl(lid, expand_typ env t))

  | Sig_logic_function (lid, t, tags) -> 
      Some (Sig_logic_function(lid, expand_typ env t, tags))

  | Sig_extern_value (lang, lid, t) ->
      Some (Sig_extern_value (lang, lid, expand_typ env t))

  | Sig_extern_typ(eref, s) -> 
      (match expand_sigelt env s with 
        | None -> Some (Sig_extern_typ (eref, s))
        | Some s -> Some (Sig_extern_typ (eref, s)))

  | Sig_query(lid, f) -> Some (Sig_query(lid, expand_typ env f))

  | Sig_ghost_assume(lid, t, aq) -> Some (Sig_ghost_assume(lid, expand_typ env t,  aq))
 
let expand_let_binding env lb =
  List.map (fun (bvd, t, e) -> 
              let t = expand_typ env t in
              let e = expand_exp env e in
                (bvd, t, e)) lb
    
let expand_typ_abbrevs env modul = 
  let env = Tcenv.clear_expand_externs env in
  let expandSigs sigs = 
     List.fold_right (fun sigelt sigout -> 
       match expand_sigelt env sigelt with
           None -> sigout
         | Some se -> se::sigout) modul.signature [] in
  let sigs = expandSigs modul.signature in
  let exps = expandSigs modul.exports in 
  let lbs = List.map 
    (fun (lb, b) -> 
       (expand_let_binding env lb, b)) modul.letbindings in
  let main = match modul.main with 
      None -> None
    | Some e -> Some (expand_exp env e) in
    {modul with signature=sigs; exports=exps; letbindings=lbs; main=main}
