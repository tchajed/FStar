﻿#light "off"

(*
  A translation that goes directly to JSMin
  
  Written in two phases:
  --First to JSMin via a "light" translation
  --Then add wrappers on generated JSMin

  Currently, we handle only the following source language:

  v ::= x | () | D t1..tn v1..vm | \x:t.e
  e ::= v | let x = e in e' | e v | ref v | v1 := v2 | !v

  Given modules m1...mn, that depend on function g1..gn from the global object, 
  we translate them as follows, with the <script> tag being the first in the page (e.g., in the header).

  <script>
  var init = function(pglobal) { //a pristine copy of the global object provided by the loader
    var global = {g1=pglobal.g1; ...; gn=pglobal.gn};

    var m1_f1 = [[M1.f1]]; ...; var m1_fn = [[M1.fn]];
    var m1 = {f1:m1_f1, ... , fn:m1_fn}; //for each of let binding f1..fn in M1
     ... 
    var mk_f1 = [[Mk.f1]]; ...; var mk_fm = [[Mk.fm]];;
    var mk = {f1:mk_f1; ...}; 
  
    //export m1..mk into the global namespace after defensive wrapping
    pglobal.m1 = wrap_m1(m1);
    ...
    pglobal.mk = wrap_mk(mk);
  };
  init(window);// load all the wrapped code into a pristine window object
  init=undefined; // get rid of the loader
  </script>
*)

module Microsoft.FStar.ToJS.TstarAbsyn2JSMin

open System
open Microsoft.FStar
open Util
open Absyn
open KindAbbrevs
type jexp = JSMinSyntax.exp
type jstmt = JSMinSyntax.stmt
type fexp = Absyn.exp
open JavaScriptSyntax
open JSMinSyntax

let r2p r : Common.pos = r
let dummyp = r2p Absyn.dummyRange

let VConstant(c) = VConstant(dummyp, c)
let VId(id) = VId(dummyp, id)
let VLambda(args, body) = VLambda(dummyp, args, body)
let VObject(fields) = VObject(dummyp, fields)

let EValue(x) = EValue(dummyp, x)
let EOp1(pfx, e) = EOp1(dummyp, pfx, e)
let EOp2(op, e1, e2) = EOp2(dummyp, op, e1, e2)
let EDot(e, id) = EDot(dummyp, e, id)
let EBracket(e1, e2) = EBracket(dummyp, e1, e2)
let ECall(e1, e2, e3) = ECall(dummyp, e1, e2, e3)
let EBuiltIn(b) = EBuiltIn(dummyp, b)
let EAssign(id, e) = EAssign(dummyp, id, e)
let EDotAssign(e, id, e') = EDotAssign(dummyp, e, id, e')
let EBracketAssign(e1, e2, e3) = EBracketAssign(dummyp, e1, e2, e3)
let ENew(e, el) = ENew(dummyp, e, el)
let EObjLiteral(el) = EObjLiteral(dummyp, el)
let EList(e1, e2) = EList(dummyp, e1, e2)
let EIf(e1, e2, e3) = EIf(dummyp, e1, e2, e3)
let EVar(x, e1, e2) = EVar(dummyp, x, e1, e2)

let ECallComp = List.foldBack (fun e a -> ECall(e, None, [a]))

let ECall0 = fun e -> ECall(e, None, [])
let ECall1 = fun e1 e2 -> ECall(e1, None, [e2])
let EIndex = fun e i -> EBracket(e, EValue (VId (spr "%d" i)))
let ELambda = fun xs s -> EValue (VLambda(xs, s))

let SSeq(s1, s2) = SSeq(dummyp, s1, s2)
let SIf(e, s1, s2) = SIf(dummyp, e, s1, s2)
let SWhile(e, s) = SWhile(dummyp, e, s)
let SReturn(e) = SReturn(dummyp, e)
let SBreak = SBreak(dummyp)
let SEmpty = SEmpty(dummyp)
let SForInStmt(id, e, s) = SForInStmt(dummyp, id, e, s)
let SVar(id, e, s) = SVar(dummyp, id, e, s)
let SVarDecl(id) = SVarDecl(dummyp, id)
let SThrow(e) = SThrow(dummyp, e)

let SSeqs = fun stms stm -> List.foldBack (fun s1 s2 -> SSeq(s1, s2)) stms stm
let SVarSeq = List.foldBack (fun (x, e) s -> SVar(x, e, s))

let fail_string = EValue(VConstant(JSMinSyntax.CBuiltIn <| JavaScriptSyntax.CString "error"))
let mk_id x = x.realname.idText
let exp_of_id x = EValue (VId x)
let fullname_as_string (l:lident) = String.concat "." (l.lid |> List.map (fun i -> i.idText))
let id_of_lid (l:lident) = String.concat "_" (l.lid |> List.map (fun i -> i.idText))
let undefined_exp = EValue(VConstant(CBuiltIn JavaScriptSyntax.CUndefined))
let true_jexp = EValue(VConstant(CBuiltIn <| JavaScriptSyntax.CBool true))
let false_jexp = EValue(VConstant(CBuiltIn <| JavaScriptSyntax.CBool false))
let jexp_of_string s = EValue(VConstant(CBuiltIn (JavaScriptSyntax.CString s)))
let jexp_of_int i = EValue(VConstant(CBuiltIn (JavaScriptSyntax.CInt i)))
let id_jexp = EValue <| VLambda(["x"], SReturn (exp_of_id "x"))
let check_eq e1 e2 = EOp2(JavaScriptSyntax.OpStrictEq, e1, e2)
let new_id () = (genident (None)).idText


let Q_field f = EDot(exp_of_id "Q", f)

let is_builtin lid = 
  Sugar.lid_equals lid Const.int_lid 
  || Sugar.lid_equals lid Const.num_lid 
  || Sugar.lid_equals lid Const.bool_lid 
  || Sugar.lid_equals lid Const.string_lid
  || Sugar.lid_equals lid Const.unit_lid
  || Sugar.lid_equals lid Const.object_lid
  || Sugar.lid_equals lid Const.float_lid
  || Sugar.lid_equals lid Const.ref_lid
  || Sugar.lid_equals lid Const.ntuple_lid
  || Sugar.lid_equals lid Const.bytes_lid

type env = (Disj<bvvdef,var<typ>> * jexp) list
let lookup_bvar env x = 
  match Util.findOpt (function (Inr _, _) -> false | (Inl y, _) -> Absyn.bvd_eq x.v y) env with 
    | None -> failwith (spr "Variable not found: %s" (Pretty.strBvd x.v))
    | Some(x, e) -> e

let lookup_fvar env (x:var<typ>) = 
  match Util.findOpt (function (Inl _, _) -> false | (Inr y, _) -> Sugar.lid_equals x.v y.v) env with
    | None -> (match x.v.lid with 
                 | m::[id] ->
                    let m = if m.idText = "Prims" then ident("Q", dummyRange) else m in
                      Some (EDot(exp_of_id (m.idText), id.idText))  (* hack for names from other modules *)
                 | _ -> None)
    | Some(_, e) -> Some e

let extend_env env m = 
  m.letbindings |> List.fold_left 
      (fun env (lb, _) -> 
         lb |> List.fold_left 
             (fun env (x,t,_) -> 
                let lid = Sugar.dot_lid m.name x.ppname in 
                let var = ewithsort lid t in
                let jexp = EDot(exp_of_id <| id_of_lid m.name, x.ppname.idText) in 
                  (Inr var, jexp)::env) env) env

(* mutable t -> t *)
let removeMutable t = match t.v with
    | Typ_app({v=Typ_const(c, _); sort = _; p=_}, ta) when Sugar.lid_equals c.v Const.mutable_lid -> ta
    | _ -> t

(* primitiveLinking:
     the name says it all: it does the linking of primitive operations,
     in a very primitive way. Put otherwise, this is a filthy hack. I'm a naughty boy.
*) 
let primitiveLinking (s : string) : string = match s with
    | "op_Equality" -> "(function (a) { return function (b) { return a === b; } })"
    | "String_concat" -> "(function (a) {return function (b) {return a+b;} })"
    | "String_startsWith" -> "Q.String_startsWith"
    | "String_noQueryHash" -> "Q.String_noQueryHash"
    | "_dummy_op_Negation" -> "(function (x) { return (! x) })"
    | "_dummy_op_AmpAmp" -> "(function (x) {return function(y) { return (x && y); }})"
    | "_dummy_op_OrOr" -> "(function (x) {return function(y) { return (x || y); }})"
    | "_dummy_op_Addition" -> "(function (x) {return function (y) { return (x + y); }})"
    | "_dummy_op_Substraction" -> "(function (x) {return function(y) { return (x - y); }})"
    | "_dummy_op_Multiply" -> "(function (x) {return function(y) { return (x * y); }})"
    | "_dummy_op_Division" -> "(function (x) {return function(y) { return (x / y); }})"
    | "_dummy_op_Minus" -> "(function (x) { return (-x); })"
    | "_dummy_op_Modulus" -> "(function (x) { return (x % y); })"
    | "_dummy_op_GreaterThanOrEqual" -> "(function (x) { return (x >= y); })"
    | "_dummy_op_LessThanOrEqual" -> "(function (x) { return (x <= y); })"
    | "_dummy_op_GreaterThan" -> "(function (x) { return (x > y); })"
    | "_dummy_op_GreaterThan" -> "(function (x) { return (x < y); })"

    | "typeof" -> "typeof"
    | "hasOwnProperty" -> "function (x) { return function (f) { return x.hasOwnProperty(f); } }"
    
    | "Q" -> "Q"
    | "window_postMessage" -> "Q.window_postMessage"
    | "console_log" -> "alert" //"console.log"
    | "typeOf" -> "typeof"
    | _ -> failwith (spr "Variable not found: %s" s)

let let_bound_names e = 
  AbsynUtils.reduce_exp 
    (fun _ _ _ env _ _ -> (), env)
    (fun _ _ _ env _ _ -> (), env)
    (fun rk rt ve env binders e -> match e.v with 
      | Exp_tabs _ 
      | Exp_abs _ -> (), env
      | Exp_match(_, pats, e) -> 
        let env = List.fold_left (fun env (pat, e) -> match pat with 
          | Pat_variant(lid, _, _, bvs, _) -> 
            let env = List.append (bvs |> List.map (fun bv -> bv.v)) env in
            let _, env = ve env binders e in 
            env) env pats in 
        ve env binders e
      | Exp_let(false, [x,t,e1], e2) -> 
        let env = x::env in 
        let _, env = ve env binders e1 in 
        ve env binders e2
      | _ -> ve env binders e)
    (fun _ _ env -> (), env)
    (fun _ _ env -> (), env)
    (fun _ _ env -> (), env)
    [] [] e

let rec to_stmt env (e:fexp) (k:option<Common.id>) : jstmt =
  match k with
    | None -> SReturn(to_expr env e) (* return $ejs$ *)
    | Some x -> SExp(EAssign(x, to_expr env e)) (* $x$ = $ejs$ *)

and to_expr env (e:fexp) : jexp = 
  match e.v with 
    | Exp_ascribed(e, _, _) -> to_expr env e

    | Exp_bvar x -> lookup_bvar env x
    | Exp_fvar(x,_) -> 
        begin
        match x.v.lid with
          | [lid] when lid.idText = "Q" -> exp_of_id "Q"
          | m::[lid] when m.idText = "Prims" ->
            if (lid.idText = "setTag" || lid.idText = "canTag" || lid.idText = "isTag" 
               || lid.idText = "warp" || lid.idText = "canWrap" || lid.idText = "emptyRecord" 
               || lid.idText = "String_split" || lid.idText = "foreach")
            then Q_field lid.idText
            else exp_of_id (primitiveLinking (Pretty.str_of_lident x.v))
          | _ ->
        match lookup_fvar env x with
            | Some e -> e
            | None -> failwith (spr "variable not found: %s" (Pretty.str_of_lident x.v))
        end

    | Exp_bot ->
      let x = new_id () in
        EVar(x, EValue(VLambda([], SThrow(fail_string))), exp_of_id x)

    | Exp_constant c -> 
        EValue(VConstant(to_constant c))

    | Exp_constr_app(d, tl, [], el) -> 
        let eljs = List.mapi (fun i e -> (spr "%d" i, to_expr env e)) el in
        (* let tag = jexp_of_int ((Sugar.text_of_lid d.v).GetHashCode()) in  *)
        let tag = jexp_of_string (Sugar.text_of_lid d.v) in
        let obj = EObjLiteral(("tag", tag)::eljs) in 
          obj

    | Exp_cond(econd, etrue, efalse) ->
      let econd  = to_expr env econd  in
      let etrue  = to_expr env etrue  in
      let efalse = to_expr env efalse in
        EIf(econd, etrue, efalse)

    | Exp_ascribed(e, _, _) ->
      to_expr env e

    | Exp_let(isRec, [(x,_,e1)], e2) ->
      let xenv = (Inl x, exp_of_id <| mk_id x)::env in
      let env_e1 = if isRec then xenv else env in
      let e1 = to_expr  env_e1 e1 in
      let e2 = to_expr xenv e2 in
        EVar(mk_id x, e1, e2)

    | Exp_match(v, pats, def) -> 
        (* Compile v down to a JS expression and return a binder for the branches *)
        let vjs, mkbranches = match (unascribe v).v with
          | Exp_bvar x -> lookup_bvar env x, (fun x -> x)
          | _ -> 
              let vjs = to_expr env v in 
              let id = (Absyn.genident None).idText in
                exp_of_id id, (fun branches -> (* let $id$ = $vjs$ in branches *)
                                               EVar(id, vjs, branches)) in 
        let branches = List.fold_right
            (fun (pat, thenexp) elsejs -> 
               match pat with 
                 | Pat_variant(d, _, _, xs, _) -> 
                     let cond = EOp2(JavaScriptSyntax.OpStrictEq, 
                                     EDot(vjs, "c"),                                      
                                     jexp_of_string (Sugar.text_of_lid d)) in
                     (* jexp_of_int ((Sugar.text_of_lid d).GetHashCode())) in  *)
                     let env =
		       List.fold_left
		         (fun env x -> (Inl x.v, exp_of_id <| mk_id x.v)::env)
			 env xs in
		     let thenjs, _ =
		       List.fold_right 
			 (fun x (body, i) -> 
			   let bracket =
			     EBracket(vjs, jexp_of_string <| string_of_int i) in
			   let body =
			     EVar(mk_id x.v, bracket, body)
			   in 
                             (body, i - 1))
			 xs (to_expr env thenexp, (List.length xs - 1)) in
                     EIf(cond, thenjs, elsejs))
            pats (to_expr env def) in
          mkbranches branches
    | Exp_abs(x, t, body) -> 
        let env = (Inl x, exp_of_id <| mk_id x)::env in
        let _, names = let_bound_names body in 
        let body = to_stmt env body None in 
        let body = List.fold_right (fun nm body -> SVar(mk_id nm, undefined_exp, body)) names body in  
          EValue(VLambda([x.realname.idText], body))

    | Exp_tabs(a, k, _, body) -> 
        if AbsynUtils.is_value body 
        then to_expr env body 
        else failwith "Value restriction"

    | Exp_app ({ v = Exp_app ({ v = Exp_fvar (x, _) }, { v = Exp_bvar f }) }, e)
        when (Pretty.str_of_lident x.v) = "_dummy_op_ColonEquals" -> begin
            match lookup_bvar env f with
            | EValue (_, VId (_, x)) -> EAssign(x, to_expr env e)
        end

    | Exp_app(e1, v) ->
        ECall(to_expr env e1, None, [to_expr env v])

    | Exp_tapp(e, t) -> 
        to_expr env e

    | Exp_primop(op, [e]) -> 
        (match js_uniop op.idText with
          | Some o -> EOp1 (o, to_expr env e)
          | None -> failwith ("Unsupported unary operator: " ^ op.idText))
    | Exp_primop(op, [e1; e2]) -> 
        (match js_binop op.idText with
          | Some o ->
	    let e1 = to_expr env e1 in
            let e2 = to_expr env e2 in
     	      EOp2 (o, e1, e2)
          | None -> failwith ("Unsupported binary operator: " ^ op.idText))

    | Exp_proj(e, fn) -> 
      let id = new_id () in 
      EVar(id, to_expr env e, EDot(EValue(VId id), id_of_lid fn))
        
    | Exp_recd(_, _, _, fn_e_l) -> 
      let fields = fn_e_l |> List.map (fun (fn, e) -> 
        let v = to_expr env e in 
        let fn = id_of_lid fn in 
        (fn,v)) in 
      EObjLiteral(fields)

    | Exp_primop(op, _) -> failwith ("Unsupported operator: " ^ op.idText)
    | Exp_extern_call(_, id, t, tl, el) -> 
        failwith "extern_call: NYI"
    | _ -> let _ = pr "We don't handle %s in the translation to JS" (Pretty.strExp e) in failwith "unknown exp"
      

and to_constant c : constant = 
  CBuiltIn <| match c with 
    | Sugar.Const_unit -> JavaScriptSyntax.CUndefined
    | Sugar.Const_bool b -> JavaScriptSyntax.CBool b
    | Sugar.Const_int32 i -> JavaScriptSyntax.CInt i
    | Sugar.Const_float f -> JavaScriptSyntax.CNum f 
    | Sugar.Const_string (bytes, _) -> JavaScriptSyntax.CString (Util.unicodeEncoding.GetString(bytes))
    | Sugar.Const_decimal _
    | Sugar.Const_bigint _ 
    | Sugar.Const_bignum _
    | Sugar.Const_bytearray _ 
    | Sugar.Const_uint16array _
    | Sugar.Const_int8 _ 
    | Sugar.Const_uint8 _
    | Sugar.Const_int16 _
    | Sugar.Const_uint16 _
    | Sugar.Const_uint32 _
    | Sugar.Const_int64 _
    | Sugar.Const_uint64 _
    | Sugar.Const_nativeint _
    | Sugar.Const_unativeint _
    | Sugar.Const_float32 _
    | Sugar.Const_char _ -> failwith (spr "Unsupported constant %s" (c.ToString()))

and js_binop (op : string)  =
  match op with
    | "op_BarBar" -> Some JavaScriptSyntax.OpLOr
    | "op_AmpAmp" -> Some JavaScriptSyntax.OpLAnd
    | "op_Addition" -> Some JavaScriptSyntax.OpAdd
    | "op_GreaterThan" -> Some JavaScriptSyntax.OpGT
    | "op_LessThan" -> Some JavaScriptSyntax.OpLT
    | "op_Subtraction" -> Some JavaScriptSyntax.OpSub
    | "op_Modulus" -> Some JavaScriptSyntax.OpMod
    | "op_Multiply" -> Some JavaScriptSyntax.OpMul
    | _ -> None

and js_uniop (op : string) =
    match op with
    | "op_Minus" -> Some JavaScriptSyntax.PrefixMinus
    | _ -> None

(* 
    Given 
        type T1 a1..an = 
           | D11 : t1 -> ... -> T1 a1..an
           | D1n_1 : t1n_1
        ...
        and Tk a1..an
           | Dk1 : tk1 
           | Dkn_k : tkn_k

    we generate 
        function down_T1(down_a1, ..., down_ak,  up_a1, ..., up_ak) {
               return function (x) {
                    if (x.tag == D11) {
                        return {"tag":"D11", 
                                "0":down_t1 (down_a1..up_ak) x["0"],
                                ..
                                "n":down_tn (down_a1..up_ak) x["n"]}

                    } ... else if (x.tag == D1n_1) {
                        ...
                    } else { throw "expected T1"; }
               }
        }
        ...
        function down_Tk(down_a1, up_a1, ... down_ak, up_ak) {

        }
*)

exception WrappingError of string
    
let down_err t = raise (WrappingError (spr "Type %s cannot be exported to a JavaScript context" (Pretty.strTyp t)))
let up_err t = raise (WrappingError (spr "Type %s cannot be imported from a JavaScript context" (Pretty.strTyp t)))

type wdir = LUp | LDown

let wtake = fun ud (xu, xd) ->
  match ud with LUp -> xu | LDown -> xd

let strwdir = fun ud -> wtake ud ("up", "down")

type wrscalar_t =
  | WR_Num
  | WR_Bool
  | WR_Unit
  | WR_Float
  | WR_String

let scalar_types = [
  (Const.num_lid   , WR_Num   );
  (Const.bool_lid  , WR_Bool  );
  (Const.unit_lid  , WR_Unit  );
  (Const.float_lid , WR_Float );
  (Const.string_lid, WR_String)
]

let is_scalar_type = fun tc ->
  scalar_types |>
      List.exists (fun (x, _) -> Sugar.lid_equals tc.v x)

let is_any_type tc = Sugar.lid_equals tc.v (AbsynUtils.liOfSl ["Prims"; "any"])

let get_as_scalar = fun tc ->
  scalar_types |>
      List.tryFind (fun (x, _) -> Sugar.lid_equals tc.v x)

let rec down tcenv tvar_wrappers (t:typ) : jexp = 
  let t = Tcenv.expand_typ tcenv (unascribe_typ t) in 
    match t.v with 
    | Typ_btvar btv ->
        (match tvar_wrappers |> Util.findOpt (fun (a, _ , _) -> bvd_eq a btv.v) with 
           | Some (_, d, _) -> d
           | _ -> down_err t)

    | Typ_const(tc, _) -> 
        if   is_scalar_type tc
        then exp_of_id "downid"
        else if is_any_type tc then exp_of_id "downany"
        else wrap_dt tcenv tvar_wrappers LDown t

    | Typ_fun(x, t1, t2) -> 
        let up_t1 = up tcenv tvar_wrappers t1 in
        let down_t2 = down tcenv tvar_wrappers t2 in
        ECall(exp_of_id "downfun", None, [up_t1; down_t2])
 
    | Typ_univ(a, k, _, t) -> 
      let f    = new_id () in 
      let tvar = new_id () in 

      let body =
        let dw_t = new_id () in 
        let up_t = new_id () in 
        let du_t = new_id () in 

        let tvar_wrappers = (a, exp_of_id dw_t, exp_of_id up_t)::tvar_wrappers in

        SVarSeq
          [(du_t, ECall1 (exp_of_id "wrappers_for_t") (exp_of_id tvar));
           (dw_t, EIndex (exp_of_id du_t) 0);
           (up_t, EIndex (exp_of_id du_t) 1)]
          (SReturn <| ECall1 (down tcenv tvar_wrappers t) (exp_of_id f))
      in
        EValue(VLambda([f], SReturn <| EValue(VLambda([tvar], body))))

    | Typ_refine(_, t, _, _) -> down tcenv tvar_wrappers t
                
    | Typ_app _ -> wrap_dt tcenv tvar_wrappers LDown t
      
    | Typ_dtuple([(None, t1); (_, t2)]) -> 
        let down_t1 = down tcenv tvar_wrappers t1 in
        let down_t2 = down tcenv tvar_wrappers t2 in
        ECall(exp_of_id "downpair", None, [down_t1; down_t2])
      
    | _ -> down_err t

and up tcenv tvar_wrappers (t:typ) : jexp = 
  let t = Tcenv.expand_typ tcenv (unascribe_typ t) in 
    match t.v with 
      | Typ_btvar btv ->
          (match tvar_wrappers |> Util.findOpt (function (a, _ , _) -> bvd_eq a btv.v) with 
             | Some (_, _, u) -> u
             | _ -> up_err t)
            
      | Typ_const(tc, _) -> (* floats ? *)
        begin match get_as_scalar tc with
          | Some (_, WR_Num) -> exp_of_id "upnumber"
          | Some (_, WR_Bool) -> exp_of_id "upbool"
          | Some (_, WR_Unit) -> exp_of_id "upunit"
          | Some (_, WR_String) -> exp_of_id "upstring"
          | None ->
            if is_any_type tc then exp_of_id "upany"
            else let x = new_id () in
            let mkFun body = EValue <| VLambda([x], body) in 
            let xvar = exp_of_id (* Bug: jexp_of_string*) x  in
            EValue <| VLambda([x], SReturn (ECall(wrap_dt tcenv tvar_wrappers LUp t, None, [xvar])))
        end

      | Typ_fun(x, t1, t2) -> 
        let down_t1 = down tcenv tvar_wrappers t1 in
        let up_t2 = up tcenv tvar_wrappers t2 in
        ECall(exp_of_id "upfun", None, [down_t1; up_t2])
          
      | Typ_app _ -> wrap_dt tcenv tvar_wrappers LUp t

      | Typ_dtuple([(None, t1); (_, t2)]) -> 
        let up_t1 = up tcenv tvar_wrappers t1 in
        let up_t2 = up tcenv tvar_wrappers t2 in
        ECall(exp_of_id "uppair", None, [up_t1; up_t2])

      | _ -> up_err t

and wrap_dt tcenv tvar_wrappers ud t = 
  let wrap t = wtake ud (up, down) tcenv tvar_wrappers t in
  let err  t = wtake ud (up_err, down_err) t in

    match AbsynUtils.flattenTypAppsAndDeps t with 
    | {v = Typ_const(tc, _)} as tconst, args ->  begin
        if Tcenv.is_record tcenv tc.v then exp_of_id (spr "%s_%s" (strwdir ud) (id_of_lid tc.v))
        else match Tcenv.lookup_datatype tcenv tc.v with 
        | None -> err t
        | _ ->
           let args_ud = fun ud ->
             args |> List.map
               (function 
                 | Inr _ -> raise Impos 
                 | Inl t -> wtake ud (up, down) tcenv tvar_wrappers t)
           in 
             ECall(exp_of_id (spr "%s_%s" (strwdir ud) (id_of_lid tc.v)), 
                   None, (args_ud LDown) @ (args_ud LUp))
    end
    | _ -> err t


type datatype = list<(sigelt * signature)>
type datatypes = list<datatype>
let rec datatypes tcenv (m:modul) : datatypes = 
  // let _ = Printf.printf "\n module: %s" (Pretty.strModule m) in
  let rec aux = function  
    | (Sig_tycon_kind(lid, parms, Kind_star, _, rlids, _) as tc)::rest when (not (is_builtin lid)) -> 
      let rlids = rlids |> List.filter (not -<- Sugar.lid_equals lid) in
      let tcs = rlids |> List.map 
          (fun rlid -> 
            let seopt = rest |> Util.findOpt 
                (function 
                  | Sig_tycon_kind(lid', _, _, _, _, _) -> Sugar.lid_equals rlid lid'
                  | _ -> false) in
            match seopt with 
              | Some se -> se
              | None -> failwith (spr "Type constructor %s (mutual with %s) not found" (Sugar.text_of_lid rlid) (Sugar.text_of_lid lid))) in 
      let tcs = tc::tcs in 
      let dt = tcs |> List.map 
          (function 
            | Sig_tycon_kind(lid, _, _, _, _, _) as tc -> 
              (match Tcenv.lookup_datatype tcenv lid with 
                | None -> (tc, [])
                | Some s -> (tc, s))
            | _ -> raise Impos) in 
      let rest = rest |> List.filter 
          (function 
            | Sig_tycon_kind(lid', _, _, _, _, _) -> 
              not <| List.exists (function Sig_tycon_kind(lid, _, _, _, _, _) -> 
                Sugar.lid_equals lid lid' | _ -> false) tcs
            | _ -> true) in
      dt::aux rest               
    | Sig_record_typ _ as se::rest -> [(se,[])]::aux rest
    | _::rest -> aux rest 
    | [] -> [] in 
  aux m.signature

let wrap_datatype tcenv dt : list<stmt> = 
  let wrap_one ud = function 
    | (Sig_tycon_kind(tclid, tparams, _, _, _, _), constrs) -> 
        let scrutinee = exp_of_id "x" in 
        let branches = constrs |> List.map 
            (function 
               | Sig_datacon_typ(tag, tparamsd, typ, _, _, _, _, _) -> 
                   if List.length tparams <> List.length tparamsd then raise Impos;
                   let wrap_params = tparamsd |> List.mapi 
                       (fun i tp -> match tp with 
                          | Tparam_typ(a, k) -> (a, exp_of_id (spr "down_%d" i), exp_of_id (spr "up_%d" i))
                          | Tparam_term _ -> failwith "Value-indexed datatypes not yet supported") in
                   let rec wrap_fields (ix, fields) = function
                     | {v=Typ_fun(_, t1, t2)} -> 
                         let wt1 = wtake ud (up, down) tcenv wrap_params t1 in 
                         let field = ECall(wt1, None, [EBracket(scrutinee, jexp_of_string <| string_of_int ix)]) in 
                           wrap_fields ((ix + 1), (string_of_int ix, field)::fields) t2
                     | t -> 
                         match AbsynUtils.flattenTypAppsAndDeps t with 
                           | {v=Typ_const(tc, _)}, _  when Sugar.lid_equals tc.v tclid -> 
                               List.rev fields
                           | _ -> failwith (spr "Unexpected type %s for constructor %s\n Expected a constructor of %s\n" 
                                              (Pretty.strTyp t)
                                              (Sugar.text_of_lid tag)
                                              (Sugar.text_of_lid tclid)) in 
                   (* let tagval = jexp_of_int ((Sugar.text_of_lid tag).GetHashCode()) in  *)
                   let tagval = jexp_of_string (Sugar.text_of_lid tag) in
                   let fields = ("tag", tagval)::(wrap_fields (0, []) typ) in 
                   let cond = EOp2(JavaScriptSyntax.OpStrictEq, 
                                   EDot(scrutinee, "tag"),
                                   tagval) in
                     cond, fields
               | _ -> raise Impos) in
        let body = List.fold_right 
          (fun (cond, o) elsebranch -> SIf(cond, SReturn(EObjLiteral o), elsebranch))
          branches (SThrow(jexp_of_string (spr "Expected type %s" (Sugar.text_of_lid tclid)))) in 
        let body = EValue <| VLambda(["x"], body) in 
          SVar(spr "%s_%s" (strwdir ud) (id_of_lid tclid),
               EValue(VLambda((tparams |> List.mapi (fun i _ -> spr "down_%d" i))@
                              (tparams |> List.mapi (fun i _ -> spr "up_%d" i)), 
                              SReturn body)), 
               SEmpty)

    | Sig_record_typ(lid, tps, k, {v=Typ_record(fnt_l,_)}, None), _ -> 
      let scrutinee = exp_of_id "x" in 

      let wrap_params = tps |> List.mapi 
          (fun i tp -> match tp with 
            | Tparam_typ(a, k) -> (a, exp_of_id (spr "down_%d" i), exp_of_id (spr "up_%d" i))
            | Tparam_term _ -> failwith "Value-indexed datatypes not yet supported") in

      let wrap_fields = fnt_l |> List.map (fun (fn,t) -> (fn, wtake ud (up,down) tcenv wrap_params (removeMutable t))) in 
      let wrapper = 
        EValue (VLambda(["x"], 
                        SReturn (EObjLiteral (wrap_fields |> List.map (fun (fn, w) -> 
                          (id_of_lid fn, ECall(w, None, [EDot(scrutinee, id_of_lid fn)]))))))) in 
      let wrapper = EValue (VLambda((tps |> List.mapi (fun i _ -> spr "down_%d" i))@
                                       (tps |> List.mapi (fun i _ -> spr "up_%d" i)), 
                                    SReturn wrapper)) in 
      SVar(spr "%s_%s" (strwdir ud) (id_of_lid lid), wrapper, SEmpty)

    | _ -> raise Impos in 
     (dt |> List.map (wrap_one LDown))
    @(dt |> List.map (wrap_one LUp))

(* function wrappers_for_t(t) {
      if (t.tag === "Prims.int") {
          return {"0": down_int, "1":up_int};
      }
      else if (t.tag === "Prims.string") {
          return {"0": down_string, "1":up_string};
      }
      else if (t.tag === "Typ_fun") {
          var t1 = wrappers_for_t(t["0"]);
          var t2 = wrappers_for_t(t["1"]);
          return {"0":down_fun(t1["1"], t2["0"]), "1":up_fun(t1["0"], t2["1"])};
      }
      else if (t.tag === "Typ_app") {
          var tc = t.constructor;
          if (tc === "Prims.list") {
              ...
          }
          else if (tc === "Prims.option") {
              ...
          }
          ...
          else { throw "Error"; }
      }
   }
*)
let wrappers_for_t ms tcenv : stmt = 
  let impl = 
    let tagvar = new_id () in 
    let check_field e f s = check_eq (EBracket(e, jexp_of_string f)) (jexp_of_string s) in 
    let check_tag s = EOp2(JavaScriptSyntax.OpStrictEq, 
                           exp_of_id tagvar,
                           jexp_of_string s) in  (* GetHashCode *)
    let read_field s f = EBracket(exp_of_id s, 
                                  jexp_of_string f) in
      (fun body -> EValue(VLambda(["t"], SVar(tagvar, read_field "t" "tag", body)))) <| 
          let branches =
            [(check_tag "Prims.unit", 
              let d = new_id () in 
              let u = new_id () in 
                SVar(d, down tcenv [] Const.unit_typ, 
                     SVar(u, up tcenv [] Const.unit_typ, 
                          SReturn <| EObjLiteral([("0", exp_of_id d);
                                                  ("1", exp_of_id u)]))));

             (check_tag "Prims.bool", 
              let d = new_id () in 
              let u = new_id () in 
                SVar(d, down tcenv [] Const.bool_typ, 
                     SVar(u, up tcenv [] Const.bool_typ, 
                          SReturn <| EObjLiteral([("0", exp_of_id d);
                                                  ("1", exp_of_id u)]))));
             
             (check_tag "Prims.number", 
              let d = new_id () in 
              let u = new_id () in 
                SVar(d, down tcenv [] Const.num_typ, 
                     SVar(u, up tcenv [] Const.num_typ, 
                          SReturn <| EObjLiteral([("0", exp_of_id d);
                                                  ("1", exp_of_id u)]))));

             (check_tag "Prims.string", 
              let d = new_id () in 
              let u = new_id () in 
                SVar(d, down tcenv [] Const.string_typ, 
                     SVar(u, up tcenv [] Const.string_typ, 
                          SReturn <| EObjLiteral([("0", exp_of_id d);
                                                  ("1", exp_of_id u)]))));

             (check_tag "Typ_fun", 
              let t0 = new_id () in 
              let t1 = new_id () in 
                SVar(t0, ECall(exp_of_id "wrappers_for_t", None, [read_field "t" "0"]), 
                     SVar(t1, ECall(exp_of_id "wrappers_for_t", None, [read_field "t" "1"]), 
                          let a, b = new_bvd None, new_bvd None in 
                          let t = twithsort (Typ_fun(None, 
                                                     twithsort (Typ_btvar (bvd_to_bvar_s a Kind_star)) Kind_star, 
                                                     twithsort (Typ_btvar (bvd_to_bvar_s b Kind_star)) Kind_star)) Kind_star in
                          let tvars = [(a, read_field t0 "0", read_field t0 "1");
                                       (b, read_field t1 "0", read_field t1 "1")] in 
                          let d = new_id () in 
                          let u = new_id () in 
                            SVar(d, down tcenv tvars t, 
                                 SVar(u, up tcenv tvars t, 
                                      SReturn <| EObjLiteral([("0", exp_of_id d);
                                                              ("1", exp_of_id u)]))))));
             (check_tag "Typ_app", 
              let tc = new_id () in 
              let signature = ms |> List.collect (fun m -> m.signature) in 
              let branches = signature |> List.collect 
                  (function 
                     | Sig_tycon_kind(lid, tps, Kind_star, _, _, _) when not (is_builtin lid) -> 
                         let pwrappers = tps |> List.mapi 
                             (fun i _ -> 
                                let pi = new_id() in 
                                  (pi, ECall(exp_of_id "wrappers_for_t", None, 
                                             [read_field "t" (string_of_int i)]))) in 
                         let args = 
                           (pwrappers |> List.map (fun (pi, _) -> read_field pi "0"))
                           @(pwrappers |> List.map (fun (pi, _) -> read_field pi "1")) in 
                         let down = 
                           ECall(exp_of_id (spr "down_%s" (id_of_lid lid)), None, args) in 
                         let up = 
                           ECall(exp_of_id (spr "up_%s" (id_of_lid lid)), None, args) in 
                         let branch = List.fold_right 
                           (fun (pi, init) body -> SVar(pi, init, body))
                           pwrappers 
                           (let d = new_id () in
                            let u = new_id () in
                              SVar(d, down, 
                                   SVar(u, up, 
                                        (SReturn <| EObjLiteral([("0", exp_of_id d);
                                                                 ("1", exp_of_id u)]))))) in 
                         let cond = check_eq (exp_of_id tc) (jexp_of_string (fullname_as_string lid)) in 
                           [(cond, branch)]
                     | _ -> []) in
              let body = List.fold_right 
                (fun (guard, branch) elsebranch -> SIf(guard, branch, elsebranch))
                branches (SThrow(jexp_of_string "Unexpected type constructor")) in 
                SVar(tc, read_field "t" "constructor", body))] in
            
          let body = List.fold_right 
            (fun (guard, branch) elsebranch -> SIf(guard, branch, elsebranch))
            branches (SThrow(jexp_of_string "Unexpected type")) in
            body in 
    SVar("wrappers_for_t", impl, SEmpty)

let build_wrappers ms = 
    let (tcenv, stmts) = ms |> List.fold_left 
      (fun (tcenv, s) m -> 
         let tcenv = Tcenv.push_module tcenv m in 
         let dts = datatypes tcenv m in
         let stmts = dts |> List.collect (wrap_datatype tcenv) in 
           tcenv, [stmts]@s)
      (Tcenv.mk_env (), []) in 
    let w = wrappers_for_t ms tcenv in
      List.flatten <| List.rev ([SComment "Wrappers from runtime types"; w]::stmts)
          
let wrap tcenv (m:Absyn.modul) (e:jexp) : stmt * Tcenv.env = 
  let tcenv = Tcenv.push_module tcenv m in 
  let fields = m.letbindings |> List.collect (fun (lb, _) -> lb) in
  let rec mk_fields fields = function 
    | [] -> SExp <| EDotAssign(exp_of_id "pglobal", 
                               id_of_lid m.name, 
                               EObjLiteral fields)
    | (x, t, _)::rest -> 
      (* let _ = pr "Wrapping %s at type %s\n" (x.ppname.idText) (Pretty.strTyp t) in  *)
      try
        let f = new_id () in         
        //let w = down tcenv [] (Absyn.compress t) in 
        let w = ECall(ECall(ECall(Q_field "wrap", None, [to_expr [] (TSStar.typ2Tag dummyRange {tcenv = tcenv; lids = []} t)]), 
                            None, [Q_field "Un"]),
                      None, [EDot(e, x.ppname.idText)]) in
          SSeq(SCommentSmall("Exporting " ^ x.ppname.idText ^ (Pretty.strTyp t)), 
               SVar(f, 
                    w, 
                    mk_fields ((x.ppname.idText, exp_of_id f)::fields) rest))
     with WrappingError msg -> 
       if !Options.ts_star then SEmpty 
       else failwith (spr "Failed to export %s at type %s\nbecause %s\n" x.ppname.idText (Pretty.strTyp t) msg) in
  mk_fields [] fields, tcenv 
      
let bind_externs ms = 
  let (env, externs) = 
                (* For all modules*)
                 ms 
                (* Extract the signatures *)
              |> List.map (fun m -> m.signature) 
              |> List.concat 
                (* Filter out the JavaScript extern values *)
              |> List.collect (function 
                  | Sig_extern_value({language=Sugar.JavaScript;
                                      dll="";
                                      namespce={lid=w::rest};
                                      classname=cname } as eref, lid, t) 
                       when Sugar.text_of_id w = "window" ->
                         (* Compute absolute name of the extern: *)
                         let extern_val this = 
                           let fieldname = List.tl lid.lid in 
                           let receiver = rest@eref.classname.lid in 
                           let path = receiver@fieldname in
                           let pathname = List.map (fun (x : Sugar.ident) -> x.idText) path in
                           List.append this pathname |>
                           String.concat "." |>
                           exp_of_id
                           (* List.fold_left 
                              (fun exp field -> EDot( exp, field.idText)) 
                              this*) in                            
                         (* Compute the name of our safe copy: *)
                         let privateName =
                          let name = ewithsort lid t in 
                          let jexp = EDot(exp_of_id "global", id_of_lid lid) in 
                          (Inr name, jexp) in
                         let copyStmt = match cname.lid with
                            | [] -> (* global.$lid$ = $extern_val$ *)
                                SExp(EDotAssign(exp_of_id "global",id_of_lid lid,extern_val ["pglobal"]))
                            | c::_ -> 
                                (*global.$lid$ = function () { return $c$.$extern_val c$.apply($c$, arguments) }; *)
                                SExp(EDotAssign(exp_of_id "global",id_of_lid lid,
                                     EValue (VLambda([],
                                             SReturn(ECall(exp_of_id "apply", Some(extern_val []), 
                                                     [exp_of_id (Sugar.text_of_id c); exp_of_id "arguments"]))))))
                         in
                         (*printf "Classname: %s\n" (Sugar.text_of_id c);*)
                         [privateName, copyStmt]
                  | _ -> [])
              |> List.unzip in
  let mkObject = 
    (* let object = function (o) { 
                        let F = function () {} in 
                        F.prototype = o; 
                        return new F(); } in () *)
    SVar("object", EValue(VLambda(["o"], 
                                  SVar("F", EValue(VLambda([], SEmpty)),
                                       SSeq(SExp(EDotAssign(exp_of_id "F","prototype",exp_of_id "o")),
                                            SReturn(ENew(exp_of_id "F",[])))))), 
         SEmpty); in
  let mkGlobal =
    (* let global = object(pglobal) in () *)
    SVar("global", ECall(exp_of_id "object", None, [exp_of_id "pglobal"]), SEmpty) in
  (* HACK: this should be generated by looking at the extern declarations *)
  let mkLocalStore =
   (* let localStorage = object(pglobal.localStorage) in () *)
    SVar("localStorage", ECall(exp_of_id "object", None, [exp_of_id "pglobal.localStorage"]), SEmpty) in
  (*let wrapperGenerators = 
    SVar("equalML", EDot(exp_of_id "pglobal", "equalML"), 
         SEmpty) in *)
  env, mkObject::mkGlobal::mkLocalStore::externs

let translate_modules (ms:modul list) = 
  let env, initExterns = bind_externs ms in 
  let _, mstmts = ms |> List.fold_left 
      (fun (env,mpfxstmts) m -> 
         //let _ = Printf.printf "translate module: %s" (Pretty.strModule m) in
         let _, mstmts = List.fold_left 
           (fun (env, mstmts) (lb:letbinding, isrec) -> 
              match lb with 
                | [(x,t,e)] when (not isrec) -> 
                    let initx = 
                      if AbsynUtils.is_value e 
                      then SVar(mk_id x, to_expr env e, SEmpty)
                      else SSeq(SVarDecl(mk_id x),
                                to_stmt env e (Some <| mk_id x)) in
                    let env = (Inl x, exp_of_id <| mk_id x)::env in 
                    (env, initx::(SCommentSmall(x.ppname.idText))::mstmts)
                | _ -> 
                    let env = List.fold_left (fun env (x,_,_) -> (Inl x, exp_of_id <| mk_id x)::env) env lb in 
                    let stmts = lb |> List.collect (fun (x, _, e) -> 
                                                  if AbsynUtils.is_value e 
                                                  then [SVar(mk_id x, to_expr env e, SEmpty);
                                                        SCommentSmall x.ppname.idText]
                                                  else raise Impos) in 
                    let stmt = stmts |> List.fold_left (fun out s -> SSeq(s, out)) SEmpty in 
                      (env, stmt::mstmts)) (env, []) m.letbindings in 
         let mstmts = List.rev mstmts in 
         let obj = 
           EObjLiteral(m.letbindings |> 
                           List.collect (fun (lb, _) ->
                                           lb |> List.map (fun (x, _, _) -> (x.ppname.idText, exp_of_id (mk_id x))))) in 
         let mstmts = mstmts@[SVar(id_of_lid m.name, obj, SEmpty)] in 
         let env = extend_env env m in 
           (env, mpfxstmts@(SComment (spr "Module %s" (Sugar.text_of_lid m.name))::mstmts))) (env, []) in 
  let wrappers = build_wrappers ms in 
  let wrapped, _ = ms |> List.fold_left 
      (fun (ws, tcenv) m -> 
          let w, tcenv = wrap tcenv m (exp_of_id (id_of_lid m.name)) in
          w::ws, tcenv) 
      ([], Tcenv.mk_env ()) in 
  let wrapped = List.rev wrapped in
  let init_body = 
    mstmts
    //@[SComment "Wrappers for datatypes"]@wrappers
    @[SComment "Exporting wrapped modules"]@wrapped in 
  let init_body = List.fold_right 
    (fun s out -> SSeq(s, out)) 
    init_body SEmpty in 
  let init_body = List.fold_right 
    (fun s out -> SSeq(s, out))
    (SComment "Importing external names"::initExterns)
    init_body in 
  let init = VLambda(["pglobal"], init_body) in 
    (* let init = $init$ in
       init(window);
       init = undefined; *)
    SVar("init", EValue init, 
         SSeq(SExp(ECall(exp_of_id "init", 
                         None,  
                         [exp_of_id "window"])), 
              SExp(EAssign("init", 
                           undefined_exp))))
