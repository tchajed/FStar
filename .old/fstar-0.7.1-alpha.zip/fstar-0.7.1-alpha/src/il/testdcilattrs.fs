﻿module Microsoft.FStar.TestDcilAttrs

open System
open System.Text

open Microsoft.FSharp.Compiler.AbstractIL
open Microsoft.FSharp.Compiler.AbstractIL.IL
open Microsoft.FStar.DcilAttrs
open Microsoft.FStar.Target
open Microsoft.FStar.AttribAst
open Microsoft.FStar.Attribs
open Microsoft.FStar.Util

let _ = Util.prettyAttribs := true

let set_pretty () : unit = Util.prettyAttribs := true
let unset_pretty () : unit = Util.prettyAttribs := false

(* Some values. *)
let const_true = TVal_constant (Sugar.Const_bool true)

(* Some types. *)
let ty_index = TType_index (uint16 (0))
let ty_var (tname : string) = TType_var (tname, TKind_star)
let ty_fun = TType_fun (None, ty_var "t0", ty_var "t1")

(*
and tType =
  | TType_name of tName<tKind> * option<Sugar.externref> (* type names [for external types] *)
  | TType_tfun of tBvDef * tKind * tType        (* \a::k.t *)
  | TType_dep of tType * tValue                 (* dependent type function application *)
  | TType_tapp of tType * tType                 (* type application *)
  | TType_concrete of tTypeConcrete             (* data class *)
  | TType_affine of tType                       (* affine type *)
  | TType_refine of tBvDef * tType * tFormula * string * list<tClassName * list<tType>>  (* x:t{phi} *)
  | TType_inferred of Unionfind.uvar<tUvar_inferred>     (* place holder for inferrable types, currently used only for let bindings *)
*)

(* Evidences. *)
let ev_val : tEvidence = TEv_val (("v0", boolType), const_true)
let ev_type : tEvidence = TEv_type(("t0", TKind_star), boolType)
let empty_evidences : Evidence = Evidence(Some [], None)
let single_type_evidence : Evidence = Evidence(Some [ev_type], None)
let single_val_evidence : Evidence = Evidence(Some [ev_val], None)

(* Types *)
(* Can be used for SuperClassType, MethodReturnType *)
let sct_index : SuperClassType = SuperClassType(Some ty_index, None)

(* LocalTypeDecls *)
(* TODO: Change after we get parsing working. *)
let empty_decls = LocalTypeDecls(Some (0, []), None)
let single_decl = LocalTypeDecls(Some (1, [("v", Some intType)]), None)
let double_decls = LocalTypeDecls(Some (2, [("v1", Some intType); ("v2", Some boolType)]), None)

(* GenericParamKind *)
let kind_star = GenericParamKind(Some TKind_star, None)

(* ClassPtvars *)
let empty_ptvars = ClassPtvars(Some [], None)
let single_ptvar = ClassPtvars(Some ["k1"], None)

(* ClassParamKinds *)
let empty_kinds = ClassParamKinds(Some [], None)
let single_kinds = ClassParamKinds (Some [TKind_star], None)

(* MethodParamTypes *)
let empty_method_params = MethodParamTypes(Some [], None)
let single_method_params = MethodParamTypes(Some [("v1", intType)], None)
let double_method_params = MethodParamTypes(Some [("v1", intType); ("v2", boolType)], None)

(* MethodReturnType *)
let simple_method_return = MethodReturnType (Some intType, None)

(* FieldDeclType *)
let simple_field_decl_ty = FieldDeclType(Some intType, None)

(* HigherOrderTvars *)
(* type HigherOrderTvars(_vopt:list<int*tVar<tKind>> option, _seropt:string option) = *)

(* ClassKind *)
let star_class_kind = ClassKind(Some TKind_star, None)

(*
type NewObjType(_vopt:(uint16 * tTypeConcrete) list option, 
                _vsimpleopt :  (uint16 * (tType list -> tType list * int)) list option, 
                _seropt : string option) = 
*)

(*
type TypeInstantiation(_vopt:(uint16 * tType) list option, 
                       _vsimpleopt: (uint16 * (tType -> tType)) list option,
                       _seropt:string option) = 
    inherit DcilAttribute()
    let mutable vopt = _vopt
    let mutable vsimpleopt = _vsimpleopt
    let mutable seropt = _seropt 
    new(v) = TypeInstantiation(Some v, None, None)
    new(ser) = TypeInstantiation(None, None, Some ser)
    override this.attrName = "TypeInstantiation"
    static member fullTypeName = TypeInstantiation(None, None, None).GetType().FullName
    static member decode(attrs:ILAttributes) = 
        match DcilAttribute.decodeData(attrs, TypeInstantiation.fullTypeName) with 
            | None -> TypeInstantiation([])
            | Some ser -> TypeInstantiation(None, Some (TypeInstantiation.decodeString(ser)), Some ser)
    static member decodeString(ser) = 
      let getType aty default_ty =
        match Attribs.aType2tType (Some default_ty) aty with
        | Some t -> t
        | None -> raise (AttributeCodec "no type") in
        let r:((uint16 * aType) list) = DcilAttribute.deserialize ser 
        r |> List.map (fun (idx, aty) -> (idx, getType aty))
    override this.getSerialForm() = match seropt, vopt with 
        | Some ser, _ -> ser
        | _, Some v -> 
            let ser = to_b64(Attribs.CustomAttr.toCompactRepr(v)) in
            seropt <- Some ser;
            ser
        | _ -> raise (AttributeCodec "Empty TypeInstantiation")
    member this.getValueSimple() = match vsimpleopt with 
        | Some v -> v
        | _ -> match vopt, seropt with 
                | Some v, _ -> this.simplify v
                | _, Some ser -> 
                    let v = TypeInstantiation.decodeString(ser)
                    vsimpleopt <- Some v;
                    v
                | _ -> raise (AttributeCodec "Empty TypeInstantiation")
    member this.simplify(v) : (uint16 * (tType -> tType)) list = 
        v |> List.map (fun (i, t) -> (i, fun _ -> t))

type ExternMethods(_vopt:tExternMethodDecl list option, _seropt:string option) = 
    inherit DcilAttribute()
    let mutable vopt = _vopt
    let mutable seropt = _seropt 
    new(v) = ExternMethods(Some v, None)
    new(ser) = ExternMethods(None, Some ser)
    override this.attrName = "ExternMethods"
    static member fullTypeName = ExternMethods(None, None).GetType().FullName
    static member decode(attrs:ILAttributes) = 
        match DcilAttribute.decodeData(attrs, ExternMethods.fullTypeName) with 
            | None -> ExternMethods([])
            | Some ser -> ExternMethods(Some (ExternMethods.decodeString(ser)), Some ser)
    static member decodeString(ser) : tExternMethodDecl list = DcilAttribute.deserialize ser
    override this.getSerialForm() = match seropt, vopt with 
        | Some ser, _ -> ser
        | _, Some v -> 
            let ser = to_b64(Attribs.CustomAttr.toCompactRepr(v)) in
            seropt <- Some ser;
            ser
        | _ -> raise (AttributeCodec "Empty ExternMethods")
    member this.getValue(def) = match vopt, seropt with 
        | Some v, _ -> v
        | _, Some ser -> 
            let v = ExternMethods.decodeString(ser)
            vopt <- Some v;
            v
        | _ -> raise (AttributeCodec "Empty ExternMethods")
    member this.getValue() = match vopt with 
        | Some v -> v
        | _ -> raise (AttributeCodec "Empty ExternMethods")


        *)
