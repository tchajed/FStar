module Microsoft.FStar.Runtime.ProcessILEnv

open Microsoft.FStar.Runtime.Utils

open Microsoft.FSharp.Compiler.AbstractIL
open Microsoft.FSharp.Compiler.AbstractIL.BinaryReader
open Microsoft.FSharp.Compiler.AbstractIL.BinaryWriter
open Microsoft.FSharp.Compiler.AbstractIL.IL

open Microsoft.FStar
open Microsoft.FStar.Target

(* Continuation for processing sequences of IL instructions. *)
type ptExp =
  | TExp of tExp
  | InstMatch of tExp * ((tVar<tType>) list)
  | InstBr of ptExp * tExp

type expstack = tExp list
type genericstack = tType list

(******************************)
(* IL processing environment. *)
(******************************)
type procenv = { isPickled : bool
               ; modname : string
               ; superclass_types : (tClassName, tType option) Hashtbl.t
               ; sfields : (string, tExp * tType option) Hashtbl.t
               ; field_types : (string, tType) Hashtbl.t
               ; extern_methods : (string, Sugar.externref) Hashtbl.t }
let (empty_procenv : procenv) =
  { isPickled = false
  ; modname = ""
  ; superclass_types = Hashtbl.create 20
  ; sfields = Hashtbl.create 20
  ; field_types = Hashtbl.create 20
  ; extern_methods = Hashtbl.create 25 }

type methodenv =
  { lblocks : (ILCodeLabel, (procenv * methodenv -> ptExp) * tType) Hashtbl.t
  ; args : tVar<tType> list
  ; value_args : tVar<tType> list
  ; localTypes : tVar<tType> list
  ; locals : (string * bool * tExp option) array
  ; obj_types :
    ( uint16
    , (tType list) -> (tType list) * int) Hashtbl.t
  ; tyapp_types : (uint16, tType -> tType) Hashtbl.t
  ; numlocals : int
  ; expand_vars : bool }
let empty_methodenv () : methodenv =
  { lblocks = Hashtbl.create 100
  ; args = []
  ; value_args = []
  ; localTypes = []
  ; locals = Array.create 0 ("dl", false, None)
  ; obj_types = Hashtbl.create 20
  ; tyapp_types = Hashtbl.create 4
  ; numlocals = 0
  ; expand_vars = false }

type mkont = (ptExp * tType) -> (procenv * methodenv) -> ptExp

(*******************)
(* Default values. *)
(*******************)
let default_local_val = TExp_val (TVal_constant (Sugar.Const_int32 -1))
let default_error_val = TExp_val (TVal_constant (Sugar.Const_int32 -2))
let default_exp = TExp_val (TVal_constant (Sugar.Const_int32 3))
