#light "off"

module Microsoft.FStar.Runtime.ProcessIL

open Microsoft.FStar.Runtime.Utils
open Microsoft.FStar.Runtime.ProcessILEnv
open Microsoft.FStar.Runtime.ProcessILUtils
open Microsoft.FStar.Util

open Microsoft.FSharp.Compiler.AbstractIL
open Microsoft.FSharp.Compiler.AbstractIL.BinaryReader
open Microsoft.FSharp.Compiler.AbstractIL.BinaryWriter
open Microsoft.FSharp.Compiler.AbstractIL.IL

open Microsoft.FStar
open Microsoft.FStar.Target
open Microsoft.FStar.TargetUtil
open Microsoft.FStar.DcilAttrs

let builtins = new Set<string> ([ "Prims"; "ProofLib" ])
let is_builtin x = builtins.Contains(x) 

let cleanname (name : string) = (name.Split ('`')).[0] 
let hasreturn ty = ty = TType_name ((["Prims"; "unit"], TKind_star), None)

(* Handling IL class access level. *)
let processILTDAccess (acc : ILTypeDefAccess) : tVisibility =
  match acc with
  | IL.Public -> TVis_public
  | IL.Private -> TVis_internal
  | IL.Nested member_access ->
    (match member_access with
    | MemAccess_assembly -> raise (Unexpected "assembly")
    | MemAccess_compilercontrolled -> raise (Unexpected "cc")
    | MemAccess_famandassem -> raise (Unexpected "famandassem")
    | MemAccess_famorassem -> raise (Unexpected "famorassem")
    | MemAccess_family -> raise (Unexpected "family")
    | MemAccess_private -> TVis_internal
    | MemAccess_public -> TVis_public)

(* Process types. *)
let rec processTypeSpec (gtys, penv) (ts : ILTypeSpec) : tType =
  let mkTNameStar n = TType_name ((n, TKind_star), None) in
  let (tname : string) = ts.FullName in
  match tname with
  | "System.Boolean" -> mkTNameStar [ "Prims"; "bool" ]
  | "System.Int32" -> mkTNameStar [ "Prims"; "int" ]
  | "System.Object" -> mkTNameStar [ "System"; "object" ]
  | "System.String" -> mkTNameStar [ "Prims"; "string" ]
  | "Microsoft.FSharp.Core.Unit" -> mkTNameStar [ "Prims"; "unit" ]
  | "Microsoft.FSharp.Core.FSharpFunc`2" -> processDepClass "DepArrowSS" (gtys, penv) ts
  | "Tuple_UU`2" -> processDepClass "Tuple_UU" (gtys, penv) ts
  | "Prims.All" -> processParamClass "All" (gtys, penv) ts
  | "Prims.DepTuple2SS`2" -> processDepClass "DepTuple2SS" (gtys, penv) ts
  | _ -> processParamClass (cleanname tname) (gtys, penv) ts
and processAll (gtys, penv) (ts : ILTypeSpec) : tType =
  TType_concrete
    ( ["All"], [], List.map (fun targ -> Targ(processType penv targ)) ts.GenericArgs, None )
and processDepClass depname (gtys, penv) (ts : ILTypeSpec) : tType =
  let arg0 = processType (gtys, penv) ts.GenericArgs.[0] in
  let arg0_name = gensym () in
  let arg' =
    processType (add_types gtys [arg0], penv) ts.GenericArgs.[1] in
  let arg1 = TType_fun (Some (arg0_name, arg0_name), arg0, arg') in
    TType_concrete
        ( [ depname ], [ (* Kinds *) ], [ Targ arg0; Targ arg1 ], None)
(* Process a class that may take generic parameters. *)
and processParamClass
  (classname : string) (gtys, penv) (ts : ILTypeSpec) : tType =
  let classidentarr = (classname.Split ('.')) in
  let classident =
    List.rev (Array.fold (fun acc x -> x::acc) [] classidentarr) in
  let ident = classident in
  if List.length ts.GenericArgs = 0
    then TType_name ((ident, TKind_star), None)
    else
      let (_gtys', rgparams) =
        List.fold
          (fun (gtys', args) ilty ->
            let tty = processType (gtys', penv) ilty in
              (add_types gtys' [tty], tty::args)) (gtys, []) ts.GenericArgs in
      TType_concrete ( ident, [], List.map Targ (List.rev rgparams), None) (* !! *)
and processType (gtys, penv) (t : ILType) : tType =
  match t with
  | Type_void -> unitType
  (* TODO: Are bytes the only kind of array? *)
  | Type_array (_shape, ty) -> TType_name ((["Prims"; "bytes"], TKind_star), None)
  | Type_value tspec -> processTypeSpec (gtys, penv) tspec
  | Type_boxed ty -> processTypeSpec (gtys, penv) ty
  | Type_fptr _ptr -> raise (Unexpected "fcode pointer")
  | Type_tyvar i -> get_generic_arg gtys (int i)
  | Type_ptr _ty -> raise (Unexpected "pointer")
  | Type_byref _ty -> raise (Unexpected "byref")
  | Type_modified (_required, _class, _ty) -> raise (Unexpected "modified type")

(****************************)
(* Processing instructions. *)
(****************************)
let getVal exp =
    match exp with
    | TExp_val v -> v
    | TExp_name ((v, ty), None) ->
      let vlast = v.[(List.length v) - 1] in
      if vlast.Contains (".")
        then
          TVal_var (vlast, ty)
        else
          let v' = String.concat "." v in
            TVal_var (v', ty)
    | _ -> raise (Unexpected "non-value")

(* Process arithmetic instructions. *)
let processArithInstr (penv, menv, es, k) (ai : ILArithInstr)
  : expstack * tExp =
  match ai with
  | AI_add ->
    let (es', arg1) = pop_exp es in
    let (es'', arg2) = pop_exp es' in
    let val1 = getVal arg1 in
    let val2 = getVal arg2 in
    let add_exp = TExp_primop (ADD, [val1; val2]) in
      (push_exp es'' add_exp, add_exp)
  | AI_add_ovf -> raise Undefined
  | AI_add_ovf_un -> raise Undefined
  | AI_and -> raise Undefined
  | AI_div -> raise Undefined
  | AI_div_un -> raise Undefined
  | AI_ceq -> raise Undefined
  | AI_cgt -> raise Undefined
  | AI_cgt_un -> raise Undefined
  | AI_clt -> raise Undefined
  | AI_clt_un -> raise Undefined
  | AI_conv _ty -> raise Undefined
  | AI_conv_ovf _ty -> raise Undefined
  | AI_conv_ovf_un _ty -> raise Undefined
  | AI_mul -> raise Undefined
  | AI_mul_ovf -> raise Undefined
  | AI_mul_ovf_un -> raise Undefined
  | AI_rem -> raise Undefined
  | AI_rem_un -> raise Undefined
  | AI_shl -> raise Undefined
  | AI_shr -> raise Undefined
  | AI_shr_un -> raise Undefined
  | AI_sub -> raise Undefined
  | AI_sub_ovf -> raise Undefined
  | AI_sub_ovf_un -> raise Undefined
  | AI_xor -> raise Undefined 
  | AI_or -> raise Undefined 
  | AI_neg -> raise Undefined
  | AI_not -> raise Undefined
  (* Loads null onto the stack. *)
  | AI_ldnull ->
    let nullval = TExp_val (TVal_constant (Sugar.Const_unit)) in
      (push_exp es nullval, nullval)
  | AI_dup | AI_pop | AI_ckfinite -> raise (Unexpected "arith instrs")
  | AI_nop -> (es,  TExp_val (TVal_constant (Sugar.Const_int32 0)))
  | AI_ldc (ty, cspec) ->
    let ldval =
      (match ty with
      | DT_I4 ->
        (match cspec with
        | NUM_I4 i ->
          if i = 0
            then TExp_val (TVal_constant (Sugar.Const_bool false))
            else
              if i = 1
                then TExp_val (TVal_constant (Sugar.Const_bool true))
                else TExp_val (TVal_constant (Sugar.Const_int32 i))
        | _ -> raise (Unexpected "type/spec mismatch"))
      | DT_I8 ->
        (match cspec with
        | NUM_I8 i -> TExp_val (TVal_constant (Sugar.Const_int64 i))
        | _ -> raise (Unexpected "type/spec mismatch"))
      | DT_R4 ->
        (match cspec with
        | NUM_R4 s -> TExp_val (TVal_constant (Sugar.Const_float32 s))
        | _ -> raise (Unexpected "type/spec mismatch"))
      | DT_R8 ->
        (match cspec with
        | NUM_R8 d -> TExp_val (TVal_constant (Sugar.Const_float d))
        | _ -> raise (Unexpected "type/spec mismatch"))
      | _ -> raise (Unexpected "load type")) in
    (push_exp es ldval, ldval)
let processCompInstr (es : expstack) (c : ILComparisonInstr)
  : expstack * tExp =
  match c with
  | BI_brtrue -> (es, TExp_val (TVal_constant (Sugar.Const_bool true)))
  | _ -> raise Undefined
let processInstr
  (retty : tType option) (gtys : genericstack)
  ((penv, menv, es, k) : procenv * methodenv * expstack * mkont)
  (instr : ILInstr)
  : procenv * methodenv * expstack * mkont =
  match instr with
  (**********)
  (* Basic. *)
  (**********)
  | I_arith ai ->
    let (es', e) = processArithInstr (penv, menv, es, k) ai in
      (match ai with
      | AI_nop ->
        let k' =
          fun (e, ty) menv -> k (InstMatch (getTexp e, []), ty) menv in
        (penv, menv, es', k')
      | _ -> (penv, menv, es', k))
  (* Load argument onto the stack. *)
  | I_ldarg arg_idx ->
    let idx : int = int arg_idx in
    let arg = TExp_val (TVal_var (get_arg menv idx)) in
      (penv, menv, push_exp es arg, k)
  | I_ldarga _ -> raise Undefined
  | I_ldind (_align, _vol, _by) -> raise Undefined
  (* Load local onto the stack. *)
  | I_ldloc loc_idx ->
    let idx = int loc_idx in
    let hasty, mexp = get_local_exp menv idx in
    let locvar = get_local menv idx in
    let ldexp =
      if hasty
        then
          match mexp with
          | Some exp ->
            (match exp with
            | TExp_val v -> exp
            | _ -> TExp_val (TVal_var locvar))
          | None -> TExp_val (TVal_var locvar)
        else TExp_val (TVal_var locvar) in
      (penv, menv, push_exp es ldexp, k)
  | I_ldloca _ -> raise Undefined
  | I_starg _ -> raise Undefined
  | I_stind _ -> raise Undefined
  (* Pop from the stack and store into a local. *)
  | I_stloc loc_idx ->
    let get_list_rest dropnum lst =
      let list_rest = (List.length lst) - dropnum in
       ( lst |> Seq.take dropnum |> Seq.toList
       , lst |> Seq.skip dropnum |> Seq.take list_rest |> Seq.toList ) in

    let idx : int = int loc_idx in
    let (es', exp) = pop_exp es in
    (* Special case to handle new objects. *)
    let processed_exp, has_ty (* TODO: get rid of has_ty *) =
       match lookup_obj_type menv loc_idx with
        | Some fn ->
            (match exp with
                | TExp_val (TVal_obj (objty, valargs)) ->
                    let (cname, kinds, args, extref) = objty in
                    let (attrtys, num_tyargs) = fn (getTys args) in
                    let tyvals, vals = get_list_rest num_tyargs valargs in
                    let cty = (cname, kinds, (List.map Targ attrtys)@(List.map Varg tyvals), extref) in
                      (TExp_val (TVal_obj (cty, vals)), true)
                | _ -> raise (PickleInternalError "should not happen"))
        | None ->
            (match lookup_tyapp_type menv loc_idx with
            | Some tfn ->
              (match exp with
              | TExp_call (objval, args, ("TyApp", [tyarg])) ->
                let tyarg' = tfn tyarg in
                  ( TExp_call (objval, args, ("TyApp", [tyarg']))
                  , false)
              | _ ->
                (match exp with
                | TExp_val (TVal_obj _) -> exp, true
                | _ -> exp, false))
          (* (* Printf.printf "%A\n" exp; raise (Unexpected "something else") *) exp, false) *)
            | None ->
                (match exp with
                | TExp_val (TVal_obj _) -> exp, true
                | _ -> exp, false)) in
    let varname, varty = store_local menv idx has_ty (Some processed_exp) in
    let k' =
      fun (pte, ty) ->
        match pte with
        | TExp e ->
          k
            (TExp
              (TExp_let ((varname, varty), processed_exp, e, ref true)), ty)
        | InstMatch (e, vtys) -> k (InstMatch (e, (varname, varty)::vtys), ty)
        | InstBr (_e, _d) -> raise (Unexpected "inst branch") in
      (penv, menv, es', k')
  (*********************)
  (* Control transfer. *)
  (*********************)
  | I_br label ->
    ( penv, menv, es
    , fun _e final_env ->
        let e, ty = (get_labelled_exp final_env label) in
          k (e final_env, ty) final_env )
  | I_jmp _ -> raise Undefined
  | I_brcmp (compinstr, label1, label2) ->
    let (es', ce) = processCompInstr es compinstr in
    let newk =
      fun _e final_env ->
        let (te', tety) = (get_labelled_exp final_env label1) in
        let te = te' final_env in
        let (tf', tfty) = (get_labelled_exp final_env label2) in
        let tf = tf' final_env in
          match te with
          | TExp e ->
            (match ce with
            | TExp_val (TVal_constant (Sugar.Const_bool true)) ->
              k (te, tety) final_env
            | TExp_val (TVal_constant (Sugar.Const_bool false)) ->         
              k (tf, tfty) final_env
            | _ ->
              k
                (TExp (TExp_cond (ce, getTexp te, getTexp tf)), tety)
                final_env)
          | InstMatch (e, vartys) ->
            k (InstBr (te, getTexp tf), tety) final_env
          | InstBr (_, _) -> raise (Unexpected "inst br") in
      (penv, menv, es', newk)
  | I_switch (_, _) -> raise Undefined
  (* The evaluation of the instruction before the return *should* have produced
     a value and so our current continuation k should have the form
     \k.[returned expression].  Thus we can apply it to TExp_bot to get the
     result. *)
  | I_ret ->
    (match retty with
    | Some ty ->
        let (es', rexp) = pop_exp es in
        let returnexp = convertInts ty rexp in
          (penv, menv, es', fun _e -> k (TExp returnexp, ty))
    | None ->
        let nullval = TExp_val (TVal_constant (Sugar.Const_unit)) in
          (penv, menv, es, fun _e -> k (TExp nullval, unitType)))
  | I_call (_tcall, mspec, varargs) ->
    let ilmref = mspec.MethodRef in
    let gtyargs = List.map (processType (gtys, penv)) mspec.GenericArgs in
    let numargs = List.length ilmref.ArgTypes in
    let mname = ilmref.Name in
    let (es', args) = get_args es numargs in
    (* Processing constructor to make a new object.  This should only happen
       for a call to a superclass constructor.  We should be throwing away
       this result. *)
    if mname.Equals (".ctor")
      then
        let objty =
          ([cleanname ilmref.EnclosingTypeRef.Name], [], List.map Targ gtyargs, None) in
        let newobj =
          TExp_val (TVal_obj (objty, args))in
          (penv, menv, push_exp es' newobj, k)
      (* External method call. *)
      else
        let mcall =
          TExp_extern_call (get_extern penv mname, (mname, gtyargs), args) in
          (penv, menv, push_exp es' mcall, k)
  (* Virtual call. *)
  | I_callvirt (_tailcall, mspec, _varargs) ->
    let generic_args = List.map (processType (gtys, penv)) mspec.GenericArgs in
    let mref = (mspec.MethodRef.Name, generic_args) in
    let (es', args) = get_args es (List.length mspec.FormalArgTypes) in
    let (es'', exp) = pop_exp es' in
      (penv, menv, push_exp es'' (TExp_call (getVal exp, args, mref)), k)

  (* New object. *)
  | I_newobj (mspec, varargs) ->
    let objname = mspec.MethodRef.EnclosingTypeRef.Name in
    let classname =
      let cname = List.map cleanname (String.split ['.'] objname) in
        if List.length cname = 1
          then (mspec.MethodRef.EnclosingTypeRef.Enclosing) @ cname
          else cname in
    
    let gtyargs =
      List.map (processType (gtys, penv)) mspec.EnclosingType.GenericArgs in
    let objty =
      let gtyargs' =
        match classname with
        | [ "Prims"; "Tuple_UU" ] | [ "DepArrow2SS" ] | [ "DepTuple2SS" ] ->
          if List.length gtyargs = 2
            then [gtyargs.[0]; TType_fun (None, gtyargs.[0], gtyargs.[1])]
            else raise (Unexpected "tuple type with <> 2 args.")
        | _ -> gtyargs in
      (classname, [(* kinds *)], List.map Targ gtyargs', None) in

    let (es', args) = get_args es (List.length mspec.FormalArgTypes) in
    
    (* Handle exceptions by pushing bottom on the stack. *)
    let newobj =
      if objname.Equals("System.Exception")
        then TExp_bot
        else TExp_val (TVal_obj (objty, args)) in
      (penv, menv, push_exp es' newobj, k)
  (* Exceptions - throw expects an exception to be on the stack? *)
  | I_throw ->
    let (es', except_exp) = pop_exp es in
      (penv, menv, es', fun _e -> k (TExp except_exp, botType))
  | I_endfinally -> raise Undefined
  | I_endfilter -> raise Undefined
  | I_leave _ -> raise Undefined
  (************************)
  (* Object instructions. *)
  (************************)
  (* Push the value of the (static?) field onto the stack. *)
  (* NOTE: Hmm, we might not know this until later... *)
  | I_ldsfld (_vol, fieldspec) ->
    let parname = fieldspec.FieldRef.frefParent.Name in
    let sref_name = fieldspec.Name in
    let sfty =
      match get_field_type penv sref_name with
      | Some ty -> ty
      | None -> raise (Unexpected "Looking up unknown static field") in
    let sfref =
      if parname.Equals(penv.modname) (* is_builtin parname || (not (parname.Euq)) *)
        then TExp_val (TVal_var (sref_name, sfty))
        else TExp_name (([parname; sref_name], sfty), None) in
    let es' = push_exp es sfref in
      (penv, menv, es', k)
  (* Load field. *)
  | I_ldfld (_align, _vol, fieldspec) ->
    let (es', e) = pop_exp es in
    let ef =
      match e with
      | TExp_val v ->
        (match v with
        (* If it's this, then just push a variable reference rather than a
           field load. *)
        | TVal_var ("this", TType_var ("TODO", TKind_star)) ->
          let fieldname = fieldspec.FieldRef.Name in
          let fieldty =
            match get_field_type penv fieldname with
            | Some ty -> ty
            | None -> raise (Unexpected "field should have a type") in
            TExp_val (TVal_var (fieldname, fieldty))
        | _ -> TExp_val (TVal_ldfld (v, fieldspec.FieldRef.Name)))
      | _ -> raise (Unexpected "don't have a value") in
      (penv, menv, push_exp es' ef, k)
  | I_ldsflda (_fieldspec) -> raise Undefined
  | I_ldflda (_fieldspec) -> raise Undefined
  (* Update static field. *)
  (* Add a static definition here. *)
  | I_stsfld (_, fieldspec) | I_stfld (_, _, fieldspec) ->
    let fname = fieldspec.Name in
    let (es', v) = pop_exp es in
    let vexp, vty =
      match v with
      | TExp_val (TVal_obj (cty, _vals)) ->
        let (cname, _, _, _) = cty in
        (* TODO: Break this out into a separate type inference function. *)
        let ty =
          match get_superclass_type penv cname with
          | Some ty -> ty
          | None ->
            (match cty with
            | (["Prims"; "Tuple_UU"], kindargs, args, None) ->
              (* TODO: Figure out why we would have value arguments. *)
              TType_concrete (["DepTuple2SS"], kindargs, List.map Targ (getTys args), None)
            | _ -> TType_concrete cty) in
        let vexp =
          match k (TExp v, ty) (penv, menv) with
          | TExp e -> e
          | _ -> raise (Unexpected "non-exp result") in
          (set_field_type penv fname ty;
           vexp, Some ty)
      | _ ->
        v, None in
      add_static_def penv fname vexp vty;
      (penv, menv, es', default_kont)
  (* Load a string onto the stack. *)
  | I_ldstr str ->
    (* NOTE: Um, I am using an arbitrary second part here. *)
    let str' =
      (System.Text.Encoding.Unicode.GetBytes(str), 1044855479211737092L) in
    let es' =
      push_exp es (TExp_val (TVal_constant (Sugar.Const_string str'))) in
      (penv, menv, es', k)
  (* Processing pattern match. *)
  | I_isinst ty ->
    let matchty = processType (gtys, penv) ty in
    let matchty_name, targs =
      (match matchty with
      | TType_name ((cname, _kind), _extref) -> cname, []
      | TType_concrete (cname, ks, args, _) -> cname, getTys args (* !! *)
      | _ -> Printf.printf "%A\n" matchty; raise (Unexpected "non-concrete type")) in
    let (es', v) = pop_exp es in
    (* We expect the thing we popped off the stack to be a value. *)
    let matchobj =
      match v with
      | TExp_val ve -> ve
      | _ -> Printf.printf "%A\n" v; raise (Unexpected "non-value") in
    let instk =
      fun (pte, expty) (penv, menv) ->
        let instexp =
          match pte with
          | InstBr (tbr, default_exp) ->
            let boundvars, matchexp =
              (match tbr with
              | InstMatch (e, vartys) -> List.rev vartys, e
              | _ -> raise (Unexpected "!")) in
            TExp
              (TExp_isinst
                ( matchobj
                , [(matchty_name, [], (List.map Ptype targs) @ (List.map Pvar boundvars), false, convertInts expty matchexp)] (* TODO, isGADT!! *)
                , convertInts expty default_exp, expty))
          | _ -> Printf.printf "%A\n" pte; raise (Unexpected "!") in
         k (instexp, expty) (penv, menv) in
        (penv, menv, es', instk)
  (* Casting from one class to another. *)
  | I_castclass ty ->
    let (es', exp) = pop_exp es in
    let castty = processType (gtys, penv) ty in
    (* Getting the new expression. *)
    let exp' =
      match exp with
      | TExp_val v ->
        let v' =
          (match v with | TVal_var (v, ty) -> TVal_var (v, castty) | _ -> v) in
          TExp_val v'
      | TExp_name ((n, ty), None) -> TExp_name ((n, castty), None)
      | _ -> exp in
      (penv, menv, push_exp es' exp', k)
  | I_ldtoken _ | I_callconstraint (_, _, _, _) | I_calli (_, _, _)
  | I_ldftn _ -> raise Undefined
  | _ -> raise (Unexpected "Some other instruction.")
  
let processBasicBlock (retty : tType option) (gtys, penv, es, menv) (bb : ILBasicBlock)
  : procenv * methodenv * expstack * mkont =
  let (label : ILCodeLabel) = bb.Label in
  (* Printf.printf "Processing block with label %d: %A\n" label bb.Instructions; *)
  let (instrs : ILInstr array) = bb.Instructions in
  let blockty =
    match retty with
    | Some ty -> ty
    | None -> unitType in
  let (penv', menv', es', k) =
    Array.fold (processInstr retty gtys)
      (penv, menv, es, fun (e, _ty) env -> e) instrs in
    (* Plugging bottom into our continuation should not do anything bad. *)
  let _ = add_labelled_exp menv' label
        ((fun (penv, menv) -> (k (TExp default_error_val, intType) (penv, menv))), blockty) in
    (penv', menv', es', k)

(* Processing a code block. *)
let rec processILCode (retty : tType option) (gtys, penv, es, menv) (ilc : ILCode)
  : procenv * methodenv * expstack * mkont =
  match ilc with
  | ILBasicBlock bb -> processBasicBlock retty (gtys, penv, es, menv) bb
  (* For a group block, thread each continuation through to the next one. *)
  | GroupBlock (_debugmap, codelst) ->
    let ((rpenv, rmenv), es', reversek's) =
      List.fold
        (fun ((cpenv, cmenv), cur_es, curk) code ->
          let (penv', menv', es', k') =
            processILCode retty (gtys, cpenv, cur_es, cmenv) code in
            ((penv', menv'), es', k'::curk))
          ((penv, menv), es, []) codelst in
    let kfst, krst =
      match List.rev reversek's with
      | k::ks -> k, ks
      | [] -> raise (Unexpected "empty block") in
      (rpenv, rmenv, es', kfst)
  | RestrictBlock (internal_labels, code) ->
    processILCode retty (gtys, penv, es, menv) code
  | TryBlock (_code, _exception) -> raise (Unexpected "try block")

(* Get the name and kind of generic parameters. *)
let processGenericParam (p : ILGenericParameterDef) : tVar<tKind> =
  let kind = GenericParamKind.decode(p.gpCustomAttrs).getValue() in
    (p.gpName, kind)

(*******************************)
(* Process method definitions. *)
(*******************************)
let processMethodDef ext (gtys, tpenv, penv) (m : ILMethodDef)
  : procenv * tMethodDecl =
  let _ = Printf.printf "CIL->DCIL method: %A\n" m.mdName in
  let attrs = m.CustomAttrs in

  (* Process generic parameters and add them to the environment. *)
  (* NOTE: Not processing higher-order tvars in a special way yet. *)
  let generic_params =
    let raw_gps = List.map processGenericParam m.GenericParams in
    let kinds = ClassParamKinds.decode(attrs).getValue() in
      List.map
        (fun ((v, _origk), newk) -> (v, newk)) (List.zip raw_gps kinds) in
  let gtys' =
    add_types gtys (List.map (fun v -> TType_var v ) generic_params) in

  (* Special case for handling TyApp.
     Get the return type, and, look at the return type to determine whether a
     return value is expected. *)
  let default_returnty =
    if m.Name.Equals("TyApp")
      then
        (match ext with
        | Some t ->
          (match t with
          | TType_concrete (["All"], _k's, [Targ (TType_tfun (_bv, _t1, ty))], _extref) -> ty
          | _ -> Printf.printf "Actual type: %A\n" t; raise (Unexpected "tyapp return"))
        | None -> raise (Unexpected "tyapp return"))
      else processType (gtys', penv) m.Return.Type in

  let retty = MethodReturnType.decode(attrs, default_returnty).getValue() in
  (* Printf.printf "Process return type %A; got %A\n" m.Return.Type retty; *)
  let retty_option =
    if ( (retty = TType_name ((["Prims"; "unit"], TKind_star), None))
         || (m.Name.Equals(".ctor")) || (m.Name.Equals(".cctor")))
      then None
      else Some retty in
  
  (* Get custom attribute for the argument types. *)
  let mp_defaults = m.mdParams |> List.map
                      (fun p -> 
                        let pname = match p.paramName with
                           | Some n -> n 
                           | None -> raise (Unexpected "no name") in
                          (pname, processType (gtys', penv) p.Type)) in
  let args = MethodParamTypes.decode(attrs, mp_defaults).getValue() in 
  let args' = ("this", TType_var ("TODO", TKind_star))::args in
  let methodenv = add_args (empty_methodenv ()) args' in
  
  let (renv, mbody) =
    match dest_mbody m.mdBody with
    | MethodBody_il mb ->
      (* Process method body. *)
      let (penv', menv', _es', k) =
        let default_locals =
          List.map
            (fun loc -> processType (gtys', penv) (typ_of_local loc))
            mb.ilLocals in
        let num_locals, localtys = LocalTypeDecls.decode(attrs, m.mdName, default_locals).getValue() in 
        let localtys = List.map (function (x, Some t) -> x,t | _ -> raise Impos) localtys in
        let menv' =
          { add_num_locals (add_locals methodenv localtys) num_locals
              with expand_vars = m.Name.Equals(".cctor") } in
        let newobjs = NewObjType.decode(attrs).getValueSimple() in
        let newobjs = newobjs |> List.map (fun (i, mkt) -> 
                        let mkt' def = 
                            let (tl, j) = mkt def in
                            (List.map (Qname.transformType tpenv) tl, j) in
                        (i, mkt')) in                              
        let tinst = TypeInstantiation.decode(attrs).getValueSimple() in
        add_obj_types menv' newobjs;
        add_tyapp_types menv' tinst;
        processILCode retty_option (gtys', penv, empty_estack, menv') mb.ilCode in
        (penv', Some (getTexp (k (TExp default_exp, intType) (penv', menv'))))
    | _ -> (penv, None) in
  let mdecl = ( retty, m.Name, generic_params, args, mbody) in
    (renv, mdecl)

(**********************************)
(* Processing class declarations. *)
(**********************************)
let processSuperClassType (env : procenv) (tdef : ILTypeDef) : unit =
  let classname = cleanname tdef.tdName in
  let tdef_attrs = tdef.CustomAttrs in
  
  (* Add generic parameters. *)
  let g_class_vars =
    let init_tvars = List.map processGenericParam tdef.tdGenericParams in
    let class_kinds =
      let ck = ClassParamKinds.decode(tdef_attrs).getValue() in
      match ck with
      | [] -> List.map (fun _ -> TKind_star) init_tvars
      | _ -> ck in
      List.map
        (fun ((v, _origk), newk) -> (v, newk))
        (List.zip init_tvars class_kinds) in
  let g_class_params = List.map (fun p -> TType_var p) g_class_vars in
    (* Add generic parameters. *)
  let gtys = add_types empty_genericstack g_class_params in
  (* Get parent class. *)
  let default_par_ty =
    match tdef.tdExtends with
    | Some ty ->
      (try
        let par_ty = processType (gtys, empty_procenv) ty in
          (match par_ty with
          | TType_name ((["System"; "object"], _), _) -> None
          | _ -> Some par_ty)
       with _ -> None)
    | None -> None in
  let ext = SuperClassType.decode(tdef_attrs, default_par_ty).getValue() in
  add_superclass_type env [env.modname; classname] (Some ext)

(***************************************)
(* Processing nested type definitions. *)
(***************************************)
let processILTypeDef (env : procenv) (tdef : ILTypeDef) : tClassDecl =
  Printf.printf "CIL->DCIL class %A\n" tdef.Name;

  let classname = cleanname tdef.tdName in
  (* How do we get the original module this thing was part of? *)
  let tdef_attrs = tdef.CustomAttrs in
  
  (* Add generic parameters. *)
  let g_class_vars =
    let init_tvars = List.map processGenericParam tdef.tdGenericParams in
    let class_kinds = ClassParamKinds.decode(tdef_attrs).getValue() in
      List.map
        (fun ((v, _origk), newk) -> (v, newk))
        (List.zip init_tvars class_kinds) in
  let class_ptvars = ClassPtvars.decode(tdef_attrs).getValue() in
  let ptvars, tvars =
    List.partition (fun (t, _kind) -> List.mem t class_ptvars) g_class_vars in
  (* Add generic parameters. *)
  let gtys =
    add_types empty_genericstack (List.map (fun p -> TType_var p) g_class_vars) in
  let ext = get_superclass_type env [env.modname; classname] in

  (* Process fields. *)
  (* Partition static fields from regular fields. *)
  let nonstatic, sfields =
    List.partition
      (fun (f : ILFieldDef) ->
      (* TODO: For some reason, using the isValueParameter causes stuff to break. *)
        not f.fdStatic (* isValueParameter (dest_custom_attrs f.CustomAttrs) *))
      (dest_fdefs tdef.tdFieldDefs) in
  let valvardefs, fielddefs =
    List.partition
      (fun (f : ILFieldDef) -> ValueParameter.decode(f.CustomAttrs))
      nonstatic in

  let procvar (vdef : ILFieldDef) =
    let default_fty = processType (gtys, env) vdef.fdType in
    let fdt = FieldDeclType.decode(vdef.CustomAttrs, default_fty).getValue() in
      (vdef.Name, fdt) in 
  let valvars = List.map procvar valvardefs in
  let fields = List.map procvar fielddefs in
  (* Add field types for value variables. *)
  let _ =
    List.fold
      (fun curenv (fname, fty) -> set_field_type env fname fty) () valvars in

  let tpenv = { Qname.modname = env.modname
              ; Qname.classname = classname
              ; Qname.staticfields =
                List.map (fun (vdef : ILFieldDef) -> vdef.Name) sfields } in

  (* Partition methods.  Need to do something special with the .ctor method,
     but this depends on. *)
  let constructorlst, methods =
    List.partition
      (fun (m : ILMethodDef) ->
        m.Name.Equals(".ctor") || m.Name.Equals(".cctor"))
      tdef.tdMethodDefs.AsList in
  (* NOTE: This assumes we always have either a constructor or a class
     constructor, but never both... *)
  let (penv, ck) =
    if List.length constructorlst > 0 
      then
        let cmdef = constructorlst.[0] in
        let (penv', ck) = processMethodDef ext (gtys, tpenv, env) cmdef in
          (penv', ck)
      else raise (Unexpected "no constructor") in
  let _ = Printf.printf "Finished processing constructor\n" in
  let (final_env, rmethoddecls) =
    List.fold
      (fun (cur_env, acc) m ->
         let (penv', m') = processMethodDef ext (gtys, tpenv, cur_env) m
          in (penv', m'::acc)) (penv, []) methods in
  let evidence = Evidence.decode(tdef_attrs).getValue() in
  let classKind = ClassKind.decode(tdef_attrs).getValue() in

  (* Return a target DCIL module. *)
  { visibility = processILTDAccess tdef.tdAccess
  ; attr = NoAttr
  (* Want to preserve the original name here. *)
  ; name = [ penv.modname; classname ]
  ; namestring = penv.modname + "." + classname
  ; kvars = []  (* !! *)
  ; vars = (List.map Tvar ptvars) @ (List.map Tvar tvars) @ (List.map Vvar valvars)
  ; evidences = evidence
  ; extends = ext
  ; fields = fields
  ; staticFields =
      List.map
        (fun (sfield : ILFieldDef) ->
          let fty =
            match get_field_type penv sfield.fdName with
            | Some ty -> ty
            | None -> raise (Unexpected "static type didn't have field def") in
            ( sfield.fdName, fty, get_static_def penv sfield.Name))
        sfields
   ; methods = List.rev rmethoddecls
  ; kind = Some classKind
  ; externref = None
  ; hasTag = false
  ; tagNum = None}

(* Processing module class definition. *)
(* Processing the module and module class definition.
   The module type definition has nested classes for the other classes defined
   within. *)
let processILModuleTypeDef (env : procenv) (tdef : ILTypeDef) : tModule =
  let tdef_attrs = tdef.CustomAttrs in

  let mname = tdef.tdName in
  let _ = Printf.printf "\nCIL->DCIL module %A\n" mname in
  let env =
    let nenv = set_mod_name env mname in
     if tdef.tdName.Equals("Pickle")
      then
        (Printf.printf "Reading pickled module\n";
         { nenv with isPickled = true })
      else nenv in
  let externs = ExternMethods.decode(tdef_attrs).getValue() in
  (* Add the extern declarations to the environment. *)
  let _ = add_externs env externs in
  (* Add superclass types for nested classes to the environment.  These are
     important for inferring the types of static fields by looking at class
     constructors. *)
  let _ = List.map (processSuperClassType env) tdef.tdNested.AsList in

  (* Create the actual module. *)
  { name = [ mname ]
  ; extends = None
  ; modCdecl =
    { processILTypeDef env tdef
        with
          visibility = TVis_public;
          name = [ mname ];
          namestring = mname }
  ; decls =
    createTCdecls
      (List.rev
        (List.fold
          (fun acc td ->
            (processILTypeDef env td)::acc) [] tdef.tdNested.AsList))
  ; externs = createTCdecls []
  ; entry  = None
  ; externMethods = externs }

(**
  This function takes a list of includes modules and an IL module and produces
  a DCIL target module.
 *)
let ilmod2target (includes : tModule list) env (ilmod : ILTypeDef) : tModule =
  (* Add information about static fields types. *)
  let get_name (n : tClassName) = List.nth n ((List.length n) - 1) in
  let addClassFieldInfo (c : tClassDecl) = 
    c.staticFields |> 
    List.iter (fun (var, ty, _e) -> set_field_type env var ty) in
  let addModuleFieldInfo m = addClassFieldInfo m.modCdecl in
      List.iter addModuleFieldInfo includes;
      processILModuleTypeDef env ilmod

(**
  This function takes a list of includes modules and an IL module and produces
  a DCIL target module.
 *)
let il2target (includes : tModule list) (ilmod : ILModuleDef) : tModule list =
  Printf.printf "Process IL Module with includes %A\n" (List.map (fun t -> t.name) includes);
  (* Create an empty environment and prime it with the class definitions from
     included classes. *)
  let env = empty_procenv in

  let (mdefs : ILTypeDef list) =
    List.filter (fun m -> m.tdAccess = IL.Public) (ilmod.modulTypeDefs).AsList in
  let (_includes', rmodules) =
    List.fold
      (fun (includes', rmods) md ->
        let newmod = ilmod2target includes' env md in
          (newmod::includes', newmod::rmods))
      (includes, []) mdefs in
    rmodules

let absil_mods_to_dcil (mods:list<ILModuleDef>) : list<tModule> = 
  let env = empty_procenv in
  let (mdefs : ILTypeDef list) =
    mods |> List.map (fun ilmod -> ilmod.modulTypeDefs.AsList) 
         |> List.flatten
         |> List.filter (fun m -> m.tdAccess = IL.Public) in 
  let (_includes', rmodules) =
    List.fold
      (fun (includes', rmods) md ->
        let newmod = ilmod2target includes' env md in
          (newmod::includes', newmod::rmods))
      ([], []) mdefs in
    rmodules
