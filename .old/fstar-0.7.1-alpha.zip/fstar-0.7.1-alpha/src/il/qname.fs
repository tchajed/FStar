#light "off"
(*
  Process the target modules in order to:
  - Qualify uses of static field names.
  - Find class dependences
*)
module Microsoft.FStar.Runtime.Qname

open Microsoft.FStar
open Microsoft.FStar.Target
open Microsoft.FStar.TargetUtil
open Microsoft.FStar.Runtime.Utils

(* Processing environment. *)
type tprocenv = { modname : string
                ; classname : string
                ; staticfields : tFieldName list }
let isStaticField penv fn =
  List.exists (fun n -> n.Equals(fn)) penv.staticfields

let getStaticFields (cdecl : tClassDecl) : tFieldName list =
  List.map (fun (fname, _fty, _fexp) -> fname) cdecl.staticFields

(*******************************)
(* Getting class dependencies. *)
(*******************************)
open Util
type dep = {curmod:string option; di:depinfo}
type stdep = Util.state<dep, unit>
let stmap l f = Util.stmap l f >> (fun _ -> ret ())

let add_class_dep (n : tLident) dep : dep =
  try
    let (mname, cname) = split_name n in
      {dep with di=add_depinfo dep.di mname cname}
  with Unexpected _ ->
    try
      let (mname, cname) =
        split_name (String.split ['.'] (n.[(List.length n) - 1])) in
        (* HACK *)
        if mname.Equals("Microsoft")
          then dep
          else {dep with di=add_depinfo dep.di mname cname}
    with Unexpected _ -> dep (* Nik: Really? *)

let add_mod_dep (n : tLident) dep : dep =
  try
    let (mname, cname) = split_name n in
    match dep.curmod with
        None -> raise Util.Impos
      | Some curmod -> {dep with di=add_depinfo dep.di curmod mname}
  with Unexpected _ -> dep (* Nik: Really? *)

let getExternDepends (er : option<Sugar.externref>) : stdep =
  match er with
  | Some ename -> 
      upd (add_class_dep (ename.classname.lid |> List.map (fun x -> x.idText)))
  | None -> ret ()

let rec getCTypeDepends
  ((obj_name, obj_kinds, obj_args, extref) : tTypeConcrete)
  : stdep =
  let obj_tys, obj_vals = getTys obj_args, getVals obj_args in
  upd (add_class_dep obj_name) >> (fun () -> 
  stmap obj_tys getTypeDepends >> (fun () -> 
  stmap obj_vals getValueDepends >> (fun () -> 
  getExternDepends extref)))

and getKindDepends (k : tKind) : stdep =
  match k with
  | TKind_star 
  | TKind_affine -> ret () 
  | TKind_arrow (ty, k) -> 
        getTypeDepends ty >> (fun () -> 
        getKindDepends k)
  | TKind_karrow (k1, k2) ->
        getKindDepends k1 >> (fun () -> 
        getKindDepends k2)
  | TKind_var _ -> raise (Unimplemented "hmm")

and getTypeDepends (t : tType) : stdep =
  match t with
  | TType_index _ 
  | TType_inferred _ -> ret ()
  (* TODO: Make sure this is right. *)
  | TType_var (_v, kind) -> 
       getKindDepends kind
  | TType_name ((n, kind), extref) ->
       getExternDepends extref >> (fun () -> 
       getKindDepends kind)
  | TType_tapp (t1, t2) 
  | TType_fun (_, t1, t2) ->
       getTypeDepends t1 >> (fun () -> 
       getTypeDepends t2)
  | TType_tfun (_varname, kind, t) ->
       getKindDepends kind >> (fun () -> 
       getTypeDepends t)
  | TType_dep (ty, v) ->
      getTypeDepends ty >> (fun () -> 
      getValueDepends v)
  | TType_concrete tc -> getCTypeDepends tc
  | TType_affine t -> getTypeDepends t
  | TType_refine _ -> raise (Unimplemented "!!")
  
and getMethodDepends ((_mname, tylst) : tMethodRef) : stdep =
  stmap tylst getTypeDepends

and getValueDepends (v : tValue)  : stdep =
  match v with
  | TVal_constant _ 
  | TVal_var _ 
  | TVal_uvar _ -> ret ()
  | TVal_obj (ct, vals) ->
        getCTypeDepends ct >> (fun () -> 
        stmap vals getValueDepends)
  | TVal_ldfld (v, fref) -> getValueDepends v

let rec getExpDepends (e : tExp) : stdep =
  match e with
  | TExp_val v -> getValueDepends v
 
  (* TODO: Do something about the external reference. *)
  | TExp_name ((n, ty), extref) ->
        getExternDepends extref >> (fun () -> 
        upd (add_class_dep n) >> (fun () -> 
        getTypeDepends ty))
 
  | TExp_ldfld (v, tfr) -> getValueDepends v
 
  | TExp_call (v, args, mref) ->
        getValueDepends v >> (fun () -> 
        stmap args getValueDepends >> (fun () -> 
        getMethodDepends mref))

  | TExp_extern_call (extref, mref, args) ->
        getExternDepends (Some extref) >> (fun () -> 
        getMethodDepends mref >> (fun () -> 
        stmap args getValueDepends))
     
  | TExp_let ((_v, ty), bound, body, _type_inferred) ->
        getTypeDepends ty >> (fun () -> 
        getExpDepends bound >> (fun () -> 
        getExpDepends body))

  | TExp_isinst (v, cinfo, e, ty) ->  
        let getCinfoDepends (cname, _tkinds, pats, isGADT, exp) =
            let tys, vtys = getTysFromPats pats, getVarsFromPats pats in
            upd (add_class_dep cname) >> (fun () -> 
            stmap tys getTypeDepends >> (fun () -> 
            stmap vtys (fun (_v, ty) -> getTypeDepends ty) >> (fun () -> 
            getExpDepends exp))) in

        getValueDepends v >> (fun () -> 
        stmap cinfo getCinfoDepends >> (fun () -> 
        getExpDepends e >> (fun () -> 
        getTypeDepends ty)))

  | TExp_cond (et, ef, ebody) ->
        getExpDepends et >> (fun () -> 
        getExpDepends ef >> (fun () -> 
        getExpDepends ebody))

  | TExp_primop (_op, vs) ->
        stmap vs getValueDepends

  | TExp_ascribed (e, _ty) -> 
        getExpDepends e

  | TExp_bot -> ret ()

(* Gets the class and module dependencies from the current target class declaration. *)
let getCDeclDepends (cdecl : tClassDecl)
  : stdep (* Map of deps (module names, classes *) =
  let curmod =
    let len_mname = List.length cdecl.name in
      cdecl.name.[len_mname - 1] in

  upd (fun dep -> {dep with curmod=Some curmod}) >> (fun () -> 

  (* Process vvars. *)
  stmap (getVvars cdecl) (fun (_n, ty) -> getTypeDepends ty) >> (fun () -> 

  (* Process static fields. *)
  stmap cdecl.staticFields (fun (_fn, fty, fexp) ->  match fexp with
        | Some fe ->
            getTypeDepends fty >> (fun () -> 
            getExpDepends fe)
        | None -> ret ())  >> (fun () -> 

  (* Process methods. *)
  stmap cdecl.methods (fun (mty, mn, targs, fargs, mbody) -> match mbody with
        | Some mb -> getExpDepends mb
        | None -> ret ()))))

  
(******************************************)
(* Transforming modules.                  *)
(* - Qualify references to static fields. *)
(******************************************)
let maybeTransform (f : 'a -> 'a) (v : 'a option) : 'a option =
  match v with
  | Some v' -> Some (f v')
  | None -> None

let transformFieldRef (penv : tprocenv) (fr : tFieldRef) : tFieldRef =
  if List.exists (fun f -> f.Equals(fr)) penv.staticfields
    (* TODO: Is this right? *)
    then penv.modname + "." + fr
    else fr

let transformExtern (penv : tprocenv) (er : Sugar.externref)
  : Sugar.externref =
  er
let rec transformCType
  (penv : tprocenv) ((obj_name, obj_ks, args, extref) : tTypeConcrete) (* !! *)
  : tTypeConcrete =
  ( obj_name
  , obj_ks
  , List.map (function |Targ targ -> Targ(transformType penv targ)
                       |Varg varg -> Varg(transformValue penv varg)) args
  , maybeTransform (transformExtern penv) extref )
and transformKind (penv : tprocenv) (k : tKind) : tKind = k
and transformType (penv : tprocenv) (t : tType) : tType =
  match t with
  | TType_concrete tc -> TType_concrete (transformCType penv tc)
  | _ -> t
and transformMethodRef (penv : tprocenv) ((mname, tylst) : tMethodRef) : tMethodRef =
  (transformFieldRef penv mname, List.map (transformType penv) tylst)
  
and transformValue (penv : tprocenv) (v : tValue) : tValue =
  match v with
  | TVal_constant _
  | TVal_uvar _ -> v
  | TVal_var (var, ty) ->
      TVal_var (transformFieldRef penv var, transformType penv ty)
  | TVal_obj (ct, vals) ->
     TVal_obj
      ( transformCType penv ct
      , List.map (transformValue penv) vals )
  | TVal_ldfld (v, fref) ->
      TVal_ldfld (transformValue penv v, transformFieldRef penv fref)
  
let rec transformExp (penv: tprocenv) (e : tExp) : tExp =
  match e with
  | TExp_val v -> TExp_val (transformValue penv v)
  | TExp_name ((n, ty), extref) ->
      TExp_name
        ( (n, transformType penv ty)
        , maybeTransform (transformExtern penv) extref )
  | TExp_ldfld (v, tfr) ->
      TExp_ldfld (transformValue penv v, transformFieldRef penv tfr)
  | TExp_call (v, args, mref) ->
      TExp_call
        ( transformValue penv v
        , List.map (transformValue penv) args
        , transformMethodRef penv mref)
  | TExp_extern_call (extref, mref, args) ->
      TExp_extern_call
        ( transformExtern penv extref
        , mref
        , List.map (transformValue penv) args )
  | TExp_let ((var, ty), bound, body, type_inferred) ->
      TExp_let
        ( (var, transformType penv ty)
        , transformExp penv bound
        , transformExp penv body
        , type_inferred )
  | TExp_isinst (obj, cinfo, e, ty) ->
      let transformCinfo (cname, ks, pats, isGADT, body) = (* !! *)
        ( cname
        , ks                                            (* !! *)
        , List.map (function |Ptype targ -> Ptype(transformType penv targ)
                             |Pvar (v, ty) -> Pvar(v, transformType penv ty)) pats
        , isGADT
        , transformExp penv body ) in
      TExp_isinst
        ( transformValue penv obj
        , List.map transformCinfo cinfo
        , transformExp penv e
        , transformType penv ty)
  | TExp_cond (et, ef, ebody) ->
      TExp_cond
        (transformExp penv et, transformExp penv ef, transformExp penv ebody)
  | TExp_primop (op, v's) -> TExp_primop (op, List.map (transformValue penv) v's)
  | TExp_ascribed (e, ty) -> TExp_ascribed (transformExp penv e, ty)
  | TExp_bot -> TExp_bot

let transformCDecl (sfields : tFieldName list) (cdecl : tClassDecl)
  : tClassDecl =
  let (mn, cn) =
    try split_name cdecl.name
    with _ -> (cdecl.name.[0], "") in

  let penv = { modname = mn
             ; classname = cn
             ; staticfields = sfields } in
  
  let transformStaticField (fname, ty, body) =
    ( mn + "." + fname
    , transformType penv ty
    , maybeTransform (transformExp penv) body) in
    
  let transformMethodDecl (penv : tprocenv) (ty, mname, argkinds, argtypes, body)
    : tMethodDecl =
    ( transformType penv ty, mname
    , List.map (fun (tn, k) -> (tn, transformKind penv k)) argkinds
    , List.map (fun (tn, ty) -> (tn, transformType penv ty)) argtypes
    , maybeTransform (transformExp penv) body) in

    { cdecl
        with staticFields = List.map transformStaticField cdecl.staticFields;
             methods = List.map (transformMethodDecl penv) cdecl.methods } 

let transformModuleDecl (mdecl : tModule) : tModule =
  let sfields = getStaticFields mdecl.modCdecl in
  
  (* New class declarations. *)
  let newdecls =
        Hashtbl.fold
          (fun _ cdecl cur_decls -> (transformCDecl sfields cdecl)::cur_decls)
          mdecl.decls [] in
  (* New static fields. *)
  { mdecl
    with modCdecl = transformCDecl sfields mdecl.modCdecl;
         decls = createTCdecls (List.rev newdecls) }
