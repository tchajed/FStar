#light "off"
// (c) Microsoft Corporation. All rights reserved

  (* Known issues:

     1. Unit is not translated properly. At the moment, it's
        translated to bool
 *)
module Microsoft.FStar.Ilgen

open Attribs
open Util
open Target
open TargetUtil
open Sugar
open DcilAttrs
open Microsoft.FSharp.Collections
open Microsoft.FSharp.Compiler.AbstractIL
open Microsoft.FSharp.Compiler.AbstractIL.IL

let DEFAULT_MAX_STACK = 256

type extraLocalAttr = 
    | NewObj of (tTypeConcrete * list<tValue>)
    | TyApp of tType
    | GadtLocal of ILType

type env = 
    { curmodulename : string;
      curclassname : string;
      entry:option<tExp>;
      classDeclEnv: TargetUtil.tCenv;
      externs: TargetUtil.tCenv;
      tvarindices: list<tIdent * uint16>;
      paramindices: list<tIdent * uint16>;
      localindices: list<tIdent * uint16>;
      fieldspecs: list<tIdent * (bool * ILFieldSpec)>;
      topfields:option<(ILTypeRef * ILType * list<tStaticFieldDecl>)>;
      eraseUnit:bool;
      enclosingLet:option<uint16>;
      allowNewLocs:bool;
      newlocals:(option<uint16> * list<uint16 * extraLocalAttr>); //uint16 * (tTypeConcrete * list<tType> * list<tValue>)>);
      externMeths: list<tExternMethodDecl>;
      modsInThisAssembly:list<string>;
    }

let insertNewLocal env attr =
  let idopt, locs = env.newlocals in
  let cur, next = idopt |> (function None -> 0us, 1us | Some id -> id, id+1us) in
  let locs = (cur, attr)::locs in 
  let env = {env with newlocals=(Some next, locs)} in
    env, cur

(* let (^^) ctr f = Profiling.prof ctr f *)

let inThisAssembly env s = 
    (env.curmodulename=s || List.contains s env.modsInThisAssembly)
let strEnv env = "TODO"
  (*  spr "[%s]" (String.concat " ### " (List.map (fun cd -> Sugar.text_of_path cd.name) env.classDeclEnv))*)

let fsharp_core_2_0_0_0 =
  ILAssemblyRef.Create("FSharp.Core",
                       None,
                       Some (PublicKeyToken [| 0xB0uy; 0x3Fuy; 0x5Fuy; 0x7Fuy; 0x11uy; 0xD5uy; 0x0Auy; 0x3Auy |]),
                       false,
                       (Some (2us, 0us, 0us, 0us)),
                       None)

let fsharp_core_4_0_0_0 =
  ILAssemblyRef.Create("FSharp.Core",
                       None,
                       Some (PublicKeyToken [| 0xB0uy; 0x3Fuy; 0x5Fuy; 0x7Fuy; 0x11uy; 0xD5uy; 0x0Auy; 0x3Auy |]),
                       false,
                       (Some (4us, 0us, 0us, 0us)),
                       None)

let fine_runtime = 
  ILAssemblyRef.Create("runtime", 
                       None,
                       None, 
                       false,
                       None,
                       None)

//let dcil_attrs = 
//  ILAssemblyRef.Create("dcilattrs", 
//                       None,
//                       None, 
//                       false,
//                       None,
//                       None)

(* NOTE: ecma_ prefix refers to the standard "mscorlib" *)
(* let ecma_mscorlib_assembly_name = "mscorlib" *)
(* let dotnet4_ecma_public_token = PublicKeyToken ( [|0xb7uy; 0x7auy; 0x5cuy; 0x56uy; 0x19uy; 0x34uy; 0xe0uy; 0x89uy |]) *)
(* let dotnet4_ecma_mscorlib_assref = *)
(*   ILAssemblyRef.Create(ecma_mscorlib_assembly_name, None, Some dotnet4_ecma_public_token, false, Some (4us, 0us, 0us, 0us), None) *)
(* let ecma_mscorlib_scoref = *)
(*   if !Util.dotnet4 then ScopeRef_assembly dotnet4_ecma_mscorlib_assref *)
(*   else IL.ecma_mscorlib_scoref *)
  
let ecmaILGlobals = mk_ILGlobals ecma_mscorlib_scoref None
let empty_attrs = mk_custom_attrs []      

let write_local_type (v, ty) =
  (* TODO: Come up with an even more compact representation for this? *)
  if type_needs_attrib ty then (v, Some ty) else (v, Some ty)

let fsharp_core = if !Options.dotnet4 then fsharp_core_4_0_0_0 else fsharp_core_2_0_0_0 

exception Ilgen_error of string
let must o msg = match o with 
  | Some x -> x
  | None -> raise (Ilgen_error (msg()))

let or_else o f g = match o with
  | Some x -> f x
  | None -> g ()


let my_mk_simple_assref =
  let assemblies = ref [] in 
    fun asname -> 
      if asname.Equals("") then raise Impos;
      match asname with 
        | "FSharp.Core" -> fsharp_core
        | _ -> match Options.get_signer () with
            | None -> mk_simple_assref asname
            | Some s -> 
                match List.try_assoc asname !assemblies with 
                  | Some b -> b
                  | _ -> 
                      let aref = 
                        ILAssemblyRef.Create(asname, None, Some (IL.PublicKey (BinaryWriter.signerPublicKey s)), false, None, None) in
                        assemblies := (asname, aref)::!assemblies;
                        aref
  

let mk_scoref asname = 
  match asname with 
    | "mscorlib" -> ecma_mscorlib_scoref
    | _ -> 
        let eref = my_mk_simple_assref asname in
          ScopeRef_assembly eref

let mk_assembly_ref env modname = 
    if inThisAssembly env modname then ScopeRef_local 
    else ScopeRef_assembly(my_mk_simple_assref modname) 

let catch_not_found f = 
  try 
    Some (f ())
  with
    | :? System.Collections.Generic.KeyNotFoundException -> None 

let lookup_cdecl env cn : option<tClassDecl> =
  match cn with 
    | "__Extern"::rest -> 
        TargetUtil.tryLookupCdeclByName env.externs rest
    | _ -> 
        TargetUtil.tryLookupCdeclByName env.classDeclEnv cn

let lookup_tvar_id env tv =
  catch_not_found (fun _ -> List.assoc (fst tv) env.tvarindices)

let lookup_local_id env (tv:tVar<tType>) = 
  catch_not_found (fun _ -> List.assoc (fst tv) env.localindices)

let mk_index_map init (al:list<'a>) (f:'a -> 'b) : list<'b * uint16> * uint16 = 
  let ix, ixmap = List.fold_left (fun (ix, out) a -> (ix + 1us, (f a, ix)::out)) (init, []) al in  
    ixmap, ix

let initial_env (modul:tModule) = 
  let mname = Sugar.text_of_path modul.name in
  let cenv = [modul.decls;Target.predefined] in
  let e = modul.entry in
    {curmodulename=mname; classDeclEnv=cenv; externs=[modul.externs]; tvarindices=[]; 
     paramindices=[]; localindices=[]; fieldspecs=[]; entry=e; enclosingLet=None;
     topfields=None; curclassname="<NONE>"; eraseUnit=false; allowNewLocs=true; newlocals=(None,[]); 
     externMeths=[]; modsInThisAssembly=[];
    }  

let add_generic_params env gpds = 
  let init = match env.tvarindices with 
      (_, init)::_ -> init + 1us
    | _ -> 0us in
  let ixmap, _ = mk_index_map init gpds (fun gpd -> gpd.gpName) in
    {env with tvarindices=ixmap@env.tvarindices}

let add_parameter_map env plist = 
  let ixmap, _ = mk_index_map 0us plist fst in
    {env with paramindices=ixmap}
      
let add_local_map env locals = 
  let ixmap, ix = mk_index_map 0us locals fst in
    {env with localindices=ixmap; newlocals=(Some ix, [])}

let add_fieldspec_map env fsm = {env with fieldspecs=fsm}

let extend_env env (modul:tModule) = 
  let mname = Sugar.text_of_path modul.name in
  let cenv = modul.decls in
  let e = modul.entry in
    {curmodulename=mname; classDeclEnv=cenv::env.classDeclEnv; externs=[modul.externs]; curclassname="<NONE>";
     tvarindices=[]; paramindices=[]; localindices=[]; fieldspecs=[]; entry=e; topfields=None; eraseUnit=false; 
     enclosingLet=None; allowNewLocs=true; newlocals=(None, []); externMeths=[]; modsInThisAssembly=env.modsInThisAssembly}


let lookup_failed msg a = 
  Printf.printf "Lookup failed %s\n" msg; printfn "%A" a;
  raise (Ilgen_error msg)
    
let lookup_local env tv =
    catch_not_found (fun _ -> List.assoc (fst tv) env.localindices)
    
(* 0th param is the this ptr, unless this is a static method *)        
let lookup_param env tv = 
  catch_not_found (fun _ ->
                     let x = List.assoc (fst tv) env.paramindices in
                       x + 1us)     
       
let is_extern_name (cname:tClassName) = 
  match cname with
    | "__Extern"::dll::rest -> true 
    | _ -> false

let get_extern_name (cname:tClassName) = 
  match cname with
    | "__Extern"::dll::rest -> Some (dll,rest)
    | _ -> None

let lookup_field env tconc fref = 
  catch_not_found 
      (fun _ -> 
         let cname, ks, args, eref = tconc in 
           let ts, vs = getTys args, getVals args in
           match is_extern_name cname with (* TODO: check eref here for extern records *)
             | false ->
                 let cdecl = must (lookup_cdecl env cname) (fun () -> "Class not found") in
                 let fname, ftype = List.find (fun (fn, t) -> fn=fref) ((getVvars cdecl)@cdecl.fields) in
                 let out, _ = List.fold_left (fun (out,ix) tv -> TType_index ix::out, ix+1us) ([],0us) (getTvars cdecl) in
                 let tsub = List.rev out in
                 let args = ((List.map Targ tsub)@(List.map Varg vs)) in 
                 (* let _ = pr "Trying to instantiate cdecl.vars \n%A\n with arguments \n%A\n cdecl.kvars =\n%A\n args=\n%A\n"  *)
                   (* cdecl.vars args cdecl.kvars ks in  *)
                 let ftypeInst = TargetUtil.instantiateType cdecl ks args ftype in 
                   fname, ftypeInst
             | true -> 
                 let cdecl = must (lookup_cdecl env cname) (fun () -> "Class not found") in
                 let fname, ftype = List.find (fun (fn, t) -> fn=fref) (getVvars cdecl) in
                   fname, ftype)

let lookup_method env tconc mref = 
  catch_not_found (fun _ -> 
  let cname, ks, args, eref = tconc in (* TODO: fix calls to functions in extern concrete types *)
  let ts, vs = getTys args, getVals args in
  let cdecl = TargetUtil.lookupCdeclByName env.classDeclEnv cname in
  let (retType, mname, targs, params, body) = 
    List.find (fun (_, name, _, _, _) -> (name = fst mref)) cdecl.methods in
  let targs = (getTvars cdecl)@targs in
  let tsubst = List.rev (snd (List.fold_left (fun (ix, out) t -> ix+1us, TargetUtil.TvarMap(t, TType_index ix)::out) (0us, []) targs)) in
  let tmap = tsubst in (* (TargetUtil.buildTyMap cdecl ts vs)@tsubst in *)
  let retType = TargetUtil.substType tmap retType in
  let params = List.map (fun (n,t) -> n, TargetUtil.substType tmap t) params in
    (retType, mname, targs, params, None))
          
type fieldqual = Instance | Static


let props = IL.mk_properties []
let atts = IL.mk_custom_attrs []
let events = IL.mk_events []

let is_value_type = function
  | ["Prims"; "int"]
  | ["Prims"; "bool"] -> true
  | _ -> false

let tClassName2NamespaceAndString = Util.pfx 

let tVisibility2TypeDefAccess = function
  | TVis_public -> IL.Public
(*   | TVis_internal -> TypeAccess_private *)
  | TVis_internal -> IL.Nested (MemAccess_family)

let tVar2GenericParameterDef (tvarName, tvarKind) = 
  (* does not always have to be ref type; value types like int etc. are permissible too *)
  (* ignoring kind constraints *)
  let attrs =
    if !Options.writeAttribs && kind_needs_attrib tvarKind
      then GenericParamKind(tvarKind).encodel()
      else empty_attrs in
    {gpName=tvarName; 
     gpCustomAttrs=attrs;
     gpConstraints=[];
     gpVariance=NonVariant;
     gpReferenceTypeConstraint=false; 
     gpNotNullableValueTypeConstraint=false;
     gpDefaultConstructorConstraint=false}

let is_primitive_deparrow = function 
  | ["DepArrow"] -> true
  | _ -> false


let is_tuple_class c =
  c=Target.tClassDepTuple.name ||
  c=Target.tClassDconDepTuple.name ||
  c=Const.dcil_tuple_UU_name ||
  c=Const.dcil_tuple_UA_name ||
  c=Const.dcil_tuple_AU_name ||
  c=Const.dcil_tuple_AA_name ||
  c=Const.dcil_tuple_UU_name
  
let is_primitive = function 
  | "DepArrow"
  | "DepTuple"
  | "DconDepTuple"
  | "All" -> true
  | _ -> false
      
let tryfind_extern_classdecl env fullname = 
  TargetUtil.tryLookupCdeclByName env.externs fullname
    
let strenv [e] =
  let keys = Hashtbl.fold (fun key value st -> key::st) e [] in
    String.concat ", " keys 

let fsScope = ILScopeRef.Assembly(fsharp_core)
let unitTypeRef = 
  ILTypeRef.Create(fsScope, [], "Microsoft.FSharp.Core.Unit")

let typeOfRef t = Type_boxed(ILTypeSpec.Create(t, []))
let systemTypeRef = 
  ILTypeRef.Create(ecma_mscorlib_scoref, [], "System.Type")
let systemType = typeOfRef systemTypeRef
let systemTypeArray = mk_array_ty(systemType, Rank1ArrayShape)

let systemFieldInfoRef = 
  ILTypeRef.Create(ecma_mscorlib_scoref, [], "System.FieldInfo")
let systemFieldInfo = typeOfRef systemFieldInfoRef
let systemFieldInfoArray = mk_array_ty(systemFieldInfo, Rank1ArrayShape)

let systemObjectRef = mscorlibrefs.tref_Object
let systemObject = mscorlibrefs.typ_Object
let systemObjectArray = mk_array_ty(systemObject, Rank1ArrayShape)

let runtimeTypeHandleRef =
  ILTypeRef.Create(ecma_mscorlib_scoref, [], "System.RuntimeTypeHandle")
let runtimeTypeHandle = typeOfRef runtimeTypeHandleRef

let constructorInfoRef =
  ILTypeRef.Create(ecma_mscorlib_scoref, [], "System.Reflection.ConstructorInfo")
let constructorInfo = typeOfRef constructorInfoRef
let constructorInfoArray = mk_array_ty(constructorInfo, Rank1ArrayShape)

let methodInfoRef = 
  ILTypeRef.Create(ecma_mscorlib_scoref, [], "System.Reflection.MethodInfo")
let methodInfoType = typeOfRef methodInfoRef

let memberInfoRef = 
  ILTypeRef.Create(ecma_mscorlib_scoref, [], "System.Reflection.MemberInfo")
let memberInfo = typeOfRef methodInfoRef

let methodBaseRef = 
  ILTypeRef.Create(ecma_mscorlib_scoref, [], "System.Reflection.MethodBase")
let methodBase = typeOfRef methodInfoRef

let bytesType = (mk_array_ty (ecmaILGlobals.typ_Byte, Rank1ArrayShape))
let sysBytesType = 
  Type_boxed (ILTypeSpec.Create(ILTypeRef.Create(ecma_mscorlib_scoref, [], "System.Byte"), []))


let fsharpCoreAssRef = my_mk_simple_assref "FSharp.Core"
let fsharpCoreScopeRef = ScopeRef_assembly fsharpCoreAssRef

let compress_tval = function 
  | TVal_uvar uv -> (match Unionfind.find uv with 
                       | TUval v 
                       | TUcast(_, v) -> v)
  | v -> v
      
let ldc c = I_arith (AI_ldc(DT_I4, NUM_I4 (int32 c))) 

let mk_call receiverTref receiverType name args ret = 
  let cc = Callconv(CC_instance, CC_default) in 
  let mref = mk_mref(receiverTref, cc, name, 0, args, ret) in
  let mspec = IL.mk_mref_mspec_in_typ(mref, receiverType, []) in 
    mk_normal_callvirt mspec                    

let tClassName2TypeRef env tlid ngenerics eref = 
  let ns_cn tlid = 
    let ns, cn = Util.pfx tlid in
    let ns =
      if ns=[] then
        if is_primitive cn then ["Prims"] else [env.curmodulename]
      else ns in 
      ns, cn in
    (* TODO: Special handling for primitive types; map these to mscorlib types *)
  let ns, cn = ns_cn tlid in
    match ns, cn with 
      | ["Prims"], "string" -> mscorlibrefs.tref_String
      | ["Prims"], "int" -> mscorlibrefs.tspec_Int32.TypeRef 
      | ["Prims"], "bool" -> mscorlibrefs.tspec_Bool.TypeRef 
      | ["Prims"], "unit" -> unitTypeRef
      | ["Prims"], "object"
      | ["System"], "object" 
      | ["Prims"], "Affine" -> mscorlibrefs.tref_Object
      | ["Prims"], "DepArrow" -> 
            mk_nested_tref(fsharpCoreScopeRef, [], "Microsoft.FSharp.Core.FSharpFunc`2")
      | ["Microsoft";"FSharp";"Core"], _ ->
            mk_nested_tref(fsharpCoreScopeRef, [], String.concat "." (ns@[cn]))
      | _ -> 
          match eref with 
            | Some (eref:Sugar.externref) -> 
                let sr = mk_scoref eref.dll in
                let encloser = mk_tref(sr, Sugar.text_of_lid (Absyn.asLid <| eref.namespce.lid@eref.classname.lid)) in
                let tc = 
                  match eref.innerclass with 
                      None -> encloser
                    | Some ic -> mk_tref_in_tref(encloser, ic) in
                let cn = Sugar.text_of_path tlid in
                let cn = if ngenerics <> 0 then spr "%s`%d" cn ngenerics else cn in
                  mk_tref_in_tref(tc, cn)
            | None -> 
                let moduleName = Sugar.text_of_path ns in
                let cn = if ngenerics <> 0 then spr "%s`%d" cn ngenerics else cn in
                  (*             Printf.printf "Making reference to class %s\n" cn; *)
                  if inThisAssembly env moduleName then 
                    ILTypeRef.Create (ScopeRef_local, [moduleName], cn)
                  else
                    let assemblyName = moduleName in
                    let assRef = my_mk_simple_assref assemblyName in
                    let sr = ScopeRef_assembly assRef in
                    let fcn = cn in (* classes are nested inside a module main class *)
                      if cn = assemblyName then 
                        mk_tref(sr, fcn) 
                      else
                        mk_nested_tref(sr, [assemblyName], fcn)
                          (*                 mk_tref(sr, fcn) (\* Q: Should cn be the full name or just the class name? *\) *)
                  
let typeName2TypeSig (tn, _) = 
  match Util.pfx tn with 
      | ["Prims"], "String" -> Some mscorlibrefs.typ_String
      | ["Prims"], "int" -> Some mscorlibrefs.typ_int32
      | ["Prims"], "bool" -> Some mscorlibrefs.typ_bool
      | ["Prims"], "unit" -> None
      | [], "Affine" -> Some mscorlibrefs.typ_Object
      | _ -> None

let split_ho_tvars tvs = 
  let rec aux (i, out_fo, out_ho) = function
    | [] -> List.rev out_fo, List.rev out_ho
    | (v, (TKind_karrow _ as k))::tl -> aux (i+1, out_fo, (i, (v,k))::out_ho) tl
    | (v, k)::tl ->  aux (i+1, (v,k)::out_fo, out_ho) tl in
    aux (0, [], []) tvs

let rec tTypeConcrete2TypeSpec env (tn, ks, args, eref) = (* Note: value args are erased *) 
  let targs = getTys args in
  let gargs = 
    List.fold_left (fun out t -> match tType2TypeSigOpt env t with 
                      | None -> out
                      | Some t' -> t'::out) [] targs in
  let ngenerics = List.length gargs in
  let tr = tClassName2TypeRef env tn ngenerics eref in
    ILTypeSpec.Create(tr, List.rev gargs)
      
and lookup_fieldspec env tv = 
  catch_not_found (fun _ -> 
                     match List.try_assoc (fst tv) env.fieldspecs with 
                       | Some x -> x
                       | None -> (* try looking this up as a top-level binder *)
                           match env.topfields with
                             | None -> raise Not_found
                             | Some (tref, tsig, fields) -> 
                                 match List.tryFind (fun (fn, t, _) -> fn=(fst tv)) fields with
                                   | None -> 
                                       pr "Looking for field named %s in class %s .. not found\n"
                                         (fst tv) (env.curmodulename);
                                       raise Not_found
                                   | Some (fn,t,_) -> 
                                       let fieldtsig = tType2TypeSig env t in
                                       let fref = mk_fref_in_tref(tref, fn, fieldtsig) in
                                         true, mk_fspec(fref, tsig))
    
and tType2TypeSigOpt env = function
  | TType_index i -> Some (Type_tyvar i)
      
  | TType_var tv ->
      let id = must (lookup_tvar_id env tv) 
        (fun () -> raise Impos; (spr "Type variable %s not found when checking class %s\n" (PrettyTarget.strTvar tv) env.curclassname)) in
        Some (Type_tyvar id)

  | TType_name((tn, _), eref) when tn=["Prims";"bytes"] -> 
      Some bytesType

  | TType_name(tn, eref) -> 
      (match typeName2TypeSig tn with 
         | None -> 
             let ts = tTypeConcrete2TypeSpec env (fst tn, [], [], eref) in
               if is_value_type (fst tn) then Some (Type_value ts)
               else Some (Type_boxed ts)
         | Some ts -> Some ts)
                 
  | TType_fun (bvd, t1, t2) -> (* Type-level functions \x:t1.t2 are erased to the erasure of t2 *)
      tType2TypeSigOpt env t2 

  | TType_dep (t, _) -> (* Dependent types (t v) are erased to the erasure of t *)
      tType2TypeSigOpt env t 
        
  | TType_concrete ct -> 
      let ts = tTypeConcrete2TypeSpec env ct in
        Some (Type_boxed ts)
      
  | TType_affine t -> (* affine types !t are erased to the erasure of t *)
      Some (tType2TypeSig env t)

  | TType_tfun _ -> 
      (* these are expected to occur only among the targs of a concrete type 
         In particular, in the arguments of Id : All<\c. Fun<'c,'c>> etc. 
         These are erased altogether *)
      None
        
  | TType_tapp _ -> 
      (* these are expected to occur only in the return type of TyApp in a sub-class of All 
         And are erased to object *)
      Some mscorlibrefs.typ_Object

  | TType_refine(_, t, _, src_formula, _) -> tType2TypeSigOpt env t

  | t -> printfn "%A" t; raise (Ilgen_error "Unexpected target type in ilgen")

and tType2TypeSig env t = 
    match tType2TypeSigOpt env t with 
        None -> raise (Ilgen_error (spr " match tType2TypSigOpt expected a translatable type; got %s\n" (PrettyTarget.strType t)))
      | Some t -> t
          
let tFieldDecl2FieldDef is_vvar fq env (fname, (ftyp : tType)) = 
  let fTypeSig = tType2TypeSig env ftyp in
  let fd = match fq with 
    | Instance -> mk_instance_fdef (fname, fTypeSig, None, MemAccess_public)
    | Static -> mk_static_fdef (fname, fTypeSig, None, None, MemAccess_public) in
    if !Options.writeAttribs then 
      let fattrs =
        if type_needs_attrib ftyp
        then FieldDeclType(ftyp).encodel()
        else empty_attrs in
      let attrs =
        if is_vvar 
        then concat_attrs (ValueParameter().encodel()) fattrs
        else empty_attrs in
        {fd with fdCustomAttrs=attrs}
    else fd
      
let rec tTypeOftValue env v = match compress_tval v with
  | TVal_var (_, tt) -> tt
  | TVal_obj (ttc,  _) -> TType_concrete ttc
  | TVal_constant sc -> TargetChecker.constTyping sc
  | TVal_ldfld (tv, fr) -> let _, t = lookup_field_typ env (tTypeOftValue env tv) fr in t
  | TVal_logic_fun _ -> raise Impos

and lookup_field_typ env vtype fref = 
  let msg i () = spr "[%d](In class %s) Field ref %s not found in type %s\n" i (env.curclassname) fref (PrettyTarget.strType vtype)in
  let fail i = raise (Ilgen_error (msg i ())) in
    match vtype with
      | TType_concrete tconc ->
          let (cname, ks, args, _) = tconc in
            let ts, vs = getTys args, getVals args in
            if (is_tuple_class cname) then 
              match ts with
                | [t1; TType_fun(_, _, t2)] -> 
                    if (fref = Const.dcil_proj_one_name) then 
                      let cd = 
                        must (lookup_cdecl env cname) 
                          (fun () -> (spr "Could not find class declaration for %s\n" (PrettyTarget.strLident cname))) in 
                      let (f_fst, _)::tl = getVvars cd in
                        must (lookup_field env tconc f_fst) (msg 1) 
                    else if (fref = Const.dcil_proj_two_name) then 
                      let cd = must (lookup_cdecl env cname) 
                        (fun () -> (spr "Could not find class declaration for %s\n" (PrettyTarget.strLident cname))) in 
                      let [_;(f_snd, _)] = getVvars cd in
                        must (lookup_field env tconc f_snd) (msg 1) 
                    else must (lookup_field env tconc fref) (msg 1) 
                | _ -> must (lookup_field env tconc fref) (msg 2) 
            else  must (lookup_field env tconc fref) (msg 3)
      | TType_name ((n,_), None) -> 
          must (lookup_field env (n,[], [],None) fref) (msg 4) 
      | TType_name ((n,_), Some eref) -> 
          let cdecl = TargetUtil.lookupCdeclByName env.externs n in 
            must (List.tryFind (fun (fn, t) -> fn=fref) (cdecl.fields)) (msg 5)
      | TType_refine(_, tt, _, src_formula, _) -> lookup_field_typ env tt fref
      | _ -> fail 6

and sconst2Instr = function 
  | Sugar.Const_unit ->
      I_arith (AI_ldnull)
  | Sugar.Const_bool false -> 
      I_arith (AI_ldc (DT_I4, NUM_I4 0))
        
  | Sugar.Const_bool true -> 
      I_arith (AI_ldc (DT_I4, NUM_I4 1))

  | Sugar.Const_int8 i -> 
      I_arith (AI_ldc (DT_I1, NUM_I4 (int32 i)))
        
  | Sugar.Const_uint8 i -> 
      I_arith (AI_ldc (DT_U1, NUM_I4 (int32 i)))

  | Sugar.Const_int16 i -> 
      I_arith (AI_ldc (DT_I2, NUM_I4 (int32 i)))

  | Sugar.Const_uint16 i -> 
      I_arith (AI_ldc (DT_U2, NUM_I4 (int32 i)))

  | Sugar.Const_int32 i -> 
      I_arith (AI_ldc (DT_I4, NUM_I4 (int32 i)))
        
  | Sugar.Const_uint32 i -> 
      I_arith (AI_ldc (DT_U4, NUM_I4 (int32 i)))

  | Sugar.Const_nativeint i 
  | Sugar.Const_int64 i -> 
      I_arith (AI_ldc (DT_I8, NUM_I8 i))

  | Sugar.Const_unativeint i
  | Sugar.Const_uint64 i -> 
      I_arith (AI_ldc (DT_U8, NUM_I8 (int64 i)))

  | Sugar.Const_float32 i -> 
      I_arith (AI_ldc (DT_R4, NUM_R4 i))

  | Sugar.Const_float i -> 
      I_arith (AI_ldc (DT_R8, NUM_R8 i))

  | Sugar.Const_char i -> 
      I_arith (AI_ldc (DT_I1, NUM_I4 (int32 i)))

  | Sugar.Const_string (bytes, _) -> 
      let s = unicodeEncoding.GetString(bytes) in
        I_ldstr (s)

  | Sugar.Const_bytearray _
  | Sugar.Const_decimal _
  | Sugar.Const_bigint _ 
  | Sugar.Const_bignum _
  | Sugar.Const_uint16array _ -> raise (NYI "Unhandled constant form") 

and bytes2Instrs (b:byte[]) = 
  let _ = pr "Size of byte array is %d\n" b.Length in
  let loads = [for i in 0 .. (b.Length-1) do 
                 let dup = I_arith AI_dup in
                 let index = I_arith (AI_ldc (DT_I4, NUM_I4 (int32 i))) in
                 let value = I_arith (AI_ldc (DT_I4, NUM_I4 (int32 b.[i]))) in
                 let stelem = I_stelem DT_U1 in
                   yield ([dup;index;value;stelem]) 
               done ] in
  let newarr = [I_arith (AI_ldc (DT_I4, NUM_I4 (int32 b.Length)));
                I_newarr (Rank1ArrayShape, sysBytesType)] in
    List.concat (newarr::loads)

and tExp2Instrs env : tExp -> (env * list<ILInstr>) = 
  let tVals2Instrs env el = 
    let env, instrsl = List.fold_left (fun (env, out) argv -> 
                                         let env, instrs = tExp2Instrs env (TExp_val argv) in
                                           env, instrs::out) (env,[]) el in
      env, List.rev instrsl |> List.concat in
    function
      | TExp_val(TVal_uvar uv )-> 
          (match Unionfind.find uv with 
             | TUval v -> tExp2Instrs env (TExp_val v)
             | TUcast(t, v) -> 
                 let env, instrs = tExp2Instrs env (TExp_val v) in
                 let iltype = tType2TypeSig env t in 
                   (* needs two steps, since basic type may be unboxed *)
                 let instrs = instrs@[I_castclass systemObject; I_castclass iltype] in 
                   env, instrs)
      | TExp_val (TVal_constant sc) ->
          (match sc with
               Sugar.Const_unit when env.eraseUnit -> env, [] (* HACK! *)
             | Sugar.Const_bytearray (b, _) -> env, bytes2Instrs b 
             | _ -> env, [sconst2Instr sc])
            
      | TExp_val (TVal_var tv) -> 
          or_else 
            (lookup_local env tv) 
            (fun local_ix -> env, [I_ldloc local_ix]) 
            (fun _ -> 
               or_else 
                 (lookup_param env tv)
                 (fun param_ix -> env, [I_ldarg param_ix])
                 (fun _ -> 
                    let isStatic, fs = must (lookup_fieldspec env tv) (fun () -> (spr "Unable to translate variable: %s" (fst tv))) in
                      if isStatic then 
                        env, [mk_normal_ldsfld fs]
                      else 
                        env, [I_ldarg 0us; (* load this *)
                              mk_normal_ldfld fs]))
            
      | TExp_name ((tn, tt), eref) -> (* EXTERN REF TODO: Handle eref here *)
          let moduleName, fieldName = Util.pfx tn in 
          let moduleNameStr = Sugar.text_of_path moduleName in
          let assref = mk_assembly_ref env moduleNameStr in 
            (*         let containerClass = assemblyName in (\* @ ["_Container"] in *\) *)
          let containerTref = mk_tref(assref, moduleNameStr) in 
          let fieldType = tType2TypeSig env tt in
          let fspec = mk_fspec_in_nongeneric_boxed_tref(containerTref, fieldName, fieldType) in
            env, [mk_normal_ldsfld fspec]
      | TExp_val(TVal_ldfld(v, fref)) 
      | TExp_ldfld (v, fref) -> 
          (*         let msg () = spr "Field ref %s not found" fref in  *)
          let env, instrs = tExp2Instrs env (TExp_val v) in
          let vtype = tTypeOftValue env v in
          let vtypeSig = tType2TypeSig env vtype in
          let fname, ftype = lookup_field_typ env vtype fref in
          let ld_or_call = match vtype with
            | TType_name ((n,_), Some eref) -> (* EXTERN REF TODO: Handle eref here *)
                raise (NYI "Refs to external records is currently broken")
                  (*               (match get_extern_name n with  *)
                  (*                  | None -> raise Impos *)
                  (*                  | Some (dll, classname) ->  *)
                  (*                      let ftsig = tType2TypeSig env ftype in *)
                  (*                      let mname = "get_"^fname in *)
                  (*                      let cc = Callconv(CC_instance, CC_default) in *)
                  (*                      let methodRef = mk_mref(tref_of_typ vtypeSig, cc, mname, 0, [], ftsig) in *)
                  (*                      let mspec = mk_mref_mspec_in_typ(methodRef, vtypeSig, []) in *)
                  (*                        mk_normal_callvirt mspec) *)
            | _ -> 
                let ftypeSig = tType2TypeSig env ftype in 
                let fspec = mk_fspec_in_typ (vtypeSig, fname, ftypeSig) in
                  mk_normal_ldfld fspec
          in                  
            env, instrs@[I_castclass vtypeSig; ld_or_call]

      | TExp_extern_call (eref, (mn, tl), args) -> 
          let argTypes, retType = TargetChecker.lookupExtMethod env.externMeths eref mn in 
          let assref = ScopeRef_assembly(my_mk_simple_assref eref.dll) in
          let tref = mk_tref (assref, Sugar.text_of_lid (Absyn.asLid <| eref.namespce.lid@eref.classname.lid)) in
          let tref = match eref.innerclass with 
              None -> tref
            | Some s -> mk_tref_in_tref (tref, s) in
          let tsig = mk_boxed_typ tref [] in
          let argTsigs = List.map (tType2TypeSig env) argTypes in
          let retTsig = tType2TypeSig env retType in
          let genArgs = List.map (tType2TypeSig env) tl in
          let mspec = mk_static_mspec_in_typ (tsig, mn, argTsigs, retTsig, genArgs) in
          let callInstr = mk_normal_call mspec in
          let env, argLdInstrs = tVals2Instrs env args in 
            env, argLdInstrs@[callInstr]

      | TExp_primop(op, args) ->
          let env, argLdInstrs = tVals2Instrs env args in
          let op_instr = match op with 
            | AND -> AI_and
            | OR -> AI_or
            | ADD -> AI_add
            | SUB -> AI_sub
            | MUL -> AI_mul
            | DIV -> AI_div
            | NOT -> AI_not in
            env, argLdInstrs@[I_arith op_instr]

      | TExp_call (v, [arg], ("Equals", [t])) when t=Target.objType -> 
          let env, instrs = tExp2Instrs env (TExp_val v) in
          let env, argLdInstrs = tExp2Instrs env (TExp_val arg) in
          let instrs = instrs@argLdInstrs in
          let vtype = tTypeOftValue env v in
          let vtypeSig = tType2TypeSig env vtype in
          let vtypeRef = tref_of_typ vtypeSig in
          let genArity = 0 in 
          let retTypeSig = mscorlibrefs.typ_Bool in
          let plist = [mscorlibrefs.typ_Object] in
          let cc = Callconv(CC_instance, CC_default) in
          let mspec = mk_nongeneric_mspec_in_typ(vtypeSig, cc, "Equals", plist, retTypeSig) in
          let callInstr = mk_normal_callvirt mspec in
            env, instrs@[callInstr]

      | TExp_call(v, args, ((mname, tparams) as tmref)) when mname="Invoke" -> 
          let env, instrs = tExp2Instrs env (TExp_val v) in
          let env, argLdInstrs = tVals2Instrs env args in 
          let instrs = instrs@argLdInstrs in
          let vtype = tTypeOftValue env v in
          let (retType, mname, targs, params, _) = match vtype with
            | TType_affine (TType_concrete((tcn, _,  _, _) as tconc)) 
            | TType_concrete ((tcn,_,  _, _) as tconc) when is_primitive_deparrow tcn -> 
                must (lookup_method env tconc tmref) (fun () -> (spr "Method ref %s not found in class %s\n" mname (String.concat "." tcn)))
            | _ -> raise Impos in
          let vtypeSig = tType2TypeSig env vtype in
          let vtypeRef = tref_of_typ vtypeSig in
          let genArity = List.length targs in
          let retTypeSig = (Type_tyvar 1us) in (* notice that numbering of return type ... *)
          let plist = [Type_tyvar 0us] in (* ... and formal is relative to the static decl of FastFunc. *)
          let cc = Callconv(CC_instance, CC_default) in
          let methodRef = mk_mref(vtypeRef, cc, mname, genArity, plist, retTypeSig) in
          let genArgs = List.map (tType2TypeSig env) tparams in
          let mspec = mk_mref_mspec_in_typ(methodRef, vtypeSig, genArgs) in
          let callInstr = mk_normal_callvirt mspec in
            env, instrs@[callInstr]

      | TExp_call(v, [], ((mname, [tparam]) as tmref)) when mname="TyApp" -> 
          let env, instrs = tExp2Instrs env (TExp_val v) in
          let vtype = tTypeOftValue env v in  (* vtype should be like All<\'c. Fun<'c,'c>> *)
          let (retType, mname, _, _, _), tfun_arg = match vtype with
            | TType_concrete ((tcn, _, [Targ targ], _) as tconc) -> 
                must (lookup_method env tconc tmref) (fun () -> (spr "Method ref TyApp not found in %s" (Sugar.text_of_path tcn))), targ
            | _ -> Printf.printf "%A\n" vtype; raise Impos in
          let vtypeSig = tType2TypeSig env vtype in (* should be just All<> *)
          let vtypeRef = tref_of_typ vtypeSig in
          let retTypeSig = tType2TypeSig env retType in (* should be object *)
          let cc = Callconv(CC_instance, CC_default) in
          let methodRef = mk_mref(vtypeRef, cc, mname, 1, [], retTypeSig) in
          let genArgs = List.map (tType2TypeSig env) [tparam] in
          let mspec = mk_mref_mspec_in_typ(methodRef, vtypeSig, genArgs) in
          let callInstr = mk_normal_callvirt mspec in
          let retTyp = TType_tapp(tfun_arg, tparam) in
          let normRetTyp = (TargetUtil.normalize retTyp) in
          let env = match env.enclosingLet with 
            | None -> raise Impos
            | Some l -> 
                let idopt, locs = env.newlocals in
                let locs = (l, TyApp(tparam))::locs in 
                  {env with newlocals=(idopt, locs)} in
            (* pr "TyApp gets a tapp with fun_arg=%A\n and type argument %A\n" tfun_arg tparam; *)
            (* pr "Inserting a cast to type %A\n which normalizes to %A\n" retTyp normRetTyp; *)
          let retTypSig = tType2TypeSig env normRetTyp in
            env, instrs@[callInstr; I_castclass retTypSig]
              
      | TExp_val (TVal_obj (tconc, vals)) ->
          let tn, ks, args, eref = tconc in 
          let targs, vargs = getTys args, getVals args in
          let env, instrsl = tVals2Instrs env (vargs@vals) in
            (match tryfind_extern_classdecl env tn with 
               | Some cdecl -> 
                   raise (NYI "Constructing external classes from FStar is currently broken.")
                     (*                  let eref = cdecl.externref in *)
                     (*                    (match cdecl.extends with *)
                     (*                         Some (TType_name((enclosing::ename, _), eref)) -> *)
                     (*                           let _::dll::_, propertyName = Util.pfx tn in *)
                     (*                           let assref = my_mk_simple_assref dll in *)
                     (*                           let sr = ScopeRef_assembly assref in *)
                     (*                             (\*                         let _ = printfn "%A" ("Making name ", dll::ename) in *\) *)
                     (*                           let tref = mk_tref_in_tref(mk_tref(sr, enclosing), Sugar.text_of_path ename)  in *)
                     (*                             (\*                         let tref = tClassName2TypeRef env ename in *\) *)
                     (*                           let mn = "get_uniq_"^propertyName in *)
                     (*                           let tsig = mk_boxed_typ tref [] in *)
                     (*                           let argTsigs = [] in *)
                     (*                           let retTsig = tsig in *)
                     (*                           let genArgs = [] in *)
                     (*                           let mspec = mk_static_mspec_in_typ (tsig, mn, argTsigs, retTsig, genArgs) in *)
                     (*                           let callInstr = mk_normal_call mspec in *)
                     (*                             [callInstr] *)
                     (*                       | _ -> raise Impos) *)
               | _ -> 
                   let cdecl = TargetUtil.lookupCdeclByName env.classDeclEnv tn in
                   let formalTargs = getTvars cdecl in
                   let tsubst = List.rev (snd (List.fold_left (fun (ix, out) t -> ix+1us, TargetUtil.TvarMap(t, TType_index ix)::out) (0us, []) formalTargs)) in
                   let paramTypes = List.map (fun (_,t) -> t) ((getVvars cdecl)@cdecl.fields) in
                   let paramTypes = List.map (fun t -> 
                                                tType2TypeSig env (TargetUtil.substType tsubst t)) paramTypes in
                   let fo_tvars, ho_tvars = split_ho_tvars formalTargs in
                   let tref = tClassName2TypeRef env tn (List.length fo_tvars) None in
                   let boxity = AsObject in
                     (*                  let paramTypes =  *)
                     (*                    if List.length argts > 0 then List.map (fun t -> tType2TypeSig env t) argts  *)
                     (*                    else List.map (fun v -> tType2TypeSig env (tTypeOftValue env v)) (vargs@vals) in *)
                   let genArgs = List.map (tType2TypeSig env) targs in 
                   let mspec = mk_ctor_mspec (tref, boxity, paramTypes, genArgs) in
                     if env.allowNewLocs then 
                       let idopt, locs = env.newlocals in
                       let cur, next = idopt |> (function None -> 0us, 1us | Some id -> id, id+1us) in
                       let locs = (cur, NewObj (tconc, vals))::locs in 
                       let env = {env with newlocals=(Some next, locs)} in
                         env, instrsl@[mk_normal_newobj mspec; I_stloc cur; I_ldloc cur]
                     else 
                       env, instrsl@[mk_normal_newobj mspec])
              
      | TExp_bot -> 
          let tref = mk_tref(ecma_mscorlib_scoref, "System.Exception") in
          let mspec = mk_ctor_mspec(tref, AsObject, [mscorlibrefs.typ_String], []) in
            env, [I_ldstr ("Incomplete pattern match!"); 
                  mk_normal_newobj mspec; 
                  I_throw]
              
      | ee -> printfn "%A" ("Unexpected expression not translatable to a basic block", ee); raise Impos (* Other expression forms are translated into blocks *) 

and tExp2Code env exp jump_opt : (env * ILCode * ILCodeLabel) = 

  let rec tExp2Code env (jump:ILInstr) : tExp -> (env * ILCodeLabel * ILCode) = function
    | TExp_ascribed (e, _ty) -> tExp2Code env jump e

    | TExp_let (x, e1, e2, hasTypeRef) -> 
        let loc = must (lookup_local env x) (fun () -> "Local not found") in
        let env, e2label, e2code = tExp2Code env jump e2 in
        let instrs = 
            [I_stloc loc; I_br e2label] in
        let letlabel = generate_code_label () in
        let xbb = ILBasicBlock({bblockLabel=letlabel; bblockInstrs=Array.of_list instrs}) in
        let jxbb = I_br letlabel in
        let env, e1label, e1code = tExp2Code {env with enclosingLet=Some loc} jxbb e1 in
        let groupBlock = mk_group_block([e2label; letlabel], [e1code;xbb;e2code]) in
          env, e1label, groupBlock

    | TExp_cond (e1, e2, e3) -> 
        let env, e2label, e2code = tExp2Code env jump e2 in
        let env, e3label, e3code = tExp2Code env jump e3 in
        let brlabel = generate_code_label () in
        let instrs = [I_brcmp (BI_brtrue, e2label, e3label); I_br e3label] in 
        let brcode = ILBasicBlock({bblockLabel=brlabel;
                                 bblockInstrs=Array.of_list instrs}) in
        let env, e1label, e1code = tExp2Code env (I_br brlabel) e1 in
        let groupBlock = mk_group_block([e2label;e3label;brlabel], [e1code;brcode;e2code;e3code]) in
          env, e1label, groupBlock

    | TExp_isinst (v, branches, def, tt) -> 
        let ldv, localname = match compress_tval v with 
          | TVal_var x -> 
              (match lookup_local env x with 
                 | Some vlocalId -> I_ldloc vlocalId, x
                 | _ -> (match lookup_param env x with 
                             Some paramId -> I_ldarg paramId, x
                           | None -> raise (Ilgen_error (spr "(in class %s): local variable or parameter %s not found" (env.curclassname) (fst x)))))
          | _ -> raise Impos in
        let vtype = tTypeOftValue env v in 
        let vtypeSig = tType2TypeSig env vtype in
        let env, defLabel, defCode = tExp2Code env jump def in 
          
        let translate_nongadt_branch env defLabel jump (tcn, ks, pats, _, branch) = 
          let ttl, tvl, fields = getTysFromPats pats, getVarsFromPats pats, getFieldsFromPats pats in
          let lookup_pattern_constructor env tcn = match lookup_cdecl env tcn with 
            | Some cd -> cd
            | _ -> let msg = 
                spr "Translation error when translating module %s\n\
                        Class %s not found in environment %s or class has not tag" 
                  env.curmodulename (Sugar.text_of_path tcn) (strEnv env) in 
                raise (Ilgen_error msg) in
          let env, blabel, branchCode = tExp2Code env jump branch in (* TODO: load locals *)
          let cdecl = lookup_pattern_constructor env tcn in 
          let allfields = (getVvars cdecl)@cdecl.fields in
            if (List.length (tvl@fields) <> List.length allfields) then raise Impos; (* # pattern variables must match # fields *) 
            let ttc = TType_concrete(tcn, ks, (List.map Targ ttl) @ (List.map (fun v -> Varg(TVal_var v)) tvl), None) in 
            let v' = TVal_var (fst localname, ttc) in
            let env, stlocs = 
              (List.fold_left (fun (env, out) ((fn,_), loc) -> 
                                 let env, ldfld = tExp2Instrs env (TExp_ldfld(v', fn)) in
                                 let loc = must (lookup_local env loc) (fun () -> "Local not found") in
                                   env, ldfld@(I_stloc loc::out)) 
                 (env, [I_br blabel]) (List.zip allfields (tvl@fields))) in
            let storeLocsLabel = generate_code_label () in
            let storeCode =
              ILBasicBlock({bblockLabel=storeLocsLabel; bblockInstrs=Array.of_list (stlocs @ [I_arith AI_nop])}) in
            let testTypeInstrs = 
              (match tryfind_extern_classdecl env tcn with 
                 | Some cdecl when (match cdecl.externref with Some er when er.extqual=Some Sugar.Nullary -> true | _ -> false) -> 
                     raise (NYI "Constructing nullary external data constructors is currently broken.")
                 | _ -> 
                     match cdecl.tagNum, vtype with 
                       | Some tag, TType_concrete _ -> 
                           let fspec = mk_fspec_in_typ(vtypeSig, "__tag", mscorlibrefs.typ_int32) in 
                           let ldfld = mk_normal_ldfld fspec in 
                           let ldtag = sconst2Instr (Sugar.Const_int32 tag) in
                           let cmp = I_arith AI_ceq in
                             [ldfld;ldtag;cmp]
                       | _ -> 
                           let testTypeSig = 
                             tType2TypeSig env (TType_concrete(tcn, ks, (List.map Targ ttl) @ 
                                                                 (List.map (fun t -> Varg(TVal_var t)) tvl), 
                                                               None)) in 
                             [I_isinst testTypeSig])  in
            let instrs = (ldv::testTypeInstrs)@[I_brcmp (BI_brtrue, storeLocsLabel, defLabel);
                                                I_br defLabel] in
            let testLabel = generate_code_label () in
            let testCode = ILBasicBlock({bblockLabel=testLabel; bblockInstrs=Array.of_list instrs}) in
              env, testLabel, [storeLocsLabel;blabel], [testCode;storeCode;branchCode] in
          
        (* Translating gadt branches *)
        (* see ix.cs for the code that's supposed to be generated by this branch *)
        let getTypeFromHandle = mk_normal_call (mk_static_mspec_in_typ(systemType, "GetTypeFromHandle", [runtimeTypeHandle], systemType, [])) in 
        let loadTargs env typeArrayLocal genericArgsLocal pbtvars targs = 
          let is_pattern_bound_tvar (x, _) = List.exists (function  (TType_var (x', _)) -> x=x' | _ -> false) pbtvars in
          let pbound_tvar_index (x,_) =  
            let rec aux i = function
              | [] -> -1
              | TType_var (x', _)::tl when x'=x -> i+1
              | _::tl -> aux (i+1) tl in
              aux -1 pbtvars in
          let _, loadTargs =  
            List.fold_left (fun (index, codel) -> function 
                              | TType_var x when is_pattern_bound_tvar x -> 
                                  let tvarIndex = pbound_tvar_index x in 
                                  let code = [I_ldloc typeArrayLocal;
                                              I_arith (AI_ldc (DT_I4, NUM_I4 (int32 index)));
                                              I_ldloc genericArgsLocal;
                                              I_arith (AI_ldc (DT_I4, NUM_I4 (int32 tvarIndex)));                                           
                                              I_ldelem DT_REF;
                                              I_stelem DT_REF] in 
                                    (index+1, code::codel)
                              | t -> 
                                  let iltype = tType2TypeSig env t in 
                                  let ttok = Token_type iltype in 
                                  let code = [I_ldloc typeArrayLocal;
                                              I_arith (AI_ldc (DT_I4, NUM_I4 (int32 index)));
                                              I_ldtoken ttok; 
                                              getTypeFromHandle;
                                              I_stelem DT_REF] in 
                                    (index+1, code::codel)) (0, []) targs in
            List.rev loadTargs |> List.flatten in            
        let loadVargs env valueArrayLocal fieldArgsLocal pbxvars vargs =
          let is_pattern_bound_xvar (x, _) = List.exists (fun (x', _) -> x=x') pbxvars in
          let pbound_xvar_index (x,_) =  
            let rec aux i = function
              | [] -> -1
              | (x', _)::tl when x'=x -> i+1
              | _::tl -> aux (i+1) tl in
              aux -1 pbxvars in
          let getValue = mk_call systemFieldInfoRef systemFieldInfo "GetValue" [systemObject] systemObject in
          let env, _, loadVargs =  
            List.fold_left (fun (env, index, codel) -> function 
                              | TVal_var x when is_pattern_bound_xvar x -> 
                                  let xvarIndex = pbound_xvar_index x in 
                                  let code = [I_ldloc valueArrayLocal;
                                              I_arith (AI_ldc (DT_I4, NUM_I4 (int32 index)));
                                              I_ldloc fieldArgsLocal;
                                              I_arith (AI_ldc (DT_I4, NUM_I4 (int32 xvarIndex)));                                           
                                              I_ldelem DT_REF;
                                              ldv;
                                              getValue;
                                              I_stelem DT_REF] in 
                                    (env, index+1, code::codel)
                              | v -> 
                                  let env, loadv = tExp2Instrs env (TExp_val v) in 
                                  let code = 
                                    [I_ldloc valueArrayLocal; 
                                     I_arith (AI_ldc (DT_I4, NUM_I4 (int32 index)))]
                                    @loadv
                                    @[I_castclass systemObject;
                                      I_stelem DT_REF] in 
                                    (env, index+1, code::codel)) (env, 0, []) vargs in
            env, List.rev loadVargs |> List.flatten in            

        let gadt_branch_code env pbtvars pbxvars branch = 
          match branch with 
            | TExp_let(x, TExp_call((TVal_obj((receiverClass, kl, args, _),  _)), arguments, mref), 
                       TExp_val (TVal_uvar uv), _) -> 
                let targs, vargs = getTys args, getVals args in
                (* let _ = pr "Translating GADT branch: %A\n" branch in  *)
                let env, typeArrayLocal, typeArrayInit = 
                  let env, loc = insertNewLocal env (GadtLocal systemTypeArray) in
                  let init = [ldc (List.length targs);
                              I_newarr (Rank1ArrayShape, systemType);
                              I_stloc loc] in
                    env, loc, init in 
                let env, genericArgsLocal, genericArgsInit = 
                  let env, loc = insertNewLocal env (GadtLocal systemTypeArray) in
                  let getType = mk_call systemObjectRef systemObject "GetType" [] systemType in 
                  let getGenArgs = mk_call systemTypeRef systemType "GetGenericArguments" [] systemTypeArray in 
                  let init = [ldv; (* load scrutinee *)
                              getType;
                              getGenArgs;
                              I_stloc loc] in 
                    env, loc, init in 
                let env, fieldArgsLocal, fieldArgsInit = 
                  let env, loc = insertNewLocal env (GadtLocal systemFieldInfoArray) in
                  let getType = mk_call systemObjectRef systemObject "GetType" [] systemType in 
                  let getFields = mk_call systemTypeRef systemType "GetFields" [] systemFieldInfoArray in 
                  let init = [ldv; (* load scrutinee *)
                              getType;
                              getFields;
                              I_stloc loc] in 
                    env, loc, init in 
                let env, valueArrayLocal, valueArrayInit = 
                  let env, loc = insertNewLocal env (GadtLocal systemObjectArray) in
                  let init = [ldc (List.length vargs);
                              I_newarr (Rank1ArrayShape, systemObject);
                              I_stloc loc] in
                    env, loc, init in
                let env, unitArgLocal, unitArgInit = 
                  let env, loc = insertNewLocal env (GadtLocal systemObjectArray) in
                  let init = [ldc 1;
                              I_newarr (Rank1ArrayShape, systemObject);
                              I_stloc loc;
                              I_ldloc loc;
                              I_arith (AI_ldnull);
                              I_ldelem DT_REF] in 
                    env, loc, init in
                let env, receiverLocal = insertNewLocal env (GadtLocal systemObject) in
                let lookupTypeHandle = 
                  (* let _ = pr "********Looking up type handle for class %s\n" cn in  *)
                  let tref = tClassName2TypeRef env receiverClass (List.length targs) None in 
                  let iltype = Type_boxed (ILTypeSpec.Create(tref, [])) in 
                  let receiverTok = Token_type(iltype) in 
                    [I_ldtoken receiverTok; getTypeFromHandle] in 
                let loadTargs = loadTargs env typeArrayLocal genericArgsLocal pbtvars targs in 
                let instantiateClass = mk_call systemTypeRef systemType "MakeGenericType" [systemTypeArray] systemType in
                let ldConstructorArray = mk_call systemTypeRef systemType "GetConstructors" [] constructorInfoArray in
                let env, loadVargs = loadVargs env valueArrayLocal fieldArgsLocal pbxvars vargs in
                let callConstructor = mk_call constructorInfoRef constructorInfo "Invoke" [systemObjectArray] systemObject in
                let callGetType = mk_call systemObjectRef systemObject "GetType" [] systemType in 
                let getDepArrowInvokeMethod = 
                  let call = mk_call systemTypeRef systemType "GetMethod" [mscorlibrefs.typ_String] methodInfoType in 
                    [I_ldstr "Invoke"; call] in
                let callDepArrowInvoke = mk_call methodBaseRef methodBase "Invoke" [systemObject; systemObjectArray] systemObject in 
                let resultType = match Unionfind.find uv with 
                  | TUcast(t, _) -> tType2TypeSig env t
                  | _ -> raise Impos in
                let instrs = typeArrayInit@genericArgsInit@fieldArgsInit@valueArrayInit@unitArgInit
                  @lookupTypeHandle
                  @loadTargs
                  @[instantiateClass;ldConstructorArray; ldc 0; I_ldelem DT_REF]
                  @loadVargs
                  @[callConstructor; I_stloc receiverLocal]
                  @[I_ldloc receiverLocal; callGetType]
                  @getDepArrowInvokeMethod
                  @[I_ldloc receiverLocal; I_ldloc unitArgLocal; callDepArrowInvoke; I_castclass resultType] in
                let lab = generate_code_label () in
                let bb = ILBasicBlock({bblockLabel=lab; bblockInstrs=Array.of_list instrs}) in
                  env, lab, bb
            | _ -> raise Impos (* GADT branches are always hoisted *) in
          
        let translate_gadt_branch env defLabel jump (tcn, ks, pats, _, branch) = 
          let pbtvars, pbxvars, pbfields = getTysFromPats pats, getVarsFromPats pats, getFieldsFromPats pats in
          let _ = if (List.length pbfields <> 0) then raise (Ilgen_error "GADT pattern has extra fields") in 
          let env, branchLabel, branchCode = gadt_branch_code env pbtvars pbxvars branch in 
          let testInstrs = 
            let getType = mk_call systemObjectRef systemObject "GetType" [] systemType in 
            let getName = mk_call memberInfoRef memberInfo "get_Name" [] mscorlibrefs.typ_String in 
            let strcmp = mk_normal_call (mk_static_mspec_in_typ(mscorlibrefs.typ_String, "op_Equality", 
                                                                [mscorlibrefs.typ_String; mscorlibrefs.typ_String],
                                                                mscorlibrefs.typ_bool, [])) in 
            let tagName = spr "%s`%d" (String.concat "." tcn) (List.length pbtvars) in 
              [ldv; getType; getName; I_ldstr tagName; strcmp;
               I_brcmp (BI_brtrue, branchLabel, defLabel)] in 
          let testLabel = generate_code_label () in
          let testCode = ILBasicBlock({bblockLabel=testLabel; bblockInstrs=Array.of_list testInstrs}) in
            env, testLabel, [branchLabel], [testCode;branchCode] in
          (* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ *)
          
        let env, label, internalLabels, codel = List.fold_right 
          (fun ((_, _, _,  gadt, _) as branch) (env, defLabel, internalLabels, codel) -> 
             let env, defLabel', internalLabels', codel' =
               if not gadt then 
                 translate_nongadt_branch env defLabel jump branch 
               else 
                 translate_gadt_branch env defLabel jump branch in
               env, defLabel', internalLabels'@[defLabel]@internalLabels, codel'@codel)
          branches (env, defLabel, [], [defCode]) in
        let groupBlock = mk_group_block(internalLabels, codel) in
          env, label, groupBlock
            
    | e -> (* these are compiled to straight-line sequences of instructions *)
        let env, instrs = tExp2Instrs env e in
        let instrs = match e with 
          | TExp_bot -> instrs
          | _ -> instrs@[jump] in
        let cl = generate_code_label () in
          env, cl, ILBasicBlock ({bblockLabel=cl; bblockInstrs=(Array.of_list instrs)}) in

  let env, label, code = match jump_opt with 
    | None -> tExp2Code env I_ret exp 
    | Some i -> tExp2Code env i exp in
    env, code, label

let rec collect_locals out = function
  | TExp_let (x, e1, e2, hasTypeRef) -> 
      let out = collect_locals ((x, hasTypeRef)::out) e1 in
        collect_locals out e2
  | TExp_isinst (v, branches, defbranch, t) -> (* Q: What's the last argument t for? *)
      let out =
        List.fold_left
          (fun out (tc, ks, pats, gadt, e) -> 
             let targs, xargs = getTysFromPats pats, ((getVarsFromPats pats)@(getFieldsFromPats pats)) in
               if gadt then out (* locals for gadt branches handled specially *)
               else collect_locals ((List.map (fun x -> (x, ref true)) xargs)@out) e)
          out branches in
        collect_locals out defbranch
  | TExp_cond (e1, e2, e3) -> 
      List.fold_left (fun out e -> 
                        collect_locals out e) out [e1;e2;e3] 
  | TExp_ascribed(e, t) -> collect_locals out e
      
  | _ -> out 
      
let mkNewLocs env = 
  let rec aux (newlocs, newloctypes, newobjAttrLocs, tyappAttrLocs) = function
    | [] -> newlocs, newloctypes, newobjAttrLocs, tyappAttrLocs
    | ((lnum, NewObj(ttc, _)) as ll)::tl -> 
        let (cn, ks, args, _) = ttc in
          let targs, vargs = getTys args, getVals args in
          (match lookup_cdecl env cn with
               None -> raise (Ilgen_error (spr "Class not found %s" (String.concat "." cn)))
             | Some cdecl -> 
                 (match cdecl.extends with 
                      None -> (* records are both D and T-classes *)
                        let ttypeInst = TType_concrete ttc in 
                        let iltype = tType2TypeSig env ttypeInst in
                        let newloc = mk_local iltype in
                        let newloctype = (spr "nl%d" lnum, ttypeInst) in
                            aux (newloc::newlocs, newloctype::newloctypes, ll::newobjAttrLocs, tyappAttrLocs) tl
                    | Some ptype -> 
                        let ttypeInst = TargetUtil.instantiateType cdecl ks ((List.map Targ targs)@(List.map Varg vargs)) ptype in
                        let iltype = tType2TypeSig env ttypeInst in
                        let newloc = mk_local iltype in
                        let newloctype = (spr "nl%d" lnum, ttypeInst) in 
                          aux (newloc::newlocs, newloctype::newloctypes, ll::newobjAttrLocs, tyappAttrLocs) tl)) 
    | ((lnum, TyApp _) as ll)::tl ->
        aux (newlocs, newloctypes, newobjAttrLocs, ll::tyappAttrLocs) tl
    | (lnum, GadtLocal iltype)::tl ->
        let newloc = mk_local iltype in
          aux (newloc::newlocs, newloctypes, newobjAttrLocs, tyappAttrLocs) tl in
  let newlocs, newloctypes, newobjAttrLocs, tyappAttrLocs = aux ([],[],[],[]) (snd env.newlocals) in 
    if !Options.writeAttribs then 
      let newobjattr = match newobjAttrLocs with 
         | [] -> empty_attrs
         | _ -> NewObjType(List.map (fun (i, NewObj((cty,  _))) -> i,cty) newobjAttrLocs).encodel() in
      let tyinstAttr = match tyappAttrLocs with 
         | [] -> empty_attrs
         | _ -> TypeInstantiation(List.map (fun (i, TyApp(attr)) -> i,attr) tyappAttrLocs).encodel() in
      let attrs = concat_attrs newobjattr tyinstAttr in
        newlocs, newloctypes, attrs
    else newlocs, newloctypes, empty_attrs

let tExp2ILMethodBody env e = 
  let (raw_locals : (tVar<tType> * bool ref) list) = collect_locals [] e in
  let (localTvars : tVar<tType> list) = List.map fst raw_locals in
  let env = add_local_map env localTvars in
  let env, code, _ = tExp2Code env e None in
  let locals = List.map (fun (tid, tType) -> 
                           let tsig = tType2TypeSig env tType in
                             mk_local tsig) localTvars in
  let newlocs, newloctypes, locattrs =  mkNewLocs env in 
  let maxStackDepth = DEFAULT_MAX_STACK in
    
  (* Write custom attributes. *)
  let (localAttrTypes : tVar<tType> list) =
    let raw_locals = List.filter (fun (_, type_needed) -> !type_needed) raw_locals in 
      List.map (fun ((v, ty), type_needed) -> (v, ty)) raw_locals in (* attrs for newloctypes can be reconstructed from the newobj attrs; no need to write them out again *)
    (* (let locals =  *)
    (*    (\* TODO: Drop inferred types. *\) *)
    (*    List.map (fun ((v, ty), type_needed) -> (v, ty)) raw_locals in (\* attrs for newloctypes can be reconstructed from the newobj attrs; no need to write them out again *\) *)
    (*    locals@newloctypes) in *)
  let attrs =
    let localAttrTypes = List.filter (fun (_, t) -> type_needs_attrib t) localAttrTypes in
    let x = (List.length localAttrTypes, List.map write_local_type localAttrTypes) in
    LocalTypeDecls(x).encodel() in
    mk_ilmbody (true, locals@newlocs, maxStackDepth, code, None), concat_attrs attrs locattrs
      
let tMethodDecl2MethodDef env (retType, mname, (targs : tVar<tKind> list), (args : tVar<tType> list), bodyOpt) = 
    begin
      let gpds = List.map tVar2GenericParameterDef targs in
      let env = add_generic_params env gpds in
      let plist = List.map (fun (n, t) -> 
                              let ts = tType2TypeSig env t in
                                mk_param (Some n, ts)) args in
        (* NOTE: This should go away when the generic param attrs bug is fixed. *)
      let kattr = ClassParamKinds(List.map snd targs).encodel() in
      let pattr =
        if List.exists (fun (_v, ty) -> type_needs_attrib ty) args
        then MethodParamTypes(args).encodel()
        else empty_attrs in
      let env = add_parameter_map env args in
      let retTypeSig =  (* retType is already normalized; so can't tell that it's a TType_tapp *)
        if mname="TyApp" then mscorlibrefs.typ_Object 
        else tType2TypeSig env retType in
      let body, mk, localAttrs = match bodyOpt with
          None -> MethodBody_abstract, Some (MethodKind_virtual {virtFinal=false;
                                                                 virtNewslot=true;
                                                                 virtStrict=false;
                                                                 virtAbstract=true}), empty_attrs
        | Some b ->  
              (let mb, localAttrs = tExp2ILMethodBody env b in
                 MethodBody_il mb, None, localAttrs) in
      let res = match gpds with
          [] -> 
            mk_nongeneric_virtual_mdef(mname, MemAccess_public, plist, mk_return retTypeSig, body)
        | _ -> 
            mk_generic_virtual_mdef (mname, MemAccess_public, 
                                     gpds, plist, 
                                     mk_return retTypeSig, 
                                     body) in
      let attrs =
          (let attrs' =
             if List.exists (fun (_n, ty) -> type_needs_attrib ty) args
             then concat_attrs kattr (concat_attrs pattr localAttrs)
             else concat_attrs kattr localAttrs in
             if (not (mname.Equals("TyApp"))) && (type_needs_attrib retType)
             then
               let ret = MethodReturnType(retType).encodel() in 
                 concat_attrs ret attrs'
             else attrs') in 
        match mk with
          | None -> {res with mdCustomAttrs= if !Options.writeAttribs then attrs else empty_attrs}
          | Some mk -> {res with mdKind=mk; mdCustomAttrs= if !Options.writeAttribs then attrs else empty_attrs} 
    end
          
let genericParameterDef2GenericArg env gpd = 
  let tvid = must (lookup_tvar_id env (gpd.gpName, ())) (fun () -> "Tyvar not found") in
    Type_tyvar tvid

let makeConstructorMethodDef env (tcd:tClassDecl) (superTsig:ILType) superArgs fds = 
  let params, setFieldInstrsL, _ = 
    List.fold_left (fun (params, instrsL, count) (fd:ILFieldDef) ->
                      let param = mk_named_param(fd.Name, fd.Type) in
                      let isStatic, fspec = must (lookup_fieldspec env (fd.Name, ())) (fun () -> "Field spec not found") in
                        if isStatic then raise Impos;
                        let stinstrs = [I_ldarg 0us;
                                        I_ldarg count;
                                        mk_normal_stfld fspec] in
                          param::params, stinstrs::instrsL, count + 1us) ([], [], 1us) fds in
  let rec super_init_and_typ env fds (v, ilType) = 
    try 
      let _, instrs = tExp2Instrs {env with allowNewLocs=false} (TExp_val v) in 
        (* let ilType = tType2TypeSig env t in *)
        (* let _ = pr "super constructor arg: %s (%s)\n" (PrettyTarget.strType t) ilType.BasicQualifiedName in *)
      instrs, ilType
    with
      | _ ->  if (ilType = mscorlibrefs.typ_int32) then [I_arith (AI_ldc (DT_U2, NUM_I4 (int32 0)))], ilType
        else if (ilType = mscorlibrefs.typ_bool) then [I_arith (AI_ldc (DT_I4, NUM_I4 0))], ilType
        else if (ilType = mscorlibrefs.typ_String) then [I_ldstr ""], ilType
        else [I_arith (AI_ldnull)], ilType
  in
  let env = {env with
               paramindices=fst <| (List.fold_left (fun (ps, ix) fd -> (fd.fdName, ix)::ps, ix+1us) 
                                      ([], 0us) fds) } in
  (* let _ = pr "Calling super ctor on class %s (%A)\n" superTsig.BasicQualifiedName superTsig in  *)
  let superInit_Typs = List.map (super_init_and_typ env fds) superArgs in
  let superCtorSpec = mk_ctor_mspec_for_typ(superTsig, List.map snd superInit_Typs) in
  let superInits = List.concat (List.map fst superInit_Typs) in 
  let superCall = [ldarg_0]@superInits@[mk_normal_call superCtorSpec] in
  let params = List.rev params in
  let setFields = List.concat (List.rev setFieldInstrsL) in
  let ctorInstrs = superCall@setFields@[I_ret] in
  let code = nonbranching_instrs_to_code ctorInstrs in
  let mb = MethodBody_il (mk_ilmbody (true, [], DEFAULT_MAX_STACK, code, None)) in
    mk_ctor(MemAccess_public, params, mb)

let mk_entry_point env e =
  trace -1977 "Entry point target expression" e;
  let mb, attrs = (tExp2ILMethodBody {env with eraseUnit=true} e) in
  let mbody = MethodBody_il mb in
  let mdef = mk_static_nongeneric_mdef ("__entrypoint", 
                                        MemAccess_public, 
                                        [],
                                        mk_return Type_void, 
                                        mbody) in
    (*   let attrs = mk_custom_attrs [(mk_DebuggableAttribute ecmaILGlobals (false, false))] in *)
    (*   let mdef = {mdef with mdEntrypoint=true; mdCustomAttrs=attrs} in *)
  let mdef =
    { mdef with
        mdEntrypoint=true;
        mdCustomAttrs=if !Options.writeAttribs then attrs else empty_attrs} in
    mdef

(* This makes the class constructor .cctor. *)
let mk_static_field_initializers env staticfields fspecs = 
  let (raw_locals : (tVar<tType> * bool ref) list) =
    List.fold_left
      (fun out -> function
        (_, _, None) -> out
      | (_, _, Some e) -> collect_locals out e) [] staticfields  in
  let (locals : tVar<tType> list) = List.map fst raw_locals in
  let env = add_local_map env locals in
  let ret_label = generate_code_label() in

  let ret = ILBasicBlock({bblockLabel=ret_label; bblockInstrs=[|I_ret|]}) in    
  let add_initializer (fn, t, init) (fspec:ILFieldSpec) (env, jump_lab, block) =  
    match init with
        None -> (env, jump_lab, block)
      | Some init -> 
          let stfld = mk_normal_stsfld fspec in
          let st = match init with 
            | TExp_val (TVal_constant _) -> [stfld; I_br jump_lab]
            | _ -> [I_castclass (fspec.FormalType); 
                    stfld; I_br jump_lab] in
          let stlab = generate_code_label() in
          let stcode = ILBasicBlock({bblockLabel=stlab; bblockInstrs=Array.of_list st}) in
          let env, initcode, init_label = tExp2Code env init (Some (I_br stlab)) in
          let groupBlock = mk_group_block ([stlab; jump_lab], [initcode;stcode;block]) in
            (env, init_label, groupBlock) in
  let (env, _, code) = List.fold_right2 add_initializer staticfields fspecs (env, ret_label, ret) in
  let illocs = List.map (fun (tid, tType) -> 
                           let tsig = tType2TypeSig env tType in
                             mk_local tsig) locals in
  let newlocs, newloctypes, locattrs = mkNewLocs env in
  let illocs = illocs@newlocs in 
  let md = mk_cctor (MethodBody_il (mk_ilmbody(true, illocs, DEFAULT_MAX_STACK, code, None))) in
    if !Options.writeAttribs then 
      let allLocs = locals@newloctypes in
      let loctypattr = LocalTypeDecls((List.length locals, List.map write_local_type allLocs)).encodel() in
        {md with mdCustomAttrs = concat_attrs loctypattr locattrs}
    else md

let tClassDecl2TypeDef env (tcd:tClassDecl) extraAttrs = 
  let ns, className = tClassName2NamespaceAndString tcd.name in
  let env = {env with curclassname=className} in
  let tda = tVisibility2TypeDefAccess tcd.visibility in
  let fo_tvars, ho_tvars = split_ho_tvars (getTvars tcd) in
  let gpds = List.map tVar2GenericParameterDef fo_tvars in
  let env = add_generic_params env gpds in
  let ext, superArgs = match tcd.extends with 
    | None -> mscorlibrefs.typ_Object, []
    | Some (TType_affine(TType_concrete(cn, ks, args, _) as t_ext))
    | Some ((TType_concrete(cn, ks, args, _) as t_ext))  -> (* TODO: fix this if type is external *) 
        let tpl, vpl = getTys args, getVals args in
        let t_extSig = tType2TypeSig env t_ext in
          (match vpl with
             | [] -> 
                 let valParams = match tcd.tagNum with
                   | None -> []
                   | Some i -> 
                       (* let _ = pr "ILGEN (%s): adding arg to super constructor for tag %d\n" className i in  *)
                         [(TVal_constant (Const_int32 i), mscorlibrefs.typ_int32)] in
                   t_extSig, valParams
             | _ -> 
                 let cnDecl = TargetUtil.lookupCdeclByName env.classDeclEnv cn in 
                 let tvarindices = fst <| List.fold_left (fun (out, ix) v -> match v with 
                                                            | Tvar (id, _) -> (id, ix)::out, ix+1us
                                                            | _ -> out, ix) ([], 0us) cnDecl.vars in
                 let env' = {env with tvarindices=tvarindices} in 
                 let argTypes = List.rev <| List.fold_left (fun out v -> match v with 
                                                              | Tvar _ -> out
                                                              | Vvar (_, t) -> (tType2TypeSig env' t)::out) [] cnDecl.vars in
                 let valParams = List.zip vpl argTypes in 
                 let valParams = match tcd.tagNum with
                   | None -> valParams
                   | Some i -> 
                       (* let _ = pr "ILGEN (%s): adding arg to super constructor for tag %d\n" className i in  *)
                         (TVal_constant (Const_int32 i), mscorlibrefs.typ_int32)::valParams in
                   t_extSig, valParams)
            
    | Some ((TType_name _) as tn) -> 
        let t_extSig = tType2TypeSig env tn in 
        let valParams = match tcd.tagNum with
          | None -> []
          | Some i -> 
              (* let _ = pr "ILGEN (%s): adding arg to super constructor for tag %d\n" className i in  *)
                [(TVal_constant (Const_int32 i), mscorlibrefs.typ_int32)] in
          t_extSig, valParams
            
    | _ -> printfn "%A" tcd.extends; raise Impos in
  let vvars = getVvars tcd in
  let vvfds = List.map (tFieldDecl2FieldDef true Instance env) vvars in 
  let fields = tcd.fields in
  let ifds = List.map (tFieldDecl2FieldDef false Instance env) fields in
  let sfds = tcd.staticFields in
  let sfds = List.map (fun (fn, typ, init) -> 
                         tFieldDecl2FieldDef false Static env (fn, typ)) sfds in
  let tagFdOpt = 
    if tcd.hasTag 
    then Some (tFieldDecl2FieldDef false Instance env ("__tag", intType))
    else None in
  let allFields = consOpt tagFdOpt (vvfds@ifds@sfds) in
  let fds = IL.mk_fdefs allFields in
  let ngenerics = List.length gpds in
  let className = if ngenerics <> 0 then spr "%s`%d" className ngenerics else className in
         (*printfn "Generating decl for class %s\n" className; *)
  let thisTypeRef = 
    if className = env.curmodulename then 
      ILTypeRef.Create (ScopeRef_local, [], className) 
    else   
      ILTypeRef.Create (ScopeRef_local, [env.curmodulename], className) in
  let genericArgs = List.map (genericParameterDef2GenericArg env) gpds in
  let thisTypeSig = mk_boxed_typ thisTypeRef genericArgs in
  let fieldSpecs = List.map 
    (fun fd -> 
       let fref =  mk_fref_to_fdef (thisTypeRef, fd) in
       let fspec = mk_fspec (fref, thisTypeSig) in
         fd.fdName, (fd.IsStatic, fspec)) (dest_fdefs fds) in
  let env = add_fieldspec_map env fieldSpecs in
  let mds = List.map (tMethodDecl2MethodDef env) tcd.methods in
  let isabs = (Target.is_abstract tcd.name) || (List.exists (fun md -> match md.mdKind with 
                                                               | MethodKind_virtual k -> k.virtAbstract 
                                                               | _ -> false) mds) in
  let mds = 
    let ctor = makeConstructorMethodDef env tcd ext superArgs (consOpt tagFdOpt (vvfds@ifds)) in 
      ctor::mds in
  let mds = 
    if (Sugar.text_of_path tcd.name) = env.curmodulename then 
      match env.entry with
          None -> mds
        | Some e -> 
            let emdef = mk_entry_point env e in 
              emdef::mds 
    else mds in
  let mds = IL.mk_mdefs mds in
  let mds = 
    if List.length tcd.staticFields <> 0 then 
      let fspecs = (List.map (fun sfd -> 
                                let fref =  mk_fref_to_fdef (thisTypeRef, sfd) in
                                  mk_fspec (fref, thisTypeSig)) sfds) in
      let cctor = mk_static_field_initializers env tcd.staticFields fspecs in
        add_mdef cctor mds
    else mds in
(*     printfn "Generating decl for class %s\n" className; *)
  let td = IL.mk_generic_class (className, tda, gpds, ext, [], mds, fds, mk_tdefs [], props, events, atts, TypeInit_beforefield) in
  let is_nested = className <> env.curmodulename in
  let superClassAttr = match tcd.extends with 
    | Some t ->
        if type_needs_attrib t
        then SuperClassType(t).encodel() //toCustomAttrs superClassAttr (CustomAttr.toCompactRepr t)
        else empty_attrs
    | _ -> empty_attrs in
  let evidenceAttrs = Evidence(tcd.evidences).encodel() in 
  let ho_tvarsAttrs =
    if ho_tvars <> []
    then HigherOrderTvars(ho_tvars).encodel()
    else empty_attrs in
  (* NOTE: This should go away when the AbSIL bug is fixed. *)
  let classParamKindsAttrs =
    let tvarKinds = List.map snd (getTvars tcd) in
      ClassParamKinds(tvarKinds).encodel() in
  let classPtvarsAttrs = empty_attrs in (* TODO: should remove it completely *)
  let kindAttrs = match tcd.kind with 
    | None -> empty_attrs
    | Some k ->
        if kind_needs_attrib k
        then ClassKind(k).encodel()
        else empty_attrs in
  let attrs =
    (List.fold_left concat_attrs empty_attrs [classPtvarsAttrs;classParamKindsAttrs;kindAttrs;superClassAttr;evidenceAttrs;ho_tvarsAttrs;extraAttrs]) in
  let td = match td.tdAccess with 
      TypeAccess_public when is_nested -> 
        {td with
           tdAbstract=isabs;
           tdAccess=IL.Nested MemAccess_public;
           tdCustomAttrs=if !Options.writeAttribs then attrs else empty_attrs}
    | _ ->
        {td with
           tdAbstract=isabs;
           tdCustomAttrs=if !Options.writeAttribs then attrs else empty_attrs} in
    td
      (*     add_initializers env td tcd.staticFields  *)
      (*       (List.map (fun sfd ->  *)
      (*                    let fref =  mk_fref_to_fdef (thisTypeRef, sfd) in *)
      (*                      mk_fspec (fref, thisTypeSig)) sfds) *)
      
let remove_dups (decls:list<tClassDecl>) = 
  let rec aux (out:list<string * tClassDecl>) (x:list<tClassDecl>) = match x with
    | [] -> List.rev (List.map snd out)
    | hd::tl -> let thisclassName = String.concat "." hd.name in
        match List.tryFind (fun (cn, _) -> cn=thisclassName) out with
            Some _ -> aux out tl
          | None -> aux ((thisclassName, hd)::out) tl in    
    aux [] decls 
      
let addTopLevelFieldDecls (m:tModule) env : env = 
  let top = m.modCdecl in
  let topTref = ILTypeRef.Create (ScopeRef_local, [], Sugar.text_of_path top.name) in
  let topTsig = mk_nongeneric_boxed_typ topTref in
    {env with topfields=Some(topTref, topTsig, top.staticFields)}

let predefined_classes =
  match Target.predefined_classes with 
      [_; arrow; deptuple; tuple; dcondtuple; dcontuple; all] -> 
        [arrow; deptuple; tuple;
         Translation.addEqualityMethod dcondtuple;
         (* Translation.addEqualityMethod  *)dcontuple;
         all]
                                                      
let tmod_to_tdef env (m:tModule) : ILTypeDef  = 
//   pr "\n**********\n";
//   pr "tmod_to_absil called for module %A with externs %A\n" m.name m.externMethods;
//   pr "\n**********\n"; 
  let env = {env with curmodulename=String.concat "." m.name; externMeths=m.externMethods} in
  let mname = Sugar.text_of_path m.name in
  let decls = 
    if m.name <> ["Prims"] then 
      Hashtbl.fold (fun n (cd:tClassDecl) (cls:list<tClassDecl>) -> if (is_primitive (List.hd cd.name)) then cls else cls@[cd]) m.decls [] 
        (*List.filter (fun tcd -> not (is_primitive (List.hd tcd.name))) m.decls *)
    else      (*List.filter (fun tcd -> tcd.name <> ["Prims";"unit"]) m.decls *)
      let d = Hashtbl.fold (fun name (cd:tClassDecl) (cls:list<tClassDecl>) -> if (name = "Prims.unit") then cls else cls@[cd]) m.decls [] in
        predefined_classes@d
  in
  let decls = remove_dups decls in
  let env = addTopLevelFieldDecls m env in
  let tdefs = IL.mk_tdefs (List.map (fun d -> tClassDecl2TypeDef env d empty_attrs) decls) in
  let mainclass = match m.extends with
    | Some [mn] -> 
(*         Printf.printf "Module %s extends module %s\n" env.curmodulename mn; *)
        {m.modCdecl with extends=Some(TType_concrete ([mn;mn], [], [], None))} 
    | _ -> m.modCdecl in
  let externMethods =
    if !Options.writeAttribs
    then ExternMethods(m.externMethods).encodel()
    else empty_attrs in
  let mainclass = {(tClassDecl2TypeDef env mainclass externMethods) with tdNested=tdefs} in
    mainclass

let wrapTypeDefsInAssembly tdefs asmname : ILModuleDef = 
  let metadataVersion = Options.get_metadata_version () in
  let exportedTypes = (mk_exported_types [])  in
  let flags = 0x0 in
    mk_simple_mainmod asmname ("FStar-Module-"^asmname) true (mk_tdefs tdefs) None None flags exportedTypes metadataVersion

let tmods_to_absil env (ms:list<tModule>) (asmname:string) : ILModuleDef = 
  let tdefs = List.map (tmod_to_tdef env) ms in
    wrapTypeDefsInAssembly tdefs asmname 

let tmod_to_absil env (m:tModule) : ILModuleDef = 
  let asmname = Sugar.text_of_path m.name in
   tmods_to_absil env [m] asmname

let partially_trusted_callers = ILTypeRef.Create(ecma_mscorlib_scoref, [], "System.Security.AllowPartiallyTrustedCallersAttribute")
let ptc_attr = IL.mk_custom_attribute mscorlibrefs (partially_trusted_callers, [], [], [])
type mkind = EXE | DLL 
type output = BYTES | FILE

let mkindOfTmod (tmod:tModule) = match tmod.entry with None -> DLL | _ -> EXE
     
let write_il mkind (m:ILModuleDef) : unit = 
  let ext, m = match mkind with 
     | DLL -> ".dll", m 
     | EXE -> ".exe", {m with modulDLL=false} in
  let fname = match m.modulManifest with
    | Some n -> n.manifestName ^ ext 
    | None -> m.modulName ^ ext in 
  let fname = Options.prependOutputDir fname in 
  let manifest = match m.modulManifest with
    | None -> failwith "expected manifest on main module"
    | Some manifest -> 
        if !Options.allow_partially_trusted then
          { manifest with 
            IL.manifestCustomAttrs =
              if !Options.writeAttribs
                then IL.mk_custom_attrs [ ptc_attr ] else empty_attrs}
        else 
          manifest in
  let defaults =  { BinaryWriter.mscorlib=ecma_mscorlib_scoref ;
                    BinaryWriter.pdbfile=None;
                    BinaryWriter.signer=Options.get_signer ();
                    BinaryWriter.fixupOverlappingSequencePoints=false } in
  let _ = pr "Writing to file %s\n" fname in 
    BinaryWriter.WriteILBinary fname defaults ({ m with IL.modulManifest = Some manifest })

let write_il_bytes mkind (m:ILModuleDef) : byte[] = 
  let manifest = match m.modulManifest with
    | None -> failwith "expected manifest on main module"
    | Some manifest -> 
        if !Options.allow_partially_trusted then
          { manifest with 
            IL.manifestCustomAttrs =
              if !Options.writeAttribs then IL.mk_custom_attrs [ ptc_attr ] else empty_attrs}
        else 
          manifest in
  let defaults =  { BinaryWriter.mscorlib=ecma_mscorlib_scoref ;
                    BinaryWriter.pdbfile=None;
                    BinaryWriter.signer=Options.get_signer ();
                    BinaryWriter.fixupOverlappingSequencePoints=false } in
    BinaryWriter.WriteILBinaryBytes defaults ({ m with IL.modulManifest = Some manifest })

let writeMultipleAssemblies borf env tmods : Disj<list<byte[]>, unit> = 
    let _, out = List.fold_left (fun (env, ilmods) tm -> 
        let env' = extend_env env tm in
        let ilmod = tmod_to_absil env' tm in
            (* Attribute profile. *)
        if !Options.profile_attribs
        then (Attribs.print_attrib_size tm.name; Attribs.reset_attrib_counts ());
        let mk = mkindOfTmod tm in
        let out = match borf with BYTES -> Inl (write_il_bytes mk ilmod) | FILE -> Inr (write_il mk ilmod) in 
            env', (tm, ilmod, out)::ilmods) (env, []) tmods in
        match borf with 
            | FILE -> Inr ()
            | _ -> Inl (List.map (fun (_, _, Inl b) -> b) out |> List.rev)

let writeAssembly borf env (tmods:list<tModule>) name : Disj<byte[], unit> = 
    let env, tdsrev = List.fold_left (fun (env, tds) tm ->
        if mkindOfTmod tm = EXE then failwith "executables must be emitted in a dedicated dll; drop the -o flag"; 
        let env = extend_env env tm in 
        let td = tmod_to_tdef env tm in
        if !Options.profile_attribs
        then (Attribs.print_attrib_size tm.name; Attribs.reset_attrib_counts ());
            env, td::tds) (env, []) tmods in
    let tds = List.rev tdsrev in 
    let md = wrapTypeDefsInAssembly tds name in
    let out = match borf with 
      | BYTES -> Inl (write_il_bytes DLL md) 
      | FILE -> 
          pr "!!!Writing to file ... !!!\n";
          Inr (write_il DLL md) in
      out
        
let writeAssemblies env (tmods:list<tModule>) asmNameOpt =
    match asmNameOpt with 
        | None -> let _ = writeMultipleAssemblies FILE env tmods in ()
        | Some asmName -> 
            let allModNames = List.map (fun tm -> Sugar.text_of_path tm.name) tmods in
            let _ = pr "Writing to FILE: Mods in this assembly = %A\n" allModNames in
            let _ = writeAssembly FILE {env with modsInThisAssembly=allModNames} tmods asmName in ()

let writeAssembliesBytes env (tmods:list<tModule>) asmNameOpt : list<byte[]> =
    match asmNameOpt with 
        | None -> 
            (match writeMultipleAssemblies BYTES env tmods with Inl bytes -> bytes | _ -> raise Impos)
        | Some asmName -> 
            let allModNames = List.map (fun tm -> Sugar.text_of_path tm.name) tmods in
            let _ = pr "Mods in this assembly = %A\n" allModNames in
            (match writeAssembly BYTES {env with modsInThisAssembly=allModNames} tmods asmName with 
                | Inl bytes -> [bytes]
                | Inr _ -> raise Impos)
             
