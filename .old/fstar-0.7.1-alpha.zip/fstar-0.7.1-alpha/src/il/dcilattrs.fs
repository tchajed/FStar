﻿module Microsoft.FStar.DcilAttrs

open System
open System.Text

open Microsoft.FSharp.Compiler.AbstractIL
open Microsoft.FSharp.Compiler.AbstractIL.IL
open Microsoft.FStar.Target
open Microsoft.FStar.TargetUtil
open Microsoft.FStar.AttribAst
open Microsoft.FStar.Attribs
open Microsoft.FStar.Util

exception AttributeCodec of string

let dcil_attrs = 
  ILAssemblyRef.Create("il", 
                       None,
                       None, 
                       false,
                       None,
                       None)
let dcilAttrsScope = ILScopeRef.Assembly(dcil_attrs)
let ecmaILGlobals = mk_ILGlobals ecma_mscorlib_scoref None
let to_b64 = System.Convert.ToBase64String
let from_b64 = System.Convert.FromBase64String
let attrName (a:ILAttribute) = a.Method.EnclosingType.BasicQualifiedName
let moduleName = "Microsoft.FStar.DcilAttrs"

(* All attributes are serialized to and from the standard serialization.  This
   code is for serialization and deserialization of the compact
   representation. *)
let serialize_attribute (attrib : AttribAst.attrib) (size_count : int ref)
  : string =
  let (initial_bytes : byte []) =
    if !Options.prettyAttribs
      then
        let as_str = pickle_attrib attrib in
          Printf.printf "%s \n" as_str;
          string_to_ascii_bytes as_str
      else Util.__temp_dot_net_marshall attrib in
  let compressed = Util.standard_compress initial_bytes in
    size_count := !size_count + compressed.Length;
    to_b64 compressed
let deserialize_attribute (str : string) : AttribAst.attrib =
  let (compressed_bytes : byte []) = from_b64 str in
  let (decompressed : byte [] ) = Util.standard_decompress compressed_bytes in
  if !Options.prettyAttribs
    then
      let str = ascii_bytes_to_string decompressed in
      match tryParse str with
      | Some at -> at
      | None -> raise (AttributeCodec "Could not parse attribute")
    else
      (* let (decompressed : byte []) = Util.standard_decompress bytes in *)
      Util.__temp_dot_net_unmarshall decompressed :> AttribAst.attrib in 

(* Below are functions for converting specific target types to attribute
   representations. *)

(* Encoding a tType first involves converting it to a conpact aType representation. *)
let encode_tType (t : tType) : string =
  (*maybeSkip () ^^ lazy *)
    serialize_attribute (AttribAst.AttrType (tType2aType t)) size_type
let decode_tType (str : String) (default_ty : tType) : tType =
  let aType =
    match deserialize_attribute str with
    | AttribAst.AttrType t -> t
    | _ -> raise (AttributeCodec "Did not get type from parsing") in
    match aType2tType (Some default_ty) aType with
    | Some ty -> ty
    | None -> raise (AttribConvertError "could not get type")
 
let encode_tKind (k :tKind) : string =
  (* maybeSkip () ^^ lazy *)
    serialize_attribute (AttribAst.AttrKind k) size_kinds
let decode_tKind (str : String) : tKind =
  match deserialize_attribute str with
  | AttribAst.AttrKind k -> k
  | _ -> raise (AttributeCodec "Did not get kind from parsing")

(**
  Attributes for DCIL metadata in the form of tagged attributes on CIL DLLs.
 *)
[<AbstractClass>]
type DcilAttribute() =
    inherit Attribute ()
    abstract attrName : string with get
    (* NOTE(JY): Had to make this a + to get checkAttrs to work. *)
    member this.typeRef = mk_tref(dcilAttrsScope, moduleName ^ "+" ^ this.attrName)

    (* Encoding.  The current encoding strategy involves serializing a compact
       representation of the attribute. *)
    abstract member encode : unit -> ILAttribute
    default this.encode() = Attribs.toILAttribute this.typeRef (this.getSerialForm())
    member this.encodel() = mk_custom_attrs [this.encode()]
    (* Serializes. *)
    abstract member getSerialForm : unit -> string

    (* Decoding. *)
    (* NOTE(JY): What is the difference between the two decodeData functions? *)
    static member decodeData(attr:ILAttribute) : string = 
        let ([ae], _) = decode_il_attrib_data ecmaILGlobals attr None in
        match ae with
         | CustomElem_string (Some str) -> str
         | _ -> raise (AttributeCodec "Empty attribute")
    static member decodeData(attrs:ILAttributes, fullTypeName:string) : string option =
        try
            let attrs = IL.dest_custom_attrs attrs
            let attr = attrs |> List.find (fun a -> (attrName a) = fullTypeName) 
            Some (DcilAttribute.decodeData attr)
        with :? System.Collections.Generic.KeyNotFoundException -> None
    static member deserialize (str : string) : 'a =
      let bytes = Util.string_to_ascii_bytes str in
        Util.__temp_dot_net_unmarshall bytes (* .NET deserialization; other options slot in here. *)

    static member checkAttr(attr, fullTypeName) = 
      if (attrName attr) = fullTypeName then ()
      else
        Printf.printf "Got name %s, but attribute has name %s\n" fullTypeName (attrName attr);
        raise (AttributeCodec ("Wrong attribute name; expected "^fullTypeName))

type ValueParameter() = //data-less attribute; only one constructor
    inherit DcilAttribute()
    override this.attrName = "ValueParameter" 
    static member fullTypeName = ValueParameter().GetType().FullName
    static member decode(attrs:ILAttributes) =      //fake constructor: called during DCIL reconstruction
        Printf.printf "%s\n" ValueParameter.fullTypeName;
        match DcilAttribute.decodeData(attrs, ValueParameter.fullTypeName) with
            | None -> false 
            | Some ser -> true
    override this.encode() : ILAttribute =
      mk_custom_attribute ecmaILGlobals (this.typeRef, [],[],[])
    override this.getSerialForm() = raise Impos

type Evidence(_evopt: tEvidences option, _seropt:string option) =                      //default constructor, never directly called
    inherit DcilAttribute()
    let mutable evopt = _evopt 
    let mutable seropt = _seropt
    new(evs:tEvidences) = Evidence(Some evs, None)  //called during ilgen
    new(ser:string) = Evidence(None, Some ser)      //called by VM at reflection time
    override this.attrName = "Evidence"
    static member fullTypeName = Evidence(None, None).GetType().FullName
    (* TODO: Read from compact representation. *)
    static member decode(attrs:ILAttributes) : Evidence =      //fake constructor: called during DCIL reconstruction
        match Evidence.decodeData(attrs, Evidence.fullTypeName) with
            | None -> Evidence(Some [], None)
            | Some ser ->
                let ev =
                  match deserialize_attribute ser with
                  | AttribAst.AttrEvidences evs -> evs
                  | _ -> raise (AttributeCodec "Did not get evidence from parsing") in
                Evidence(Some ev, Some ser)
    (* This implementation is basically inlined from Attribs.CustomAttr.toCompactRepr *)
    override this.getSerialForm() = match seropt, evopt with 
        | Some ser, _ -> ser
        | _, Some evs ->
            let ser = serialize_attribute (AttribAst.AttrEvidences evs) size_evidences in
            seropt <- Some ser;
            ser
        | _ -> raise (AttributeCodec "Empty evidence attribute")
    member this.getValue() = match evopt, seropt with 
        | Some evs, _ -> evs
        | _, Some ser -> 
            let evs = Evidence.deserialize ser
            evopt <- Some evs;
            evs
        | _ -> raise (AttributeCodec "Empty evidence attribute")

type SuperClassType(_topt : tType option, _seropt : string option) =
    inherit DcilAttribute()
    let mutable topt = _topt 
    let mutable seropt = _seropt 
    new(t:tType) = SuperClassType(Some t, None)
    new(ser:string) = SuperClassType(None, Some ser)
    override this.attrName = "SuperClassType"
    static member thisType = SuperClassType(None,None).GetType()
    static member fullTypeName = SuperClassType.thisType.FullName
    static member decode(attrs:ILAttributes, def:tType option) : SuperClassType =
        match DcilAttribute.decodeData(attrs, SuperClassType.fullTypeName) with
            | None -> SuperClassType(def, None)
            | Some ser ->
                let t = SuperClassType.decodeString(ser, def) 
                SuperClassType(Some t, Some ser)        
    static member decode(tt:System.Type, def:tType) : SuperClassType =
        try 
            Attribute.GetCustomAttribute(tt, SuperClassType.thisType) :?> SuperClassType
        with _ -> SuperClassType(def)
    static member decodeString(str:string, def:tType option) : tType =
        let defType = match def with Some t -> t | _ -> Target.botType in
        decode_tType str defType
    (* Serialization involves converting to the compact representation. *)
    override this.getSerialForm() = match seropt, topt with 
        | Some ser, _ -> ser
        | _, Some t ->
            let ser = encode_tType t
            seropt <- Some ser;
            ser
        | _ -> raise (AttributeCodec "Empty super class attribute")
    member this.getValue(def:tType option) = match topt, seropt with 
        | Some t, _ -> t
        | _, Some ser -> 
            let t = SuperClassType.decodeString(ser, def)
            topt <- Some t;
            t
        | _ -> raise (AttributeCodec "Empty super class attribute")
    member this.getValue() = match topt with 
        | Some t -> t
        | _ -> raise (AttributeCodec "Empty super class attribute")

(* AttrLocVarTypes of int * tVar<aType> list *)
type LocalTypeDecls(_valopt:option<int * list<tVar<tType option>>>, _seropt:option<string>) =
    inherit DcilAttribute()
    let mutable valopt = _valopt
    let mutable seropt = _seropt 
    new(v) = LocalTypeDecls(Some v, None)
    new(s) = LocalTypeDecls(None, Some s)
    override this.attrName = "LocalTypeDecls"
    static member fullTypeName = LocalTypeDecls(None, None).GetType().FullName
    static member decode(attrs:ILAttributes, mname:string, def_locs:list<tType>) = 
        match DcilAttribute.decodeData(attrs, LocalTypeDecls.fullTypeName) with 
            | None -> 
                if mname.Equals(".ctor") || mname.Equals(".cctor")
                then
                    let def_locs = List.map (fun ty -> (Absyn.gensym None, Some ty)) def_locs 
                    LocalTypeDecls((List.length def_locs, def_locs))
                else (raise (AttributeCodec(spr "No locals for %s\n" mname)))
            | Some ser -> LocalTypeDecls(Some(LocalTypeDecls.decodeString(ser, mname, def_locs)), Some ser)
    static member decodeString(ser, mname:string, def_locs:list<tType>) = 
        let (tys: int * tVar<aType> list) = DcilAttribute.deserialize ser
        let x = def_locs, tys 
        let i, tl = Attribs.CustomAttr.fromCompactRepr x 
        i, tl |> List.map (fun (x,t) -> (x, Some t))
    override this.getSerialForm() = match seropt, valopt with 
        | Some ser, _ -> ser
        | _, Some v -> 
            let ser = to_b64 (Attribs.CustomAttr.toCompactRepr(v)) in
            seropt <- Some ser;
            ser
        | _ -> raise (AttributeCodec "Empty LocalTypeDecls")
    member this.getValue(mname:string, def_locs:list<tType>) = match valopt, seropt with 
        | Some v, _ -> v
        | _, Some ser -> 
            let v = LocalTypeDecls.decodeString(ser, mname, def_locs)
            valopt <- Some v;
            v
        | _ -> raise (AttributeCodec "Empty LocalTypeDecls")
    member this.getValue() = match valopt with 
        | Some v -> v
        | _ -> raise (AttributeCodec "Empty LocalTypeDecls")

type GenericParamKind(_kopt:tKind option, _seropt:string option) =
    inherit DcilAttribute()
    let mutable kopt = _kopt
    let mutable seropt = _seropt
    new(k) = GenericParamKind(Some k, None)
    new(s) = GenericParamKind(None, Some s)
    override this.attrName = "GenericParamKind"
    static member fullTypeName = GenericParamKind(None, None).GetType().FullName
    static member decode(attrs:ILAttributes) = 
        match DcilAttribute.decodeData(attrs, GenericParamKind.fullTypeName) with 
            | None -> GenericParamKind(TKind_star)
            | Some ser -> GenericParamKind(Some (GenericParamKind.decodeString(ser)), Some ser)
    static member decodeString(ser) : tKind = decode_tKind ser
    override this.getSerialForm() = match seropt, kopt with 
        | Some ser, _ -> ser
        | _, Some k -> 
            let ser = encode_tKind k in
            seropt <- Some ser;
            ser
        | _ -> raise (AttributeCodec "Empty GenericParamKind")
    member this.getValue() = match kopt, seropt with 
        | Some k, _ -> k
        | _, Some ser -> 
            let k = GenericParamKind.decodeString(ser)
            kopt <- Some k;
            k
        | _ -> raise (AttributeCodec "Empty GenericParamKind")

type ClassPtvars(_slopt, _seropt:string option) =
    inherit DcilAttribute()
    let mutable slopt = _slopt
    let mutable seropt = _seropt 
    new(sl) = ClassPtvars(Some sl, None)
    new(ser) = ClassPtvars(None, Some ser)
    override this.attrName = "ClassPtvars"
    static member fullTypeName = ClassPtvars(None, None).GetType().FullName
    static member decode(attrs:ILAttributes) = 
        match DcilAttribute.decodeData(attrs, ClassPtvars.fullTypeName) with 
            | None -> ClassPtvars([])
            | Some ser -> ClassPtvars(Some(ClassPtvars.decodeString(ser)), Some ser)
    static member decodeString(ser) : string list = DcilAttribute.deserialize ser
    override this.getSerialForm() = match seropt, slopt with 
        | Some ser, _ -> ser
        | _, Some sl -> 
            let ser = to_b64(Attribs.CustomAttr.toCompactRepr(sl)) in
            seropt <- Some ser;
            ser
        | _ -> raise (AttributeCodec "Empty ClassPtvars")
    member this.getValue() = match slopt, seropt with 
        | Some sl, _ -> sl
        | _, Some ser -> 
            let sl = ClassPtvars.decodeString(ser)
            slopt <- Some sl;
            sl
        | _ -> raise (AttributeCodec "Empty ClassPtvars")


type ClassParamKinds(_klopt: tKind list option, _seropt:string option) = 
    inherit DcilAttribute()
    let mutable klopt = _klopt
    let mutable seropt = _seropt 
    new(kl) = ClassParamKinds(Some kl, None)
    new(ser) = ClassParamKinds(None, Some ser)
    override this.attrName = "ClassParamKinds"
    static member thisType = ClassParamKinds(None, None).GetType()
    static member fullTypeName = ClassParamKinds.thisType.FullName
    static member decode(attrs:ILAttributes) =
        match ClassParamKinds.decodeData(attrs, ClassParamKinds.fullTypeName) with 
            | None -> ClassParamKinds([])
            | Some ser -> ClassParamKinds(Some(ClassParamKinds.decodeString(ser)), Some ser)
    static member decode(tt:System.Type) =
        if Attribute.IsDefined(tt, ClassParamKinds.thisType) 
        then Attribute.GetCustomAttribute(tt, ClassParamKinds.thisType) :?> ClassParamKinds
        else ClassParamKinds([])         
    static member decodeString(ser) : tKind list =
      match deserialize_attribute ser with
      | AttribAst.AttrKinds kl -> kl
      | _ -> raise (AttributeCodec "Did not serialize kind list")
    override this.getSerialForm() = match seropt, klopt with 
        | Some ser, _ -> ser
        | _, Some kl -> 
            let ser = serialize_attribute (AttribAst.AttrKinds kl) size_kinds in
            seropt <- Some ser;
            ser
        | _ -> raise (AttributeCodec "Empty ClassParamKinds")
    member this.getValue() = match klopt, seropt with 
        | Some kl, _ -> kl
        | _, Some ser -> 
            let kl = ClassParamKinds.decodeString(ser)
            klopt <- Some kl;
            kl
        | _ -> raise (AttributeCodec "Empty ClassParamKinds")

type MethodParamTypes(_tlopt : tVar<tType> list option, _seropt:string option) =
    inherit DcilAttribute()
    let mutable tlopt = _tlopt
    let mutable seropt = _seropt 
    new(tl) = MethodParamTypes(Some tl, None)
    new(ser) = MethodParamTypes(None, Some ser)
    override this.attrName = "MethodParamTypes"
    static member fullTypeName = MethodParamTypes(None, None).GetType().FullName
    static member decode(attrs:ILAttributes, defs:tVar<tType> list) = 
        match DcilAttribute.decodeData(attrs, MethodParamTypes.fullTypeName) with 
            | None -> MethodParamTypes(defs)
            | Some ser -> MethodParamTypes(Some (MethodParamTypes.decodeString(ser, defs)), Some ser)
    static member decodeString(ser, defs:tVar<tType> list) =
        let r:aType list = DcilAttribute.deserialize ser
        let x = (defs, r) 
        Attribs.CustomAttr.fromCompactRepr(x)
    override this.getSerialForm() = match seropt, tlopt with 
        | Some ser, _ -> ser
        | _, Some tl -> 
            let ser = to_b64(Attribs.CustomAttr.toCompactRepr(tl)) in
            seropt <- Some ser;
            ser
        | _ -> raise (AttributeCodec "Empty MethodParamTypes")
    member this.getValue(defs) = match tlopt, seropt with 
        | Some tl, _ -> tl
        | _, Some ser -> 
            let tl = MethodParamTypes.decodeString(ser,defs)
            tlopt <- Some tl;
            tl
        | _ -> raise (AttributeCodec "Empty MethodParamTypes")
    member this.getValue() = match tlopt with 
        | Some v -> v
        | _ -> raise (AttributeCodec "Empty MethodParamTypes")


type MethodReturnType(_topt : tType option, _seropt:string option) =
    inherit DcilAttribute()
    let mutable topt = _topt
    let mutable seropt = _seropt 
    new(t) = MethodReturnType(Some t, None)
    new(ser) = MethodReturnType(None, Some ser)
    override this.attrName = "MethodReturnType"
    static member fullTypeName = MethodReturnType(None, None).GetType().FullName
    static member decode(attrs:ILAttributes, def:tType) = 
        match DcilAttribute.decodeData(attrs, MethodReturnType.fullTypeName) with 
            | None -> MethodReturnType(def)
            | Some ser -> MethodReturnType(Some (MethodReturnType.decodeString(ser, def)), Some ser)
    static member decodeString(ser, def:tType) = decode_tType ser def
    override this.getSerialForm() = match seropt, topt with 
        | Some ser, _ -> ser
        | _, Some t ->
            let ser = encode_tType t
            seropt <- Some ser;
            ser
        | _ -> raise (AttributeCodec "Empty MethodReturnType")
    member this.getValue(def) = match topt, seropt with 
        | Some t, _ -> t
        | _, Some ser -> 
            let t = MethodReturnType.decodeString(ser,def)
            topt <- Some t;
            t
        | _ -> raise (AttributeCodec "Empty MethodReturnType")
    member this.getValue() = match topt with 
        | Some v -> v
        | _ -> raise (AttributeCodec "Empty MethodReturnType")

type FieldDeclType(_topt : tType option, _seropt:string option) =
    inherit DcilAttribute()
    let mutable topt = _topt
    let mutable seropt = _seropt 
    new(t) = FieldDeclType(Some t, None)
    new(ser) = FieldDeclType(None, Some ser)
    override this.attrName = "FieldDeclType"
    static member thisType = FieldDeclType(None, None).GetType()
    static member fullTypeName = FieldDeclType.thisType.FullName
    static member decode(attrs:ILAttributes, def:tType) = 
        match DcilAttribute.decodeData(attrs, FieldDeclType.fullTypeName) with 
            | None -> FieldDeclType(def)
            | Some ser -> FieldDeclType(Some (FieldDeclType.decodeString(ser, def)), Some ser)
    static member decode(fi:System.Reflection.FieldInfo, def:tType) = 
         try 
            Attribute.GetCustomAttribute (fi, FieldDeclType.thisType) :?> FieldDeclType
         with _ -> FieldDeclType(def)
    static member decodeString(ser, def:tType) = decode_tType ser def
    override this.getSerialForm() = match seropt, topt with 
        | Some ser, _ -> ser
        | _, Some t ->
            let ser = encode_tType t
            seropt <- Some ser;
            ser
        | _ -> raise (AttributeCodec "Empty FieldDeclType")
    member this.getValue(def) = match topt, seropt with 
        | Some t, _ -> t
        | _, Some ser -> 
            let t = FieldDeclType.decodeString(ser,def)
            topt <- Some t;
            t
        | _ -> raise (AttributeCodec "Empty FieldDeclType")
    member this.getValue() = match topt with 
        | Some v -> v
        | _ -> raise (AttributeCodec "Empty FieldDeclType")

type HigherOrderTvars(_vopt:list<int*tVar<tKind>> option, _seropt:string option) =
    inherit DcilAttribute()
    let mutable vopt = _vopt
    let mutable seropt = _seropt 
    new(v) = HigherOrderTvars(Some v, None)
    new(ser) = HigherOrderTvars(None, Some ser)
    override this.attrName = "HigherOrderTvars"
    static member fullTypeName = HigherOrderTvars(None, None).GetType().FullName
    static member decode(attrs:ILAttributes) = 
        match DcilAttribute.decodeData(attrs, HigherOrderTvars.fullTypeName) with 
            | None -> HigherOrderTvars([])
            | Some ser -> HigherOrderTvars(Some (HigherOrderTvars.decodeString(ser)), Some ser)
    static member decodeString(ser) =
      match deserialize_attribute ser with
      | AttribAst.AttrHoTvar htvs -> htvs
      | _ -> raise (AttributeCodec "Could not decode higher order tvars")
    override this.getSerialForm() = match seropt, vopt with 
        | Some ser, _ -> ser
        | _, Some v -> 
            let ser = serialize_attribute (AttribAst.AttrHoTvar v) size_hotvars in
            seropt <- Some ser;
            ser
        | _ -> raise (AttributeCodec "Empty HigherOrderTvars")
    member this.getValue(def) = match vopt, seropt with 
        | Some v, _ -> v
        | _, Some ser -> 
            let v = HigherOrderTvars.decodeString(ser)
            vopt <- Some v;
            v
        | _ -> raise (AttributeCodec "Empty HigherOrderTvars")
    member this.getValue() = match vopt with 
        | Some v -> v
        | _ -> raise (AttributeCodec "Empty HigherOrderTvars")

type ClassKind(_kopt:tKind option, _seropt:string option) =
    inherit DcilAttribute()
    let mutable kopt = _kopt
    let mutable seropt = _seropt
    new(k) = ClassKind(Some k, None)
    new(s) = ClassKind(None, Some s)
    override this.attrName = "ClassKind"
    static member fullTypeName = ClassKind(None, None).GetType().FullName
    static member decode(attrs:ILAttributes) = 
        match DcilAttribute.decodeData(attrs, ClassKind.fullTypeName) with 
            | None -> ClassKind(TKind_star)
            | Some ser -> ClassKind(Some (ClassKind.decodeString(ser)), Some ser)
    static member decodeString(ser) : tKind = decode_tKind ser
    override this.getSerialForm() = match seropt, kopt with 
        | Some ser, _ -> ser
        | _, Some k -> 
            let ser = encode_tKind k in
            seropt <- Some ser;
            ser
        | _ -> raise (AttributeCodec "Empty ClassKind")
    member this.getValue() = match kopt, seropt with 
        | Some k, _ -> k
        | _, Some ser -> 
            let k = ClassKind.decodeString(ser)
            kopt <- Some k;
            k
        | _ -> raise (AttributeCodec "Empty ClassKind")

type NewObjType(_vopt:(uint16 * tTypeConcrete) list option, 
                _vsimpleopt :  (uint16 * (tType list -> tType list * int)) list option, 
                _seropt : string option) = 
    inherit DcilAttribute()
    let mutable vopt = _vopt
    let mutable seropt = _seropt 
    let mutable vsimpleopt = _vsimpleopt
    new(v) = NewObjType(Some v, None, None)
    new(ser) = NewObjType(None, None, Some ser)
    override this.attrName = "NewObjType"
    static member fullTypeName = NewObjType(None, None, None).GetType().FullName
    static member decode(attrs:ILAttributes) = 
        match DcilAttribute.decodeData(attrs, NewObjType.fullTypeName) with 
            | None -> NewObjType([])
            | Some ser -> NewObjType(None, Some (NewObjType.decodeString(ser)), Some ser)
    static member decodeString(ser) = 
        let r:list<uint16 * (list<aType> * int)> = DcilAttribute.deserialize ser 
        let processElt (idx, (tys, numtys)) =
           match tys with
            | [] -> (idx, (fun defs -> defs, numtys))
            | _ -> (idx, (fun defs -> ((List.zip defs tys) |> List.map (fun (default_ty, t) ->
                           match aType2tType (Some default_ty) t with
                           | Some ty -> ty
                           | None -> raise (AttribConvertError "could not get type")), 
                          numtys)))
        List.map processElt r
    override this.getSerialForm() = match seropt, vopt with 
        | Some ser, _ -> ser
        | _, Some v -> 
            let ser = to_b64(Attribs.CustomAttr.toCompactRepr(v)) in
            seropt <- Some ser;
            ser
        | _ -> raise (AttributeCodec "Empty NewObjType")
    member this.getValueSimple() = 
        match vsimpleopt with 
          | Some v -> v
          | _ -> 
              match vopt, seropt with 
                | Some v, _ -> this.simplify v
                | _, Some ser -> 
                    let v = NewObjType.decodeString(ser)
                    vsimpleopt <- Some v;
                    v
                | _ -> raise (AttributeCodec "Empty NewObjType")
    member this.simplify(v) = 
        List.map (fun (i, (cname, _kinds, args, _ext)) -> 
                    let tys, tyvals = getTys args, getVals args in
                    (i, (fun _ -> tys, List.length tyvals))) v

type TypeInstantiation(_vopt:(uint16 * tType) list option, 
                       _vsimpleopt: (uint16 * (tType -> tType)) list option,
                       _seropt:string option) = 
    inherit DcilAttribute()
    let mutable vopt = _vopt
    let mutable vsimpleopt = _vsimpleopt
    let mutable seropt = _seropt 
    new(v) = TypeInstantiation(Some v, None, None)
    new(ser) = TypeInstantiation(None, None, Some ser)
    override this.attrName = "TypeInstantiation"
    static member fullTypeName = TypeInstantiation(None, None, None).GetType().FullName
    static member decode(attrs:ILAttributes) = 
        match DcilAttribute.decodeData(attrs, TypeInstantiation.fullTypeName) with 
            | None -> TypeInstantiation([])
            | Some ser -> TypeInstantiation(None, Some (TypeInstantiation.decodeString(ser)), Some ser)
    static member decodeString(ser) = 
      let getType aty default_ty =
        match Attribs.aType2tType (Some default_ty) aty with
        | Some t -> t
        | None -> raise (AttributeCodec "no type") in
        let r:((uint16 * aType) list) = DcilAttribute.deserialize ser 
        r |> List.map (fun (idx, aty) -> (idx, getType aty))
    override this.getSerialForm() = match seropt, vopt with 
        | Some ser, _ -> ser
        | _, Some v -> 
            let ser = to_b64(Attribs.CustomAttr.toCompactRepr(v)) in
            seropt <- Some ser;
            ser
        | _ -> raise (AttributeCodec "Empty TypeInstantiation")
    member this.getValueSimple() = match vsimpleopt with 
        | Some v -> v
        | _ -> match vopt, seropt with 
                | Some v, _ -> this.simplify v
                | _, Some ser -> 
                    let v = TypeInstantiation.decodeString(ser)
                    vsimpleopt <- Some v;
                    v
                | _ -> raise (AttributeCodec "Empty TypeInstantiation")
    member this.simplify(v) : (uint16 * (tType -> tType)) list = 
        v |> List.map (fun (i, t) -> (i, fun _ -> t))

type ExternMethods(_vopt:tExternMethodDecl list option, _seropt:string option) = 
    inherit DcilAttribute()
    let mutable vopt = _vopt
    let mutable seropt = _seropt 
    new(v) = ExternMethods(Some v, None)
    new(ser) = ExternMethods(None, Some ser)
    override this.attrName = "ExternMethods"
    static member fullTypeName = ExternMethods(None, None).GetType().FullName
    static member decode(attrs:ILAttributes) = 
        match DcilAttribute.decodeData(attrs, ExternMethods.fullTypeName) with 
            | None -> ExternMethods([])
            | Some ser -> ExternMethods(Some (ExternMethods.decodeString(ser)), Some ser)
    static member decodeString(ser) : tExternMethodDecl list = DcilAttribute.deserialize ser
    override this.getSerialForm() = match seropt, vopt with 
        | Some ser, _ -> ser
        | _, Some v -> 
            let ser = to_b64(Attribs.CustomAttr.toCompactRepr(v)) in
            seropt <- Some ser;
            ser
        | _ -> raise (AttributeCodec "Empty ExternMethods")
    member this.getValue(def) = match vopt, seropt with 
        | Some v, _ -> v
        | _, Some ser -> 
            let v = ExternMethods.decodeString(ser)
            vopt <- Some v;
            v
        | _ -> raise (AttributeCodec "Empty ExternMethods")
    member this.getValue() = match vopt with 
        | Some v -> v
        | _ -> raise (AttributeCodec "Empty ExternMethods")

