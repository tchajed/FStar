#light "off"
module Microsoft.FStar.Runtime.ProcessILUtils

open Microsoft.FStar.AttribAst
open Microsoft.FStar.Runtime.ProcessILEnv
open Microsoft.FStar.Runtime.Utils

open Microsoft.FSharp.Compiler.AbstractIL
open Microsoft.FSharp.Compiler.AbstractIL.BinaryReader
open Microsoft.FSharp.Compiler.AbstractIL.BinaryWriter
open Microsoft.FSharp.Compiler.AbstractIL.IL

open Microsoft.FStar
open Microsoft.FStar.Target
open Microsoft.FStar.TargetUtil
open Microsoft.FStar.Util

(****************************************)
(* Converting ints to the right things. *)
(****************************************)
let convertValInts ty v =
  let convertInt (ty : tType) (c : Sugar.sconst) : Sugar.sconst =
    match ty with
    | TType_name ((["Prims"; "bool"], TKind_star), None) ->
      (match c with
      | Sugar.Const_int32 0 -> Sugar.Const_bool false
      | Sugar.Const_int32 1 -> Sugar.Const_bool true
      | _ -> c)
    | TType_name ((["Prims"; "unit"], TKind_star), None) ->
      (match c with
      | Sugar.Const_int32 0 -> Sugar.Const_unit
      | _ -> c)
    | _ -> c in
  (match v with
  | TVal_constant c -> TVal_constant (convertInt ty c)
  | _ -> v)
let rec convertInts ty exp : tExp =
  (match exp with
  | TExp_val v -> TExp_val (convertValInts ty v)
  | TExp_let (v, e, b, ti) -> TExp_let (v, e, convertInts ty b, ti)
  | TExp_isinst (v, pats, def, instty) ->
    let convert_pat (cname, ks, pats, isGADT, exp) = (* !! *)
      (cname, ks, pats, isGADT, convertInts ty exp) in (* !! *)
      TExp_isinst (v, List.map convert_pat pats, convertInts ty def, instty)
  | TExp_cond (c, te, tf) ->
    TExp_cond (c, convertInts ty te, convertInts ty tf)
  | _ ->  exp)


(* Continuation *)
let getTexp pte =
  match pte with
  | TExp e -> e
  | InstMatch (_e, _vartys) -> raise (Unexpected "naked isinst match")
  | InstBr (_matches, _default) -> raise (Unexpected "naked isinst branch")

(*********************)
(* Expression stack. *)
(*********************)
let empty_estack = []
(* Manipulate stack. *)
let push_exp (es : expstack) binding = binding::es
let pop_exp es =
  match es with
  | x::xs -> (xs, x)
  | [] -> raise (Unexpected "empty bindings")
let get_args es num_args : expstack * (tValue list) =
  let getVal exp =
    match exp with
    | TExp_val v -> v
    | TExp_name ((var, ty), None) ->
      let var' = String.concat "." var in
        TVal_var (var', ty)
    | _ ->
      Printf.printf "Getting val of: %A\n" exp; raise (Unexpected "non-value") in
  let rec pop_args (curenv, acc) num_left =
    if num_left = 0
      then (curenv, acc)
      else
        let (es', e) = pop_exp curenv in
        let v = getVal e in
          pop_args (es', v::acc) (num_left - 1) in
  let (es', args) = pop_args (es, []) num_args in
    (es', args)

let empty_genericstack = []
let add_types gs tys = gs@tys
let get_generic_arg (gs : genericstack) i =
  try gs.Item(i) (* (List.rev gs).Item (i) *)
  with _ ->
    Printf.printf "Current generic args: %A\n" gs;
    raise (Unexpected "generic arg index")

(******************************)
(* IL processing environment. *)
(******************************)
let (default_kont : mkont) = fun (e, _ty) _m -> e

(* Symbol generation. *)
let cur_sym = ref 0
let gensym () =
  let cursym = !cur_sym in
    cur_sym := !cur_sym + 1;
    "ilgen_gen_sym_" + cursym.ToString() 

let set_mod_name (env : procenv) (name : string) =
  { env with modname = name }

let set_field_type env fieldname ftype =
  Hashtbl.add env.field_types fieldname ftype
let get_field_type env fieldname : tType option =
  try Some (Hashtbl.find env.field_types fieldname)
  with _ ->
    Printf.printf "Missing field: %A\n" fieldname;
    None

(* Labelled code blocks. *)
let add_labelled_exp
  (menv : methodenv) (label : ILCodeLabel)
  (e : (procenv * methodenv -> ptExp) * tType)
  : unit = Hashtbl.add menv.lblocks label e
let get_labelled_exp (penv, menv) (label : ILCodeLabel)
  : (procenv * methodenv -> ptExp) * tType=
  try Hashtbl.find menv.lblocks label
  with Not_found ->
    Printf.printf "Label %A not found\n%A\n" label menv;
    raise (Unexpected "label not found")

(* Manipulate locals. *)
let add_num_locals menv numlocs = { menv with numlocals = numlocs }
let is_local_index menv idx = idx < menv.numlocals
let add_locals menv (localtypes : tVar<tType> list) =
  let num = List.length localtypes in
  { menv with localTypes = localtypes;
              locals = Array.create num ("dl", false, None) }
let get_local_type menv (idx : int) : tType =
  try snd (menv.localTypes.Item (idx))
  with _ ->
    Printf.printf "Could not get local type %d\n" idx;
    raise (Unexpected "indexing local out of bounds")
let lookup_local_by_name menv (varname : string) : tExp option =
  try let _, _, e = Array.find (fun (v, hasty, e) -> v.Equals(varname)) menv.locals in e
  with Not_found -> None

let store_local menv (idx : int) (has_ty : bool) (e : tExp option)
  : tVar<tType>  =
  try let (var, ty) = menv.localTypes.Item (idx) in
      let varname = if var.Equals("dl") then gensym () else var in
        Array.set menv.locals idx (varname, has_ty, e);
        (varname, ty)
  with _ ->
    Printf.printf "Could not store local %d\n" idx;
    raise (Unexpected "indexing local out of bounds")
let get_local menv (idx : int) : string * tType =
  try
    let var, _, _ = Array.get menv.locals idx in
      (var, snd (menv.localTypes.Item (idx)))
  with _ -> raise (Unexpected "indexing locals out of bounds")

let get_local_exp  menv (idx : int) : bool * tExp option =
  try
    let _, hasty, e = Array.get menv.locals idx in (hasty, e)
  with _ -> raise (Unexpected "indexing locals out of bounds")

(* Manipulate locals. *)
let add_obj_types
  menv
  (objtypes : ( (uint16 * (tType list -> tType list * int)) list))
  : unit =
  List.fold
    (fun _ (idx, ty) ->
      Hashtbl.add menv.obj_types idx ty) ()
    objtypes
let lookup_obj_type menv idx =
  try Some (Hashtbl.find menv.obj_types idx)
  with _ -> None

let lookup_tyapp_type menv (idx : uint16) =
  try Some (Hashtbl.find menv.tyapp_types idx)
  with _ -> None
let add_tyapp_types menv tyapp_types =
  List.iter
    (fun (idx, ty) -> Hashtbl.add menv.tyapp_types idx ty)
    tyapp_types

(* Manipulate arguments. *)
let init_args menv newargs = { menv with args = newargs }
let add_args menv newargs = { menv with args = newargs @ menv.args }
let get_arg menv idx =
  try menv.args.Item(idx)
  with _ ->
    Printf.printf "Could not get arg %A\n" idx;
    raise (Unexpected "indexing arg list out of bounds")

(* Class supertypes. *)
let add_superclass_type
  (env : procenv) (cname : tClassName) (ty : tType option) =
  Hashtbl.add env.superclass_types cname ty
let get_superclass_type (env : procenv) (cname : tClassName)
  : tType option =
  try Hashtbl.find env.superclass_types cname
  with :? System.Collections.Generic.KeyNotFoundException -> None

(* Initializers. *)
let add_static_def
  (env : procenv) (fname : string) (e : tExp) (t : tType option)
  : unit =
  Hashtbl.add env.sfields fname (e, t)
let get_static_def (env : procenv) (fname : string)
  : tExp option =
  try Some (fst (Hashtbl.find env.sfields fname))
  with Not_found -> None
let get_static_type (env : procenv) (fname : string)
  : tType option =
  try snd (Hashtbl.find env.sfields fname)
  with Not_found -> None
  
let add_externs (env : procenv) (externs : list<tExternMethodDecl>) =
  List.iter
    (fun {extref=e; methodname=mn; formalargs=_args; ret=_rt} ->
      Hashtbl.add env.extern_methods mn e)
    externs
let get_extern (env : procenv) (methodname : string) =
  try Hashtbl.find env.extern_methods methodname
  with Not_found ->
    Printf.printf "Extern not found: %s\n" methodname;
    raise (Unexpected "missing extern")

(* This seems to do some kind of substitution of locals.
   Not sure why it's needed. *)
let rec replace_exp_locals menv (e : tExp) : tExp =
  match e with
  | TExp_val v -> TExp_val (replace_value_locals menv v)
  | TExp_name ((n, ty), extref) ->
    TExp_name ((n, replace_type_locals menv ty), extref)
  | TExp_ldfld (v, fref) -> TExp_ldfld (replace_value_locals menv v, fref)
  | TExp_call (objv, vals, mref) ->
    TExp_call
      ( replace_value_locals menv objv
      , List.map (replace_value_locals menv) vals
      , mref (* TODO *) )
  | TExp_extern_call (extref, mref, vals) ->
    TExp_extern_call (extref, mref, List.map (replace_value_locals menv) vals)
  | TExp_let ((v, ty), e, body, infer) ->
    TExp_let
      ( (v, replace_type_locals menv ty)
      , replace_exp_locals menv e
      , replace_exp_locals menv body
      , infer )
  | TExp_isinst (obj, lst, default_exp, ty) -> e (* TODO *)
  | TExp_cond (ce, et, ef) ->
    TExp_cond
      ( replace_exp_locals menv ce
      , replace_exp_locals menv et
      , replace_exp_locals menv ef)
  | TExp_primop (op, vals) ->
    TExp_primop (op, List.map (replace_value_locals menv) vals)
  | TExp_ascribed (e, ty) ->
    TExp_ascribed (replace_exp_locals menv e, replace_type_locals menv ty)
  | TExp_bot -> TExp_bot

and replace_value_locals menv (v : tValue) : tValue =
  match v with
  | TVal_var (var, ty) ->
    Printf.printf "val var %s\n" var;
    let ty' = replace_type_locals menv ty in
    let v' = TVal_var (var, ty') in
      (try match lookup_local_by_name menv var with
          | Some e ->
            (match e with
            | TExp_val value -> Printf.printf "Replacing %s\n" var; value
            | _ -> v)
          | None -> v'
       with _ -> v')
  | TVal_obj (tc, vals) ->
    TVal_obj
      ( replace_ctype_locals menv tc
      , List.map (replace_value_locals menv) vals )
  | TVal_constant _ -> v
  | TVal_ldfld (objv, fref) -> TVal_ldfld (replace_value_locals menv objv, fref)

and replace_type_locals menv ty =
  match ty with
  | TType_fun (def, t1, t2) ->
    TType_fun (def, replace_type_locals menv t1, replace_type_locals menv t2)
  | TType_concrete tc -> TType_concrete (replace_ctype_locals menv tc)
  | _ -> ty
and replace_ctype_locals menv (cname, kinds, args, extref) =
  ( cname, kinds
  , List.map (function |Targ targ -> Targ(replace_type_locals menv targ)
                       | Varg varg -> Varg(replace_value_locals menv varg)) args
  , extref)
  
