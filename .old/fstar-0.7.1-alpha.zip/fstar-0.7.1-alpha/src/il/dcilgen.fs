(*
  Runtime utility functions.
*)
module Microsoft.FStar.Runtime.DcilGen

open Microsoft.FStar
open Microsoft.FStar.Target
open Microsoft.FStar.Runtime.Utils
open Microsoft.FStar.Util

open System
open System.IO
open System.Reflection

open Microsoft.FSharp.Compiler.AbstractIL
open Microsoft.FSharp.Compiler.AbstractIL.BinaryReader
open Microsoft.FSharp.Compiler.AbstractIL.BinaryWriter
open Microsoft.FSharp.Compiler.AbstractIL.IL

let module_map = [  ]
let get_dll_name mod_name =
  try List.assoc mod_name module_map with Not_found -> mod_name

let find_dll_filename n = 
    let dirs = [System.AppDomain.CurrentDomain.SetupInformation.ApplicationBase;
                (Options.get_fstar_home())^"/bin/"] in
    let rec aux = function 
       | dir::dirs -> 
            let fn = dir ^ n in
            let dll = fn ^ ".dll" in
            if (File.Exists dll) 
            then Some dll 
            else
                let exe = fn ^ ".exe" in 
                if File.Exists exe then Some exe
                else aux dirs
       | [] -> None in
    aux dirs

let absil_reader mod_name : ILModuleReader = 
  let dll_name = get_dll_name mod_name in
  let filename = match find_dll_filename dll_name with 
    | Some fn -> fn
    | None -> raise (Unexpected ("Could not find module: " ^ mod_name)) in
  let readerOptions =
        { pdbPath = None
        ; ilGlobals = mk_ILGlobals ecma_mscorlib_scoref None
        ; optimizeForMemory = false } in
    try OpenILModuleReader filename readerOptions
    with _ -> raise (Unexpected ("Could not file module: " ^ mod_name)) 

let system_dll m = List.mem m ["FSharp.Core"; "mscorlib"]

(* Reads a module and its dependences in order to a list of AbsIL modules *)
type arec = {aname:string; moddef:ILModuleDef; adeps:list<string>}
let cmp_arec a1 a2 = 
    if List.mem a1.aname a2.adeps then -1
    else if List.mem a2.aname a1.adeps then 1
    else String.Compare(a1.aname, a2.aname)

let mod_name_to_absil mod_name : list<ILModuleDef> = 
    let rec aux out mod_name =
        if out |> List.exists (fun m -> m.aname = mod_name) then out
        else 
            let mreader = absil_reader mod_name in
            let deps = 
                mreader.ILAssemblyRefs |> List.map (fun x -> x.Name) |>
                List.filter (fun x -> not (system_dll x)) in 
            let arec = {aname=mod_name; moddef=mreader.ILModuleDef; adeps=deps} in
               deps |> List.fold_left (fun out dep -> aux out dep) (arec::out) in
    let all = aux [] mod_name in 
    List.sortWith cmp_arec all |> List.map (fun arec -> arec.moddef)

let mod_name_to_dcil mod_name = 
    let ilmods = mod_name_to_absil mod_name in 
    ProcessIL.absil_mods_to_dcil ilmods

let tc_module mod_name = 
    let modules = mod_name_to_dcil mod_name in 
    let _ = 
        modules |> List.fold_left (fun headers m -> 
            let mclasses = TargetChecker.checkModule headers m in
            headers@mclasses) [Target.predefined] in
      modules

let rec read_module_to_dcil (t's : targetmodules) (mod_name : string)
  : tModule =
  Printf.printf "Reading module to DCIL: %s\n" mod_name;
  (* HACK *)
  let approp_dlls =
    new Set<string> (["CCA"; "Prims"; "ProofLib"; "CryptoLib"; "DomExample"; "Defs"; "Server"; "Client"; "Pickle"]) in

  let dll_name = get_dll_name mod_name in
  let ilcontents = absil_reader mod_name in 
  let (ilmod : ILModuleDef) = ilcontents.ILModuleDef in
  let (assembly_ref_names : string list) =
    List.map (fun (x : ILAssemblyRef) -> x.Name) ilcontents.ILAssemblyRefs in
  let (dcil_dep_names : string list) =
    List.filter
      (fun x ->
        (approp_dlls.Contains(x)) && (not (x.Equals(dll_name))))
      assembly_ref_names in

  (* Get new set of modules. *)
  let included_modules =
    List.fold
      (fun curmods cur_dcil_dep ->
        match get_module t's cur_dcil_dep with
        | Some m -> m::curmods
        | None ->
          let curmod = read_module t's cur_dcil_dep in
            curmod::curmods)
      [] dcil_dep_names in
  let new_modules = ProcessIL.il2target included_modules ilmod in
  
    (* TODO: Look at ilmod.modulCustomAttrs to see whether it's the right kind of assembly. *)
  Printf.printf "Looking for %A\n" mod_name;
  let curmod, other_modules =
    List.partition
      (fun m ->
        match m.name with
        | [mn] -> mn.Equals(mod_name)
        | _ -> false)
      new_modules in
  let m =
    match curmod with
    | [m] -> m
    | _ -> raise Undefined in
  let modules' = other_modules@included_modules in
  let headers =
    Target.predefined::(List.map (fun (m : tModule) -> m.decls) modules') in
  let checkMod m =
    try (let _ = TargetChecker.checkModule headers m in ())
    with e ->
      ((try
          let refmod, _ = read_module_cache mod_name in
          Printf.printf "\n\nREFERENCE MODULE:\n";
          PrettyTarget.printModule refmod;
        with _ -> ());
       Printf.printf "\n\nACTUAL MODULE:\n";
       PrettyTarget.printModule m; 
       Printf.printf "TargetChecker failed with %A\n" e; raise e) in
   (*
    let refmod, _ = read_module_cache mod_name in
    Printf.printf "\n\nREFERENCE MODULE:\n";
    PrettyTarget.printModule refmod;
    Printf.printf "\n\nACTUAL MODULE:\n";
    PrettyTarget.printModule m; *)
    Printf.printf "Checking %A with dependencies\n%A\n" m.name (List.map (fun m -> m.name) modules');
    checkMod m;
    m

(* Reads a module somewhere off disk. *)
and read_module (t's : targetmodules) (mod_name : string) : tModule =
  match get_module t's mod_name with
  | Some m -> m
  | None ->
    if ProcessIL.is_builtin mod_name
    then
      let m, _env = read_module_cache mod_name in
      (* let m' = Qname.processModuleDecl m in *)
        add_module t's mod_name m; m
    else
      let m' = read_module_to_dcil t's mod_name in
        add_module t's mod_name m'; m'

let read_mod_wrapper (mod_name) = read_module (Hashtbl.create 10) mod_name

(* This function returns a list of modules and external references. *)
let rec process_includes
  (t's : targetmodules)
  (includes : depinfo) (* This is a set of initial includes that are mentioned. *)
  : tModule list (* tClassDecl list * tExternMethodDecl list * tStaticFieldDecl list *) =
  let default_externs = [ "Prims"; "ProofLib" ] in

  (* Returns classes that are not part of the default externally defined
     classes. *)
  let filter_externs classes =
    Set.filter
      (fun ((mname, _cname) : tIdent * tIdent) ->
        (not (List.exists (fun dn -> dn.Equals(mname)) default_externs)))
      classes in
  let is_extern_module mname =
    List.exists (fun n -> n.Equals(mname)) default_externs in
  let add_class (m : Map<tIdent, tIdent list>) mn cname =
    match m.TryFind (mn) with
      | Some c's -> m.Add (mn, cname::c's)
      | None -> m.Add (mn, [cname]) in

  (* Given a set of dependencies as a (module name, class name) list, traverses
     the classes to get the classes those depend on. *)
  let get_cur_dependencies (t's : targetmodules) (include_lst : depinfo) : depinfo =
    (* Takes an included module and a list of classes in the module and returns
        a list of modules/classes it depends on, including the classes in the
       original list. *)
    let rec get_module_includes
      (cur_includes : depinfo) (inc_mod : tIdent) (inc_classes : Set<tIdent>)
      : depinfo =
      let cur_mod = read_module t's inc_mod in
      (* Process external definitions. *)
      let ext_includes =
          Hashtbl.fold
            (fun _ (curclass : tClassDecl) (acc : depinfo) ->
              try let modname, classname = split_name curclass.name in
                  add_depinfo acc modname classname
              with _ -> acc) cur_mod.externs cur_includes in
      let stdep = (Qname.getCDeclDepends cur_mod.modCdecl) >> (fun () -> 

      (* Get transitive closures of all classes we depend on here. *)
      let decls = Util.hashtbl_as_list cur_mod.decls in 
      stmap decls (fun (_, cdecl:tClassDecl) -> 
         let mname, cname = split_name cdecl.name in
           if contains_dep cur_includes mname cname
           then Qname.getCDeclDepends cdecl
           else ret ())) in
      let _, dep = Util.runState {Qname.curmod=None; Qname.di=ext_includes} stdep in 
        dep.di in

    (* Gets the current list of included modules in a class. *)
    let get_cur_includes (cur_includes : depinfo) : depinfo =
      Map.fold get_module_includes cur_includes cur_includes in
      
    let orig_depends = ref include_lst in
    let isDone = ref false in
    (while not !isDone do
        let new_depends = get_cur_includes !orig_depends in
        (if new_depends.Equals(!orig_depends)
            then isDone := true
            else ());
        orig_depends := new_depends);
    !orig_depends in
       
  let get_transitive_dependencies
    (t's : targetmodules) (include_lst : depinfo) : depinfo =
    let orig_depends = ref include_lst in
    let isDone = ref false in
      (while not !isDone do
        let new_depends = get_cur_dependencies t's !orig_depends in
        (if new_depends.Equals(!orig_depends)
          then isDone := true
          else ());
        orig_depends := new_depends);
      !orig_depends in

  (**************************************)
  (* Get module definitions to pull in. *)
  (**************************************)
  let get_defs
    (t's : targetmodules)
    (inc_classes : depinfo)
    (modules : tModule list)
    (mname : tIdent)        (* Current module we're looking at. *)
    (classes : Set<tIdent>) (* Classes we want to pull from current module. *)
    : tModule list (* tClassDecl list * tExternMethodDecl list * tStaticFieldDecl list *) =
    if ProcessIL.is_builtin mname
      then modules
      else
      (*
        let dll_name = get_dll_name mname; 
        (* Delete DLL corresponding to current module. *)
        
        (try
          Printf.printf "\nDeleting %s\n" ((get_fstar_home()) + "\\bin\\" + dll_name + ".dll");
          File.Delete ((get_fstar_home()) + "\\bin\\" + dll_name + ".dll");
          raise Undefined
         with e ->
          Printf.printf "failed to delete: %A\n" e; raise Undefined); *)
        (* Get class definitions. *)
        (*
        let classdefs =
            Hashtbl.fold
              (fun _ (cdecl : tClassDecl) acc ->
                let (mn, cn) = split_name cdecl.name in
                if (contains_dep inc_classes mn cn)
                then cdecl::acc else acc) inc_mod.decls [] (* cur_mod,modCDecl *) in *)
        (read_module t's mname)::modules in
    (*
    
    (* Get class definitions of classes we want. *)
    if is_extern_module mname
      then ( def_classes, extern_defs, sfields )
      else
        (* Delete DLL corresponding to current module. *)
        Printf.printf "Deleting %s\n" mname;
        File.Delete ((get_fstar_home()) + mname + "dll");
        (* Get class definitions. *)
        let classdefs =
            Hashtbl.fold
              (fun _ (cdecl : tClassDecl) acc ->
                let (mn, cn) = split_name cdecl.name in
                if (contains_dep inc_classes mn cn)
                then cdecl::acc else acc) inc_mod.decls [] (* cur_mod,modCDecl *) in
        (* Return class definitions and external definitions. *)
        ( classdefs @ def_classes
        , inc_mod.externMethods @ extern_defs
        , inc_mod.modCdecl.staticFields @ sfields ) in *)
  
  (* Pull in included modules. *)
  let inc_classes = get_transitive_dependencies t's includes in
  Map.fold (get_defs t's inc_classes) [] inc_classes

(*
  This function builds the final set of modules to write to the DLL.  It
  creates the following modules:
  - Modules corresponding to FStar data types used in the body of this thing.
  - A Pickle module that contains a Pickle class with an entry point method.
    This is the current solution for regenerating the value we are pickling.

  This creates a DLL named Pickle.dll.
*)
let mkPickleDLL
  (cur_name : string)
  (included_modules : depinfo)  (* Names of modules we need to pull in. *)
  (mtype : tType) (mbody : tExp) : byte[] =
  Options.writeAttribs := true;

  let t's = Hashtbl.create 20 in
  let mod_name = cur_name + "Pickle" in

  let included_modules = process_includes t's included_modules in

  (* Define a static method that creates our object. *)
  let tmdecl =
    ( mtype
    , "entry_point"   (* method name *)
    , []              (* type variable list *)
    , []              (* parameter list *)
    , Some mbody      (* method body *) ) in

  let cdecl =
    { visibility = TVis_public
    ; attr = NoAttr
    ; name = [ mod_name; "Entry" ]
    ; namestring = mod_name + ".Entry"
    ; kvars = []  (* !! *)
    ; vars = []
    ; evidences = []
    ; extends = None
    ; fields = []
    ; staticFields = []
    ; methods = [ tmdecl ]
    ; kind = Some TKind_star
    ; externref = None
    ; hasTag = false
    ; tagNum = None} in

  let tmod =
    { name = [mod_name]
    ; extends = None
    ; modCdecl = mkModuleClass mod_name []
    ; decls = createTCdecls [cdecl]
    ; externs = createTCdecls []
    ; entry = None
    ; externMethods = [] } in
  
  (*******************)
  (* Generate a DLL. *)
  (*******************)
  let _ = Printf.printf "Checking modules\n" in
  let add_decls decls curmod = curmod.decls::decls in
  
  (* Read in information for externally defined classes. *)
  let external_includes = [ "Prims"; "ProofLib" ] in
  let header_modules =
    included_modules@
      (List.fold
        (fun acc -> fun (m : string) ->
          try (read_module t's m)::acc with _ -> acc) [] external_includes) in

  let (checked_headers : tCdecls list) =
    List.fold add_decls [Target.predefined] header_modules in
  
  let _ = 
    try TargetChecker.checkModule checked_headers tmod 
    with 
      e -> (PrettyTarget.printModule tmod;
            Printf.printf "TargetChecker failed with %A\n" e;
            raise (Unexpected "TargetChecker failed")) in
  let _ = Printf.printf "Finished checking modules\n" in

  (* Generate CIL. *)
  let _ = Printf.printf "Starting to write to CIL\n" in
  let ilenv = Ilgen.initial_env tmod in
  let env' =
    List.fold
      (fun env_accum -> fun curmod -> Ilgen.extend_env env_accum curmod)
      ilenv header_modules in

  (* Writing the new module to file--but not the one we needed for checking. *)
  (* PrettyTarget.printModule tmod; *)
  let _ = Attribs.reset_attrib_counts () in
  let dll_name =
    if cur_name.Equals("") then Some "Pickle" else Some cur_name in
  Printf.printf "Writing assemblies with DLL name %A\n" dll_name;
  (*
  let _ =
    Printf.printf "PICKLING\n\n";
    List.iter (fun m -> PrettyTarget.printModule m) (included_modules@[tmod]) in *)
  let bytes = Ilgen.writeAssembliesBytes env' (included_modules@[tmod]) dll_name in
    Attribs.print_attrib_size ["Pickle"];
    match bytes with
    | [b] -> b
    | _ -> raise Undefined
    
