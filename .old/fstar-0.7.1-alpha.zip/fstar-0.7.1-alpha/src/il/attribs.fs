﻿module Microsoft.FStar.Attribs

open Microsoft.FStar.AttribAst
open Microsoft.FStar.AttribLex
open Microsoft.FStar.Target
open Microsoft.FStar.TargetUtil
open Microsoft.FStar.PrettyTarget
open Microsoft.FSharp.Compiler.AbstractIL
open Microsoft.FSharp.Compiler.AbstractIL.IL

(* open Microsoft.FStar.AttribLex *)

open System.IO

exception Undefined
exception AttribParseError of string
exception AttribConvertError of string

let isAType t = match t with AType -> true | _ -> false

let mscorlibrefs:ILGlobals = mk_ILGlobals ecma_mscorlib_scoref None

(* Determine whether things need custom attributes. *)
let kind_needs_attrib (k : tKind) : bool =
  match k with
  | TKind_star -> false
  | _ -> true
let rec ctype_needs_attrib ((cname, kinds, args, extref) : tTypeConcrete) =
  match kinds, (getVals args), extref with
  | [], [], None -> List.exists type_needs_attrib (getTys args)
  | _ -> true
and type_needs_attrib (t : tType) : bool =
  match t with
  | TType_index _ -> false
  | TType_var (_v, k) -> kind_needs_attrib k
  | TType_name (_, extref) -> false 
    (* (match extref with *)
    (* | Some _ -> true *)
    (* | None -> false) *)
  | TType_fun (_bv, t1, t2) -> (type_needs_attrib t1) || (type_needs_attrib t2)
  | TType_tfun (_bv, k, ty) -> (kind_needs_attrib k) || (type_needs_attrib ty)
  (* TODO: Figure out if this is actually true. *)
  | TType_dep (_, _) -> true
  | TType_tapp (_t1, _t2) -> true
  (* Some concrete types don't need custom attributes. *)
  | TType_concrete cty -> ctype_needs_attrib cty
  | TType_affine _t -> true
  | TType_refine (_bv, _ty, _formula, _,  _) -> true
  | TType_inferred _ -> true
and val_needs_attrib (v : tValue) : bool =
  match v with
  | TVal_var (v, ty) -> type_needs_attrib ty
  | TVal_obj (tc, vals) -> true (* TODO *)
  | TVal_constant _ -> false
  | TVal_ldfld _ -> false
  | TVal_logic_fun _ -> raise Util.Impos (* TODO: Revisit *)

(******************)
(* Serialization. *)
(******************)
let pickle_tuple ((x, y) : string * string) : string = "(" ^ x ^ ", " ^ y ^ ")" 
let pickle_list (lst : string list) : string = "[" ^ String.concat ", " lst ^ "]"
let pickle_option (ov : 'a option) (picklefun : 'a -> string) =
  match ov with
  | Some s -> PrettyTarget.spr "(Some %s)" (picklefun s)
  | None -> "None"

let pickle_tBvDef _ = raise Undefined
let pickle_tName (tn : tLident) = pickle_list tn
let pickle_tTypeConcrete (classname, kinds, _, maybe_extref) =
  raise Undefined

let pickle_maybe_externref (mext : option<Sugar.externref>) : string =
  match mext with
  | Some _ -> raise Undefined
  | None -> "None"

let rec pickle_tType (ty : tType) =
  match ty with
  | TType_index ui -> PrettyTarget.spr "(TType_index %d)" ui
  | TType_var (v, k) -> PrettyTarget.spr "(TType_var (%s, %s))" v (pickle_tKind k)
  | TType_name ((tn, k), extref) ->
    PrettyTarget.spr "(TType_name (%s, %s) %s)"
      (pickle_tName tn) (pickle_tKind k) (pickle_maybe_externref extref)
  (* of tName<tKind> * option<Sugar.externref> (* type names [for external types] *)  *)
  | TType_fun (maybe_bvd, t1, t2) ->
    PrettyTarget.spr "(TType_fun %s %s %s)"
      (pickle_option maybe_bvd pickle_tBvDef) (pickle_tType t1) (pickle_tType t2)
  | TType_tfun (bvd, k, ty) ->
    PrettyTarget.spr "(TType_tfun %s %s %s)" (pickle_tBvDef bvd) (pickle_tKind k) (pickle_tType ty)
  | TType_dep (ty, v) -> PrettyTarget.spr "(TType_dep %s %s)" (pickle_tType ty) (pickle_tValue v)
  | TType_tapp (t1, t2) ->
    PrettyTarget.spr "(TType_tapp %s %s)" (pickle_tType t1) (pickle_tType t2)
  | TType_concrete tc -> PrettyTarget.spr "(TType_concrete %s)" (pickle_tTypeConcrete tc)
  | TType_affine ty -> PrettyTarget.spr "(TType_affine %s)" (pickle_tType ty)
  | TType_refine (bvdef, ty, formula, str, classtys) -> raise Undefined
  (* of tBvDef * tType * tFormula * string * list<tClassName * list<tType>>  (* x:t{phi} *) *)
  | TType_inferred _ -> raise Undefined
and pickle_tKind (k : tKind) =
  match k with
  | TKind_star -> "star"
  | TKind_affine -> "affine"
  | TKind_erasable -> "erasable"
  | TKind_prop -> "prop"
  (* TODO: Add these to parser. *)
  | TKind_arrow (ty, kind) ->
    "arrow " ^ pickle_tuple (pickle_tType ty, pickle_tKind kind)
  | TKind_karrow (k1, k2) ->
    "karrow " ^ pickle_tuple (pickle_tKind k1, pickle_tKind k2)
  | TKind_var (tvar, _u) ->
    "var " ^ tvar
and pickle_tValue (v : tValue) =
  let pickle_tFieldRef _ = raise Undefined in
  match v with
  | TVal_var (v, ty) -> PrettyTarget.spr "(TVal_var %s)" (pickle_tuple (v, pickle_tType ty))
  | TVal_obj (tc, vals) ->
    PrettyTarget.spr "(TVal_obj %s %s)"
      (pickle_tTypeConcrete tc)
      (pickle_list (List.map pickle_tValue vals))
  | TVal_constant sc -> raise Undefined
  | TVal_ldfld (v, fref) ->
    PrettyTarget.spr "(TVal_ldfld %s %s)" (pickle_tValue v) (pickle_tFieldRef fref)
  | TVal_uvar _ -> raise Undefined
  | TVal_logic_fun _ -> raise Util.Impos (* TODO: Revisit *)


let rec pickle_aType (at : aType) : string =
  let strDef def =
      match def with
      | Some d -> (PrettyTarget.strBvdef d)
      | None -> "N" in
  match at with
  | AType -> "AType"
  (* TODO: Add more things as needed. *)
  | AType_var (tv, tk) ->
    PrettyTarget.spr "(AType_var (%s, %s))" tv (PrettyTarget.strKind tk)
  | AType_name (name, _extref) ->
    PrettyTarget.spr "(AType_name %s )" (PrettyTarget.strTname name)
  | AType_fun (def, t1, t2) ->
    PrettyTarget.spr
      "(AType_fun %s %s %s)" (strDef def) (pickle_aType t1) (pickle_aType t2)
  | AType_tfun (def, k, t) ->
     PrettyTarget.spr
      "(AType_tfun %s %s %s)"
        (PrettyTarget.strBvdef def) (PrettyTarget.strKind k) (pickle_aType t)
  | AType_tapp (t1, t2) ->
    PrettyTarget.spr "(AType_tapp %s %s)" (pickle_aType t1) (pickle_aType t2)
  | AType_concrete (tys, vals, _ext) ->
    let strTypes = String.concat " " (List.map pickle_aType tys) in
    let strVals = String.concat " " (List.map pickle_tValue vals) in
      PrettyTarget.spr "(AType_concrete %s %s)" strTypes strVals
  | AType_concrete_types tys ->
    let strTypes = String.concat " " (List.map pickle_aType tys) in
      PrettyTarget.spr "(AType_concrete_types %s)" strTypes
  | AType_concrete_vals vals ->
    let strVals = String.concat " " (List.map pickle_tValue vals) in
      PrettyTarget.spr "(AType_concrete_vals %s)" strVals
  | AType_all (ks, types) ->
    let strKinds = String.concat " " (List.map PrettyTarget.strKind ks) in
    let strTypes = String.concat " " (List.map pickle_tType types) in
      PrettyTarget.spr "(AType_all %s %s)" strKinds strTypes
  | AType_deparrowSS (def, t1, t2) ->
    PrettyTarget.spr
      "(AType_deparrowSS %s %s %s)" (strDef def) (pickle_aType t1) (pickle_aType t2)
  | AType_deptuple2SS (def, t1, t2) ->
    PrettyTarget.spr
      "(AType_deptuple2SS %s %s %s)" (strDef def) (pickle_aType t1) (pickle_aType t2)
  | AType_tupleUU (t1, t2) ->
    PrettyTarget.spr "(AType_tupleUU %s %s)" (pickle_aType t1) (pickle_aType t2)
  | AType_other tty -> "(AType_other " ^ pickle_tType tty ^ ")"

let pickle_tEvidence (ev : tEvidence) =
  match ev with
  | TEv_val ((var, ty), v) -> "TEv_val " ^ pickle_tuple (pickle_tuple (var, pickle_tType ty), pickle_tValue v)
  | TEv_type ((v, k), ty) -> "TEv_type " ^ pickle_tuple (pickle_tuple (v, pickle_tKind k), pickle_tType ty)

let pickle_attrib (a : attrib) : string =
  let pickle_varty (v, aty) = v ^ ":" ^ pickle_aType aty in
  let pickle_varkind (v, kind) = v ^ ":" ^ pickle_tKind kind in
  let pickle_atype_list atys = pickle_list (List.map pickle_aType atys) in
  match a with
  | AttrType aty -> "AttrType " ^ pickle_aType aty
  | AttrLocVarTypes loc_vars ->
    let pickle_locvar (idx, varty) = pickle_tuple (string_of_int idx, pickle_varty varty) in
    "AttrLocVarTypes " ^ pickle_list (List.map pickle_locvar loc_vars)
  | AttrVarTypes vartys ->
    "AttrVarTypes " ^ pickle_list (List.map pickle_varty vartys)
  | AttrTypes atys -> "AttrTypes " ^ pickle_atype_list atys
  | AttrHoTvar hotvars ->
    let pickle_hotvar (idx, varkind) =
      pickle_tuple (string_of_int idx, pickle_varkind varkind) in
    "AttrHoTvar " ^ pickle_list (List.map pickle_hotvar hotvars)
  | AttrObj objs ->
    let pickle_obj (objidx : uint16, (tys, numtys)) =
      string_of_int (System.Convert.ToInt32 objidx) ^ (pickle_atype_list tys) ^ string_of_int numtys in
    "AttrObj " ^ pickle_list (List.map pickle_obj objs)
  | AttrKind k -> "AttrKind " ^ pickle_tKind k
  | AttrKinds k's -> "AttrKinds " ^ (pickle_list (List.map pickle_tKind k's))
  | AttrEvidences evs ->
    "AttrEvidences " ^ (pickle_list (List.map pickle_tEvidence evs))

(* Converts a tType to a more compact attribute type. *)
let rec tType2aType (tty : tType) : aType =
  match tty with
  | TType_index _ -> AType
  | TType_var (v, k) -> AType_var (v, k)
  | TType_name ((v, k), extref) -> AType_name ((v, k), extref)
  (* When do these kinds of things arise? *)
  | TType_fun (def, t1, t2) -> AType_other tty
  (*
    AType_fun (def, tType2aType t1, tType2aType t2) *)
  | TType_tfun (def, k, ty) ->
    AType_tfun (def, k, tType2aType ty)
  | TType_dep (t, v) -> AType_other tty
  | TType_tapp (t1, t2) -> AType_tapp (tType2aType t1, tType2aType t2)
  | TType_concrete (cname, kinds, args, extref) ->
    let tys, vals = getTys args, getVals args in
    (match cname with
    | ["All"] -> AType_all (kinds, tys)
    | ["DepArrowSS"] ->
      if List.length tys = 2
        then
          (match tys.[1] with
          | TType_fun (def, t1, t2) ->
            AType_deparrowSS (def, tType2aType t1, tType2aType t2)
          | _ -> raise Undefined)
        else raise Undefined
    | ["DepTuple2SS"] ->
      if List.length tys = 2
        then
          (match tys.[1] with
          | TType_fun (def, t1, t2) ->
            AType_deptuple2SS (def, tType2aType t1, tType2aType t2)
          | _ ->
            (* This case is for when we have a type variable. *)
            AType_concrete_types (List.map tType2aType tys))
        else raise Undefined
    | ["Tuple_UU"] ->
      if List.length tys = 2
        then AType_tupleUU (tType2aType tys.[0], tType2aType tys.[1])
        else raise Undefined
    | _ ->
      let tys' =
        let ctys = List.map tType2aType tys in
        if List.forall isAType ctys
          then []
          else ctys in
        (match tys', vals, extref with
        | [], [], None -> AType
        | _ ->
          (match extref with
          | None ->
            (match tys' with
            | [] -> AType_concrete_vals vals
            | _ ->
              (match vals with
              | [] -> AType_concrete_types tys'
              | _ -> AType_concrete (tys', vals, extref)))
          | Some _ -> AType_concrete (tys', vals, extref))))
  | TType_affine _t -> AType_other tty
  | TType_refine _ -> AType_other tty
  | TType_inferred _-> AType_inferred

let rec aType2tType (origty : tType option) (aty : aType) : tType option =
  (* Printf.printf "Attribs: Resolving %A with %A\n" aty origty; *)
  let r =
  match aty with
  | AType -> origty
  | AType_var (v, k) -> Some (TType_var (v, k))
  | AType_name (tn, ext) -> Some (TType_name (tn, ext))
  | AType_fun (def, t1, t2) ->
    (match origty with
    | Some (TType_fun (_origdef, ot1, ot2)) ->
      (match aType2tType (Some ot1) t1, aType2tType (Some ot2) t2 with
      | Some t1', Some t2' -> Some (TType_fun (def, t1', t2'))
      | _, _ -> None)
    | Some _ -> raise (AttribConvertError "bad")
    | None ->
      (* NOTE(JY): Look into this special case. *)
      (match aType2tType None t1, aType2tType origty t2 with
      | Some t1', Some t2' -> Some (TType_fun (def, t1', t2'))
      | _, _ -> None))
  | AType_tfun (def, k, ty) ->
    (match origty with
    | Some (TType_tfun (_origdef, _k, oty)) ->
      (match aType2tType (Some oty) ty with
      | Some ty' -> Some (TType_tfun (def, k, ty'))
      | None -> None)
    | _ ->
      Printf.printf "attrib type: %A\n" aty;
      Printf.printf "%A\n" origty;
      raise (AttribConvertError "unexpected type"))
  | AType_tapp (t1, t2) ->
    (match origty with
    | Some (TType_tapp (ot1, ot2)) ->
      (match aType2tType (Some ot1) t1, aType2tType (Some ot2) t2 with
      | Some t1', Some t2' -> Some (TType_tapp (t1', t2'))
      | _, _ -> None)
    | _ -> Printf.printf "attrib type: %A\n" aty; Printf.printf "%A\n" origty; raise Undefined)
  | AType_concrete (tys, vals, extref) ->
    (match origty with
    | Some (TType_concrete (cname, k's, origArgs, _ext)) ->
      let origtys, _origvals = getTys origArgs, getVals origArgs in
      let tys' =
        match tys with
        | [] -> origtys
        | _ ->
          List.map
            (fun (origty, aty) ->
              match aType2tType (Some origty) aty with
              | Some t -> t
              | None -> raise (AttribConvertError "expected conversion"))
            (List.zip origtys tys) in
      Some (TType_concrete (cname, k's, (List.map Targ tys') @ (List.map Varg vals), extref))
      (* TODO: Make sure this is okay. *)
    | Some (TType_name ((cname, _ckind), _ext)) ->
      Some (TType_concrete (cname, [], List.map Varg vals, extref))
    | _ -> raise Undefined)
  | AType_concrete_types tys ->
    (match origty with
    | Some (TType_concrete (cname, k's, origArgs, _ext)) ->
      let origtys = getTys origArgs in
      let tys' =
        match tys with
        | [] -> origtys
        | _ ->
          List.map
            (fun (origty, aty) ->
              match aType2tType (Some origty) aty with
              | Some t -> t
              | None -> raise (AttribConvertError "expected conversion"))
            (List.zip origtys tys) in
      Some (TType_concrete (cname, k's, List.map Targ tys', None))
    | Some (TType_name ((cname, _ckind), _ext)) ->
      Some (TType_concrete (cname, [], [], None))
    | _ -> raise Undefined)
  | AType_concrete_vals vals ->
    (match origty with
    | Some (TType_concrete (cname, k's, origArgs, _ext)) ->
      let origtys = getTys origArgs in
      Some (TType_concrete (cname, k's, (List.map Targ origtys)@(List.map Varg vals), None))
      (* TODO: Make sure this is okay. *)
    | Some (TType_name ((cname, _ckind), _ext)) ->
      Some (TType_concrete (cname, [], List.map Varg vals, None))
    | _ -> raise Undefined)
  (* All type *)
  | AType_all (kinds, tys) ->
    Some (TType_concrete (["All"], kinds, List.map Targ tys, None))
  | AType_deparrowSS (def, at1, at2) ->
    (match origty with
    | Some (TType_concrete (["DepArrowSS"], [], [Targ targ; Targ tresult], None)) ->
      (match aType2tType (Some targ) at1, aType2tType (Some tresult) (AType_fun (def, at1, at2)) with
      | Some t1', Some t2' -> Some (TType_concrete (["DepArrowSS"], [], [Targ t1'; Targ t2'], None))
      | _, _ -> raise (AttribConvertError "Unexpected conversion"))
    | _ -> Printf.printf "Not a dep arrow: %A\n" origty; raise Undefined)
  | AType_deptuple2SS (def, at1, at2) ->
    (match origty with
    | Some (TType_concrete (["DepTuple2SS"], [], [Targ targ; Targ tresult], None)) ->
      (match aType2tType (Some targ) at1, aType2tType (Some tresult) (AType_fun (def, at1, at2)) with
      | Some t1', Some t2' -> Some (TType_concrete (["DepTuple2SS"], [], [Targ t1'; Targ t2'], None))
      | _, _ -> None)
    | _ ->
      (match aType2tType None at1, aType2tType None at2 with
      | Some t1', Some t2' ->
        Some
          (TType_concrete
            (["DepTuple2SS"], [], [Targ t1'; Targ(TType_fun (def, t1', t2'))], None))
      | _, _ -> None))
      (* Printf.printf "Not a dep arrow: %A\n" origty; raise Undefined) *)
  | AType_tupleUU (t1, t2) ->
    (match origty with
    | Some (TType_concrete (["Tuple_UU"], [], [Targ ot1; Targ ot2], None)) ->
      (match aType2tType (Some ot1) t1, aType2tType (Some ot2) t2 with
      | Some t1', Some t2' -> Some (TType_concrete (["Tuple_UU"], [], [Targ t1'; Targ t2'], None))
      | _, _ -> None)
    | _ -> Printf.printf "Not a dep arrow: %A\n" origty; raise Undefined)
  | AType_inferred -> Some (TType_inferred (Unionfind.fresh TUvar))
  | AType_other tty -> Some tty in
    (* Printf.printf "Result: %A\n" r; *)
    r

(****************************)
(* Attribute parsing utils. *)
(****************************)
let tryParse (text : string) : AttribAst.attrib option =
  let lb = Microsoft.FSharp.Text.Lexing.LexBuffer<char>.FromString(text) in
  try Some (Microsoft.FStar.AttribPars.customattr Microsoft.FStar.AttribLex.parsetokens lb)
  with e -> None

(****************************************************)
(* Serializing and deserializing custom attributes. *)
(****************************************************)
let size_type = ref 0
let size_evidences = ref 0
let size_kinds = ref 0
let size_hotvars = ref 0
let size_locals = ref 0
let size_methodparams = ref 0
let size_newobj = ref 0
let size_externs = ref 0

(* Attribute profiling. *)
let print_attrib_size modname =
  let total_size =
      !size_type + !size_evidences + !size_kinds + !size_hotvars + !size_locals
    + !size_methodparams + !size_newobj + !size_externs in
    Printf.printf "\n\n***\nAttribute sizes for %s (bytes)\n"
      (PrettyTarget.strLident modname);
    Printf.printf "Evidences: %d\n" !size_evidences;
    Printf.printf "Kinds: %d\n" !size_kinds;
    Printf.printf "Higher-order tvars: %d\n" !size_hotvars;
    Printf.printf "Types (from fields, return types, super class):";
    Printf.printf " %d\n" !size_type;
    Printf.printf "Method params: %d\n" !size_methodparams;
    Printf.printf "Locals: %d\n" !size_locals;
    Printf.printf "New object types: %d\n" !size_newobj;
    Printf.printf "Externs: %d\n" !size_externs;
    Printf.printf "Total attribute size: %d\n" total_size
let reset_attrib_counts () =
  size_type := 0;
  size_evidences := 0;
  size_kinds := 0;
  size_hotvars := 0;
  size_locals := 0;
  size_methodparams := 0;
  size_newobj := 0;
  size_externs := 0

let toCustomElemString (x:byte []) =
  CustomElem_string(Some (System.Convert.ToBase64String x))

let profile f = Profiling.profile f "Attributes"
let maybeSkip () : option<string> = if !Options.writeAttribs then None else Some "" (*[||] *)
let (^^) bopt (f:Lazy<byte[]>) = 
  profile (fun () -> match bopt with Some b -> b | _ -> f.Force())

(* Nik: Can we merge this with dcilattrs.fs?
        Each overload below can be associated with a particular attribute class. 
        See DcilAttrs.Evidence for an example of what I mean. *)
(* Representing custom attributes. *)
type CustomAttr =
  (** ptvars *)
  static member compact2bytes (x : string list) =
    (* maybeSkip () ^^ lazy *)
    if !Options.prettyAttribs
      then Util.serialize_string (String.concat " " x)
      else Util.__temp_dot_net_marshall x
  static member toCompactRepr (x : string list) =
    (* maybeSkip () ^^ lazy *)
    let attrib_repr = CustomAttr.compact2bytes x in
      size_evidences := !size_evidences + attrib_repr.Length;
      CustomAttr.compact2bytes (x)

  (** Local variable decls. *)
  static member compact2bytes ((numlocs, rlst) : int * tVar<aType> list) =
    (* maybeSkip () ^^ lazy *)
    if !Options.prettyAttribs
      then
        Util.serialize_string
          (String.concat " " (List.map (fun (v, at) -> v ^ pickle_aType at) rlst))
      else Util.__temp_dot_net_marshall (numlocs, rlst)

  (** NOTE(JY): What is this? *)
  static member toPrettyCompactRepr ((numlocals, locals) : int * (tVar<tType option> list))
    : byte [] =
    (* maybeSkip () ^^ lazy *)
    let localStr = 
      Util.spr "%d:%s" numlocals 
        (String.concat "^" 
           (List.map
              (fun (v, mty) -> match mty with
                 | Some ty ->(PrettyTarget.strVvar (v, ty) ^ ":" ^ PrettyTarget.strSmallType ty) 
                 | None ->  "") 
              locals))in 
    let attrib_repr = Util.serialize_string localStr in 
      (* CustomAttr.compact2bytes (result : int * (tVar<aType> list)) in *)
      size_locals := !size_locals + attrib_repr.Length;
      attrib_repr

  static member toCompactRepr ((numlocals, locals) : int * (tVar<tType option> list))
    : byte [] =
    (* maybeSkip () ^^ lazy *)
    let locals = List.map (fun (x,t) -> match t with None -> (x, AType) | Some t -> (x, tType2aType t)) locals in 
    let attrib_repr = CustomAttr.compact2bytes ((numlocals, locals) : int * (tVar<aType> list)) in 
      size_locals := !size_locals + attrib_repr.Length;
      attrib_repr
        
  static member fromCompactRepr
    ((locals, (numlocals, clocals)) : tType list * (int * tVar<aType> list))
    : int * tVar<tType> list =
    ( numlocals
    , List.map
        (fun (default_ty, (v, aty)) ->
          match aType2tType (Some default_ty) aty with
          | Some t -> (v, t) | None -> raise Undefined (* TODO *))
        (List.zip locals clocals) )

  (** Method parameters and local types. *)
  static member compact2bytes (atlst : aType list) : byte [] =
    (* maybeSkip () ^^ lazy *)
    if !Options.prettyAttribs
      then Util.serialize_string (String.concat " " (List.map pickle_aType atlst))
      else Util.__temp_dot_net_marshall atlst
  static member toCompactRepr (x : tVar<tType> list)
    (* repr of aType list *) =
    (* maybeSkip () ^^ lazy *)
    (*let r = (List.map (fun (v, ty) -> tType2aType ty) x) in
    let attrib_repr = CustomAttr.compact2bytes r in*)
    let attrib_repr = Util.serialize_string (String.concat "," (List.map (fun v -> (strSmallType (snd v))) x)) in
      size_methodparams := !size_methodparams + attrib_repr.Length;
      attrib_repr
  static member fromCompactRepr
    ((defaults, attr_tys) : tVar<tType> list * aType list)
    : tVar<tType> list =
    match attr_tys with
    | [] -> defaults
    | _ ->
      List.map
        (fun ((vd, td), ta) ->
          match aType2tType (Some td) ta with
          | Some t -> (vd, t) | None -> raise Undefined (* TODO *))
        (List.zip defaults attr_tys)

  (** Higher-order type variables. *)
  (* TODO: Also ptvars? *)
  static member compact2bytes (x : list< int * tVar<tKind> >) : byte [] =
    (* maybeSkip () ^^ lazy *)
    if !Options.prettyAttribs
      then
        Util.serialize_string
          (String.concat " "
            (List.map (fun (i, tvar) -> (string i) ^ PrettyTarget.strTvar tvar) x))
      else Util.__temp_dot_net_marshall x
  static member toCompactRepr (x : list< int * tVar<tKind> >) (* : string *) =
    (* maybeSkip () ^^ lazy *)
    let attrib_repr = CustomAttr.compact2bytes x in
      size_hotvars := !size_hotvars + attrib_repr.Length;
      attrib_repr

  (** New object. *)
  static member compact2bytes (x : (uint16 * (aType list * int)) list)
    : byte [] =
    (* maybeSkip () ^^ lazy *)
    if !Options.prettyAttribs
      then
        let str =
          String.concat " "
            (List.map
              (fun (idx, (tys, numargs)) ->
                string idx ^ string numargs ^ "(" ^
            (String.concat " " (List.map pickle_aType tys)) ^ ")") x) in
          Util.serialize_string (str)
      else Util.__temp_dot_net_marshall x
  (* Um sorry.  This function is kind of ugly. *)
  static member toAType
    (newobj_locals : (uint16 * tTypeConcrete) list)
    : (uint16 * (aType list * int)) list =
    let processElt (idx, (tys, tyvals)) =
      let attrib_tys = List.map tType2aType tys in
        if List.forall isAType attrib_tys
          then (idx, ([], List.length tyvals))
          else (idx, (attrib_tys, List.length tyvals)) in
    let get_ctys_vals acc (idx, cty) =
      let (_cname, _kinds, args, _ext) = cty in
        let tys, tyvals = getTys args, getVals args in
        let tys' =
          if List.exists type_needs_attrib tys then tys else [] in
        match tyvals with
        | [] ->
          (match tys' with
             [] -> acc
            | _ -> (processElt (idx, (tys', tyvals)))::acc)
        | _ -> (processElt (idx, (tys', tyvals)))::acc in
      List.fold get_ctys_vals [] newobj_locals

  static member toCompactRepr
    (lst : (uint16 * tTypeConcrete) list) =
    (* maybeSkip () ^^ lazy *)
    let r = CustomAttr.toAType (lst) in
    (* Profiling. *)
    let attrib_repr = CustomAttr.compact2bytes r in
    size_newobj := !size_newobj + attrib_repr.Length;
      attrib_repr

  (* Nik: Added this for typinst attributes *)
  static member compact2bytes (x : (uint16 * aType) list)
    : byte [] =
    (* maybeSkip () ^^ lazy *)
    if !Options.prettyAttribs
      then
        let str =
          String.concat " "
            (List.map
              (fun (idx, ty) -> 
              string idx ^ "(" ^ pickle_aType ty ^ ")") x) in
          Util.serialize_string (str)
      else Util.__temp_dot_net_marshall x  
  static member toAType
    (tyinst_locals : (uint16 * tType) list)
    : (uint16 * aType) list =
    let processElt (idx, ty) = match tType2aType ty with 
         | AType -> None
         | a -> Some (idx, a) in 
      List.fold_left (fun out elt -> match processElt elt with 
                        | None -> out
                        | Some x -> x::out) [] tyinst_locals |> List.rev   
  static member toPrettyCompactRepr
    (lst : (uint16 * tType) list) =
    (* maybeSkip () ^^ lazy *)
    let attrib_repr = Util.serialize_string(String.concat "," (List.map (fun (i,t) -> spr "%d:%s" i (strSmallType t)) lst)) in
      size_newobj := !size_newobj + attrib_repr.Length;
      attrib_repr 
  static member toCompactRepr
    (lst : (uint16 * tType) list) =
    (* maybeSkip () ^^ lazy *)
    let r = CustomAttr.toAType (lst) in
    let attrib_repr = CustomAttr.compact2bytes r in
      size_newobj := !size_newobj + attrib_repr.Length;
      attrib_repr

  static member compact2bytes x =
    (* maybeSkip () ^^ lazy *)
    if !Options.prettyAttribs
      then Util.serialize_string ("extern!!!!!!!!!!!!!!!!!!!")
      else Util.__temp_dot_net_marshall x
  static member toCompactRepr (x : list<Target.tExternMethodDecl>) =
    (* maybeSkip () ^^ lazy  *)
    let attrib_repr = CustomAttr.compact2bytes x in
      size_externs := !size_externs + attrib_repr.Length;
      attrib_repr

(* General custom attributes. *)
(* let toCustomAttr aname (x:byte []) =  *)
(*   if x.Length = 0 then  *)
(*   else *)
(*     let attr = toCustomElemString x in *)
(*       mk_custom_attribute ecmaILGlobals (aname, *)
(*                                          [mscorlibrefs.typ_String], *)
(*    
                                      [attr], []) *)
let empty_attrs = mk_custom_attrs []   
let toILAttribute attrTref string = 
  let attr = CustomElem_string(Some string) in
  let a = mk_custom_attribute ecmaILGlobals (attrTref,
                                             [mscorlibrefs.typ_String],
                                             [attr], []) in
    a

let toCustomAttrs aname (x:byte []) = 
  if x.Length = 0 then empty_attrs
  else mk_custom_attrs [toILAttribute aname (System.Convert.ToBase64String x)]

let concat_attrs attrs1 attrs2 =
  mk_custom_attrs ((IL.dest_custom_attrs attrs1)@(IL.dest_custom_attrs attrs2))
    
