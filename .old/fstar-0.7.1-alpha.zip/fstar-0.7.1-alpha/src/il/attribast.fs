﻿module Microsoft.FStar.AttribAst

open Microsoft.FStar.Target

type aType =
  | AType (* A reconstructible type. *)
  (* TODO: Add more things as needed. *)
  | AType_var of tVar<tKind>
  | AType_name of tName<tKind> * option<Sugar.externref>
  | AType_fun of option<tBvDef> * aType * aType
  | AType_tfun of tBvDef * tKind * aType
  | AType_tapp of aType * aType
  | AType_concrete of aType list * tValue list
                    * option<Sugar.externref>
  | AType_concrete_types of aType list
  | AType_concrete_vals of tValue list
  (* TODO: Handle extern ref *)
  | AType_all of tKind list * tType list
  | AType_deparrowSS of option<tBvDef> * aType * aType
  | AType_deptuple2SS of option<tBvDef> * aType * aType
  | AType_tupleUU of aType * aType
  | AType_inferred
  | AType_other of tType
and attrib =
  | AttrType of aType
  | AttrLocVarTypes of (int * tVar<aType>) list
  | AttrVarTypes of tVar<aType> list
  | AttrTypes of aType list
  | AttrHoTvar of (int * tVar<tKind>) list
  | AttrObj of (uint16 * (aType list * int)) list
  | AttrKind of tKind
  | AttrKinds of tKind list
  | AttrEvidences of tEvidences
