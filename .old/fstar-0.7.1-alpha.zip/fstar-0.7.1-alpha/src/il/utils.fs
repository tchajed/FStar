(*
  Runtime utility functions.
*)
module Microsoft.FStar.Runtime.Utils

open Microsoft.FStar
open Microsoft.FStar.Target

open System
open System.IO
open System.Reflection
open System.Text.RegularExpressions

(* Defining some exceptions. *)
exception PickleInternalError of string
exception Undefined
exception Unexpected of string
exception Unimplemented of string

let gensym () = Sugar.nng.Apply "rt_" Absyn.dummyRange
let nub list = Util.remove_dups (fun x y -> x=y) list

(* Storing information about dependencies.

   Right now we don't allow storage of anything with an empty module.  To my
   knowledge, the only classes like this are DepArrowSS, DepTuple, etc. *)
type depinfo = Map<tIdent, Set<tIdent>>
let empty_depinfo = new Map<tIdent, Set<tIdent>> ([])
let add_depinfo (d : depinfo) (m : string) (c : string) =
  if m.Equals("")
    then d
    else
      match d.TryFind m with
      | Some classes -> d.Add (m, classes.Add c)
      | None -> d.Add (m, new Set<tIdent>([c]))
let contains_dep (d : depinfo) (m : string) (c : string) : bool =
  match d.TryFind m with
  | Some classes -> classes.Contains (c)
  | None -> false

//No module cache allowed
//(* Module cache. *)
type targetmodules = (string, tModule) Hashtbl.t
let has_module t's mname =
  try let _ = Hashtbl.find t's mname in true
  with _ -> false
let get_module t's mname =
  try Some (Hashtbl.find t's mname)
  with _ -> None
let add_module t's mname tmod = Hashtbl.add t's mname tmod

(* Nik: TODO, remove this *)
let rename (cname : tLident) : tLident =
  match cname with
  | [ "System"; "int32" ] -> [ "Prims"; "int" ]
  (* TODO: Make this less ad hoc. *)
  | [ "System"; something ] -> [ "Prims"; something ]
  | _ -> cname
let split_name (cname : tLident) : tIdent * tIdent =
  try let cname' = rename cname in (cname'.[0], cname'.[1])
  with _ ->
    match cname with
    | ["DepArrowSS"] -> ("", "DepArrowSS")
    | _ -> raise (Unexpected "Class name not in form (module, class)")

(* Making target values into target expressions. *)
let hoist ((e,t):tExp*tType) (body:tValue -> tExp) : tExp = 
  match e with 
    | TExp_val v -> body v
    | _ -> 
        let v = newVvar t in
          TExp_let(v, e, body (TVal_var v), ref true)

let hoistList (et_l:list<tExp*tType>) (body:list<tValue> -> tExp) : tExp = 
  let rec aux vals = function 
    | [] -> body (List.rev vals)
    | (fexp,fty)::tl -> hoist (fexp,fty) (fun fval -> aux (fval::vals) tl) in
    aux [] et_l

(* Make class corresponding to the module. *)
let mkModuleClass mname sfields =
  { visibility = TVis_public
  ; attr = NoAttr
  ; name = [ mname ]
  ; namestring = mname
  ; kvars = []
  ; vars = []
  ; evidences = []
  ; extends = None
  ; fields = []
  ; staticFields = sfields
  ; methods = [ ]
  ; kind = Some TKind_star
  ; externref = None 
  ; hasTag = false
  ; tagNum = None}

(* Nik: Should get rid of the module_cache *)
(* Load the module cache for the given module name. *)
let read_module_cache (mod_name : string) : tModule * Ilgen.env = 
  let (odir : string) =
    match !(Options.outputDir) with
    | Some d -> d
    | None -> "" in
  let cachefile = (Options.get_fstar_home()) + "/bin/." + mod_name +  ".fine.cache" in
  Printf.printf "Reading from module cache: %s\n" cachefile;
  let is = System.IO.File.OpenRead cachefile in
  let formatter =
    new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter() in
  let res = formatter.Deserialize(is) in
  let result =
    match ((unbox res) : (tModule * Ilgen.env) list) with 
    | [(tprelude, ilenv)] -> tprelude, ilenv
    | _ -> failwith "deserialization failed: expected one item" in
    is.Close();
    result

