﻿
module PrettyPrintCoretyping

open System.IO;
open System.Text;
open CoretypingUtil

let prettyName name = "\"" + name + "\""
let prettyBvar = prettyName
let prettyTyname = prettyName
let prettyVlname = prettyName
let prettyCname = prettyName
let prettyIname = prettyName
let prettyBoxname = prettyName
let prettyGvar gv =
  let str = match gv with
    | GV_Bound bvar -> "GV_Bound " + prettyBvar bvar
    | GV_Free fvar -> "GV_Free " + prettyBvar fvar in
  "(" + str + ")"

let prettyBasekind k =
  match k with
    | BK_Comp -> "BK_Comp"
    | BK_Prop -> "BK_Prop"
    | BK_Erase -> "BK_Erase"
    | BK_Afn -> "BK_Afn" 

let rec prettyKind k =
  let str = match k with
    | K_Base bk -> "K_Base " + prettyBasekind bk
    | K_ProdK(bvar, k1, k2) ->
      "K_ProdK " + prettyBvar bvar + " " + prettyKind k1 + " " + prettyKind k2
    | K_ProdT(bvar, t, k2) ->
      "K_ProdT " + prettyBvar bvar + " " + prettyTyp t + " " + prettyKind k2 in
  "(" + str + ")"

and prettyList (prettyOne:'a -> string) (lst: Prims.list<'a>) delimiter =
  match lst with
    | Nil -> ""
    | Cons(x, rest) -> 
        (match rest with 
           | Nil -> prettyOne x (* [x] *)
           | _ -> (prettyOne x) + delimiter + (prettyList prettyOne rest delimiter))
          
and prettyTyp t = 
  let str = match t with
    | T_Var gvar -> "T_Var " + prettyGvar gvar
    | T_Unit  -> "T_Unit "
    | T_Ind name -> "T_Ind " + prettyIname name
    | T_VApp(t1, v) -> "T_VApp " + prettyTyp t1 + " " + prettyValue v
    | T_App(t1, t2) -> "T_App " + prettyTyp t1 + " " + prettyTyp t2
    | T_Prod(bvar, t1, t2) -> "T_Prod " + prettyBvar bvar + " " + prettyTyp t1 + " " + prettyTyp t2
    | T_ProdK(bvar, k, t2) -> "T_ProdK " + prettyBvar bvar + " " + prettyKind k + " " + prettyTyp t2
    | T_Ref(bvar, t1, t2) -> "T_Ref " + prettyBvar bvar + " " + prettyTyp t1 + " " + prettyTyp t2
    | T_Lam(bvar, t1, t2) -> "T_Lam " + prettyBvar bvar + " " + prettyTyp t1 + " " + prettyTyp t2
    | T_Afn(t2) -> "T_Afn " + prettyTyp t2
    | T_Ascribe(t1, k2) -> "T_Ascribe " + (prettyTyp t1) + " " + (prettyKind k2)  in
  "(" + str + ")"

and prettyValue v =
  let str = match v with
    | V_Var gvar -> "V_Var " + prettyGvar gvar
    | V_Unit -> "V_Unit"
    | V_Fun(bvar, t, e) -> "V_Fun " + prettyBvar bvar + " " + prettyTyp t + " " + prettyExp e
    | V_FunT(bvar, k, e) -> "V_FunT " + prettyBvar bvar + " " + prettyKind k + " " + prettyExp e
    | V_Boxed(boxname, v) -> "V_Boxed " + prettyBoxname boxname + " " + prettyValue v
    | V_Const(cname, ts, vs) ->
      "V_Const " + prettyCname cname +
       " ([:: " + prettyList prettyTyp ts ";" + "]) ([:: " +
       prettyList prettyValue vs ";" + "])"
    | V_Ascribe(v, t) -> "V_Ascribe " + (prettyValue v) + " " + (prettyTyp t) in
  "(" + str + ")"
  
and prettyExp e =
  let str = match e with
    | E_Value v -> "E_Value " + prettyValue v
    | E_App(e1, v) -> "E_App " + prettyExp e1 + " " + prettyValue v
    | E_TApp(e, t) -> "E_TApp " + prettyExp e + " " + prettyTyp t
    | E_LetIn(bvar, e1, e2) -> "E_LetIn " + prettyBvar bvar + " " + prettyExp e1 + " " + prettyExp e2
    | E_Match(v, p, e1, e2) ->
      "E_Match " + prettyValue v + " " + prettyPattern p + " " + prettyExp e1 + " " + prettyExp e2
    | E_Assume(t) -> "E_Assume " + prettyTyp t
    | E_Ascribe(e, t) -> "E_Ascribe " + (prettyExp e) + " " + (prettyTyp t) in
  "(" + str + ")" 

and prettyPattern p = 
  match p with
    | MkPattern(name, bvars_t, bvars_v) -> (* name [bvars] [bvars'] *)
      prettyName name + "[" + prettyList prettyBvar bvars_t ";" + "] [" +
      prettyList prettyBvar bvars_v ";" + "]"

let indName ikinds = Microsoft.FStar.Util.spr "%s'" (prettyList (function (MkIKind(name, kind)) -> name) ikinds "_") 

(* write the inductives and bindings in env into a file, using Coq concrete syntax *)
let writeEnv env (fh:System.IO.Stream) = 
  let inds, bindings, names = env in
 
  (*let inds, bindings = List.rev inds, List.rev bindings in*)
  (* let fs = File.Create(filename) in *)
  let write (str: string) =
    let encoding = new UTF8Encoding(true) in
    let bytes = encoding.GetBytes(str) in
    fh.Write(bytes, 0, bytes.Length) in
  let writeName name = write (prettyName name) in
  let rec writePrimsList (writeOne: 'a -> unit) (lst: Prims.list<'a>) delimiter =
    match lst with
      | :? Prims.Nil<'a> -> ()
      | :? Prims.Cons<'a> as cons ->
        let x, rest = cons.field_1, cons.field_2 in
        (match rest with
          | :? Prims.Nil<'a> -> writeOne x
          | _ ->
            writeOne x; write delimiter; writePrimsList writeOne rest delimiter) in
  let rec writeList (writeOne: 'a -> unit) (lst: 'a list) delimiter =
    match lst with
      | [] -> ()
      | [x] -> writeOne x
      | x::rest ->
        writeOne x; write delimiter; writeList writeOne rest delimiter in
  
  let writeIkind (MkIKind(name, kind)) = write (Microsoft.FStar.Util.spr "(MkIKind \"%s\" %s)" name (prettyKind kind)) in
  let writeConstr cons = match cons with
    | MkConstructor(name, t) ->
      write "mkConstructor "; writeName name; write (" " + (prettyTyp t)) in
  let writeInd ind = match ind with
    (* Definition name1_name2_..._namen' : inductive :=
        mkIndType 
          [:: (Tup name1 k1);  ..
              (Tup namen kn); ] 
          [:: mkConstructor constr1_name constr1_type;
              mkConstructor constr2_name constr2_type; ...]. *)
    | MkIndType(ikinds, dcons) ->
      write "Definition "; write (indName ikinds); write (" : inductive := \n");
      write "  mkIndType "; 
      write "[:: "; writePrimsList writeIkind ikinds ";\n        ";
      write "]\n";
      write "[:: "; writePrimsList writeConstr dcons ";\n        ";
      write "].\n";
      (* Definition nameI := T_Ind name. *)
      writePrimsList (function (MkIKind(name, kind)) -> 
                        write "Definition "; write (name ^ "I"); write " := T_Ind "; writeName name; write ".") ikinds "\n" in
    
  let bindingName name = "binding_" + name in
  let writeBinding bind = match bind with
    (* Definition name_binding := (EB_VlName name t). *)
    | FV_VlName(name, t) ->
      write "Definition "; write (bindingName name); write " := ("; 
      write "EB_VlName "; writeName name; write " "; write (prettyTyp t); write (").")
    | FV_TyName(name, k) ->
      write "Definition "; write (bindingName name); write " := (";
      write "EB_TyName "; writeName name; write " "; write (prettyKind k); write (").") in

  write "Require Import certprelude.\n";
  write "Import Dec.\n Set Vm Optimize.\n Set Virtual Machine.\n";
  write "Local Open Scope ntstring_scope.\n";
  write "Notation GV_Bound := (@GV_Bound String_eqType String_eqType).\n";

//  write "Require Import ssreflect eqtype ssrbool ssrnat seq ssrfun.\n";
//  write "Require Import FS_Core FS_Notations FS_Pick FS_Terms FS_Dec FS_Judge.\n";
//  write "Local Open Scope string_scope.\n";
//  write "Local Implicit Arguments GV_Bound [bvar T].\n";
//  write "Local Implicit Arguments GV_Free  [bvar T].\n";
//  write "Import Dec.\n";
//  write "Definition TVB name := T_Var (GV_Bound name).\n";
//  write "Definition TVF name := T_Var (GV_Free name).\n";
//  write "Definition VB name := V_Var (GV_Bound name).\n";
//  write "Definition VF name := V_Var (GV_Free name).\n";
//  write "Definition BKC := K_Base BK_Comp.\n";
//  write "Definition BKP := K_Base BK_Prop.\n";
//  write "Definition BKE := K_Base BK_Erase.\n";
//  write "Definition BKA := K_Base BK_Afn.\n";
//  write "Notation Inr := (@inr _ _).\n";
//  write "Notation Inl := (@inl _ _).\n";
//  write "Axiom WFENV_Admit: forall i e b, wfE i e b.\n";
//  write "Notation MkIndType := mkIndType.\n";
//  write "Notation MkPattern := mkPattern.\n";
//  write "Notation MkConstructor := mkConstructor.\n";
//  write "Notation Partition := Split.\n";
//  write "Axiom Part_Admit : forall l1 l2 l3, Partition l1 l2 l3.\n";
//  write "Axiom Subtyping_Admit: forall i g b t1 t2, subtype i g b [::] t1 t2.\n";
//  write "Axiom Subkinding_Admit: forall i g b k1 k2, subkind i g b [::] k1 k2.\n";
//  write "Notation FV_VlName := EB_VlName.\n";
//  write "Notation FV_TyName := EB_TyName.\n";
//  write "Notation Refl_eq := refl_equal.\n";
//  write "Notation Tup := pair.\n";
//  write "Notation NotMem_hd := NotMem_nil.\n";
//  write "Notation NotMem_tl := NotMem_cons.\n";
//  write "Notation True := true. (* HACK *)\n";

  // write definition for tuples

  List.map (fun ind -> writeInd ind; write "\n") inds;
  List.map (fun binding -> writeBinding binding; write "\n") bindings;
  (* Definition icomp: seq inductive (i.e., icompartment) := [:: ind_names].*)
  (* Definition gamma: seq ebinding (i.e., environment) := [:: binding_names]. *)
  write "Definition icomp: seq inductive := [:: ";
  writeList write ((List.map (function | MkIndType(ikinds, _) -> indName ikinds) inds)) "; ";
  write "].\nDefinition gamma: seq ebinding := [:: ";
  writeList write (List.map (function |FV_VlName(name, _) -> bindingName name
                                      |FV_TyName(name, _ ) -> bindingName name) bindings) "; ";
  
  write "].\n";
  (* fs.Close(); *)
  ()

  
