﻿#light "off"
module CoretypingUtil

(* active patterns for coretyping data types *)
let (| GV_Bound |_|) (gv: Terms.gvar<string>) =
  match gv with
    | :? Terms.GV_Bound<string> as gvb -> Some(gvb.field_1)
    | _ -> None

let (| GV_Free | _ |) (gv: Terms.gvar<string>) =
  match gv with 
    | :? Terms.GV_Free<string> as gvf -> Some(gvf.field_1)
    | _ -> None

let (|MkPattern|) (p: Terms.pattern) =
  match p with
    | :? Terms.MkPattern as pat -> (pat.field_1, pat.field_2, pat.field_3)

let (|BK_Comp | BK_Prop | BK_Erase | BK_Afn|) (bk: Terms.basekind) = 
  match bk with
   | :? Terms.BK_Comp -> BK_Comp
   | :? Terms.BK_Prop -> BK_Prop
   | :? Terms.BK_Erase -> BK_Erase
   | :? Terms.BK_Afn -> BK_Afn

let (|K_Base|_|) (k:Terms.kind) =
  match k with
    | :? Terms.K_Base as knd -> Some (knd.field_1)
    | _ -> None

let (|K_ProdK|_|) (k:Terms.kind) =
  match k with
    | :? Terms.K_ProdK as knd -> Some(knd.field_1, knd.field_2, knd.field_3)
    | _ -> None

let (|K_ProdT|_|) (k:Terms.kind) =
  match k with
    | :? Terms.K_ProdT as knd -> Some(knd.field_1, knd.field_2, knd.field_3)
    | _ -> None

let (|T_Var|_|) (t:Terms.typ) =
  match t with
    | :? Terms.T_Var as tvar -> Some (tvar.field_1)
    | _ -> None

let (|T_Unit|_|) (t:Terms.typ) =
  match t with
    | :? Terms.T_Unit -> Some ()
    | _ -> None

let (|T_Ind|_|) (t:Terms.typ) =
  match t with
    | :? Terms.T_Ind as tt -> Some (tt.field_1)
    | _ -> None

let (|T_VApp|_|) (t:Terms.typ) =
  match t with
    | :? Terms.T_VApp as tt -> Some (tt.field_1, tt.field_2)
    | _ -> None

let (|T_App|_|) (t:Terms.typ) =
  match t with
    | :? Terms.T_App as tt -> Some (tt.field_1, tt.field_2)
    | _ -> None

let (|T_Prod|_|) (t:Terms.typ) =
  match t with
    | :? Terms.T_Prod as tt -> Some (tt.field_1, tt.field_2, tt.field_3)
    | _ -> None

let (|T_ProdK|_|) (t:Terms.typ) =
  match t with
    | :? Terms.T_ProdK as tt -> Some (tt.field_1, tt.field_2, tt.field_3)
    | _ -> None

let (|T_Ref|_|) (t:Terms.typ) =
  match t with
    | :? Terms.T_Ref as tt -> Some (tt.field_1, tt.field_2, tt.field_3)
    | _ -> None

let (|T_Lam|_|) (t:Terms.typ) =
  match t with
    | :? Terms.T_Lam as tt -> Some (tt.field_1, tt.field_2, tt.field_3)
    | _ -> None
   
let (|T_Afn|_|) (t:Terms.typ) =
  match t with
    | :? Terms.T_Afn as tt -> Some (tt.field_1)
    | _ -> None

let (|T_Ascribe|_|) (t:Terms.typ) =
  match t with
    | :? Terms.T_Ascribe as tt -> Some (tt.field_1, tt.field_2)
    | _ -> None

let (|V_Var|_|) (v:Terms.value) =
  match v with
    | :? Terms.V_Var as vv -> Some (vv.field_1)
    | _ -> None

let (|V_Unit|_|) (v:Terms.value) =
  match v with
    | :? Terms.V_Unit as vv -> Some ()
    | _ -> None

let (|V_Fun|_|) (v:Terms.value) =
  match v with
    | :? Terms.V_Fun as vv -> Some (vv.field_1, vv.field_2, vv.field_3)
    | _ -> None

let (|V_FunT|_|) (v:Terms.value) =
  match v with
    | :? Terms.V_FunT as vv -> Some (vv.field_1, vv.field_2, vv.field_3)
    | _ -> None

let (|V_Boxed|_|) (v:Terms.value) =
  match v with
    | :? Terms.V_Boxed as vv -> Some (vv.field_1, vv.field_2)
    | _ -> None

let (|V_Const|_|) (v:Terms.value) =
  match v with
    | :? Terms.V_Const as vv -> Some (vv.field_1, vv.field_2, vv.field_3)
    | _ -> None

let (|V_Ascribe|_|) (v:Terms.value) =
  match v with
    | :? Terms.V_Ascribe as vv -> Some (vv.field_1, vv.field_2)
    | _ -> None

let (|E_Value|_|) (e:Terms.expr) =
  match e with
    | :? Terms.E_Value as ee -> Some (ee.field_1)
    | _ -> None

let (|E_App|_|) (e:Terms.expr) =
  match e with
    | :? Terms.E_App as ee -> Some (ee.field_1, ee.field_2)
    | _ -> None

let (|E_TApp|_|) (e:Terms.expr) =
  match e with
    | :? Terms.E_TApp as ee -> Some (ee.field_1, ee.field_2)
    | _ -> None

let (|E_LetIn|_|) (e:Terms.expr) =
  match e with
    | :? Terms.E_LetIn as ee -> Some (ee.field_1, ee.field_2, ee.field_3)
    | _ -> None

let (|E_Match|_|) (e:Terms.expr) =
  match e with
    | :? Terms.E_Match as ee -> Some (ee.field_1, ee.field_2, ee.field_3, ee.field_4)
    | _ -> None

let (|E_Assume|_|) (e:Terms.expr) =
  match e with
    | :? Terms.E_Assume as ee -> Some (ee.field_1)
    | _ -> None

let (|E_Ascribe|_|) (e:Terms.expr) =
  match e with
    | :? Terms.E_Ascribe as ee -> Some (ee.field_1, ee.field_2)
    | _ -> None

let (|MkConstructor|) (c:Env.constructor) =
  match c with
    | :? Env.MkConstructor as constr -> (constr.field_1, constr.field_2)

let (|MkIndType|) (i:Env.inductive) =
  match i with
    | :? Env.MkIndType as mki -> (mki.field_1, mki.field_2)

let (|FV_VlName|_|) (f:Env.fvbinding) =
  match f with
    | :? Env.FV_VlName as fv -> Some(fv.field_1, fv.field_2)
    | _ -> None

let (|FV_TyName|_|) (f:Env.fvbinding) =
  match f with
    | :? Env.FV_TyName as fv -> Some(fv.field_1, fv.field_2)
    | _ -> None

let (|Cons | Nil|) (l:Prims.list<'a>) = 
  match l with 
    | :? Prims.Nil<'a> -> Nil
    | :? Prims.Cons<'a> as cons -> Cons (cons.field_1, cons.field_2)

let rec primsListOfList (l:list<'a>) : Prims.list<'a> = match l with 
  | [] -> new Prims.Nil<'a> () :> Prims.list<'a>
  | hd::tl -> new Prims.Cons<'a>(hd, primsListOfList tl) :> Prims.list<'a>

let (|Tup|) (f:Util.tup<'a,'b>) =
  match f with 
    | :? Util.Tup<'a,'b> as t -> Tup(t.field_1, t.field_2)

let (|MkIKind|) (f:Env.ikind) =
  match f with 
    | :? Env.MkIKind as t -> MkIKind(t.field_1, t.field_2)

let (|MkW|) (f:FiniteSet.W<'a>) = 
  match f with 
    | :? FiniteSet.MkW<'a> as t -> MkW(t.field_1)

let (|DepTuple|) (f:Prims.DepTuple<'a,'b>) = 
  match f with 
    | :? Prims.DconDepTuple<'a,'b> as t -> DepTuple(t.fst, t.snd)

let (|DepTuple5|) (f:Prims.DepTuple<'a,Prims.DepTuple<'b,Prims.DepTuple<'c, Prims.DepTuple<'d,'e>>>>) = 
  let (DepTuple(x1, DepTuple(x2, DepTuple(x3, DepTuple(x4, x5))))) = f in 
    DepTuple5(x1, x2, x3, x4, x5)
