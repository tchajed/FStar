﻿(* #light "off" *)
module AbsynToCoretyping

open Microsoft.FStar
open Microsoft.FStar.Absyn
open Microsoft.FStar.Pretty
open Microsoft.FStar.Util
open CoretypingUtil
open KindAbbrevs

let pr = Printf.printf

let text_of_id = Microsoft.FStar.Sugar.text_of_id
let text_of_lid (lid:lident) = String.concat "_" (List.map text_of_id lid.lid)
let lid_equals = Microsoft.FStar.Sugar.lid_equals

exception Impos
let __dummy = string2ident "__dummy"
let newDummyString = 
  let ctr = ref 0 in 
    fun () -> incr ctr; spr "_id_%d" !ctr


let bvdefToBvar bvdef = text_of_id(bvdef.realname)
let bvdefToVlname = bvdefToBvar
let bvdefOptToBvar bvdopt = 
  match bvdopt with
    | Some bvd -> bvdefToBvar bvd
    | None -> newDummyString ()

let bvarCount = ref 0
let genBvar = fun (x:unit) -> let n = !bvarCount in 
                              bvarCount := n+1; 
                              Printf.sprintf "bvar_%d" n

let bvarToBvar bvar = text_of_id(bvar.v.realname)
let varToBvar (var: var<'t>) = text_of_lid (var.v)
let idToVlname = text_of_id
let lidToCname = text_of_lid 
let lidToVlname = text_of_lid
let lidToIname = lidToCname
let varToVlname = varToBvar
let varToIname = varToBvar
let varToCname = varToBvar
let typToBvar = Microsoft.FStar.Pretty.strTyp
let consToVlname = Microsoft.FStar.Pretty.strConst

let vlnameToFreeV vlname = 
  new Terms.V_Var(new Terms.GV_Free<string>(vlname)) :> Terms.value

let nameToBoundV name =
  new Terms.V_Var(new Terms.GV_Bound<string>(name)) :> Terms.value

let nameToBoundTv name = new Terms.T_Var(new Terms.GV_Bound<string>(name)) :> Terms.typ

let nilTerms = new Prims.Nil<'a>() :> Prims.list<'a>

let rec alistToPrimsList (l: 'a list) : Prims.list<'a> =
  match l with 
    | [] -> new Prims.Nil<'a>() :> Prims.list<'a>
    | x::rest -> new Prims.Cons<'a>(x, alistToPrimsList rest) :> Prims.list<'a>

type transenv = Env.inductive list * Env.fvbinding list * string list
let emptyTransenv = ([], [], [])
let transEnvToIcompFenv env =
  let (inds, fvs, _) = env in
  (alistToPrimsList inds, alistToPrimsList fvs)
let isIn (name:string) (names:string list) = List.exists (fun name' -> name = name') names 
let isInEnv env name = let _, _, names = env in isIn name names
let normalizeString (s: string) : string = 
  let s = s.Trim([|' '; '!'; ':'; ','; ';'; '.'; '('; ')'; '-'; '^'; '='; '*'; '/'; '"'|]) in
  let s = s.Replace(' ', '_') in
  let s = s.Replace('!', '_') in
  let s = s.Replace(':', '_') in
  let s = s.Replace(',', '_') in
  let s = s.Replace(';', '_') in
  let s = s.Replace('.', '_') in
  let s = s.Replace('<', '_') in
  let s = s.Replace('>', '_') in
  let s = s.Replace('=', '_') in
  let s = s.Replace('(', '_') in
  let s = s.Replace(')', '_') in
  let s = s.Replace('-', '_') in
  let s = s.Replace('^', '_') in
  let s = s.Replace('*', '_') in
  let s = s.Replace('/', '_') in
  let s = s.Replace('"', '_') in
  s
let contains (_, _, (names:list<string>)) (iname:string) = List.exists (fun n -> iname=n) names
let addInd (env:transenv) (inames:list<string>) (ind:Env.inductive) =
  if List.exists (contains env) inames 
  then env
  else 
    let inds, fvs, names = env in
      ind::inds, fvs, inames@names
let addVbinding env vname t = 
  let vname = normalizeString vname in
  let inds, fvs, names = env in
  if (not(isIn vname names)) 
  then 
    let fvb = new Env.FV_VlName(vname, t) in
    (* let _ = pr "Adding vbinding: %A\n" (fvb.ToString()) in *)
      inds, (fvb :> Env.fvbinding) :: fvs, vname::names
  else env
let addTbinding env tname k = 
  //let tname = normalizeString tname in
  let inds, fvs, names = env in
  if (not(isIn tname names)) then inds, (new Env.FV_TyName(tname, k) :> Env.fvbinding) :: fvs, tname::names
  else env


let propKind: Terms.kind = new Terms.K_Base(new Terms.BK_Prop()) :> Terms.kind
let starKind: Terms.kind = new Terms.K_Base(new Terms.BK_Comp()) :> Terms.kind
let affineKind: Terms.kind = new Terms.K_Base(new Terms.BK_Afn()) :> Terms.kind
let mkTup (x:'a * 'b) : Util.tup<'a,'b> = new Util.Tup<'a,'b>(fst x, snd x) :> Util.tup<'a,'b>
let mkIKind i k = new Env.MkIKind(i,k) :> Env.ikind

let rec transKind env k : transenv * Terms.kind = match k(* .u *) with
  | Kind_boxed k' -> transKind env k'
  | Kind_star -> env, starKind
  | Kind_affine -> env, affineKind
  | Kind_prop -> env, new Terms.K_Base(new Terms.BK_Prop()) :> Terms.kind
  | Kind_erasable -> env, new Terms.K_Base(new Terms.BK_Erase()) :> Terms.kind
  | Kind_tcon(bvdopt, k1, k2) ->
    let env, k1' = transKind env k1 in
    let env, k2' = transKind env k2 in
    env, new Terms.K_ProdK(bvdefOptToBvar bvdopt, k1', k2') :> Terms.kind
  | Kind_dcon(bvdopt, t, k2) ->
    let env, t' = transTyp env t in
    let env, k2' = transKind env k2 in
    env, new Terms.K_ProdT(bvdefOptToBvar bvdopt, t', k2') :> Terms.kind
  | Kind_unknown -> pr "Kind_unknown\n"; raise Impos

and transTyp env t : transenv * Terms.typ = 
  let t = whnf (compress t) in
  let env, t' = match t.v with
  | Typ_btvar bv -> env, nameToBoundTv(bvarToBvar bv)
  | Typ_const(var, _) -> 
    env, new Terms.T_Ind(varToIname var) :> Terms.typ
  | Typ_record(fname_tys, topt) -> pr "transTyp: %s\n" (Pretty.strTyp t); raise Impos
  | Typ_fun(bvdopt, t1, t2) -> 
    let env, t1' = transTyp env t1 in
    let env, t2' = transTyp env t2 in
    env, new Terms.T_Prod(bvdefOptToBvar bvdopt, t1', t2') :> Terms.typ
  | Typ_univ(bvd, k, [], t2) -> 
    let env, k' = transKind env k in
    let env, t2' = transTyp env t2 in
    env, new Terms.T_ProdK(bvdefToBvar bvd, k', t2') :> Terms.typ
  | Typ_dtuple((bvdef_opt, t1) :: [(None, t2)]) -> (* x1:t1 * t2 *)
    (* translate to inductive types *)
    (* An exmaple of tuple Ind: 
       Tuple**: a::* => b::a=>* => * {Tuple_UU: forall a::*, b::x:a =>*, a -> b a -> Tuple a (\x:a.b)}
       x:a * b ==> Tuple a (\x:a.b) *)
    let env, t1', tfun = tyArgsOfTuple env bvdef_opt t1 t2 in
    let tuple_data_lid = Microsoft.FStar.Const.tuple_data_lid t1.sort t2.sort in
    let tuple_name =
      if lid_equals tuple_data_lid Microsoft.FStar.Const.tuple_UU_lid then "tupleUU'"
      else if lid_equals tuple_data_lid Microsoft.FStar.Const.tuple_UA_lid then "tupleUA'"
      else if lid_equals tuple_data_lid Microsoft.FStar.Const.tuple_AU_lid then "tupleAU'"
      else if lid_equals tuple_data_lid Microsoft.FStar.Const.tuple_AA_lid then "tupleAA'"
      else if lid_equals tuple_data_lid Microsoft.FStar.Const.tuple_UP_lid then "tupleUP'"
      else if lid_equals tuple_data_lid Microsoft.FStar.Const.tuple_PU_lid then "tuplePU'"
      else if lid_equals tuple_data_lid Microsoft.FStar.Const.tuple_PP_lid then "tuplePP'"
      else pr "transTyp: %s\n" (Pretty.strTyp t); raise Impos in
    (* return tuple t1' (\x:t1'.t2') *)
    env, new Terms.T_App(new Terms.T_App(new Terms.T_Ind(tuple_name), t1'), tfun) :> Terms.typ
  | Typ_refine(bvd, t1, formula, _) -> 
    let env, t1' = transTyp env t1 in
    let env, formula' = transTyp env formula in
    env, new Terms.T_Ref(bvdefToBvar bvd, t1', formula') :> Terms.typ
  | Typ_app(t1, t2) ->
    let env, t1' = transTyp env t1 in
    let env, t2' = transTyp env t2 in
    env, new Terms.T_App(t1', t2') :> Terms.typ
  | Typ_dep(t1, e) ->
    let env, t1' = transTyp env t1 in
    let env, e' = transExpToVal env e in
    env, new Terms.T_VApp(t1', e') :> Terms.typ
  | Typ_affine t1 -> 
    let env, t1' = transTyp env t1 in
    env, new Terms.T_Afn(t1') :> Terms.typ
  | Typ_lam(bvd, t1, t2) ->
    let env, t1' = transTyp env t1 in
    let env, t2' = transTyp env t2 in
    env, new Terms.T_Lam(bvdefToBvar bvd, t1', t2') :> Terms.typ
  | Typ_tlam(bvd, k, t') -> pr "transTyp: %s\n" (Pretty.strTyp t); raise Impos
  | Typ_ascribed(t1, k) ->
    let env, t1' = transTyp env t1 in
    let env, k'= transKind env k in
    env,new Terms.T_Ascribe(t1', k') :> Terms.typ
  | _ -> pr "Unexpected type in translation: %s" (Pretty.strTyp t); raise Impos in
  let env, k' = transKind env t.sort in
  (* env, Terms.T_Ascribe(t', k') :> Terms.typ *)
  env, t' 

and transExpToVal env e : transenv * Terms.value = 
  let env, e' = match e.v with
  | Exp_bvar bvar -> 
    env, nameToBoundV(bvarToBvar bvar)
  | Exp_fvar (var, _ ) -> 
    env, vlnameToFreeV(varToVlname var)
  | Exp_constr_app(var, [t1;t2], _, [e1;e2]) when Const.is_tuple_data_lid var.v -> 
      let t2 = AbsynUtils.mkTlam None t1 t2 in 
      let env, t1 = transTyp env t1 in 
      let env, t2 = transTyp env t2 in 
      let env, e1 = transExpToVal env e1 in 
      let env, e2 = transExpToVal env e2 in 
        env, new Terms.V_Const(varToCname var, alistToPrimsList [t1;t2], alistToPrimsList [e1;e2]) :> Terms.value
  | Exp_constr_app(var, ts, _, es) ->
    let (env, ts') = List.fold (fun env_ts t -> let (env, newts) = env_ts in
                                                let env, t' = transTyp env t in
                                                env, t'::newts) (env, []) ts in 
    let (env, es') = List.fold (fun env_vs e -> let (env, newvs) = env_vs in
                                                let env, e' = transExpToVal env e in
                                                env, e'::newvs) (env, []) es in
    env, new Terms.V_Const(varToCname var, alistToPrimsList (List.rev ts'), alistToPrimsList (List.rev es')) :> Terms.value
  | Exp_constant (Sugar.Const_bool true) -> env, Terms.V_Const("true", alistToPrimsList [], alistToPrimsList []) :> Terms.value
  | Exp_constant (Sugar.Const_bool false) -> env, Terms.V_Const("false", alistToPrimsList [], alistToPrimsList []) :> Terms.value
  | Exp_constant (Sugar.Const_unit) -> 
      env, Terms.V_Const("__unit_val", alistToPrimsList [], alistToPrimsList []) :> Terms.value
  | Exp_constant c ->
    let vlname = consToVlname c in
    let vlname = normalizeString vlname in
    let env, t = transTyp env e.sort in
    let env = addVbinding env vlname t in
    env, vlnameToFreeV vlname
  | Exp_abs(bvd, t, e2) -> 
    let env, t' = transTyp env t in
    let env, e2' = transExp env e2 in
    env, new Terms.V_Fun(bvdefToBvar bvd, t', e2') :> Terms.value
  | Exp_tabs(bvd, k, [], e2) -> 
    let env, k' = transKind env k in
    let env, e2' = transExp env e2 in
    env, new Terms.V_FunT(bvdefToBvar bvd, k', e2') :> Terms.value
  | Exp_ascribed(e1, t, _ ) -> 
    let env, e1' = transExpToVal env e1 in
    let env, t' = transTyp env t in
    let env_e, ty_e = transTyp env (e1.sort) in
      (* NS: Removed this. 
         The typing of match statements differs between tc and coretyping. 
         We need the ascribe node. *)
      (* if (ty_e = t') then env, e1' *)
      (* else  *)
      env, new Terms.V_Ascribe(e1', t') :> Terms.value 
  | Exp_let _ 
  | Exp_gvar _ 
  | Exp_extern_call _ 
  | Exp_app _ 
  | Exp_tapp _ 
  | Exp_match _ 
  | Exp_cond _
  | Exp_primop _ 
  | Exp_bot 
  | _ -> pr "\nGot %s; expected value" (Pretty.strExp e); raise Impos  in
  let env, t' = transTyp env (e.sort) in
  (* env, Terms.V_Ascribe (e', t') :> Terms.value *)
  env, e' 

and transExp env e : transenv * Terms.expr = 
  let env, e' = match e.v with
  | Exp_bvar _ 
  | Exp_fvar _ 
  | Exp_abs _ 
  | Exp_tabs _ 
  | Exp_constant _
  | Exp_constr_app _ ->
    let env, e' = transExpToVal env e in
    env, new Terms.E_Value(e') :> Terms.expr
  | Exp_app(e1, e2) -> 
    let env, e1' = transExp env e1 in
    let rec getParamTyp t = (match t.v with
      | Typ_fun(_, t1, _) -> t1
      | Typ_ascribed(t', _) -> getParamTyp t'
      | _ -> pr "GetParamTyp: %s\n" (Pretty.strTyp t); raise Impos) in
    let env, e2' = transExpToVal env e2 in
    env, new Terms.E_App(e1', e2') :> Terms.expr
  | Exp_tapp(e1, t) -> 
    let env, e1' = transExp env e1 in
    let env, t' = transTyp env t in
    env, new Terms.E_TApp(e1', t') :> Terms.expr
  | Exp_match (e1, pes, e2) -> (* flatten to one pattern at a time? what to do if e1 is affine *) (* E_Match  : value -> pattern -> expr -> expr -> expr *)
      (* let _ = pr "Translation of exp_match %s\n" (Pretty.strExp e) in  *)
      (* let _ = pr "Annotated type of match is %s\n" (Pretty.strTyp e.sort) in *)
      let env, tmatch = transTyp env e.sort in 
      (* let _ = pr "Translated type of match to %A\n" tmatch in *)
      let env, e1' = transExpToVal env e1 in
      let env, e2' = transExp env e2 in
      let env, t2 = transTyp env e2.sort in 
      (* let _ = pr "Translated type of default case to %A\n" t2 in *)
        (* NS: Syntactic identity of types gets broken by expansion of type abbreviations in expand_typs, 
               although types remain alpha equivalent. 
               Need these checks and ascribes to get alpha renaming to work properly in coretyping. 
        *)
      let e2' = 
        if tmatch=t2 
        then e2' 
        else 
          (* let _ = pr "Ascribing branch %A of match as %A\n" e2' tmatch in *)
            new Terms.E_Ascribe(e2', tmatch) :> Terms.expr in 
        List.fold_right (fun pe env_e ->
                           let env, reste = env_e in
                           let pat, eb = pe in
                           let env, eb' = transExp env eb in
                           let env, tb = transTyp env eb.sort in 
                           let eb' = if tmatch=tb then eb' else new Terms.E_Ascribe(eb', tmatch) :> Terms.expr in
                             env, new Terms.E_Match(e1', transPattern pat, eb', reste) :> Terms.expr) 
          pes (env, e2')
  | Exp_proj(e1, fname_lid) -> (* handle tuple projection *)
    let isProjOne, isProjTwo = lid_equals fname_lid Microsoft.FStar.Const.tuple_proj_one, 
                               lid_equals fname_lid Microsoft.FStar.Const.tuple_proj_two in
    if (isProjOne || isProjTwo) then 
      (* translate to let x = e1 : (b:t1*t2) in match x with tuple t1 (\b:t1.t2) left right -> left/right | _ -> botExp *)
      let env, e1' = transExp env e1 in
      let xname = "x" in
      let leftName, rightName = "left", "right" in
      let (env, t1', tfun), cname = (match e1.sort.v with
                     | Typ_dtuple ((bvdef_opt, t1) :: [(None, t2)]) ->
                       tyArgsOfTuple env bvdef_opt t1 t2, text_of_lid(Microsoft.FStar.Const.tuple_data_lid t1.sort t2.sort)
                     | _ -> pr "transExp: %s\n" (Pretty.strExp e); raise Impos) in
      let pat = new Terms.MkPattern(cname, alistToPrimsList([genBvar(); genBvar()]), 
                                    alistToPrimsList [leftName; rightName]) :> Terms.pattern in (* Tuple([t1'; tfun], [left; rigth]) *)
      let leftOrRight = if isProjOne then leftName else rightName in
      let env, t = transTyp env e.sort in 
      let env, bot = botExp env t in 
        env, new Terms.E_LetIn(xname, e1',
                               new Terms.E_Match(nameToBoundV xname, pat, new Terms.E_Value(nameToBoundV leftOrRight), bot)) :> Terms.expr
    else pr "transExp: %s\n" (Pretty.strExp e); raise Impos
  | Exp_ascribed(e1, t, _) ->
    let env, e1' = transExp env e1 in
    let env, t' = transTyp env t in
    let env_e, ty_e = transTyp env e1.sort in
      (* NS: Removed this. 
         The typing of match statements differs between tc and coretyping. 
         We need the ascribe node. *)
    (* if (ty_e = t') then env, e1' *)
    (* else *) env, new Terms.E_Ascribe(e1', t') :> Terms.expr
  | Exp_let(_, [(bvd, t, e1)], e2) -> (* E_LetIn  : bvar -> expr -> expr -> expr *)
    (match e2.v with
      | Exp_bvar bvd' when bvd_eq bvd bvd'.v -> (* let x = e in x ==> e *)
        transExp env e1 
      | _ -> 
        (match e1.v with
           | Exp_bvar _ -> (* let x = y in e => e[y/x]*)
             transExp env (substitute_exp_val e2 bvd e1)
           | _ ->
            let env, e1' = transExp env e1 in
            let env, e2' = transExp env e2 in
            env, new Terms.E_LetIn(bvdefToBvar bvd, e1', e2') :> Terms.expr))
  | Exp_cond (eb, et, ef) ->
    let env, eb' = transExpToVal env eb in
    let env, tmatch = transTyp env e.sort in 
    let env, et' = transExp env et in
    let env, ttrue = transTyp env et.sort in 
    let et' = if tmatch = ttrue then et' else new Terms.E_Ascribe(et', tmatch) :> Terms.expr in 
    let env, ef' = transExp env ef in
    let env, tfalse = transTyp env ef.sort in 
    let ef' = if tmatch = tfalse then ef' else new Terms.E_Ascribe(ef', tmatch) :> Terms.expr in 
    let truePat = new Terms.MkPattern("true", nilTerms, nilTerms) :> Terms.pattern in
      env, new Terms.E_Match(eb', truePat, et', ef') :> Terms.expr

  | Exp_primop (id, args0) ->
    let env, args' = List.fold_left (fun (env, out) e -> 
                                     let env, e' = transExpToVal env e in 
                                       env, e'::out) (env, []) args0 in
    let args = List.rev args' in 
    let lhs, env = match id.idText with 
      | "op_BarBar"
      | "op_AmpAmp" -> 
          new Terms.E_Value(vlnameToFreeV(spr "Prims__dummy_%s" (idToVlname id))) :> Terms.expr, env
      | op -> pr "transExp: %s primitive operator not handled\n" op; raise Impos in 
    let tm = List.fold_left (fun out arg -> new Terms.E_App(out, arg) :> Terms.expr) lhs args in 
      env, tm

  (* | Exp_primop (id, [e1; e2]) when text_of_id id = "op_Equality" -> (\* eq e1 e2 => eq<t> e1' e2' *\) *)
  (*   let env, e1' = transExpToVal env e1 in *)
  (*   let env, e2' = transExpToVal env e2 in *)
  (*   let env, t' = transTyp env e1.sort in *)
  (*   env, new Terms.E_App( *)
  (*          new Terms.E_App( *)
  (*            new Terms.E_TApp( *)
  (*              new Terms.E_Value(vlnameToFreeV(idToVlname id)), *)
  (*              t'), *)
  (*            e1'), *)
  (*          e2') :> Terms.expr  *)

  | Exp_bot ->  (* translate to riase() *)
      let env, t = transTyp env e.sort in 
        botExp env t
  | Exp_gvar _ 
  | Exp_extern_call _ 
  | _ -> pr "transExp: %s\n" (Pretty.strExp e); raise Impos in
  let env, t' = transTyp env e.sort in
  (* env, Terms.E_Ascribe(e', t') :> Terms.expr *)
  env, e'

and botExp env t = 
  let env, v = transExpToVal env (ewithsort (Exp_constant (Sugar.Const_string (Util.unicodeEncoding.GetBytes "", 0L))) Const.string_typ) in 
  let call = new Terms.E_App((new Terms.E_TApp(new Terms.E_Value(vlnameToFreeV "Prims_raise") :> Terms.expr,
                                               t) :> Terms.expr),
                             v) :> Terms.expr in 
    env, call
                                    
and transPattern p : Terms.pattern = match p with
  | Pat_variant(lid, ts, phantoms, bvars, _) ->
    new Terms.MkPattern(lidToCname lid, alistToPrimsList(List.map (fun t -> genBvar()) ts), 
      alistToPrimsList(List.map bvarToBvar bvars)) :> Terms.pattern

and tyArgsOfTuple env x t1 t2 = (* get the two type arguments for Tuple from \x:t1 * t2 *)
  let env, t1' = transTyp env t1 in
  let env, t2' = transTyp env t2 in
  let x = match x with 
    | Some _ -> x
    | None -> let d=string2ident (newDummyString ()) in  Some (mkbvd(d,d)) in
    env, t1', new Terms.T_Lam(bvdefOptToBvar x, t1', t2') :> Terms.typ

(*************************** level 0 embedding *********************)

let eb (fs:System.IO.FileStream) (str: string) = 
  let encoding = new System.Text.UTF8Encoding(true) in
  let bytes = encoding.GetBytes(str) in
  fs.Write(bytes, 0, bytes.Length)

let ebBvar fs bvar = eb fs (text_of_id(bvar.v.realname))
let ebBvd fs bvd = eb fs (text_of_id bvd.realname)
let ebVar fs (var: var<'t>) = eb fs (text_of_lid(var.v))
let ebId fs id = eb fs (text_of_id id)
let ebLid fs lid = eb fs (text_of_lid lid)
let ebCons fs cons = eb fs (Microsoft.FStar.Pretty.strConst cons)

(* print out (ebA a) -> (ebB b) or forall x, (ebA) a -> (ebB b) if bvdopt = Some x *)
let ebArrowOrTuple isArrow (fs:System.IO.FileStream) (bvdopt: bvvdef option) (a:'a) (b:'b) 
    (ebA: System.IO.FileStream -> 'a -> unit)
    (ebB: System.IO.FileStream -> 'b -> unit): unit = 
    let _ = eb fs "(" in
    let _ = match bvdopt with
      | Some x -> eb fs "forall "; ebBvd fs x; eb fs ", "
      | None -> () in
    let _ = ebA fs a in
    let _ = if isArrow then eb fs " -> " else eb fs " * " in
    ebB fs b; eb fs ")"

(* print out (ebA a) -> (ebB b) or forall x, (ebA) a -> (ebB b) if bvdopt = Some x *)
let ebArrow (fs:System.IO.FileStream) (bvdopt: (Disj<option<btvdef>,option<bvvdef>>))
    (ebA: unit -> unit)
    (ebB: unit -> unit): unit = 
    let _ = eb fs "(" in
    let _ = match bvdopt with
      | Inl (Some x) -> eb fs "forall "; ebBvd fs x; eb fs ", "
      | Inr (Some x) -> eb fs "forall "; ebBvd fs x; eb fs ", "
      | _ -> () in
    let _ = ebA() in
    let _ = eb fs " -> " in
    ebB(); eb fs ")"

let ebApp (fs:System.IO.FileStream) (a:'a) (b:'b) 
    (ebA: System.IO.FileStream -> 'a -> unit)
    (ebB: System.IO.FileStream -> 'b -> unit): unit = 
    let _ = eb fs "("; ebA fs a; eb fs " " in
    ebB fs b; eb fs ")"

let rec ebKind (fs:System.IO.FileStream) (k: kind) = 
  let _ = Util.pr "\n EBKIND: %s" (Pretty.strKind k) in
  match k(* .u *) with
    | Kind_boxed k' -> ebKind fs k'
    | Kind_star -> eb fs "Type"
    | Kind_afn -> eb fs "K_afn"
    | Kind_prop -> eb fs "Prop"
    | Kind_erasable -> eb fs "K_erasable"
    | Kind_tcon(bvdopt, k1, k2) -> (* forall x, k1 -> k2 *)
      ebArrow fs (Inl bvdopt) (fun () -> ebKind fs k1) (fun () -> ebKind fs k2)
    | Kind_dcon(bvdopt, t, k2) -> (* forall x, t -> k2 *)
      ebArrow fs (Inr bvdopt) (fun () -> ebTyp fs t) (fun () -> ebKind fs k2)
    | _ -> let _ = pr "ebKind: Kind_unknown" in raise Impos

and ebTyp fs (t: typ) = 
  let t = whnf (compress t) in
  //let _ = eb fs "(" in
  let _ = match t.v with
    | Typ_btvar bv -> ebBvar fs bv 
    | Typ_const(var, _) -> ebVar fs var
    | Typ_record(_, _) -> pr "ebTyp: record type"; raise Impos
    | Typ_fun(bvdopt, t1, t2) -> (* forall x, t1 -> t2 *)
      ebArrow fs (Inr bvdopt) (fun() -> ebTyp fs t1) (fun () -> ebTyp fs t2)
    | Typ_univ(bvd, k, [], t2) -> (* forall x, t2 *)
      eb fs "forall "; ebBvd fs bvd; eb fs ", "; ebTyp fs t2 
    | Typ_dtuple((bvdopt, t1):: [(None, t2)]) -> (* forall x, t1 * t2 *)
      ebArrowOrTuple false fs bvdopt t1 t2 ebTyp ebTyp
    | Typ_refine(_, t1, _, _) -> ebTyp fs t1
    | Typ_app(t1, t2) -> (* t1 t2 *)
      ebApp fs t1 t2 ebTyp ebTyp
    | Typ_dep(t1, e) -> (* t1 e *)
      ebApp fs t1 e ebTyp ebExp
    | Typ_affine t1 -> pr "ebTyp: affine type"; raise Impos
    | Typ_lam(bvd, t1, t2) -> (* fun bvd => t2 *)
      eb fs "fun "; ebBvd fs bvd; eb fs " => "; ebTyp fs t2
    | Typ_tlam _ -> pr "ebTyp: Typ_tlam"; raise Impos
    | Typ_ascribed(t1, k) -> ebTyp fs t1
    | _ -> let _ = pr "Unexpected type in ebTyp: %s" (Pretty.strTyp t) in raise Impos in
  ()//eb fs ")"

and ebExp fs e = 
  //let _ = eb fs "(" in
  let _ = match e.v with
    | Exp_bvar bvar -> ebBvar fs bvar
    | Exp_fvar (var, _) -> ebVar fs var
    | Exp_constr_app(var, ts, _, es) -> (* var ts es *)
      let _ = eb fs "(" in
      let _ = ebVar fs var in
      let _ = List.map (fun t -> eb fs " "; ebTyp fs t) ts in
      let _ = List.map (fun e -> eb fs " "; ebExp fs e) es in
      eb fs ")" 
    | Exp_constant (Sugar.Const_bool true) -> eb fs "true"
    | Exp_constant (Sugar.Const_bool false) -> eb fs "false"
    | Exp_constant c -> 
      (match c with
         | Sugar.Const_string _ -> eb fs ("\"" ^ (consToVlname c) ^ "\"")
         | _ -> eb fs (consToVlname c))
    | Exp_ascribed (e1, _, _) -> ebExp fs e1
    | _ -> pr "unexpected exp %s in ebExp" (Pretty.strExp e); raise Impos in
  () //eb fs ")"

let tclidOfDcon = function 
  | Sig_datacon_typ(_, _, _, _, _, Some lid_tcon, _, _) -> lid_tcon
  | x -> pr "Unexpected sigelt: %A\n" x; raise Impos

let mkDc name typ lid = Sig_datacon_typ(Const.p2l [name], [], typ, None, Public, Some lid, None, [])
(* Inductive lid_tcon: forall tparams, k := 
     | lid_dcon : forall tparams, t 
     | ... 
   with tcon2 := 
   ... .

*)
let ebTDcon fs (tycons, dcons) = 
  let rec group tycons dcons = match tycons, dcons with 
    | [], [] -> []
    | (Sig_tycon_kind(tc_lid, _, _, _, _, _) as tc1)::rest, _ -> 
        let dcons1, dcons_rest = List.partition (fun dc -> lid_equals tc_lid (tclidOfDcon dc)) dcons in 
          (tc1, dcons1)::group rest dcons_rest in
  let first::rest = group tycons dcons in 
  let ebGroup pfx (Sig_tycon_kind(lid_tcon, tparams, k, _, _, _), dcons) = 
    let rec isProp k = match k(* .u *) with
      | Kind_boxed k' -> isProp k'
      | Kind_prop -> true
      | Kind_tcon(_, _, k2)
      | Kind_dcon(_, _, k2) -> isProp k2
      | _ -> false in
      if not (isProp k) 
      then ()
      else
        let ebTparam tp = match tp with
          | Tparam_typ(x, k) -> ebBvd fs x
          | Tparam_term(x, t) -> ebBvd fs x in
        let ebTparams tps = 
          if List.length tps > 0 then
            let _ = eb fs "forall " in
            let _ = List.map (fun tp -> eb fs " "; ebTparam tp) tps in
              eb fs ", " 
          else () in
        let _ = eb fs (spr "%s " pfx); ebLid fs lid_tcon; eb fs ": " in
        let _ = ebTparams tparams in
        let _ = ebKind fs k; eb fs " := \n" in
        let ebDcon (Sig_datacon_typ(lid_dcon, tparams_dcon, t, _, _, _, _, _)) =
          let _ = eb fs "  | "; ebLid fs lid_dcon; eb fs ": " in
          let _ = ebTparams tparams_dcon in
            ebTyp fs t; 
            eb fs "\n" in
          List.iter ebDcon dcons in
    ebGroup "Inductive" first;
    List.iter (ebGroup "with") rest; 
    eb fs ".\n"

  (* type sigelt =
  | Sig_tycon_kind   of lident * list<tparam> * kind * bool (* bool identifies a prop *)
  | Sig_typ_abbrev   of lident * list<tparam> * kind * typ
  | Sig_record_typ   of lident * list<tparam> * kind * typ * option<Sugar.externref>
  | Sig_datacon_typ  of (lident * list<tparam> * typ * bool * aqual * 
                         option<lident> * option<Sugar.externref> * list<formula_pat>) 
      (* bool identifies an assumption;lident identifies type name *)
  | Sig_value_decl   of lident * typ 
  | Sig_extern_value of Sugar.externref * lident * typ
  | Sig_extern_typ   of Sugar.externref * sigelt (* lident * typ * kind *)
  | Sig_query        of lident * formula
  | Sig_ghost_assume of lident * formula * aqual*)
let transSig fs_opt env sigelts = 
  let transInductive env (tycons, datas) = 
    let ikinds, env  = List.fold_left (fun (out, env) (Sig_tycon_kind(lid, tps, k, _, _, _)) -> 
                                         let k_tcon = Microsoft.FStar.Tcenv.tycon_kind_from_tparams tps k in
                                         let env, k' = transKind env k_tcon in
                                           (mkIKind (lidToCname lid) k')::out, env) ([], env) tycons in
    let ikinds = List.rev ikinds in
    let constrs, env = List.fold_left (fun (out, env) (Sig_datacon_typ(lid_dcon, tps, t, _, _, _, _, _)) -> 
                                         let env, t' = transTyp env (Microsoft.FStar.Tcenv.dcon_type_from_tparams tps t) in
                                         let data = new Env.MkConstructor(lidToCname lid_dcon, t') :> Env.constructor in
                                           data::out, env) ([], env) datas in 
    let constrs = List.rev constrs in 
    let ind = new Env.MkIndType(alistToPrimsList ikinds, 
                                alistToPrimsList constrs) :> Env.inductive in
    let inames = List.map (function MkIKind(iname, _) -> iname) ikinds in 
      addInd env inames ind in 
  let rec transValdecl env = function
    | Sig_value_decl(lid, t)
    | Sig_extern_value(_, lid, t) ->
        let env, t' = transTyp env t in
          addVbinding env (lidToVlname lid) t'
    | Sig_extern_typ(_, sigelt') -> transValdecl env sigelt'
    | _ -> env in   
  let transPrimitive env ((Sig_tycon_kind(lid, _, _, _, _, _)) as s) = 
    if lid_equals lid Const.bool_lid then
      transInductive env ([s], [mkDc "true" Const.bool_typ lid; 
                                mkDc "false" Const.bool_typ lid])
    else if lid_equals lid Const.unit_lid then 
      transInductive env ([s], [mkDc "__unit_val" Const.unit_typ lid])
    else transInductive env ([s], []) in
  let rec groupMutuals sigelts = match sigelts with 
    | [] -> []
    | Sig_tycon_kind(_, _, _, _, mutuals, _)::rest -> 
        let inMutuals lid = List.exists (lid_equals lid) mutuals in 
        let check inds dcon = 
          let lid = tclidOfDcon dcon in
            if not (inds |> List.exists (function Sig_tycon_kind(lid', _, _, _, _, _) -> lid_equals lid lid'))
            then raise Impos in 
        let inds, sigelts = gatherUntil sigelts (function Sig_tycon_kind(lid, _, _, _, _, _) when inMutuals lid -> true | _ -> false) in 
        let data, sigelts = gatherUntil sigelts (function Sig_datacon_typ _ -> true | _ -> false) in 
          List.iter (check inds) data;
          match inds, data with 
            | [], [] -> raise Impos
            | _ -> (inds, data)::groupMutuals sigelts in
  let is_primitive lid = List.exists (lid_equals lid)  [Const.object_lid; 
                                                        Const.bool_lid; 
                                                        Const.unit_lid; 
                                                        Const.int_lid; 
                                                        Const.string_lid; 
                                                        Const.bytes_lid] in 
  let primitives, sigelts = sigelts |> List.partition (function Sig_tycon_kind(lid, _, _, _, _, _) -> is_primitive lid | _ -> false) in
  let inductives, vals = List.partition (function 
                                           | Sig_tycon_kind _ 
                                           | Sig_datacon_typ(_, _, _, None, _, Some _, _, _) -> true 
                                           | _ -> false) sigelts in  
  let inductives = groupMutuals inductives in 
  let inductives = inductives |> List.filter (function (inds, _) -> 
                                                inds |> List.exists (function Sig_tycon_kind(lid_tcon, _, _, _, _, _) -> 
                                                                       not (Sugar.lid_equals lid_tcon Const.ntuple_lid))) in
  let env = List.fold_left transPrimitive env primitives in 
  let env = List.fold_left transInductive env inductives in 
  let env = List.fold_left transValdecl env vals in 
  let env, strtyp = transTyp env Const.string_typ in 
  let env = addVbinding env "" strtyp in
  let env = addVbinding env "__dummy" strtyp in
  let _ = match fs_opt with
    | Some fs -> List.map (ebTDcon fs) inductives; ()
    | None -> () in
  // add tuple inds to env
  let addTupleInd env tuple_lid tuple_name k1 k2 k =
    let tupleTyp = new Terms.T_Ind(tuple_name) in
    let alphaName, betaName = "a", "b" in
    let alpha, beta = nameToBoundTv alphaName :> Terms.typ, nameToBoundTv betaName :> Terms.typ in
    let aTok2 = new Terms.K_ProdT(newDummyString (), alpha, k2) :> Terms.kind in
        (* constructor (cname, forall a::k1, b::a=>k2, x:a -> _:b x -> tuple a b) *)
    let xName = newDummyString () in 
    let x = nameToBoundV xName :> Terms.value in
    let ctype = new Terms.T_ProdK(alphaName, k1,
                    new Terms.T_ProdK(betaName, aTok2,
                    new Terms.T_Prod(xName, alpha,
                        new Terms.T_Prod(newDummyString (), new Terms.T_VApp(beta, x),
                        new Terms.T_App(new Terms.T_App(tupleTyp, alpha), beta))))) :> Terms.typ in
    let constr = new Env.MkConstructor(lidToCname tuple_lid, ctype) :> Env.constructor in
    (* Tuple: tuple_name :: a::k1 => b::(a=>k2) => k <constr> *)      
    let kind = new Terms.K_ProdK(alphaName, k1, new Terms.K_ProdK(newDummyString (), aTok2, k)) :> Terms.kind in
    addInd env [tuple_name] (new Env.MkIndType(alistToPrimsList([mkIKind tuple_name kind]), 
                        alistToPrimsList([constr])) :> Env.inductive) in
  let env = addTupleInd env Microsoft.FStar.Const.tuple_UU_lid "tupleUU'" starKind starKind starKind in
  let env = addTupleInd env Microsoft.FStar.Const.tuple_UA_lid "tupleUA'" starKind affineKind affineKind in
  let env = addTupleInd env Microsoft.FStar.Const.tuple_UP_lid "tupleUP'" starKind propKind starKind in
  let env = addTupleInd env Microsoft.FStar.Const.tuple_PU_lid "tuplePU'" propKind starKind starKind in
  let env = addTupleInd env Microsoft.FStar.Const.tuple_PP_lid "tuplePP'" propKind propKind starKind in
  (*let env = addTupleInd env Microsoft.FStar.Const.tuple_AU_lid "tupleAU'" affineKind starKind affineKind in*)
  (*addTupleInd env Microsoft.FStar.Const.tuple_AA_lid "tupleAA'" affineKind affineKind affineKind in*)
  env

let doLetbinding env letbinding = 
  let (inductives, freevars, _) = env in
    match letbinding with
      | [((bvd:bvvdef), t, e)] -> 
          let talpha = Absyn.alpha_convert t in 
          let env, t' = transTyp env talpha in 
          (* let _  = pr "Translating letbinding %s,%s of type %s\n alpha converted to %A\n translated to %A\n" (bvd.ppname.idText) (bvd.realname.idText) (t.ToString()) (talpha.ToString()) t' in  *)
          let (inductives', freevars', _), e' = transExp env e in
            (if not (inductives === inductives') then raise Impos);
            let newFreevars = Util.remove_tail freevars' freevars in 
              (newFreevars, (bvdefToVlname bvd), e', t')
      | _ -> (pr "multiple bindings"; raise Impos)
        (* fenv for constants and value-decls *)
        
(* type letbinding = list<bvdef * typ * exp> (* let recs may have more than one element *)

type modul = {
  name: lident;
  extends: option<lident>;
  pos: Range.range;
  signature: signature;
  letbindings: list<letbinding * bool>; (* the boolean signals a let rec *)
  main:option<exp>;
  exports: signature;
}*)
