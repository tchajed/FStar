#light "off"
module Microsoft.FStar.MonadicInference
(* TODO: remove this file from svn *)

open Util
open Absyn
open MonadicPretty
open MonadicUtils

(*****************************************************************************)
(*                        Typed elaboration functions                        *)
(*              for inference of refined ST Pre 'a Post types                *)
(*****************************************************************************)

(* Assumption: target.sort has been populated with an accurate ST type for *)
(*             the target exp.                                             *)
let mkResult (constraints:prop) (target:exp) : result =
  (* The result type makes the assumption that
   *
   *     target : typ
   *     typ = ST pre t post
   *
   * where t and post are some type and post-condition.
   * So, return {pre=getPreFromST typ; typ=target.sort; ... }
   *)
  let typ = target.sort in
  let pre = getPreFromST typ in
    {pre=pre; typ=typ; constraints=constraints; target=target;}

let refined_sub (env:Tcenv.env) (t1:typ) (t2:typ) : prop =
  if unify env t1 t2 then Const.true_typ
  else failwith "Subtyping failed."

(* result.typ will always be an ST *)
let rec refined_elaborate_exp_comp (env:Tcenv.env) (top_exp:exp) (post:pred) 
    : result = 
  match top_exp.v with 
    | Exp_bvar _
    | Exp_fvar _
    | Exp_constant _
    | Exp_constr_app _
    | Exp_abs _ ->
        let env, topt = Tcenv.clear_expected_typ env in
        let t, constraints, e = refined_elaborate_val_pure env top_exp in
        (* e.sort should equal t *)
        let e' = mkRefinedReturn env post e in
        let t' = e'.sort in
        let t', e' = (match topt with 
          | None -> e'.sort, e'
          | Some et ->
              if unify env t' et
              then e'.sort, e'
              else failwith 
                (spr 
                  "val_comp expected %s got %s\n    for %s\n" 
                  (typ2string et "") 
                  (typ2string t' "")
                  (exp2string e' ""))) in (* TODO: nicer error *)
          {pre=mkPreFromPost post e'; typ=t'; constraints=constraints; target=e';}

(* TODO | Exp_tabs       of bvdef * kind * exp *)

    | Exp_app ({v=Exp_app({v=Exp_fvar(fv, _)} as eq, v1)}, v2) 
      when Sugar.lid_equals fv.v Const.op_Eq -> 
        (* this is a hack around the refinement in EQ's type *)
        let env, topt = Tcenv.clear_expected_typ env in
        let _ = 
          match topt with
            | Some et -> if unify env et Const.bool_typ then ()
                else 
                  failwith 
                    (spr "Expecting something other than bool as the result of %s = %s."
                      (exp2string v1 "")
                      (exp2string v2 "")) 
            | None -> () in
        let t1,constraints1,v1' = 
          refined_elaborate_val_pure (Tcenv.set_expected_typ env Const.int_typ) v1 in
        let t2,constraints2,v2' = 
          refined_elaborate_val_pure (Tcenv.set_expected_typ env Const.int_typ) v2 in
        let partial_typ = 
          withsort (Typ_fun(None, Const.int_typ, Const.bool_typ)) Kind_star in
        let eq_typ =
          withsort (Typ_fun(None, Const.int_typ, partial_typ)) Kind_star in
        let eq = setsort eq eq_typ in
        let partial_app = withsort (Exp_app(eq, v1')) partial_typ in
        let new_exp_app = (withsort (Exp_app(partial_app, v2')) Const.bool_typ) in
        let res_exp = mkRefinedReturnExp env post new_exp_app in
        let constraints = mkAnd constraints1 constraints2 in
          mkResult constraints res_exp

    | Exp_app (e, v) -> 
        (* Create fresh unification variables. *)
        let ua = TypeRelations.new_uvar env Kind_star top_exp.p in
        let uPre = TypeRelations.new_uvar env kindPre top_exp.p in
        let ub = TypeRelations.new_uvar env Kind_star top_exp.p in
        let uPost = TypeRelations.new_uvar env (mkKindPost None ub) top_exp.p in
        let uPhi = TypeRelations.new_uvar env kindPre top_exp.p in
        let ut = TypeRelations.new_uvar env Kind_star top_exp.p in
        let uPsi1 = TypeRelations.new_uvar env (mkKindPost None ut) top_exp.p in

        (* Grab and clear any expected type *)
        let env, topt = Tcenv.clear_expected_typ env in

        (* Type e *)
        let result1 = refined_elaborate_exp_comp env e uPsi1 in

        (* Type v *)
        let tv, vconstraints, v = refined_elaborate_val_pure env v in

        (* TODO: kinding check on post with ut2 *)

        (* Unify result.typ with (ST uPhi (ua -> ST uPre ub uPost) uPsi1) *)
        let x_bvd = new_bvd (Some top_exp.p) in
        let uST = mkST env uPre ub uPost in
        let uSTarr = withinfo (Typ_fun(Some x_bvd,ua,uST)) Kind_star result1.typ.p in
        let uSTarr' = mkST env uPhi uSTarr uPsi1 in
        let _ = if unify env result1.typ uSTarr' then ()
          else failwith "Cannot unify function type." in

        (* tv <: ua *)
        let s1Constraints = refined_sub env tv ua in
        (* ub <: ut2 *)
        (* TODO: we need kinding to generate post :: ut2 => ... *)
        (* let ub_sub = substitute_exp ub x_bvd v in *)
        (* let s2Constraints = refined_sub env ub_sub ut in *)

        (* uPsi1 \unifies \y:uSTarr. \h@heap. (uPre h)[v/x] *)
        let y_bvd = new_bvd (Some top_exp.p) in
        let h_bvd = new_bvd (Some top_exp.p) in
        let h_exp = bvd_to_exp h_bvd Const.heap_typ in
        let uPre_h = withsort (Typ_dep(uPre, h_exp)) Kind_erasable in
        let uPre_h_sub = substitute_exp uPre_h x_bvd v in
        let lam_h = withsort (Typ_lam(h_bvd, Const.heap_typ, uPre_h_sub)) kindPre in
        let lam_y_h = withsort (Typ_lam(y_bvd, uSTarr, lam_h)) (mkKindPost None uSTarr) in
        let _ = if unify env uPsi1 lam_y_h then ()
          else failwith "Cannot unify application post-condition." in

        (* postImpConstraints = postImp(uPost[v\x], post, ub[v/x]) *)
        let postImp (p1:pred) (p2:pred) (b:typ) : prop =
          (* p1 :: b => heap => E *)
          (* p2 :: b => heap => E *)
          match p1.v with 
            | Typ_uvar _ ->
                if unify env p1 p2 then Const.true_typ
                else failwith "Couldn't unify application postconditions."
            | _ ->
                let y_bvd = new_bvd (Some top_exp.p) in
                let y_exp = bvd_to_exp y_bvd b in
                let h_bvd = new_bvd (Some top_exp.p) in
                let h_exp = bvd_to_exp h_bvd Const.heap_typ in
                let p1_y = withsort (Typ_dep(p1,y_exp)) kindPre in
                let p1_y_h = withsort (Typ_dep(p1_y,h_exp)) Kind_erasable in
                let p2_y = withsort (Typ_dep(p2,y_exp)) kindPre in
                let p2_y_h = withsort (Typ_dep(p2_y,h_exp)) Kind_erasable in
                let imp = mkImplies p1_y_h p2_y_h in
                let fh_imp = mkForall h_bvd Const.heap_typ imp in
                let fy_fh_imp = mkForall y_bvd b fh_imp in
                  fy_fh_imp in
        let uPost_sub = substitute_exp uPost x_bvd v in
        let ub_sub = substitute_exp ub x_bvd v in
        let postImpConstraints = postImp uPost_sub post ub_sub in

        (* constraints = c1 and ... and c6 *)
        let constraints = 
          List.fold mkAnd 
            result1.constraints 
            [vconstraints; (* kinding constraints; *) 
             s1Constraints; (* s2Constraints; *) postImpConstraints;] in

        (* Compare against an expected type *)
        let _ = match topt with
          | Some et -> 
              if unify env uST et then ()
              else failwith 
                (spr "Expected a %s but got a %s\n    for %s\n" 
                  (typ2string et "")
                  (typ2string uST "")
                  (exp2string top_exp "")) 
          | _ -> () in

        (* Sanity check *)
        let phi = 
          match uPhi.v with
            | Typ_uvar _ -> failwith "Phi cannot be a unification variable."
            | _ -> uPhi in

        (* Build and return the result *)
        let f_bvd = new_bvd (Some top_exp.p) in 
        let f_exp = bvd_to_exp f_bvd uSTarr in

        (* TODO: is this result_typ right? *)
        let result_typ = mkST env  phi ub_sub post in
        let target = 
          mkRefinedBind 
            env 
            result1.target
            f_bvd 
            (withsort (Exp_app(f_exp, v)) result_typ) in
          mkResult constraints target

(* TODO | Exp_tapp       of exp * typ  *) 
(* TODO | Exp_match (v, patlist, d) *)
(* TODO | Exp_cond (v, eq, e2) *)
(* TODO
    (* let r' = {r with f=1} *)
  | Exp_recd       of option<lident> * list<typ> * list<exp> * list<fieldname * exp>  
  | Exp_proj       of exp * fieldname 
*)

    | Exp_ascribed (e, ascribed_t, evidence) ->
        (* TODO: actually handle this *)
        refined_elaborate_exp_comp env e post

    (* TODO: pick up here next, and then with top-level lets. *)
    | Exp_let(false, [(x,t,e')], body) when AbsynUtils.is_value e' -> todo ()
    | Exp_let(false, [(x,{v=Typ_unknown},e')], body) -> 
        let tx = TypeRelations.new_uvar env Kind_star e'.p in 
        let env_body = Tcenv.push_local_binding env (Tcenv.Binding_var(real_name x, tx)) in 
        let result_body = refined_elaborate_exp_comp env_body body post in 
        let post1 = withinfo 
          (Typ_lam(x, tx, result_body.pre)) (* result_body.pre :: heap => E *)
          (Kind_dcon(Some x, tx, result_body.pre.sort)) (* post1 :: tx => heap => E *) 
          e'.p in 
        let result_e' = refined_elaborate_exp_comp env e' post1 in 
        let target = mkRefinedBind env result_e'.target x result_body.target in
        let result = {pre=result_e'.pre;
                      typ=result_body.typ;
                      constraints=mkAnd result_e'.constraints result_body.constraints;
                      target=target} in 
          result

(* TODO
  | Exp_gvar       of int  (* only for internal use by proof extraction. unbound variable deBruijn index *) 
  | Exp_extern_call of Sugar.externref * ident * typ * list<typ> * list<exp>
*)
    
    | Exp_primop(op, args) ->
        (* Primitive operators are assumed to be pure. *)
        (match Tcenv.lookup_operator env op with
          | None -> raise (Tcenv.Err ("Unknown operator: "^op.idText))
          | Some t -> 
              let args_rev, constraints, result_typ = List.fold_left 
                (fun (args, constraints, t) arg -> match t.v with 
                   | Typ_fun(xopt, t_arg, t_ret) -> 
                       let env = Tcenv.set_expected_typ env t_arg in
                       let t',new_constraints,arg = refined_elaborate_val_pure env arg in
                       (* Check t_arg against the inferred type t' *)
                       let sub_constraints = refined_sub env t' t_arg in
                       let t_ret = match xopt with
                         | None -> t_ret
                         | Some x -> substitute_exp t_ret x arg in
                       let new_constraints = mkAnd new_constraints sub_constraints in
                       let new_constraints = mkAnd new_constraints constraints in
                         arg::args, new_constraints, t_ret
                   | _ -> 
                       let msg = 
                         spr "Too many arguments to operator %s, (e.g., %s is extra)" 
                           op.idText 
                           (Pretty.strExp arg) in
                         raise (Tcenv.Err msg)) ([], Const.true_typ, t) args in
              let _ = match result_typ.v with 
                | Typ_fun _ -> 
                    raise 
                      (Tcutil.Error 
                        (spr "All operators must be fully-applied\n%s" 
                          (Pretty.strExp top_exp), 
                          top_exp.p))
                | _ -> () in
              (* TODO: problem: we're treating the application of primitive operations as
               *       if they were pure, but we need a value to apply the postcondition
               *       to in order to get the precondition.
               *
               *       Does it make sense to have something like:
               *           ST (Post (1 + 2)) int Post
               *)
              let new_op = (withinfo (Exp_primop(op, List.rev args_rev)) result_typ top_exp.p) in
              let e' = mkRefinedReturnExp env post new_op in
                mkResult constraints e')

    | Exp_bot -> failwith "Type inference encountered Exp_bot."
    | _ -> failwith (spr "unexpected %s\n" (exp2string top_exp ""))


and refined_elaborate_val_pure (env:Tcenv.env) (top_exp:exp) : (typ * prop * exp) =
  let inst_variable env exp sigma : (typ * exp) = 
    let t, alphas = 
      let t, alpha_bindings = TypeRelations.instantiate_typ env sigma in
        t, (List.unzip alpha_bindings |> snd) in
      List.fold_left (fun (sigma, exp) alpha -> 
                        (* (open_typ_with_typ forall a.t t') --> t[t'/a] *)
                        let sigma' = ignore_formula_open_typ_with_typ sigma alpha in 
                        let exp' = {v=Exp_tapp(exp, alpha);
                                    sort=sigma';
                                    p=exp.p} in 
                          sigma', exp') (sigma, exp) alphas in
  let t, constraints, target = 
    match top_exp.v with
      | Exp_bvar bv -> 
          (* 1. lookup type scheme in env 
             2. instantiate type scheme producing type arguments
             3. elaborate to a type application *)
          let sigma = Tcenv.lookup_bvar env bv in
          let t,e = inst_variable env (setsort top_exp sigma) sigma in
            t, Const.true_typ, e

      | Exp_fvar(fv, _) -> 
          (match Tcenv.lookup_fvar env fv with
             | None -> failwith "variable not found" (* TODO: nicer error *)
             | Some sigma -> 
                 let t, e = inst_variable env (setsort top_exp sigma) sigma in
                   t, Const.true_typ, e)
    
      | Exp_constant c ->
          let t = Tcutil.typing_const env c in
            t, Const.true_typ, setsort top_exp t

        (* TODO: handle type args *)
      | Exp_constr_app(cname, targs, [], vargs) -> (* Nik: A simple way to handle this would be to treat it as an application *)
          let ctyp, tps = match Tcenv.lookup_fvar_with_params env cname with
            | None -> raise (Tcenv.Err ("Variable not found: "^(Sugar.text_of_lid cname.v)))
            | Some t -> t
            in
          let inst_ctyp, targs' = instantiate_typ env ctyp targs in (* Nik: Inconsistent. Should this be instantiate_typ_scheme? *)
          let env, topt = Tcenv.clear_expected_typ env in (* Nik: expected_typ etc. suggests this is bidirectional. Should it be? *)
          let inst_ctyp, subst = match topt, tps with (* Nik: Can we simplify this for ML1? I.e., no term indices etc. *)
            | None, [] -> inst_ctyp, []
            | None, _ -> 
                let msg = 
                  spr 
                    "Cannot infer term indices for constructed type %s; a type annotation may help" 
                    (Pretty.strTyp ctyp)
                  in
                raise (Tcutil.Error (msg, top_exp.p))
            | Some et, _ -> 
                let inst_ctyp, subst = 
                  TypeRelations.try_instantiate_final_typ env tps inst_ctyp et in
                  inst_ctyp, subst 
            in
          let vargs_rev, result_typ, constraints_list = 
            List.fold_left 
            (fun (arglist, ctyp, constraints_list) arg -> match ctyp.v with 
               | Typ_fun (bvd_opt, arg_typ, ret_typ) -> 
                   let env' = Tcenv.set_expected_typ env arg_typ in 
                   let t', constraints, arg' = refined_elaborate_val_pure env' arg in 
                   let ret_typ' = match bvd_opt with 
                       None -> ret_typ
                     | Some bvd -> substitute_exp ret_typ bvd arg' in
                   (* TODO: kinding to ensure non-value expressions don't escape into types *)
                   (* let ret_typ', _ = kinding env {ret_typ' with p=top_exp.p} in *)
                     (arg'::arglist, ret_typ', constraints::constraints_list)
               | _ -> 
                   let msg = 
                     spr "Too many arguments to constructor %s, (e.g., %s is extra)" 
                       (Pretty.str_of_lident cname.v) 
                       (Pretty.strExp arg) 
                       in
                     raise (Tcenv.Err msg)) ([], inst_ctyp, []) vargs 
            in
          let _ = match result_typ.v with 
              Typ_fun _ 
            | Typ_univ _ -> 
                raise 
                  (Tcutil.Error 
                    (spr 
                      "All data constructors must be fully-applied\n%s" 
                      (Pretty.strExp top_exp), top_exp.p))
            | _ -> () in
          let ctyp = List.fold_left (fun ctyp (bvd, e) -> 
                                       substitute_exp ctyp bvd e) ctyp subst in
          let cname' = setsort cname ctyp in
          let vargs' = List.rev vargs_rev in
          let constraints = List.fold_left (fun conj x -> mkAnd conj x) Const.true_typ constraints_list in
          let target= withinfo (Exp_constr_app(cname', targs', [], vargs')) result_typ top_exp.p in
            result_typ, constraints, target

      | Exp_abs (x, {v=Typ_unknown}, body) -> (* Nik: should we do n-ary functions and not lift body into ST if it is itself a lambda? *)
          (*  1. Generate a new unification variable, u
              2. Push (x:u) into the environment
              3. Type the body
              4. produce a function type, and elaborate *)
          let u = TypeRelations.new_uvar env Kind_star top_exp.p in 
          let env = Tcenv.push_local_binding env (Tcenv.Binding_var(real_name x, u)) in 
          let res_u = TypeRelations.new_uvar env Kind_star top_exp.p in
          let postKind = mkKindPost None res_u in
          let body_post = TypeRelations.new_uvar env postKind top_exp.p in 
          let result = refined_elaborate_exp_comp env body body_post in (* Nik: Hmm ... why not infer_exp_typ? *)
          let tbody = result.typ in

          (* Unify the result type in the post condition with the inferred
           * result type. *) (* Nik: Why do we do this unification? *)
          let body_pre = TypeRelations.new_uvar env kindPre top_exp.p in
          let _ = if unify env tbody (mkST env  body_pre res_u body_post) then () 
            else failwith 
                "Cannot unify post condition with inferred result type." in
          let body = result.target in
          let typ = withsort (Typ_fun(Some x, u, tbody)) Kind_star in
          let target = withinfo (Exp_abs(x, u, body)) typ top_exp.p in
            typ, result.constraints, target

(*      TODO: what do we do when the type is known? *)
      | Exp_abs (x, t, body) ->
          (* Set up the unification variables *)
          let u = TypeRelations.new_uvar env Kind_star top_exp.p in 
          let env = Tcenv.push_local_binding env (Tcenv.Binding_var(real_name x, u)) in 
          let res_u = TypeRelations.new_uvar env Kind_star top_exp.p in
          let postKind = mkKindPost None res_u in
          let body_post = TypeRelations.new_uvar env postKind top_exp.p in 

          (* Do the inference *)
          let result = refined_elaborate_exp_comp env body body_post in
          let tbody = result.typ in
          let body = result.target in

          (* Unify the result with the expected ST shape *)
          let body_pre = TypeRelations.new_uvar env kindPre top_exp.p in
          let _ = if unify env t (mkST env  body_pre res_u body_post) then () 
            else failwith 
                "Cannot unify post condition with inferred result type." in

          (* Build the target type *)
          let typ = withsort (Typ_fun(Some x, u, tbody)) Kind_star in
          let target = withinfo (Exp_abs(x, u, body)) typ top_exp.p in
          if unify env t u
          then typ, result.constraints, target
          else failwith (spr "Ascription 'x:%A' does not match inferred argument of '%A'." t typ)
          
      | _ -> failwith (spr "unexpected %A" top_exp)
    in
  let env, topt = Tcenv.clear_expected_typ env in
    match topt with
      | None -> t, constraints, target
      | Some et -> 
        if unify env t et
        then t, constraints, target
        else 
          failwith 
            (spr 
              "val_pure expected %s got %s\n    for %s\n" 
              (typ2string et "") 
              (typ2string t "")
              (exp2string target "")) (* TODO: nicer error *)



(* Elaboration and inference of the refined ST Pre t Post type. *)
let refined_elaborate_exp (env:Tcenv.env) (e:exp) (post:pred) : result =
  let result = 
    if AbsynUtils.is_value e
    then 
      let t', constraints, e' = refined_elaborate_val_pure env e in
        {pre=mkPreFromPost post e'; typ=t'; constraints=constraints; target=e';}
    else refined_elaborate_exp_comp env e post in
  let t', e' = Tcutil.generalize env result.typ result.target in
    result
