#light "off"
module Microsoft.FStar.MonadicSimpleInference

open Util
open Absyn
open MonadicPretty
open MonadicUtils

(* TODO: separate simple inference from elaboration. *)
(* i.e. remove references to MonadicElaboration.xxx  *)

(* This is all deprecated anyway. *)
(*

(*****************************************************************************)
(*                        Typed elaboration functions                        *)
(*                         for inference of ST types                         *)
(*****************************************************************************)

(* DEPRECATED: we assume the user annotates source programs with ascriptions *)
(* in the target language. *)
let rec elaborate_ascribed_val_typ (env:Tcenv.env) (top_typ:typ) : typ =
  let W t' = {v=t'; sort=top_typ.sort; p=top_typ.p} in
  match top_typ.v with
    | Typ_fun (bopt, t1, t2) ->
        let t1' = elaborate_ascribed_val_typ env t1 in
        let t2' = elaborate_ascribed_comp_typ env t2 in
        W (Typ_fun (bopt, t1', t2'))
    | _ -> top_typ

and elaborate_ascribed_comp_typ (env:Tcenv.env) (top_typ:typ) : typ =
  (* Elaborate user-provided type ascription top_typ into a stateful type;
   * that is, wrap top_exp in an ST and, in the case of a function,
   * recursively wrap the range.
   *)
  let W t' = {v=t'; sort=top_typ.sort; p=top_typ.p} in
  match top_typ.v with 
    | Typ_btvar _
    | Typ_const _ -> MonadicElaboration.mkST env top_typ
    | Typ_record (flist, topt) -> failwith "TODO"
    | Typ_fun (bopt, t1, t2) ->
        let t1' = elaborate_ascribed_val_typ env t1 in
        let t2' = elaborate_ascribed_comp_typ env t2 in
        MonadicElaboration.mkST env (W (Typ_fun (bopt, t1', t2')))
    | Typ_univ (b,k,_,t) -> failwith "Users should not ascribe universal types." (* NS -- ignoring formula *)
    | Typ_dtuple elts -> failwith "TODO"
    | Typ_refine _ -> failwith "unexpected Typ_refine"
    | Typ_app (t1,t2) -> 
        failwith "Users should not ascribe type applications."
    | Typ_dep (t,e) -> failwith "TODO"
    | Typ_affine t -> failwith "TODO"
    | Typ_lam (b,t1,t2) -> failwith "Users should not ascribe type functions."
    | Typ_tlam (b,k,t) -> failwith "Users should not ascribe type functions."
    | Typ_ascribed (t,k) -> 
        let t' = elaborate_ascribed_comp_typ env t in
        W (Typ_ascribed (t',k))
    | Typ_unknown -> top_typ
    | Typ_uvar _ -> failwith (spr "unexpected Typ_uvar")
    | _ -> failwith (spr "unexpected %s" (typ2string top_typ ""))

(*  bind_st t1 t2 e1 (\x:t1. e2)  *)
(* TODOs *)
(* Change withsort to withinfo to carry position information? *)
(* Simplify the call to open_typ_with_exp since t_bind_t1_t2 is not dependent *)
(* Maybe cache sigma_bind somewhere? *)

(* return_st 't e : 't -> ST 't *)
let mkReturnT (env:Tcenv.env) (t:typ) (e:exp) : exp = 
  let sigma_return = Tcenv.lookup_lid env Const.return_st_lid in
  let return_id = withsort Const.return_st_lid sigma_return in
  let return_e = withsort (Exp_fvar (return_id, None)) sigma_return in
  let t_return_t = ignore_formula_open_typ_with_typ sigma_return t in  (* NS -- ignoring formula *)
  let return_t = withsort (Exp_tapp (return_e, t)) t_return_t in
  withsort (Exp_app (return_t, e)) (MonadicElaboration.mkST env t)

(* bind_st 'a 'b e1 (\x. e2) : ST 'a -> ('a -> ST 'b) -> ST 'b *)
let mkBindT (env:Tcenv.env) (t1:typ) (t2:typ) (e1:exp) (x:bvdef) (e2:exp) : exp = 
  let sigma_bind = Tcenv.lookup_lid env Const.bind_st_lid in 
  let bind_id = withsort Const.bind_st_lid sigma_bind in
  let bind_e = withsort (Exp_fvar (bind_id, None)) sigma_bind in
  let sigma1 = (ignore_formula_open_typ_with_typ sigma_bind t1) in   (* NS -- ignoring formula *)
  let bind_t1 = withsort (Exp_tapp(bind_e, t1)) sigma1 in 
  let t_bind_t1_t2 = (ignore_formula_open_typ_with_typ sigma1 t2) in  (* NS -- ignoring formula *)
  let bind_t1_t2 = withsort (Exp_tapp(bind_t1, t2)) t_bind_t1_t2 in
  let t_bind_t1_t2_e1 = open_typ_with_exp t_bind_t1_t2 e1 in  (* (open_typ_with_exp (x:t1 -> t2) v) --> t2[v/x] *)
  let bind_t1_t2_e1 = withsort (Exp_app(bind_t1_t2, e1)) t_bind_t1_t2_e1 in 
  let lam_x_e2 = withsort (Exp_abs (x, t1, e2)) (withsort (Typ_fun(Some x, t1, MonadicElaboration.mkST env t2)) Kind_star) in
    withsort (Exp_app (bind_t1_t2_e1, lam_x_e2)) (MonadicElaboration.mkST env t2)
      
let rec telaborate_exp_comp (env:Tcenv.env) (top_exp:exp) : (typ * exp) =
  match top_exp.v with
    | Exp_bvar _
    | Exp_fvar _
    | Exp_constant _
    | Exp_constr_app _
    | Exp_abs _ ->
        let env, topt = Tcenv.clear_expected_typ env in
        let t,e' = telaborate_val_pure env top_exp in
        let e' = mkReturnT env t e' in
        let t' = e'.sort in
        (match topt with 
          | None -> e'.sort, e'
          | Some et ->
              if unify env t' et
              then e'.sort, e'
              else failwith 
                (spr 
                  "val_comp expected %s got %s\n    for %s\n" 
                  (typ2string et "") 
                  (typ2string t' "")
                  (exp2string e' ""))) (* TODO: nicer error *)

(* TODO | Exp_tabs       of bvdef * kind * exp *)

    | Exp_app ({v=Exp_app({v=Exp_fvar(fv, _)} as eq, v1)}, v2) 
      when Sugar.lid_equals fv.v Const.op_Eq -> 
        (* this is a hack around the refinement in EQ's type *)
        let env, topt = Tcenv.clear_expected_typ env in
        let _ = 
          match topt with
            | Some et -> if unify env et Const.bool_typ then ()
                else 
                  failwith 
                    (spr "Expecting something other than bool as the result of %s = %s."
                      (exp2string v1 "")
                      (exp2string v2 "")) 
            | None -> () in
        let t1,v1' = 
          telaborate_val_pure (Tcenv.set_expected_typ env Const.int_typ) v1 in
        let t2,v2' = 
          telaborate_val_pure (Tcenv.set_expected_typ env Const.int_typ) v2 in
        let partial_typ = 
          withsort (Typ_fun(None, Const.int_typ, Const.bool_typ)) Kind_star in
        let eq_typ =
          withsort (Typ_fun(None, Const.int_typ, partial_typ)) Kind_star in
        let eq = setsort eq eq_typ in
        let partial_app = withsort (Exp_app(eq, v1')) partial_typ in
        let res_exp = 
          mkReturnT 
            env 
            Const.bool_typ 
            (withsort (Exp_app(partial_app, v2')) Const.bool_typ) in
          Const.bool_typ, res_exp
    | Exp_app (e1, v) -> 
        (* 1. Type and elaborate e1
           2. Type and elaborate v
           3. Unify type of e1 as a function from type of v to some result
           4. Construct resulting type and term
        *)
        let env, topt = Tcenv.clear_expected_typ env in
        let t1, e1 = telaborate_exp_comp env e1 in
        let tv, v = telaborate_val_pure env v in
        let result_uvar = TypeRelations.new_uvar env Kind_star e1.p in 
        let result_typ = MonadicElaboration.mkST env result_uvar in
        let tf = withsort (Typ_fun(None, tv, result_typ)) Kind_star in 
        let t1' = MonadicElaboration.mkST env tf in
          if unify env t1 t1'
          then 
            (* Compare against an expected type *)
            let _ = match topt with
              | Some et -> 
                  if not (unify env result_typ et)
                  then failwith 
                    (spr "Expected a %s but got a %s\n    for %s\n" 
                      (typ2string et "")
                      (typ2string result_typ "")
                      (exp2string top_exp "")) 
                  else ()
              | _ -> () in
            let f_bvd = new_bvd (Some e1.p) in 
            let f_exp = bvd_to_exp f_bvd tf in
              result_typ, mkBindT env tf result_uvar e1 f_bvd (withsort (Exp_app(f_exp, v)) result_typ)
          else 
            failwith 
              (spr "Expected a function got a \n%A\nvs.\n%A\n" 
                (typ2string t1 "") 
                (typ2string t1' "" ))

(* TODO | Exp_tapp       of exp * typ  *) 

    | Exp_match (v, patlist, d) ->
        (* 1. Type v
           2. Type each pat
           3. Compare type of v to instantiated type
              of each id type
           4. Check that all pat types are equal
        *)
        let env', _ = Tcenv.clear_expected_typ env in
        let t_v, v' = telaborate_val_pure env v in
        let check_branch_kind t_branch = match t_branch.sort with
          | Kind_prop -> 
              (match t_v.sort with 
                 | Kind_prop -> () 
                 | _ -> 
                     raise 
                       (Tcutil.Error 
                         ("Cross-universe elimination on P-kinded types is not allowed", v.p)))
          | _ -> () in
        let expanded_t_v = Tcenv.expand_typ_rec env t_v in
        let t_d, d' = telaborate_exp_comp env d in
        let env = match Tcenv.expected_typ env with
          | None -> Tcenv.set_expected_typ env t_d
          | Some texp -> env
          in
        let process_pat (pi, branchi) =
          let pi', e_pi, bindings = 
            telaborate_pat (Tcenv.set_expected_typ env expanded_t_v) pi in
          let env_true, smapv, smapt = 
            List.fold_left 
              (fun (env, smapv, smapt) binding ->
                let env = Tcenv.push_local_binding env binding in
                  match binding with
                    | Tcenv.Binding_var (x,t) ->
                        let vx = 
                          AbsynUtils.bvd_to_exp 
                            (x,x) (t_withpos Typ_unknown dummyRange) in
                        let vx = withpos (Exp_ascribed(vx, t, [])) x.idRange in
                          env, ((x,x), vx)::smapv, smapt
                    | Tcenv.Binding_typ (a,k) ->
                        let ta = bvd_to_typ (a,a) Kind_unknown in
                        let ta = t_withpos (Typ_ascribed(ta,k)) a.idRange in
                          env, smapv, ((a,a), ta)::smapt)
              (env, [], []) bindings in
            let branchi = substitute_exp_val_l branchi smapv in
            let branchi = substitute_exp_typ_l branchi smapt in
            let env_true = 
              Tcenv.push_local_binding env_true (Tcenv.Binding_match(v', e_pi)) in
            let t_branchi, branchi' = telaborate_exp_comp env_true branchi in
            let _ = check_branch_kind t_branchi in
            let evidence =
              List.filter 
                (function 
                  | Tcenv.Binding_match _ 
                  | Tcenv.Binding_tmatch _ -> true 
                  | _ -> false)
                bindings
              |> List.map
                (function 
                  | Tcenv.Binding_tmatch(t1,t2) -> 
                      Inl(withsort (Typ_btvar t1) t1.sort, t2)
                  | Tcenv.Binding_match(e1,e2) -> Inr(e1,e2)) in
            let branchi' = ascribe branchi' t_branchi evidence in
              pi', branchi' in
        let typed_eqns = List.map process_pat patlist in
        let res_exp = Exp_match(v', typed_eqns, d') in
          t_d, withinfo res_exp t_d top_exp.p

    | Exp_cond (v, e1, e2) ->
        let t_v,v' = telaborate_val_pure (Tcenv.set_expected_typ env Const.bool_typ) v in
        let env_true, env_false = 
          if (AbsynUtils.is_value v') then
            let b1 = Tcenv.Binding_match (v', Const.exp_true_bool) in
            let b2 = Tcenv.Binding_match (v', Const.exp_false_bool) in
            Tcenv.push_local_binding env b1, Tcenv.push_local_binding env b2
          else env, env in
        let t_branch,e1' = telaborate_exp_comp env_true e1 in
        let _,e2' = telaborate_exp_comp (Tcenv.set_expected_typ env_false t_branch) e2 in
        let e' = withinfo (Exp_cond (v', e1', e2')) t_branch top_exp.p in
        t_branch, e'

(* TODO
    (* let r' = {r with f=1} *)
  | Exp_recd       of option<lident> * list<typ> * list<exp> * list<fieldname * exp>  
  | Exp_proj       of exp * fieldname 
*)

    | Exp_ascribed (e, ascribed_t, evidence) ->
        let env, topt = Tcenv.clear_expected_typ env in
        let t',e' = telaborate_exp_comp env e in
        let ascribed_t' = elaborate_ascribed_comp_typ env ascribed_t in
        if not (unify env ascribed_t' t')
        then failwith 
          (spr "Inferred type %s does not match ascription %s\n    for %s\n"
            (typ2string ascribed_t' "")
            (typ2string t' "")
            (exp2string top_exp "            "))
        else
          (match topt with
            | None    -> t', e'
            | Some et -> 
                if unify env et t' then
                  t', e'
                else 
                  failwith 
                    (spr "Expected %s but got %s\n   for %s\n" 
                      (typ2string et "") 
                      (typ2string t' "") 
                      (exp2string top_exp "")))

    | Exp_let(false, [(x,t,e')], body) when AbsynUtils.is_value e' ->
        (* 1. Type and elaborate e'
           2. Generalize the type of e'
           3. Compare with t
           4. Add to environment and type body
        *)
        let t', e' = telaborate_val_pure env e' in
        let t', e' = Tcutil.generalize env t' e' in
        (* TODO: how to compare types *)
        if is_Typ_unknown t or unify env t t'
        then
          let env = Tcenv.push_local_binding env (Tcenv.Binding_var(real_name x, t')) in 
          let t_body, body' = telaborate_exp_comp env body in
          t_body, withinfo (Exp_let (false, [(x, t', e')], body')) t_body top_exp.p
        else
          failwith (spr "Ascription '%A' does not match inferred type '%A'." t t')
    | Exp_let(false, [(x,t,e')], body) ->
        (* 1. Type and elaborate e'
           2. Generalize the type of e'
           3. Compare with t
           4. Add to environment and type body
        *)
        let t', e' = telaborate_exp_comp env e' in
        (* TODO: how to compare types *)
        if is_Typ_unknown t or unify env (MonadicElaboration.mkST env t) t'
        then
          (* t' = ST 'a *)
          let t_a = MonadicElaboration.stripST t' in
          let env = Tcenv.push_local_binding env (Tcenv.Binding_var(real_name x, t_a)) in 
          let t_body, body' = telaborate_exp_comp env body in
          (* t_body = ST 'b *)
          let t_b = MonadicElaboration.stripST t_body in
          t_body, mkBindT env t_a t_b e' x body'
        else
          failwith (spr "Ascription '%A' does not match inferred type '%A'." t t')
    | Exp_let (true, letList, body) -> 
        let update_letrec_env env (x, t, e') =
          match t.v with
            | Typ_unknown ->
                let u = TypeRelations.new_uvar env Kind_star dummyRange in 
                Tcenv.push_local_binding env (Tcenv.Binding_var(real_name x,u))
            | _ -> 
                Tcenv.push_local_binding env (Tcenv.Binding_var(real_name x,t))
          in
        let process_let env (bvd, t, e') =
          match e'.v with
            | Exp_abs _ -> 
                let t',e' = telaborate_val_pure env e' in
                bvd, t, e'
            | _ ->
                let msg = 
                  Printf.sprintf
                    ("Recursive let statements must bind abstraction values.\
                    The expression being bound is a %s")
                    (Pretty.strExp e') in
                raise (Tcutil.Error (msg, top_exp.p))
          in
        let env = List.fold_left update_letrec_env env letList in
        let letList' = List.map (process_let env) letList in
        let t_body, body' = telaborate_exp_comp env body in
        t_body, withinfo (Exp_let (true, letList', body')) t_body top_exp.p

(* TODO
  | Exp_gvar       of int  (* only for internal use by proof extraction. unbound variable deBruijn index *) 
  | Exp_extern_call of Sugar.externref * ident * typ * list<typ> * list<exp>
*)

    | Exp_primop(op, args) -> 
        (match Tcenv.lookup_operator env op with
          | None -> raise (Tcenv.Err ("Unknown operator: "^op.idText))
          | Some t -> 
              let args_rev, result_typ = List.fold_left 
                (fun (args, t) arg -> match t.v with 
                     Typ_fun(xopt, t_arg, t_ret) -> 
                       let env = Tcenv.set_expected_typ env t_arg in
                       let t',arg = telaborate_val_pure env arg in
                       let t_ret = match xopt with
                         | None -> t_ret
                         | Some x -> substitute_exp t_ret x arg in
                         arg::args, t_ret
                   | _ -> 
                       let msg = 
                         spr "Too many arguments to operator %s, (e.g., %s is extra)" 
                           op.idText 
                           (Pretty.strExp arg) in
                         raise (Tcenv.Err msg)) ([], t) args in
              let _ = match result_typ.v with 
                | Typ_fun _ -> 
                    raise 
                      (Tcutil.Error 
                        (spr "All operators must be fully-applied\n%s" 
                          (Pretty.strExp top_exp), 
                          top_exp.p))
                | _ -> () in
                let t' = MonadicElaboration.mkST env result_typ in
                let e' = 
                  mkReturnT 
                    env 
                    result_typ 
                    (withinfo (Exp_primop(op, List.rev args_rev)) result_typ top_exp.p) in
                  t', e')

    | Exp_bot -> failwith "Type inference encountered Exp_bot."

    | _ -> failwith (spr "unexpected %s" (exp2string top_exp ""))

and telaborate_val_pure (env:Tcenv.env) (e:exp) : (typ * exp) =
  let inst_variable env exp sigma : (typ * exp) = 
    let t, alphas = 
      let t, alpha_bindings = TypeRelations.instantiate_typ env sigma in
        t, (List.unzip alpha_bindings |> snd) in
      List.fold_left (fun (sigma, exp) alpha -> 
                        let sigma' = ignore_formula_open_typ_with_typ sigma alpha in (* (open_typ_with_typ forall a.t t') --> t[t'/a] *)  (* NS -- ignoring formula *)
                        let exp' = {v=Exp_tapp(exp, alpha);
                                    sort=sigma';
                                    p=exp.p} in 
                          sigma', exp') (sigma, exp) alphas in
  let t,e' = 
    match e.v with
      | Exp_bvar bv -> 
          (* 1. lookup type scheme in env 
             2. instantiate type scheme producing type arguments
             3. elaborate to a type application *)
          let sigma = Tcenv.lookup_bvar env bv in
            inst_variable env (setsort e sigma) sigma

      | Exp_fvar(fv, _) -> 
          (match Tcenv.lookup_fvar env fv with
             | None -> failwith "variable not found" (* TODO: nicer error *)
             | Some sigma -> 
                 inst_variable env (setsort e sigma) sigma)
    
      | Exp_constant c ->
          let t = Tcutil.typing_const env c in
            t, setsort e t

        (* TODO: handle type args *)
      | Exp_constr_app(cname, targs, [], vargs) -> 
          let ctyp, tps = match Tcenv.lookup_fvar_with_params env cname with
            | None -> raise (Tcenv.Err ("Variable not found: "^(Sugar.text_of_lid cname.v)))
            | Some t -> t
            in
          let inst_ctyp, targs' = instantiate_typ env ctyp targs in
          let env, topt = Tcenv.clear_expected_typ env in
          let inst_ctyp, subst = match topt, tps with
            | None, [] -> inst_ctyp, []
            | None, _ -> 
                let msg = 
                  spr 
                    "Cannot infer term indices for constructed type %s; a type annotation may help" 
                    (Pretty.strTyp ctyp)
                  in
                raise (Tcutil.Error (msg, e.p))
            | Some et, _ -> 
                let inst_ctyp, subst = 
                  TypeRelations.try_instantiate_final_typ env tps inst_ctyp et in
                  inst_ctyp, subst
            in
          let vargs_rev, result_typ = 
            List.fold_left 
            (fun (arglist, ctyp) arg -> match ctyp.v with 
               | Typ_fun (bvd_opt, arg_typ, ret_typ) -> 
                   let env' = Tcenv.set_expected_typ env arg_typ in 
                   let t', arg' = telaborate_val_pure env' arg in 
                   let ret_typ' = match bvd_opt with 
                       None -> ret_typ
                     | Some bvd -> substitute_exp ret_typ bvd arg' in
                   (* TODO: kinding to ensure non-value expressions don't escape into types *)
                   (* let ret_typ', _ = kinding env {ret_typ' with p=top_exp.p} in *)
                     (arg'::arglist, ret_typ')
               | _ -> 
                   let msg = 
                     spr "Too many arguments to constructor %s, (e.g., %s is extra)" 
                       (Pretty.str_of_lident cname.v) 
                       (Pretty.strExp arg) 
                       in
                     raise (Tcenv.Err msg)) ([], inst_ctyp) vargs 
            in
          let _ = match result_typ.v with 
              Typ_fun _ 
            | Typ_univ _ -> 
                raise (Tcutil.Error (spr "All data constructors must be fully-applied\n%s" (Pretty.strExp e), e.p))
            | _ -> () in
          let ctyp = List.fold_left (fun ctyp (bvd, e) -> 
                                       substitute_exp ctyp bvd e) ctyp subst in
          let cname' = setsort cname ctyp in
          let vargs' = List.rev vargs_rev in
            result_typ, withinfo (Exp_constr_app(cname', targs', [], vargs')) result_typ e.p

      | Exp_abs (x, {v=Typ_unknown}, body) -> 
          (*  1. Generate a new unification variable, u
              2. Push (x:u) into the environment
              3. Type the body
              4. produce a function type, and elaborate *)
          let u = TypeRelations.new_uvar env Kind_star e.p in 
          let env = Tcenv.push_local_binding env (Tcenv.Binding_var(real_name x, u)) in 
          let tbody, body = telaborate_exp_comp env body in
          let tresult = withsort (Typ_fun(Some x, u, tbody)) Kind_star in
          let result = withinfo (Exp_abs(x, u, body)) tresult e.p in
            tresult, result

(*      TODO: what do we do when the type is known? *)
      | Exp_abs (x, t, body) ->     
          let u = TypeRelations.new_uvar env Kind_star e.p in 
          let env = Tcenv.push_local_binding env (Tcenv.Binding_var(real_name x, u)) in 
          let tbody, body = telaborate_exp_comp env body in
          let tresult = withsort (Typ_fun(Some x, u, tbody)) Kind_star in
          let result = withinfo (Exp_abs(x, u, body)) tresult e.p in
          if unify env t u
          then tresult, result
          else failwith (spr "Ascription 'x:%A' does not match inferred argument of '%A'." t tresult)
          
      | _ -> failwith (spr "unexpected %A" e)
    in
  let env, topt = Tcenv.clear_expected_typ env in
    match topt with
      | None -> t, e'
      | Some et -> 
        if unify env t et
        then t,e'
        else 
          failwith 
            (spr 
              "val_pure expected %s got %s\n    for %s\n" 
              (typ2string et "") 
              (typ2string t "")
              (exp2string e "")) (* TODO: nicer error *)

and telaborate_pat env pat : (pat * exp * list<Tcenv.binding>) =
  match pat with
    | Pat_variant(lid, targs, [], pat_bvars, _) when not !Util.gadt -> 
        let t_d, phantom_params = match Tcenv.lookup_fvar_with_params env (AbsynUtils.W lid) with
          | None -> raise (Tcenv.Err (spr "Constructur %s not found" (Pretty.str_of_lident lid)))
          | Some (t,tps) -> t, tps in
        let datacon = withinfo lid t_d (Sugar.range_of_lid lid) in
        let inst_t_d, targs' = instantiate_typ env t_d targs in
        let rec mk_vargs (outb,outv) (vargs:list<bvar<typ>>) inst_t = 
          match inst_t.v, vargs with 
            | Typ_fun (formal_opt, targ, tres), bv::vrest -> 
                let bv' = setsort bv targ in
                let exp = withinfo (Exp_bvar bv') targ bv'.p in
                let trest = open_typ_with_exp inst_t exp in  (* open_typ ((x:t) -> t') e  subs e for x in t' *)
                let binding = Tcenv.Binding_var (bvar_real_name bv', targ) in
                  mk_vargs (binding::outb, bv'::outv) vrest trest
            | Typ_fun _, [] -> raise (Tcenv.Err "Insufficient pattern variables")
            | _, hd::tl -> raise (Tcenv.Err "Too many pattern variables")
            | _, [] -> (outb,outv), inst_t in
        let (bindings_rev, pat_bvars_rev), final_typ = mk_vargs ([],[]) pat_bvars inst_t_d in
        let final_typ, bindings_rev, pat_bvars_rev, phantoms = 
          match Tcenv.expected_typ env, phantom_params with 
            | _, [] -> final_typ, bindings_rev, pat_bvars_rev, []
            | Some expected_t, tps -> 
                let pat_exp = Exp_constr_app(datacon, 
                                             targs', [], 
                                             List.rev (List.map (fun bv -> withsort (Exp_bvar bv) bv.sort)
                                                         pat_bvars_rev)) in
                let env = Tcenv.set_current_value env (AbsynUtils.W pat_exp) in
                let env = 
                  List.fold_right 
                    (fun binding env -> Tcenv.push_local_binding env binding) 
                    bindings_rev 
                    env in
                let inst_final_typ, subst = 
                  TypeRelations.try_instantiate_final_typ env tps final_typ expected_t in
                let bindings_rev = 
                  List.map 
                    (fun (Tcenv.Binding_var (bv, t)) -> Tcenv.Binding_var(bv, substitute_exp_l t subst)) 
                    bindings_rev in
                let pat_bvars_rev = 
                  List.map 
                    (fun bv -> setsort bv (substitute_exp_l bv.sort subst)) 
                    pat_bvars_rev in
                let phantoms = List.map (function 
                                           | Tparam_term(bvd, t) -> List.assoc bvd subst
                                           |  _ -> raise Impos) tps in
                  inst_final_typ, bindings_rev, pat_bvars_rev, phantoms in
        let pat' = Pat_variant(lid, targs', phantoms, List.rev pat_bvars_rev, false) in
        let pat_exp_args =  List.fold_left 
          (fun out bv -> 
             let ebv = withinfo (Exp_bvar bv) bv.sort ((bvar_ppname bv).idRange) in
               ebv::out) [] pat_bvars_rev in 
        let pat_exp = Exp_constr_app(datacon, targs', phantoms, pat_exp_args) in
        let abducts = match Tcenv.expected_typ env with 
            None -> []
          | Some et -> 
              let ftvs, fxvs = freevarsTyp et in 
              let equatable_xvars = pat_bvars_rev@fxvs in 
              let env' = List.fold_left Tcenv.push_local_binding env (List.rev bindings_rev) in
              let sopt = TypeRelations.instantiable env' equatable_xvars [] et final_typ in
                match sopt with 
                    None -> 
                      let sopt = 
                        TypeRelations.convertible_ev 
                          (Tcenv.set_current_value env' (withsort pat_exp final_typ)) 
                          et 
                          final_typ in
                        (match sopt with 
                           | None -> 
                               let msg = spr "Expected a pattern of type \n\t %s \nBut got pattern of type \n\t%s" 
                                 (Pretty.strTyp et) (Pretty.strTyp final_typ) in
                                 raise (Tcenv.Err msg)
                           | Some (subst, ev) -> 
                               AbsynUtils.warn_empty_ev ev;
                               let _ = Tcutil.unify_subst_vars subst in [])
                  | Some (subst, abducts) -> let _ = Tcutil.unify_subst_vars subst in abducts in
          pat', withsort pat_exp final_typ, (List.rev bindings_rev)@abducts

    | _ -> failwith "TODO: handle GADTs/refined tuples in matches"


(* Elaboration and inference of the simple ST type. *)
let telaborate_exp (env:Tcenv.env) (e:exp) : (typ * exp) =
  let t,e =
    if AbsynUtils.is_value e
    then telaborate_val_pure env e
    else telaborate_exp_comp env e
    in
  let t,e = Tcutil.generalize env t e in
    t, e
 
let elaborate_letbinding (env:Tcenv.env) ((lb,r):(letbinding * bool)) : (letbinding * bool) =
  let update_letrec_env env (x, t, e') : Tcenv.env =
    let val_name = List.append (Tcenv.current_module env) [(fst x)] in
    let val_t = 
      try Tcenv.lookup_val_decl env val_name 
      with _ -> withsort Typ_unknown Kind_star in
    match t.v,val_t.v with
      | Typ_unknown,Typ_unknown ->
          let u = TypeRelations.new_uvar env Kind_star dummyRange in 
          Tcenv.push_local_binding env (Tcenv.Binding_var(snd x,u))
      | Typ_unknown,_ -> 
          Tcenv.push_local_binding env (Tcenv.Binding_var(snd x,val_t))
      | _,Typ_unknown -> 
          Tcenv.push_local_binding env (Tcenv.Binding_var(snd x,t))
      | _,_ ->
          if unify env val_t t
          then 
            Tcenv.push_local_binding env (Tcenv.Binding_var(snd x,val_t))
          else
            failwith "Recursive let binding does not match its declared signature."
            (* TODO: better error *)
        in
  let env = 
    if r then
      List.fold_left update_letrec_env env lb
    else env in
  let do_lb (b, t, e) =
    let t',e' = telaborate_exp env e in
      (b, t', e')
  in
    pr "Original AST: \n%s\n\n" (letbinding2string (lb,r));
    let lb' = List.map do_lb lb in
      pr "New AST: \n%s\n\n" (letbinding2string (lb',r));
      (lb', r)

*)
