#light "off"
module Microsoft.FStar.MonadicElaboration

open Util
open Absyn
open MonadicPretty
open MonadicUtils

(*****************************************************************************)
(*                      Refined elaboration functions                        *)
(*****************************************************************************)

type constants = Tcenv.env

(* Invariants:
 *   - top_exp.sort must be Typ_meta.
 *   - If e is a returned expression, e.sort has a type (ST pre t post) 
 *       for t a small_type, and pre and post computed from the Typ_meta
 *)
let rec refined_elaborate_exp_comp consts (top_exp:exp) : exp = failwith "disabled"

  (* let top_exp, pre, post, optRe = *)
  (*   if isRefinedMeta top_exp.sort *)
  (*   then *)
  (*     let t, p, po, re = unpack_refined_meta top_exp in  *)
  (*       t, p, po, (Some re) *)
  (*   else  *)
  (*     let t, p, po = unpack_meta top_exp in *)
  (*       t, p, po, None in *)
  (* let res_exp =  *)
  (*   match top_exp.v with *)
  (*     | Exp_abs _  *)
  (*     | Exp_tabs _ -> failwith "Impossible: monadicInference is always first-order" *)
          
  (*     | _ when AbsynUtils.is_value top_exp ->  *)
  (*         let e = refined_elaborate_val_pure consts top_exp in *)
  (*           mkReturn consts post e *)
  
  (*     | Exp_tapp _ -> failwith "Impossible: type applications can only arise with normal applications" *)
              
  (*     | Exp_app (e, v) ->  *)
  (*         (\* Handle curried functions specially. *\) *)
  (*         let rec process_app (e_app:exp) : exp = *)
  (*           (\* Elaborate each value and finally the function itself. *\) *)
  (*           match e_app.v with *)
  (*             | Exp_app (e, v) -> *)
  (*                 let e' = process_app e in *)
  (*                 let v' = refined_elaborate_val_pure consts v in *)
  (*                   withinfo (Exp_app(e',v')) e_app.sort e_app.p *)
  (*             | Exp_tapp (e, t) -> *)
  (*                 let e' = process_app e in *)
  (*                   withinfo (Exp_tapp(e', t)) e_app.sort e_app.p *)
  (*             | Exp_ascribed(e, t, ev) ->  *)
  (*                 let e' = process_app e in  *)
  (*                 let _ = match e'.v with *)
  (*                   | Exp_ascribed _ -> failwith "Ascribing an ascription." *)
  (*                   | _ -> () in *)
  (*                   withinfo (Exp_ascribed(e', t, ev)) e_app.sort e_app.p *)
  (*             | _ -> refined_elaborate_val_pure consts e_app in *)
            
  (*         (\* Elaborate app *\) *)
  (*         let app = process_app top_exp in *)
  
  (*         (\* If app.sort is not an ST type, then treat it as a pure *)
  (*          * function application. *\) *)
  (*         (\* If optRe is None, then the application is stateful; otherwise, *)
  (*          * it's pure. *)
  (*          *\) *)
  (*         (match optRe with *)
  (*           | Some re -> *)
  (*               (\* Elaborate app into *)
  (*                * let x = app in return_st x *)
  (*                *\) *)
  (*               let x_bvd = new_bvd None in *)
  (*               let x_exp = bvd_to_exp x_bvd app.sort in *)
  
  (*               (\* return_st<post> x *\) *)
  (*               let return_exp = mkRefinedReturn consts post x_exp re in *)
  
  (*               (\* let x = app in return_st<post> x *\) *)
  (*               withinfo  *)
  (*                 (Exp_let(false,[(x_bvd,re,app)],return_exp))  *)
  (*                 return_exp.sort  *)
  (*                 app.p *)
  (*           | None -> *)
  (*               (\* The full application of any function must return an ST type, *)
  (*                * but the inference types Exp_app with Pre t Post instead, so *)
  (*                * construct the ST.  (Note that this may be different than the *)
  (*                * result type of the underlying function. *)
  (*                *\) *)
  (*               let app_t = mkST consts pre app.sort post in *)
                  
  (*                 setsort app app_t) *)
  
  (*     | Exp_match(v, pats, edef) ->  *)
  (*         (\* Invariant: expect the return types of all branches *)
  (*            to match each other and the sort of the returned expression. *\) *)
  (*         let result_t = mkST consts pre top_exp.sort post in *)
  (*         let v = refined_elaborate_val_pure consts v in  *)
  (*         let elab_pat (pat, branch) =  *)
  (*           (pat, refined_elaborate_exp_comp_at_typ consts branch result_t) in  *)
  (*         let pats = pats |> List.map elab_pat in *)
  (*         (\* Ignore edef if it's bot *\) *)
  (*         let edef = match edef.v with *)
  (*           | Exp_bot -> edef *)
  (*           | _ -> refined_elaborate_exp_comp_at_typ consts edef result_t in  *)
  (*           withinfo (Exp_match(v, pats, edef)) result_t top_exp.p *)
              
  (*     | Exp_cond (v, e1, e2) ->  *)
  (*         (\* Invariant: expect the return types of elaborated e1 and e2  *)
  (*            to match each other and the sort of the returned expression. *\) *)
  (*         let result_t = mkST consts pre top_exp.sort post in  *)
  (*         let v' = refined_elaborate_val_pure consts v in *)
  (*         let e1' = refined_elaborate_exp_comp_at_typ consts e1 result_t in *)
  (*         let e2' = refined_elaborate_exp_comp_at_typ consts e2 result_t in *)
  (*           withinfo (Exp_cond(v', e1', e2')) result_t top_exp.p *)
  
  (*     | Exp_ascribed (e, t, ev) -> *)
  (*         (\* Any ascriptions we receive after inference should be in the *)
  (*          * target language. *\) *)
  (*         let e' = refined_elaborate_exp_comp consts e in *)
  (*         let _ = match e'.v with *)
  (*           | Exp_ascribed _ -> failwith "Ascribing an ascription." *)
  (*           | _ -> () in *)
  (*         let result_t = mkST consts pre top_exp.sort post in *)
  (*         withinfo (Exp_ascribed (e', t, ev)) result_t top_exp.p *)
            
  (*     | Exp_let(false, [(x,t,e)], body) when AbsynUtils.is_value e -> *)
  (*         let result_t = mkST consts pre top_exp.sort post in  *)
  (*         let e' = refined_elaborate_val_pure consts e in *)
  (*         let body' = refined_elaborate_exp_comp_at_typ consts body result_t in *)
  (*           withinfo (Exp_let(false, [(x,t,e')], body')) result_t top_exp.p *)

  (*     | Exp_let(false, [(x,t,e)], body) when (not (MonadicUtils.small_type consts t)) ->  (\* partial apps *\) *)
  (*         let result_t = mkST consts pre top_exp.sort post in  *)
  (*         let e' = elaborate_pure_partial_app consts e in *)
  (*         let body' = refined_elaborate_exp_comp_at_typ consts body result_t in *)
  (*           withinfo (Exp_let(false, [(x,t,e')], body')) result_t top_exp.p *)

  (*     | Exp_let(false, [(x,t,e)], body) ->  *)
  (*         let e' = refined_elaborate_exp_comp consts e in *)
  (*         let body' = refined_elaborate_exp_comp consts body in *)
  (*           mkRefinedBind consts e' x body' *)
  
  (* (\* TODO: recursive let statements *\) *)
  (*     | Exp_let(true, [(x,t,e)], body) -> todo () *)
      
  (*     | Exp_primop(op, args) -> *)
  (*         (\* Primitive operators are assumed to be pure. *\) *)
  (*         let args' = List.map (refined_elaborate_val_pure consts) args in *)
  (*         let app = withinfo (Exp_primop(op, args')) top_exp.sort top_exp.p in *)
  
  (*         (\* Elaborate app into *)
  (*          * let x = app in return_st x *)
  (*          *\) *)
  (*         let x_bvd = new_bvd None in *)
  (*         let x_exp = bvd_to_exp x_bvd app.sort in *)
  
  (*         (\* Get the refinement *\) *)
  (*         let re = match optRe with *)
  (*           | Some re -> re *)
  (*           | None -> raise Impos in *)
  
  (*         (\* return_st<post> x *\) *)
  (*         let return_exp = mkRefinedReturn consts post x_exp re in *)
  
  (*         (\* let x = app in return_st<post> x *\) *)
  (*         withinfo  *)
  (*           (Exp_let(false,[(x_bvd,re,app)],return_exp))  *)
  (*           return_exp.sort  *)
  (*           app.p *)
  
  (*     | Exp_bot ->  *)
  (*         let result_t = mkST consts pre top_exp.sort post in  *)
  (*           withinfo Exp_bot result_t top_exp.p *)
              
  (*     | _ -> failwith (spr "unexpected %s\n" (exp2string top_exp "")) in *)
  (* match res_exp.sort.v with *)
  (*   | Typ_meta _ -> *)
  (*       failwith  *)
  (*         (spr "Meta escaped elaboration: %s\n"  *)
  (*           (Pretty.strTyp res_exp.sort))  *)
  (*   | _ -> res_exp *)

and refined_elaborate_exp_comp_at_typ consts e t = failwith "disabled"
  (* let e = refined_elaborate_exp_comp consts e in  *)
  (* (\* Sanity check *\) *)
  (* let _ = match t.v, e.sort.v with *)
  (*   | Typ_meta _, _ ->  *)
  (*       failwith (spr "Ascribing a meta: %s" (Pretty.strTyp t)) *)
  (*   | _, Typ_meta _ ->  *)
  (*       failwith (spr "Ascribing to an exp with type meta: %s : %s"  *)
  (*         (Pretty.strExp e) (Pretty.strTyp e.sort)) *)
  (*   | _,_ -> () in *)
  (* let _ = match e.v with *)
  (*   | Exp_ascribed _ -> failwith "Ascribing an ascription." *)
  (*   | _ -> () in *)
  (*   withinfo (Exp_ascribed(e, t, [])) t e.p *)

and elaborate_pure_partial_app consts (e:exp) : exp = failwith "disabled"
  (* match e.v with  *)
  (*   | _ when AbsynUtils.is_value e -> refined_elaborate_val_pure consts e *)
  (*   | Exp_app(e1, v1) ->  *)
  (*       let e1 = elaborate_pure_partial_app consts e1 in  *)
  (*       let v1 = refined_elaborate_val_pure consts v1 in  *)
  (*         withinfo (Exp_app(e1, v1)) e.sort e.p *)
  (*   | Exp_tapp(e1, t) ->  *)
  (*       let e1 = elaborate_pure_partial_app consts e1 in  *)
  (*         withinfo (Exp_tapp(e1, t)) e.sort e.p *)
  
and refined_elaborate_val_pure consts (top_exp:exp) : exp = failwith "disabled"
  (* let e =  *)
  (* match top_exp.v with *)
  (*   | Exp_bvar _ *)
  (*   | Exp_fvar _ *)
  (*   | Exp_recd _  *)
  (*   | Exp_constant _ -> top_exp *)

  (*   | Exp_constr_app(cname, targs, [], vargs) ->  *)
  (*       let vargs' = List.map (refined_elaborate_val_pure consts) vargs in *)
  (*         withinfo (Exp_constr_app(cname, targs, [], vargs')) top_exp.sort top_exp.p *)

  (*   | Exp_abs _ ->  *)
  (*       (\* Handle curried functions. *\) *)
  (*       let rec process_abs (e:exp) : exp = *)
  (*         match e.v with *)
  (*           | Exp_abs (x, t, body) -> *)
  (*               let body' = process_abs body in *)
  (*               let t' =  *)
  (*                 withinfo (Typ_fun (Some x, t, body'.sort)) Kind_star e.sort.p in *)
  (*                 withinfo (Exp_abs(x, t, body')) t' e.p *)
  (*           | _ ->  *)
  (*               refined_elaborate_exp_comp consts e in *)
  (*         process_abs top_exp *)

  (*   | Exp_tabs(a, k, p, e) ->  *)
  (*       withinfo (Exp_tabs(a, k, p, refined_elaborate_val_pure consts e)) top_exp.sort top_exp.p *)
          
  (*   | Exp_ascribed(v, t, []) -> *)
  (*       withinfo (Exp_ascribed(refined_elaborate_val_pure consts v, t, [])) top_exp.sort top_exp.p *)
        
  (*   | _ -> failwith (spr "unexpected %s" (exp2string top_exp "")) *)
  (* in *)
  (*   if isRefinedST e.sort then failwith (spr "Elaborated to refined ST: \n%s\n\n" (exp2string top_exp "")) else e *)
      
let refined_elaborate_letbinding consts ((lb,r):(letbinding * bool)) : (letbinding * bool) = failwith "disabled"
  (* let do_lb (x, t, e) = *)
  (*   (\* TODO: don't assume all top-level letbindings bind values *\) *)
  (*   let e' = refined_elaborate_val_pure consts e in *)
  (*     (x, e'.sort, e') in *)
  (* let lb' = List.map do_lb lb in *)
  (*   (lb', r) *)

