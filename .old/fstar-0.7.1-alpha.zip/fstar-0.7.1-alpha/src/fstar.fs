#light "off"
module Microsoft.FStar.FStar

open Microsoft.FSharp.Compiler
open Microsoft.FStar
open System.IO
open Util
open Options 
open Getopt
open Profiling 

#if CERTIFY
open AbsynToCoretyping
#endif

    
let process_args () = 
  let file_list = ref [] in
  let res = parse_cmdline Options.specs (fun i -> file_list := !file_list @ [i]) in
    (match res with
       | GoOn -> ignore (Options.set_fstar_home ())
       | _ -> ());
    (res, !file_list)

let monadic_tc tcenv mods = 
  let typedMods, env = List.fold_left 
    (fun (typedModules, env) (modul:Absyn.modul) -> 
       let _ = printf "monadic_tc: %s\n" (Absyn.sli modul.name) in
       let env = Tcenv.set_current_module env modul.name in
       let m = Monadic.typing_modul env modul in
         (match m with 
            | Some m -> 
                let env' = Tcenv.push_module env m in                        
                  m::typedModules, env'
            | None -> raise (Failure ("Type checking failed: " ^(Pretty.str_of_lident modul.name))))) ([], tcenv) mods in
    List.rev typedMods, env

let tc tcenv mods =
  let typedMods, env = List.fold_left 
    (fun (typedModules, env) (modul:Absyn.modul) -> 
      let env = Tcenv.set_current_module env modul.name in
      let m = profile (fun () -> Tc.typing_modul env modul) "Typechecking" in
      (match m with 
          Some m -> 
            let env' = Tcenv.push_module env m in                        
            m::typedModules, env'
        | None -> raise (Failure ("Type checking failed: " ^(Pretty.str_of_lident modul.name))))) ([], tcenv) mods in
  List.rev typedMods, env

let desugar pragmas (tcenv, dsenv) sugar = 
  let hasMod (mlist:List<Absyn.modul>) (mname:string) = 
    List.fold 
      (fun (acc:bool) (e:Absyn.modul) -> 
        if acc then acc else Pretty.sli e.name = mname)
      false
      mlist in
  let name = Sugar.module_name sugar in
  (match !Options.dump_module, name with 
    | Some nm, Some nm' when nm = nm' -> pr "%A\n" sugar; 
    | _ -> ());
  let dsenv, mods = Desugar.desugar pragmas dsenv sugar in
  let monadic =
    (!Options.monadic || List.exists (function Sugar.PRAGMA_MONADIC _ -> true | _ -> false) pragmas)
    && (not ((hasMod mods "Prims") || hasMod mods "ProofLib")) in
  (*let _ = if !Util.dump_src then List.iter Pretty.printModule mods in*)
  let anf_mods = if !Options.no_anf then mods else List.map (Anf.anf_module monadic) mods in
  let _ = List.iter2 (fun (m_orig:Absyn.modul) (m_anf:Absyn.modul) ->
                        let _ = match !Options.dump_module with
                          | Some nm when nm = Pretty.str_of_lident m_orig.name ->
                            ( pr "Original module\n%A\n" m_orig;
                              fpr stderr "ANF module\n"; 
                              Pretty.printModule m_anf;
                              pr "\n%A\n" m_anf;
                            );
                          | _ -> () in
                          if (Pretty.str_of_lident m_orig.name).EndsWith("_js")
                          then
                            let nm = Pretty.str_of_lident m_orig.name in
                            let nm = nm.Substring(0, nm.Length - 3) in
                            writeFile (spr "%s.js.fst" nm) (Pretty.strModule {m_orig with name=Const.p2l [nm]}))
    mods anf_mods in
  monadic, dsenv, anf_mods


let desugar_and_tc pragmas (tcenv, dsenv) sugar = 
  let monadic, dsenv, anf_mods = desugar pragmas (tcenv, dsenv) sugar in 
  let tmods, tcenv = 
    if monadic
    then monadic_tc tcenv anf_mods 
    else tc tcenv anf_mods in
  let tmods = if !addGK then snd(GateKeeperPass.trans tmods) else tmods in
  tmods, (tcenv, dsenv)

let parse (filename:Disj<string,string>) =  
  (if !Options.new_parser 
   then Parse.parse filename
   else Parser.parse filename) |>  
      (function 
        | (Sugar.ParsedImplFile _ as x) -> [], x
        | Sugar.ParsedImplFileWithPragmas(x, p) -> p, (Sugar.ParsedImplFile x))
  
let parse_and_tc envs (filename:Disj<string,string>) = 
#if JS
  if filename.EndsWith(".js")
  then 
    let sugar = Microsoft.JScript.StaticAnalysis.ASTBridge.ProcessFile(filename) in 
    (* let _ = if not !Options.silent then pr "JS translated to F* sugar: \n %A\n" sugar in  *)
    let mtyp = Sugar.Type_lid (Const.DST_lid, Absyn.dummyRange) in
    let mrettx = Sugar.Type_lid(Const.returnTX_lid, Absyn.dummyRange) in
    let mcomposetx = Sugar.Type_lid(Const.bindTX_lid, Absyn.dummyRange) in
      desugar_and_tc [Sugar.PRAGMA_MONADIC(mtyp, mrettx, mcomposetx)] envs sugar
  else
#endif
  let p, x = parse filename in 
  desugar_and_tc p envs x  

#if F7
let doF7 (tcenv,dsenv) filenames = 
  let trim(filename:string) =
    let pos = filename.LastIndexOf "/" in
      if pos = -1 then filename
      else  filename.Substring (pos + 1) in
  let basename name = let [bn;ext] = String.split ['.'] (trim name) in bn in
  let from_function f = 
    LexBuffer<char>.FromByteFunction(f) in
  let from_text_reader (enc: System.Text.Encoding) (tr: TextReader) =
    from_function (fun bytebuf len ->
                     /// Don't read too many characters!
                   let lenc = (len * 99) / enc.GetMaxByteCount(100) in 
                   let charbuf : char[] = Array.zeroCreate lenc in
                   let nRead = tr.Read(charbuf,0,lenc) in
                     if nRead = 0 then 0 
                     else enc.GetBytes(charbuf,0,nRead,bytebuf,0)) in
  let has_kind s (f:string) = f.EndsWith("."^s) in
  let isFs7 f = has_kind "fs7" f  || has_kind "mli" f || has_kind "fsi" f  || has_kind "ml7" f  in
  let parseFs7 (filename:string) = 
    if not (isFs7 filename)  
    then (printf "The file %s is not a .fs7 file\n" filename;  exit 1)
    else
      let lb = (Microsoft.FSharp.Text.Lexing.LexBuffer<char>.FromTextReader(new System.IO.StreamReader(filename))) in
        lb.StartPos <- {lb.StartPos with pos_fname = (trim filename)};
        let ast = 
          try Fs7Pars.start Fs7Lex.token lb
          with e ->
            let pos = lb.EndPos in
              printf "ERROR: Syntax error near line %d, character %d in file %s\n" (pos.pos_lnum+1) (pos.pos_cnum - pos.pos_bol) filename;
              exit 0 in
          ast in
  let isImpl fs7 filename = (basename fs7) = (basename filename) in
  let mkAssoc filenames = 
    let fs7s, impls = List.partition isFs7 filenames in
    let result = List.fold_left (fun out fs7 -> (fs7, List.tryFind (isImpl fs7) impls)::out) [] fs7s  |> List.rev in
      if List.forall (fun impl -> List.exists (function (_, Some impl') -> impl=impl' | _ -> false) result) impls then 
        result
      else failwith "Some implementation files are missing a corresponding fs7" in
  let fs7_impls = mkAssoc filenames in
  let sugarOfF7 (fs7, impl_opt) = 
    (* let _ = pr "Parsing FS7 %s\n" fs7 in *)
    let fs7 = parseFs7 fs7 in
    let sugarfs7 = TransFs7.modulOfFs7 fs7 in
      match impl_opt with 
          None -> Sugar.ParsedImplFile [sugarfs7] 
        | Some f7 ->  
            let f7 = Parser.parse f7 in
              TransFs7.merge sugarfs7 f7 in
  let sugars = "Parser" ^^ lazy List.map sugarOfF7 fs7_impls in 
  let env, tmods = List.fold_left (fun (env, out) sugar -> 
                                     (* if (Sugar.module_name sugar) = Some "Test" then  *)
                                       (* pr "Desugaring and type-checking module %A\n" sugar; *)
                                     let tmod, env = desugar_and_tc [] env sugar in
                                       (env, tmod@out)) ((tcenv, dsenv), []) sugars in
  let _ = pr "Type-checked F7 modules\n" in
  let tmods = List.rev tmods in
  let _ = tmods |> List.iter (fun m -> pr "%s\n" (Pretty.str_of_lident m.name)) in 
  tmods, env
#else
let doF7 _ _ = raise Impos
#endif

#if NOCERT
 let startClock () = ()
 let messageWithTime msg = ()
#else
let startClock, messageWithTime = 
    let s = ref None in 
    let start () = match !s with None -> failwith "Clock not initialized" | Some s -> s in 
    (fun () -> s := Some System.DateTime.Now), 
    (fun msg -> 
       let elapsed = System.DateTime.Now - (start()) in 
        Util.pr "%f: %s\n" (elapsed.TotalSeconds) msg)
#endif 

let rec printCompletionMessage : Absyn.modul list -> unit = function
  | m::tl -> 
      Util.err "Verified module: %s\n" (Sugar.text_of_lid m.name);
      printCompletionMessage tl 
  | [] -> messageWithTime "Done"; () 

#if NOCERT
 let doBackend env fmods preludeMod proofMod prelude_tcenv solver : string option = 
   match !Options.output_js with
     | Some (fname : string) -> 
       let stmt = Microsoft.FStar.ToJS.Absyn2JSMin.translate_modules (preludeMod::fmods) in
       if fname = "[string]" then Some (stmt.ToString())
       else (let writer = new System.IO.StreamWriter(fname) in
             writer.Write(stmt.ToString());
             writer.Close ();
             None)
     | _ -> None

#else
let expand_types env mods = 
  let env = Tcenv.clear_current_state env in
    List.map (fun m -> 
                let m' = Expandtyp.expand_typ_abbrevs env m in 
                (* let _ = pr "\n---------Before Expand Types--------\n" in *)
                (* let _ = Pretty.printModule m in  *)
                (* let _ = pr "\n---------After Expand Types--------\n" in *)
                (* let _ = Pretty.printModule m' in  *)
                  m') mods
      
let derefine env mods = 
  if !extract_proofs then 
    let dmods, env = List.fold_left 
      (fun (dmods, env) (modul:Absyn.modul) -> 
         let env = Tcenv.set_current_module env modul.name in
         let dmod = Derefine.derefine_modul env modul in
         let env' = Tcenv.push_module env dmod in                        
           dmod::dmods, env')
      ([], env) mods in
      (env, List.rev dmods)
  else env, mods

let translate tcenv rest = 
let _, t_rest = List.fold_left 
    (fun (pfx, out) (mref:Absyn.modul option ref) -> 
       match !mref with
         | Some m ->
           let externs = Translation.getExterns m in
           let _ = mref := None in   (* release the absyn module *)
           let name = Pretty.str_of_lident m.name in
           if !spl && name = "ProofLib" then externs@pfx, out
           else if (name <> "ProofLib" && name <> "Prims") 
                then let _ = if (not (name.Contains("Typing"))) then System.GC.Collect() in
                     let m' = Translation.transModule tcenv pfx m in 
                     (externs@pfx, m'::out)
                else (pfx, out)) ([],[]) rest in
    List.rev t_rest

#if CERTIFY
let absynToCoretyping mods =  
  let ctr = ref 0 in 
  let mctr = ref 0 in
  let doMod (env: transenv) (modul: Absyn.modul) =
    let _ = incr mctr in
    let env = transSig None env modul.signature in
    let modName = Pretty.str_of_lident modul.name in
    let icomp, fenv = transEnvToIcompFenv env in
    let (CoretypingUtil.DepTuple5(wfig, vls, tys, vlnames, tynames)) = Typing.checkWFIG icomp fenv in
    let modul = if !Options.no_anf then modul else Anf.anf_module false modul in
    let _ = if !Options.dump_src then Pretty.printModule modul in 
    let dirName = spr "%s/module%d" (get_cert_dir()) !mctr in
    let _ = if not(System.IO.Directory.Exists(dirName)) then (System.IO.Directory.CreateDirectory(dirName); ()) in
    let mkfilename nm = (spr "%s/%s.v" dirName nm) in 
    let wfiName = mkfilename "wfi" in
    let _ = Runtime.Pickler.clearBindings(true) in
    let _ = if !Options.print_certs then 
      (let envstream = System.IO.File.Create(wfiName) in 
         pr "\n Writing environment to %s " wfiName;
         PrettyPrintCoretyping.writeEnv env envstream; 
         pr "\n Writing wfi to %s " wfiName;
         Runtime.Pickler.writeWFI wfiName envstream wfig;
         Runtime.Pickler.flushFiles()) in
    let env, bindings = List.fold (fun (env, bindings) (letbinding, letrec) -> 
                                     let _ = incr ctr in 
                                     let ppname, typ = match letbinding with 
                                       | [(x:Absyn.bvvdef, typ, e)] -> 
                                           (* pr "Certifying letbinding %s: %s\n" (ppname.idText) (Pretty.strExp e) ; *)
                                           x.ppname, typ
                                       | _ -> pr "Unexpected letbinding shape: %A\n" letbinding; 
                                           raise Impos in
                                     let certMod = spr "cert%d" !ctr in 
                                     let certFile = mkfilename certMod  in
                                     let _ = pr "\n__________Typing let binding: %s____________\n" (ppname.idText) in
                                     let _ = if !Options.print_certs then 
                                       let _ = Runtime.Pickler.printfile certFile (spr "(* Certificate for %s *)" (ppname.idText)) in
                                       let _ = Runtime.Pickler.findStream certFile in 
                                         pr "Writing certificate to file \n%s\n" certFile in 
                                     let lbFreevars, name, e, t = doLetbinding env letbinding in 
                                     let (CoretypingUtil.DepTuple(fenv, wfig)) = 
                                       Typing.extendEnvironment icomp fenv (CoretypingUtil.primsListOfList lbFreevars) vls tys vlnames tynames wfig in
                                     let _ =  if !Options.print_certs then 
                                       (Runtime.Pickler.set_icomp icomp;
                                        Runtime.Pickler.set_gamma fenv) in
                                     let bindings = if letrec then Certify.pushBvarTy name t bindings else bindings in
                                     let _ = if !Options.print_certs then 
                                       let _ = Runtime.Pickler.printfile certFile (spr "(* Term %s is \n %A \n *)" 
                                                                                     (if letrec
                                                                                      then spr "(named (%s : %A))" name t
                                                                                      else "") e) in 
                                       let _ = fpr stderr "\n--------------------------------------------------------------------------------\n" in
                                         fpr stderr "%s (%s)\n" certFile (ppname.idText) in
                                     let result = Certify.certifyLetBinding letrec certFile icomp fenv wfig bindings name e in
                                     let _ = if !Options.print_certs then Runtime.Pickler.flushFiles () in
                                       (env, result.Certify_bindings))
      (env, new Prims.Nil<Env.locbinding>() :> Prims.list<'a>) modul.letbindings in 
      env in
    (* match modul.main with *)
    (*   | Some e ->  *)
    (*       let env, e' = transExp env e in  *)
    (*         env *)
    (*   | _ -> env in *)
    List.fold doMod emptyTransenv mods
#endif

#if MONO
#else
let tc_target (pfx :Target.tModule list) mods = 
  if !Options.skip_target_checker then Util.warn "UNSAFE---Skipping target checker!!!\n"
  else
    let _ = List.fold_left TargetChecker.checkModule 
      (Target.predefined::(List.map (fun (m:Target.tModule) -> m.decls) pfx))
      mods in
      ()

let translate_and_check tcenv dprelude dproof =
    let tprelude = Translation.transModule tcenv [] dprelude in
    let _ = pr "finished translating prelude \n" in
    let tproof = Translation.transModule tcenv (Translation.getExterns dprelude) dproof in
    let _ = pr "finished translating proof \n" in
      if !typecheck_proofs then 
        (let _ = TargetChecker.checkModule [Target.predefined] tprelude in
         let _ = TargetChecker.checkModule [Target.predefined;tprelude.decls] tproof in ());
      let _ = pr "finished dcil checking prelude and proof \n" in
      let ilenv = Ilgen.initial_env tprelude in
      let _ = if !writePrims then
        (let _ = Attribs.reset_attrib_counts () in
           if !Options.dump_tgt then PrettyTarget.printModule tprelude;
           let primsMod = Ilgen.tmod_to_absil ilenv tprelude in
           let _ = Ilgen.write_il Ilgen.DLL primsMod in
           let _ = pr "finished writing prims \n" in
             (*        let _ = PrettyTarget.printModule tprelude in *)
             if !profile_attribs then Attribs.print_attrib_size tprelude.name;
             ()) in
      let ilenv = Ilgen.extend_env ilenv tproof in
      let _ = (if !writePrims then
                 let ilproofmod = Ilgen.tmod_to_absil ilenv tproof in
                 let _ = Attribs.reset_attrib_counts () in
                 let _ = Ilgen.write_il Ilgen.DLL ilproofmod in
                 let _ = pr "finished writing proof \n" in
                   if !profile_attribs then Attribs.print_attrib_size tproof.name;
                   ()) in
        tprelude, tproof, ilenv
#endif

let doBackend env fmods preludeMod proofMod prelude_tcenv solver : string option = 
  match !Options.output_js with
    | Some (fname : string) -> 
      let stmt = Microsoft.FStar.ToJS.Absyn2JSMin.translate_modules (preludeMod::fmods) in
      if fname = "[string]" then Some (stmt.ToString())
      else (let writer = new System.IO.StreamWriter(fname) in
            writer.Write(stmt.ToString());
            writer.Close ();
            None)
    | None -> 
        if !Options.dump_src && !Options.skip_trans then 
          List.iter (fun m -> Pretty.printModule m) fmods;
        if !Options.skip_trans then None
        else
          let _ = pr "\n starting backend" in
          let [preludeMod;proofMod] = expand_types prelude_tcenv [preludeMod; proofMod] in
          let _ = pr "\n starting derefinement" in
          let (denv, [dprelude; dproof]) = 
            derefine (Tcenv.initial_env Const.prims_lid solver) [preludeMod; proofMod] in
          let main_tcenv, _ = env in
          let _ = pr "\n starting expanding types" in
          let fmods = expand_types main_tcenv fmods in 
          let _ = pr "\n finished with expanding types" in
#if CERTIFY
          let _ = if !Options.certify then 
            let _ = absynToCoretyping ([dprelude;dproof]@fmods) in () else () in
          let _ = if !Options.embed1 then
            let eb0_fs = System.IO.File.Create("embed0.v") in
            let env = List.fold (fun env (modl:Absyn.modul) -> transSig (Some eb0_fs) env modl.signature)
                                emptyTransenv ([dprelude;dproof]@fmods) in
            let fs = System.IO.File.Create("coretyping.v") in 
            let _ = PrettyPrintCoretyping.writeEnv env fs in
             eb0_fs.Close(); fs.Close(); None
          else None in
#endif
#if MONO
         None
#else
          let dmods = 
            let _ = (pr "\n"; messageWithTime "starting derefinement") in
            let _, dmods = derefine denv fmods in 
              dmods in
            let _ = if !Options.dump_src then List.iter (fun m -> Pretty.printModule m) dmods in
            if !to_dcil then 
              let _ = messageWithTime "starting translation prelude to DCIL" in
              let tprelude, tproof, ilenv = translate_and_check prelude_tcenv dprelude dproof in
              let _ = messageWithTime "finished prelude; starting translation to DCIL" in
              let dmods = List.map (fun m -> ref (Some m)) dmods in
              let tmods = translate main_tcenv dmods in
                if !Options.dump_tgt 
                then List.iter 
                  (fun (m:Target.tModule) -> 
                    (*Hashtbl.iter (fun name (cdecl:Target.tClassDecl) -> pr "Class decl: %A\n" cdecl) m.decls;*)
                    PrettyTarget.printModule m) tmods; 
              let nclasses =
                List.fold_left (fun out (m:Target.tModule)  -> out + Hashtbl.fold (fun name cd n -> n+1) m.decls 0) 0 tmods in 
              let _ = pr "\nTranslated to %d classes\n" nclasses in
              begin
                messageWithTime "starting DCIL checking";
                Proof.clear ();
                ProofState.init();
                Attribs.reset_attrib_counts ();
                tc_target [tprelude;tproof] tmods;
                messageWithTime "finished DCIL checking";
                ProofState.clear();
                if !Options.dump_tgt 
                then (messageWithTime "after target checkering";
                      List.iter(fun m -> PrettyTarget.printModule m) tmods);
                if !genIL then 
                  let _ = messageWithTime "starting writing to CIL" in
                  Ilgen.writeAssemblies ilenv tmods !Options.outputAsm 
              end;
              None
            else None
#endif
#endif
      
let doFStar env (preludeMod:Absyn.modul) proofMod prelude_tcenv solver fileOrSources : (string option * Absyn.modul list) =
  let _ = messageWithTime "starting parser and src checker" in
  let lastfile = match fileOrSources with 
    | [] -> None
    | _ -> Some (List.hd (List.rev fileOrSources)) in 
  if !Options.ts_star
  then 
    let _, fmods, jmods = 
      let (tcenv, dsenv) = env in
      let tsenv: TSStar.tsenv = {tcenv = tcenv; lids = []} in
      List.fold_left (fun ((tsenv:TSStar.tsenv, dsenv), fmods, jmods) fileOrSource -> 
        let pragmas, sugar = parse fileOrSource in 
        let _, dsenv, anf_mods = desugar pragmas (tsenv.tcenv, dsenv) sugar in
        let fmods', tsenv = TSStar.checkAndTranslate tsenv anf_mods in 
        let _ = printfn "Starting translation to JS" in
        let jmod' = ToJS.TstarAbsyn2JSMin.translate_modules fmods' in
        (tsenv,dsenv), fmods@fmods', jmods@[jmod']) ((tsenv, dsenv), [], []) fileOrSources in 
    let fh = System.IO.File.CreateText("output.js") in
       List.iter (fun jmod -> fprintfn fh "%s\n" (jmod.ToString ())) jmods;
       fh.Close ();
       (None, fmods)
  else
    let env, fmods = List.fold_left (fun (env, fmods) fileOrSource -> 
      let fmods', env' = parse_and_tc env fileOrSource in 
      let _ = if Some fileOrSource=lastfile
        then match !Options.ncnb with
          | Some fn -> 
            let fh = System.IO.StreamWriter(fn)  :> System.IO.TextWriter in
            fmods' |> List.iter (Pretty.dumpModule fh);
            fh.Close()
          | _ -> () in 
      env', fmods@fmods') (env,[]) fileOrSources in 
    (doBackend env fmods preludeMod proofMod prelude_tcenv solver, fmods)

#if MONO
 module Z3Enc = Z3Exe.Query
 let solver () = 
   if !__unsafe then 
     {Tcenv.solver_toggle_caching=(fun () -> ());
      Tcenv.solver_query=(fun e t -> true);
      Tcenv.solver_query_equiv=(fun e e1 e2 -> true);
      Tcenv.solver_discharge_proof=(fun e t -> None)}
   else 
     {Tcenv.solver_toggle_caching=(fun () -> ());
      Tcenv.solver_query=Z3Enc.query;
      Tcenv.solver_query_equiv=Z3Enc.query_equality;
      Tcenv.solver_discharge_proof=fun env t -> None}
 let init_state () = ()
#else
let solver () = 
  if !__unsafe then 
    {Tcenv.solver_toggle_caching=(fun () -> ());
     Tcenv.solver_query=(fun e t -> true);
     Tcenv.solver_query_equiv=(fun e e1 e2 -> true);
     Tcenv.solver_discharge_proof=(fun e t -> None)}
  else if !Options.encodingdt
  then 
    {Tcenv.solver_toggle_caching=(fun () -> ());
     Tcenv.solver_query=Z3Encoding.Query.query;
     Tcenv.solver_query_equiv=Z3Encoding.Query.query_equality;
     Tcenv.solver_discharge_proof=fun env t -> None}
  else
    {Tcenv.solver_toggle_caching=(fun () -> Z3Encoding.Encoding.caching := not (!Z3Encoding.Encoding.caching));
     Tcenv.solver_query=Solver.query;
     Tcenv.solver_query_equiv=Solver.query_equiv;
     Tcenv.solver_discharge_proof=Solver.discharge_proof}  
let init_state = Proof.init_state 
#endif            

let doJsStar (src:string) = 
  let pieces = List.ofArray (src.Split([|'#'|])) in 
  match pieces with 
    | [mode; head; fstarcode; body] -> 
      Options.silent := true;
      Options.logQueries := false;
      Options.z3exe := false;
      Options.outputDir := None;
      Options.encodingdt := false;
      Options.new_parser := false;
      Options.output_js := Some "[string]";
      Options.prims_ref := Some (get_fstar_home() ^ "/lib/primsjs.fst.txt");
      let _ = startClock () in
      let _ = init_state () in 
      messageWithTime (spr "silent = %A" (!Options.silent));
      let [preludeMod], env =
        parse_and_tc (Tcenv.initial_env Const.prims_lid (solver()), []) (Inl (Options.prims())) in
      let [proofMod], env = parse_and_tc env (Inl (prooflibvals ())) in
      let prelude_tcenv, _ = env in
      let dom = (get_fstar_home()) ^ "/lib/dom.fst.txt" in 
      begin match doFStar env preludeMod proofMod prelude_tcenv (solver()) [Inl dom; Inr fstarcode]  with 
        | Some result, _ -> 
            Printf.printf 
              "<html>
                <head>
                  <script type=\"text/javascript\" src=\"/Tools/FStar/jstarlib.js\"></script> \n
                  <script type=\"text/javascript\" src=\"/Tools/FStar/dom.js\"></script> \n
                  <script type=\"text/javascript\">%s</script> \n
                  %s \n
               </head> \n
               <body>%s</body> \n
              </html>" result head body 
        | _ -> err "Failed to compile file!"
      end
    | _ -> pr "Unexpected source format: %s" src

let err msg = printfn "%s\n" msg; false 

type cachetyp = ((Tcenv.env * Desugar.dsenv) * Absyn.modul * Absyn.modul * Tcenv.env)

let do_main _ =    
  let read_cache () = 
    let is = System.IO.File.OpenRead (Options.prelude_cache_file()) in 
    let formatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter() in
    let res = formatter.Deserialize(is) in
    let result = match ((unbox res) : cachetyp list) with 
      | [c] -> c
      | _ -> failwith "deserialization failed: expected one item" in
      is.Close(); result in 
  let write_cache (c:cachetyp) = 
    let os = System.IO.File.OpenWrite (Options.prelude_cache_file()) in
    let formatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter() in
      formatter.Serialize(os,box ([c]));
      os.Flush(); os.Close() in 
    try 
      (* first compile prelude and prooflibvals *)
      let (res, filenames) = process_args () in
        match res with
          | Help ->
              display_usage ();
              true
          | Die msg ->
              printfn "error: %s" msg;
              false
          | GoOn ->
            let filenames = match filenames with 
              | [fn] -> 
                let stream = new System.IO.FileStream(fn, System.IO.FileMode.Open, System.IO.FileAccess.Read) in
                let reader = new System.IO.StreamReader(stream) in
                let fileAsString = reader.ReadToEnd() in
                stream.Close(); 
                if fileAsString.StartsWith("mode=JS-STAR")
                then (doJsStar(fileAsString); [])
                else 
#if RISE4FUN
                      [get_fstar_home()^"/lib/map.fst"; fn]
#else
                      [fn]
#endif
              | _ -> filenames in 
            if filenames <> [] then
              begin
                let _, fmods = 
                  if !Options.read_prelude_cache
                  then 
                    let (env, preludeMod, proofMod, prelude_tcenv) = read_cache () in 
                    let _ = startClock () in
                    let _ = init_state () in 
                    doFStar env preludeMod proofMod prelude_tcenv (solver()) (List.map Inl filenames)
                  else
                    let _ = startClock () in
                    let _ = init_state () in 
                    let prelude = prims () in
                    let _ = messageWithTime "starting prims" in
                    let [preludeMod], env =
                      parse_and_tc (Tcenv.initial_env Const.prims_lid (solver()), []) (Inl prelude) in
                    let _ = messageWithTime "completed prims, starting prooflib" in
                    let [proofMod], env = parse_and_tc env (Inl (prooflibvals ())) in
                    let _ = messageWithTime "finished prooflib" in
                    let _ = startClock() in
                    let prelude_tcenv, _ = env in
                    if !Options.f7 then 
                      let tmods, env = doF7 env filenames in 
                      if !Options.f7backend 
                      then ignore(doBackend env tmods preludeMod proofMod prelude_tcenv (solver())); 
                      None,[]
                    else 
                      (if !Options.write_prelude_cache
                       then write_cache (env, preludeMod, proofMod, prelude_tcenv);
                       let filenames = List.map Inl filenames in 
                       doFStar env preludeMod proofMod prelude_tcenv (solver()) filenames) in 
#if RISE4FUN
                printCompletionMessage (List.tl fmods)
#else
                printCompletionMessage fmods
#endif
              end;
            true
    with
      | Failure msg -> err msg 
      | Sugar.WrappedError(Failure m, r) -> err m 
      | Sugar.WrappedError(e, r) -> 
          let msg = spr "%A\n%s\n" e (Range.string_of_range r) in
            err msg 
            
let main _ = let result = do_main () in Profiling.print_profile (); result
