﻿// See LICENSE-js2ml.txt for terms and conditions
// (c) Joel Weinberger 2012. All rights reserved.

module JSMinSyntax

open Microsoft.FStar.Util
open Common
open System.Collections.Generic

(*
 * env is an id Set * string list tuple. This is a collection of all non-global variables defined in the corrent closure as well
 * as a list representing the id of the current scope.
 *)
type env = Map<id, string> * string list

let nextfuncid = ref -1
let newFuncId () = nextfuncid := !nextfuncid + 1; (!nextfuncid).ToString ()

type builtin = JavaScriptSyntax.constant
type prefixOp = JavaScriptSyntax.prefixOp
type infixOp = JavaScriptSyntax.infixOp

type constant =
    | CThis
    | CArguments
    | CBuiltIn of builtin
with override x.ToString() =
        match x with
        | CThis -> "this"
        | CArguments -> "arguments"
        | CBuiltIn b -> b.ToString()
end

type value =
    | VConstant of pos * constant
    | VId of pos * id
    (* VLambda is a position, list of tuples of argument pretty print identifiers and the unique, underlying identifier *)
    | VLambda of pos * id list * stmt (* position * args * body *)
    | VObject of pos * (string * exp) list
    | VGlobal of pos
    | VLocals of pos * string (* the string value is the unique identifying scope suffix *)
with override x.ToString() = 
        match x with 
        | VConstant(_, c) -> c.ToString()
        | VId(_, x) -> x
        | VLambda(_, args, body) -> spr "function (%s) {\n %s \n}" (String.concat ", " args) (body.ToString())
        | VObject(_, fields) -> spr "{%s}" (String.concat ",\n " (fields |> (List.map (fun (fn, e) -> spr "\"%s\":%s" fn (e.ToString())))))
        | VGlobal _ -> "<<global>>" (* Global should not appear explicitly in JS source *)
        | VLocals(_, s) -> spr "<<locals %s>>" s (* should not appear in JS source *)
end

(*
 * These aren't really all "BuiltInOps", strictly speaking. These are really built in, JavaScript system
 * operations that are internally called.
 *)
and BuiltInOp =
    | BToInt32 of exp
    | BToNumber of exp
    | BToObject of exp
    | BToString of exp

    | BDelete of exp * exp
    | BTypeOf of exp
    | BValueOf of exp

    | BAbstractEquality of exp * exp
    | BRefEquality of exp * exp
    | BIn of exp * exp
    | BInstanceOf of exp * exp
    | BAddition of exp * exp
with override x.ToString() =
        match x with 
        | BToInt32 e -> spr "<<toInt32>> %s" (e.ToString())
        | BToNumber e -> spr "<<toNumber>> %s" (e.ToString())
        | BToObject e -> spr "<<toObject>> %s" (e.ToString())
        | BToString e -> spr "<<toString>> %s" (e.ToString())  (* these first few are not in source programs *)

        | BDelete(e1, e2) -> spr "delete %s[%s]" (e1.ToString()) (e2.ToString())
        | BTypeOf e -> spr "typeOf %s" (e.ToString())
        | BValueOf e -> spr "%s.valueOf()" (e.ToString())

        | BAbstractEquality(e1, e2) -> spr "%s == %s" (e1.ToString()) (e2.ToString())
        | BRefEquality(e1, e2) -> spr "%s === %s" (e1.ToString()) (e2.ToString())
        | BIn(e1, e2) -> spr "%s in %s" (e1.ToString()) (e2.ToString())
        | BInstanceOf(e1, e2) -> spr "%s instanceOf %s" (e1.ToString()) (e2.ToString())
        | BAddition(e1, e2) -> spr "%s + %s" (e1.ToString()) (e2.ToString())
end


and exp =
    | EValue of pos * value
    | EOp1 of pos * prefixOp * exp
    | EOp2 of pos * infixOp * exp * exp
    | EDot of pos * exp * id (* position * object expression * property identifier *)
    | EBracket of pos * exp * exp (* position * object expression * property expresionn *)
    | ECall of pos * exp * exp option * exp list
    | ECallDom of pos * exp * exp * exp list * id
    | ECallInvariant of pos * id * id
    | EBuiltIn of pos * BuiltInOp
    | EAssign of pos * id * exp
    | EDotAssign of pos * exp * id * exp (* position * object expression * field id * assigning expression *)
    | EBracketAssign of pos * exp * exp * exp (* position * object expression * field expression * assigning expression *)
    | ENew of pos * exp * exp list
    | EObjLiteral of pos * (id * exp) list
    | EList of pos * exp * exp
    | EIf of pos * exp * exp * exp
    | EVar of pos * id * exp * exp
with override x.ToString() = 
        match x with 
        | EValue(_, v) -> v.ToString()
        | EOp1(_, op, e) -> spr "(%s %s)" (op.ToString()) (e.ToString())
        | EOp2(_, op, e1, e2) -> spr "(%s %s %s)" (e1.ToString()) (op.ToString()) (e2.ToString())
        | EDot(_, e, id) -> spr "%s.%s" (e.ToString()) id
        | EBracket(_, e1, e2) -> spr "%s[%s]" (e1.ToString()) (e2.ToString())
        | ECall(_, e1, None, args) -> spr "%s(%s)" (e1.ToString()) (String.concat ", " (List.map (fun e -> e.ToString()) args))
        | ECall(_, e1, Some this, args) -> spr "%s.%s(%s)" (this.ToString()) (e1.ToString()) (String.concat ", " (List.map (fun e -> e.ToString()) args))
        | ECallDom(p, e1, e2, e3, _) -> ECall(p, e1, Some e2, e3).ToString()
        | ECallInvariant(_, _, _) -> "undefined"
        | EBuiltIn(_, bi) -> bi.ToString()
        | EAssign(_, x, e) -> spr "%s = %s" x (e.ToString())
        | EDotAssign(_, e, f, e') -> spr "%s.%s = %s" (e.ToString()) f (e'.ToString())
        | EBracketAssign(_, e1, e2, e3) -> spr "%s[%s] = %s" (e1.ToString()) (e2.ToString()) (e3.ToString())
        | ENew(_, e1, el) -> spr "new %s(%s)" (e1.ToString()) (String.concat ", " (List.map (fun e -> e.ToString()) el))
        | EObjLiteral(_, fields) -> spr "{%s}" (String.concat ",\n " (fields |> (List.map (fun (fn, e) -> spr "\"%s\":%s" fn (e.ToString())))))
        | EList(_, e1, e2) -> failwith "What's a list expression?"
        | EIf(_, e1, e2, e3) -> spr "(%s \n\t?/*then*/ %s \n\t:/*else*/ %s)" (e1.ToString()) (e2.ToString()) (e3.ToString())
        | EVar(_, x, e1, e2) -> spr "(/*let*/ %s=(%s), /*in*/\n\t%s)" x (e1.ToString()) (e2.ToString())
end

and stmt =
    | SSeq of pos * stmt * stmt
    | SIf of pos * exp * stmt * stmt
    | SWhile of pos * exp * stmt
    | SReturn of pos * exp
    | SBreak of pos
    | SEmpty of pos
    | SExp of exp
    | SForInStmt of pos * id * exp * stmt (* position * variable to assign to * object expression * body *)
    | SVar of pos * id * exp * stmt (* position * let binding id * expression to bind to * stmt to evalutate with the new binding *)
    | SVarDecl of pos * id
    | SThrow of pos * exp
    | SComment of string
    | SCommentSmall of string
with override x.ToString() =
        match x with 
        | SSeq(_, s1, s2) -> spr "%s\n%s" (s1.ToString()) (s2.ToString())
        | SIf(_, e1, s1, s2) -> spr "if (%s) {\n %s \n} else {\n %s \n};" (e1.ToString()) (s1.ToString()) (s2.ToString())
        | SWhile(_, e, s) -> spr "while (%s) {\n %s \n};" (e.ToString()) (s.ToString())
        | SReturn(_, e) -> spr "return %s;" (e.ToString())
        | SBreak _ -> "break;"
        | SEmpty _ -> ""
        | SExp e -> spr "%s;" (e.ToString())
        | SForInStmt(_, x, e, s) -> spr "for(%s in %s) {\n %s \n};" x (e.ToString()) (s.ToString())
        | SVar(_, x, e, s) -> spr "var %s = %s;\n %s" x (e.ToString()) (s.ToString())
        | SVarDecl(_, id) -> spr "var %s;" id
        | SThrow(_, e) -> spr "throw %s;" (e.ToString())
        | SComment s -> spr "\n////////////////////////////////////////////////////////////////////////////////\n \
                               // %s \n \
                               ////////////////////////////////////////////////////////////////////////////////\n" s
        | SCommentSmall s -> spr "\n/* %s */" s
end

type prog =
    | PStmt of pos * stmt
with override x.ToString() = match x with | PStmt(_, s) -> s.ToString()

let JSSyntax2JSMinMap = new Dictionary<System.Object, System.Object>()

(*
 * Given a JavaScript statement, returns a Set<id> of the variable ids declared in it, stopping at function boundaries.
 *)
let rec liftvars (s : JavaScriptSyntax.stmt) : Set<id> =
    let error s = raise (System.Exception (s + " are currently unsupported."))
    let liftdecls decls =
        let decllist = List.map (fun decl -> match decl with
                                                | JavaScriptSyntax.VarDecl (_, v, _) -> Set.singleton v
                                                | JavaScriptSyntax.VarDeclNoInit (_, v) -> Set.singleton v)
        Set.unionMany (decllist decls)
    match s with
        | JavaScriptSyntax.BlockStmt (_, block) -> Set.unionMany (List.map liftvars block)
        | JavaScriptSyntax.EmptyStmt _ -> Set.empty
        (*
         * The only expression that matters is named function expressions, because these introduce a new variable name.
         * No other expression can introduce a variable name.
         *)
        | JavaScriptSyntax.ExprStmt (e) ->
            match e with
                | JavaScriptSyntax.NamedFuncExpr (_, name, _, _) -> Set.singleton name
                | _ -> Set.empty
        | JavaScriptSyntax.IfStmt (_, _, true_body, false_body) -> Set.union (liftvars true_body) (liftvars false_body)
        | JavaScriptSyntax.IfSingleStmt (_, _, true_body) -> liftvars true_body
        | JavaScriptSyntax.SwitchStmt (_, _, cases) ->
            List.fold (fun vars c -> Set.union vars (match c with 
                                                       | JavaScriptSyntax.CaseClause (_, _, s) -> liftvars s
                                                       | JavaScriptSyntax.CaseDefault (_, s) -> liftvars s)) Set.empty cases
        | JavaScriptSyntax.WhileStmt (_, _, body) -> liftvars body
        | JavaScriptSyntax.DoWhileStmt (_, body, _) -> liftvars body
        | JavaScriptSyntax.BreakStmt _ -> Set.empty
        | JavaScriptSyntax.BreakToStmt _ -> (error "break to labels")
        | JavaScriptSyntax.ContinueStmt _ -> (error "continues")
        | JavaScriptSyntax.ContinueToStmt _ -> (error "continue to labels")
        | JavaScriptSyntax.LabelledStmt _ -> (error "labeled statements")
        | JavaScriptSyntax.ForInStmt (_, init, _, body) ->
            match init with
                | JavaScriptSyntax.VarForInInit (_, v) -> Set.union (Set.singleton v) (liftvars body)
                | _ -> liftvars body
        | JavaScriptSyntax.ForStmt (p, init, _, _, body) ->
            let initvars = match init with
                            | JavaScriptSyntax.VarForInit decls -> (liftdecls decls)
                            | _ -> Set.empty
            Set.union initvars (liftvars body)
        | JavaScriptSyntax.TryStmt _ -> (error "try statements")
        | JavaScriptSyntax.ThrowStmt _ -> (error "throw statements")
        | JavaScriptSyntax.ReturnStmt _ -> Set.empty
        | JavaScriptSyntax.WithStmt _ -> (error "with statements")
        | JavaScriptSyntax.VarDeclStmt (_, decls) -> liftdecls decls
        | JavaScriptSyntax.FuncStmt (_, name, _, _) -> Set.singleton name

(*
 * var decls at the beginning of a lambda expression are translated so they are part of an object locals.
 * Thus:
 *    var x, y;
 *    var z = 5;
 * becomes:
 *    locals = { x = undefined, y = undefined, z = undefined };
 * 
 * Note that we now also pass a suffix for the locals variable that uniquely identifies which scoped locals object the variable is defined in.
 * For example, in the code:
 *    function f () {
 *       var a;
 *       function g () {
 *          var b;
 *          function h () {
 *             var c;
 *          }
 *       }
 *    }
 *
 * var a would be lifted as "a" -> "_f", var b would be lifted as "b" -> "_f_g", and var c would be lifted as "c" -> "_f_g_h".
 *
 * Note that we now define Alloc to create any specified fields with Undef as the initial assignment. Thus, we do not need to initially specify
 * any properties of the local object; we can just allocate it.
 *)
let rec mkvardecls env (p : pos) (vars : id list) (body : stmt) (scopesuffix : string) =
    let varprops = List.map (fun var -> JavaScriptSyntax.PropId var) vars
    let positions = List.replicate (List.length varprops) p
    let undefs = List.replicate (List.length varprops) (JavaScriptSyntax.ConstExpr (p, JavaScriptSyntax.CUndefined))
    (*
    SVar (p, "locals" + scopesuffix, EValue (p, VObject (p, mkobject env (List.zip3 positions varprops undefs))),
          body)
    *)
    SVar (p, "locals" + scopesuffix, EValue (p, VObject (p, mkobject env [])),
          body)

and mklocals (locals : Map<id, string>) (suffix : string) (newvars : Set<id>) =
    Set.fold (fun locals v -> Map.add v suffix locals) locals newvars

(*
 * Functions need to have their variables explicitly extracted from the arguments object
 * and then made into local variables.
 *)
and mkfuncbody (env : env) p args body =
    let locals, scope = env
    let newscope = scope @ [newFuncId ()]
    let newscopesuffix = (mkscopesuffix newscope)
    let length = List.length args
    let argsi = List.mapi (fun i arg -> i, arg) args
    let bodyvars = Set.union (liftvars body) (Set.ofList args) //The variables in the body include the argument variables
    let newlocals = mklocals locals newscopesuffix bodyvars
    let newenv = newlocals, newscope
    mkvardecls newenv p (Set.toList bodyvars)
        (List.foldBack (fun (i, arg) body ->
                            SSeq (p, SExp (EDotAssign (p, EValue (p, VLocals (p, newscopesuffix)), arg,
                                                        EDot (p, EValue (p, VConstant (p, CArguments)), i.ToString()))),
                                  body))
                      argsi (stmt newenv body))
        newscopesuffix

and mkobject env props =
    List.map (fun (p, field, prop) ->
                let propexp = exp env prop
                match field with
                    | JavaScriptSyntax.PropId v -> (v, propexp)
                    | JavaScriptSyntax.PropString s -> (s, propexp)
                    | JavaScriptSyntax.PropNum n -> (string n, propexp))
              props

and mkscopesuffix (scope : string list) : string =
    match scope with
        | [] -> ""
        | s::ss -> "_" + s + (mkscopesuffix ss)

and exp (env : env) (e : JavaScriptSyntax.expr) =
    let locals, scope = env
    (*
     * Local variables are now properties of the locals object
     *)
    let mkid p id =
        if locals.ContainsKey id then EDot (p, EValue (p, VLocals (p, Map.find id locals)), id)
        else EDot (p, EValue (p, VGlobal p), id)
    let mkarray env elts =
        List.map2 (fun i e -> (string i, exp env e)) (iota (List.length elts)) elts
    let get_lvalue_exp (lv : JavaScriptSyntax.lvalue) =
        match lv with
            | JavaScriptSyntax.VarLValue (p, name) -> mkid p name
            | JavaScriptSyntax.DotLValue (p, obj, field) -> EDot (p, exp env obj, field)
            | JavaScriptSyntax.BracketLValue (p, obj, field) -> EBracket (p, exp env obj, exp env field)
    (*
     * Given a left value, creates an assignment to that left value, and also passes the created left value into the body function
     * so it can create a right hand side as appropriate.
     *)
    let assign_lvalue (lv : JavaScriptSyntax.lvalue) (body_fn : exp -> exp) =
        let body = body_fn (get_lvalue_exp lv)
        match lv with
            | JavaScriptSyntax.VarLValue (p, name) ->
                if locals.ContainsKey name
                    then EDotAssign (p, EValue (p, VLocals (p, Map.find name locals)), name, body)
                    else EDotAssign (p, EValue (p, VGlobal p), name, body)
            | JavaScriptSyntax.DotLValue (p, obj, field) -> EDotAssign (p, exp env obj, field, body)
            | JavaScriptSyntax.BracketLValue (p, obj, field) -> EBracketAssign (p, exp env obj, exp env field, body)

    match e with
        | JavaScriptSyntax.ConstExpr (p, c) -> EValue (p, VConstant (p, CBuiltIn c))
        | JavaScriptSyntax.ArrayExpr (p, elts) -> EValue (p, VObject (p, mkarray env elts))
        | JavaScriptSyntax.ObjectExpr (p, props) -> EValue (p, VObject (p, mkobject env props))
        | JavaScriptSyntax.ThisExpr p -> EValue (p, VConstant (p, CThis))
        | JavaScriptSyntax.VarExpr (p, v) -> mkid p v
        | JavaScriptSyntax.DotExpr (p, obj, field) -> EDot (p, exp env obj, field)
        | JavaScriptSyntax.BracketExpr (p, obj, field) -> EBracket (p, exp env obj, exp env field)
        | JavaScriptSyntax.NewExpr (p, constr, args) -> ENew (p, exp env constr, List.map (exp env) args)
        | JavaScriptSyntax.PrefixExpr (p, op, e) -> EOp1 (p, op, exp env e)
        | JavaScriptSyntax.UnaryAssignExpr (p, op, lvalue) ->
            (*
             * ++x
             *   -> (x = x + 1)
             *
             * x++
             *   -> (x = x + 1), (x - 1) 
             *)
            match op with
                | JavaScriptSyntax.PrefixDec -> assign_lvalue lvalue (fun e -> (EOp2 (p, infixOp.OpSub,
                                                                                      e, EValue (p, VConstant (p, CBuiltIn (builtin.CInt 1))))))
                | JavaScriptSyntax.PrefixInc -> assign_lvalue lvalue (fun e -> (EOp2 (p, infixOp.OpAdd,
                                                                                      e, EValue (p, VConstant (p, CBuiltIn (builtin.CInt 1))))))
                | JavaScriptSyntax.PostfixDec -> EList (p, assign_lvalue lvalue (fun e -> EOp2 (p, infixOp.OpSub,
                                                                                                e, EValue (p, VConstant (p, CBuiltIn (builtin.CInt 1))))),
                                                       (EOp2 (p, infixOp.OpAdd, get_lvalue_exp lvalue, EValue (p, VConstant (p, CBuiltIn (builtin.CInt 1))))))
                | JavaScriptSyntax.PostfixInc -> EList (p, assign_lvalue lvalue (fun e -> EOp2 (p, infixOp.OpAdd,
                                                                                                e, EValue (p, VConstant (p, CBuiltIn (builtin.CInt 1))))),
                                                       (EOp2 (p, infixOp.OpSub, get_lvalue_exp lvalue, EValue (p, VConstant (p, CBuiltIn (builtin.CInt 1))))))
        | JavaScriptSyntax.InfixExpr (p, op, left, right) -> EOp2 (p, op, exp env left, exp env right)
        | JavaScriptSyntax.IfExpr (p, condition, true_branch, false_branch) ->  EIf (p, exp env condition, exp env true_branch, exp env false_branch)
        | JavaScriptSyntax.AssignExpr (p, assign_op, lv, value) -> assign_lvalue lv (fun _ -> exp env value)
        | JavaScriptSyntax.ParenExpr (p, e) -> exp env e
        | JavaScriptSyntax.ListExpr (p, e1, e2) -> EList (p, exp env e1, exp env e2)
        | JavaScriptSyntax.CallExpr (p, func, args) as g ->
            let f = 
                let basic_call receiver = ECall (p, exp env func, Some receiver, List.map (exp env) args)
                (*
                 * The following is the world's dumbest alias analysis. If we are calling a function that *could* be an interesting DOM function,
                 * we provide a hint that we think it is so by calling gapply, rather than the regular apply. We determine if it "might" be such a function
                 * by doing a string compare of the function names.
                 *)
                let call_with_guess receiver guess = ECallDom (p, exp env func, receiver, List.map (exp env) args, guess)
                let mk_invariant_call args =
                    let raise_invariant_exception _ = System.Exception "Invalid call to __inavriant__. You must have exactly one id argument." |> raise
                    match args with
                        | [arg] -> match arg with
                                    | JavaScriptSyntax.ConstExpr (_, JavaScriptSyntax.CString s) -> ECallInvariant (p, s, "locals" + (mkscopesuffix scope))
                                    | _ -> raise_invariant_exception ()
                        | _ -> raise_invariant_exception ()
                let mk_call name receiver =
                    if name.Equals("__invariant__")
                    then mk_invariant_call args
                    else if isDomFunction name
                    then call_with_guess receiver name
                    else basic_call receiver
                match func with
                    | JavaScriptSyntax.VarExpr (p, v) -> EValue (p, VGlobal p) |> mk_call v
                    | JavaScriptSyntax.BracketExpr (p, receiver, prop) ->
                        match prop with
                            | JavaScriptSyntax.expr.ConstExpr (_, JavaScriptSyntax.constant.CString id) -> exp env receiver |> mk_call id
                            | _ -> exp env receiver |> mk_call ""
                    | JavaScriptSyntax.DotExpr (p, receiver, prop) -> exp env receiver |> mk_call prop
                    | _ -> System.Exception "Invalid JavaScript expression as function call." |> raise
            in 
            let _ = if (not(JSSyntax2JSMinMap.ContainsKey(g))) then JSSyntax2JSMinMap.Add(g,f) in
            f
        (* When we are parsing the function, lift the variable declarations in the body. *)
        | JavaScriptSyntax.FuncExpr (p, args, body) as g -> 
         let f = VLambda (p, args, mkfuncbody env p args body) in
         let func = EValue (p, f) in
             JSSyntax2JSMinMap.Add(g, f);
             func
        (* Variable name should be lifted earlier, so at this point it is just transformed into the assignment of a lambda to a variable name *)
        | JavaScriptSyntax.NamedFuncExpr (p, name, args, body) as g -> 
         let f = VLambda (p, args, mkfuncbody env p args body) in
         let func = EValue (p, f) in 
                JSSyntax2JSMinMap.Add(g, f);
                assign_lvalue (JavaScriptSyntax.lvalue.VarLValue (p, name)) (fun _ -> func)

and stmt (env : env) (s : JavaScriptSyntax.stmt) =
    let locals, scope = env
    let error s = raise (System.Exception (s + " are currently unsupported."))
    let rec block_stmt p block =
        match block with
            | [] -> SEmpty p
            | (JavaScriptSyntax.ReturnStmt (p, e))::ss -> stmt env (JavaScriptSyntax.ReturnStmt (p, e))
            | (JavaScriptSyntax.BreakStmt p)::ss -> stmt env (JavaScriptSyntax.BreakStmt p)
            | s::ss -> SSeq (p, stmt env s, block_stmt p ss)
    match s with
        | JavaScriptSyntax.BlockStmt (p, b) -> block_stmt p b
        | JavaScriptSyntax.EmptyStmt p -> SEmpty p
        | JavaScriptSyntax.ExprStmt e -> SExp (exp env e)
        | JavaScriptSyntax.IfStmt (p, guard, true_branch, false_branch) -> SIf (p, exp env guard, stmt env true_branch, stmt env false_branch)
        | JavaScriptSyntax.IfSingleStmt (p, guard, true_branch) -> SIf (p, exp env guard, stmt env true_branch, SEmpty p)
        | JavaScriptSyntax.SwitchStmt (p, guard, cases) ->
            (error "switch statement")
            (* The following does not work yet because of "break" statements *)
            (*
            let guardexpr = exp env guard
            let rec mkswitchconditions cases =
                match cases with
                    | [] -> SEmpty p
                    | c::cc -> match c with
                                | JavaScriptSyntax.CaseClause (p, caseexpr, body) ->
                                    SIf (p, EOp2 (p, infixOp.OpStrictEq, exp env caseexpr, guardexpr), stmt env body,
                                        mkswitchconditions cc)
                                | JavaScriptSyntax.CaseDefault (p, body) -> stmt env body
            mkswitchconditions cases
            *)
        | JavaScriptSyntax.WhileStmt (p, guard, body) -> SWhile (p, exp env guard, stmt env body)
        | JavaScriptSyntax.DoWhileStmt (p, body, guard) -> let body = (stmt env body) in SSeq (p, body, SWhile (p, exp env guard, body))
        | JavaScriptSyntax.BreakStmt p -> SBreak p
        | JavaScriptSyntax.BreakToStmt _ -> (error "break to labels")
        | JavaScriptSyntax.ContinueStmt _ -> (error "continues")
        | JavaScriptSyntax.ContinueToStmt _ -> (error "continue to labels")
        | JavaScriptSyntax.LabelledStmt _ -> (error "labeled statements")
        | JavaScriptSyntax.ForInStmt (p, init, obj, body) ->
            (*
             * Ultimately, in the ML translation, we want the output to look like the following:
             *
             * var v = undefined
             * var tl = object
             * while not (isEmpty? tl)
             *      v := head tl
             *      tl := tail tl
             *      body
             *
             * ...but we don't have the expressive power for that now, so for now we put
             * placeholders in the AST.
             *)
            let forin v = SForInStmt (p, v, exp env obj, stmt env body)
            match init with
                | JavaScriptSyntax.VarForInInit (p, v) -> SSeq (p, SExp (EDotAssign (p, EValue(p, VLocals (p, Map.find v locals)), v,
                                                                                     EValue (p, VConstant (p, CBuiltIn builtin.CUndefined)))),
                                                                forin v)
                | JavaScriptSyntax.NoVarForInInit (p, v) -> forin v
        | JavaScriptSyntax.ForStmt (p, init, guard, inc, body) ->
            let preloop = match init with
                            | JavaScriptSyntax.ExprForInit e -> SExp (exp env e)
                            (* variable declarations will be hoisted already, so do nothing *)
                            | _ -> SEmpty p
            SSeq (p, preloop, SWhile (p, exp env guard, SSeq (p, stmt env body, SExp (exp env inc))))
        | JavaScriptSyntax.TryStmt _ -> (error "try statements")
        | JavaScriptSyntax.ThrowStmt _ -> (error "throw statements")
        | JavaScriptSyntax.ReturnStmt (p, e) -> SReturn (p, exp env e)
        | JavaScriptSyntax.WithStmt _ -> (error "with statements")
        (* All var declarations will be hoisted in functions, so they will be dealt with there.
         * However, we still must initialize variables at this point if there is an initialization value.
         * Note that if there was no explicit initialization value given, we just no-op here with an SEmpty statement. *)
        | JavaScriptSyntax.VarDeclStmt (p, decls) ->
            let rec mkinit decls =
                match decls with
                    | [] -> SEmpty (p)
                    | decl::rest -> 
                        match decl with
                            | JavaScriptSyntax.VarDeclNoInit (p, _) -> SEmpty (p)
                            | JavaScriptSyntax.VarDecl (p, name, e) ->
                                if locals.ContainsKey name
                                then SExp (EDotAssign (p, EValue (p, VLocals (p, Map.find name locals)), name, exp env e))
                                else SExp (EDotAssign (p, EValue (p, VGlobal p), name, exp env e))
            mkinit decls
        (* This is equivalent to var f = function (args) { ... }, so we just translate this to a named function expression. *)
        | JavaScriptSyntax.FuncStmt (p, name, args, body) as g -> 
        let f = exp env (JavaScriptSyntax.NamedFuncExpr (p, name, args, body)) in
        let _ = match f with 
                | EDotAssign(_, EValue _, _, EValue(_, vlam)) -> JSSyntax2JSMinMap.Add(g, vlam)
                | _ -> () in
        SExp (f)

(* Takes a JS AST and returns a JSmin AST that has not been desugared *)
let js_to_jsmin_raw (program : JavaScriptSyntax.prog) : prog =
    match program with
        | JavaScriptSyntax.Prog (program_pos, js) ->
            (*
             * Vars declared at the global level are not "local" in any normal sense; they are added as properties of the global object.
             * Thus, we do not lift them. When they appear in the AST, a lookup to the global object will be inserted.
             *)
            PStmt (program_pos, stmt (Map.empty, []) (JavaScriptSyntax.BlockStmt (program_pos, js)))
