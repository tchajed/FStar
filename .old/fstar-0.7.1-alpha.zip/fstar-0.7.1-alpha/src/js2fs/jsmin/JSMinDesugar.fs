﻿// See LICENSE-js2ml.txt for terms and conditions
// (c) Joel Weinberger 2012. All rights reserved.

module JSMinDesugar

open JSMinSyntax
open System.Collections.Generic

let JSMin2DesugarMap = new Dictionary<System.Object, System.Object>()

(* Takes a JS AST and returns a desugared JSmin AST *)
let js_to_jsmin (program : JavaScriptSyntax.prog) (insert_coercions : bool) : prog =
    let rec desugar_value (v : value) : value =
        match v with
            | VLambda (p, args, body) as g -> 
                let f = VLambda (p, args, desugar_stmt body) in
                JSMin2DesugarMap.Add(g,f);
                f
            | VObject (p, fields) -> VObject (p, List.map (fun (name, field) -> (name, desugar_exp field)) fields)
            | _ -> v
    
    and desugar_exp (e : exp) : exp =
        let toInt32 p e = if insert_coercions then EBuiltIn (p, BToInt32 e) else e
        let toNumber p e = if insert_coercions then EBuiltIn (p, BToNumber e) else e
        let toObject p e = if insert_coercions then EBuiltIn (p, BToObject e) else e
        let toString p e = if insert_coercions then EBuiltIn (p, BToString e) else e
        let boolexp p b = EValue (p, VConstant (p, CBuiltIn (builtin.CBool b)))
        let numnum p op e1 e2 =
            EOp2 (p, op, toNumber p e1, toNumber p e2)
        match e with
            | EValue (p, v) -> EValue (p, desugar_value v)
            | EOp1 (p, op, e) ->
                match op with
                    (* Translation changed where possible for logical operators. We now convert these operators directly to their F* equivalents. *)
                    (* | prefixOp.PrefixLNot -> EIf (p, desugar_exp e, boolexp p false, boolexp p true) *)
                    | prefixOp.PrefixLNot -> EOp1 (p, op, desugar_exp e)
                    | prefixOp.PrefixBNot -> EOp1 (p, op, desugar_exp e |> toInt32 p)
                    | prefixOp.PrefixPlus -> desugar_exp e |> toNumber p
                    | prefixOp.PrefixMinus -> numnum p infixOp.OpSub (EValue (p, VConstant (p, CBuiltIn (builtin.CNum 0.0)))) (desugar_exp e)
                    | prefixOp.PrefixTypeof -> EBuiltIn (p, BTypeOf (EBuiltIn (p, BValueOf (desugar_exp e))))
                    | prefixOp.PrefixVoid -> EList (p, e, EValue (p, VConstant (p, CBuiltIn builtin.CUndefined)))
                    | prefixOp.PrefixDelete ->
                        match e with
                            | EBracket (p, obj, field) -> EBuiltIn (p, BDelete (desugar_exp obj, desugar_exp field))
                            | EDot (p, obj, field) -> EBuiltIn (p, BDelete (desugar_exp obj, EValue (p, desugar_value (VConstant (p, CBuiltIn (builtin.CString (field)))))))
                            | _ -> raise (System.Exception "Invalid delete operand.")
            | EOp2 (p, op, e1, e2) ->
                let d_e1 = desugar_exp e1
                let d_e2 = desugar_exp e2
                match op with
                    | infixOp.OpLT ->  numnum p op d_e1 d_e2
                    | infixOp.OpLEq -> numnum p op d_e1 d_e2
                    | infixOp.OpGT -> numnum p op d_e1 d_e2
                    | infixOp.OpGEq -> numnum p op d_e1 d_e2
                    | infixOp.OpDiv -> numnum p op d_e1 d_e2
                    | infixOp.OpMul -> numnum p op d_e1 d_e2
                    | infixOp.OpMod -> numnum p op d_e1 d_e2
                    | infixOp.OpSub -> numnum p op d_e1 d_e2
                    | infixOp.OpLShift -> numnum p op d_e1 d_e2
                    | infixOp.OpSpRShift -> numnum p op d_e1 d_e2
                    | infixOp.OpZfRShift -> numnum p op d_e1 d_e2
                    | infixOp.OpBAnd -> numnum p op d_e1 d_e2
                    | infixOp.OpBOr -> numnum p op d_e1 d_e2
                    | infixOp.OpBXor -> numnum p op d_e1 d_e2
                    (* If e1 is false valued, we return the value of e1, which may be false, or zero, or ... *)
                    (*
                    | infixOp.OpLAnd -> EIf (p, d_e1, d_e2, d_e1)
                    | infixOp.OpLOr -> EIf (p, d_e1, d_e1, d_e2)
                    *)
                    (* Translation changed so that we pass && and || operators on. Now, we translate these directly to F*. *)
                    | infixOp.OpLAnd -> EOp2(p, op, d_e1, d_e2)
                    | infixOp.OpLOr -> EOp2(p, op, d_e1, d_e2)
                    | infixOp.OpEq -> EBuiltIn (p, BAbstractEquality (d_e1, d_e2))
                    | infixOp.OpNEq -> EIf (p, EBuiltIn (p, BAbstractEquality (d_e1, d_e2)),
                                            boolexp p false,
                                            boolexp p true)
                    | infixOp.OpStrictEq -> EBuiltIn (p, BRefEquality (d_e1, d_e2))
                    | infixOp.OpStrictNEq -> EIf (p, EBuiltIn (p, BRefEquality (d_e1, d_e2)),
                                                  boolexp p false,
                                                  boolexp p true)
                    | infixOp.OpIn -> EBuiltIn (p, BIn (toString p d_e1, toObject p d_e2))
                    | infixOp.OpInstanceof -> EBuiltIn (p, BInstanceOf (d_e1, d_e2))
                    | infixOp.OpAdd -> EBuiltIn (p, BAddition (d_e1, d_e2))
            | EDot (p, obj, field) -> EDot (p, desugar_exp obj |> toObject p, field)
            | EBracket (p, obj, field) -> EBracket (p, desugar_exp obj |> toObject p, desugar_exp field |> toString p)
            | ECall (p, func, ropt, args) as g -> 
                let ropt = match ropt with None -> None | Some r -> Some <| desugar_exp r in  
                let f = ECall (p, desugar_exp func, ropt, List.map desugar_exp args) in 
                let _ = if not(JSMin2DesugarMap.ContainsKey(g)) then JSMin2DesugarMap.Add(g,f) in
                f
            | ECallDom (p, func, receiver, args, guess) as g -> 
                let f = ECallDom (p, desugar_exp func, desugar_exp receiver, List.map desugar_exp args, guess) in
                let _ = if not(JSMin2DesugarMap.ContainsKey(g)) then JSMin2DesugarMap.Add(g,f) in
                f
            | ECallInvariant (p, inv, locals) as g -> 
                let f = ECallInvariant (p, inv, locals) in
                    JSMin2DesugarMap.Add(g,f);
                    f
            | EBuiltIn (p, b) -> EBuiltIn (p, b)
            | EAssign (p, v, assigment) -> EAssign (p, v, desugar_exp assigment)
            | EDotAssign (p, obj, field, assignment) -> EDotAssign (p, desugar_exp obj |> toObject p, field, desugar_exp assignment)
            | EBracketAssign (p, obj, field, assignment) -> EBracketAssign (p, desugar_exp obj |> toObject p, desugar_exp field |> toString p, desugar_exp assignment)
            (* TODO desugar to prototype lookup for constructor *)
            | ENew (p, obj, args) -> ENew (p, desugar_exp obj, List.map desugar_exp args)
            | EList (p, e1, e2) -> EList (p, desugar_exp e1, desugar_exp e2)
            | EIf (p, guard, true_branch, false_branch) -> EIf (p, desugar_exp guard, desugar_exp true_branch, desugar_exp false_branch)
            | EObjLiteral(p, fields) -> EObjLiteral(p, List.map (fun (f, e) -> (f, desugar_exp e)) fields)
            | EVar(p, x, e1, e2) -> EVar(p, x, desugar_exp e1, desugar_exp e2)
    and desugar_stmt (s : stmt) : stmt =
        match s with
            | SSeq (p, s1, s2) -> SSeq (p, desugar_stmt s1, desugar_stmt s2)
            | SIf (p, guard, true_stmt, false_stmt) -> SIf (p, desugar_exp guard, desugar_stmt true_stmt, desugar_stmt false_stmt)
            | SWhile (p, guard, body) -> SWhile (p, desugar_exp guard, desugar_stmt body)
            | SReturn (p, retval) -> SReturn (p, desugar_exp retval)
            | SBreak (p) -> s
            | SEmpty (p) -> s
            | SExp (e) -> SExp (desugar_exp e)
            | SForInStmt (p, v, obj, body) -> SForInStmt (p, v, desugar_exp obj, desugar_stmt body)
            | SVar (p, v, e, body) -> SVar (p, v, desugar_exp e, desugar_stmt body)
            | SVarDecl(p, v) -> SVarDecl(p, v)
            | SThrow(p, e) -> SThrow(p, desugar_exp e)
            
    let rec desugar (program : prog) : prog =
        match program with
            | PStmt (p, s) -> PStmt (p, desugar_stmt s)

    (* body of js_to_jsmin *)
    desugar (js_to_jsmin_raw program)
