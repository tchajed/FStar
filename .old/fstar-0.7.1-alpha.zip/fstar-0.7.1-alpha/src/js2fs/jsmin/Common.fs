﻿// See LICENSE-js2ml.txt for terms and conditions
// (c) Joel Weinberger 2012. All rights reserved.

module Common
open Microsoft.FStar

type id = string

(* We track the start and end position of each syntactic form. *)
type pos = Range.range
let posToString (p : pos) : string = //Range.string_of_range p
  sprintf "%s-%s" (Range.string_of_pos (Range.start_of_range p)) 
      (Range.string_of_pos (Range.end_of_range p))
let dummy_pos = 0L

let rec iota size = if size <= 0 then List.Empty else List.Cons (size - 1, iota (size - 1))

let fst (a, b) = a
let snd (a, b) = b
let fst3 (a, b, c) = a
let snd3 (a, b, c) = b
let third3 (a, b, c) = c

let TEMPVAR_ID = "v'"
let TEMPOBJ_ID = "obj'"

let dom_functions = Set.ofList([ "getAttribute";
                                 "setAttribute";
                                 "appendChild";
                                 "removeChild";
                                 "getChildren";
                                 "getChild"
                               ])
let isDomFunction func = dom_functions.Contains func
