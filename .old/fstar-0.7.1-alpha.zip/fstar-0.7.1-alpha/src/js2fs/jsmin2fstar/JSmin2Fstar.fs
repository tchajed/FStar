﻿// See LICENSE-js2ml.txt for terms and conditions
// (c) Joel Weinberger 2012. All rights reserved.

#light "off"

module JSmin2Fstar

open Common
open Microsoft.FStar
open Microsoft.FStar.Absyn
open Microsoft.FStar.Sugar
open Microsoft.FStar.Util
open System.Collections.Generic

type cg = {callees:System.Collections.Generic.Dictionary<JSMinSyntax.exp, ISet<JSMinSyntax.value>>;
           targets:HashMultiMap<JSMinSyntax.value, Sugar.typ>}

let mk_cg callees = {callees=callees;
                     targets=Hashtbl.create 100}
type env = {gamma:list<id>; callgraph:cg}
exception Trans of string * pos

type domMap = {api: string; transformer: typ}
let domMaps = (* mapping from dom API names to their transformers *)
  let mkMap name txName =
    {api = name; 
     transformer = Type_named(name, Type_lid(p2l txName, Absyn.dummyRange), Absyn.dummyRange)} in
  [mkMap "getElementsByTagName" ["DOM"; "GetElementsByTagNameTX"];
   mkMap "getElementById" ["DOM"; "GetElementByIdTX"];
   mkMap "log" ["DOM";"ConsoleLogTX"];
   mkMap "getSelection" ["DOM"; "GetSelectionTx"];
   mkMap "addListener" ["DOM"; "addListenerTx"];
   mkMap "addListenerCB" ["DOM"; "addListenerCBTx"];
   mkMap "sendRequest1" ["DOM"; "sendRequestTx1"];
   mkMap "sendRequest2" ["DOM"; "sendRequestTx2"];
   mkMap "toString" ["DOM"; "windowSelectionToStringTx"];
   mkMap "Next" ["DOM"; "NextTX"]]

let lookForDomType name = match List.tryFind (fun({api = nm; transformer = t}) -> name = nm) domMaps with
   | Some {api = _; transformer = t} -> Some t
   | None -> None

let nyi s = failwith (spr "NYI: %s" s)
let mk_lid i = asLid [ident(i, Absyn.dummyRange)]
let mk_id i = ident(i, Absyn.dummyRange)
// For the range, we unfortunately don't have access to the file name, so we just insert a blank string.
let range_of_pos (p:pos) : Range.range = p
    (* if p=null  *)
    (* then  *) //Absyn.dummyRange
    (* else Range.mk_range "" (Range.mk_pos p.StartLine p.StartColumn) (Range.mk_pos p.EndLine p.EndColumn) *)
let mk_fvar path p  = let r = range_of_pos p in Expr_lid_get(false, lid_of_text path r, r)
let mk_local name p = Expr_id_get (ident(name,range_of_pos p))
let mk_deref exp p  = Expr_app(mk_fvar "Prims.deref" p, exp, range_of_pos p)
let mk_tapp e tl p = Expr_tyapp(e, tl, range_of_pos p)
let mk_app e1 e2 p  = Expr_app(e1, e2, range_of_pos p)
let mk_app_l fargs p = match fargs with 
    | [] -> raise Impos
    | f::args -> List.fold_left (fun e1 e2 -> mk_app e1 e2 p) f args 
let print (s : string) : unit = System.Console.WriteLine(s)

let try_resolve_callee env callnode p =
  try 
    let v = env.callgraph.callees.Item(callnode) in
        if v.Count = 1 then            
            let v =  v.GetEnumerator() in 
                ignore (v.MoveNext());
                (match v.Current with
                  | JSMinSyntax.VId(_, name) -> lookForDomType name
                  | _ ->
                    (match Hashtbl.tryfind env.callgraph.targets v.Current with 
                       | None -> None
                       | Some t -> pr "Resolved one call using GK\n"; Some t) )
        else 
            None
  with _ -> None

let _Null   = mk_fvar "JSVerify.Null"   Common.dummy_pos
let _Undef  = mk_fvar "JSVerify.Undef"  Common.dummy_pos
let _Bool   = mk_fvar "JSVerify.Bool"   Common.dummy_pos
let _Str    = mk_fvar "JSVerify.Str"    Common.dummy_pos
let _Num    = mk_fvar "JSVerify.Num"    Common.dummy_pos
let _Float  = mk_fvar "JSVerify.Num"  Common.dummy_pos
let _Obj    = mk_fvar "JSVerify.Obj"    Common.dummy_pos
let _Fun    = mk_fvar "JSVerify.Fun"    Common.dummy_pos
let _MkFun  = mk_fvar "JSVerify.mkFun"  Common.dummy_pos

let _Return = mk_fvar "Prims.Return" Common.dummy_pos
let _Break  = mk_fvar "Prims.Break"  Common.dummy_pos

let _MkMap  = mk_fvar "JSVerify.mkMap"   Common.dummy_pos
let _Alloc  = mk_fvar "JSVerify.alloc"   Common.dummy_pos
let _Assign = mk_fvar "JSVerify.assign"  Common.dummy_pos
let _AsVal  = mk_fvar "JSVerify.asVal"   Common.dummy_pos
let _Select = mk_fvar "JSVerify.select"  Common.dummy_pos

let _Update = mk_fvar "JSVerify.update"  Common.dummy_pos

let _While  = mk_fvar "JSVerify._while"   Common.dummy_pos
let _ForIn  = mk_fvar "JSVerify.forin"   Common.dummy_pos
let _UnFun  = mk_fvar "JSVerify.unFun"   Common.dummy_pos 
let _apply  = mk_fvar "JSVerify.apply"   Common.dummy_pos 
let _applyHint  = mk_fvar "JSVerify.apply_hint"   Common.dummy_pos 
let _applyHintEx = mk_fvar "JSVerify.apply_hint_ex_witness'"   Common.dummy_pos 
let _UnBool = mk_fvar "JSVerify.unBool"  Common.dummy_pos

let _CoerceString = mk_fvar "JSVerify.coerceString" Common.dummy_pos 
let _CoerceBool   = mk_fvar "JSVerify.coerceBool"   Common.dummy_pos 
let _DummyBool   = mk_fvar "JSVerify.dummyBool"   Common.dummy_pos 
let _CoerceInt    = mk_fvar "JSVerify.coerceInt"    Common.dummy_pos 

let _Delete = mk_fvar "JSVerify.opDelete"  Common.dummy_pos (* jw: should this really just be an explicit removal from the object map? *)
let _TypeOf = mk_fvar "JSVerify.typeOf"  Common.dummy_pos
let _ValOf  = mk_fvar "JSVerify.valueOf" Common.dummy_pos
let _Void   = mk_fvar "JSVerify.void"    Common.dummy_pos

let _AbsEq  = mk_fvar "JSVerify.absEq"   Common.dummy_pos
let _AbsEqBool = mk_fvar "JSVerify.absEqBool"  Common.dummy_pos
let _RefEq  = mk_fvar "JSVerify.refEq"   Common.dummy_pos
let _RefEqBool = mk_fvar "JSVerify.refEqBool"  Common.dummy_pos
let _InExp  = mk_fvar "JSVerify.inExp"   Common.dummy_pos
let _InstOf = mk_fvar "JSVerify.instOf"  Common.dummy_pos

(* We should probably reduce this to something simpler, looking up the prototype and what-not. *)
let _New    = mk_fvar "JSVerify.newObj"  Common.dummy_pos

(* Prefix operators *)
let _LNot   = mk_fvar "JSVerify.lnot"    Common.dummy_pos
let _BNot   = mk_fvar "JSVerify.bnot"    Common.dummy_pos
let _Pos    = mk_fvar "JSVerify.pos"     Common.dummy_pos
let _Neg    = mk_fvar "JSVerify.neg"     Common.dummy_pos

(* Infix operators *)
let _Add    = mk_fvar "JSVerify.opAddition"     Common.dummy_pos
let _LT     = mk_fvar "JSVerify.lt"      Common.dummy_pos
let _LTEq   = mk_fvar "JSVerify.lteq"    Common.dummy_pos
let _GT     = mk_fvar "JSVerify.gt"      Common.dummy_pos
let _GTEq   = mk_fvar "JSVerify.gteq"    Common.dummy_pos
let _Eq     = mk_fvar "JSVerify.eq"      Common.dummy_pos
let _NEq    = mk_fvar "JSVerify.neq"     Common.dummy_pos
let _SEq    = mk_fvar "JSVerify.seq"     Common.dummy_pos
let _NSEq   = mk_fvar "JSVerify.seq"     Common.dummy_pos
let _LAnd   = mk_fvar "JSVerify.land"    Common.dummy_pos
let _LOr    = mk_fvar "JSVerify.lor"     Common.dummy_pos
let _Mul    = mk_fvar "JSVerify.mul"     Common.dummy_pos
let _Div    = mk_fvar "JSVerify.div"     Common.dummy_pos
let _Mod    = mk_fvar "JSVerify.mod"     Common.dummy_pos
let _Sub    = mk_fvar "JSVerify.sub"     Common.dummy_pos
let _LSh    = mk_fvar "JSVerify.lsh"     Common.dummy_pos
let _SpRSh  = mk_fvar "JSVerify.sprsh"   Common.dummy_pos
let _ZfRSh  = mk_fvar "JSVerify.zfrsh"   Common.dummy_pos
let _BAnd   = mk_fvar "JSVerify.band"    Common.dummy_pos
let _BXor   = mk_fvar "JSVerify.bxor"    Common.dummy_pos
let _BOr    = mk_fvar "JSVerify.bor"     Common.dummy_pos

let DST_typ = Type_lid(lid_of_text "Prims.DST" Common.dummy_pos, Common.dummy_pos)
let initial_heap_pred = Type_lid(lid_of_text "DOM.InitialHeap" Common.dummy_pos, Common.dummy_pos)
let dyn_typ    = Type_lid(lid_of_text "JSVerify.dyn" Common.dummy_pos, Common.dummy_pos)
let result_typ = Type_lid(lid_of_text "Prims.result" Common.dummy_pos, Common.dummy_pos)
let heap_typ = Type_lid(lid_of_text "Prims.heap" Common.dummy_pos, Common.dummy_pos)
let unit_typ = Type_lid(Const.unit_lid, Common.dummy_pos)
  
let freshint = 
  let ctr = ref 0 in 
     fun () -> incr ctr; !ctr

let sconst_of_string (s:string) : Sugar.sconst = Const_string (Util.unicodeEncoding.GetBytes(s), Absyn.dummyRange)
let exprconst_of_string s p = Expr_const(sconst_of_string s, range_of_pos p)
let synexpr_of_prefixOp (op) =
    match op with
        | JavaScriptSyntax.PrefixLNot -> nyi "'!' operator" (* should have been caught earlier for direct translation *)
        | JavaScriptSyntax.PrefixBNot -> _BNot
        | JavaScriptSyntax.PrefixPlus -> _Pos
        | JavaScriptSyntax.PrefixMinus -> _Neg
        | JavaScriptSyntax.PrefixTypeof -> _TypeOf
        | JavaScriptSyntax.PrefixVoid -> _Void
        | JavaScriptSyntax.PrefixDelete -> _Delete

let synexpr_of_infixOp (op) =
    match op with
        | JavaScriptSyntax.OpLT -> _LT
        | JavaScriptSyntax.OpLEq -> _LTEq
        | JavaScriptSyntax.OpGT -> _GT
        | JavaScriptSyntax.OpGEq -> _GTEq
        | JavaScriptSyntax.OpIn -> nyi "'in' operator" (* should have been desugared *)
        | JavaScriptSyntax.OpInstanceof -> nyi "'instanceof' operator" (* should have been desugared *)
        | JavaScriptSyntax.OpEq -> _Eq
        | JavaScriptSyntax.OpNEq -> _NEq
        | JavaScriptSyntax.OpStrictEq -> _SEq
        | JavaScriptSyntax.OpStrictNEq -> _NSEq
        | JavaScriptSyntax.OpLAnd -> nyi "'and' operator" (* should have been caught earlier for direct translation *)
        | JavaScriptSyntax.OpLOr -> nyi "'or' operator" (* should have been caught earlier for direct translation *)
        | JavaScriptSyntax.OpMul -> _Mul
        | JavaScriptSyntax.OpDiv -> _Div
        | JavaScriptSyntax.OpMod -> _Mod
        | JavaScriptSyntax.OpSub -> _Sub
        | JavaScriptSyntax.OpLShift -> _LSh
        | JavaScriptSyntax.OpSpRShift -> _SpRSh
        | JavaScriptSyntax.OpZfRShift -> _ZfRSh
        | JavaScriptSyntax.OpBAnd -> _BAnd
        | JavaScriptSyntax.OpBXor -> _BXor
        | JavaScriptSyntax.OpBOr -> _BOr
        | JavaScriptSyntax.OpAdd -> nyi "'addition' operator" (* should have been desugared *)
    
let jsmin_exp_of_string s p = 
  JSMinSyntax.EValue(p, 
                     JSMinSyntax.VConstant(p, JSMinSyntax.CBuiltIn 
                                             (JavaScriptSyntax.CString s)))

let synexpr_of_const (b : JSMinSyntax.builtin) (p : pos) : Sugar.synexpr =
  let r = range_of_pos p in
  match b with
    | JSMinSyntax.builtin.CBool (v) -> mk_app _Bool (Expr_const (Sugar.Const_bool v, r)) p
    | JSMinSyntax.builtin.CInt (v) -> mk_app _Num (Expr_const (Sugar.Const_float (float v), r)) p
    | JSMinSyntax.builtin.CNull -> _Null
    | JSMinSyntax.builtin.CNum (v) -> mk_app _Float (Expr_const (Sugar.Const_float v, r)) p
    | JSMinSyntax.builtin.CRegexp (e, g, i) -> nyi "regular expressions"
    | JSMinSyntax.builtin.CString (v) -> mk_app _Str (exprconst_of_string v p) p
    | JSMinSyntax.builtin.CUndefined -> _Undef

let thunk e p = 
  let r = range_of_pos p in 
    Expr_lambda((SPats([], r), e, r))

let abs x body p = 
  let r = range_of_pos p in 
    Expr_lambda(SPats([(SPat_as(ident(x,r), r))], r), 
                body, 
                r)

let dynvarpat x r = Pat_typed(Pat_as(Pat_wild r, ident(x,r), false, r), 
                              dyn_typ, 
                              r)
let varpat x r = Pat_as(Pat_wild r, ident(x,r), false, r) 
let pat_of_args args r = 
  match args with 
    | [] -> Pat_const(Const_unit, r)
    | _ -> Pat_paren(Pat_tuple(args |> List.map (fun id -> varpat id r), r), r)

let rec synexpr_of_value env (v : JSMinSyntax.value) : Sugar.synexpr * env =
  match v with
    | JSMinSyntax.VConstant (p, JSMinSyntax.CBuiltIn b) ->
        synexpr_of_const b p, env

    | JSMinSyntax.VConstant (p, JSMinSyntax.CThis) -> 
        mk_local "this" p, env

    | JSMinSyntax.VConstant (p, JSMinSyntax.CArguments) -> 
        mk_local "arguments" p, env

    | JSMinSyntax.VId (p, name) ->
        if List.contains name env.gamma  
        then mk_deref (mk_local name p) p, env
        else raise (Trans(spr "Unbound local: %s" name, p))

    | JSMinSyntax.VLambda (p, args, body) -> 
        let r = range_of_pos p in 
        let t = Type_tid(freshint(), r) in
        let t = Type_named (posToString p, t, r) in
        Hashtbl.add env.callgraph.targets v t;
        let body, env = synexpr_of_stmt env body in
          mk_app (mk_app (mk_tapp _MkFun [t] p) 
                         (Expr_const(sconst_of_string (posToString p), Absyn.dummyRange)) p)
                 (mksyn_match_lambdas
                        false
                        (range_of_pos p)
                        [dynvarpat "this" r; dynvarpat "arguments" r]
                        body) p, env

    | JSMinSyntax.VObject (p, fields) -> 
        let fnames, vals = List.unzip fields in 
        let vals, env = List.fold_left (fun (out, env) f -> let f, env = synexpr_of_exp env f in f::out, env) ([], env) vals in 
        mk_object p fnames (List.rev vals), env

    | JSMinSyntax.VGlobal (p) ->
        mk_app _Obj (mk_local "global" p) p, env

    | JSMinSyntax.VLocals (p, scopesuffix) ->
        mk_local ("locals" + scopesuffix) p, env

(*
 * Sets up a while loop of the form:
 *    let h0 = get () in
 *    let _ = __whilecall__
 *       (fun () -> ...body... )
 *
 * where "let h0 = get ()" sets h0 to the current heap.
 *
 * and the __whilecall__ portion is defined by the argument. This
 * could be a simple reference to Prims._while, or it could be a more
 * complex type dependent argument, such as:
 *    Prims._while<(Inv locals h0),_,_>
 *)
and mk_while p env guard body whilecall =
    let r = range_of_pos p in
    let guard, env = synexpr_of_exp env guard in
    let body, env = synexpr_of_stmt env body in
    Expr_let(false, false, [Binding(NormalBinding, 
                                    varpat "h0" r,
                                    BindingExpr(None, mk_app (mk_local "get" p) (Expr_const (Const_unit, r)) p),
                                    r)],
            (mk_app_l [whilecall;
                      thunk guard p; 
                      thunk body p] p),
            r), env
        
and mk_object p fnames (exprs: Sugar.synexpr list) =
  let r = range_of_pos p in
  Expr_let(false, false, [Binding(NormalBinding,
                                  varpat "object" r,
                                  BindingExpr(None, (mk_app _Alloc (Expr_const (Const_unit, r)) p)),
                                  r)],
           List.foldBack2 (fun fname expr rest -> Expr_seq (true, mk_app_l [_Update;
                                                                            (mk_local "object" p);
                                                                            exprconst_of_string fname p;
                                                                            expr] p,
                                                            rest, r)) fnames exprs (mk_local "object" p), r)

(*
* We special case if(a === b) because our refEqBool function internally coerces the arguments, rather than coercing them explicitly.
*)
and mk_if_guard env (guard_jsmin : JSMinSyntax.exp) (guard_exp : Sugar.synexpr)
                    (true_exp : Sugar.synexpr) (false_exp : Sugar.synexpr) (p : pos) : Sugar.synexpr =
  let r = range_of_pos p in
  match guard_jsmin with
    | JSMinSyntax.EBuiltIn (p, JSMinSyntax.BRefEquality (lhs, rhs)) ->
        let e1, env = synexpr_of_exp env lhs in
        let e2, env = synexpr_of_exp env rhs in
            Expr_cond(mk_app_l [_RefEqBool; e1; e2] p, true_exp, Some false_exp, r, r)
    | JSMinSyntax.EBuiltIn (p, JSMinSyntax.BAbstractEquality (lhs, rhs)) ->
        let e1, env = synexpr_of_exp env lhs in
        let e2, env = synexpr_of_exp env rhs in
            Expr_cond(mk_app_l [_AbsEqBool; e1; e2] p, true_exp, Some false_exp, r, r)
    | _ -> Expr_cond(mk_app_l [ _CoerceBool; guard_exp ] p,
                     true_exp, Some false_exp, r, r)
      
and synexpr_of_exp env e : Sugar.synexpr * env = let e, _, env = synexpr_of_exp' env e in e, env

and synexpr_of_exp' env (e : JSMinSyntax.exp) : (Sugar.synexpr * option<Sugar.synexpr> * env) = 
  match e with
    | JSMinSyntax.EValue (p, v) -> 
        let e, env = synexpr_of_value env v in 
            e, None, env

    | JSMinSyntax.EOp1 (p, op, e) -> 
        let r = range_of_pos p in
        let e, env = synexpr_of_exp env e in 
        (*
         * See comment in EOp2 re: operators that can be translated directly to F*.
         *)
        begin match op with
            | JavaScriptSyntax.PrefixLNot -> mk_app (mk_fvar "not" Common.dummy_pos) (mk_app_l [_CoerceBool; e] p) p, None, env
            | _ -> mk_app (synexpr_of_prefixOp op) e p, None, env
        end

    | JSMinSyntax.EOp2 (p, op, e1, e2) ->
        let r = range_of_pos p in
        let e1, env = synexpr_of_exp env e1 in 
        let e2, env = synexpr_of_exp env e2 in 
        (*
         * For some operators that can translate directly to F*, we do that translation here so we can use the
         * built in F* operators (such as for "&&" and "||"). For other operators, we need to translate to special
         * function calls that can handle all the intricacies of JS semantics.
         *)
        begin match op with
                // Currently, the monadic inference doesn't allow us to use && and || directly.
                (*
                | JavaScriptSyntax.OpLAnd -> mk_app _Bool (mksyn_infix r r (mk_app_l [_CoerceBool; e1] p) "&&" (mk_app_l [_CoerceBool; e2] p)) p, None, env
                | JavaScriptSyntax.OpLOr -> mk_app _Bool (mksyn_infix r r (mk_app_l [_CoerceBool; e1] p) "||" (mk_app_l [_CoerceBool; e2] p)) p, None, env
                *)
                | JavaScriptSyntax.OpLAnd -> mk_app _Bool (mk_app_l [_LAnd; e1; e2] p) p, None, env
                | JavaScriptSyntax.OpLOr -> mk_app _Bool (mk_app_l [_LOr; e1; e2] p) p, None, env
                | _ -> mk_app (mk_app (synexpr_of_infixOp op) e1 p) e2 p, None, env
        end

    | JSMinSyntax.EDot (p, obj, field) ->
        let receiver, env = synexpr_of_exp env obj in 
        let projection = mk_app 
          (mk_app _Select receiver p)
          (exprconst_of_string field p) p in 
          projection, Some receiver, env

    | JSMinSyntax.EBracket (p, obj, field) -> 
        let receiver,env = synexpr_of_exp env obj in 
        let field,env = synexpr_of_exp env field in
        let projection = mk_app 
          (mk_app _Select receiver p)
          (mk_app _CoerceString field p) p in
        projection, Some receiver,env

    | JSMinSyntax.ECall (p, jsfunc, Some receiver, args)  
    | JSMinSyntax.ECallDom (p, jsfunc, receiver, args, _) ->
        let callnode = e in
        let func, recv,env = synexpr_of_exp' env jsfunc in 
        let receiver,env = synexpr_of_exp env receiver in
        let _, args, env = List.fold_left (fun (ix, out, env) arg -> 
                                let arg, env = synexpr_of_exp env arg in
                                (ix+1, out@[(spr "%d" ix, arg)], env)) (0, [], env) args in 
        let fnames, args  = List.unzip args in 
        let arg = mk_object p  fnames args in 
        let app = match try_resolve_callee env callnode p with 
          | None -> _apply
          | Some t -> (match t with
              | Type_named("addListener", tlid, _) ->
                // apply_hint_ex_witness'<t, tlid, callbackTx>
                // find if EValue(VId("addListenerCallback")) is mapped in callees
                begin
                  let mutable keyopt = None in 
                  for key in env.callgraph.callees.Keys do 
                    (match key with
                      | JSMinSyntax.EValue(_, JSMinSyntax.VId(_, "addListenerCallback")) -> keyopt <- Some key
                      | _ -> ())
                  done;
                  match keyopt with
                    | Some key -> (match try_resolve_callee env key p with
                                     | None -> mk_tapp _applyHint [t] p
                                     | Some callbackTx -> mk_tapp _applyHintEx [t; Type_lid(p2l ["DOM"; "addListenerExTx"], Absyn.dummyRange); callbackTx] p)
                    | _ -> mk_tapp _applyHint [t] p
                  end
              | Type_named("sendRequest2", tlid, _) ->
                // apply_hint_ex_witness'<t, tlid, callbackTx>
                // find if EValue(VId("sendRequestCallback")) is mapped in callees
                begin
                  let mutable keyopt = None in 
                  for key in env.callgraph.callees.Keys do 
                    (match key with
                      | JSMinSyntax.EValue(_, JSMinSyntax.VId(_, "sendRequestCallback")) -> keyopt <- Some key
                      | _ -> ())
                  done;
                  match keyopt with
                    | Some key -> (match try_resolve_callee env key p with
                                     | None -> mk_tapp _applyHint [t] p
                                     | Some callbackTx -> mk_tapp _applyHintEx [t; Type_lid(p2l ["DOM"; "sendRequestExTx2"], Absyn.dummyRange); callbackTx] p)
                    | _ -> mk_tapp _applyHint [t] p
                  end
              | _ -> mk_tapp _applyHint [t] p) in 
        let call = 
          mk_app_l [app;
                    func;
                    receiver;
                    arg] p in
          call, None, env

    | JSMinSyntax.ECall _ -> failwith "receiver object not resolved"
    
    | JSMinSyntax.ECallInvariant (p, inv, locals) -> System.Exception "Invariant calls should be dealt with before they are directly reached in the AST." |> raise

    | JSMinSyntax.EBuiltIn (p, op) -> begin
        match op with
            | JSMinSyntax.BToInt32 (e) -> nyi "coercion to int32"
            | JSMinSyntax.BToNumber (e) -> nyi "coercion to number"
            | JSMinSyntax.BToObject (e) -> nyi "coercion to object"
            | JSMinSyntax.BToString (e) -> nyi "coercion to string"
        
            | JSMinSyntax.BDelete (obj, field) -> 
                    let obj, env = synexpr_of_exp env obj in
                    let field, env = synexpr_of_exp env field in
                    (mk_app_l [_Delete; obj; field] p, None, env)

            | JSMinSyntax.BTypeOf (e) -> 
                    let e, env = synexpr_of_exp env e in
                    (mk_app _TypeOf e p), None, env

            | JSMinSyntax.BValueOf (e) ->
                    let e, env = synexpr_of_exp env e in
                     (mk_app _ValOf e p), None, env
   
            | JSMinSyntax.BAbstractEquality (e1, e2) -> 
                    let e1, env = synexpr_of_exp env e1 in
                    let e2, env = synexpr_of_exp env e2 in
                    (mk_app_l [_AbsEq; e1; e2] p), None, env

            | JSMinSyntax.BRefEquality (e1, e2) -> 
                    let e1, env = synexpr_of_exp env e1 in
                    let e2, env = synexpr_of_exp env e2 in
                    (mk_app_l [_RefEq; e1; e2] p), None, env

            | JSMinSyntax.BIn (e1, e2) -> 
                    let e1, env = synexpr_of_exp env e1 in
                    let e2, env = synexpr_of_exp env e2 in
                    (mk_app_l [_InExp; e1; e2] p), None, env

            | JSMinSyntax.BInstanceOf (e1, e2) -> 
                    let e1, env = synexpr_of_exp env e1 in
                    let e2, env = synexpr_of_exp env e2 in
                     (mk_app_l [_InstOf; e1; e2] p), None, env

            | JSMinSyntax.BAddition (e1, e2) -> 
                    let e1, env = synexpr_of_exp env e1 in
                    let e2, env = synexpr_of_exp env e2 in
                    (mk_app_l [_Add; e1; e2] p), None, env
        end

    | JSMinSyntax.EAssign (p, v, e) -> 
        let e, env = synexpr_of_exp env e in 
        mk_app_l [_Assign; 
                  mk_local v p; 
                  e] p, None, env
                      
    | JSMinSyntax.EDotAssign (p, obj, field, e) ->
        let obj, env = synexpr_of_exp env obj in
        let e, env = synexpr_of_exp env e in
        mk_app_l [_Update;
                  obj;
                  exprconst_of_string field p; 
                  e] p, None, env

    | JSMinSyntax.EBracketAssign (p, obj, field, assignment) -> 
        let receiver, env = synexpr_of_exp env obj in
        let field,env = synexpr_of_exp env field in
        let obj, env = synexpr_of_exp env obj in
        let assignment, env = synexpr_of_exp env assignment in
        let upd = 
          mk_app_l [_Update;
                    obj;
                    (mk_app _CoerceString field p);
                    assignment] p in 
          upd, None, env

    | JSMinSyntax.ENew (p, obj, args) -> 
          let obj, env = synexpr_of_exp env obj in
          let args, env = List.fold_left (fun (out, env) arg -> 
                                            let arg, env = synexpr_of_exp env arg in 
                                            arg::out, env) ([], env) args in 
          let args = List.rev args in 
            (mk_app_l ([_New;
                        obj;
                        Expr_list(args, range_of_pos p)]) p), None, env

    | JSMinSyntax.EList (p, e1, e2) -> 
        let e1, env = synexpr_of_exp env e1 in
        let e2, env = synexpr_of_exp env e2 in 
          Expr_seq (true,
                    e1, 
                    e2,
                    range_of_pos p), None, env

    | JSMinSyntax.EIf (p, guard, true_exp, false_exp) -> 
        let guard_exp, env = synexpr_of_exp env guard in
        let true_exp, env = synexpr_of_exp env true_exp in
        let false_exp, env = synexpr_of_exp env false_exp in
          mk_if_guard env guard guard_exp true_exp false_exp p, None, env

    | JSMinSyntax.EVar (p, x, e1, e2) ->
        let r = range_of_pos p in 
        let e1, env = synexpr_of_exp env e1 in
        let e2, env = synexpr_of_exp {env with gamma=x::env.gamma} e2 in
          Expr_let(false, false, [Binding(NormalBinding, 
                                          varpat x r, 
                                          BindingExpr(None, e1),
                                          r)],
                   e2, 
                   r), None, {env with gamma=env.gamma}

and synexpr_of_stmt env (s : JSMinSyntax.stmt) : Sugar.synexpr * env = 
  match s with
    | JSMinSyntax.SSeq (p, s1, s2) -> 
        let seq s1 s2 = 
          let s1, env = synexpr_of_stmt env s1 in 
          let s2, env = synexpr_of_stmt env s2 in 
            Expr_seq(true, s1, s2, range_of_pos p), env in
        begin match (s1, s2) with
                | JSMinSyntax.SExp(JSMinSyntax.ECallInvariant (p1, inv, locals)), JSMinSyntax.SSeq (p2, JSMinSyntax.SWhile (p3, guard, body), _) ->
                    let r = range_of_pos p in
                    mk_while p env guard body
                            (let t = Type_app (Type_lid (mk_lid "Inv", r), [Type_term_index (mk_local locals p, r); Type_term_index (mk_local "h0" p, r)], r) in
                                Expr_tyapp (_While, [t; Type_anon r; Type_anon r], r))
                | _ -> seq s1 s2
        end

    | JSMinSyntax.SIf (p, guard, true_stmt, false_stmt) -> 
        let guard_exp, env = synexpr_of_exp env guard in
        let true_stmt, env = synexpr_of_stmt env true_stmt in 
        let false_stmt, env = synexpr_of_stmt env false_stmt in 
        let r = range_of_pos p in
            mk_if_guard env guard guard_exp true_stmt false_stmt p, env

    | JSMinSyntax.SWhile (p, guard, body) -> mk_while p env guard body _While

    | JSMinSyntax.SReturn (p, retval) -> 
        //mk_app _Return (synexpr_of_exp env retval) p (* Need to handle return properly *)
        (synexpr_of_exp env retval)

    | JSMinSyntax.SBreak (p) -> 
        _Break, env
       
    | JSMinSyntax.SEmpty (p) -> 
        _Undef, env

    | JSMinSyntax.SExp (e) -> 
        synexpr_of_exp env e 

    | JSMinSyntax.SForInStmt (p, v, obj, body) -> 
        let obj, env = synexpr_of_exp env obj in 
        let body, env = synexpr_of_stmt env body in
        mk_app_l [_ForIn;
                  obj;
                  abs v body p] p, env
          
    | JSMinSyntax.SVar (p, v, e, body) -> 
        let r = range_of_pos p in 
        let e, env = synexpr_of_exp env e in 
        let body, env' = synexpr_of_stmt {env with gamma=v::env.gamma} body in 
          Expr_let(false, false, [Binding(NormalBinding, 
                                          varpat v r, 
                                          BindingExpr(None, e),
                                          r)],
                   body, 
                   r), {env' with gamma=env.gamma}
            
let rec to_fstar env (prog : JSMinSyntax.prog) : Sugar.ModuleImplDecls * Range.range * env =
  match prog with
    | JSMinSyntax.PStmt (p, s) ->
        let r = range_of_pos p in 
        let s, stmt = synexpr_of_stmt env s in
        let main = Binding(NormalBinding,
                           Pat_lid(mk_lid "main", 
                                   [(Pat_typed (varpat "u" r, unit_typ, r))], 
                                   r), 
                           BindingExpr(None, s), r) in 
          
        let result_dyn_typ = Type_app(result_typ, [dyn_typ], r) in
        let post_tvar = Typar(mk_id "Post", Some (Kind_dcon(None, result_dyn_typ, Kind_dcon(None, heap_typ, Kind_erasable)))) in
        let main_typ = Type_fun((None, unit_typ), 
                                Type_app(DST_typ, 
                                         [dyn_typ;
                                          Type_tlam(post_tvar, 
                                                    Type_lam(mk_id "h", 
                                                             heap_typ,
                                                             Type_formula(Form_conj(Form_atom(Atom_pred(Type_app(initial_heap_pred, 
                                                                                                                 [Type_term_index(Expr_id_get(mk_id "h"), r)], 
                                                                                                                 r)),
                                                                                              r),
                                                                                    Form_all(mk_id "x", 
                                                                                             result_dyn_typ, 
                                                                                             Form_all(mk_id "h'", 
                                                                                                      heap_typ,
                                                                                                      Form_atom(Atom_pred(Type_app(Type_var(Typar(mk_id "Post", None), r),
                                                                                                                                   [Type_term_index(Expr_id_get(mk_id "x"),r);
                                                                                                                                    Type_term_index(Expr_id_get(mk_id "h'"),r)],
                                                                                                                                   r)),
                                                                                                               r),
                                                                                                      r, [], false),
                                                                                             r, [], false), 
                                                                                    r), 
                                                                          r), 
                                                             r),
                                                    r)], 
                                         r),
                                r) in
        let vdecl = Def_val(mk_id "main", main_typ, r) in 
          [vdecl;Def_let(false, [main], r)], r, env
            
let translate mname cg p = 
    let mdecls, r, _ = to_fstar {gamma=[]; callgraph=cg} p in 
    let mdecls = (Def_open(Const.jsver_lid, Absyn.dummyRange)::
                    Def_open(Const.dom_lid, Absyn.dummyRange)::mdecls) in
      Sugar.ParsedImplFile([Sugar.NamedTopModuleImpl(Sugar.ModuleOrNamespaceImpl(Sugar.lid_of_path [mname] r, None, mdecls, r))])
