#light "off"

module Microsoft.FStar.Z3Encoding.Basic
open Microsoft.FStar
open Absyn
open Util
open Term

type sort = int

let kOfName =  "KindOf"
let kindOf t  = App(kOfName, Arrow(Type_sort, Kind_sort), [| t |]) 

let tOfName =  "TypeOf"
let typeOf t  = App(tOfName, Arrow(Term_sort, Type_sort), [| t |]) 

let kctrName =  "KCtrId"
let kctrId t  = App(kctrName, Arrow(Kind_sort, Int_sort), [| t |]) 

let tctrName  =  "TCtrId"
let tctrId t  = App(tctrName, Arrow(Type_sort, Int_sort), [| t |]) 

let ctrName =  "CtrId"
let ctrId  t  = App(ctrName, Arrow(Term_sort, Int_sort), [| t |]) 

let boxName =  "Box"
let box    t  = App(boxName, Arrow(Int_sort, Term_sort), [| t |]) 

let unboxName =  "Unbox"
let unbox  t  = App(unboxName, Arrow(Term_sort, Int_sort), [| t |]) 

let intName = "Int_type"
let intType  = FreeV(intName, Type_sort)

let strName   = "String_type"
let strType   = FreeV(strName, Type_sort)

let floatName   = "Float_type"
let floatType   = FreeV(floatName, Type_sort)

let boolName = "Bool_type"
let boolType = FreeV(boolName, Type_sort)

let unitName= "Unit_type"
let unitType  = FreeV(unitName, Type_sort)
  
let starName = "Star"
let Star_kind_term = FreeV(starName, Kind_sort)
let starTerm = Star_kind_term

let tkName =  "TK"
let tkInv1 =  "TKInv1"
let tkInv2 =  "TKInv2"
let mkTK t k = App(tkName, Arrow(Type_sort, Arrow(Kind_sort, Kind_sort)), [| t; k |])
let mkTKInv1 t = App(tkInv1, Arrow(Kind_sort, Type_sort), [| t |])
let mkTKInv2 t = App(tkInv2, Arrow(Kind_sort, Kind_sort), [| t |])

let kkName =  "KK"
let kkInv1 =  "KKInv1"
let kkInv2 =  "KKInv2"
let mkKK k1 k2 = App(kkName, Arrow(Kind_sort, Arrow(Kind_sort, Kind_sort)), [| k1; k2 |])
let mkKKInv1 t = App(kkInv1, Arrow(Kind_sort, Kind_sort), [| t |])
let mkKKInv2 t = App(kkInv2, Arrow(Kind_sort, Kind_sort), [| t |])

let ttName =  "TT"
let ttInv1 =  "TTInv1"
let ttInv2 =  "TTInv2"
let mkTT t1 t2 = App(ttName, Arrow(Type_sort, Arrow(Type_sort, Type_sort)), [| t1; t2 |])
let mkTTInv1 t = App(ttInv1, Arrow(Type_sort, Type_sort), [| t |])
let mkTTInv2 t = App(ttInv2, Arrow(Type_sort, Type_sort), [| t |])

let tvName =  "TV"
let tvInv1 =  "TVInv1"
let tvInv2 =  "TVInv2"
let mkTV t v = App(tvName, Arrow(Type_sort, Arrow(Term_sort, Type_sort)), [| t; v |])
let mkTVInv1 t = App(tvInv1, Arrow(Type_sort, Type_sort), [| t|])
let mkTVInv2 t = App(tvInv2, Arrow(Type_sort, Term_sort), [| t |])

let tfunName = "TFun"
let tfunTerm = FreeV(tfunName, Type_sort)
let mkTfun t1 t2 = mkTT (mkTT tfunTerm t1) t2

let ttupName = "TTup"
let ttupTerm = FreeV(ttupName, Type_sort)
let mkTtup t1 t2 = mkTT (mkTT ttupTerm t1) t2

let tlamName = "TLam"
let tlamTerm = FreeV(tlamName, Type_sort)
let mkTlam t1 t2 = mkTT (mkTT tlamTerm t1) t2

let ttfunName =  "TTFun"
let ttfunInv1 =  "TTFunInv1"
let ttfunInv2 =  "TTFunInv2"
let mkTtfun k t = App(ttfunName, Arrow(Kind_sort, Arrow(Type_sort, Type_sort)), [| k; t |])
let mkTtfunInv1 t = App(ttfunInv1, Arrow(Type_sort, Kind_sort), [| t |])
let mkTtfunInv2 t = App(ttfunInv2, Arrow(Type_sort, Type_sort), [| t |])

let ttlamName =  "TTLam"
let ttlamInv1 =  "TTLamInv1"
let ttlamInv2 =  "TTLamInv2"
let mkTtlam k t = App(ttlamName, Arrow(Kind_sort, Arrow(Type_sort, Type_sort)), [| k; t |])
let mkTtlamInv1 t = App(ttlamInv1, Arrow(Type_sort, Kind_sort), [| t |])
let mkTtlamInv2 t = App(ttlamInv2, Arrow(Type_sort, Type_sort), [| t |])


(* :assumption (= (KCtrId Star) 0) *)
let StarAssumption = 
  let tm = Eq (kctrId starTerm, Integer 0) in 
    Assume(tm, None, AName "Star")

let Forall (i,j,names,body) = Forall(i,j,names,body)
(* :assumption (forall ((T Type) (K Kind))            *)
(*                      (and (= (KCtrId (TK T K)) 1)) *)
(*                           (= (TK_Inv_1 (TK T K)) T) *)
(*                           (= (TK_Inv_2 (TT T K)) K)) *)
let TKAssumption = 
  let tref = termref() in 
  let kref = termref() in 
  let t = BoundV(1, Type_sort,  "t", tref) in
  let k = BoundV(0, Kind_sort,  "k", kref) in
  let tk = mkTK t k in
  let tm = Forall ([], [| Type_sort; Kind_sort |], [| (Inr <| bvdef_of_str "t", tref); (Inl <| bvdef_of_str "k", kref) |], 
                   (And (Eq (kctrId tk, Integer 1), 
                         And(Eq (mkTKInv1 tk, t), 
                             Eq (mkTKInv2 tk, k))))) in 
    Assume(tm, None, AName "TK")

(* :assumption (forall ((K1 Kind) (K2 Kind))            *)
(*                      (and (= (KCtrId (KK K1 K2)) 2)) *)
(*                           (= (KK_Inv_1 (KK K1 K2)) K1) *)
(*                           (= (KK_Inv_2 (KK K1 K2)) K2)) *)
let KKAssumption = 
  let k1ref = termref() in
  let k2ref = termref() in
  let k1 = BoundV(1, Kind_sort,  "k1", k1ref) in
  let k2 = BoundV(0, Kind_sort,  "k2", k2ref) in
  let kk = mkKK k1 k2 in
  let tm = Forall ([], [| Kind_sort; Kind_sort |], [| (Inl <| bvdef_of_str "k1", k1ref); (Inl <| bvdef_of_str "k2", k2ref) |], 
                   (And (Eq (kctrId kk, Integer 2), 
                         And(Eq (mkKKInv1 kk, k1), 
                             Eq (mkKKInv2 kk, k2))))) in 
    Assume(tm, None, AName "KK")

(* :assumption (forall ((T1 Type) (T2 Type)) *)
(*                      (and (= (TCtrId (TT T1 T2)) 1)) *)
(*                           (= (TT_Inv_1 (TT T1 T2)) T1) *)
(*                           (= (TT_Inv_2 (TT T1 T2)) T2)) *)
let TTAssumption = 
  let t1ref = termref() in
  let t2ref = termref() in 
  let t1 = BoundV(1, Type_sort,  "t1", t1ref) in 
  let t2 = BoundV(0, Type_sort,  "t2", t2ref) in 
  let tt = mkTT t1 t2 in
  let tm = Forall ([], [| Type_sort; Type_sort |], [| (Inr <| bvdef_of_str "t1", t1ref); (Inr <| bvdef_of_str "t2", t2ref) |], 
                   (And (Eq (tctrId tt, Integer 1), 
                         And(Eq (mkTTInv1 tt, t1), 
                             Eq (mkTTInv2 tt, t2))))) in 
    Assume(tm, None, AName "TT")

(* :assumption (forall ((T1 Type) (V2 Term)) *)
(*                      (and (= (TCtrId (TV T1 V2)) 2)) *)
(*                           (= (TV_Inv_1 (TV T1 V2)) T1) *)
(*                           (= (TV_Inv_2 (TV T1 V2)) V2)) *)
let TVAssumption = 
  let tref = termref() in
  let vref = termref() in
  let t = BoundV(1, Type_sort,  "t", tref) in
  let v = BoundV(0, Term_sort,  "v", vref) in
  let tv = mkTV t v in
  let tm = Forall ([], [| Type_sort; Term_sort |], [| (Inr <| bvdef_of_str "t", tref); (Inr <| bvdef_of_str "v", vref) |], 
                   (And (Eq (tctrId tv, Integer 2), 
                         And(Eq (mkTVInv1 tv, t), 
                             Eq (mkTVInv2 tv, v))))) in 
    Assume(tm, None, AName "TV")                             

(* :assumption (forall ((i Int)) *)
(*                      (and (= (TCtrId (Btvar i)) 3) *)
(*                           (= (BTV_Inv (Btvar i) i)))) *)
let BTVAssumption = 
  let iref = termref() in
  let i = BoundV(0, Int_sort,  "i", iref) in
  let t = mk_Typ_btvar_term i in
  let tm = Forall ([], [| Int_sort |], [| (Inr <| bvdef_of_str "i", iref) |], 
                   Eq (mkBtvInv t, i)) in
    Assume(tm, None, AName "BTV")


(* :assumption (forall ((i Int)) *)
(*                      (and (= (CtrId (Bvar i)) 4) *)
(*                           (= (BV_Inv (Bvar i) i)))) *)
let BVAssumption = 
  let iref = termref() in
  let i = BoundV(0, Int_sort,  "i", iref) in
  let v = mk_Exp_bvar_term i in
  let tm = Forall ([], [| Int_sort |], [| (Inr <| bvdef_of_str "i", iref) |], 
                   Eq (mkBvInv v, i)) in
  (* let tm = Forall ([], [| Int_sort |], [| "i" |],  *)
  (*                  (And (Eq (ctrId v, Integer 4),  *)
  (*                        Eq (mkBvInv v, i)))) in *)
    Assume(tm, None, AName "BV")

(* :assumption (and (= (TCtrId TFun) 5) *)
(*                  (= (KindOf TFun) *)
(*                     (KK Star (TK (Bvar 0) Star)))) *)
let TFunAssumption = 
  let tm = (And (Eq (tctrId tfunTerm, Integer 5), 
                 Eq (kindOf tfunTerm,
                     mkKK starTerm (mkTK (mk_Typ_btvar 0) starTerm)))) in
    Assume(tm, None, AName "TFun")

(* :assumption (and (= (TCtrId TTup) 6) *)
(*                  (= (KindOf TTup) *)
(*                     (KK Star (TK (Bvar 0) Star)))) *)
let TTupAssumption = 
  let tm = (And (Eq (tctrId ttupTerm, Integer 6), 
                 Eq (kindOf ttupTerm,
                     mkKK starTerm (mkTK (mk_Typ_btvar 0) starTerm)))) in
    Assume(tm, None, AName "TTup")


(* :assumption (forall ((K Kind) (T Type)) *)
(*                      (and (= (TCtrId (TTFun K T)) 7)) *)
(*                           (= (TTFun_Inv_1 (TTFun K T) K)) *)
(*                           (= (TTFun_Inv_2 (TTFun K T) T)))) *)
let TTFunAssumption = 
  let kref = termref() in 
  let tref = termref() in
  let k = BoundV(1, Kind_sort, "k", kref) in
  let t = BoundV(0, Type_sort, "t", tref) in
  let ttf = mkTtfun k t in
  let tm = Forall ([], [| Kind_sort; Type_sort |], [| (Inl <| bvdef_of_str "k", kref); (Inr <| bvdef_of_str "t", tref) |], 
                   (And (Eq (tctrId ttf, Integer 7), 
                         And(Eq (mkTtfunInv1 ttf, k), 
                             Eq (mkTtfunInv2 ttf, t))))) in 
    Assume(tm, None, AName "TTFun")

(* :assumption (and (= (TCtrId TLam) 8) *)
(*                  (= (KindOf TLam) *)
(*                     (KK Star (TK (Bvar 0) Star)))) *)
let TLamAssumption = 
  let tm = (And (Eq (tctrId tlamTerm, Integer 8), 
                 Eq (kindOf tlamTerm,
                     mkKK starTerm  (mkTK (mk_Typ_btvar 0) starTerm)))) in
    Assume(tm, None, AName "TLam")

let BoundV(i,j,k) = let tref = termref() in BoundV(i,j,k,tref),tref

(* :assumption (forall ((K Kind) (T Type)) *)
(*                      (and (= (TCtrId (TTLam K T)) 7)) *)
(*                           (= (TTLam_Inv_1 (TTLam K T) K)) *)
(*                           (= (TTLam_Inv_2 (TTLam K T) T)))) *)
let TTLamAssumption = 
  let k,kref = BoundV(1, Kind_sort,"k") in
  let t,tref = BoundV(0, Type_sort,"t") in
  let ttf = mkTtlam k t in
  let tm = Forall ([], [| Kind_sort; Type_sort |], [| (Inl<| bvdef_of_str "k", kref); (Inr<| bvdef_of_str "t", tref) |], 
                   (And (Eq (tctrId ttf, Integer 9), 
                         And(Eq (mkTtlamInv1 ttf, k), 
                             Eq (mkTtlamInv2 ttf, t))))) in 
    Assume(tm, None, AName "TTLam")

(* :assumption (forall ((i Int) (t Term)) *)
(*                     (and (= (Unbox (Box i)) i)  *)
(*                          (= (Box (Unbox t)) t) *)
(*                          (= (TypeOf (Box i))  *)
(*                                     #Int))) *)
let boxUnboxAssumption = 
  let tVar,tref = BoundV(0, Term_sort, "t") in
  let tm2 = Forall ([], [| Term_sort |], [| (Inl<| bvdef_of_str "t", tref) |], 
                    (Imp(Eq (typeOf tVar, intType), 
                         Eq(box(unbox(tVar)), tVar)))) in
  let iVar,iref = BoundV(0, Int_sort,"i") in
  let tm1 = Forall ([], [| Int_sort |], [| (Inr <| bvdef_of_str "i", iref) |], 
                    Eq(unbox(box(iVar)), iVar)) in
  let iVar,iref = BoundV(0, Int_sort,"i") in
  let tm3 = Forall ([], [| Int_sort |], [| (Inr <| bvdef_of_str "i", iref) |], 
                    Eq(typeOf(box(iVar)), intType)) in 
  let tm4 = Eq(tctrId intType, Integer 10) in
  let tm5 = Eq(kindOf intType, starTerm) in
    [Assume(tm1, None, AName "unbox box"); 
     Assume(tm2, None, AName "box unbox");
     Assume(tm3, None, AName "box typing");
     Assume(tm4, None, AName "box tctrid");
     Assume(tm5, None, AName "int :: *")]

let strIdName =  "__id_of_string"
let strIdOf s = App(strIdName, Arrow(Term_sort, Int_sort), [| s |])
let strAssumption =                  
  let tm = Eq(tctrId strType, Integer 11) in 
  let tm2 = Eq(kindOf strType, starTerm) in
  let strId = DeclFun(strIdName, [| Term_sort |], Int_sort, None) in 
    [Assume(tm, None, AName "string");
     Assume(tm2, None, AName "string :: *");
     DeclFun(strIdName, [| Term_sort |], Int_sort, None)]

let boolAssumption = 
  let tm = Eq(tctrId boolType, Integer 12) in 
  let tm2 = Eq(kindOf boolType, starTerm) in
    [Assume(tm, None, AName "bool");
     Assume(tm2, None, AName "bool :: *")]

let unitAssumption =                  
  let tm = Eq(tctrId unitType, Integer 13) in 
  let tm2 = Eq(kindOf unitType, starTerm) in
    [Assume(tm, None, AName "unit");
     Assume(tm2, None, AName "unit :: *")]

let floatIdName =  "__id_of_float"
let floatIdOf s = App(floatIdName, Arrow(Term_sort, Int_sort), [| s |])
let floatAssumption =                  
  let tm = Eq(tctrId floatType, Integer 14) in 
  let tm2 = Eq(kindOf floatType, starTerm) in
  let floatId = DeclFun(floatIdName, [| Term_sort |], Int_sort, None) in 
    [Assume(tm, None, AName "float");
     Assume(tm2, None, AName "float :: *");
     DeclFun(floatIdName, [| Term_sort |], Int_sort, None)]
      
let trueName  = "true_tm"
let trueTerm = FreeV(trueName, Term_sort)
let trueAssumption = Assume(And(Eq(ctrId trueTerm, Integer -1), 
                                Eq(typeOf trueTerm, boolType)), None, AName "true")

let falseName = "false_tm"
let falseTerm = FreeV(falseName, Term_sort)
let falseAssumption = Assume(And(Eq(ctrId falseTerm, Integer -2), 
                                Eq(typeOf falseTerm, boolType)), None, AName "false")

let boolFunctionsAssumption = 
  let op_and = "op_AmpAmp" in 
  let bin_op_sort = Arrow(Term_sort, Arrow(Term_sort, Term_sort)) in
  let andDef = mkFunSym op_and [Term_sort;Term_sort] Term_sort in
  let x,xref = BoundV(0, Term_sort,"x") in 
  let andAssumptions =
    [Assume (Eq(App(op_and, bin_op_sort, [| trueTerm; trueTerm |]), trueTerm),
             None, AName "op_AmpAmp1");
     Assume(mkForall [Term_sort] [Inr<| bvdef_of_str "x", xref] None 
            (Imp(Eq(typeOf x, boolType), 
                mkAnd [Eq(App(op_and, bin_op_sort, [| x; falseTerm |]), falseTerm);
                       Eq(App(op_and, bin_op_sort, [| falseTerm; x |]), falseTerm)])),
            None, AName "op_AmpAmp2")] in 

  let x,xref = BoundV(0, Term_sort,"x") in    
  let op_or = "op_BarBar" in 
  let orDef = mkFunSym op_or [Term_sort;Term_sort] Term_sort in
  let orAssumptions =
    [Assume (Eq(App(op_or, bin_op_sort, [| falseTerm; falseTerm |]), falseTerm), 
             None, AName "op_BarBar1");
     Assume(mkForall [Term_sort] [Inr<| bvdef_of_str "x",xref] None 
              (Imp(Eq(typeOf x, boolType), 
                   (mkAnd  [Eq(App(op_or, bin_op_sort, [| trueTerm; x |]), trueTerm);
                            Eq(App(op_or, bin_op_sort, [| x; trueTerm |]), trueTerm)]))), 
            None, AName "op_BarBar")] in 
    
  let op_neg = "_dummy_op_Negation" in 
  let un_op_sort = Arrow(Term_sort, Term_sort) in 
  let negDef = mkFunSym op_neg [Term_sort] Term_sort in
  let negAssumption = Assume(mkAnd  [Eq(App(op_neg, un_op_sort,  [| trueTerm |]), falseTerm);
                                     Eq(App(op_neg, un_op_sort, [| falseTerm |]), trueTerm)], 
                             None, AName "op_BarBar") in 

    [andDef]@andAssumptions@[orDef]@orAssumptions@[negDef;negAssumption]

let unitValName = "unitVal"
let unitTerm = FreeV(unitValName, Term_sort)
let unitValAssumption = Assume(And(Eq(ctrId unitTerm, Integer -3), 
                                 Eq(typeOf unitTerm, unitType)), None, AName "unitval")

let boolTerm b = if b then trueTerm else falseTerm

let basicOps : list<op<unit>> =
  List.rev
   ([ (*:extrasorts *)
    DefSort(Kind_sort, Some "Kind");
    DefSort(Type_sort, Some "Type");
    DefSort(Term_sort, Some "Term");
    (*:extrafuns *)
    DeclFun(kOfName,  [| Type_sort |], Kind_sort, None);
    DeclFun(tOfName,  [| Term_sort |], Type_sort, None);
    DeclFun(kctrName, [| Kind_sort |], Int_sort,  None);
    DeclFun(tctrName, [| Type_sort |], Int_sort,  None);
    DeclFun(ctrName,  [| Term_sort |], Int_sort,  None);
    DeclFun(boxName,  [| Int_sort  |], Term_sort, None);
    DeclFun(unboxName,[| Term_sort |], Int_sort,  None);
    (* Kind constants *)
    DeclFun(starName, [|           |], Kind_sort, None); 
    DeclFun(tkName,   [| Type_sort;
                        Kind_sort |], Kind_sort, None);
    DeclFun(tkInv1,   [| Kind_sort |], Type_sort, None);
    DeclFun(tkInv2,   [| Kind_sort |], Kind_sort, None);
    DeclFun(kkName,   [| Kind_sort;
                        Kind_sort |], Kind_sort, None);
    DeclFun(kkInv1,   [| Kind_sort |], Kind_sort, None);
    DeclFun(kkInv2,   [| Kind_sort |], Kind_sort, None);
    (* Type constants *)
    DeclFun(ttName,   [| Type_sort;
                        Type_sort |], Type_sort, None);
    DeclFun(ttInv1,   [| Type_sort |], Type_sort, None);
    DeclFun(ttInv2,   [| Type_sort |], Type_sort, None);
    DeclFun(tvName,   [| Type_sort;
                        Term_sort |], Type_sort, None);
    DeclFun(tvInv1,   [| Type_sort |], Type_sort, None);
    DeclFun(tvInv2,   [| Type_sort |], Term_sort, None);
    DeclFun(btvName,  [| Int_sort  |], Type_sort, None);
    DeclFun(btvInv,   [| Type_sort |], Int_sort,  None);
    DeclFun(tfunName, [|           |], Type_sort, None);
    DeclFun(ttupName, [|           |], Type_sort, None);
    DeclFun(tlamName, [|           |], Type_sort, None);

    DeclFun(ttfunName,[| Kind_sort;
                        Type_sort |], Type_sort, None);
    DeclFun(ttfunInv1,[| Type_sort |], Kind_sort, None);
    DeclFun(ttfunInv2,[| Type_sort |], Type_sort, None);

    DeclFun(ttlamName,[| Kind_sort;
                        Type_sort |], Type_sort, None);
    DeclFun(ttlamInv1,[| Type_sort |], Kind_sort, None);
    DeclFun(ttlamInv2,[| Type_sort |], Type_sort, None);

    DeclFun(boolName, [|           |], Type_sort, None);
    DeclFun(intName,  [|           |], Type_sort, None);
    DeclFun(strName,  [|           |], Type_sort, None);
    DeclFun(unitName, [|           |], Type_sort, None);
    DeclFun(floatName, [|          |], Type_sort, None);
    (* Term constants *)
    DeclFun(bvName,   [| Int_sort  |], Term_sort, None);
    DeclFun(bvInv,    [| Term_sort |], Int_sort,  None);
    DeclFun(trueName, [|           |], Term_sort, None);
    DeclFun(falseName,[|           |], Term_sort, None);
    DeclFun(unitValName,[|         |], Term_sort, None);
    (*:assumptions *)
    StarAssumption;
    TKAssumption;
    KKAssumption;
    TTAssumption;
    TVAssumption;
    BTVAssumption; 
    BVAssumption; 
    TFunAssumption;
    TTupAssumption;
    TTFunAssumption;
    TLamAssumption;
    TTLamAssumption]@
    boxUnboxAssumption
    @strAssumption
    @floatAssumption
    @boolAssumption
    @unitAssumption
    @[trueAssumption;
      falseAssumption;
      unitValAssumption]
    @boolFunctionsAssumption)
    

