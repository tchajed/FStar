#light "off"

module Microsoft.FStar.Z3Encoding.Encoding

open Microsoft.FStar
open Z3Encoding.Basic
open Z3Encoding.Env
open Util
open Absyn
open Term
open Profiling 
open KindAbbrevs

type config = {skip_pf:bool;
               subterm_typing:bool}
let config = {skip_pf=true;
              subterm_typing=false}
type term = Term.term<unit>
type transenv=Env.transenv<unit>
type op = Term.op<unit>
type ops = list<op>
type qnames     = list<string> 
type qvars      = list<term>
type qsorts     = list<sort>
type phi        = term
type opState    = {ops:list<op>; 
                   env:option<Tcenv.env>;
                   ctr:int;
                   strings:list<byte[] * term * ops>;
                   floats:list<float * term * ops>;
                   cached_ops:list<lident * ops>;
                   pp_name_map:HashMultiMap<string,string>}

type res        = {term:term; 
                   subterm_phi:list<phi>; 
                   binding_phi:option<phi>}
            
let mkAndOpt p1 p2 = match p1, p2  with
  | Some p1, Some p2 -> Some (And(p1, p2))
  | Some p, None
  | None, Some p -> Some p
  | None, None -> None

let mkAndOpt_l pl = 
  List.fold_left (fun out p -> mkAndOpt p out) None pl 

let mkAnd_l l = match l with 
  | [] -> []
  | hd::tl -> [List.fold_left (fun p1 p2 -> And(p1,p2)) hd tl]
  
let join phi1 phi2 = mkAnd_l (phi1@phi2)
(* let join phi1 phi2 = (phi1@phi2) *)

(* let getPhiOpt (res:res) = mkAndOpt res.phi res.phi_binding  *)

(* let getPhi (res:res) = match getPhiOpt res with *)
(*   | Some p -> p *)
(*   | None -> raise Impos *)

//let pushOpt tenv xopt t tmopt = match xopt with 
//  | None -> tenv
//  | Some x -> push tenv (Var_binding(x, t, tmopt)) 


let is_builtin lid = 
    Sugar.lid_equals lid Const.int_lid ||
    Sugar.lid_equals lid Const.bool_lid ||
    Sugar.lid_equals lid Const.string_lid ||
    Sugar.lid_equals lid Const.unit_lid


type ST<'a>  = state<opState, 'a>
let addOp op : ST<unit>   = upd (fun s -> {s with ops=op::s.ops})
let addOps ops : ST<unit> = upd (fun s -> {s with ops=ops@s.ops})
let addPPName (k,v) : ST<unit> = get >> (fun s -> Hashtbl.add s.pp_name_map k v; ret ())
let internString bytes term ops : ST<unit> = upd (fun s -> {s with strings=(bytes,term,ops)::s.strings})
let internFloat f term ops : ST<unit> = upd (fun s -> {s with floats=(f,term,ops)::s.floats})
let gammaLid = asLid <| [ident("GAMMA", 0L)]
let addMark lid = addOp (Mark lid)
let rec removeCache lid = function
  | [] -> []
  | (lid', _, _)::tl when Sugar.lid_equals lid lid' -> tl
  | hd::tl -> hd::(removeCache lid tl)
  
let lookupCache lid signature : ST<option<ops>> = 
  get >> (fun st -> 
            match st.cached_ops |> Util.findOpt (fun (lid', _) -> 
                                                   Sugar.lid_equals lid lid') with 
              | None -> ret None
              | Some(_, ops) -> ret (Some ops))

let incrCtr : ST<int>     = get >> (fun s -> put {s with ctr=s.ctr + 1} >> (fun _ -> ret s.ctr))

let isPropErr f ktop = 
  let rec aux k = match k(* .u *)with
    | Kind_prop
    | Kind_erasable -> true
    | Kind_star 
    | Kind_affine -> false
    | Kind_dcon(_, _, k) 
    | Kind_tcon(_, _, k) -> aux k
    | _ -> (pr "Type %s has kind %A\n" (Pretty.strTyp f) ktop; raise Impos) in 
    aux ktop
      

let rec isProp k = match k(* .u *)with
  | Kind_prop
  | Kind_erasable -> true
  | Kind_star 
  | Kind_affine -> false
  | Kind_dcon(_, _, k) 
  | Kind_tcon(_, _, k) -> isProp k

let rec kindToSorts k = match k(* .u *)with
  | Kind_tcon(_, _, k) -> Type_sort::kindToSorts k
  | Kind_dcon(_, _, k) -> Term_sort::kindToSorts k
  | Kind_prop
  | Kind_erasable -> []
  | _ -> raise Impos 

let newFunSym : ST<term> = 
  incrCtr >> (fun p -> 
  let fname = spr "fun_%d" p in
  let op = DeclFun(fname, [| |], Term_sort, None) in 
  addOp op >> (fun _ -> 
  ret (FreeV(fname, Term_sort))))

let newTypSym : ST<term> = 
  incrCtr >> (fun p -> 
  let fname = spr "type_%d" p in
  let op = DeclFun(fname, [| |], Type_sort, None) in 
  addOp op >> (fun _ -> 
  ret (FreeV(fname, Type_sort))))

let newPredSym k : ST<string> = 
  incrCtr >> (fun p -> 
  let fname = spr "Pred_%d" p in
  let sorts = kindToSorts k in 
  let op = mkPred fname sorts in 
  addOp op >> (fun _ -> 
  ret fname))

let isAtom p = 
  let pred, args = AbsynUtils.flattenTypAppsAndDeps p in 
    match p.sort(* .u *)with 
      | Kind_prop 
      | Kind_erasable -> 
          (match pred.v with 
             | Typ_const _
             | Typ_btvar _ 
             | Typ_uvar _ -> true
             | _ -> false)
      | _ -> false

let is_arith d = 
  Sugar.lid_equals d.v Const.add_lid ||
  Sugar.lid_equals d.v Const.sub_lid ||
  Sugar.lid_equals d.v Const.mul_lid ||
  Sugar.lid_equals d.v Const.div_lid ||
  Sugar.lid_equals d.v Const.minus_lid 

let getBvd = function Some x -> x | None -> new_bvd None 
let mkApp s f (args:list<term<'a>>) = 
    let s = List.fold_right (fun tm s -> Arrow(tm.tmsort, s)) args s in 
    App(f,s,Array.ofList args)

(* ******************************************************************************** *)
(* Encoding core language: kinds, types, terms, formulas                            *)
(* ******************************************************************************** *)
let destructConnectives f = 
  let oneType = [Type_sort] in
  let twoTypes = [Type_sort;Type_sort] in
  let twoTerms = [Term_sort;Term_sort] in
  let connectives = [(Const.and_lid,     twoTypes);
                     (Const.or_lid,      twoTypes);
                     (Const.implies_lid, twoTypes);
                     (Const.iff_lid,     twoTypes);
                     (Const.not_lid,     oneType);
                     (Const.tag_lid,     oneType);
                     (Const.lt_lid,      twoTerms);
                     (Const.gt_lid,      twoTerms);
                     (Const.gte_lid,     twoTerms);
                     (Const.lte_lid,     twoTerms);
                     (Const.eqTyp_lid,   twoTypes);
                     (Const.eq_lid,      twoTerms@[Type_sort]);
                     (Const.eq2_lid,     twoTerms@twoTypes);
                     (Const.eqA_lid,     twoTerms@[Type_sort])] in 
  let rec aux args f lid arity =  match f.v, arity with
    | Typ_app(tc, arg), [t] 
        when (t=Type_sort && AbsynUtils.is_constructor tc lid) -> Some (lid, Inl arg::args)
    | Typ_dep(tc, arg), [t] 
        when (t=Term_sort && AbsynUtils.is_constructor tc lid) -> Some (lid, Inr arg::args)
    | Typ_app(f, arg), t::farity 
        when t=Type_sort -> aux (Inl arg::args) f lid farity
    | Typ_dep(f, arg), t::farity 
        when t=Term_sort -> aux (Inr arg::args) f lid farity
    | _ -> None in
    Util.find_map connectives (fun (lid, arity) -> aux [] f lid arity)
    
let rec encodeKind (tenv:transenv) (binding:option<term>) (k:kind) : ST<res> = 
  let mkKindOf tm_opt k = bind_opt tm_opt (fun tm -> Some (Eq(kindOf tm, k))) in
  let rec aux tenv (k: kind) : ST<term*list<phi>> = match k(* .u *)with
    | Kind_erasable
    | Kind_star
    | Kind_prop
    | Kind_affine ->  ret (Star_kind_term, [])
    | Kind_dcon(xopt, t, k) ->
        encodeTyp tenv None t >> (fun res_t ->
        let x = getBvd xopt in
        let tenv = push tenv (Var_binding(x,t,Term_sort,termref())) in
        aux tenv k >> (fun (k, phi_opt) -> 
        let tm = mkTK res_t.term k in 
          ret (tm, join res_t.subterm_phi phi_opt)))
    | Kind_tcon(aopt, k1, k2) -> 
        aux tenv k1 >> (fun (k1_tm, phi1) ->
        let a = getBvd aopt in
        let tenv = push tenv (Tvar_binding(a, k1,Type_sort,termref())) in
        aux tenv k2 >> (fun (k2_tm, phi2) -> 
        let tm = mkKK k1_tm k2_tm in
          ret (tm, join phi1 phi2)))
  in
    aux tenv k >> (fun (k, phiopt) -> 
    ret {term=k; subterm_phi=phiopt; binding_phi=mkKindOf binding k})


and encodeTyp (tenv:transenv) (binding:option<term>) (t:typ) : ST<res> = 
  let mkTypeOf tm_opt t = bind_opt tm_opt (fun tm -> Some (Eq(typeOf tm, t))) in
  let rec aux' tenv (t:typ) : ST<term * list<phi>> = 
    let mkProduct tenv xopt t1 t2 mk = match xopt with
      | None ->
          aux tenv t1 >> (fun (t1_tm, phi1) ->
          aux tenv t2 >> (fun (t2_tm, phi2) ->
          ret (mk t1_tm t2_tm, join phi1 phi2)))
      | Some x ->
          aux tenv t1 >> (fun (t1_tm, phi1) ->
          let tref = termref() in 
          let tenv = push tenv (Var_binding(x, t1, Term_sort, tref)) in
          aux tenv t2 >> (fun (t2_tm, phi2) ->
          let guard = Some (Eq(typeOf (mk_Exp_bvar 0), t1_tm)) in
          let phi2 = List.map (mkForall [Term_sort] [Inr<| x,tref] guard) phi2 in
            ret (mk t1_tm t2_tm, join phi1 phi2))) in
    let mkTProduct tenv (a:btvdef) k t mk =
        encodeKind tenv None k >> (fun {term=k_tm; subterm_phi=phi1} ->
        let tref = termref() in 
        let tenv = push tenv (Tvar_binding(a, k, Type_sort, tref)) in
        aux tenv t >> (fun (t, phi2) ->
        let guard = Some (Eq(kindOf (mk_Typ_btvar 0), k_tm)) in
        let phi2 = List.map (mkForall [Type_sort] [Inl<| a,tref] guard) phi2 in
        ret (mk k_tm t, join phi1 phi2))) in

      match (norm (tcenv tenv) t).v with 
        | Typ_unknown
        | Typ_record(_,  None) -> raise Impos
        | Typ_uvar _ -> newTypSym >> (fun tm -> ret (tm, []))
        | Typ_refine(_, t, _, _) (* top-level refinements handled separately below *)
        | Typ_affine t 
        | Typ_ascribed(t, _) 
        | Typ_record(_, Some t) ->  aux tenv t 
        | Typ_btvar bv -> 
            let tm = lookupBtvar tenv bv in
              (if !Options.logQueries then 
                 match tm.tm with 
                   | FreeV(name, _) -> addPPName (name, typePPNameOfBvar bv)
                   | _ -> ret ()
               else ret ()) >> (fun _ -> 
                                  ret (tm, []))

        | Typ_const (v, _) -> 
            let tm= lookupTypConst tenv v in
              ret (tm, [])

        | Typ_fun(xopt, t1, t2) -> mkProduct tenv xopt t1 t2 mkTfun
        | Typ_dtuple([(xopt, t1); (_, t2)]) -> mkProduct tenv xopt t1 t2 mkTtup
        | Typ_lam(x,t1,t2) -> mkProduct tenv (Some x) t1 t2 mkTlam 

        | Typ_univ(a, k, _, t) -> (* NS: Ignoring formulas *)
            mkTProduct tenv a k t mkTtfun 
        | Typ_tlam(a,k,t) -> 
            mkTProduct tenv a k t mkTtlam 

        | Typ_dep(t, v) -> 
            aux tenv t >> (fun (t_tm, phi1) -> 
                             encodeValue tenv v >> (fun (v_tm, phi2) -> 
                                                      ret (mkTV t_tm v_tm, join phi1 phi2)))
        | Typ_app(t1, t2) -> 
            aux tenv t1 >> (fun (t1_tm, phi1) -> 
                              aux tenv t2 >> (fun (t2_tm, phi2) -> 
                                                ret (mkTT t1_tm t2_tm, join phi1 phi2)))
  and aux tenv t =
    aux' tenv t >> (fun (tm, phiopt) -> 
    match t.sort(* .u *)with 
      | Kind_star
      | Kind_prop
      | Kind_affine -> 
          encodeKind tenv (Some tm) t.sort >> (fun res -> 
                                                 let phiopt = join phiopt (listOfOpt res.binding_phi) in
                                                   ret (tm, phiopt))
      | _ -> ret (tm, phiopt))
  in
    match (Tcenv.expand_typ (tcenv tenv) t).v with 
      | Typ_refine(x, t, form, _) -> 
          encodeTyp tenv binding t >> (fun res -> 
            match form.sort(* .u *)with 
              | Kind_dcon _  when (tcenv tenv).object_invariants ->  ret res
              | Kind_prop
              | Kind_erasable -> 
                  let tenv = push tenv (Var_binding(x, t, Term_sort, ref binding)) in 
                  let form = if !Options.relational then project_vars_or_duplicate (tcenv tenv) form else form in 
                    encodeFormula tenv form >> (fun (phi, subterms) ->
                                                  ret {res with 
                                                         subterm_phi=join res.subterm_phi subterms; 
                                                         binding_phi=mkAndOpt_l [res.binding_phi; (Some phi)]})
              | _ -> raise (Error(spr "Unexpected kind of refinement formula (%s)\n" (Pretty.strKind form.sort), 
                                         t.p)))
      | _ -> 
           aux tenv t >> (fun (tm, phi) -> 
          ret {term=tm; subterm_phi=phi; binding_phi=mkTypeOf binding tm})

and encodeValue (tenv:transenv) (e:exp) : ST<term*list<phi>> = match e.v with 
  | Exp_bvar x -> 
      let tm = lookupBvar tenv x in
        (if !Options.logQueries then 
           match tm.tm with 
             | FreeV(name, _) -> addPPName (name, funPPNameOfBvar x)
             | _ -> ret ()
         else ret ()) >> (fun _ -> 
     ret (tm, []))

  | Exp_fvar (x, _) -> 
      let tm = lookupFvar tenv x in
        ret (tm, [])                    

  | Exp_constant c -> 
      encodeConstant tenv e.sort c


  | Exp_constr_app(d, tl, el1, el2) -> 
      let encodeArith args mk = 
        (stmap args (encodeValue tenv)) >> (fun args -> 
                                              let args, phis = List.unzip args in
                                              let args = List.map Basic.unbox args in 
                                              let op = box (mk args) in 
                                                ret (op, mkAnd_l (List.flatten phis))) in 
      if Sugar.lid_equals d.v Const.add_lid then encodeArith el2 (fun [arg1; arg2] -> Add(arg1, arg2))
      else if Sugar.lid_equals d.v Const.sub_lid then encodeArith el2 (fun [arg1; arg2] -> Sub(arg1, arg2))
      else if Sugar.lid_equals d.v Const.mul_lid then encodeArith el2 (fun [arg1; arg2] -> Mul(arg1, arg2))
      else if Sugar.lid_equals d.v Const.div_lid then encodeArith el2 (fun [arg1; arg2] -> Div(arg1, arg2))
      else if Sugar.lid_equals d.v Const.modulo_lid then encodeArith el2 (fun [arg1; arg2] -> Mod(arg1, arg2))
      else if Sugar.lid_equals d.v Const.minus_lid then encodeArith el2 (fun [arg1] -> Minus(arg1))
      else
        let dname = funNameOfConstr d.v in
      (stmap tl (encodeTyp tenv None)) >> (fun tl_res -> 
      (stmap (el1@el2) (encodeValue tenv)) >> (fun el_res -> 
       let tl, subterm_phi1 = List.unzip (List.map (fun r -> r.term, r.subterm_phi) tl_res) in
       let el, subterm_phi2 = List.unzip el_res in
       let subterm_phi1 = List.flatten subterm_phi1 in
       let subterm_phi2 = List.flatten subterm_phi2 in
       let tm = mkApp Term_sort dname (tl@el) in 
      (encodeTyp tenv (Some tm) e.sort) >> (fun res -> 
       ret (tm, join res.subterm_phi (join (listOfOpt res.binding_phi) (join subterm_phi1 subterm_phi2))))))

  | Exp_recd(Some rec_lid, targs, vargs, fn_e_l) -> 
      let el = List.map snd fn_e_l in
      (stmap targs (encodeTyp tenv None)) >> (fun tl_res -> 
      (stmap (vargs@el) (encodeValue tenv)) >> (fun el_res ->
       let recDname = recordConstrName rec_lid in 
       let tl, subterm_phi1 = List.unzip (List.map (fun r -> r.term, r.subterm_phi) tl_res) in
       let el, subterm_phi2 = List.unzip el_res in
       let subterm_phi1 = List.flatten subterm_phi1 in
       let subterm_phi2 = List.flatten subterm_phi2 in
       let tm = mkApp Term_sort recDname (tl@el) in 
      (encodeTyp tenv (Some tm) e.sort) >> (fun res -> 
       ret (tm, join res.subterm_phi (join (listOfOpt res.binding_phi) (join subterm_phi1 subterm_phi2))))))

  | Exp_proj(e1, fn) -> 
      (encodeValue tenv e1) >> (fun (e1_term, subterm_phi) -> 
       let projName = fieldProjector tenv e1.sort fn in
       let projection = mkApp Term_sort projName [e1_term] in 
      (encodeTyp tenv (Some projection) e.sort) >> (fun res -> 
        ret (projection, join (listOfOpt res.binding_phi) (join res.subterm_phi subterm_phi))))

  | Exp_abs _ 
  | Exp_tabs _ -> 
      newFunSym >> (fun fterm -> 
      (encodeTyp tenv (Some fterm) e.sort) >> (fun res -> 
      ret (fterm, (join res.subterm_phi (listOfOpt res.binding_phi)))))

  | Exp_ascribed(e, t, _) -> 
      encodeValue tenv e 

  | Exp_primop(primop, el) -> 
      stmap el (encodeValue tenv) >> (fun tm_phi_l -> 
      let tms, subterm_phi = List.unzip tm_phi_l in
      let tm = encodePrimop primop tms in 
        ret (tm, List.flatten subterm_phi))

  | Exp_app  _ -> 
      let rec aux args e' = match e'.v with
        | Exp_app(e, arg) -> aux (arg::args) e
        | Exp_fvar(fv, _) -> 
            let primop = string2ident (Pretty.str_of_lident fv.v) in 
            let e = ewithsort (Exp_primop(primop, args)) e.sort in 
              encodeValue tenv e
        | _ -> raise Impos in
        aux [] e

  | Exp_tapp _ 
  | Exp_match _ 
  | Exp_cond _
  | Exp_let _ 
  | Exp_gvar _
  | Exp_extern_call _
  | Exp_bot _ -> raise Impos (* expression forms *)

and encodeConstant tenv typ = function
  | Sugar.Const_unit -> ret (unitTerm, [])
  | Sugar.Const_bool b -> ret (boolTerm b, [])
  | Sugar.Const_int32 i -> ret (box (Integer i), [])
  | Sugar.Const_string(bytes, _) -> lookupStringConstant tenv bytes 
  | Sugar.Const_float f -> lookupFloatConstant tenv f
  | _ -> 
      newFunSym >> (fun fterm -> 
      (encodeTyp tenv (Some fterm) typ) >> (fun res -> 
      ret (fterm, join res.subterm_phi (listOfOpt res.binding_phi))))

and encodePrimop primop tms = match primop.idText with 
  | "op_AmpAmp" 
  | "op_BarBar" 
  | "_dummy_op_Negation" -> mkApp Term_sort primop.idText tms
  | "_dummy_op_Addition"    
  | "_dummy_op_Subtraction" 
  | "_dummy_op_Multiply"    
  | _ -> raise (NYI (spr "Primop %s" primop.idText))

and lookupStringConstant tenv b = 
  get >> (fun st -> 
  let strings = st.strings in
    match strings |> Util.findOpt (fun (b', _, _) -> b=b') with 
      | Some (_, ({tm=FreeV(name, _)} as tm), ops) -> 
          if List.exists (function DeclFun(name', _, _, _) -> name=name' | _ -> false) st.ops then 
            ret (tm, [])
          else 
            (addOps ops >> (fun _ -> 
              ret (tm, [])))
      | None -> 
          incrCtr >> (fun p -> 
          let name = spr "string_%d" p in 
          let op = mkConstant name Term_sort in 
          let tm = FreeV(name, Term_sort) in 
          let op' = Assume(Eq(typeOf tm, strType), 
                           Some (Util.unicodeEncoding.GetString(b)), 
                           AName "string constant") in
          let id = Assume(Eq(strIdOf tm, Integer p), 
                          None, AName (spr "string id %d" p)) in 
          let ops = [id;op';op] in 
            addOps ops  >> (fun _ -> 
            internString b tm ops >> (fun _ -> 
            ret (tm, [])))))                                    

and lookupFloatConstant tenv f = 
  get >> (fun st -> 
  let floats = st.floats in
    match floats |> Util.findOpt (fun (f', _, _) -> f=f') with 
      | Some (_, ({tm=FreeV(name, _)} as tm), ops) -> 
          if List.exists (function DeclFun(name', _, _, _) -> name=name' | _ -> false) st.ops then 
            ret (tm, [])
          else 
            (addOps ops >> (fun _ -> 
              ret (tm, [])))
      | None -> 
          incrCtr >> (fun p -> 
          let name = spr "float_%d" p in 
          let op = mkConstant name Term_sort in 
          let tm = FreeV(name, Term_sort) in 
          let op' = Assume(Eq(typeOf tm, floatType), 
                           Some (spr "%f" f),
                           AName "float constant") in
          let id = Assume(Eq(floatIdOf tm, Integer p), 
                          None, AName (spr "float id %d" p)) in 
          let ops = [id;op';op] in 
            addOps ops  >> (fun _ -> 
            internFloat f tm ops >> (fun _ -> 
            ret (tm,[])))))                                    

and encodeFormula tenv f : ST<phi * list<phi>> = 
  let f = norm (tcenv tenv) f in 
  let mkQuant mkQ x t1 t2 = 
    let tref = termref() in
    let tenv = pushFormulaVar tenv (Var_binding(x, t1, Term_sort, tref)) in 
    let xterm = BoundV(0, Term_sort, string_of_bvd x, tref) in 
    encodeTyp tenv (Some xterm) t1 >> (fun {term=tm; subterm_phi=subterms_t1; binding_phi=Some guard} ->
    encodeFormula tenv t2 >> (fun (body, subterms_t2) -> 
    let subterms = join subterms_t1 (List.map (mkForall [Term_sort] [Inr<| x,tref] (Some guard)) subterms_t2) in
    let form = mkQ [Term_sort] [Inr <| x,tref] (Some guard) body in 
      ret (form, subterms))) in
    match f.v with 
      | Typ_ascribed(t, _) -> encodeFormula tenv t 
      | Typ_app(t1, t2) 
          when (AbsynUtils.is_constructor t1 Const.withpatterns_lid) -> 
          encodeFormula tenv t2 >> (fun (phi, subterms_t) -> 
          let phi = List.fold_left (fun p1 p2 -> And(p1, p2)) phi subterms_t in 
            ret (phi, []))
      | Typ_app({v=Typ_app(t,t1)}, {v=Typ_lam(x, _, t2)})
          when (AbsynUtils.is_constructor t Const.forallA_lid ||
                AbsynUtils.is_constructor t Const.forallP_lid ||
                AbsynUtils.is_constructor t Const.forall_lid) -> mkQuant mkForall x t1 t2
      | Typ_fun(xopt, t1, t2) -> mkQuant mkForall (getBvd xopt) t1 t2
      | Typ_app({v=Typ_app(t,t1)}, {v=Typ_lam(x, _, t2)})
          when (AbsynUtils.is_constructor t Const.existsA_lid ||
                AbsynUtils.is_constructor t Const.existsP_lid ||
                AbsynUtils.is_constructor t Const.exists_lid) -> mkQuant mkExists x t1 t2
      (* | Typ_dtuple([(xopt, t1); (_, t2)]) -> mkQuant mkExists (getBvd xopt) t1 t2 *)
      | Typ_univ(a, k, _, t) -> (* NS: ignoring formulas *)
          let kref = termref() in 
          let tenv = pushFormulaVar tenv (Tvar_binding(a, k, Type_sort, kref)) in
          let aterm = BoundV(0, Type_sort, string_of_bvd a, kref) in 
          encodeKind tenv (Some aterm) k >> (fun {term=tm; subterm_phi=subterms_k; binding_phi=Some guard} ->
          encodeFormula tenv t >> (fun (body, subterms_t) -> 
            let subterms = join subterms_k (List.map (mkForall [Type_sort] [Inl<|a,kref] (Some guard)) subterms_t) in
            let form = mkForall [Type_sort] [Inl<|a,kref] (Some guard) body in
              ret (form, subterms)))
      | Typ_btvar _ 
      | Typ_const _
      | Typ_app _
      | Typ_dep _  when isPropErr f f.sort -> encodeConnectives tenv f
      | Typ_unknown 
      | Typ_uvar _ 
      | Typ_refine _
      | Typ_affine _ 
      | Typ_lam _
      | Typ_tlam _
      | Typ_record _ 
      | _ -> raise Impos
          
and encodeConnectives tenv (f:typ) : ST<phi * list<phi>> =
  match destructConnectives f with 
      | None -> 
          if isAtom f then encodeAtom tenv f
          else raise (Bad (spr "UNABLE TO MAKE PROGRESS!! %s, \n %A\n %A" (Pretty.strTyp f) f.sort f))
            
      | Some (lid, [Inl p1; Inl p2]) when not (Sugar.lid_equals lid Const.eqTyp_lid) -> 
          stmap [p1;p2] (encodeFormula tenv) >> (fun [(t1, sub_t1);(t2, sub_t2)] -> 
          let sub = join sub_t1 sub_t2 in
          ret (if      lid=Const.and_lid     then (And(t1,t2), sub)
               else if lid=Const.or_lid      then (Or(t1,t2),  sub)
               else if lid=Const.implies_lid then (Imp(t1,t2), sub)
               else if lid=Const.iff_lid     then (Iff(t1,t2), sub)
               else raise Impos))

      | Some (lid, [Inl p])          when lid=Const.not_lid -> 
          encodeFormula tenv p >> (fun (t, sub) -> ret (Not t, sub))

      | Some (lid, [Inl p])          when lid=Const.tag_lid -> 
          ret (True(), [])

      | Some (lid, [Inr v1; Inr v2])   when lid=Const.gt_lid -> 
          stmap [v1;v2] (encodeValue tenv) >> (fun [(t1,sub_e1); (t2, sub_e2)] -> 
          let sub = join sub_e1 sub_e2 in
          ret (GT(Basic.unbox t1, Basic.unbox t2), sub))

      | Some (lid, [Inr v1; Inr v2])   when lid=Const.lt_lid -> 
          stmap [v1;v2] (encodeValue tenv) >> (fun [(t1,sub_e1); (t2, sub_e2)] -> 
          let sub = join sub_e1 sub_e2 in
          ret (LT(Basic.unbox t1, Basic.unbox t2), sub))

      | Some (lid, [Inr v1; Inr v2])   when lid=Const.gte_lid -> 
          stmap [v1;v2] (encodeValue tenv) >> (fun [(t1,sub_e1); (t2, sub_e2)] -> 
          let sub = join sub_e1 sub_e2 in
          ret (GTE(Basic.unbox t1, Basic.unbox t2), sub))

      | Some (lid, [Inr v1; Inr v2])   when lid=Const.lte_lid -> 
          stmap [v1;v2] (encodeValue tenv) >> (fun [(t1,sub_e1); (t2, sub_e2)] -> 
          let sub = join sub_e1 sub_e2 in
          ret (LTE(Basic.unbox t1, Basic.unbox t2), sub))

      | Some (lid, [Inl t1; Inl t2]) when Sugar.lid_equals lid Const.eqTyp_lid -> 
          (encodeTyp tenv None t1) >> (fun {term=t1; subterm_phi=phi1} -> 
          (encodeTyp tenv None t2) >> (fun {term=t2; subterm_phi=phi2} -> 
           let sub = join phi1 phi2 in
            ret (Eq(t1, t2), sub)))
              
      | Some (lid, [Inl _; Inl _; Inr e1; Inr e2]) 
      | Some (lid, [Inl _; Inr e1; Inr e2]) when AbsynUtils.is_lid_equality lid -> 
          stmap [e1;e2] (encodeValue tenv) >> (fun [(t1,sub_e1); (t2, sub_e2)] -> 
          let sub = join sub_e1 sub_e2 in
          ret (Eq(t1, t2), sub))
              
      | Some _ -> raise Impos 
            
and encodeAtom tenv (p_orig:typ) : ST<term * list<phi>> = 
  let encodeTypOrValue tenv = function 
    | Inl t -> encodeTyp tenv None t >> (fun res -> ret (res.term, res.subterm_phi))
    | Inr e -> encodeValue tenv e in 
  let mkPredName = function
    | Typ_const(tc,_) -> ret (predNameOfLid tc.v)
    | Typ_btvar a -> 
        let nm = predNameOfLid (asLid [bvar_real_name a]) in
          (if !Options.logQueries 
           then
             addPPName (nm, predNameOfLid (asLid [bvar_ppname a])) >> (fun _ -> ret nm)
           else ret nm)
    | _ -> raise Impos in
  let p, args = AbsynUtils.flattenTypAppsAndDeps p_orig in
  let getPredName p = match p.v with 
      | Typ_const _
      | Typ_btvar _ -> mkPredName p.v
      | Typ_uvar _ -> newPredSym p.sort in 
    match p.v, args with 
      | Typ_const(tc, _), [] when Sugar.lid_equals tc.v Const.true_lid -> ret (True(), [])
      | Typ_const(tc, _), [] when Sugar.lid_equals tc.v Const.false_lid -> ret (False(), [])
      | Typ_const _, _ 
      | Typ_btvar _, _ 
      | Typ_uvar _, _ -> 
          getPredName p >> (fun predName -> 
          stmap args (encodeTypOrValue tenv) >> (fun tm_sub_l -> 
          let tms, subs = List.unzip tm_sub_l in 
          let tm = mkApp Bool_sort predName tms in
            ret  (tm, List.flatten subs)))
      | _ -> raise (Bad (spr "Unexpected predicate: %s\n %A" (Pretty.strTyp p_orig) p_orig))

let encodeKind' (binding:option<term>) (k:kind) : ST<res> = 
  get >> (fun st -> 
  encodeKind (mkTransenv st.env) binding k)

let encodeTyp' (binding:option<term>) (t:typ) : ST<res> = 
  get >> (fun st -> 
  encodeTyp (mkTransenv st.env) binding t)  

let encodeValue' (v:exp) : ST<term * list<phi>> = 
  get >> (fun st -> 
  encodeValue (mkTransenv st.env) v)  

let encodeFormula' (f:typ) : ST<phi * list<phi>> = 
  get >> (fun st -> 
  let f = match st.env with
    | Some tcenv when !Options.relational ->
        project_vars_or_duplicate tcenv f
    | _ -> f in
  encodeFormula (mkTransenv st.env) f)  

(* ******************************************************************************** *)
(* Encoding signatures *)
(* ******************************************************************************** *)

let mkLogicFunction __D_lid qnames qvars qsorts qsortReps tenv t tm_t binding_phi : ST<unit> = 
  let __D = funNameOfConstr __D_lid in 
  let df = mkFunSym __D qsorts Term_sort in  (* :extrafuns (#D Type_1... Type_n Term_1... Term_m Term) *)
    match binding_phi with 
      | None -> addOps [df]
      | Some phi ->
          let op = mkAssumption (spr "%s_typing" (Pretty.sli __D_lid)) (mkForall qsorts qnames None phi) in 
            addOps [op;df]

let mkDatacon __D_lid qnames qvars qsorts qsortReps tenv t tm_t binding_phi : ST<unit> = 
  let __D = funNameOfConstr __D_lid in 
  let df = mkFunSym __D qsorts Term_sort in  (* :extrafuns (#D Type_1... Type_n Term_1... Term_m Term) *)
  let _, inverses = qsorts |> List.fold_left  
      (fun (ix, out) sort ->
         let __D_inv = invName __D ix in
         let dinv_f = mkFunSym __D_inv [Term_sort] sort in
           (ix+1, dinv_f::out)) (0, []) in 
  let inverses = inverses |> List.rev in     (* :extrafuns (#D_Inv_i Term Type)  (#D_Inv_i Term Term) *)
  let __D_app = mkApp Term_sort __D qvars in 

  incrCtr >> (fun p -> 
    let ctrid_2 = (Eq (ctrId __D_app, Integer p)) in    (* :assumption (= (CtrId (#D a x) p)) *)
    let _, inverses_3 = inverses |> List.fold_left 
        (fun (ix, out) (DeclFun(__D_inv, _, _, _)) -> 
           let rhs = List.nth qvars ix in
           let ith_eq = Eq(mkApp rhs.tmsort __D_inv [__D_app], 
                           rhs) in
             (ix+1, ith_eq::out)) (0, []) in
    let conjuncts = ctrid_2::(List.rev inverses_3) in 
    let quantify c = match qsorts with 
      | [] -> mkAssumption __D c
      | _ -> mkAssumption __D (mkForall qsorts qnames None c) in 
    let derivableEq = 
      if derivableEquality tenv t 
      then 
        let n = List.length qsorts in
        let r1ref = termref() in
        let rec1 = BoundV(n, Term_sort, "r1", r1ref) in
        let guard1 = Eq(typeOf rec1, tm_t) in 
        let projs = List.map (fun (DeclFun(proj_i, _, s, _)) -> mkApp s proj_i [rec1]) inverses in 
        let eq = 
          mkForall ([Term_sort]@qsorts) ([Inr<| bvdef_of_str "r1", r1ref]@qnames)
            (Some guard1)
            (Eq(rec1, mkApp Term_sort __D projs)) in 
        let typeEq = 
          match t.v with 
            | Typ_dtuple _ -> []
            | _ -> 
                let teq = mkForall ([Term_sort]@qsorts) ([Inr<| bvdef_of_str "r1",r1ref]@qnames)
                  (Some guard1)
                  (mkAnd (List.map3 (fun proj proj_typ -> function
                                       | Term_sort -> Eq(typeOf proj, proj_typ)
                                       | Type_sort -> Eq(kindOf proj, proj_typ)) projs qsortReps qsorts)) in 
                  [mkAssumption (spr "%s_derivable_typeOf" __D) teq] in
          typeEq@[mkAssumption (spr "%s_derivable_eq" __D) eq]
      else [] in
    let ops = List.map quantify conjuncts in
      addOps (derivableEq@ops@inverses@[df]))
    
let mkNaryData __D_lid t (test : typ -> bool) (f: list<Disj<btvdef,bvvdef> * termref<unit>> -> qvars -> qsorts -> list<term> -> transenv -> typ -> term -> option<phi> -> ST<unit>) : ST<unit> = 
  let rec aux (ix, qnames, qsorts, qsort_tms) tenv t : ST<unit> = 
    match t.v with
      | Typ_univ(a, k, _, t) ->
          (encodeKind tenv None k) >> (fun res -> 
          let qnames = (Inl<|(bvdef_of_str (typeNameOfBvdef a ix)))::qnames in
          let qsorts = Type_sort::qsorts in 
          let qsort_tms = res.term::qsort_tms in
            aux (ix+1, qnames, qsorts, qsort_tms) tenv t)

      | Typ_fun(xopt, t1, t2) ->
          (encodeTyp tenv None t1) >> (fun res -> 
          let x = getBvd xopt in
          let qnames = (Inr<|(bvdef_of_str (funNameOfBvdef_sfx x ix)))::qnames in
          let qsorts = Term_sort::qsorts in 
          let qsort_tms = res.term::qsort_tms in
            aux (ix+1, qnames, qsorts, qsort_tms) tenv t2)
              
      | _ -> 
          let qnames = List.rev qnames in 
          let _, qvars = List.fold_left (fun (ix, out) sort -> (ix+1, BoundV(ix, sort, (genident None).idText, termref())::out)) (0, []) qsorts in
          let qsorts = List.rev qsorts in
          let qsort_tms = List.rev qsort_tms in
          let __D = funNameOfConstr __D_lid in 
          let __D_app = mkApp Term_sort __D qvars in 
          (encodeTyp tenv (Some __D_app) t) >> (fun res -> 
            f (List.map (fun q -> (q, termref())) qnames) qvars qsorts qsort_tms tenv t res.term res.binding_phi) in
  get >> (fun st ->
  let tenv = mkTransenv st.env in
  let rec mkTenv tenv t = match t.v with 
      | Typ_univ(a, k, _, t) ->
          let tenv = pushFormulaVar tenv (Tvar_binding(a, k, Type_sort, termref())) in 
            mkTenv tenv t 
      | Typ_fun(xopt, t1, t2) ->
          let x = getBvd xopt in
          let tenv = pushFormulaVar tenv (Var_binding(x, t1, Term_sort, termref())) in
            mkTenv tenv t2
      | _ when test t -> tenv
      | _ -> raise (Bad (spr "mkNaryData got type %s\n" (Pretty.strTyp t))) in 
  let tenv = mkTenv tenv t in 
    aux (0, [], [], []) tenv t)

let opsOfPhis config name phis = 
  if config.subterm_typing
  then List.map (mkAssumption (spr "%s_subterms" name)) phis
  else []

let rec encodeSigelt : sigelt -> ST<unit> = function
  | Sig_typ_abbrev(lid, tps, k, texpand) -> ret ()

  | Sig_extern_typ(_, se) -> encodeSigelt se

  (* Abstract function symbols *)
  | Sig_value_decl(lid, t)
  | Sig_extern_value(_, lid, t) -> 
      let name = funNameOfFvar lid in 
      let tm = mkTerm name in
      (encodeTyp' (Some tm) t) >> (fun {term=tm_t; subterm_phi=phi_sub; binding_phi=Some phi_b} -> 
      let df = mkConstant name Term_sort in       (* :extrafuns ((name Term)) *)
      let ops = [mkAssumption name phi_b;df] in   (* :assumption (= (TypeOf name) ... ) *)
      let ops = (opsOfPhis config name phi_sub)@ops in 
        addOps ops)
        
  (* Axioms *)
  | Sig_datacon_typ(lid, [], formula, Some _, _, _, _, _)
  | Sig_ghost_assume(lid, formula, _)
  | Sig_query(lid, formula) -> 
      (encodeFormula' formula) >> (fun (phi, subTermTyping) ->     (* :assumption (phi) *) 
       let op1 = mkAssumption (funNameOfFvar lid) phi in
       let ops = (opsOfPhis config (funNameOfFvar lid) subTermTyping)@[op1] in 
         addOps ops)

  (* Predicate symbols *)
  | Sig_tycon_kind(lid, tps, k, isProp, muts, tags) when isProp -> 
      if config.skip_pf && Sugar.lid_equals lid Const.pf_lid then ret ()
      else
        let k = Tcenv.tycon_kind_from_tparams tps k in 
        let name = predNameOfLid lid in 
        let sorts = kindToSorts k in
          (addOp (mkPred name sorts)) >> (fun _ ->    (* :extrapred ((name Type1...Typen Term1...Termn)) *)
           encodeSigelt (Sig_tycon_kind(lid, [], k, false, muts, tags)))

  (* Type constructors *)
  | Sig_tycon_kind(lid, _, _, _, _, _) when is_builtin lid -> ret ()

  | Sig_tycon_kind(lid, tps, k, _, _, _) -> 
      let k = Tcenv.tycon_kind_from_tparams tps k in 
      let name = typeNameOfLid lid in 
      (encodeKind' (Some (mkType name)) k) >> (fun {term=tm_k; subterm_phi=phi_sub; binding_phi=Some phi}  -> 
      let df = mkConstant name Type_sort in       (* :extrafuns ((name Type)) *)
      incrCtr >> (fun p -> 
      let disj = Eq(tctrId (mkType name), Integer p) in
      let phi = And(phi, disj) in
      let ops = [mkAssumption name phi;df] in   (* :assumption (And (= (TctrId name) p) phi) *)
      let ops = (opsOfPhis config name phi_sub)@ops in 
        addOps ops))

  (* Logical functions *)
  | Sig_logic_function(lid, t, _) -> 
      mkNaryData lid t (fun _ -> true) (mkLogicFunction lid)
        
  (* Tuple constructor *)
  | Sig_datacon_typ(__tup_lid, _, t, _, _, Some tcName, _, _) 
      when Const.is_tuple_data_lid __tup_lid -> 
      let test t = match t.v with Typ_dtuple _ -> true | _ -> pr "Constr %s\nExpected tuple; got %s\n" (Pretty.sli __tup_lid) (Pretty.strTyp t); false in
        if Sugar.lid_equals __tup_lid Const.tuple_UU_lid then 
          mkNaryData __tup_lid t test (mkDatacon __tup_lid)
        else ret ()

          
  (* Data item only *)
  | Sig_datacon_typ(__D_lid, tps, t, _, _, Some tcName, _, _) -> 
      if config.skip_pf && Sugar.lid_equals tcName Const.pf_lid then ret ()
      else
        let test t = 
          let res = AbsynUtils.is_constructed_typ t tcName in
            if not res 
            then pr "Expected type with constructor %s\n Got %s\n" 
              (Pretty.sli tcName) (Pretty.strTyp t);
            res in
        let t = t |> (tps |> List.fold_right (
                        fun tp out -> match tp with 
                          | Tparam_typ (a,k) -> twithsort (Typ_univ (a,k,[],out)) Kind_star
                          | Tparam_term (x,t) -> twithsort (Typ_fun (Some x,t,out)) Kind_star)) in
          mkNaryData __D_lid t test (mkDatacon __D_lid)

  (* Type, a single data constructor, and an inversion principle *)
  | Sig_record_typ(__R_lid, tps, k, {v=Typ_record(fn_t_l, _)}, _) ->
      let k_r = Tcenv.tycon_kind_from_tparams tps k in
      let rec_typ = twithsort (Typ_const(fvwithsort __R_lid k, None)) k_r in
      let rec_typ = List.fold_left (fun out tp -> match tp with 
                                      | Tparam_typ(a, k) -> 
                                          let t_a = bvd_to_typ a k in 
                                            Tcutil.mkTypApp out t_a
                                      | Tparam_term(x,t) -> 
                                          let v_x = bvd_to_exp x t in
                                            Tcutil.mkTypDep out v_x) rec_typ tps in
      let data_lid = recordConstrLid __R_lid in 
      let data_typ =
        (rec_typ |> (fn_t_l |> List.fold_right
                        (fun (fn,t) out -> twithsort (Typ_fun(None, t, out)) out.sort))) in
      let sig_tycon = Sig_tycon_kind(__R_lid, tps, k, false, [], []) in
      let sig_data = Sig_datacon_typ(data_lid, tps, data_typ, None, Public, Some __R_lid, None, []) in
        (encodeSigelt sig_tycon) >> (fun _ ->
        (encodeSigelt sig_data))    

(* ******************************************************************************** *)
let encodeBinding env_pfx b = 
  let tenv = mkTransenv (Some env_pfx) in 
     match b with 
       | Tcenv.Binding_var(id, t) -> 
           let nm = funNameOfBvdef (mkbvd(id,id)) in 
           let df = DeclFun(nm, [||], Term_sort, None) in
           let tm = FreeV(nm, Term_sort) in 
           encodeTyp tenv (Some tm) (norm env_pfx t) >> (fun {term=tm_t; subterm_phi=phi_sub; binding_phi=Some phi} -> 
           incrCtr >> (fun p ->
           let op' = Assume (phi, Some id.idText, ABindingVar p) in
           let ops = (opsOfPhis config nm phi_sub)@[op';df] in 
           let tt = AbsynUtils.unrefine t in 
             match tt.sort(* .u *)with
               | Kind_prop ->
                   encodeFormula tenv tt >> (fun (phi, subterms) ->
                   incrCtr >> (fun q ->
                   let op'' = Assume(phi, Some (spr "%s_P" id.idText), ABindingVar q) in
                     addOps (ops@[op''])))
               | _ -> addOps ops))
               
       | Tcenv.Binding_typ(id, k) -> 
           (if (isProp k) then 
              let name = predNameOfLid (asLid [id]) in
              let sorts = kindToSorts k in
                (addOp (mkPred name sorts)) 
            else ret ()) >> 
             (fun _ -> 
                let nm = typeNameOfBtvar (bvd_to_bvar_s (mkbvd(id,id)) k) in 
                let df = DeclFun(nm, [||], Type_sort, None) in
                let tm = FreeV(nm, Type_sort) in
                encodeKind tenv (Some tm) k >> (fun {subterm_phi=phi_sub; binding_phi=Some phi} -> 
                incrCtr >> (fun p ->
                let op' = Assume (phi, Some id.idText, ABindingVar p) in
                let ops = (opsOfPhis config nm phi_sub)@[op';df] in 
                addOps ops)))

       | Tcenv.Binding_match(e1exp, e2exp) when !Options.relational ->
           let t = mkEq (tcenv tenv) e1exp e2exp in
           let t = project_vars_or_duplicate (tcenv tenv) t in
           encodeFormula tenv t >> (fun (phi, subterms) ->
           incrCtr >> (fun p ->
           let op1 = Assume(phi, None, ABindingMatch p) in
           let ops = (opsOfPhis {config with subterm_typing=true} (spr "binding_match_%d_subterms" p) subterms)@[op1] in
              addOps ops))

       | Tcenv.Binding_match(e1exp, e2exp) -> 
           (encodeValue tenv e1exp) >> (fun (e1, phi1) -> 
           (encodeValue tenv e2exp) >> (fun (e2, phi2) -> 
            incrCtr >> (fun p -> 
            let tm = Eq(e1,e2) in
            let subterms = join phi1 phi2 in 
            let op1 = Assume(tm, None, ABindingMatch p) in
            let ops = (opsOfPhis {config with subterm_typing=true} (spr "binding_match_%d_subterms" p) subterms)@[op1] in 
              addOps ops)))

       | Tcenv.Binding_tmatch(a, t) -> 
           (encodeTyp tenv None (AbsynUtils.btvar_to_typ a))  >> (fun res_a -> 
           (encodeTyp tenv None t) >> (fun res_t -> 
            incrCtr >> (fun p -> 
            let tm = Eq(res_a.term, res_t.term) in
            let op1 = Assume(tm, None, ABindingMatch p) in
            let subterms = join res_a.subterm_phi res_t.subterm_phi in 
            let ops = (opsOfPhis {config with subterm_typing=true} (spr "binding_tmatch_%d_subterms" p) subterms)@[op1] in 
              addOps ops)))

(* ******************************************************************************** *)

let encodeEnvironment : ST<unit> =
  get >> (fun {env=Some env} ->
  let modules = Tcenv.modules env |> List.map (fun (mname, m) ->
                                                 (mname, List.rev m.signature)) in
  let modules = (Tcenv.current_module env, Tcenv.signature env)::modules in
  stfoldr_pfx modules (fun _ (mname, signature) ->
                         lookupCache mname signature >>
                           (function
                              | Some ops -> addOps ops
                              | None ->
                                  addMark (Inl mname) >> (fun _ ->
                                  stfoldr_pfx signature (fun _ se -> encodeSigelt se)))) >>
    (fun _ ->
       addMark (Inl gammaLid) >> (fun _ ->
       Tcenv.stfoldr env encodeBinding)))

(* ******************************************************************************** *)
(* Caching *)
(* ******************************************************************************** *)
let caching = ref true
let initState, cacheState = 
  let cachedState = ref {ops=Basic.basicOps; 
                         env=None;
                         ctr=100;
                         strings=[];
                         floats=[];
                         cached_ops=[];
                         pp_name_map=Hashtbl.create 100} in 
  let _ = if !caching then Term.pushOps tctxConst (List.rev Basic.basicOps) else () in
  let init env = {!cachedState with env=Some env} in 
  let cache init_state = 
    if not !caching then init_state.ops 
    else
      let rec splitUsingMarks (accum, gamma, cache) = function 
        | Mark (Inl n)::tl when n=gammaLid -> splitUsingMarks ([], List.rev accum, cache) tl 
        | Mark (Inl n)::tl -> splitUsingMarks ([], gamma, (n, List.rev (Mark (Inl n)::accum))::cache) tl 
        | hd::tl -> splitUsingMarks (hd::accum, gamma, cache) tl
        | [] -> gamma, cache in (* last bit accumulated is the basic ops; discard it *)
      let gamma, cache = splitUsingMarks ([],[],[]) init_state.ops in 
      let cache = cache |> List.filter 
          (fun (lid, _) -> 
             not (init_state.cached_ops |> List.exists 
                      (fun (lid', _) -> 
                         Sugar.lid_equals lid lid'))) in 
      let _ = 
        if !caching 
        then cache |> List.iter (fun (_, ops) -> Term.pushOps tctxConst (List.rev ops)) 
        else () in
      let state = {init_state with cached_ops=cache@init_state.cached_ops} in
      let _ = cachedState := {state with env=None; ops=Basic.basicOps} in
        if !caching then gamma else init_state.ops in
    init, cache

(* ******************************************************************************** *)
(* External interface *)
(* ******************************************************************************** *)

let askZ3 ops = Term.queryZ3 tctxConst (List.rev ops) 

let cache_ctr = new_counter "Caching"

let check_skip descr f : bool =
  ignore (bumpQueryCount ());
  if !Options.describe_queries then descr ();
  let skip =
    (match !Options.skip_queries with
       | None -> false
       | Some x ->
           (if x > !Options.skipped_queries then
              (Options.skipped_queries := !Options.skipped_queries + 1;
               true)
            else
              (if x = !Options.skipped_queries && not (!Options.describe_queries) then
                 (descr ();  (* print the starting point *)
                  Options.skipped_queries := !Options.skipped_queries + 1);
               false))) in
    if skip then true
    else f ()

let query (env:Tcenv.env) (phi:formula) : bool =
  check_skip
    (fun () ->
       pr "%s\n" (Range.string_of_range phi.p);
       pr "%s\n" (Pretty.strTyp phi))
    (fun () ->
       let ee = encodeEnvironment >> (fun _ -> 
                encodeFormula' phi >> (fun (phi, subterms) -> 
                let ops = List.map (mkAssumption "query subterms") subterms in 
                let ops = (Query phi)::ops in 
                  addOps ops)) in
       let init = initState env in
       let _, final = (* "Z3 encoding" ^^ lazy *) runState init ee in 
       let ops = (* "Caching" ^^ lazy  *) cacheState final in  
         if !Options.logQueries then logQuery Term.tctxConst.z3ctx final.pp_name_map final.ops;
         askZ3 ops)

let query_equality (env:Tcenv.env) (e1:Absyn.exp) (e2:Absyn.exp) : bool =
  let phi = mkEq env e1 e2 in 
    query env phi 

  (* check_skip *)
  (*   (fun () -> pr "Query eq: %s = %s\n" (Pretty.strExp e1) (Pretty.strExp e2)) *)
  (*   (fun () -> *)
  (*      let ee = encodeEnvironment >> (fun _ ->  *)
  (*               encodeValue' e1 >> (fun (e1,phi1) ->  *)
  (*               encodeValue' e2 >> (fun (e2,phi2) ->  *)
  (*               let phi = List.map (mkAssumption "query subterms") (phi1@phi2) in  *)
  (*               let query = Query(Eq(e1,e2)) in *)
  (*               let ops = query::phi in  *)
  (*                 addOps ops))) in *)
  (*      let init = initState env in *)
  (*      let _, final = (\* "Z3 encoding" ^^ lazy *\) runState init ee in  *)
  (*      let ops = (\* "Caching" ^^ lazy  *\) cacheState final in *)
  (*        if !Options.logQueries then logQuery Term.tctxConst.z3 final.pp_name_map final.ops; *)
  (*        askZ3 ops) *)
  
