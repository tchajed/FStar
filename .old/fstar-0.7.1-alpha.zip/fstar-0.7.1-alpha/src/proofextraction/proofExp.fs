(* Modified by Nikhil Swamy; May, July 2010 *)
(* Modified by Nikhil Swamy; May, July 2010 *)
(*
  Copyright (c) 2009, Regents of the University of California

  Authors: Ravi Chugh
  
  All rights reserved.
  
  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following 
  conditions are met:
  
  1. Redistributions of source code must retain the above copyright 
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above 
  copyright notice, this list of conditions and the following disclaimer 
  in the documentation and/or other materials provided with the distribution.

  3. Neither the name of the University of California, San Diego, nor 
  the names of its contributors may be used to endorse or promote 
  products derived from this software without specific prior 
  written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
  CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
  PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
  PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
  LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
  SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*)


#light "off"

module Microsoft.FStar.ProofExp

open Absyn
open AbsynUtils
open ProofCommon
open ProofCombinators
open Util

(****************************************************************************)
(* Absyn.exp --> ProofCommon.term                                           *)
(* Absyn.typ (when prop) --> ProofCommon.term                               *)
(* Absyn.typ --> ProofCommon.typinst                                        *)
(****************************************************************************)

let noneExp, noneTyp, noneExpMsg, noneTypMsg =
  let b = true in (* set to true for debugging *) 
  (fun e -> if b then pr "noneExp: %s\n" (Pretty.strExp e); None),
  (fun t -> if b then pr "noneTyp: %s\n" (Pretty.strTyp t); None),
  (fun e s -> if b then pr "noneExp @ %s: %s\n" s (Pretty.strExp e); None),
  (fun s t -> if b then pr "noneTyp @ %s: %s\n" s (Pretty.strTyp t); None)

let rec expToTerm (info:info) (e:exp) : st<option<term>> = match e.v with
  | Exp_ascribed(e',_,_) -> expToTerm info e'
  | Exp_constant(Sugar.Const_bool true) -> retOpt termTrue
  | Exp_constant(Sugar.Const_bool false) -> retOpt termFalse
  | Exp_constant(Sugar.Const_unit) -> retOpt termUnit
  | Exp_constant(Sugar.Const_string (b,_)) ->
      let s = System.Text.Encoding.Unicode.GetString(b,0,b.Length) in
      let ops = 
        match ProofState.StringConstants.idOptOfString s with
            Some _ -> [] 
           | _ -> 
              let i = ProofState.StringConstants.addString s in
              let sym = ProofState.Z3Symbols.symOfString s in
              let stringSort = stringSort () in
              let def = (DefFun (sym, [||], stringSort, None)) in
              let defSort = (Assume(inSort stringSort (FreeV(sym, stringSort)), None, AOther)) in
              let ops = [def;defSort] in 
              ProofState.Ops.storeOps ops;
              ops in (* NIK: Remove this storeOps since we're now using a state monad *)
       addAndRet ops [] (Some (App (ProofState.Z3Symbols.symOfString s, [||])))

  | Exp_bvar x ->
      let t = (Tcenv.expand_typ_rec info.envn e.sort) in
      let sort = sortOfTyp t in
      let s = (bvar_real_name x).idText in
      (match findIdx s info.binders with
         | Some i -> retOpt (BoundV (i, sort))
         | None   -> retOpt (FreeV (s, sort)))
  
  | Exp_fvar (x, _) -> 
        ret <| bind_opt (sortOptOfTyp (Tcenv.expand_typ_rec info.envn e.sort))
                        (fun sort -> Some (FreeV(sli x.v, sort)))
    
  | Exp_constr_app(dc,[t1;t2],_,[e1;e2]) when is_tuple_constructor dc -> 
      (* let _ = pr "Trying to convert expression %s\n" (Pretty.strExp e) in *)
      let t1 = Tcenv.expand_typ_rec info.envn t1 in
      let t2 = Tcenv.expand_typ_rec info.envn t2 in
      let ti = TITuple (tiOfTyp t1, tiOfTyp t2) in 
      (* let _ = pr "Converted type to ti: %A\n" ti in  *)
      let s = (match sortOptOfTi ti with 
         | None ->
            (* NIK: If this fails, we should add a typinst for the Tuple, 
                    call processEquatableTypinst
                    and return both the sort and any new ops *)
             let sigs, ops = processEquatableTypinst info ti in 
             let sort = sortOfTi ti in
             (* let _ = pr "Converted ti to fresh sort: %A\n" sort in  *)
               addAndRet ops sigs sort
         | Some sort -> 
             (* let _ = pr "Converted ti to existing sort: %A\n" sort in  *)
               ret sort) in
       s >> (fun sort -> 
         stmap [e1;e2] (expToTerm info) >> (function
             | [Some f1; Some f2] -> retOpt <| App (ProofState.Z3Symbols.symOfTuple sort, [|f1;f2|])
             | _                -> ret <| noneExpMsg e "1"))

  | Exp_constr_app(dc,ts,_,es) ->
      (* let _ = pr "Trying to convert constructor app %s\n" (Pretty.strExp e) in *)
      let ts = List.map (Tcenv.expand_typ_rec info.envn) ts in
      let diOpt = ProofState.DataConstructors.idOptOfName (slOfLi dc.v) in
        (match diOpt with 
           | None ->  ret (noneExpMsg e "2")
           | Some di ->
              let sorts = 
                if not (ProofState.DataConstructors.isUniform di) then [] (* non-uniform types are monomorphized *)
                else List.map sortOfTyp ts in
                (Util.stmap es (expToTerm info)) >> (fun fos -> 
                 if existsNone fos 
                 then ret (noneExpMsg e "3")
                 else 
                   let fs = projSomes fos in 
                     retOpt (App (ProofState.Z3Symbols.symOfDconinst (di,sorts), Array.of_list fs))))
        
  | Exp_recd(Some(li),[],[],l) -> (* monomorphic record *)
      let fields, es = sortByFieldName l |> List.split in
      let rid = ProofState.Records.idOfName (slOfLi li) in
      let sort = sortOfTi (TIRecordMono rid) in  
      Util.stmap es (expToTerm info) >> (fun fos ->
        if existsNone fos then ret (noneExpMsg e "4")
        else retOpt (App (ProofState.Z3Symbols.symOfRecd sort, Array.of_list (projSomes fos))))

  | Exp_proj(e',fn) ->
      let t = Tcenv.expand_typ_rec info.envn e'.sort in
        (match (AbsynUtils.unrefine t).v with 
            | Typ_const(x,_) ->
                let rid = ProofState.Records.idOfName (slOfLi x.v) in
                let sort = sortOfTi (TIRecordMono rid) in
                (expToTerm info e') >> (function
                    | None -> ret (noneExpMsg e "5")
                    | Some f ->
                       let j = ProofState.Records.fieldId (slOfLi fn) in
                         retOpt (App (ProofState.Z3Symbols.symOfRecdProj sort j, [|f|])))
            (* | Typ_dtuple([(_, t1); (None;t2)]) ->  *)
            | _ -> ret (noneExpMsg e (spr "6: proj3: %s" (Pretty.strTyp t))))

  | Exp_fvar (x, _) -> failwith (spr "expToTerm: Exp_fvar %s" (sli x.v))

  | _ -> ret (noneExpMsg e "7")

let isFullyAppliedProp info t = match t.sort(* .u *) with 
  | Kind_prop
  | Kind_erasable -> Tcenv.is_prop info.envn t 
  | _ -> false

let rec fullyAppliedPropToTerm (info:info) (acc:Disj<term,Absyn.typ> list) t : st<option<term>> = 
   let termsOnly = List.map (function Inl tm -> tm | Inr ty -> raise (Never "Unexpected polymorphic prop")) in
   match t.v with
  | Typ_const(x,_) ->
      let s, sl = sli x.v, slOfLi x.v in
      if s = sli Const.true_lid then
        (match acc with
           | [] -> retOpt True
           | _  -> raise (Never "fullyAppliedPropToTerm 1"))
      else if s = sli Const.false_lid then
        (match acc with
           | [] -> retOpt False
           | _  -> raise (Never "fullyAppliedPropToTerm 2"))
      else (match ProofState.Props.idOptOfName sl with 
                Some propid -> retOpt (App (ProofState.Z3Symbols.symOfPropid propid, Array.of_list (termsOnly acc)))
               | _ -> 
                  match ProofState.DataConstructors.idOptOfName sl with 
                    Some _ -> failwith "Unexpected type in data-constructor position (TODO: Nik says maybe uncomment)"
                   | _ -> retOpt (PolyApp (t, acc)))

  | Typ_btvar bv -> 
        if List.for_all (function Inl _ -> true | _ -> false) acc 
        then retOpt (App((bvar_real_name bv).idText, Array.of_list (termsOnly acc)))
        else retOpt (PolyApp(t, acc))

  | Typ_dep(t1, e) ->
      (expToTerm info e) >> (function 
         | Some f -> fullyAppliedPropToTerm info (Inl f::acc) t1
         | None   -> ret (noneTypMsg "1" t))
        
  | Typ_app({v=Typ_const(x,_);sort=_;p=_}, _) when is_equality x -> 
      (match acc with 
         | [Inl a;Inl b] -> retOpt (Eq(a,b))
         | _ -> 
             pr "Equality %s applied to non-terms: [%s]\n" 
               (Pretty.str_of_lident x.v)
               (String.concat ", " (List.map (function 
                                                | Inl t -> ProofZZZ.termToSmt info t
                                                | Inr t -> Pretty.strTyp t) acc));
             raise (Never "Equality applied to non-terms"))
        
  | Typ_app(t1, t2) -> fullyAppliedPropToTerm info (Inr t2::acc) t1
       
  | _ -> ret (noneTypMsg "2" t)


let rec otherTypToTerm  (info:info) (t:typ) : st<term option> = match  t.v with

  | Typ_const(x,_) when Sugar.lid_equals x.v Const.true_lid -> ret (noneTypMsg "3" t)
  | Typ_const(x,_) when Sugar.lid_equals x.v Const.false_lid -> ret (noneTypMsg "4" t)

  (* existentials *)
  | Typ_app({v=Typ_app(t,t1)}, f) when (is_constructor t Const.existsA_lid || 
                                        is_constructor t Const.exists_lid) -> 
      let bvd, t2 = match f with
        | {v=Typ_lam(bvd, _, t2)} -> bvd, t2 (* (strip_typ Const.p2e_lid t2)  *)
        | _ -> raise Impos in
      let id = real_name bvd in
      let env' = Tcenv.push_local_binding info.envn (Tcenv.Binding_var (id,t1)) in
      let binders' = id.idText :: info.binders in
      (typToTerm { envn=env'; binders=binders' } (stripPfT t2)) >> (function
         | Some s -> 
            let s1 = sortOfTyp t1 in 
            retOpt <| Exists ([], [|s1|], [|ProofState.Z3Symbols.qvarOfBvd bvd t1 s1|], s)
         | _ -> ret <| noneTypMsg "13" t)

  (* standard logical connectives *)
  | Typ_app (t1,t2) ->
      (match t1.v with
         | Typ_const(x,_) when Sugar.lid_equals x.v Const.not_lid ->
             (typToTerm  info (stripPfT t2)) >> (function
                | Some s -> retOpt (Not s)
                | _      -> ret (noneTypMsg "5" t))
         | Typ_app (u1,u2) ->
             (match u1.v with
                | Typ_const(x,_) ->
                    let a, b = stripPfT u2, stripPfT t2 in
                    (stmap [a;b] (typToTermOpt info)) >> (function 
                       | [Some s1; Some s2] ->
                           if Sugar.lid_equals x.v Const.and_lid then retOpt (And (s1,s2))
                           else if Sugar.lid_equals x.v Const.or_lid then retOpt (Or (s1,s2))
                           else if Sugar.lid_equals x.v Const.implies_lid then retOpt (Imp (s1,s2))
                           else if Sugar.lid_equals x.v Const.iff_lid then retOpt(Iff (s1,s2))
                           else ret <| noneTypMsg "6" t
                       | _ -> ret <| noneTypMsg "7" t)
                | _ -> ret <| noneTypMsg "8" t)
         | _ -> ret <| noneTypMsg "9" t)

  (* propositions *)
  | Typ_fun (None, t1, t2) ->
      (stmap [stripPfT t1; stripPfT t2] (typToTerm  info)) >> (function 
         | [Some s1; Some s2] -> retOpt <| Imp (s1, s2)
         | _                -> ret <| noneTypMsg "10" t)

  (* universals *)
  | Typ_fun (Some bvd, t1, t2) ->
      ((* match t1.sort with  *)
       (*  | Kind_star ->  *)
        let id = bvd.realname in 
        let env' = Tcenv.push_local_binding info.envn (Tcenv.Binding_var (id,t1)) in
        let binders' = id.idText :: info.binders in
          (typToTerm  { envn=env'; binders=binders' } (stripPfT t2)) >> (function 
                 | Some s -> 
                     let s1 = sortOfTyp t1 in 
                        retOpt <| Forall ([], [|s1|], [|ProofState.Z3Symbols.qvarOfBvd bvd t1 s1 |], s)
                 | _ -> ret <| noneTypMsg "11" t))

  (* (\* existentials: Standard form *\) *)
  (* | Typ_dtuple [(Some(bvd),t1);(_,t2)] -> *)
  (*     let id = real_name bvd in *)
  (*     let env' = Tcenv.push_local_binding info.envn (Tcenv.Binding_var (id,t1)) in *)
  (*     let binders' = id.idText :: info.binders in *)
  (*     (typToTerm { envn=env'; binders=binders' } (stripPfT t2)) >> (function *)
  (*        | Some s ->  *)
  (*           let s1 = sortOfTyp t1 in  *)
  (*           retOpt <| Exists ([], [|s1|], [|ProofState.Z3Symbols.qvarOfBvd bvd t1 s1|], s) *)
  (*        | _ -> ret <| noneTypMsg "13" t) *)

  | _ -> ret <| noneTypMsg "14" t

and fullyAppliedPropToTermMsg info l t = 
  try fullyAppliedPropToTerm info l t 
  with e -> (pr "(%A) Failed to translate FAP: %s\n" e (Pretty.strTyp t); ret None) 

and typToTerm (info:info) (t:typ) : st<term option> =
  try 
    let t = Absyn.whnf (compress t) in
    if isFullyAppliedProp info t
    then fullyAppliedPropToTermMsg info [] t 
    else otherTypToTerm info t
  with
    | Translation m
    | Bad_sort m -> (pr "Translation or bad_sort error %s\n" m; ret None)

and typToTermOpt (info:info) (t:typ) : st<term option> =
  (typToTerm info t) >> (function
                           | Some s -> ret (Some s)
                           | _ -> 
                               let ss = if isFullyAppliedProp info t then "fully applied prop" else "other type" in
                                 pr "Failed to translate %s %s\n" ss (Pretty.strTyp t); ret None)
    
let addPattern tm = function 
  | None -> tm
  | Some pats -> 
     match tm with 
        | Forall _ -> flatten_forall' ([], pats) tm
        | Exists _ -> flatten_exists' ([], pats) tm
