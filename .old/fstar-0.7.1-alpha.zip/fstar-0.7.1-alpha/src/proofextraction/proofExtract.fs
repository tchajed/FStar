(* Modified by Nikhil Swamy; May, July 2010 *)
(*
  Copyright (c) 2009, Regents of the University of California

  Authors: Ravi Chugh
  
  All rights reserved.
  
  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following 
  conditions are met:
  
  1. Redistributions of source code must retain the above copyright 
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above 
  copyright notice, this list of conditions and the following disclaimer 
  in the documentation and/or other materials provided with the distribution.

  3. Neither the name of the University of California, San Diego, nor 
  the names of its contributors may be used to endorse or promote 
  products derived from this software without specific prior 
  written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
  CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
  PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
  PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
  LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
  SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*)


#light "off"

module Microsoft.FStar.ProofExtract

open System.Text.RegularExpressions
open Microsoft.Z3
type ZZZTerm = Microsoft.Z3.Term
open Microsoft.FStar
open Util
open Absyn
open AbsynUtils
open ProofCommon
open ProofCombinators
open ProofState
open Profiling
open KindAbbrevs

(* let W = Wmark *)
let printAscription = true
let bvd_to_bvar bvd = bvd_to_bvar_s bvd tunknown
let debugString = 
  let debug = [
    (int64 1,  "_QuantInst: exc_tm");
    (int64 2,  "_QuantInst: implies1_tm lambda");
    (int64 3,  "_QuantInst: implies1_tm lambda body");
    (int64 4,  "_QuantInst: y i");
    (int64 5,  "_QuantInst: y i lambda");
    (int64 6,  "_QuantInst: y i lambda body");
    (int64 7,  "_QuantInst: implies2_tm");
    (int64 8,  "_QuantInst: implies2_tm lambda");
    (int64 9,  "_QuantInst: implies2_tm lambda body");
    (int64 10, "_QuantInst: OrElim");
    (int64 11, "_QuantInst: implies1_tm");
    (int64 12, "_MpIff");
    (int64 13, "_ReflIff");
    (int64 14, "_ReflEq");
    (int64 15, "_Equi");
    (int64 16, "_PullQuant");
    (int64 17, "_SymmIff");
    (int64 18, "_SymmEq");
    (int64 19, "_TransIff");
    (int64 20, "_TransEq");
    (int64 21, "_AndElim");
    (int64 22, "_NotOrElim");
    (int64 23, "_Contra");
    (int64 24, "_UnitResGeneral");
    (int64 25, "_DefAxiomOne");
    (int64 26, "_DefAxiomTwo");
    (int64 27, "_DefAxiomThree");
    (int64 28, "_DefAxiomFour");
    (int64 29, "_DefAxiomFive");
    (int64 30, "_DefAxiomSix");
    (int64 31, "_DefAxiomSeven");
    (int64 32, "_DefAxiomEight");
    (int64 33, "_DefAxiomNine");
    (int64 34, "_MonoEq");
    (int64 37, "_MonoConnective");
    (int64 38, "_RwEq");
    (int64 39, "_Rw_IdImplies");
    (int64 40, "_Rw_IdImplies_2");
    (int64 41, "_Rw_DblNotElim");
    (int64 42, "_Rw_DeMorganNotOr");
    (int64 43, "_Rw_DeMorganAnd");
    (int64 44, "_Rw_DeMorganNotAnd");
    (int64 45, "_Rw_DeMorganOr");
    (int64 46, "_Rw_FlattenCommute");
    (int64 47, "_ProofByContradiction");
    (int64 48, "_UnitResQuantInst");
    (int64 49, "_Lemma: ProofByContradiction");
    (int64 50, "_Lemma: DestructFalse");
    (int64 51, "doMonoTupProj: return");
    (int64 52, "doMonoTupProj");
    (int64 53, "doMonoTupProj");
    (int64 54, "doMonoTupProj");
    (int64 55, "");
    (int64 56, "");
    (int64 57, "");
    (int64 58, "");
    (int64 59, "");
    (int64 60, "");
    (int64 61, "");
    (int64 62, "");
    (int64 63, "");
    (int64 64, "");
    (int64 65, "");
    (int64 66, "");
    (int64 67, "");
    (int64 68, "");
    (int64 69, "");
  ] in
  (fun i -> try assocFind ((=) i) debug
            with Not_found -> spr "unknown debug id: %d" i)


(****************************************************************************)
(* PROOF EXTRACTION STATE AND UTILITIES                                     *)
(****************************************************************************)
let antecedentsAndGoal (t:ZZZTerm) = 
  let xs = (!z3).GetAppArgs t in
    splitAntesAndGoal (Array.to_list xs)

let curGoalId   = ref (-1)
let curProofId  = ref (-1)

let counters () = spr "[q%d p%d f%d]" (queryCount()) !curProofId !curGoalId

let failwith s = failwith (spr "%s %s" (counters()) s)

(*
let fromDerefinedContext = ref 0
*)

type subproof =
  | Subpf       of int (* cache id of a proof Term *)
  | Subpf_exp   of exp

type proof =
  (* TODO since providing all type params now, remove goal typ *)
  | Pf_fadc     of var<typ> * typ list * subproof list * typ * int
  | Pf_fadc_asc of var<typ> * typ list * subproof list * typ * int
  | Pf_call     of exp * typ list * subproof list * typ * int
  | Pf_exp      of exp
  | Pf_bot
  | Pf_bot_asc  of typ
  | Pf_string   of string (* for debugging *)


(* the cache ids of proof Terms already processed *)
let processedProofIds = ref (Zset.empty compare)

(* same as processedProofIds, but kept in order *)
let processedProofIdsList = ref []

let htProofTermIdToProof : (int, proof) Ht.t =
  Ht.create "proofTermIdToProof" strTerm

let htProofTermToFormulaTerm : (Term, Term) Ht.t =
  Ht.create "proofTermToFormulaTerm" strTerm

(* TODO remove these hypo tables *)
let hypothesisGoalidToFormDom : (int, bvvdef * typ) Ht.t =
  Ht.create "hypothesisGoalidToFormDom" soi

let hypothesisTermToGoalid : (Term, int) Ht.t =
  Ht.create "hypothesisTermToGoalid" (fun _ -> "_Term_")

let goalVar       = ref None
let negGoalTerm   = ref None
let negGoalBvd    = ref (mkbvd(mkId "", mkId ""))
let negGoalExp    = ref dummyExp
let negGoalTyp    = ref dummyTyp
let goalTyp       = ref dummyTyp

(* TODO 11/12 *)
let htProofTermExpandedCount : (int, int) Ht.t =
  Ht.create "proofTermExpandedCount" soi

let htRepeats : ((int*int*string), int) Ht.t = Ht.create "htRepeats" (fun _ -> "__htRepeats__")

(*
(* index is formula id. bvdef, (pf-wrapped) typ, and exp for hypothesis *)
*)



(* index is _goal_ id. Term is _formula_. bvdef, (pf-wrapped) typ, and exp for hypothesis *)
let hypotheses : (int, Term * bvvdef * typ * exp) Ht.t = Ht.create "hypotheses" soi

type skrec = {sksym:string; eqsat_pf: exp; 
              ex_typ: typ; ex_typ_1:typ; ex_typ_2:typ;
              ante_typ:typ; mp_eq: option<bvvdef*subproof>}
let skolemPackages : (int, skrec) Ht.t = Ht.create "skolemPackages" string_of_int


let clearProofTermState () =
  negGoalTerm            := None;
  negGoalBvd             := mkbvd(mkId "", mkId "");
  negGoalExp             := dummyExp;
  negGoalTyp             := dummyTyp;
  goalTyp                := dummyTyp;
  processedProofIds      := Zset.empty compare;
  processedProofIdsList  := [];
  Ht.clear htProofTermIdToProof;
  Ht.clear htProofTermToFormulaTerm;
  Ht.clear hypothesisGoalidToFormDom;
  Ht.clear hypothesisTermToGoalid;
(*
  pr "finished query %d\n" (queryCount()); Ht.iter htProofTermExpandedCount (fun i j -> pr "\nravi %10d %10d" i j); 
*)
  Ht.clear htProofTermExpandedCount;

  Ht.clear skolemPackages;
  Ht.clear hypotheses;

  ()


(* Expands out the full proof expression corresponding to the proof Term. *)
let rec proofTermIdToProofExp i : exp =
  if Ht.mem htProofTermExpandedCount i
    then Ht.replace htProofTermExpandedCount i (1 + Ht.find htProofTermExpandedCount i)
    else Ht.add htProofTermExpandedCount i 1;
  match Ht.find htProofTermIdToProof i with
    | Pf_string _   -> dummyExp
    | Pf_bot        -> dummyExp
    | Pf_bot_asc t  -> mkExp (Exp_ascribed (dummyExp, t, []))
    | Pf_exp e      -> e
    | Pf_fadc(dc,ts,l,_,tag) ->
        let es = List.map subProofToExp l in
        mkTagDconApp tag dc ts es
    | Pf_fadc_asc(dc,ts,l,goal,tag) ->
        let es = List.map subProofToExp l in
        mkExp (Exp_ascribed (mkTagDconApp tag dc ts es, goal, []))
    | Pf_call(f,ts,l,goal,tag) ->
        let es = List.map subProofToExp l in
          mkCall1 f ts es
and subProofToExp = function
  | Subpf i -> proofTermIdToProofExp i
  | Subpf_exp e -> e
      
let proofTermToProofExp (tm:Term) : exp =
  proofTermIdToProofExp (ProofState.Extraction.idOfTerm tm)

let proofToFormula (tm:Term) : Term =
  Ht.find htProofTermToFormulaTerm tm

let proofTermIdToFormulaTermId pi =
  let pfi = ProofState.Extraction.termOfId pi in 
   ProofState.Extraction.idOfTerm (proofToFormula pfi)

let strSubproof = function
  | Subpf(i) -> spr "p%d_f%d" i (proofTermIdToFormulaTermId i)
  | Subpf_exp(e) -> Pretty.strExp e

let wrapSubpf pf =
(*
  let j = IdTable.getId idTerm (proofToFormula pf) in
  if Ht.mem hypothesisGoalidToFormDom j then
    let bvNotP, tyNotP = Ht.find hypothesisGoalidToFormDom j in
    Subpf_exp (bvdToExp bvNotP tyNotP)
*)
(*
  let j = IdTable.getId idTerm (proofToFormula pf) in
  if Ht.mem hypotheses j then
    let (_,_,_,e) = Ht.find hypotheses j in
    let _ = pr "ravi: using %s for hypothesis %d\n" (strExp e) j in
    Subpf_exp e
*)
  let pi = ProofState.Extraction.idOfTerm pf in 
  if Ht.mem hypotheses pi then    
    let (_,_,_,e) = Ht.find hypotheses pi in
    Subpf_exp e
  else
    Subpf pi 

let wrapSubpfExp e = Subpf_exp e


(****************************************************************************)
(* Z3 TERMS --> FINE EXPS/TYPS                                              *)
(****************************************************************************)

let destructTerm funsym tm =
  match (!z3).GetTermKind tm with
    | TermKind.App ->
        if funsym = ((!z3).GetAppDecl(tm)).GetDeclName()
          then Some (Array.to_list ((!z3).GetAppArgs tm))
          else None
    | _ -> None

let getAppSymbol tm =
  match (!z3).GetTermKind tm with
    | TermKind.App -> (!z3).GetAppDecl(tm).GetDeclName()
    | _            -> failwith "getAppSymbol"

let getAppArgs tm =
  match (!z3).GetTermKind tm with
    | TermKind.App -> Array.to_list ((!z3).GetAppArgs tm)
    | _            -> failwith "getAppArgs"

(* TODO remove this, and call isForallTerm instead *)
let isQuantTerm t =
  match (!z3).GetTermKind t with
    | TermKind.Quantifier -> true
    | _ -> false

let isForallTerm t =
  match (!z3).GetTermKind t with
    | TermKind.Quantifier -> ((!z3).GetQuantifier t).IsForall
    | _ -> false

let isExistsTerm t =
  match (!z3).GetTermKind t with
    | TermKind.Quantifier -> not ((!z3).GetQuantifier t).IsForall
    | _ -> false

(* strips off all quantifiers at the top level *)
let rec getQuantBody t =
  match (!z3).GetTermKind t with
    | TermKind.Quantifier -> getQuantBody ((!z3).GetQuantifier t).Body
    | _ -> t

let reInv = new Regex("^inv\!.*\!([0-9]+)$")

let reSkolem = new Regex("^(.*)\!(.*)$")

let unbangSkolemSym s = 
  let m = reSkolem.Match s in
  let prefix, suffix = m.Groups.get_Item(1).Value, m.Groups.get_Item(2).Value in
    (spr "%s_BANG_%s" prefix suffix)
let skolemSymToLi = mkId -<- unbangSkolemSym 

let skolemSymToExp s = idToExp (skolemSymToLi s) dummyTyp

let skolemSymToProofLi s =
  let m = reSkolem.Match s in
  let prefix, suffix = m.Groups.get_Item(1).Value, m.Groups.get_Item(2).Value in
  mkId (spr "%s_SKOLEMPROOF_%s" prefix suffix)

let skolemSymToProofExp s = idToExp (skolemSymToProofLi s) dummyTyp



(* TODO added 11/10
   ugly way to retroactively support Z3-generated foralls like forall (0:tii005 1:tii005).
   this contains list like [("1",Some 5);("0",Some 5)] *)
let bindersSorts : (string * sort) list ref = ref []

(* TODO added 11/10 *)
let lookupSort x =
  let rec f = function
    | [] -> None
    | (y,s)::tl -> if x = y then Some s else f tl
  in
  f !bindersSorts

(* TODO added 11/10 *)
let usedBoundVars : int Zset.t ref = ref (Zset.empty compare)


let rec termToExp info : string list -> Term -> (exp * sort) option =
  let termToExp bvs = termToExp info bvs in
  let dconinstToExp (bvs:string list) ((di,tiil):dconinst) (xs:Term array) =
    let dconLi = liOfSl (ProofState.DataConstructors.nameOfDconid di) in 
    let retTiio = ProofState.DataConstructors.retSortOfDconinst (di,tiil) in
    (* TODO apply to typ args if tiil <> [] ? *)
    if Array.length xs = 0 then Some (liToExp dconLi, retTiio)
    else
      let l = List.map (termToExp bvs) (Array.to_list xs) in
      if existsNone l then None
      else let etiiol = projSomes l in
           (* TODO ok to ignore tiiol of args? *)
           let es, _ = List.split etiiol in
           let til = List.map tiOfSort tiil in
           let typs = List.map typOfTi til in
           Some (mkDconApp (mkVarT dconLi) typs es, retTiio) in

  let tupleCtorToExp (bvs:string list) (tii:sort) (x1:Term) (x2:Term) =
    (match termToExp bvs x1, termToExp bvs x2 with
       | Some(e1,_), Some(e2,_) ->
           let tii1, tii2 = ProofState.Tuples.argSorts tii in
           let ti1, ti2 = tiOfSort tii1, tiOfSort tii2 in
           let t1, t2 = typOfTi ti1, typOfTi ti2 in
           Some (mkTup t1 t2 e1 e2, tii)
       | _ -> None) in

  let tupleProjToExp (bvs:string list) (tii:sort) (x:Term) (one:bool) =
    (match termToExp bvs x with
      | None -> None
      | Some(e,_) ->
          let tii1, tii2 = ProofState.Tuples.argSorts tii in
          if one
            then Some (mkProj1 e, tii1)
            else Some (mkProj2 e, tii2)) in

  let recdCtorToExp (bvs:string list) (sort:sort) (xs:Term array) =
    let l = List.map (termToExp bvs) (Array.to_list xs) in
    if existsNone l then None
    else let es, sortl = List.split (projSomes l) in
         let fieldnames, _ = ProofState.Records.fieldNamesAndTypsOfSort sort |> List.split in  
         let retSort = sort in // used to be: Ht.find RecordInsts.retTii sort; but this is never written to
            Some (mkRecd fieldnames es, retSort) in

  let recdProjToExp (bvs:string list) (tii:sort) (j:fieldid) (x:Term) =
    (match termToExp bvs x with
       | None -> None
       | Some(e,_) ->
           let allFieldnames, fieldTyps = ProofState.Records.fieldNamesAndTypsOfSort tii |> List.split in 
           let allFieldnames = List.map slOfLi allFieldnames in
           let fieldj = ProofState.Records.fieldName j in 
           (match findIdx fieldj allFieldnames with
              | None -> None
              | Some i ->
                  let fieldTii = List.nth fieldTyps i |> sortOfTyp in
                  Some (mkProj e (liOfSl fieldj), fieldTii))) in
      
  let otherSymToExp (bvs:string list) (s:string) =
    if s = stringPrimsTrue then Some (expTrue, boolSort())
    else if s = stringPrimsFalse then Some (expFalse, boolSort())
    else
        (bind_opt (ProofState.Z3Symbols.identSortOptOfSym s) (fun sort -> Some (idToExp (mkId s) dummyTyp, sort))) =^^=>
        (fun _ -> bind_opt (ProofState.Z3Symbols.stringidOfSym s) (fun i -> Some (mkStr i, stringSort()))) =^^=>
        (fun _ -> bind_opt (lookupSort s) (fun sort -> Some (idToExp (mkId s) dummyTyp, sort))) =^^=>
        (fun _ -> raise (Bad_sort (spr "termToExp: unknown symbol %s" s))) in

  (fun bvs tm -> "ProofExtract.termToExp" ^^ lazy 
     match (!z3).GetTermKind tm with

       | TermKind.App ->

           let fd, xs = (!z3).GetAppDecl tm, (!z3).GetAppArgs tm in
           let symbol = fd.GetDeclName () in

           (match ProofState.Z3Symbols.dconinstOfSym symbol with
              | Some(di,tiil) -> dconinstToExp bvs (di,tiil) xs
              | None ->
           (match ProofState.Z3Symbols.tupleCtorOfSym symbol, xs with
              | Some(tii), [|x1;x2|] -> tupleCtorToExp bvs tii x1 x2
              | _ -> 
           (match ProofState.Z3Symbols.tupleProj1OfSym symbol, xs with
              | Some(tii), [|x|] -> tupleProjToExp bvs tii x true
              | _ ->
           (match ProofState.Z3Symbols.tupleProj2OfSym symbol, xs with
              | Some(tii), [|x|] -> tupleProjToExp bvs tii x false
              | _ ->
           (match ProofState.Z3Symbols.recdCtorOfSym symbol with
              | Some(tii) -> recdCtorToExp bvs tii xs
              | None ->
           (match ProofState.Z3Symbols.recdProjOfSym symbol, xs with
              | Some(tii,j), [|x|] -> recdProjToExp bvs tii j x
              | _ ->
           (match reInv.IsMatch symbol, xs with
(*  TODO Nik: Commented this out
              | true, [|x|] ->
                  Some (dummyExp, sortOther)
// Nik: this was already commented out
//                  let m = reInv.Match symbol in
//                  let projIdx = ios (m.Groups.get_Item(1).Value) in
//                  (match (!z3).GetTermKind x with
//                     | TermKind.App -> 
//                         let ys = (!z3).GetAppArgs x in (* could do a check that the AppDecl is indeed the inverse *)
//                         termToExp bvs ys.[projIdx]
//                     | _ -> failwith (spr "termToExp: inv not App: %s" symbol))
*)
              | true, _ -> failwith (spr "termToExp: inv with weird args: %s" symbol)
              | false, _ ->
           (match reSkolem.IsMatch symbol with
              | true -> Some (skolemSymToExp symbol, strSortToSort (((!z3).GetRange ((!z3).GetAppDecl tm)).GetName())) 
              | false ->
           otherSymToExp bvs symbol))))))))

       | TermKind.Var ->
           let i = int ((!z3).GetVarIndex tm) in
           let _ = usedBoundVars := Zset.add i !usedBoundVars in
           if i < List.length bvs then otherSymToExp bvs (List.nth bvs i)
           (* TODO explain *)
           else let j = i - (List.length bvs) in
                Some (mkExp (Exp_gvar j), ProofState.Extraction.sortOfVar tm)

       | _ -> failwith "termToExp: TermKind other"
  )



let (==>) (f:'a -> option<'b>) (g: 'a -> option<'b>) : 'a -> option<'b> = 
  fun a -> match f a with 
    | None -> g a
    | x -> x
let uc3 f (a,b,c) = f a b c
  
(* All the termToTyp functions return a type wrapped with pf<>. *)
let rec termToTyp (info:info) (bvs:string list) (tm:Term) : typ option =  
  "ProofExtract.termToTyp" ^^ lazy 
      let f = (uc3 termToEq) ==>
         (uc3 termToNot) ==>
         (uc3 termToAnd) ==>
         (uc3 termToOr) ==>
         (uc3 termToIff) ==>
         (uc3 termToImp) ==>
         (uc3 termToEqui) ==>
         (uc3 termToProp) ==>
         (uc3 termToFun) ==>
         (uc3 termToPack) ==>
         (uc3 termToTrue) ==>
         (uc3 termToFalse) in
         f (info, bvs, tm)
   
and termToProp info (bvs:string list) (tm:Term) = 
  (match (!z3).GetTermKind tm with TermKind.App ->
     let symbol, xs = ((!z3).GetAppDecl tm).GetDeclName(), (!z3).GetAppArgs tm in
     (match ProofState.Z3Symbols.propidOfSym symbol with Some propid ->
        let propLi = liOfSl (ProofState.Props.nameOfId propid) in 
        let l = List.map (termToExp info bvs) (Array.to_list xs) in
        if existsNone l then None
        else let etiiol = projSomes l in
             let es, _ = List.split etiiol in
             Some (mkPfT (mkTypApp (mkTypConst propLi) [] es))
     | None -> None)
  | _ -> None)

and termToEq info (bvs:string list) (tm:Term) = 
  (match destructTerm "=" tm with Some [t1;t2] ->
  (match termToExp info bvs t1, termToExp info bvs t2 with
     | Some(e1, tii1),Some(e2, tii2) when tii1 = tii2 ->
         let eqTii1 = ProofCombinators.eqtypOfSort info tii1 in
           Some (mkPfT (mkTypApp eqTii1 [] [e1;e2]))
     | _ -> None)
  | _ -> None)

and termToConn info bvs tm sym tc = 
  let rec nestRight tc = function
    | []    -> raise (Never "nestRight")
    | [a;b] -> mkPfT (mkTypApp tc [a; b] [])
    | h::tl -> mkPfT (mkTypApp tc [h; nestRight tc tl] []) in
    match destructTerm sym tm with
      | Some [x]    -> (match termToTyp info bvs x with
                          | Some tyX -> Some (mkPfT (mkTypApp tc [tyX] []))
                          | _        -> None)
      | Some juncts -> let l = List.map (termToTyp info bvs) juncts in
                       if existsNone l
                         then None
                         else Some (nestRight tc (projSomes l))
      | None        -> None

and termToNot info  bvs t    = termToConn info bvs t "not"     Const.not_typ
and termToAnd info  bvs t    = termToConn info bvs t "and"     Const.and_typ
and termToOr info bvs t     = termToConn info bvs t "or"      Const.or_typ
and termToIff info bvs t    = termToConn info bvs t "iff"     Const.iff_typ
and termToImp info bvs t    = termToConn info bvs t "implies" Const.implies_typ
(* TODO 11/17
and termToEqui bvs t   = termToConn bvs t "~"       Const.iff_typ
*)
and termToEqui info bvs t   = termToConn info bvs t "~"       Const.implies_typ

and termToFun info  (bvs:string list) (tm:Term) =
  match (!z3).GetTermKind tm with TermKind.Quantifier ->
    let q = (!z3).GetQuantifier tm in
    if not q.IsForall then None
    else begin
      let names = List.map (fun (a:Symbol) -> (!z3).GetSymbolString a) (Array.to_list q.Names) in
      assert (List.length names > 0);
      let bvs' = (List.rev names) @ bvs in
(* TODO 11/10
      (match termToTyp bvs' q.Body with Some bodyType ->
         let binders = List.map (Ht.find symToFormDom) names in
         Some (mkPfDepArrow binders bodyType)
      | _ -> None)
    end
  | _ -> None
*)
      let sorts = List.map (fun (a:Sort) -> strSortToSort ((!z3).GetSymbolString ((!z3).GetSortName a))) (Array.to_list q.Sorts) in  

      (* save state of incoming quantifiers *)
      let prevBindersSorts = !bindersSorts in
      let prevUsedBoundVars = !usedBoundVars in

      (* push new state *)
      let _ = bindersSorts := (List.zip (List.rev names) (List.rev sorts)) @ !bindersSorts in
      let _ = usedBoundVars := Zset.empty compare in

      (* process quantifier body, which also tracks which bound vars are used *)
      let ret =
        (match termToTyp info bvs' q.Body with Some bodyType ->

           (* TODO 11/10 ugly to have to try symToFormDom then bindersSorts *)
           let binders =
             List.map (fun x ->
                match ProofState.Z3Symbols.binderOptOfSym x with 
                    Some b -> b
                  | _ -> match lookupSort x with
                           | Some tii -> (mkbvd(mkId x, mkId x), typOfTi (tiOfSort tii))
                           | _ -> failwith (spr "termToFun binders: %s" x)) names in
           Some (mkPfDepArrow binders bodyType)
        | _ -> None) in

      (* restore state of incoming quantifiers *)
      let _ = bindersSorts := prevBindersSorts in
      let _ = usedBoundVars := prevUsedBoundVars in

      ret
    end
  | _ -> None

(* TODO added 11/17 *)
and termToPack info (bvs:string list) (tm:Term) =
  match (!z3).GetTermKind tm with TermKind.Quantifier ->
    let q = (!z3).GetQuantifier tm in
    if q.IsForall then None
    else begin
      let names = List.map (fun (a:Symbol) -> (!z3).GetSymbolString a) (Array.to_list q.Names) in
      assert (List.length names > 0);
      let bvs' = (List.rev names) @ bvs in
      (match termToTyp info bvs' q.Body with Some bodyType ->
         let binders = List.map (must -<- ProofState.Z3Symbols.binderOptOfSym) names in 
         Some (mkPfDepTuple binders bodyType)
      | _ -> None)
    end
  | _ -> None

and termToTrue info _ (tm:Term) =
  match destructTerm "true" tm with
    | Some [] -> Some (mkPfT Const.true_typ)
    | _       -> None

and termToFalse info _ (tm:Term) =
  match destructTerm "false" tm with
    | Some [] -> Some (mkPfT Const.false_typ)
    | _       -> None


(* If t is a not, then returns true and the typ inside the not *)
let isDblNotTyp t : (bool * typ) = match t.v with
  | Typ_app(u1,u2) -> (match u1.v with
      | Typ_const(x, _) when sli x.v = sli Const.pf_lid -> (match u2.v with
          | Typ_app(v1,v2) -> (match v1.v with
              | Typ_const(x, _) when sli x.v = sli Const.not_lid -> true, v2
              | _ -> false, t)
          | _ -> false, t)
      | _ -> false, t)
  | _ -> false, t

let typToStrippedTyp t = snd (isDblNotTyp t)

let termsToStrippedTyps info tms =
  let l = List.map (termToTyp info []) tms in
  if existsNone l then None
  else Some (List.map typToStrippedTyp (projSomes l))

let termsToTyps info tms =
  let l = List.map (termToTyp info []) tms in
  if existsNone l then None
  else Some (projSomes l)



(****************************************************************************)
(* PATTERN MATCHING Z3 TERMS                                                *)
(****************************************************************************)

(* if tm2 is not the Z3 complement of tm1, returns None.
   else returns Some true if tm2 had a double not eliminated
   and Some false if it did not *)
let isComplementTerm (tm1,tm2) =
  match destructTerm "not" tm1 with
    | Some [a] -> if tm2 = a then Some(true) else None
    | _ -> (match destructTerm "not" tm2 with
              | Some [b] -> if tm1 = b then Some(false) else None
              | _ -> None)

let dblNotElimFlags terms1 terms2 =
  List.rev (List.map2 (fun a b ->
    match isComplementTerm (a,b) with
      | Some(flag) -> flag
      | None -> raise (Never "dblNotElimFlags")
  ) terms1 terms2)

(* TODO don't use exceptions for normal control flow *)

type pat = A of string * pat list
         | Tm of string
         | Cmp of string

exception DestructFailed

type mapping = (string, Term) Ht.t

exception IncompatibleMappings

let matchTermWithPat ((tm,x):Term*pat) : mapping option =
  let mapping = Ht.create "matchTermWithPat.mapping" (fun _ -> "_pat_") in
  let assertEqual a b = if a = b then () else raise DestructFailed in
  let rec foo tm = function
    | A(s,l) ->
        (match destructTerm s tm with
          | Some tms when List.length l = List.length tms ->
              List.iter (fun (t,d) -> foo t d) (List.zip tms l)
          | _ -> raise DestructFailed)
    | Tm(s) ->
        if Ht.mem mapping s then assertEqual tm (Ht.find mapping s)
        else Ht.add mapping s tm
    | Cmp(s) ->
        let s' = "!" ^ s in
        if Ht.mem mapping s' then assertEqual tm (Ht.find mapping s')
        else Ht.add mapping s' tm
  in
  try (foo tm x; Some mapping) with DestructFailed -> None

let combineMappings ml : mapping option =
  let assertEqual a b = if a = b then () else raise IncompatibleMappings in
  let f () =
    let res = Ht.create "combineMappingsAll.res" id in
    List.iter (fun m ->
      Ht.iter m (fun s tm ->
        if String.get s 0 = '!' then
          let ss = s.Substring 1 in //strTail s in
          (* when processing !P, P must have already been bound *)
          (* TODO might want to allow !P to be bound before P *)
          if not (Ht.mem res ss) then raise IncompatibleMappings
          else
          (* TODO use isComplementTerm *)
            let pTerm = Ht.find res ss in
            (match destructTerm "not" pTerm with
              | Some [a] -> assertEqual tm a
              | _        -> (match destructTerm "not" tm with
                              | Some [a] -> assertEqual pTerm a
                              | _        -> raise IncompatibleMappings))
        else begin
          let b = Ht.mem res s in
          if b && tm = Ht.find res s then ()
          else if b then raise IncompatibleMappings
          else Ht.add res s tm
        end
      )
    ) ml;
    Some res
  in
  try f () with IncompatibleMappings -> None

let destructPatsWithBvs info (bvs:list<string>)
                        (tpl:list<Term*pat>)
                        (ts:list<string>)
                        (us:list<string>)
                        (es:list<string>)
    : option< list<typ> * list<bool*typ> * list<exp*sort> > =
  let l = List.map matchTermWithPat tpl in
  if existsNone l then None
  else
    match combineMappings (projSomes l) with
      | None -> None
      | Some m ->
          let l1 = List.map (termToTyp info bvs) (List.map (Ht.find m) ts) in
          let l2 = List.map (termToTyp info bvs) (List.map (Ht.find m) us) in
          let l3 = List.map (termToExp info bvs) (List.map (Ht.find m) es) in
          if existsNone l1 || existsNone l2 || existsNone l3 then None
          else let x = List.map isDblNotTyp (projSomes l2) in
               Some (projSomes l1, x, projSomes l3)

let destructPats info = "ProofExtract.destructPats" ^^ lazy destructPatsWithBvs info []

let pats info l =
  match destructPats info l [] [] [] with Some(_,_,_) -> true | None -> false

let patsToTyps info l x = 
  match destructPats info l x [] [] with Some(a,_,_) -> Some a | None -> None

let patsToTyps2 info l x y =
  match destructPats info l x y [] with Some(a,b,_) -> Some (a,b) | None -> None

let patsToExps info l z =
  match destructPats info l [] [] z with Some(_,_,c) -> Some c | None -> None


(* optionally returns the (1-based) index in l that is complemented
   and true if the complement had a double not eliminated *)
let isComplementOfListItem info x l =
  let rec foo i = function
    | [] -> None
    | h::t ->
        (match destructTerm "not" h with
          | Some [y] -> if x=y then Some (i, true) else foo (i+1) t
          | _ ->
              (match destructTerm "not" x with
                | Some [z] -> if h=z then Some (i, false) else foo (i+1) t
                | _ -> foo (i+1) t (* check this case *)))
  in foo 1 l


(* e.g. l = [P1;P2;P3;P4], order = [1;4;2;3], result = [P1;P4;P2;P3] *)
let reorderList order l =
  let rec foo acc = function
    | [] -> acc
    | i::is -> foo ((List.nth l (i-1))::acc) is
  in
  List.rev (foo [] order)


(* given two lists of length n, take k from the first and n-k from the second *) 
let take_K_NK k l1 l2 =
  let rec foo acc k l1 l2 =
    if k = 0 then (List.rev acc) @ l2
    else foo ((List.hd l1)::acc) (k-1) (List.tl l1) (List.tl l2)
  in
  foo [] k l1 l2


(* replace the kth element in a list *)
let replaceAt k l x =
  let rec foo acc i = function
    | h::tl -> if i = 0 then (List.rev acc) @ (x::tl) else foo (h::acc) (i-1) tl
    | [] -> failwith "replaceAt"
  in
  foo [] k l



(****************************************************************************)
(* PROOF EXTRACTION RULE SCHEMAS                                            *)
(****************************************************************************)

let antes0 f : Term list -> proof option =
  function [tm1] -> f tm1 | _ -> raise (Never "antes0")

let antes1 f : Term list -> proof option =
  function [tm1;tm2] -> f tm1 tm2 | _ -> raise (Never "antes1")

let antes2 f : Term list -> proof option =
  function [tm1;tm2;tm3] -> f tm1 tm2 tm3 | _ -> raise (Never "antes2")


(*                     *)
(*     P (iff P Q)     *)
(*     -----------     *)
(*          Q          *)
(*                     *)
let _MpIff info = antes2 (fun tm1 tm2 tm3 ->
  let doIt tyP tyQ = Some (Pf_call (Theorems._ModusPonensIff, List.map stripPfT [tyP;tyQ], List.map wrapSubpf [tm1;tm2], tyQ, 12)) in
  let f1, f2, f3 = proofToFormula tm1, proofToFormula tm2, tm3 in 
  let d1 = f1, Tm "P" in
  let d2 = f2, A ("iff", [Tm "P"; Tm "Q"]) in
  let d3 = f3, Tm "Q" in
  match patsToTyps info [d1;d2;d3] ["P";"Q"] with
    | Some [tyP;tyQ] -> doIt tyP tyQ
      (* TODO remove this attempt *)
    | _ -> (* if iff didn't match, try ~ *)
        let d2 = f2, A ("~", [Tm "P"; Tm "Q"]) in
        (match patsToTyps info [d1;d2;d3] ["P";"Q"] with
          | Some [tyP;tyQ] -> doIt tyP tyQ
          | _ -> None)
)

(*                    *)
(*     P  (~ P P)     *)
(*     ----------     *)
(*          P         *)
(*                    *)
let _MpEqui_Useless info argIds = antes2 (fun tm1 tm2 tm3 ->
  let f1, f2, f3 = proofToFormula tm1, proofToFormula tm2, tm3 in 
  let d1 = f1, Tm "P" in
  let d2 = f2, A ("~", [Tm "P"; Tm "P"]) in
  let d3 = f3, Tm "P" in
  match patsToTyps info [d1;d2;d3] ["P"] with
    | Some [tyP] -> Some (Pf_exp (proofTermToProofExp tm1))
    | _ -> None
)

(*                    *)
(*     P  (~ P Q)     *)   (* ~ processed as implies *)
(*     ----------     *)
(*          Q         *)
(*                    *)
let _MpEqui info argIds = antes2 (fun tm1 tm2 tm3 ->
  let f1, f2, f3 = proofToFormula tm1, proofToFormula tm2, tm3 in 
  let d1 = f1, Tm "P" in
  let d2 = f2, A ("~", [Tm "P"; Tm "Q"]) in
  let d3 = f3, Tm "Q" in
  match patsToTyps info [d1;d2;d3] ["P";"Q"] with
    | Some [tyP;tyQ] -> 
        let id_eqsat = ProofState.Extraction.idOfTerm tm2 in  (* check if this is really a skolem function intro. *)
        let ante_proof = wrapSubpf tm1 in
        let eqsat_proof = wrapSubpf tm2 in
          if Ht.mem skolemPackages id_eqsat then 
            let ante_bvd = new_bvd None in
            let ante_var = W (Exp_bvar (bvd_to_bvar_s ante_bvd tunknown)) in
            let skrec = Ht.find skolemPackages id_eqsat in
              match skrec.mp_eq with 
                | Some _ -> raise (Never "Multiple uses of mp~ on a skolem/eq-sat")
                | None -> 
                    Ht.remove skolemPackages id_eqsat;
                    Ht.add skolemPackages id_eqsat {skrec with mp_eq=Some (ante_bvd, ante_proof)};
                    let pf = Pf_fadc_asc (Axioms._ModusPonens, List.map stripPfT [tyP;tyQ], [Subpf_exp ante_var; eqsat_proof], tyQ, 14) in
                      Some pf
          else
            let pf = Pf_fadc_asc (Axioms._ModusPonens, List.map stripPfT [tyP;tyQ], [ante_proof; eqsat_proof], tyQ, 14) in
              Some pf
    | _ -> None)

(*                   *)
(*     (iff P P)     *)
(*                   *)
let _ReflIff info = antes0 (fun tm1 ->
  let f1 = tm1 in
  let d1 = f1, A ("iff", [Tm "P"; Tm "P"]) in
  match patsToTyps info [d1] ["P"], termToTyp info [] f1 with
    | Some [tyP], Some goalTyp -> Some (Pf_call (Theorems._Refl, [stripPfT tyP], [], goalTyp, 13))
    | _ -> None
)

(*                 *)
(*     (= t t)     *)
(*                 *)
let _ReflEq info = antes0 (fun tm1 ->
  let f1 = tm1 in
  let d1 = f1, A ("=", [Tm "t"; Tm "t"]) in
    match patsToExps info [d1] ["t"], termToTyp info [] f1 with
      | Some [(e1,sort)], Some goalTyp -> 
          let reflVar, t = ProofCombinators.lookupAxiomTii info Const.reflexivity_lid sort in
            Some (Pf_fadc (reflVar, [t], [Subpf_exp e1], goalTyp, 14))
      | _ -> None)

  
(*                 *)
(*     (~ P P)     *)
(*                 *)
let _ReflEqui_id info = antes0 (fun f ->
    match destructTerm "~" f with 
      | None -> raise (Never (spr "Unexpected antecedent in _ReflEqui_id, with TLC=%s\n" ((!z3).GetAppDecl(f).GetDeclName())))
      | Some [p;_] -> 
          let p_typ = must (termToTyp info [] p) in
          let x = new_bvd None in
          let exp = (Exp_constr_app(Axioms._ImpliesIntro, 
                                    [stripPfT p_typ; stripPfT p_typ], 
                                    [],
                                    [(W (Exp_abs(x, p_typ, W (Exp_bvar (bvd_to_bvar x)))))])) in
            Some (Pf_exp (W exp))
(*
  match patsToTyps [d] ["P"], termToTyp [] f with
    | Some [tyP], Some goalTyp -> Some (Pf_call (Theorems._Refl, [stripPfT tyP], [], goalTyp, 15))
    | _ -> None
*)
)

(*                    *)
(*     (iff P P')     *)
(*                    *)
let _PullQuant info = antes0 (fun t ->
  (match destructTerm "iff" t with Some [p;p'] ->
  (match termToTyp info [] p, termToTyp info [] p', termToIff info [] t with Some tyP, Some tyP', Some goalTyp ->
     (* should also check that tyP and tyP' are "equal" *)
     Some (Pf_call (Theorems._Refl, [stripPfT tyP], [], goalTyp, 16))
  | _ -> None)
  | _ -> None)
)

(*                   *)
(*     (iff P Q)     *)
(*     ---------     *)
(*     (iff Q P)     *)
(*                   *)
let _SymmIff info = antes1 (fun tm1 tm2 ->
  let f1, f2 = proofToFormula tm1, tm2 in
  let d1 = f1, A ("iff", [Tm "P"; Tm "Q"]) in
  let d2 = f2, A ("iff", [Tm "Q"; Tm "P"]) in
  match patsToTyps info [d1;d2] ["P";"Q"], termToTyp info [] f2 with
    | Some [tyP;tyQ], Some goalTyp -> Some (Pf_call (Theorems._Symm, List.map stripPfT [tyP;tyQ], [wrapSubpf tm1], goalTyp, 17))
    | _ -> None
)

(*                 *)
(*     (= t u)     *)
(*     -------     *)
(*     (= u t)     *)
(*                 *)
let _SymmEq info = antes1 (fun tm1 tm2 ->
  let f1, f2 = proofToFormula tm1, tm2 in
  let d1 = f1, A ("=", [Tm "t"; Tm "u"]) in
  let d2 = f2, A ("=", [Tm "u"; Tm "t"]) in
  match patsToExps info [d1;d2] ["t";"u"], termToTyp info [] f2 with
    | Some [(e1, tii1);(e2, tii2)], Some goalTyp when tii1 = tii2 ->
        let symmVar, t = ProofCombinators.lookupAxiomTii info Const.symmetry_lid tii1 in
          Some (Pf_fadc (symmVar, [t], [wrapSubpfExp e1; wrapSubpfExp e2; wrapSubpf tm1], goalTyp, 18))
    | _ -> None
)

(*                             *)
(*     (iff P Q) (iff Q R)     *)
(*     -------------------     *)
(*          (iff P R)          *)
(*                             *)
let _TransIff info = antes2 (fun tm1 tm2 tm3 ->
  let f1, f2, f3 = proofToFormula tm1, proofToFormula tm2, tm3 in 
  let d1 = f1, A ("iff", [Tm "P"; Tm "Q"]) in
  let d2 = f2, A ("iff", [Tm "Q"; Tm "R"]) in
  let d3 = f3, A ("iff", [Tm "P"; Tm "R"]) in
  match patsToTyps info [d1;d2;d3] ["P";"Q";"R"], termToTyp info [] f3 with
    | Some [tyP;tyQ;tyR], Some goalTyp ->
        Some (Pf_call (Theorems._Trans, List.map stripPfT [tyP;tyQ;tyR], List.map wrapSubpf [tm1;tm2], goalTyp, 19))
    | _ -> None
)

(*                         *)
(*     (= t u) (= u v)     *)
(*     ---------------     *)
(*         (= t v)         *)
(*                         *)
let _TransEq info = antes2 (fun tm1 tm2 tm3 ->
  let f1, f2, f3 = proofToFormula tm1, proofToFormula tm2, tm3 in 
  let d1 = f1, A ("=", [Tm "t"; Tm "u"]) in
  let d2 = f2, A ("=", [Tm "u"; Tm "v"]) in
  let d3 = f2, A ("=", [Tm "t"; Tm "v"]) in
  match patsToExps info [d1;d2] ["t";"u";"v"], termToTyp info [] f3 with
    | Some [(e1, tii1);(e2, tii2);(e3, tii3)],
      Some goalTyp when tii1 = tii2 && tii2 = tii3 ->
        let transVar, t = ProofCombinators.lookupAxiomTii info Const.transitivity_lid tii1 in
          Some (Pf_fadc (transVar, [t],
                         [wrapSubpfExp e1; wrapSubpfExp e2; wrapSubpfExp e3;
                          wrapSubpf tm1; wrapSubpf tm2],
                         goalTyp, 20))
    | _ -> None)


(*                         *)
(*     (and p1 ... pn)     *)
(*     ---------------     *)
(*            pi           *)
(*                         *)
let _AndElim info = antes1 (fun tm1 tm2 ->
  let f1, f2 = proofToFormula tm1, tm2 in
  (match destructTerm "and" f1 with Some ps ->
  (match findIdx f2 ps with Some i ->
  (match termsToTyps info ps with Some tyPs ->
  (match termToTyp info [] f2 with Some goalTyp ->
     Some (Pf_call (Theorems._AndElim (List.length ps) (i+1), List.map stripPfT tyPs, [wrapSubpf tm1], goalTyp, 21))
  | _ -> None)
  | _ -> None)
  | _ -> None)
  | _ -> None)
)

(*                              *)
(*     (not (or p1 ... pn))     *)
(*     --------------------     *)
(*             !pi              *)
(*                              *)
let _NotOrElim info = antes1 (fun tm1 tm2 ->
  let rec padFlags n i flagi k acc =
    if k > n then List.rev acc
    else if k = i then padFlags n i flagi (k+1) (flagi::acc)
    else padFlags n i flagi (k+1) (false::acc) (* default flag is false, so some auxiliary types may become double nots *)
  in
  let f1, f2 = proofToFormula tm1, tm2 in
  (match destructTerm "not" f1 with Some [o] ->
  (match destructTerm "or" o with Some ps ->
  (match isComplementOfListItem info f2 ps with Some(i,flag) ->
  (match termsToTyps info ps with Some tyPs ->
  (match termToTyp info [] f2 with Some goalTyp ->
     let n = List.length ps in
     let flags = padFlags n i flag 1 [] in
     let strippedTyPi = typToStrippedTyp (List.nth tyPs (i-1)) in 
     let typs = replaceAt (i-1) tyPs strippedTyPi in
     let e = mkCall1 (Theorems._DeMorgan_NotOr n flags) (List.map stripPfT typs) [proofTermToProofExp tm1] in
     let negatedStrippedTyPi = if flag then strippedTyPi else mkPfNot strippedTyPi in
     let typs' = replaceAt (i-1) (List.map mkPfNot typs) negatedStrippedTyPi in
     (* typs' is all (not Pj)'s, except that ith is (Pi) if flag is true, (not Pi) if flag is false *)
     Some (Pf_call (Theorems._AndElim (List.length ps) i, (List.map stripPfT typs'), [wrapSubpfExp e], goalTyp, 22))
  | _ -> None)
  | _ -> None)
  | _ -> None)
  | _ -> None)
  | _ -> None)
)



(****************************************************************************)
(* [unit-resolution]                                                        *)

(*                     *)
(*     true  false     *)
(*     -----------     *)
(*        false        *)
(*                     *)
(* Could easily generalize this to look for a conclusion that is simply one of the antecedents, but no need. *)
let _Trivial info = antes2 (fun tm1 tm2 tm3 ->
  match destructTerm "true" (proofToFormula tm1), destructTerm "false" (proofToFormula tm2), destructTerm "false" tm3 with
    | Some [], Some [], Some [] -> Some (Pf_exp (proofTermToProofExp tm2)) (* TODO delay expansion *)
    | _ -> None
)

(*               *)
(*     P  !P     *)
(*     -----     *)
(*     false     *)
(*               *)
let _Contra info = antes2 (fun tm1 tm2 tm3 ->
  let f1, f2, f3 = proofToFormula tm1, proofToFormula tm2, tm3 in
  let d1 = f1, Tm "P" in
  let d2 = f2, Cmp "P" in
  match patsToTyps2 info [d1;d2] [] ["P"] with
    | Some ([],[flag,strippedTyP]) ->
        Some (Pf_call (Theorems._Contra flag, [stripPfT strippedTyP], List.map wrapSubpf [tm1;tm2], mkPfT Const.false_typ, 23))
    | _ -> None
)
  

(* note: the or term has to be reordered based on the other antecedents,
   which results in the following canonical forms: *)

(*                                    *)
(*     (or p1 ... pn) !p1 ... !pn     *)
(*     --------------------------     *)
(*                false               *)
(*                                    *)

(*                                      *)
(*     (or p1 ... pn) !p1 ... !pn-1     *)
(*     ----------------------------     *)
(*                  pn                  *)
(*                                      *)

(*                                    *)
(*     (or p1 ... pn) !p1 ... !pi     *)
(*     --------------------------     *)
(*          (or pi+1 ... pn)          *)
(*                                    *)

let _UnitResGeneral info tms =
  let getUnitResOrderAndFlags n terms complements : int list * bool list =
  (* TODO rewrite without set reference *)
    let s = ref (Zset.empty compare) in
    let complemented, flags =
      List.split (List.rev (List.fold_left (fun acc compterm ->
        match isComplementOfListItem info compterm terms with
          | Some(i,flag) -> (s := Zset.add i !s; (i,flag)::acc)
          | None -> raise (Never "getUnitResOrderAndFlags")
      ) [] complements)) in
    let notComplemented =
      List.rev (List.fold_left (fun acc i ->
        if Zset.mem i !s then acc else i::acc
      ) [] (list1N n)) in
    (complemented @ notComplemented), flags
  in
  (* TODO can use splitAntesAndGoal here? *)
  let goal, rest =
    (match List.rev tms with
       | goal::rest -> goal, rest | _ -> raise (Never "unitres")) in
  let x, y = 
    (match List.rev rest with
       | x::y -> x, y | _ -> raise (Never "unitres")) in
  let hd, cps =
    (match List.map proofToFormula (x::y) with
       | hd::cps -> hd, cps | _ -> raise (Never "unitres")) in
  (match destructTerm "or" hd with Some ps ->
  (match termsToTyps info ps with Some tyPs ->
  (match termsToStrippedTyps info ps with Some strippedTyPs -> (* inefficient, reuse tyPs somehow *)
  (match termToTyp info [] goal with Some goalTyp ->
     let n, k = List.length ps, List.length cps in
     let order, flags = getUnitResOrderAndFlags n ps cps in
(*
     let rearr = Theorems._Commute_Or order in
     let tyPs = List.map stripPfT tyPs in
*)
(*
     let newOrTerm = mkCall1 (Theorems._Commute_Or order) (List.map stripPfT strippedTyPs) [proofTermToProofExp x] in
*)
     let newOrTerm = mkCall1 (Theorems._Commute_Or order) (List.map stripPfT tyPs) [proofTermToProofExp x] in
     let subpfs = wrapSubpfExp newOrTerm :: (List.map wrapSubpf y) in
(*
     Some (Pf_call (Theorems._UnitRes n k flags, reorderList tyPs order, subpfs, goalTyp, 24))
*)
(*
let _ = List.iter (fun t -> pr "one: %s\n" (strTyp t)) (List.map stripPfT strippedTyPs) in
let _ = List.iter (fun t -> pr "two: %s\n" (strTyp t)) (List.map stripPfT (reorderList strippedTyPs order)) in
*)
(*
     let crazyList = reorderList order (List.map stripPfT (take_K_NK k tyPs strippedTyPs)) in
*)
     let reorderedTyPs = reorderList order tyPs in
     let reorderedStrippedTyPs = reorderList order strippedTyPs in
     let crazyList = List.map stripPfT (take_K_NK k reorderedStrippedTyPs reorderedTyPs) in
     Some (Pf_call (Theorems._UnitRes n k flags, crazyList, subpfs, goalTyp, 24))
(*
     Some (Pf_call (Theorems._UnitRes n k flags, reorderList (List.map stripPfT strippedTyPs) order, subpfs, goalTyp, 24))
*)
  | _ -> None)
  | _ -> None)
  | _ -> None)
  | _ -> None)



(****************************************************************************)
(* [def-axiom]                                                              *)

(*                                 *)
(*     (or (or p1 ... pn) !pi)     *)
(*                                 *)
let _DefAxiomOne info = antes0 (fun f ->
  (match destructTerm "or" f with Some [o;cpi] ->
  (match destructTerm "or" o with Some ps ->
  (match isComplementOfListItem info cpi ps with Some(i,flag) ->
  (match termToTyp info [] f with Some goalTyp ->
  (match termsToTyps info ps with Some tyPs ->
     let typopts = List.map (termToTyp info []) ps in
     if existsNone typopts then None
     else
       let n = List.length ps in
       (* TODO types *)
(*
       Some (Pf_call (Theorems._DefAxiomOne n i flag, List.map stripPfT [], [], goalTyp, 25))
*)
       let strippedTyPi = typToStrippedTyp (List.nth tyPs (i-1)) in 
       let l = replaceAt (i-1) tyPs strippedTyPi in
       Some (Pf_call (Theorems._DefAxiomOne n i flag, List.map stripPfT l, [], goalTyp, 25))
  | _ -> None)
  | _ -> None)
  | _ -> None)
  | _ -> None)
  | _ -> None)
)

(*                                       *)
(*     (or (not (and p1 ... pn)) pi)     *)
(*                                       *)
let _DefAxiomTwo info = antes0 (fun f ->
  (match destructTerm "or" f with Some [x;pi] ->
  (match destructTerm "not" x with Some [y] ->
  (match destructTerm "and" y with Some ps ->
  (match findIdx pi ps with Some i ->
  (match termsToTyps info ps with Some tyPs ->
  (match termToTyp info [] f with Some goalTyp ->
     let typopts = List.map (termToTyp info []) ps in
     if existsNone typopts then None
     else
       let n = List.length ps in
       Some (Pf_call (Theorems._DefAxiomTwo n i, List.map stripPfT tyPs, [], goalTyp, 26))
  | _ -> None)
  | _ -> None)
  | _ -> None)
  | _ -> None)
  | _ -> None)
  | _ -> None)
)
    

(*                                          *)
(*     (or (and p1 ... pn) !p1 ... !pn)     *)
(*                                          *)
let _DefAxiomThree info = antes0 (fun f ->
  let rec complementsInOrder = function
    | [], [] -> true
    | [], _ | _, [] -> false
    | (h1::t1), (h2::t2) ->
        (match isComplementTerm (h1,h2) with
           | Some _ -> complementsInOrder (t1,t2)
           | _ -> false)
  in
  (match destructTerm "or" f with Some (hd::tl) ->
  (match destructTerm "and" hd with Some ps when complementsInOrder (ps,tl) ->
  (match termsToStrippedTyps info ps with Some strippedTyPs ->
  (match termToTyp info [] f with Some goalTyp ->
     let typopts = List.map (termToTyp info []) ps in
     if existsNone typopts then None
     else
       let n = List.length ps in
       let flags = dblNotElimFlags ps tl in
       Some (Pf_call (Theorems._DefAxiomThree n flags, List.map stripPfT strippedTyPs, [], goalTyp, 27))
  | _ -> None)
  | _ -> None)
  | _ -> None)
  | _ -> None)
)

(*                                             *)
(*     (or (not (or p1 ... pn)) p1 ... pn)     *)
(*                                             *)
let _DefAxiomFour info = antes0 (fun f ->
  (match destructTerm "or" f with Some (hd::tl)->
  (match destructTerm "not" hd with Some [x] ->
  (match destructTerm "or" x with Some ps when ps = tl ->
  (match termsToTyps info ps with Some tyPs ->
  (match termToTyp info [] f with Some goalTyp ->
     let typopts = List.map (termToTyp info []) ps in
     if existsNone typopts then None
     else
       let n = List.length ps in
       Some (Pf_call (Theorems._DefAxiomFour n, List.map stripPfT tyPs, [], goalTyp, 28))
  | _ -> None)
  | _ -> None)
  | _ -> None)
  | _ -> None)
  | _ -> None)
)

(*                                   *)
(*     (or (not (iff p q)) !p q)     *)
(*                                   *)
let _DefAxiomFive info = antes0 (fun f ->
  let d1 = f, A ("or", [A ("not", [A ("iff", [Tm "P"; Tm "Q"])]);
                        Cmp "P";
                        Tm "Q"]) in
  match patsToTyps2 info [d1] ["Q"] ["P"], termToTyp info [] f with
    | Some ([tyQ],[flag,strippedTyP]), Some goalTyp ->
        Some (Pf_call (Theorems._DefAxiomFive flag, List.map stripPfT [strippedTyP;tyQ], [], goalTyp, 29))
    | _ -> None
)

(*                                   *)
(*     (or (not (iff p q)) p !q)     *)
(*                                   *)
let _DefAxiomSix info = antes0 (fun f ->
  let d1 = f, A ("or", [A ("not", [A ("iff", [Tm "P"; Tm "Q"])]);
                        Tm "P";
                        Cmp "Q"]) in
  match patsToTyps2 info [d1] ["P"] ["Q"], termToTyp info [] f with
    | Some ([tyP],[flag,strippedTyQ]), Some goalTyp ->
        Some (Pf_call (Theorems._DefAxiomSix flag, List.map stripPfT [tyP;strippedTyQ], [], goalTyp, 30))
    | _ -> None
)

(*                              *)
(*     (or (iff p q) !p !q)     *)
(*                              *)
let _DefAxiomSeven info = antes0 (fun f ->
  let d1 = f, A ("or", [A ("iff", [Tm "P"; Tm "Q"]); Cmp "P"; Cmp "Q"]) in
  match patsToTyps2 info [d1] [] ["P";"Q"], termToTyp info [] f with
    | Some ([],[(flag1,strippedTyP);(flag2,strippedTyQ)]), Some goalTyp ->
        let flags = [flag1;flag2] in
        Some (Pf_call (Theorems._DefAxiomSeven flags, List.map stripPfT [strippedTyP;strippedTyQ], [], goalTyp, 31))
    | _ -> None
)

(*                            *)
(*     (or (iff p q) p q)     *)
(*                            *)
let _DefAxiomEight info = antes0 (fun f ->
  let d1 = f, A ("or", [A ("iff", [Tm "P"; Tm "Q"]); Tm "P"; Tm "Q"]) in
  match patsToTyps info [d1] ["P";"Q"], termToTyp info [] f with
    | Some [tyP;tyQ], Some goalTyp -> Some (Pf_call (Theorems._DefAxiomEight, List.map stripPfT [tyP;tyQ], [], goalTyp, 32))
    | _ -> None
)

(*                        *)
(*     (or (not p) p)     *)
(*                        *)
let _DefAxiomNine info = antes0 (fun f ->
  let d1 = f, A ("or", [A ("not", [Tm "P"]); Tm "P"]) in
  match patsToTyps info [d1] ["P"], termToTyp info [] f with
    | Some [tyP], Some goalTyp -> Some (Pf_call (Theorems._DefAxiomNine, [stripPfT tyP], [], goalTyp, 33))
    | _ -> None
)


(****************************************************************************)
(* [monotonicity]                                                           *)

let rec monoSubproofs (reflFun: Term -> exp)
                      (acc: subproof list)
                      (argPairs: (Term * Term) list)
                      (remainingAntes: Term list) : subproof list =
  match argPairs with
    | [] ->
        if remainingAntes <> []
        then raise (Never "remaining antes")
        else List.rev acc
    | (ai,bi)::tl ->
        let pf, pfs =
          (* if Terms are different, pick proof of their equality from
             antecedent proofs (assuming the proofs are in order).
             else, use the reflexivity function reflFun. *)
          if ai <> bi
            then wrapSubpf (List.hd remainingAntes), List.tl remainingAntes
            else wrapSubpfExp (reflFun ai), remainingAntes in
        monoSubproofs reflFun (pf::acc) tl pfs

let monoSubproofsTyps info =
  monoSubproofs
    (fun ai ->
       match termToTyp info [] ai with
(*
         | Some t -> mkCall2 Theorems._Refl [] (mkPfIff t t)
*)
         | Some t -> mkCall1 Theorems._Refl [stripPfT t] []
         | _      -> raise (Never "monoSubproofsTyps")
    ) []

let monoSubproofsExps info =
  monoSubproofs
    (fun ai ->
       match termToExp info [] ai with
         | Some(e,tii) -> 
             let reflVar, t = ProofCombinators.lookupAxiomTii info Const.reflexivity_lid tii in
               mkDconApp reflVar [t] [e] 
         | _                -> raise (Never "monoSubproofsExps: exp term"))
     []


(*                                          *)
(*       (iff aj bj) ... (iff ak bk)        *) 
(*     --------------------------------     *)
(*     (iff (f a1 ... an) (f b1 ... bn)     *)
(*                                          *)
let _MonoConnective info tms =
  let anteProofs, goal = splitAntesAndGoal tms in
  (match destructTerm "iff" goal with Some [x;y] ->
  (match getAppSymbol x, getAppSymbol y with f, f' when f = f' ->
  (match termToIff info [] goal with Some goalTyp ->
     let args1, args2 = getAppArgs x, getAppArgs y in
     let n = List.length args1 in let _ = assert (n = List.length args2) in
     let mono = match f, n with
       | "not", 1           -> Theorems._Monotonicity_Not
       | "implies", 2       -> Theorems._Monotonicity_Imp
       | "iff", 2 | "~", 2  -> Theorems._Monotonicity_Iff
       | "or", _            -> Theorems._Monotonicity_Or n
       | "and", _           -> Theorems._Monotonicity_And n
       | _                  -> raise (Never (spr "_MonoConnective %s %d" f n))
       (* call _MonoConnective after other _Mono rules *)
     in
     let subpfs = monoSubproofsTyps info (List.zip args1 args2) anteProofs in
     (match termsToTyps info args1, termsToTyps info  args2 with Some tyAs, Some tyBs ->
        Some (Pf_call (mono, List.map stripPfT (interleave tyAs tyBs), subpfs, goalTyp, 37))
     | _ -> None)
  | _ -> None)
  | _ -> None)
  | _ -> None)

let tupleComponentTypes tii = 
  match (typOfSort tii).v with 
      Typ_dtuple([(_, t_fst); (_, t_snd)]) -> t_fst, t_snd
    | _ -> raise (Never "expected tuple")
        
let tupleAxiom info tii lid = 
  let t_fst, t_snd = tupleComponentTypes tii in
  let tAx = Tcenv.lookup_lid info.envn lid in
  let eAx = fvwithsort lid tAx in
  let eAx = Exp_constr_app(eAx, [t_fst;t_snd], [], []) in
  let tAx = open_typ_with_typ (open_typ_with_typ tAx t_fst) t_snd in
    ewithsort eAx tAx

let tupleEqAxiom info tii fieldId = 
  let lid = if fieldId = 1 then Const.tupeq1_lid else Const.tupeq2_lid in
    tupleAxiom info tii lid

let tupleProjAxiom info tii fieldId = 
  let lid = if fieldId = 1 then Const.tupproj1_lid else Const.tupproj2_lid in
    tupleAxiom info tii lid

(*                                         *)
(*         (= tj uj) ... (= t_k u_k)       *)
(*     -------------------------------     *)
(*     (= (D t1 ... tn) (D u1 ... un))     *)
(*                                         *)
let _MonoFunSym info ts =
  let ps, g = splitAntesAndGoal ts in

  let doMonoDataCon tm1 tm2 monoPrinciple targs =
    (match termToExp info  [] tm1, termToExp info  [] tm2, termToEq info  [] g with
       | Some(e1, tii1), Some(e2, tii2), Some goal when tii1 = tii2 ->
           let stuff =
             (match e1.v, e2.v with
                | Exp_constr_app(_,_,_,es), Exp_constr_app(_,_,_,fs) ->
                    Some(es,fs)
(* TODO recd *)
                | Exp_recd(_,_,_,l1), Exp_recd(_,_,_,l2) -> (* hasn't been exercised *)
                    let (_,es),(_,fs) = List.split l1, List.split l2 in
                    Some(es,fs)
                | _ -> None) in
           (match stuff with Some(es,fs) ->
              let args = List.map wrapSubpfExp (interleave es fs) in 
              let argPairs = List.zip (getAppArgs tm1) (getAppArgs tm2) in
              let eqPfs = monoSubproofsExps info argPairs ps in
              Some (Pf_fadc (monoPrinciple, targs, args @ eqPfs, goal, 0))
           | _ -> None)
       | _ -> None) in

  let doMonoProj tii isTuple fieldId =
    (match ps with [anteProof] ->
    (match termToTyp info  [] (proofToFormula anteProof) with Some anteTyp ->
    (match destructTerm "=" (proofToFormula anteProof) with Some [x1;x2] -> 
    (match termToExp info  [] x1, termToExp info  [] x2, termToEq info [] g with
       | Some(tupOrRecd1,_), Some(tupOrRecd2,_), Some goalTyp ->
           let eAx, tAx = 
             if isTuple then 
               let eAx = tupleEqAxiom info tii fieldId in
                 eAx, eAx.sort                   
             else
               let ax = AutoAxioms.recdEq (tii,fieldId) in
                 liToExp ax.v, ax.sort in
           let (bvAx,_,tAxRange) = destructDepArrow (stripPfT tAx) in
           let pf = proofTermToProofExp (List.hd ps) in
           let t1 = stripPfT tAx in
           let t2 = substitute_exp (stripPfT tAxRange) bvAx tupOrRecd1 in
           let ((bvFoo,_),eFoo) = mkFormDom "foo" t1  in
           let ((bvGoo,_),eGoo) = mkFormDom "goo" t2 in
           let mp = W (Exp_constr_app(Axioms._ModusPonens, 
                                      (List.map stripPfT [anteTyp;goalTyp]), 
                                      [],
                                      [pf; mkExpApp eGoo tupOrRecd2])) in
           let funGoo = mkTagExpAbs 54 bvGoo t2 mp in
           let innerBind = mkTagDconApp 53 Axioms._BindPf [t2; stripPfT goalTyp] [mkExpApp eFoo tupOrRecd1; funGoo] in
           let funFoo = mkTagExpAbs 52 bvFoo t1 innerBind in
             Some (Pf_fadc (Axioms._BindPf, [t1; stripPfT goalTyp], [wrapSubpfExp eAx; wrapSubpfExp funFoo], goalTyp, 51))
       | _ -> None)
       | _ -> None)
       | _ -> None)
       | _ -> None) in
    
  (match destructTerm "=" g with Some [tm1;tm2] ->
     let funsym = getAppSymbol tm1 in
     let _ = assert (funsym = getAppSymbol tm2) in
     (match ProofState.Z3Symbols.dconinstOfSym funsym with
        | Some(x) -> doMonoDataCon tm1 tm2 (AutoAxioms.monoDconinst x) []
        | None ->
     (match ProofState.Z3Symbols.tupleCtorOfSym funsym with
        | Some(tii) -> 
            let t_fst, t_snd = tupleComponentTypes tii in
            let tAx = Tcenv.lookup_lid info.envn Const.tupmonoeq_lid in
            let eAx = fvwithsort Const.tupmonoeq_lid tAx in
              doMonoDataCon tm1 tm2 eAx [t_fst;t_snd]
        | None ->
     (match ProofState.Z3Symbols.recdCtorOfSym funsym with
        | Some(tii) -> doMonoDataCon tm1 tm2 (AutoAxioms.recdMonoEq tii) []
        | None ->
     (match ProofState.Z3Symbols.tupleProj1OfSym funsym with
        | Some(tii) -> doMonoProj tii true 1
        | None ->
     (match ProofState.Z3Symbols.tupleProj2OfSym funsym with
        | Some(tii) -> doMonoProj tii true 2
        | None ->
     (match ProofState.Z3Symbols.recdProjOfSym funsym with
        | Some(tii,j) -> doMonoProj tii false j
        | None ->
     failwith (spr "_MonoFunSym %s" funsym)))))))
  | _ -> None)


(*                                           *)
(*              (= ei fi)                    *)
(*     ---------------------------------     *)
(*     (iff (P e1 ... en) (P f1 ... fn))     *)
(*                                           *)
let _MonoProp info ts =
  let antes, g = splitAntesAndGoal ts in
    (match destructTerm "iff" g with Some [tm1;tm2] ->
       (match termToProp info [] tm1, termToProp info [] tm2, termToIff info [] g with
          | Some p1, Some p2, Some goalTyp -> begin
              let tc1, es = destructFaProp (stripPfT p1) in 
              let tc2, fs = destructFaProp (stripPfT p2) in 
                (*   assert (sli tc1 = sli tc2); *)
              let pkind = Tcenv.lookup_typ_const info.envn (Wftv tc1) in           
              let ptyp = (twithsort (Typ_const (fvwithsort tc1 pkind, None)) pkind) in
              let ifftransT = Tcenv.lookup_lid info.envn Const.ifftrans_lid  in
              let ifftrans = fvwithsort Const.ifftrans_lid ifftransT  in
              let argPairs = List.zip (getAppArgs tm1) (getAppArgs tm2) in
              let termToExp tm = 
                match termToExp info [] tm with
                    Some (e, tii) -> 
                      setsort e (typOfSort tii)
                  | _ -> raise (Never "Failed to translate argument in monoprop") in
              let ef_list = 
                List.map (fun (e_term, f_term) -> termToExp e_term, termToExp f_term)
                  argPairs in
              let useOneAnte args (ei:exp) (fi:exp) (ante:Term) : exp = 
                let x = Absyn.new_bvd None in
                let ti = ei.sort in
                let ptyp_app = List.fold_left 
                  (fun tdep ei_scan -> 
                     if LanguagePrimitives.PhysicalEquality ei_scan ei then
                       Wt (Typ_dep(tdep, W(Exp_bvar (bvd_to_bvar x))))
                     else Wt (Typ_dep(tdep, ei_scan))) ptyp args in
                let propT = twithsort (Typ_lam(x, ti, ptyp_app)) (Kind_dcon(None, ti, Kind_star)) in
                let monoPropT = Tcenv.lookup_lid info.envn Const.monoprop_lid in
                let monoPropVar = fvwithsort Const.monoprop_lid monoPropT in
                let antePf = proofTermToProofExp ante in
                  W (Exp_constr_app(monoPropVar, [ti; propT], [], [ei;fi;antePf])) in
                
              let orig_args = List.map fst ef_list in
              let orig_typ = List.fold_left 
                (fun typ e -> Wt (Typ_dep(typ, e))) ptyp orig_args in
                
              let _, (Some pf) = List.fold_left 
                (fun (argPairs, proofStep) ante -> 
                   let rec until_ante out_e out_ap ef_list ap_list = match ef_list, ap_list with 
                     | (ei, fi)::ef_tl, (a_ei, a_fi)::ap_tl -> 
                         if a_ei <> a_fi then
                           (ei, fi, 
                            ((List.rev (ei::out_e))@(List.map fst ef_tl)),
                            ((List.rev (fi::out_e))@(List.map fst ef_tl)),
                            (List.rev ((a_fi, a_fi)::out_ap))@ap_tl )
                         else
                           until_ante (fi::out_e) ((a_fi, a_fi)::out_ap) ef_tl ap_tl 
                             
                     | _ -> raise (Never "Should never reach the end if there are more antes") in
                     
                   let ei, fi, pre_args, post_args, next_argPairs = until_ante [] [] ef_list argPairs in
                   let step = useOneAnte pre_args ei fi ante in
                   let proofStep = match proofStep with 
                     | None -> step
                     | Some prior -> 
                         let prior_typ = List.fold_left 
                           (fun typ e -> Wt (Typ_dep(typ, e))) ptyp pre_args in
                         let this_typ = List.fold_left 
                           (fun typ e -> Wt (Typ_dep(typ, e))) ptyp post_args in
                           fold_app_tapp (W (Exp_fvar(ifftrans, None))) [Inl orig_typ;
                                                                   Inl prior_typ; 
                                                                   Inl this_typ; Inr prior; Inr step] in
                     (next_argPairs, Some proofStep)) (argPairs, None) antes in
                Some (Pf_exp pf)
            end
          | _ -> None)
       | _ -> None)

(*                                   *)
(*      (= xj yj) ... (= xk yk)      *)
(*     -------------------------     *)
(*     (iff (= x1 x2) (= y1 y2))     *)
(*                                   *)
let _MonoEq info ts =
  let ps, g = splitAntesAndGoal ts in
  (match destructTerm "iff" g with Some [tm1;tm2] ->
  (match destructTerm "=" tm1 with Some [x1;x2] ->
  (match destructTerm "=" tm2 with Some [y1;y2] ->
  (match termToIff info [] g with Some goalTyp ->
  (match termToExp info [] x1, termToExp info [] x2, termToExp info [] y1, termToExp info [] y2 with
    | Some (ex1, tii1), Some (ex2, tii2), Some (ey1, tii3), Some (ey2, tii4)
          when tii1 = tii2 && tii2 = tii3 && tii3 = tii4 ->
        let eqPfs = monoSubproofsExps info [(x1,y1);(x2,y2)] ps in
        let es = List.map wrapSubpfExp [ex1;ey1;ex2;ey2] in
        let monoVar, t = ProofCombinators.lookupAxiomTii info Const.eqmono_lid tii1 in
          Some (Pf_fadc (monoVar, [t], es@eqPfs, goalTyp, 34))
    | _ -> None)
  | _ -> None)
  | _ -> None)
  | _ -> None)
  | _ -> None)


(****************************************************************************)
(* [rewrite]                                                                *)

(*                            *)
(*     (iff (= t t) true)     *)
(*                            *)
let _Rw_Id info = antes0 (fun tm ->
  (match destructTerm "iff" tm with Some [tm1;tm2] ->
  (match destructTerm "true" tm2 with Some [] ->
  (match destructTerm "=" tm1 with Some [x1;x2] when x1 = x2 ->
  (match termToExp info  [] x1 with Some (e, tii) ->
  (match termToTyp info [] tm1, termToIff info [] tm with Some ty1, Some goalTyp ->
     let ty1' = stripPfT ty1 in
     let ty2 = mkPfT Const.true_typ in
     let fun1 =
       let ((bvd,_),_) = mkFormDom "rwid1" ty1 in
       mkExpAbs bvd ty1 proofTrue in
     let fun2 =
       let ((bvd,_),_) = mkFormDom "rwid2" ty2 in
       let reflVar, t = ProofCombinators.lookupAxiomTii info Const.reflexivity_lid tii in
         mkExpAbs bvd ty2 (mkDconApp reflVar [t] [e]) in
     let imp1 = mkDconApp Axioms._ImpliesIntro [ty1';Const.true_typ] [fun1] in
     let imp2 = mkDconApp Axioms._ImpliesIntro [Const.true_typ;ty1'] [fun2] in
     Some (Pf_fadc (Axioms._IffIntro, [ty1';Const.true_typ], List.map wrapSubpfExp [imp1;imp2], goalTyp, 0))
  | _ -> None)
  | _ -> None)
  | _ -> None)
  | _ -> None)
  | _ -> None)
)

(*                                   *)
(*     (iff (implies true P) P))     *)
(*                                   *)
let _Rw_TrueImplies  info = antes0 (fun tm ->
  let d = tm, A ("iff", [A ("implies", [A ("true", []); Tm "P"]); Tm "P"]) in
  match patsToTyps info [d] ["P"], termToIff info [] tm with
    | Some [tyP], Some goalTyp -> Some (Pf_call (Theorems._Rewrite_TrueImplies, [stripPfT tyP], [], goalTyp, 0))
    | _ -> None
)

(*                                 *)
(*     (iff (not true) false))     *)
(*                                 *)
let _Rw_NotTrue info = antes0 (fun tm ->
  let d = tm, A ("iff", [A ("not", [A ("true", [])]); A ("false", [])]) in
  match pats info [d], termToIff info [] tm with
    | true, Some goalTyp ->
        let tyNT, tyF = mkPfNot (mkPfT Const.true_typ), mkPfT Const.false_typ in
        let fun1 =
          let ((bvd,_),proofNotTrue) = mkFormDom "pfNotTru" tyNT in
          let a = mkDconApp Axioms._AndIntro [Const.true_typ; stripPfT tyNT] [proofTrue;proofNotTrue] in
          let contra = mkDconApp Axioms._Contra [Const.true_typ] [a] in
          mkExpAbs bvd tyNT (mkDconApp Axioms._DestructFalse [Const.false_typ] [contra]) in
        let fun2 =
          let ((bvd,_),proofFalse) = mkFormDom "pfFls" tyF in
          mkExpAbs bvd tyF (mkDconApp Axioms._DestructFalse [stripPfT tyNT] [proofFalse]) in
        let imp1 = mkDconApp Axioms._ImpliesIntro (List.map stripPfT [tyNT;tyF]) [fun1] in
        let imp2 = mkDconApp Axioms._ImpliesIntro (List.map stripPfT [tyF;tyNT]) [fun2] in
        Some (Pf_fadc (Axioms._IffIntro, List.map stripPfT [tyNT;tyF], List.map wrapSubpfExp [imp1;imp2], goalTyp, 0))
    | _ -> None
)


let termListBijection l1 l2 =
  if List.length l1 <> List.length l2 then None else
  let l = List.map (fun x -> match findIdx x l1 with
                               | None   -> None
                               | Some i -> Some (i+1)) l2 in
  if existsNone l then None
  else Some (projSomes l)

let getTermJuncts conn tm0 =
  let notConn tm0 = (match destructTerm conn tm0 with None -> true | _ -> false) in
  let rec aux acc tm0 = 
    (match destructTerm conn tm0 with
       | None -> Some (List.rev (tm0::acc))
       | Some [x;y] ->
           if not (notConn x)
           then None (* not right-deep *)
           else aux (x::acc) y
       | Some juncts -> (* last one can have multiple juncts if no nesting *)
           if List.for_all notConn juncts
           then Some (List.rev acc @ juncts)
           else None) in 
    aux [] tm0


let mk_or_false_commute ts ts' or_l or_r = 
  let (Some(pf_tsf_ts, or_ts_f, or_ts)) = List.fold_right 
    (fun t -> function
       | None -> 
           let t_or_false = mkPfOr t (mkPfT Const.false_typ) in
           let iff = W (Exp_constr_app(Axioms._OrFalse, [stripPfT t], [], [])) in
             Some (iff, t_or_false, t)
       | Some (pf_iff, t'_or_false, t') -> 
           let iff = W (Exp_constr_app(Axioms._MonoOrIff, 
                                       List.map stripPfT [t'_or_false; t'; t], 
                                       [], [pf_iff])) in
             Some (iff, mkPfOr t t'_or_false, mkPfOr t t')) ts None in
  let or_ts_f, or_ts = stripPfT or_ts_f, stripPfT or_ts in
  let p123f, p123' = must (getTermJuncts "or" or_l), must (getTermJuncts "or" or_r) in
  let p123, _ = firstN (List.length p123') p123f in
    match termListBijection p123 p123', termListBijection p123' p123 with
      | Some bij, Some bij' -> 
          let (Some or_ts') = List.fold_right (fun t -> function 
                                                   None -> Some t
                                                 | Some t' -> Some(mkPfOr t t')) ts' None in
          let or_ts' = stripPfT or_ts' in
          let ts_imp_ts' = 
            Exp_constr_app(Axioms._ImpliesIntro, 
                           [or_ts; or_ts'], 
                           [], 
                           [fold_app_tapp (Theorems._Commute_Or bij) (List.map (fun t -> Inl (stripPfT t)) ts)]) in
          let ts'_imp_ts = 
            Exp_constr_app(Axioms._ImpliesIntro, 
                           [or_ts'; or_ts],
                           [], 
                           [fold_app_tapp (Theorems._Commute_Or bij') (List.map (fun t -> Inl (stripPfT t)) ts')]) in
          let pf_ts_ts' = 
            W (Exp_constr_app(Axioms._IffIntro, 
                              [or_ts; or_ts'], 
                              [], [W ts_imp_ts'; W ts'_imp_ts])) in
          let result = fold_app_tapp Theorems._Trans 
            [Inl or_ts_f; Inl or_ts; Inl or_ts'; Inr pf_tsf_ts; Inr pf_ts_ts']  in
            Some (Pf_exp result)
      | _ -> None
      
(*                                               *)
(*     (iff (or P1 ... Pn false) (or P1 ... Pn)) *)
(*                                               *)
let _Rw_OrPFalse_P_4 info = antes0 (fun tm ->
   match destructTerm "iff" tm with None -> None
     | Some [or_l; or_r] -> 
         let d = tm, A ("iff", [A ("or", [Tm "p1"; Tm "p2"; Tm "p3"; Tm "false"]); 
                                A ("or", [Tm "p1'"; Tm "p2'"; Tm "p3'"])]) in
           match patsToTyps info [d] ["p1";"p2";"p3";"p1'";"p2'";"p3'"] with 
             | None -> None 
             | Some [p1; p2; p3; p1'; p2'; p3'] -> 
                 mk_or_false_commute [p1;p2;p3] [p1';p2';p3'] or_l or_r)

(*                                               *)
(*     (iff (or P1 ... Pn false) (or P1 ... Pn)) *)
(*                                               *)
let _Rw_OrPFalse_P_3 info = antes0 (fun tm ->
   match destructTerm "iff" tm with None -> None
     | Some [or_l; or_r] -> 
         let d = tm, A ("iff", [A ("or", [Tm "p1"; Tm "p2"; Tm "false"]); 
                                A ("or", [Tm "p1'"; Tm "p2'"])]) in
           match patsToTyps info [d] ["p1";"p2";"p1'"; "p2'"] with 
             | None -> None 
             | Some [p1; p2; p1'; p2'] -> 
                 mk_or_false_commute [p1;p2] [p1';p2'] or_l or_r
)


(*                                               *)
(*     (iff (A => A) true )                      *)
(*                                               *)
let _Rw_OrImpAA_True info = antes0 (fun tm ->
  let d = tm, A ("iff", [A ("implies", [Tm "A"; Tm "A"]);
                         Tm "true"]) in
    match patsToTyps info [d] ["A"] with
      | None -> None 
      | Some [a] -> 
          let x = new_bvd None in
          let imp_a_a = mkImp a a in
          let true_t = Const.true_typ in
          let t_pf = W (Exp_constr_app(Axioms._T, [], [], [])) in
          let imp_l = 
            W (Exp_constr_app(Axioms._ImpliesIntro, 
                              [imp_a_a; true_t], 
                              [],
                              [mkExpAbs x (mkPfT imp_a_a) t_pf])) in
          let imp_a_a_pf = 
            W (Exp_constr_app(Axioms._IffElim1, 
                              [stripPfT a; stripPfT a],
                              [],
                              [W (Exp_tapp(Theorems._Refl, stripPfT a))])) in
          let imp_r = 
            W (Exp_constr_app(Axioms._ImpliesIntro, 
                              [true_t; imp_a_a], 
                              [],
                              [mkExpAbs x (mkPfT true_t) imp_a_a_pf])) in
          let pf = W (Exp_constr_app(Axioms._IffIntro, 
                                     [imp_a_a; true_t], 
                                     [], 
                                     [imp_l; imp_r])) in
            Some (Pf_exp pf))

let _Rw_AndABC_AndBCA info = antes0 (fun tm -> 
  let d = tm, A ("iff", [A ("and", [Tm "A"; A ("and", [Tm "B"; Tm "C"])]);
                         A ("and", [A ("and", [Tm "B"; Tm "C"]); Tm "A"])]) in
    match patsToTyps info [d] ["A";"B";"C"] with
      | None -> None 
      | Some [a;b;c] -> 
          let a = stripPfT a in
          let b_and_c = mkAnd b c in
          let l_typ = mkAnd (mkPfT a) (mkPfT b_and_c) in
          let r_typ = mkAnd (mkPfT b_and_c) (mkPfT a) in
          let imp_l = 
            W (Exp_constr_app(Axioms._ImpliesIntro, 
                              [l_typ; r_typ], 
                              [], 
                              [fold_app_tapp (Theorems._Commute_And [2;1]) [Inl a; Inl b_and_c]])) in
          let imp_r = 
            W (Exp_constr_app(Axioms._ImpliesIntro, 
                              [r_typ; l_typ], 
                              [], 
                              [fold_app_tapp (Theorems._Commute_And [2;1]) [Inl b_and_c; Inl a]])) in
          let pf = W (Exp_constr_app(Axioms._IffIntro, 
                                     [l_typ; r_typ], 
                                     [], 
                                     [imp_l; imp_r])) in
            Some (Pf_exp pf))



(*                               *)
(*     (iff (= t u) (= u t))     *)
(*                               *)
let _Rw_Eq info = antes0 (fun t ->
  let d = t, A ("iff", [A ("=", [Tm "t"; Tm "u"]); 
                        A ("=", [Tm "u"; Tm "t"])]) in
  match patsToExps info [d] ["t";"u"], termToIff info [] t with
    | Some [(e1, tii1);(e2, tii2)], Some goalTyp when tii1 = tii2 ->
        let es = List.map wrapSubpfExp [e1;e2] in
        let eqiffVar, t = ProofCombinators.lookupAxiomTii info Const.eqiff_lid tii1 in
          Some (Pf_fadc (eqiffVar, [t], es, goalTyp, 38))
    | _ -> None
)

(*                                       *)
(*     (iff (implies P Q) (or !P Q))     *)
(*                                       *)
let _Rw_IdImplies_1 info = antes0 (fun tm ->
  let d1 = tm, A ("iff", [A ("implies", [Tm "P"; Tm "Q"]);
                          A ("or", [Cmp "P"; Tm "Q"])]) in  
  match patsToTyps2 info [d1] ["Q"] ["P"], termToIff info [] tm with
    | Some ([tyQ],[flag,strippedTyP]), Some goalTyp ->
        Some (Pf_call (Theorems._Rewrite_IdImplies_1 flag, List.map stripPfT [strippedTyP;tyQ], [], goalTyp, 39))
    | _ -> None
)

(*                                       *)
(*     (iff (implies P Q) (or Q !P))     *)
(*                                       *)
let _Rw_IdImplies_2 info = antes0 (fun tm ->
  let d1 = tm, A ("iff", [A ("implies", [Tm "P"; Tm "Q"]);
                          A ("or", [Tm "Q"; Cmp "P"])]) in
  match patsToTyps2 info [d1] ["Q"] ["P"], termToIff info [] tm with
    | Some ([tyQ],[flag,strippedTyP]), Some goalTyp ->
        Some (Pf_call (Theorems._Rewrite_IdImplies_2 flag, List.map stripPfT [strippedTyP;tyQ], [], goalTyp, 40))
    | _ -> None
)

(*                               *)
(*     (iff (not (not P)) P)     *)
(*                               *)
let _Rw_DblNotElim info = antes0 (fun tm ->
  let d1 = tm, A ("iff", [A ("not", [A ("not", [Tm "P"])]); Tm "P"]) in
  match patsToTyps info [d1] ["P"], termToIff info [] tm with
    | Some [tyP], Some goalTyp ->
        Some (Pf_call (Theorems._Rewrite_DblNotElim, [stripPfT tyP], [], goalTyp, 41))
    | _ -> None
)

(*                                                      *)
(*     (iff (not (or p1 ... pn)) (and !p1 ... !pn))     *)
(*                                                      *)
let _Rw_DeMorganNotOr info = antes0 (fun tm ->
  (match destructTerm "iff" tm with Some [no;a] ->
  (match destructTerm "not" no, destructTerm "and" a with Some [o], Some l2 ->
  (match destructTerm "or" o with Some l1 ->
  (match termToIff info [] tm with Some goalTyp ->
     let flaglist = List.map isComplementTerm (List.zip l1 l2) in
     if existsNone flaglist then None
     else
       (match termsToStrippedTyps info l1 with Some strippedTyPs ->
          let flags = projSomes flaglist in
          let n = List.length l1 in
          Some (Pf_call (Theorems._Rewrite_DeMorgan_NotOr n flags, List.map stripPfT strippedTyPs, [], goalTyp, 42))
       | _ -> None)
  | _ -> None)
  | _ -> None)
  | _ -> None)
  | _ -> None)
)

(*                                                      *)
(*     (iff (and p1 ... pn) (not (or !p1 ... !pn)))     *)
(*                                                      *)
let _Rw_DeMorganAnd info = antes0 (fun tm ->
  (match destructTerm "iff" tm with Some [a;no] ->
  (match destructTerm "and" a, destructTerm "not" no with Some l1, Some [o] ->
  (match destructTerm "or" o with Some l2 ->
  (match termToAnd info [] a, termToNot info [] no with Some tyA, Some tyNo ->
  (match termToIff info [] tm with Some goalTyp ->
     (* treat the and arguments as the complements, since going to call the Rw_DeMorganNotOr above *)
     let flagopts = List.map isComplementTerm (List.zip l2 l1) in
     if existsNone flagopts then None
     else 
       (match termsToStrippedTyps info l2 with Some strippedTyPs ->
          let flags = projSomes flagopts in
          let n = List.length l1 in
          let e = mkCall1 (Theorems._Rewrite_DeMorgan_NotOr n flags) (List.map stripPfT strippedTyPs) [] in
          Some (Pf_call (Theorems._Symm, List.map stripPfT [tyNo;tyA], [wrapSubpfExp e], goalTyp, 43))
       | _ -> None)
  | _ -> None)
  | _ -> None)
  | _ -> None)
  | _ -> None)
  | _ -> None)
)


(*                                                      *)
(*     (iff (not (and p1 ... pn)) (or !p1 ... !pn))     *)
(*                                                      *)
let _Rw_DeMorganNotAnd info = antes0 (fun tm ->
  (match destructTerm "iff" tm with Some [na;o] ->
  (match destructTerm "not" na, destructTerm "or" o with Some [a], Some l2 ->
  (match destructTerm "and" a with Some l1 ->
  (match termToIff info [] tm with Some goalTyp ->
     let flagopts = List.map isComplementTerm (List.zip l1 l2) in
     if existsNone flagopts then None
     else
       (match termsToStrippedTyps info l1 with Some strippedTyPs ->
          let flags = projSomes flagopts in
          let n = List.length l1 in
          Some (Pf_call (Theorems._Rewrite_DeMorgan_NotAnd n flags, List.map stripPfT strippedTyPs, [], goalTyp, 44))
       | _ -> None)
  | _ -> None)
  | _ -> None)
  | _ -> None)
  | _ -> None)
)

(*                                                      *)
(*     (iff (or p1 ... pn) (not (and !p1 ... !pn)))     *)
(*                                                      *)
let _Rw_DeMorganOr info = antes0 (fun tm ->
  (match destructTerm "iff" tm with Some [o;na] ->
  (match destructTerm "or" o with Some l1 ->
  (match destructTerm "not" na with Some [a] ->
  (match destructTerm "and" a with Some l2 ->
  (match termToOr info [] o, termToNot info [] na with Some tyO, Some tyNa ->
  (match termToIff info [] tm with Some goalTyp ->
     (* treat the or arguments as the complements, since going to call the Rw_DeMorganNotAnd above *)
     let flagopts = List.map isComplementTerm (List.zip l2 l1) in
     if existsNone flagopts then None
     else 
       let flags = projSomes flagopts in
       let n = List.length l1 in
       (* TODO types *)
(*
       let e = mkCall2 (Theorems._Rewrite_DeMorgan_NotAnd n flags)
                        [] (mkPfIff tyNa tyO) in
*)
       let e = mkCall1 (Theorems._Rewrite_DeMorgan_NotAnd n flags) (List.map stripPfT []) [] in
(*
       Some (Pf_call (Theorems._Symm, List.map stripPfT [], [wrapSubpfExp e], goalTyp, 45))
*)
None
  | _ -> None)
  | _ -> None)
  | _ -> None)
  | _ -> None)
  | _ -> None)
  | _ -> None)
)



(*                                  *)
(*     (iff (or ...) (or ...))      *)
(*                                  *)

(*                                    *)
(*     (iff (and ...) (and ...))      *)
(*                                    *)

(* If both are right-deep, then termToConn will produce FStar types with the
   same right-deep structure. So no need to flatten before commuting.
   Note: once FlattenCommute is generalized, there won't be a need for
   this special case. *)
let _Rw_CommuteOnly info = antes0 (fun tm ->
  let doIt conn tm1 tm2 ty1 ty2 goalTyp =
    (match getTermJuncts conn tm1, getTermJuncts conn tm2 with Some l1, Some l2 ->
    (match termsToTyps info l1, termsToTyps info  l2 with Some tyPs1, Some tyPs2 ->
    (match termListBijection l1 l2 with Some bij ->
          (* TODO might have to debug this proof *)
          let ibij =
            try invertBijection bij
            with _ -> failwith (spr "not a bijection: [%s]" (String.concat " " (List.map soi bij))) 
          in
          let commute, uncommute =
            if conn = "or" then
              Theorems._Commute_Or bij,
              Theorems._Commute_Or ibij
            else
              Theorems._Commute_And bij,
              Theorems._Commute_And ibij
          in
          let ty1', ty2' = stripPfT ty1, stripPfT ty2 in
(* TODO types *)
          let fun1 = 
            let ((bvd,_),e) = mkFormDom "uncommutedArg" ty1 in
            mkExpAbs bvd ty1 (mkCall1 commute (List.map stripPfT tyPs1) [e]) in
          let fun2 =
            let ((bvd,_),e) = mkFormDom "commutedArg" ty2 in
            mkExpAbs bvd ty2 (mkCall1 uncommute (List.map stripPfT tyPs2) [e]) in
(*
let _ = List.iter (fun t -> pr "one: %s\n" (strTyp t)) (List.map stripPfT tyPs1) in
let _ = List.iter (fun t -> pr "two: %s\n" (strTyp t)) (List.map stripPfT tyPs2) in
*)
          let imp1 = mkDconApp Axioms._ImpliesIntro [ty1';ty2'] [fun1] in
          let imp2 = mkDconApp Axioms._ImpliesIntro [ty2';ty1'] [fun2] in
          Some (Pf_fadc (Axioms._IffIntro, [ty1';ty2'], List.map wrapSubpfExp [imp1;imp2], goalTyp, 0))
       | None -> None)
    | _ -> None)
    | _ -> None)
  in
  (match termToTyp info [] tm with Some goalTyp ->
  (match destructTerm "iff" tm with Some [x1;x2] ->
  (match termToTyp info [] x1, termToTyp info [] x2 with Some ty1, Some ty2 ->
  (match getAppSymbol x1, getAppSymbol x2 with
     | "or",  "or"  -> doIt "or"  x1 x2 ty1 ty2 goalTyp
     | "and", "and" -> doIt "and" x1 x2 ty1 ty2 goalTyp
     | _            -> None)
  | _ -> None)
  | _ -> None)
  | _ -> None)
)




type junctTree = Leaf of Term
               | Inner of junctTree list

let rec getJunctTree conn tm =
  match destructTerm conn tm with
    | None   -> Leaf tm
    | Some l -> Inner (List.map (getJunctTree conn) l)

let rec getDepth = function
  | Leaf _  -> 0
  | Inner l -> 1 + List.fold_left max 0 (List.map getDepth l)

let rec getJuncts = function
  | []            -> []
  | (Leaf tm)::tl -> tm :: (getJuncts tl)
  | (Inner l)::tl -> (getJuncts l) @ (getJuncts tl)


(*                                  *)
(*     (iff (or ...) (or ...))      *)
(*                                  *)

(*                                    *)
(*     (iff (and ...) (and ...))      *)
(*                                    *)

let _Rw_FlattenCommute info = antes0 (fun tm ->
  let doIt conn tm1 tm2 =
    let tree1, tree2 = getJunctTree conn tm1, getJunctTree conn tm2 in

    (* currently only handling one level of flattening *)
    if getDepth tree1 > 2 || getDepth tree2 <> 1 then None else

    (match termToTyp info [] tm1, termToTyp info [] tm2 with Some ty1, Some ty2 ->
    (match termToIff info [] tm with Some goalTyp ->
    (match tree1, tree2 with Inner l1, Inner l2 ->
    (match termListBijection (getJuncts l1) (getJuncts l2) with Some bij ->
    (match termsToTyps info (getJuncts l1) with Some tyPs ->
       let branchSizes = (* assuming depth of tree1 is <= 2 *)
         List.map (function Leaf _ -> 1 | Inner l -> List.length l) l1 in
       let commute, uncommute, flatten, unflatten =
         if conn = "or" then
           Theorems._Commute_Or bij,
           Theorems._Commute_Or (invertBijection bij),
           Theorems._Flatten_Or branchSizes,
           Theorems._Unflatten_Or branchSizes
         else
           Theorems._Commute_And bij,
           Theorems._Commute_And (invertBijection bij),
           Theorems._Flatten_And branchSizes,
           Theorems._Unflatten_And branchSizes
       in
       let ty1', ty2' = stripPfT ty1, stripPfT ty2 in
       let tyPs = List.map stripPfT tyPs in
       let reorderedTyPs = reorderList bij tyPs in
       let fun1 = 
         let ((bvd,_),e) = mkFormDom "nestedArg" ty1 in
         mkExpAbs bvd ty1 (mkCall1 commute tyPs [mkCall1 flatten tyPs [e]]) in
       let fun2 =
         let ((bvd,_),e) = mkFormDom "flattenedArg" ty2 in
         mkExpAbs bvd ty2 (mkCall1 unflatten tyPs(* reorderedTyPs *) [mkCall1 uncommute reorderedTyPs [e]]) in
       let imp1 = mkDconApp Axioms._ImpliesIntro [ty1';ty2'] [fun1] in
       let imp2 = mkDconApp Axioms._ImpliesIntro [ty2';ty1'] [fun2] in
       Some (Pf_fadc (Axioms._IffIntro, [ty1';ty2'], List.map wrapSubpfExp [imp1;imp2], goalTyp, 46))
    | _ -> None)
    | _ -> None)
    | _ -> None)
    | _ -> None)
    | _ -> None)
  in
  (match destructTerm "iff" tm with Some [x1;x2] ->
  (match getAppSymbol x1, getAppSymbol x2 with
     | "or",  "or"  -> doIt "or"  x1 x2
     | "and", "and" -> doIt "and" x1 x2
     | _            -> None)
  | _ -> None)
)





(*                                    *)
(*     (iff (or false false P) P)     *)
(*                                    *)
let _Rw_TEMP_OrFalseFalseP info = antes0 (fun tm ->
  let d = tm, A ("iff", [A ("or", [A ("false", []); A("false", []); Tm "P"]); Tm "P"]) in
  match patsToTyps info [d] ["P"], termToIff info [] tm with
    | Some [tyP], Some goalTyp ->
        Some (Pf_call (Theorems._TEMP_Rewrite_OrFalseFalseP, [stripPfT tyP], [], goalTyp, 0))
    | _ -> None
)

(*                                                   *)
(*     (iff (or A (or (or B C) D)) (or B C D A))     *)
(*                                                   *)
let _Rw_TEMP_1 info = antes0 (fun tm ->
  let d = tm, A ("iff", [A ("or", [Tm "A"; A ("or", [A ("or", [Tm "B"; Tm "C"]); Tm "D"])]);
                         A ("or", [Tm "B"; Tm "C"; Tm "D"; Tm "A"])]) in
  match patsToTyps info [d] ["A";"B";"C";"D"], termToIff info [] tm with
    | Some [tyA;tyB;tyC;tyD], Some goalTyp ->
        Some (Pf_call (Theorems._TEMP_Rewrite 1, List.map stripPfT [tyA;tyB;tyC;tyD], [], goalTyp, 0))
    | _ -> None
)

(*     (iff (or A false) A)     *)
let _Rw_TEMP_2 info = antes0 (fun tm ->
  let d = tm, A ("iff", [A ("or", [Tm "A"; A ("false", [])]); Tm "A"]) in
  match patsToTyps info [d] ["A"], termToIff info [] tm with
    | Some [tyA], Some goalTyp -> Some (Pf_call (Theorems._TEMP_Rewrite 2, [stripPfT tyA], [], goalTyp, 0))
    | _ -> None
)

(*     (iff (or true A B) true)     *)
let _Rw_TEMP_3 info = antes0 (fun tm ->
  let d = tm, A ("iff", [A ("or", [A ("true", []); Tm "A"; Tm "B"]); A ("true", [])]) in
  match patsToTyps info [d] ["A";"B"], termToIff info [] tm with
    | Some [tyA;tyB], Some goalTyp -> Some (Pf_call (Theorems._TEMP_Rewrite 3, List.map stripPfT [tyA;tyB], [], goalTyp, 0))
    | _ -> None
)

(*     (iff (and (or A B C) (not D)) (not (or D (not (or A B C)))))     *)
let _Rw_TEMP_4 info = antes0 (fun tm ->
  (match destructTerm "iff" tm with Some [x;y] ->
    let d1 = x, A ("and", [A ("or", [Tm "A"; Tm "B"; Tm "C"]); A ("not", [Tm "D"])]) in
    let d2 = y, A ("not", [A ("or", [Tm "D"; A ("not", [A ("or", [Tm "A"; Tm "B"; Tm "C"])])])]) in
    (match patsToTyps info [d1;d2] ["A";"B";"C";"D"], termToIff info [] tm with
       | Some [tyA;tyB;tyC;tyD], Some goalTyp ->
           Some (Pf_call (Theorems._TEMP_Rewrite 4, List.map stripPfT [tyA;tyB;tyC;tyD], [], goalTyp, 0))
       | _ -> None)
  | _ -> None)
)

(*     (iff (or A A B) (or A B)     *)
let _Rw_TEMP_5 info = antes0 (fun tm ->
  let d = tm, A ("iff", [A ("or", [Tm "A"; Tm "A"; Tm "B"]); A ("or", [Tm "A"; Tm "B"])]) in
  match patsToTyps info [d] ["A";"B"], termToIff info [] tm with
    | Some [tyA;tyB], Some goalTyp -> Some (Pf_call (Theorems._TEMP_Rewrite 5, List.map stripPfT [tyA;tyB], [], goalTyp, 0))
    | _ -> None
)

(*     (iff (or A A B) (or B A)     *)
let _Rw_TEMP_6 info = antes0 (fun tm ->
  let d = tm, A ("iff", [A ("or", [Tm "A"; Tm "A"; Tm "B"]); A ("or", [Tm "B"; Tm "A"])]) in
  match patsToTyps info [d] ["A";"B"], termToIff info [] tm with
    | Some [tyA;tyB], Some goalTyp -> Some (Pf_call (Theorems._TEMP_Rewrite 6, List.map stripPfT [tyA;tyB], [], goalTyp, 0))
    | _ -> None
)






(****************************************************************************)
(* [asserted]                                                               *)

let _Asserted info = antes0 (fun tm ->
  match ProofState.Extraction.bgAssumeOptOfTerm tm with 
   | Some aid -> (match aid with
       | AUser(i)         -> let li, t = ProofState.Extraction.userAxiom i in 
                             Some (Pf_exp (liToExp li))
       | ATupProj(tii,i)  -> Some(Pf_exp(tupleProjAxiom info tii i))
       | ATupEq(tii,i)    -> Some(Pf_exp(tupleEqAxiom info tii i))
       | ARecdProj(tii,i) -> Some (Pf_exp (liToExp (liDconRecdProj i tii)))
       | ARecdEq(tii,i)   -> Some (Pf_exp (liToExp (liDconRecdEq i tii)))
       | ANeqBool         -> Some (Pf_exp (liToExp liDconNeqBool))
       | ANeq(i,tii)      -> Some (Pf_exp (liToExp (liDconNeq i tii)))
       | AOther _         -> None (* TODO *)
       | _                -> failwith "_Asserted: bgAssumeTerm")
   | _ -> match ProofState.Extraction.fgAssumeOptOfTerm tm with 
   | Some aid -> (match aid with
           | ABindingVar i ->
               (match ProofState.Extraction.pfBinding i with 
                  | BarePf s -> Some (Pf_exp (idToExp (mkId s) dummyTyp))
                  | SndPf s -> Some (Pf_exp (mkProj2 (idToExp (mkId s) dummyTyp))))
           | ABindingMatch _ ->
               (match destructTerm "=" tm with Some [tm1;tm2] ->
               (match termToExp info [] tm1, termToExp info [] tm2 with
                  | Some(e1, tii1), Some(e2, tii2) when tii1 = tii2 ->
                      let eqT  = ProofCombinators.eqtypOfSort info tii1 in
                      let reflVar, t = ProofCombinators.lookupAxiomTii info Const.reflexivity_lid tii1 in
                      let rawE = mkDconApp reflVar [t] [e1] in
                      let ascT = mkPfEq eqT e1 e2 in
                      Some (Pf_exp (mkExp (Exp_ascribed (rawE, ascT, []))))
                  | _ -> None)
               | _ -> failwith "_Asserted: ABindingMatch")
           | _ -> failwith "_Asserted: fgAssumeTerm")
  | _ -> 
    match !negGoalTerm with
      | Some(x) when x = tm -> Some (Pf_exp !negGoalExp)
      | _  -> 
          match !goalVar with 
              Some p when p = tm -> Some(Pf_exp (!negGoalExp))
            | _ -> (pr "didn't find asserted term\n"; None))
                


(****************************************************************************)
(* [lemma] + [hypothesis]                                                   *)
let _Hypothesis  info = antes0 (fun f ->
  (match termToTyp info [] f with Some tyHypo -> begin
     let pi, fi = !curProofId, !curGoalId in
     let s = spr "hypo_p%d_f%d" pi fi in
     let ((bvdHypo,tyHypo),expHypo) = mkFormDomFixed s tyHypo in
     Ht.add hypotheses pi (f,bvdHypo,tyHypo,expHypo);
     Some (Pf_string s)
   end
  | _ -> None)
)



(* TODO abstract all lemma matching and theorems after the PLDI deadline *)

(* for hypos like (not A), and (A) in lemma *)
let findHypoFormDom tm =
  Ht.fold (fun _ (hypotm,bv,ty,_) acc ->
    (match destructTerm "not" hypotm with
       | Some [x] when x = tm -> Some(bv,ty)
       | _ -> acc)
  ) hypotheses None

(* for hypos like (A), and (not A) in lemma *)
let findHypoFormDom2 tm = 
  Ht.fold (fun _ (hypotm,bv,ty,_) acc -> if hypotm = tm then Some(bv,ty) else acc) hypotheses None
  

(*     A => false |= (not A)     *) 
let _Lemma_1_0 info = antes1 (fun tm1 tm2 ->
  (match destructTerm "false" (proofToFormula tm1) with Some [] ->
  (match destructTerm "not" tm2 with Some [a] ->
  (match findHypoFormDom2 a with Some (bvHypoNotA,tyHypoNotA) ->
  (match termToTyp info [] a with Some tyA ->
     let proofBody = proofTermToProofExp tm1 in
     let proofFun = mkExpAbs bvHypoNotA tyHypoNotA proofBody in
     Some (Pf_call (Theorems._Lemma_1_0, [stripPfT tyA], [wrapSubpfExp proofFun], tyA, 0))
  | _ -> None)
  | _ -> None)
  | _ -> None)
  | _ -> None)
)

(*     (not A) => false |= A     *) 
let _Lemma_1_1 info = antes1 (fun tm1 tm2 ->
  (match destructTerm "false" (proofToFormula tm1) with Some [] ->
  (match findHypoFormDom tm2 with Some (bvHypoNotA,tyHypoNotA) ->
  (match termToTyp info [] tm2 with Some tyA ->
     let proofBody = proofTermToProofExp tm1 in
     let proofFun = mkExpAbs bvHypoNotA tyHypoNotA proofBody in
     Some (Pf_call (Theorems._Lemma_1_1, [stripPfT tyA], [wrapSubpfExp proofFun], tyA, 0))
  | _ -> None)
  | _ -> None)
  | _ -> None)
)

(*     (and A (not B)) => false |= (or (not A) B)     *)
let _Lemma_2_01 info = antes1 (fun tm1 tm2 ->
  (match destructTerm "false" (proofToFormula tm1) with Some [] ->
  (match destructTerm "or" tm2 with Some [na;b] ->
  (match destructTerm "not" na with Some [a] ->
  (match findHypoFormDom2 a with Some (bvHypoA,tyHypoA) ->
  (match findHypoFormDom b with Some (bvHypoNotB,tyHypoNotB) ->
  (match termToTyp info [] a, termToTyp info [] b, termToTyp info [] tm2 with Some tyA, Some tyB, Some tyGoal ->
     let proofBody = proofTermToProofExp tm1 in
     let proofFun = (mkExpAbs bvHypoA tyHypoA
                    (mkExpAbs bvHypoNotB tyHypoNotB proofBody)) in
     Some (Pf_call (Theorems._Lemma_2_01, [stripPfT tyA; stripPfT tyB], [wrapSubpfExp proofFun], tyGoal, 0))
  | _ -> None)
  | _ -> None)
  | _ -> None)
  | _ -> None)
  | _ -> None)
  | _ -> None)
)

(*     (and (not A) (not B)) => false |= (or A B)     *)
let _Lemma_2_11 info = antes1 (fun tm1 tm2 ->
  (match destructTerm "false" (proofToFormula tm1) with Some [] ->
  (match destructTerm "or" tm2 with Some [a;b] ->
  (match findHypoFormDom a with Some (bvHypoNotA,tyHypoNotA) ->
  (match findHypoFormDom b with Some (bvHypoNotB,tyHypoNotB) ->
  (match termToTyp info [] a, termToTyp info [] b, termToTyp info [] tm2 with Some tyA, Some tyB, Some tyGoal ->
     let proofBody = proofTermToProofExp tm1 in
     let proofFun = (mkExpAbs bvHypoNotA tyHypoNotA
                    (mkExpAbs bvHypoNotB tyHypoNotB proofBody)) in
     Some (Pf_call (Theorems._Lemma_2_11, [stripPfT tyA; stripPfT tyB], [wrapSubpfExp proofFun], tyGoal, 0))
  | _ -> None)
  | _ -> None)
  | _ -> None)
  | _ -> None)
  | _ -> None)
)

(*     (and (not A) B (not C)) => false |= (or A (not B) C)     *) 
let _Lemma_3_101 info = antes1 (fun tm1 tm2 ->
  (match destructTerm "false" (proofToFormula tm1) with Some [] ->
  (match destructTerm "or" tm2 with Some [a;nb;c] ->
  (match destructTerm "not" nb with Some [b] ->
  (match findHypoFormDom a with Some (bvHypoNotA,tyHypoNotA) ->
  (match findHypoFormDom2 b with Some (bvHypoB,tyHypoB) ->
  (match findHypoFormDom c with Some (bvHypoNotC,tyHypoNotC) ->
  (match termToTyp info [] a, termToTyp info [] b, termToTyp info [] c, termToTyp info [] tm2 with Some tyA, Some tyB, Some tyC, Some tyGoal ->
     let proofBody = proofTermToProofExp tm1 in
     let proofFun = (mkExpAbs bvHypoNotA tyHypoNotA
                    (mkExpAbs bvHypoB tyHypoB
                    (mkExpAbs bvHypoNotC tyHypoNotC proofBody))) in
     Some (Pf_call (Theorems._Lemma_3_101, [stripPfT tyA; stripPfT tyB; stripPfT tyC], [wrapSubpfExp proofFun], tyGoal, 0))
  | _ -> None)
  | _ -> None)
  | _ -> None)
  | _ -> None)
  | _ -> None)
  | _ -> None)
  | _ -> None)
)












(****************************************************************************)
(* [quant-inst]                                                             *)

(* TODO revisit *)
exception FoundActual of exp

(* given t2 = t1[t'/formal], find t'. *) 
let findActual t1 t2 formalName =

  let rec fE (e1,e2) = match (e1.v, e2.v) with
    | Exp_bvar(x), _ when (bvar_real_name x).idText = formalName ->
        raise (FoundActual e2)
    | Exp_bvar(x), _ -> ()
    | Exp_fvar(x, _), Exp_fvar(y, _) when sli x.v = sli y.v -> ()
    | Exp_constr_app(_,ts1,_,es1), Exp_constr_app(_,ts2,_,es2) ->
        (List.iter fT (List.zip ts1 ts2); List.iter fE (List.zip es1 es2))
(* TODO recd *)
    | Exp_recd(_,_,_,l1), Exp_recd(_,_,_,l2) ->
        let es, fs = List.map snd l1, List.map snd l2 in
        List.iter fE (List.zip es fs)
    | Exp_proj(f1,_), Exp_proj(f2,_) -> fE (f1,f2)
    | _ ->
        failwith (spr "findActual fE %s:\n\n%s\n\n%s" formalName
          (Pretty.strExp e1) (Pretty.strExp e2))

  and fT (t1,t2) = match (t1.v, t2.v) with
    | Typ_const(x, _), Typ_const(y, _) when sli x.v = sli y.v -> ()
    | Typ_app(u1,u2), Typ_app(v1,v2) -> (fT (u1,v1); fT (u2,v2))
    | Typ_dep(u1,e1), Typ_dep(u2,e2) -> (fT (u1,u2); fE (e1,e2))
    | _ ->
        failwith (spr "findActual fT %s:\n\n%s\n\n%s" formalName
          (Pretty.strTyp t1) (Pretty.strTyp t2)) in
  try
    begin
      fT (t1,t2);
      failwith (spr "findActual didn't find actual %s\n\n%s\n\n%s\n"
        formalName (Pretty.strTyp t1) (Pretty.strTyp t2))
    end
  with FoundActual e -> e
  

(*                                                                       *)
(*     (or (not (forall (xn ... x1) (Q x1 ... xn))) (Q x1' ... xn'))     *)
(*                                                                       *)
let _QuantInst info = antes0 (fun tm ->

  let genTerm notforall forall forsome goalTyp =

    let tyA = stripPfT notforall in
    let tyC = stripPfT goalTyp in

    let formsdoms, range = getFormalsDomainsRangeOfArrow (stripPfT forall) in
    let formals, domains = List.split formsdoms in
    let actuals = List.map (findActual range (stripPfT forsome)) formals in
    let n = List.length actuals in

    let tyP1 = 
      let rec tyP i =
        if i = n+1 then range else
          let formal = List.nth formals (i-1) in
          let actual = List.nth actuals (i-1) in
          substitute_exp (tyP (i+1)) (mkbvd(mkId formal, mkId formal)) actual
      in tyP 1 in

    let cacheTyB = Ht.create "cacheTyB" soi in
    let rec tyB i =
      if Ht.mem cacheTyB i
        then Ht.find cacheTyB i
        else begin
          let res =
            if i = n then stripPfT forall else
              (match (tyB (i+1)).v with Typ_fun(_,_,ttt) ->
                 let formal = List.nth formals i in
                 let actual = List.nth actuals i in
                 substitute_exp (stripPfT ttt) (mkbvd(mkId formal, mkId formal)) actual
              | _ -> failwith "matchQuantInst: tyB") in
          Ht.add cacheTyB i res;
          res
        end in

    let ((bva,_),ea) = mkFormDom "a" (mkPfT tyA) in
    let ((bvb,_),eb) = mkFormDom "b" (mkPfT (tyB n)) in

    let exc = mkTagDconApp 1 Axioms._ExcMiddle [tyB n] [] in

    let imp1 =
      mkTagDconApp 11 Axioms._ImpliesIntro
        [tyA; tyC]
        [mkTagExp 2 (Exp_abs (bva, mkPfT tyA,
                              mkTagDconApp 3 Axioms._OrIntro1
                                             [tyA; tyP1]
                                             [ea]))] in

    let y1 =
      let rec y i =
        let prev = if i = n then eb else y (i+1) in
        let resType = if i = 1 then tyP1 else tyB (i-1) in
        let ((bvz,_),ez) = mkFormDom (spr "z%d" i) (tyB i) in
        let actual = List.nth actuals (i-1) in
        mkTagDconApp 4 Axioms._BindPf
          [tyB i; resType]
          [prev; mkTagExp 5 (Exp_abs (bvz, tyB i,
                                      mkTagExp 6 (Exp_app (ez, actual))))]
      in y 1 in

    let imp2 =
      mkTagDconApp 7 Axioms._ImpliesIntro
        [tyB n; tyC]
        [mkTagExp 8 (Exp_abs (bvb, mkPfT (tyB n),
                              mkTagDconApp 9 Axioms._OrIntro2
                                [tyP1; tyA]
                                [y1]))] in

    Some (Pf_fadc (Axioms._OrElim, [tyA; tyB n; tyC],
                  List.map wrapSubpfExp [exc; imp1; imp2],
                  goalTyp, 10))
    
  in
  (match destructTerm "or" tm with Some [np;p0] ->
  (match destructTerm "not" np with Some [p] when isQuantTerm p ->
  (match termToTyp info [] np, termToTyp info [] p, termToTyp info [] p0, termToTyp info [] tm with
     | Some notforall, Some forall, Some forsome, Some goalTyp ->
         genTerm notforall forall forsome goalTyp
     | _ -> None)
  | _ -> None)
  | _ -> None)
)

(*                                                                          *)
(*     1: (or (not (forall (xn ... x1)) (P x1 ... xn)) (P x1' ... xn'))     *)
(*     2: (forall (xn ... x1) (P x1 ... xn))                                *)
(*     ----------------------------------------------------------------     *)
(*                                 P x1' ... xn'                            *)
(*                                                                          *)
let _UnitResQuantInst info = antes2 (fun p1 p2 g ->
  let f1, f2 = proofToFormula p1, proofToFormula p2 in
  (match destructTerm "or" f1 with Some [np;q] when q = g ->
  (match destructTerm "not" np with Some [p] ->
     if not (isQuantTerm p) || not (isQuantTerm f2) then None
     else if getQuantBody p <> getQuantBody f2 then None
     else
       (match termToTyp info [] p, termToTyp info [] g with
          | Some tyP, Some goalTyp ->
              let ur = Theorems._UnitRes 2 1 [true] in
              Some (Pf_call (ur, List.map stripPfT [tyP;goalTyp], List.map wrapSubpf [p1;p2], goalTyp, 48))
          | _ -> None)
  | _ -> None)
  | _ -> None)
)


(****************************************************************************)
(* [quant-intro] and [nnf-pos]                                              *)

(* TODO revisit *)

(* generalizeE zs e (resp. generalizeT z t) returns e (resp. t) with
   all occurrences of Exp_gvar #0 replaced with (nth zs 0),
   all occurrences of Exp_gvar #1 replaced with (nth zs 1), ...,
   all occurrences of Exp_gvar #(n-1) replaced with (nth zs (len zs - 1)),
   and all other occurrences Exp_gvar #i with Exp_gvar #(i-n).
 *)
let rec generalizeE zs e = { e with v = generalizeE' zs e.v }

and generalizeE' zs = function
  | Exp_gvar(i)        -> let n = List.length zs in
                          if i < n then List.nth zs i else Exp_gvar(i-n)
  | Exp_abs(bvd,t,e1)  -> Exp_abs (bvd, generalizeT zs t, generalizeE zs e1)
  | Exp_app(e1,e2)     -> Exp_app (generalizeE zs e1, generalizeE zs e2)
  | Exp_tapp(e,t)      -> Exp_tapp (generalizeE zs e, generalizeT zs t)
  | Exp_ascribed(e,t,l)-> Exp_ascribed (generalizeE zs e, generalizeT zs t, l)
  | Exp_proj(e1,fn)    -> Exp_proj (generalizeE zs e1, fn)
(* TODO recd *)
  | Exp_recd(a,b,c,l)  -> let fields, es = List.split l in
                          let es' = List.map (generalizeE zs) es in
                          Exp_recd (a, b, c, List.zip fields es')
  | Exp_bvar _ as e'   -> e'
  | Exp_fvar _ as e'   -> e' 
  | Exp_bot as e'      -> e'
  | Exp_constant _ as e'  -> e'
  | Exp_constr_app(x,ts,_,es) ->
      let ts' = List.map (generalizeT zs) ts in
      let es' = List.map (generalizeE zs) es in
      Exp_constr_app (x, ts', [], es')
  | e' -> failwith (spr "generalizeE: %s" (Pretty.strExp (ewithsort e' dummyTyp)))

and generalizeT zs t = { t with v = generalizeT' zs t.v }

and generalizeT' zs = function
  | Typ_const(x, eref)       -> Typ_const(x, eref)
  | Typ_fun(o,t1,t2)   -> Typ_fun (o, generalizeT zs t1, generalizeT zs t2)
  | Typ_app(t1,t2)     -> Typ_app (generalizeT zs t1, generalizeT zs t2)
  | Typ_dep(t,e)       -> Typ_dep (generalizeT zs t, generalizeE zs e)
  | Typ_record(l,_ig)      -> let fields, ts = List.split l in
                          let ts' = List.map (generalizeT zs) ts in
                          Typ_record (List.zip fields ts', _ig)
  | Typ_dtuple(l)      -> let bvdefopts, ts = List.split l in
                          let ts' = List.map (generalizeT zs) ts in
                          Typ_dtuple (List.zip bvdefopts ts')
  | t' -> failwith (spr "generalizeT: %s" (Pretty.strTyp (twithsort t' Kind_unknown)))
  

let doQuantIntroProof tm1 tm2 tyT1 tyT2 goalTyp (quant:Quantifier) =

  let names =
    List.map
      (fun (a:Symbol) -> (!z3).GetSymbolString a)
      (Array.to_list quant.Names) in
  let n = List.length names in

  let bvddoms = List.rev (List.map (must -<- ProofState.Z3Symbols.binderOptOfSym) names) in 
  let exp_xis = List.map (fun (bvd,dom) -> bvdToExp bvd dom) bvddoms in
  let bvds, doms = List.split bvddoms in

  let rec stripKArrows n t =
    if n = 0 then stripPfT t
    else
      match t.v with
        | Typ_app(t1,t2) ->
            (match t1.v, t2.v with
              | Typ_const(x,_), Typ_fun(_,_,t')
                    when Sugar.lid_equals x.v Const.pf_lid ->
                  stripKArrows (n-1) t'
              | _ -> failwith (spr "stripKArrows [1] %d %s" n (Pretty.strTyp t)))
        | _ -> failwith (spr "stripKArrows [2] %d %s" n (Pretty.strTyp t))
  in

  let subpf =
    let bvars = List.map (fun bvd -> Exp_bvar (bvd_to_bvar bvd)) bvds in
    generalizeE bvars (proofTermToProofExp tm1) in

  let u_p i = stripKArrows (n-i-1) tyT1 in

  let u_q i = stripKArrows (n-i-1) tyT2 in

  (* TODO use mkExpApp *)

  let rec pf_ab s u_a u_b i =
    if i = -1 then
      (* TODO ugly *)
      let dc = if s = "1" then Axioms._IffElim1 else Axioms._IffElim2 in
      mkDconApp dc [u_p (-1); u_q (-1)] [subpf]
    else begin
      let bvd_foo = mkbvd(mkId (spr "foo%d" i), genident None) in
      let bvd_goo = mkbvd(mkId (spr "goo%d" i), genident None) in
      let bvd_xi  = List.nth bvds i in
      let exp_foo = bvdToExp bvd_foo (mkPfT (u_a i)) in
      let exp_goo = bvdToExp bvd_goo (u_a i) in
      let exp_xi  = List.nth exp_xis i in
      let bind_tm =
        mkDconApp Axioms._BindPf
          [u_a i; u_a (i-1)]
          [exp_foo; mkExp (Exp_abs (bvd_goo, u_a i,
                           mkExp (Exp_app (exp_goo, exp_xi))))] in
      let mp_tm =
        mkDconApp Axioms._ModusPonens
          [u_a (i-1); u_b (i-1)]
          [bind_tm; pf_ab s u_a u_b (i-1)] in
      let lift_tm =
        mkDconApp Axioms._LiftPf
          [u_b i]
          [mkExp (Exp_abs (bvd_xi, List.nth doms i, mp_tm))] in
      let implies_tm =
        mkDconApp Axioms._ImpliesIntro
          [u_a i; u_b i]
          [mkExp (Exp_abs (bvd_foo, mkPfT (u_a i), lift_tm))] in
      implies_tm
    end
  in

  let pfs = [pf_ab "1" u_p u_q (n-1); pf_ab "2" u_q u_p (n-1)] in

  Pf_fadc (Axioms._IffIntro, [u_p (n-1); u_q (n-1)],
           List.map wrapSubpfExp pfs, goalTyp, 0)


let _QuantIntro info  = antes1 (fun tm1 tm2 ->
  let f1 = proofToFormula tm1 in
  (match destructTerm "iff" f1, destructTerm "iff" tm2 with
     | Some [_;_], Some [t1;t2] when isQuantTerm t1 && isQuantTerm t2 ->
         (match termToTyp info [] t1, termToTyp info [] t2, termToTyp info [] tm2 with
            | Some tyT1, Some tyT2, Some goalTyp ->
                let quant = (!z3).GetQuantifier t1 in
                if not quant.IsForall then None
                else Some (doQuantIntroProof tm1 tm2 tyT1 tyT2 goalTyp quant)
            | _ -> None)
     | _ -> None)
)

(*
let _NnfPos = antes1 (fun tm1 tm2 -> 
  let f1 = proofToFormula tm1 in
  (match destructTerm "~" f1, destructTerm "~" tm2 with
     | Some [_;_], Some [t1;t2] when isQuantTerm t1 && isQuantTerm t2 ->
         (match termToTyp [] t1, termToTyp [] t2, termToTyp [] tm2 with
            | Some tyT1, Some tyT2, Some goalTyp ->
                let quant = (!z3).GetQuantifier t1 in
                if not quant.IsForall then None
                else Some (doQuantIntroProof tm1 tm2 tyT1 tyT2 goalTyp quant)
            | _ -> None)
     | _ -> None)
)
*)

(*                 *)
(*       ...       *)
(*     -------     *)
(*     (~ P P)     *)
(*                 *)
let _NnfPos_Ignore info = antes1 (fun tm1 tm2 ->
  let d = tm2, A ("~", [Tm "P"; Tm "P"]) in
  if pats info [d] then Some (Pf_string "ignore nnf-pos~") else None
)

let _NnfPos info = antes1 (fun tm1 tm2 ->
  None
)

(*                                    *)
(*   A1: (not P1) ~ S1                *)
(*   A2: (not P2) ~ S2                *)
(*   -------------------------------- *)
(*     not (and P1 P2) ~ (or S1 S2)   *)
(*                                    *)
(* Translation strategy:
   First use DemorganNotAnd to get 
      (not (and P1 P2)) ~ (or (not P1) (not P2))
   Then use MonoOr to get  (or S1 S2)
   If neither A1 or A2 are [sk], we're done *)
let _NnfNeg info = antes2 (fun a1 a2 g -> 
  match destructTerm "sk" a1 with Some _ -> None | None -> 
  match destructTerm "sk" a2 with  Some _ -> None | None -> 
    let _, a1g = antecedentsAndGoal a1 in
    let _, a2g = antecedentsAndGoal a2 in
  match destructTerm "~" a1g with None -> None | Some [not_p1; s1] -> 
  match destructTerm "not" not_p1 with None -> None | Some [p1] -> 
  match destructTerm "~" a2g with None -> None | Some [not_p2; s2] -> 
  match destructTerm "not" not_p2 with None -> None | Some [p2] -> 
  match destructTerm "~" g with None -> None | Some [na_p1p2; or_s1s2] -> 
    let p1_typ = must (termToTyp info [] p1) in
    let p2_typ = must (termToTyp info [] p2) in
    let s1_typ = must (termToTyp info [] s1) in
    let s2_typ = must (termToTyp info [] s2) in
    let lhs_typ = mkPfNot (mkPfAnd p1_typ p2_typ) in
    let dm_typ = mkPfOr (mkPfNot p1_typ) (mkPfNot p2_typ) in
    let _ = pr "p1_typ=%s\n p2_typ=%s\n s1_typ=%s\ns2_typ=%s\n" (Pretty.strTyp p1_typ)
      (Pretty.strTyp p2_typ) (Pretty.strTyp s1_typ) (Pretty.strTyp s2_typ) in
    let ((lhs_bvd,_), lhs_exp) = mkFormDom "lhs" lhs_typ in
    let dm_step =                
      Exp_constr_app(Axioms._DeMorganNotAnd, [stripPfT p1_typ; stripPfT p2_typ], [], [lhs_exp]) in
    let ((dm_bvd, _), dm_exp) = mkFormDom "dm" dm_typ in
    let a1_proof, a1_rhs_typ = proofTermToProofExp a1, s1_typ in      
    let a2_proof, a2_rhs_typ = proofTermToProofExp a2, s2_typ in
    let mono_typ = mkPfOr a1_rhs_typ a2_rhs_typ in
    let mono_step = 
      Exp_constr_app(Axioms._MonoOr, 
                     [mkPfNot p1_typ; mkPfNot p2_typ; a1_rhs_typ; a2_rhs_typ], 
                     [],
                     [dm_exp; a1_proof; a2_proof]) in
    let imp = 
      mkExpAbs lhs_bvd lhs_typ
        (W (Exp_let (false, [dm_bvd, dm_typ, W dm_step], W mono_step))) in
      Some (Pf_fadc_asc(Axioms._ImpliesIntro,
                        List.map stripPfT [lhs_typ; mono_typ],
                        [Subpf_exp imp],
                        mkPfImp lhs_typ mono_typ, 0)))
(* NnfNegSK_2 *)
(*                                    *)
(*   A1: (not P1) ~ S1                *)
(*   A2: (not P2) ~ S2                *)
(*   -------------------------------- *)
(*     not (and P1 P2) ~ (or S1 S2)   *)
(*                                    *)
(* Translation strategy:
   First use DemorganNotAnd to get 
      (not (and P1 P2)) ~ (or (not P1) (not P2))
   Then use MonoOr to get  (or S1 S2)

   A2 is a [sk], so we have
      (or S1 (exists x. not S2' x))
   Use PullQuantOrE to get
      exists x. (or  S1 (not S2' x))
   and register this as a skolem package to unpack
   and put in a trivial implication at this step
*)
let _NnfNegSK_2 info = antes2 (fun a1 a2 g -> 
  match destructTerm "sk" a1 with Some _ -> None | None -> 
  match destructTerm "sk" a2 with None -> None | Some _ -> 
    let _, a1g = antecedentsAndGoal a1 in
    let _, a2g = antecedentsAndGoal a2 in
  match destructTerm "~" a1g with None -> None | Some [not_p1; s1] -> 
  match destructTerm "not" not_p1 with None -> None | Some [p1] -> 
  match destructTerm "~" a2g with None -> None | Some [not_p2; s2] -> 
  match destructTerm "not" not_p2 with None -> None | Some [p2] -> 
  match destructTerm "~" g with None -> None | Some [na_p1p2; or_s1s2] -> 
    let p1_typ = must (termToTyp info [] p1) in
    let p2_typ = must (termToTyp info [] p2) in
    let s1_typ = must (termToTyp info [] s1) in
    let s2_typ = must (termToTyp info [] s2) in
    let lhs_typ = mkPfNot (mkPfAnd p1_typ p2_typ) in
    let dm_typ = mkPfOr (mkPfNot p1_typ) (mkPfNot p2_typ) in
(*     let _ = pr "p1_typ=%s\n p2_typ=%s\n s1_typ=%s\ns2_typ=%s\n" (Pretty.strTyp p1_typ) *)
(*       (Pretty.strTyp p2_typ) (Pretty.strTyp s1_typ) (Pretty.strTyp s2_typ) in *)
    let ((lhs_bvd,_), lhs_exp) = mkFormDom "lhs" lhs_typ in
    let dm_step =                
      Exp_constr_app(Axioms._DeMorganNotAnd, [stripPfT p1_typ; stripPfT p2_typ], [], [lhs_exp]) in
    let ((dm_bvd, _), dm_exp) = mkFormDom "dm" dm_typ in
    let a1_proof, a1_rhs_typ = proofTermToProofExp a1, s1_typ in      
    let a2_id = ProofState.Extraction.idOfTerm a2 in 
    let _ = if not (Ht.mem skolemPackages a2_id) then raise (Never "Unregistered skolem package in NnfNeg-Sk2") in
      (* if a2 is an sk step, then the proof step for a2_id is just a dummy *)
      (* need to get the real proof step from the registered skolemPackages *)
    let {sksym=skolemSym; eqsat_pf=skolem_step; 
         ex_typ=ex_t; ex_typ_1=a_targ; ex_typ_2=ex_body_t;
         ante_typ=antecedent_t; mp_eq=None} = Ht.find skolemPackages a2_id in
    let _ = Ht.remove skolemPackages a2_id in
    let a2_proof, ex_var, a2_rhs_typ = match ex_t.v with 
      | Typ_dtuple [(Some ex_var, _); _] -> skolem_step, ex_var, ex_t 
      | _ -> raise (Never "Unexpected non-existential package in skolemPackages") in
    let mono_typ = mkPfOr a1_rhs_typ (mkPfT a2_rhs_typ) in (* Or S1 (exists x. not S2' x) *)
    let mono_step = 
      Exp_constr_app(Axioms._MonoOr, 
                     [mkNot p1_typ; mkNot p2_typ; stripPfT a1_rhs_typ; a2_rhs_typ], 
                     [],
                     [W dm_exp.v; W a1_proof.v; W a2_proof.v]) in
    let ((mono_bvd, _), mono_exp) = mkFormDom "mono" mono_typ in
    let pq_body_typ = mkPfOr a1_rhs_typ ex_body_t in
    let pq_typ = Wt (Typ_dtuple([(Some ex_var, a_targ);
                                 (None, pq_body_typ)])) in
(*     let _ = pr "a_targ=%s\na2_rhs_typ=%s\n mono_typ=%s\n pq_typ=%s\nex_body_t=%s\n"  *)
(*       (Pretty.strTyp a_targ) (Pretty.strTyp a2_rhs_typ) *)
(*       (Pretty.strTyp mono_typ) (Pretty.strTyp pq_typ)  *)
(*       (Pretty.strTyp ex_body_t) in *)
    let pq_step =  Exp_constr_app(Axioms._PullQuantOrE, 
                                  [a_targ; stripPfT a1_rhs_typ; Wt (Typ_lam(ex_var, a_targ, stripPfT ex_body_t))], 
                                  [],
                                  [mono_exp]) in
    let imp = 
      mkExpAbs lhs_bvd lhs_typ
        (W (Exp_let (false, [dm_bvd, dm_typ, W dm_step], 
                     W (Exp_let(false, [mono_bvd, mono_typ, W mono_step], W pq_step))))) in
    let pf = Exp_constr_app(Axioms._ImpliesIntro, [stripPfT lhs_typ; pq_typ], [], [imp]) in
    let _ = Ht.add skolemPackages !curProofId {sksym=skolemSym;
                                               eqsat_pf=W pf;
                                               ex_typ=pq_typ;
                                               ex_typ_1=a_targ;
                                               ex_typ_2=pq_body_typ;
                                               ante_typ=lhs_typ;
                                               mp_eq=None} in
      (* Make a trivial proof step here. The real step happens with an unpack at the top of the proof *)
    let fun1 =
      let ((bvd,_),_) = mkFormDom "nnfnegSk2" lhs_typ in
        mkExpAbs bvd lhs_typ (skolemSymToProofExp skolemSym) in
      Some (Pf_exp(W (Exp_constr_app(Axioms._ImpliesIntro, 
                                     List.map stripPfT [lhs_typ; pq_body_typ],
                                     [],
                                     [fun1])))))

(* NnfNegSK_1 *)
(*                                    *)
(*   A1: (not P1) ~ S1                *)
(*   A2: (not P2) ~ S2                *)
(*   -------------------------------- *)
(*     not (and P1 P2) ~ (or S1 S2)   *)
(*                                    *)
(* Translation strategy:
   First use DemorganNotAnd to get 
      (not (and P1 P2)) ~ (or (not P1) (not P2))
   Then use MonoOr to get  (or S1 S2)

   A1 is [sk], then we have
      (or (exists x. not S1' x) S2)
   Use _Commute_Or_2_12 to get 
      (or S2 (exists x. not S1' x))
   Use PullQuantOrE to get
      exists x. (or  S2 (not S1' x))
   and register this as a skolem package to unpack
   And put an implication with _Commute_Or_2_12 at this step
*)
let _NnfNegSK_1 info = antes2 (fun a1 a2 g -> 
  match destructTerm "sk" a1 with      None -> None | Some _ -> 
  match destructTerm "sk" a2 with    Some _ -> None | None -> 
    let _, a1g = antecedentsAndGoal a1 in
    let _, a2g = antecedentsAndGoal a2 in
  match destructTerm "~" a1g with      None -> None | Some [not_p1; s1] -> 
  match destructTerm "not" not_p1 with None -> None | Some [p1] -> 
  match destructTerm "~" a2g with      None -> None | Some [not_p2; s2] -> 
  match destructTerm "not" not_p2 with None -> None | Some [p2] -> 
  match destructTerm "~" g with        None -> None | Some [na_p1p2; or_s1s2] -> 
    let p1_typ = must (termToTyp info [] p1) in
    let p2_typ = must (termToTyp info [] p2) in
    let s1_typ = must (termToTyp info [] s1) in
    let s2_typ = must (termToTyp info [] s2) in
    let lhs_typ = mkPfNot (mkPfAnd p1_typ p2_typ) in
    let dm_typ = mkPfOr (mkPfNot p1_typ) (mkPfNot p2_typ) in
(*     let _ = pr "p1_typ=%s\n p2_typ=%s\n s1_typ=%s\ns2_typ=%s\n" (Pretty.strTyp p1_typ) *)
(*       (Pretty.strTyp p2_typ) (Pretty.strTyp s1_typ) (Pretty.strTyp s2_typ) in *)
    let ((lhs_bvd,_), lhs_exp) = mkFormDom "lhs" lhs_typ in
    let dm_step =                
      Exp_constr_app(Axioms._DeMorganNotAnd, [stripPfT p1_typ; stripPfT p2_typ], [], [lhs_exp]) in
    let ((dm_bvd, _), dm_exp) = mkFormDom "dm" dm_typ in
    let a2_proof, a2_rhs_typ = proofTermToProofExp a2, s2_typ in      
    let a1_id = ProofState.Extraction.idOfTerm a1 in 
    let _ = if not (Ht.mem skolemPackages a1_id) then raise (Never "Unregistered skolem package in NnfNeg-Sk1") in
    let {sksym=skolemSym; eqsat_pf=skolem_step; 
         ex_typ=ex_t; ex_typ_1=a_targ; ex_typ_2=ex_body_t;
         ante_typ=antecedent_t; mp_eq=None} = Ht.find skolemPackages a1_id in
    let _ = Ht.remove skolemPackages a1_id in
    let a1_proof, ex_var, a1_rhs_typ = match ex_t.v with 
      | Typ_dtuple [(Some ex_var, _); _] -> skolem_step, ex_var, ex_t 
      | _ -> raise (Never "Unexpected non-existential package in skolemPackages") in
    let mono_typ = mkPfOr (mkPfT a1_rhs_typ) a2_rhs_typ in (* Or (exists x. S1' x) S2 *)
    let mono_step = 
      Exp_constr_app(Axioms._MonoOr, 
                     [mkNot p1_typ; mkNot p2_typ; a1_rhs_typ; stripPfT a2_rhs_typ], 
                     [],
                     [dm_exp; a1_proof; a2_proof]) in
    let ((mono_bvd, _), mono_exp) = mkFormDom "mono" mono_typ in
    let commute_or = Theorems._Commute_Or [2;1] in
    let flip_typ = mkPfOr a2_rhs_typ (mkPfT a1_rhs_typ) in (* Or S2 (exists x. S1' x) *)
    let flip_step = fold_app_tapp commute_or [Inl a1_rhs_typ; 
                                              Inl (stripPfT a2_rhs_typ); 
                                              Inr mono_exp] in
    let ((flip_bvd, _), flip_exp) = mkFormDom "flip" flip_typ in
    let pq_body_typ = mkPfOr a2_rhs_typ ex_body_t in
    let pq_typ = Wt (Typ_dtuple([(Some ex_var, a_targ);
                                 (None, pq_body_typ)])) in
    let pq_step =  Exp_constr_app(Axioms._PullQuantOrE, 
                                  [a_targ; stripPfT a2_rhs_typ; Wt (Typ_lam(ex_var, a_targ, stripPfT ex_body_t))], 
                                  [],
                                  [flip_exp]) in
    let imp = 
      mkExpAbs lhs_bvd lhs_typ
        (W (Exp_let (false, [dm_bvd, dm_typ, W dm_step], 
                     W (Exp_let(false, [mono_bvd, mono_typ, W mono_step], 
                                W (Exp_let(false, [flip_bvd, flip_typ, flip_step], W pq_step))))))) in
    let pf = Exp_constr_app(Axioms._ImpliesIntro, [stripPfT lhs_typ; pq_typ], [], [imp]) in
    let _ = Ht.add skolemPackages !curProofId {sksym=skolemSym;
                                               eqsat_pf=W pf;
                                               ex_typ=pq_typ;
                                               ex_typ_1=a_targ;
                                               ex_typ_2=pq_body_typ;
                                               ante_typ=lhs_typ;
                                               mp_eq=None} in
      (* Make a trivial proof step here. The real step happens with an unpack at the top of the proof *)
    let ((bvd,_),_) = mkFormDom "nnfnegSk1" lhs_typ in
    let res_typ = mkOr ex_body_t a2_rhs_typ in
    let unflip = fold_app_tapp commute_or [Inl (stripPfT a2_rhs_typ);
                                           Inl (stripPfT ex_body_t);
                                           Inr (skolemSymToProofExp skolemSym)] in
    let fun1 =mkExpAbs bvd lhs_typ unflip in
      Some (Pf_exp(W (Exp_constr_app(Axioms._ImpliesIntro, 
                                     [stripPfT lhs_typ; res_typ],
                                     [],
                                     [fun1])))))

(****************************************************************************)
(* [sk]                                                                     *)
let skDebug = false

let wrapWithSkolemPackages proofBody =
(*   let _ =  pr "Wapping top-level proof with skolem var unpacks:\n " in *)
    Ht.fold (fun _ skrec acc -> 
               match skrec.mp_eq with 
                 | None -> raise (Never "Unused skolem eqsat proof step")
                 | Some (ante_bvd, ante_sub_pf) -> 
(*                      let _ =  pr "Found registered pkg for skolem var %s\n" skrec.sksym in *)
                     let li1, li2 = skolemSymToLi skrec.sksym, skolemSymToProofLi skrec.sksym in
                     let bvar1 = bvwithsort (mkbvd(li1,li1)) skrec.ex_typ_1 in 
                     let bvar2 = bvwithsort (mkbvd(li2,li2)) skrec.ex_typ_2 in 
                     let ante_pf = subProofToExp ante_sub_pf in
                     let pf_pkg =
                       W (Exp_constr_app(Axioms._ModusPonens,
                                         [(stripPfT skrec.ante_typ); skrec.ex_typ], 
                                         [], 
                                         [(W (Exp_bvar (bvd_to_bvar ante_bvd))); skrec.eqsat_pf])) in                                      
                     let unpack_body = 
                       let ((bv,_),pkgExp) = mkFormDom "deProofedPkg" skrec.ex_typ in 
                       let pat = Pat_variant (Const.tuple_UU_lid, [], [], [bvar1;bvar2], false) in (* allowed to omit type params here *)
                       let dummyBranch = mkExp (Exp_ascribed (dummyExp, mkPfT Const.false_typ, [])) in
                       let body = mkExp (Exp_match (pkgExp, [(pat, acc)], dummyBranch)) in
                         mkExpAbs bv skrec.ex_typ body in
                     let pf_pkg_bvd = new_bvd None in
                     let pf_pkg_bvar = W (Exp_bvar (bvd_to_bvar pf_pkg_bvd)) in
                       W (Exp_let (false, [ante_bvd, skrec.ante_typ, ante_pf], 
                                   W (Exp_let(false, [pf_pkg_bvd, mkPfT skrec.ex_typ, pf_pkg], 
                                              mkDconApp Axioms._BindPf [skrec.ex_typ; Const.false_typ] [pf_pkg_bvar; unpack_body])))))
      skolemPackages proofBody


(* if q2 is structurally the same as q1, but with zero or Var terms replaced
   with actuals, then return a table that maps de Bruijn indices to the
   actuals in q2.  *)
let compatibleQuantBodies q1 q2 =
  let ht = Ht.create "compatibleQuantBodies ht" soi in
  let minIdx, maxIdx = ref max_int, ref min_int in
  let rec foo (q1,q2) =
    (match (!z3).GetTermKind q1 with
       | TermKind.App ->
           let f = ((!z3).GetAppDecl q1).GetDeclName() in
           let args1 = Array.to_list ((!z3).GetAppArgs q1) in
           (match destructTerm f q2 with
              | Some args2 -> List.for_all foo (List.zip args1 args2)
              | _ -> false)
       | TermKind.Var ->
           let i = int((!z3).GetVarIndex q1) in
           (match (!z3).GetTermKind q2 with
              | TermKind.Var -> i = int((!z3).GetVarIndex q2)
              | TermKind.App ->
                  if Ht.mem ht i then q2 = (Ht.find ht i)
                  else begin
                    Ht.add ht i q2;
                    if i < !minIdx then minIdx := i;
                    if i > !maxIdx then maxIdx := i;
                    true
                  end
              | _ -> false)
       | TermKind.Quantifier ->
           raise (Never "compatibleQuantBodies: quant body not in prenex normal form")
       | _ -> false)
  in
  if foo (q1,q2)
    then Some (ht,!minIdx,!maxIdx)
    else None

let makeActualsFromTable info ht minIdx maxIdx =
  let rec foo acc i =
    if i > maxIdx then acc
    else foo ((Ht.find ht i)::acc) (i+1)
  in
  (* starting at minIdx+1, since the smallest index should be the skolem constant *)
  let l = List.map (termToExp info []) (foo [] (minIdx+1)) in
  if existsNone l
    then None
    else Some (List.map fst (projSomes l))


let rec stripForalls tm =
  (match (!z3).GetTermKind tm with
     | TermKind.Quantifier ->
         let q = (!z3).GetQuantifier tm in
         if q.IsForall then stripForalls q.Body else tm
(*
         if ((!z3).GetQuantifier tm).IsForall
           then stripForalls (getQuantBody tm)
           else tm
*)
     | _ -> tm)



(* TODO right now, just walking the term to find the first ! symbol. assuming no quantifiers *)
exception FoundSkolemSym of string*typ
let findSkolemConstantSym tm2 =
  let rec foo tm =
    (match (!z3).GetTermKind tm with
       | TermKind.Var -> ()
       | TermKind.App ->
           let sym = ((!z3).GetAppDecl tm).GetDeclName() in
             if reSkolem.IsMatch sym
             then 
               let sortName = ((!z3).GetSort tm).GetName() in
               let sort = strSortToSort sortName in
                     raise (FoundSkolemSym(sym, typOfSort sort))
             else (List.iter foo (getAppArgs tm))
       | _ -> ())
  in
    try (foo tm2; None) with (FoundSkolemSym(sym, t)) -> Some(sym,t)

(*                                                 *)
(*     (~ (not (forall x (P a1 ... an x))) (not (P a1..an x')))     *)  (* ~ treated as implies *)
(*                                                 *)
let _Sk_NotForall info = antes0 
  (fun tm1 ->
     (match destructTerm "~" tm1 with Some [x;y] ->
(*      pr "Trying _Sk_NotForAll on an equisat proof term\n"; *)
     (match destructTerm "not" x with Some [forall] when isForallTerm forall -> (* no need to examine skInBody *)
     (match destructTerm "not" y with Some [skOutBody] ->
     (match findSkolemConstantSym (skOutBody) with Some (skolemSym, a_targ) -> 
(*      pr "[_Sk_NotForAll] Found a skolem constant %s\n" skolemSym; *)
(*         let nfa_t = Tcenv.lookup_lid info.envn Const.nfa_exnot_lid in *)
(*         let nfa_var = withsort Const.nfa_exnot_lid nfa_t in *)
        let (Some skout_t) = termToTyp info [skolemSym] skOutBody in
        let ub_skolemSym = unbangSkolemSym skolemSym in
        let ex_bvd = bvdef_of_str ub_skolemSym in
        let p_targ = Wt (Typ_lam(ex_bvd, a_targ, stripPfT skout_t)) in
        let ex_t = Wt (Typ_dtuple([(Some ex_bvd, a_targ); (None, mkPfNot skout_t)])) in
        let stepIff = W (Exp_constr_app(Axioms._NotAllExistsNot, [a_targ; p_targ], [], [])) in
          (* stepIff : pf ((not (forall x. P x)) <=> exists x. not (P x)) *)          
        let (Some antecedent_t) = termToTyp info [] x in
        let step = W (Exp_constr_app(Axioms._IffElim1, 
                                     [stripPfT antecedent_t; ex_t],
                                     [],
                                     [stepIff])) in
        let _ = Ht.add skolemPackages !curProofId {sksym=skolemSym; eqsat_pf=step; 
                                                   ex_typ=ex_t; ex_typ_1=a_targ; 
                                                   ex_typ_2=mkPfNot skout_t; (* used to be p_targ *)
                                                   ante_typ=antecedent_t; mp_eq=None} in
          
(*           pr "Registered skolem sym %s at proof id %d\n" skolemSym !curProofId; *)
          (* Make a trivial proof step here. The real step happens with an unpack at the top of the proof *)
        let fun1 =
          let ((bvd,_),_) = mkFormDom "lhsSkNfa" antecedent_t in
            mkExpAbs bvd antecedent_t (skolemSymToProofExp skolemSym) in
        let (Some tyGoal) = termToTyp info [] tm1 in
          Some (Pf_fadc_asc (Axioms._ImpliesIntro, 
                             List.map stripPfT [antecedent_t; mkPfNot skout_t], 
                             [wrapSubpfExp fun1], tyGoal, 0))
        | _ -> None)
        | _ -> None)
        | _ -> None)
        | _ -> None))

(* 
   [elim-unused]------------------------ (x not in FV(P))
                  forall x:t. P <=> P
*)
let _ElimUnused info = antes0 (fun g -> 
   match destructTerm "iff" g with None -> None | Some [x_p; p] -> 
     let pf_x_p = must (termToTyp info [] x_p) in
       match (stripPfT pf_x_p).v with 
         | Typ_fun(_, t, pf_p) -> 
             let step = Exp_constr_app(Axioms._ElimUnused, 
                                       [t; stripPfT pf_p], [],
                                       []) in
               Some (Pf_exp (W step))
         | _ -> None)

(****************************************************************************)
(* STATISTICS                                                               *)
(****************************************************************************)

let ruleStats : (string, int * int) Ht.t = Ht.create "ruleCounters" id

let ruleFails : (string, string list) Ht.t = Ht.create "ruleFails" id

let trackStat rule success =
  let p, f = if Ht.mem ruleStats rule then Ht.find ruleStats rule else 0, 0 in
  let p',f' = if success then succ p, f else p, succ f in
  Ht.replace ruleStats rule (p',f');
  if not success then begin
    let l = if Ht.mem ruleFails rule then Ht.find ruleFails rule else [] in
    let s = spr "%04d  p%d_f%d" (queryCount()) !curProofId !curGoalId in
    Ht.replace ruleFails rule (s::l)
  end;
  ()

let printStatsToFile () =
  let sw = new System.IO.StreamWriter(spr "%s/stats.txt" !queries) in
  log sw (spr "\n  ==========================================");
  log sw (spr "\n  QUERY COUNT: %d" (queryCount()));
  log sw (spr "\n  ==========================================\n");
  log sw (spr "\n  ==========================================");
  log sw (spr "\n  %-20s %10s %10s" "Z3 PROOF RULE" "pass" "fail");
  log sw (spr "\n  ==========================================\n");
  let numPass, numFail =
    Ht.fold
      (fun rule (p,f) (sumP,sumF) ->
         log sw (spr "\n  %-20s %10d %10d" rule p f); (sumP+p, sumF+f)
      ) ruleStats (0,0) in
  log sw (spr "\n\n  %-20s %10d %10d\n" "TOTAL" numPass numFail);
  log sw (spr "\n  ==========================================");
  log sw (spr "\n  FAILED ON:");
  log sw (spr "\n  ==========================================\n");
  Ht.iter ruleFails
    (fun rule fails ->
       log sw (spr "\n  %-20s" rule);
       List.iter (fun s -> log sw (spr "\n  %-20s %s" "" s)) (List.rev fails);
    );
(*
  log sw
    "\n\n  asserted (from derefined context): %7d\n" !fromDerefinedContext;
*)
(*
  log sw "\n  ==========================================";
  log sw "\n  REPEATS:";
  log sw "\n  ==========================================\n";
  Ht.iter htRepeats (fun (i,j,s) k -> log sw "\n  p%-5d f%-5d %-20s %5d" i j s k); 
*)
  sw.Flush (); sw.Close ();
  ()



(****************************************************************************)
(* PROOF EXTRACTION                                                         *)
(****************************************************************************)

let registerGoal info gv x =
  (match destructTerm "not" x with 
     | Some [goalTerm] ->
         (match termToTyp info [] goalTerm, termToTyp info [] x with 
              Some g, Some ng -> 
                begin
                  goalVar         := Some gv;
                  negGoalTerm     := Some x;
                  negGoalTyp      := ng;
                  goalTyp         := stripPfT g;
                  let ((bv,_),e)   = mkFormDom "neg" !negGoalTyp in 
                    negGoalBvd      := bv;
                    negGoalExp      := e;
                end
            | _ -> raise (Never "registerGoal failed 1"))
     | _ -> raise (Never "registerGoal failed 2"))
    
(* TODO make pretty *)
let prettyPrintFStarProof oc =
  log oc (spr "\nlet proofFun (%s#%s:%s) =\n"
    (!negGoalBvd).ppname.idText (!negGoalBvd).realname.idText
    (Pretty.strTyp !negGoalTyp));

  (* TODO update with bind *)
  Ht.iter skolemPackages (fun s skrec -> 
    log oc (spr "\n  << unpack for skolem sym %s >> \n" skrec.sksym));

  List.iter (fun pi ->
    let strProof = match Ht.find htProofTermIdToProof pi with
      | Pf_bot -> "= Exp_bot"
      | Pf_bot_asc(g) ->
          if not printAscription
            then "= Exp_bot"
            else spr ":\n     (%s) =\n     Exp_bot" (Pretty.strTyp g)
      | Pf_string s -> spr "= (* %s *)" s
      | Pf_fadc(dc,ts,es,t,_)
      | Pf_fadc_asc(dc,ts,es,t,_) ->
          let s1 = String.concat "," (List.map Pretty.strTyp ts) in
          let s2 = String.concat ";" (List.map strSubproof es) in
          if not printAscription
            then spr "= %s<%s;%s>" (sli dc.v) s1 s2
            else spr "\n\n     : (%s)\n\n     = %s<%s;%s>"
                   (Pretty.strTyp t) (sli dc.v) s1 s2
      | Pf_exp(e) -> spr "= %s" (Pretty.strExp e)
      | Pf_call(e,ts,es,t,_) ->
          let s = Pretty.strExp e in
(*
          let s1 = "" in
*)
          let s1 = String.concat "," (List.map Pretty.strTyp ts) in
          let s2 = String.concat " " (List.map strSubproof es) in
          if not printAscription
            then spr "= %s<%s> %s" s s1 s2
            else spr "\n\n     : (%s)\n\n     = %s<%s> %s"
                   (Pretty.strTyp t) s s1 s2
    in
    let fj = proofTermIdToFormulaTermId pi in
    log oc (spr "\n  let p%d_f%d %s in\n" pi fj strProof)
  ) (List.rev !processedProofIdsList);

  let lastPi = List.hd !processedProofIdsList in
  let lastFj = proofTermIdToFormulaTermId lastPi in
  log oc (spr "\n  p%d_f%d\n" lastPi lastFj);

(*   Ht.iter skolemPackages (fun s (pkg,_,_,_) -> *)
(*     log oc (spr "\n  | _ -> Exp_bot (\* %s *\)\n" s) *)
(*   ); *)

  log oc (spr "\n");
  log oc (spr "let proof = ProofLib._ProofByContradiction\n");
  log oc (spr "              <%s>\n" (Pretty.strTyp !goalTyp));
  log oc (spr "              proofFun\n\n");
  flush oc

let unsupp s = failwith ("Unsupported Z3 rule: " ^ s)

let rec tryProofRules (rulename:string) bot (xs:Term array) = function
(* TODO
  | [] -> (trackStat rulename false; bot)
*)
  | [] ->
      if rulename = "true-axiom"
        then (trackStat rulename true; Pf_exp proofTrue)
        else (trackStat rulename false; bot)
  | rule::tl ->
      (match rule (Array.to_list xs) with
         | Some pf -> (trackStat rulename true; pf)
         | None    -> tryProofRules rulename bot xs tl)

let synthesizeProof info oc argids (f:FuncDecl) xs = "ProofExtract.synthesizeProof" ^^ lazy

  let applicableRules = match (!z3).GetDeclKind(f), Array.length xs with

    | DeclKind.True, 0                -> []
    | DeclKind.False, 0               -> []
    | DeclKind.Iff, 2                 -> []
    | DeclKind.Xor, 2                 -> []
    | DeclKind.Not, 1                 -> []
    | DeclKind.Implies, 2             -> []
    | DeclKind.And, n                 -> []
    | DeclKind.Or, n                  -> []

    (* length xs should be 1 plus number of antecedents for the rule *)

(*
    | DeclKind.PrTrue, 1              -> failwith "pr true"
*)
    | DeclKind.PrAsserted, 1          -> [_Asserted info]
    | DeclKind.PrGoal, 3              -> []
    | DeclKind.PrModusPonens, 3       -> [_MpIff info]
    | DeclKind.PrReflexivity, 1       -> [_ReflIff info; _ReflEq info; _ReflEqui_id info]
    | DeclKind.PrSymmetry, 2          -> [_SymmIff info; _SymmEq info]
    | DeclKind.PrTransitivity, 3      -> [_TransIff info; _TransEq info]
    | DeclKind.PrQuantIntro, 2        -> [_QuantIntro info]
    | DeclKind.PrAndElim, 2           -> [_AndElim info]
    | DeclKind.PrNotOrElim, 2         -> [_NotOrElim info]
    | DeclKind.PrPullQuant, 1         -> [_PullQuant info]
    | DeclKind.PrPushQuant, 1         -> []
    | DeclKind.PrElimUnusedVars, 1    -> [_ElimUnused info]
    | DeclKind.PrDer, 1               -> []
    | DeclKind.PrQuantInst, 1         -> [_QuantInst info]
    | DeclKind.PrHypothesis, 1        -> [_Hypothesis info]
(*
    | DeclKind.PrLemma, 2             -> [_Lemma]
*)
    | DeclKind.PrLemma, 2             -> [_Lemma_1_0 info; _Lemma_1_1 info;
                                          _Lemma_2_01 info; _Lemma_2_11 info;
                                          _Lemma_3_101 info]
    | DeclKind.PrIffTrue, 2           -> []
    | DeclKind.PrIffFalse, 2          -> []
    | DeclKind.PrCommutativity, 1     -> [_Rw_Eq info]
    | DeclKind.PrDefIntro, 1          -> []
    | DeclKind.PrIffOeq, 2            -> []
    | DeclKind.PrSkolemize, 1         -> [_Sk_NotForall info] 
(*
    | DeclKind.PrModusPonensOeq, 3    -> [_MpIff]
*)
    | DeclKind.PrModusPonensOeq, 3    -> [_MpEqui_Useless info argids; _MpEqui info argids]
    | DeclKind.PrDistributivity, n    -> []
    | DeclKind.PrApplyDef, n          -> []
    | DeclKind.PrNnfPos, n            -> [_NnfPos_Ignore info; _NnfPos info]
    | DeclKind.PrNnfNeg, 3            -> [_NnfNeg info; _NnfNegSK_2 info; _NnfNegSK_1 info]
    | DeclKind.PrThLemma, n           -> []
    | DeclKind.Uninterpreted, n       -> []

    | DeclKind.PrRewrite, 1           -> [_Rw_Eq info;
                                          _Rw_IdImplies_1 info;
                                          _Rw_IdImplies_2 info;
                                          _Rw_CommuteOnly info;
                                          _Rw_FlattenCommute info;
                                          _Rw_DblNotElim info;
                                          _Rw_DeMorganNotOr info;
                                          _Rw_DeMorganAnd info;
                                          _Rw_DeMorganNotAnd info;
                                          _Rw_DeMorganOr info;
                                          _Rw_Id info;
                                          _Rw_TrueImplies info;
                                          _Rw_NotTrue info;
                                          _Rw_OrPFalse_P_4 info;
                                          _Rw_OrPFalse_P_3 info;
                                          _Rw_OrImpAA_True info;
                                          _Rw_TEMP_OrFalseFalseP info;
                                          _Rw_TEMP_1 info;
                                          _Rw_TEMP_2 info;
                                          _Rw_TEMP_3 info;
                                          _Rw_TEMP_4 info;
                                          _Rw_TEMP_5 info;
                                          _Rw_TEMP_6 info;
                                          _Rw_AndABC_AndBCA info
                                         ]

    | DeclKind.PrDefAxiom, 1          -> [_DefAxiomOne info;   _DefAxiomTwo info;
                                          _DefAxiomThree info; _DefAxiomFour info;
                                          _DefAxiomFive info;  _DefAxiomSix info;
                                          _DefAxiomSeven info; _DefAxiomEight info;
                                          _DefAxiomNine info
                                         ]

    | DeclKind.PrMonotonicity, n      -> [_MonoFunSym info;
                                          _MonoProp info;
                                          _MonoEq info;
                                          _MonoConnective info
                                         ]

    | DeclKind.PrUnitResolution, 3    -> [_Contra info; _UnitResQuantInst info; _UnitResGeneral info; _Trivial info]
    | DeclKind.PrUnitResolution, n    -> [_UnitResGeneral info]

    (* unhandled proof rules *)

    | DeclKind.PrPullQuantStar, 1     -> unsupp "PullQuantStar (PROOF_MODE 1)"
    | DeclKind.PrTransitivityStar, n  -> unsupp "TransStar (PROOF_MODE 1)"
    | DeclKind.PrRewriteStar, n       -> unsupp "RewriteStar (PROOF_MODE 1)"
    | DeclKind.PrNnfStar, n           -> unsupp "NnfStar (PROOF_MODE 1)"
    | DeclKind.PrCnfStar, n           -> unsupp "PrCnfStar (PROOF_MODE 1)"

    | _, n -> (pr "ProofExtract WARNING: missing DeclKind!";
               failwith (spr "applying %s with %d args" (f.GetDeclName()) n))

  in
  let bot = (match termToTyp info [] xs.[Array.length xs - 1] with
              | Some goalTyp -> Pf_bot_asc goalTyp
              | None -> Pf_bot) in
  tryProofRules (f.GetDeclName()) bot xs applicableRules


let generateProofTerm info oc (gv:Term) goalTerm proofTerm =

  let rec foo t =
    let k = ProofState.Extraction.idOfTerm t in
    if Zset.mem k !processedProofIds then k
    else begin
      (match (!z3).GetTermKind t with TermKind.App -> begin
         let f = (!z3).GetAppDecl t in
         (match ((!z3).GetRange f).GetName() with "proof" -> begin
            let xs = (!z3).GetAppArgs t in
            let _, goalForm = splitAntesAndGoal (Array.to_list xs) in

            let ys = Array.to_list (Array.map foo xs) in
            let argIds, goalId = splitAntesAndGoal ys in

            curProofId := k;
            curGoalId := goalId;

            let proof = synthesizeProof info oc argIds f xs in

            Ht.add htProofTermIdToProof k proof;
            Ht.add htProofTermToFormulaTerm t goalForm;

            processedProofIds := Zset.add k !processedProofIds;
            processedProofIdsList := k :: !processedProofIdsList;

            (* how many times pi_fj appears across all obligations *)
            let key = (!curProofId, !curGoalId, f.GetDeclName()) in
            if Ht.mem htRepeats key 
              then Ht.replace htRepeats key (1 + Ht.find htRepeats key)
              else Ht.add htRepeats key 1;
          end 
          | _ -> ())
      end
      | TermKind.Var -> ()
      | TermKind.Quantifier -> ()
      | _ -> ());
      k
    end
  in

  registerGoal info gv goalTerm;
  ignore (foo proofTerm); (* do proof extraction *)
  prettyPrintFStarProof oc;

  (* create the top-level proof by contradiction structure *)
  let body = proofTermIdToProofExp (List.hd !processedProofIdsList) in
  let body = wrapWithSkolemPackages body in
  let proof = mkCall1 Theorems._ProofByContradiction [!goalTyp] [mkExpAbs !negGoalBvd !negGoalTyp body] in
(*   let _ = pr "proof term: \n %s\n" (Pretty.strExp proof) in  *)
    
    clearProofTermState ();
    proof


