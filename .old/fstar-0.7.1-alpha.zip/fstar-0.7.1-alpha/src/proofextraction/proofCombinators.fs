(* Modified by Nikhil Swamy; May, July 2010 *)
(*
  Copyright (c) 2009, Regents of the University of California

  Authors: Ravi Chugh
  
  All rights reserved.
  
  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following 
  conditions are met:
  
  1. Redistributions of source code must retain the above copyright 
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above 
  copyright notice, this list of conditions and the following disclaimer 
  in the documentation and/or other materials provided with the distribution.

  3. Neither the name of the University of California, San Diego, nor 
  the names of its contributors may be used to endorse or promote 
  products derived from this software without specific prior 
  written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
  CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
  PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
  PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
  LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
  SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*)


#light "off"

module Microsoft.FStar.ProofCombinators

open Microsoft.FStar
open Absyn
open AbsynUtils
open ProofCommon
open Util
open ProofState
open KindAbbrevs

(****************************************************************************)
(* OTHER UTILS                                                              *)
(****************************************************************************)


(* Takes a proposition T(x1,...,xn) and returns the lident of the type
   constructor and the expression arguments. *)
let destructFaProp t =
  let rec f acc t = match t.v with
    | Typ_const(x, _)  -> (x.v, acc)
    | Typ_dep(t1,e) -> f (e::acc) t1
    | _             -> failwith (spr "destructFaProp: %s" (Pretty.strTyp t))
  in f [] t

(* Takes a right-deep arrow and returns the bvdefs/domains of the innermost
   body. Automatically unwraps pf<> at each level. *)
let getFormalsDomainsRangeOfArrow t =
  let rec f acc t = match t.v with
    | Typ_fun(Some(formal),dom,t') -> f ((formal.realname.idText,dom)::acc) t'
    | Typ_app(t1,t2) ->
        (match t1.v with (* discard pf wrappers *)
           | Typ_const(x, _) when sli x.v = sli Const.pf_lid -> f acc t2
           | _ -> acc, t)
    | _ -> acc, t
  in f [] t

let rec tconIsEquatable k = match k(* .u *) with
  | Kind_tcon(_,k1,k2) -> tconIsEquatable k1 && tconIsEquatable k2
  | Kind_affine  (* Nik: Todo EA Review *)
  | Kind_prop
  | Kind_star        -> true
  | Kind_dcon(_, _, k)  -> tconIsEquatable k 
  | _                -> false

(* Canonicalizes type with type tparams by creating additional universal
   types. *)
let rec pushTparamsIntoTyp (tps:tparam list) (t:typ) : typ =
  match List.rev tps with
    | (Tparam_typ (bvd,k))::rest ->
         pushTparamsIntoTyp rest (twithsort (Typ_univ (bvd, k, [], t)) Kind_star)
    (* TODO check this, added on 10/23 *)
    | (Tparam_term(bvd,t1))::rest -> t (* since all tparams came first *)
    | [] -> t

(* Creates a new bvdef and the corresponding bvar expression. *)
let mkFormDom (s:string) (t:typ) = AbsynUtils.stringToBvdExp s t 

(* Uses the given string instead of generating a new symbol. *)
let mkFormDomFixed (s:string) (t:typ) =
  let bvd = mkbvd <| (mkId s, mkId s) in
  let e   = bvdToExp bvd t in
  (bvd,t), e


(****************************************************************************)
(* UTILS THAT LOOKUP IN TABLES                                              *)
(****************************************************************************)

let rec typOfTi : typinst -> typ =
  function
    | TIMono(i) -> ProofState.TypeConstructors.typOfSort i 
    | TIPoly(i,l) ->
        let tc = ProofState.TypeConstructors.typOfSort i in
        let targs = List.map typOfTi l in
        mkTypApp tc targs []
    | TITuple(x,y) ->
        let t1, t2 = typOfTi x, typOfTi y in
         mkTyp (Typ_dtuple [(None,t1);(None,t2)])
    | TIRecordMono(i) -> ProofState.Records.typOfSort i 
    | TITVar sort -> ProofState.BoundTvars.typOfSort sort   
    | TIUVar sort -> ProofState.Uvars.typOfSort sort   

let rec tiOfTyp : typ -> typinst =
  let terr t = raise (Translation (spr "No typinst for typ %s" (Pretty.strTyp t))) in
  let rec convert_one t = match t.v with
    | Typ_const _ ->
        let tiOpt = 
           (bind_opt (ProofState.TypeConstructors.sortOptOfTyp t)
                     (fun s -> Some (TIMono s))) =^^=> 
           (fun () -> bind_opt (ProofState.Records.sortOptOfTyp t)
                      (fun s -> Some (TIRecordMono s))) in 
         (match tiOpt with 
            | Some ti -> ti 
            | _ -> terr t)
    | Typ_dtuple([(_,t1);(_,t2)]) -> TITuple (tiOfTyp t1, tiOfTyp t2)
    | Typ_refine(_,t',_,_) -> tiOfTyp t'
    | Typ_dep(t, _) -> tiOfTyp t
    | Typ_btvar(bv) -> (match ProofState.BoundTvars.sortOptOfTyp t with 
                            | Some s -> TITVar s
                            | _ -> terr t)
    | Typ_uvar(uv, _) -> (match ProofState.Uvars.sortOptOfTyp t with 
                            | Some s -> TITVar s
                            | _ -> TITVar (ProofState.Uvars.addUvar uv))
    | _ -> terr t 
  in
  (fun t ->
    let t = remove_deps t in
     match flattenTypApps t with
       | []     -> raise (Never "tiOfTyp")
       | [t'] -> convert_one t'
       | t'::ts -> (match convert_one t' with
                      | TIMono x -> 
                          if not (ProofState.TypeConstructors.isUniform x) then TIMono x
                          else TIPoly (x, List.map tiOfTyp ts)
                      | _        -> terr t))
let tiOptOfTyp t = 
    try Some (tiOfTyp t) with Translation _ -> None

let tiOfSort (sort:sort) : typinst = ProofState.TypInsts.typinstOfSort sort

let sortOfTi (ti:typinst) : sort = match ProofState.TypInsts.sortOptOfTypinst ti with 
    | None -> raise (Bad_sort (spr "no sort for %s" (strTypinst ti)))  
    | Some s -> s

let typOfSort = typOfTi -<- tiOfSort
let sortOfTyp = sortOfTi -<- tiOfTyp 
let sortOptOfTi ti = try Some (sortOfTi ti) 
                     with Bad_sort _ -> None

let sortOptOfTyp t = bind_opt (tiOptOfTyp t) sortOptOfTi

let lookupAxiomTii info lid tii = 
  let axT = Tcenv.lookup_lid info.envn lid in
  let axVar = fvwithsort lid axT in
  let t = typOfSort tii in
    axVar, t

let boolSort () = sortOfTyp Const.bool_typ 
let stringSort () = sortOfTyp Const.string_typ

let mkStr stringid =
  let s = ProofState.StringConstants.stringOfId stringid in
  let b = Bytes.string_as_unicode_bytes(s) in
  mkExp (Exp_constant (Sugar.Const_string (b, dummyRange)))

let rec longStrTypinst : typinst -> string =
  let strList l = String.concat "," (List.map longStrTypinst l) in
  function
    | TIMono(i)    -> Pretty.strTyp (ProofState.TypeConstructors.typOfSort i)
    | TIPoly(i,l)  -> let x = longStrTypinst (TIMono i) in 
                      spr "%s<%s>" x (strList l)
    | TITuple(x,y) -> spr "tuple<%s>" (strList [x;y])
    | TIRecordMono(i) -> 
            spr "record_mono_%s" (Pretty.strTyp (ProofState.Records.typOfSort i))
    | TITVar sort -> 
            let btv = ProofState.BoundTvars.typOfSort sort in
                spr "tvar<%d>=%s" sort (Pretty.strTyp btv) 
              
let longStrOfDconinst ((di,sortl):dconinst) : string =
  let til = List.map tiOfSort sortl in
  let s = String.concat "," (List.map longStrTypinst til) in
  spr "%s<%s>" (ssl (ProofState.DataConstructors.nameOfDconid di)) s

(****************************************************************************)
(* NAMES OF SPECIALIZED AXIOMS AND THEOREMS                                 *)
(****************************************************************************)

(* these generated lidents always have length 2, where the first component
   is the module name and the second is the specialized principle name *)
let mkSpecTc (prefix:string) sort : lident =
  asLid <| [mkId (ProofState.TypInsts.moduleOfSort sort);
            mkId (spr "%s_tii%03d" prefix sort)]

let liDconRecdProj i  = mkSpecTc (spr "AxRecdProj_%d" i)
let liDconRecdEq i    = mkSpecTc (spr "AxRecdEq_%d" i)
let liDconRecdMonoEq  = mkSpecTc "RecdMonoEq"
let liDconNeqBool     = liOfSl ["Prims";"NeqBool"]
let liDconNeq i       = mkSpecTc (spr "Neq_%04d" i)

let liDconMonoDconinst ((i,js):dconinst) : lident =
  let li = liOfSl (ProofState.DataConstructors.nameOfDconid i) in
  let modname = List.hd li.lid in
  asLid <| modname :: [mkId (spr "Mono_dconinst_%s" (strOfDconinst (i,js)))]

let getEqTyp info t = 
  let eqK = Tcenv.lookup_typ_const info.envn (Wftv Const.eq_lid) in
    match eqK(* .u *) with 
      | Kind_tcon(Some a, Kind_star, Kind_dcon(_, _a1, Kind_dcon(_, _a2, Kind_prop))) ->
          (* NIK: should we be really paranoid and check _a1 and _a2? *)
          let eqT = twithsort (Typ_const (fvwithsort Const.eq_lid eqK, None)) eqK in
            eqT
      | _ ->  raise (Never "unexpected kind for Prims.Eq")
          
let eqTypOfTyp info t = 
  let eqT = getEqTyp info t in 
  let k = Kind_dcon(None, t, Kind_dcon(None, t, Kind_prop)) in
    twithsort (Typ_app(eqT, t)) k
      
let eqtypOfSort info = (eqTypOfTyp info) -<- typOfSort

(****************************************************************************)
(* AXIOMS                                                                   *)
(****************************************************************************)

let checkIfProofConstructor  = 
  let mk_logic_name s = Const.p2l ["Prims"; s] in
  let names =
    List.map (fun s -> sli (mk_logic_name s))
      [
        "LiftPf"; "BindPf"; "AndTrue"; "OrFalse";
        "ExcMiddle"; "Contra"; "DestructFalse";
        "OrIntro1"; "OrIntro2"; "OrElim"; "AndIntro";
        "AndElim1"; "AndElim2";
        "DeMorganAnd"; "DeMorganAndRev"; "DeMorganOr"; "DeMorganOrRev";
        "DblNotElim"; "DblNotElimRev"; "Distribute";
        "ImpliesIntro"; "ModusPonens"; "IffIntro"; "IffElim1"; "IffElim2";
        "IdImplies"; "IdImpliesRev";
        "MonoNot"; "MonoAnd"; "MonoOr"; "MonoImplies";
      ] in
  (fun f -> List.mem f names) 

let pfComb s = mkVarT ( (liOfSl ["Prims"; s]))

module Axioms = struct
  let _T                  = pfComb "T"
  let _LiftPf             = pfComb "LiftPf"
  let _BindPf             = pfComb "BindPf"
  let _AndTrue            = pfComb "AndTrue"
  let _OrFalse            = pfComb "OrFalse"
  let _ExcMiddle          = pfComb "ExcMiddle"
  let _Contra             = pfComb "Contra"
  let _DestructFalse      = pfComb "DestructFalse"
  let _OrIntro1           = pfComb "OrIntro1"
  let _OrIntro2           = pfComb "OrIntro2"
  let _OrElim             = pfComb "OrElim"
  let _AndIntro           = pfComb "AndIntro"
  let _AndElim1           = pfComb "AndElim1"
  let _AndElim2           = pfComb "AndElim2"
  let _DeMorganNotAnd     = pfComb "DeMorganNotAnd"
  let _DeMorganOr         = pfComb "DeMorganOr"
  let _DeMorganNotOr      = pfComb "DeMorganNotOr"
  let _DeMorganAnd        = pfComb "DeMorganAnd"
  let _DblNotElim         = pfComb "DblNotElim"
  let _DblNotElimRev      = pfComb "DblNotElimRev"
  let _Distribute         = pfComb "Distribute"
  let _ImpliesIntro       = pfComb "ImpliesIntro"
  let _ModusPonens        = pfComb "ModusPonens"
  let _IffIntro           = pfComb "IffIntro"
  let _IffElim1           = pfComb "IffElim1"
  let _IffElim2           = pfComb "IffElim2"
  let _IdImplies          = pfComb "IdImplies"
  let _IdImpliesRev       = pfComb "IdImpliesRev"
  let _MonoNot            = pfComb "MonoNot"
  let _MonoAnd            = pfComb "MonoAnd"
  let _MonoOr             = pfComb "MonoOr"
  let _MonoImplies        = pfComb "MonoImplies"
  let _NotAllExistsNot    = pfComb "NotAll_existsNot"
  let _PullQuantAnd       = pfComb "PullQuantAnd"
  let _PullQuantOr        = pfComb "PullQuantOr"
  let _PullQuantAndE      = pfComb "PullQuantAndE"
  let _PullQuantOrE       = pfComb "PullQuantOrE"
  let _ElimUnused         = pfComb "ElimUnused"
  let _MonoOrIff          = pfComb "MonoOrIff"
end


(****************************************************************************)
(* LIBRARY THEOREMS                                                         *)
(****************************************************************************)

let pfFunc s = mkFvar ( (liOfSl ["ProofLib"; s]))

module Theorems = struct

  let _Refl                 = pfFunc "_Refl"
  let _Symm                 = pfFunc "_Symm"
  let _Trans                = pfFunc "_Trans"

  let _ModusPonensIff       = pfFunc "_ModusPonensIff"

  let _ProofByContradiction = pfFunc "_ProofByContradiction"

  let _Contra flag          = pfFunc (spr "_Contra_%s" (strFlags [flag]))

  let _Monotonicity_Not     = pfFunc "_Monotonicity_Not"
  let _Monotonicity_Imp     = pfFunc "_Monotonicity_Imp"
  let _Monotonicity_Iff     = pfFunc "_Monotonicity_Iff"
  let _Monotonicity_Or n    = pfFunc (spr "_Monotonicity_Or_%d" n)
  let _Monotonicity_And n   = pfFunc (spr "_Monotonicity_And_%d" n)

  let _AndElim n k =
    pfFunc (spr "_AndElim_%d_%d" n k)

  let _Commute_And bij =
    let n, strBij = List.length bij, String.concat "" (List.map soi bij) in
    pfFunc (spr "_Commute_And_%d_%s" n strBij)

  let _Commute_Or bij =
    let n, strBij = List.length bij, String.concat "" (List.map soi bij) in
    pfFunc (spr "_Commute_Or_%d_%s" n strBij)

  let _DeMorgan_NotAnd n flags =
    pfFunc (spr "_DeMorgan_NotAnd_%d_%s" n (strFlags flags))
  
  let _DeMorgan_NotOr n flags =
    pfFunc (spr "_DeMorgan_NotOr_%d_%s" n (strFlags flags))
  
  let _DeMorgan_And n flags =
    pfFunc (spr "_DeMorgan_And_%d_%s" n (strFlags flags))
  
  let _DeMorgan_Or n flags =
    pfFunc (spr "_DeMorgan_Or_%d_%s" n (strFlags flags))
  
  let _UnitRes n k flags =
    pfFunc (spr "_UnitRes_%d_%d_%s" n k (strFlags flags))

  let _Rewrite_TrueImplies  = pfFunc "_Rewrite_TrueImplies"

  let _Rewrite_IdImplies_1 flag = pfFunc (spr "_Rewrite_IdImplies_1_%s" (strFlags [flag]))

  let _Rewrite_IdImplies_2 flag = pfFunc (spr "_Rewrite_IdImplies_2_%s" (strFlags [flag]))

  let _Rewrite_DblNotElim   = pfFunc "_Rewrite_DblNotElim"

  let _Rewrite_DeMorgan_NotAnd n flags =
    pfFunc (spr "_Rewrite_DeMorgan_NotAnd_%d_%s" n (strFlags flags))
  
  let _Rewrite_DeMorgan_NotOr n flags =
    pfFunc (spr "_Rewrite_DeMorgan_NotOr_%d_%s" n (strFlags flags))
  
  let _Rewrite_DeMorgan_And n flags =
    pfFunc (spr "_Rewrite_DeMorgan_And_%d_%s" n (strFlags flags))
  
  let _Rewrite_DeMorgan_Or n flags =
    pfFunc (spr "_Rewrite_DeMorgan_Or_%d_%s" n (strFlags flags))
  
  let _Flatten_And branchSizes =
    let s = String.concat "" (List.map soi branchSizes) in
    pfFunc (spr "_Flatten_And_%s" s)

  let _Flatten_Or branchSizes =
    let s = String.concat "" (List.map soi branchSizes) in
    pfFunc (spr "_Flatten_Or_%s" s)

  let _Unflatten_And branchSizes =
    let s = String.concat "" (List.map soi branchSizes) in
    pfFunc (spr "_Unflatten_And_%s" s)

  let _Unflatten_Or branchSizes =
    let s = String.concat "" (List.map soi branchSizes) in
    pfFunc (spr "_Unflatten_Or_%s" s)

  let _DefAxiomOne n i flag =
    pfFunc (spr "_DefAxiomOne_%d_%d_%s" n i (strFlags [flag]))

  let _DefAxiomTwo n i =
    pfFunc (spr "_DefAxiomTwo_%d_%d" n i)

  let _DefAxiomThree n flags =
    pfFunc (spr "_DefAxiomThree_%d_%s" n (strFlags flags))

  let _DefAxiomFour n =
    pfFunc (spr "_DefAxiomFour_%d" n)

  let _DefAxiomFive flag =
    pfFunc (spr "_DefAxiomFive_%s" (strFlags [flag]))

  let _DefAxiomSix flag =
    pfFunc (spr "_DefAxiomSix_%s" (strFlags [flag]))

  let _DefAxiomSeven flags =
    pfFunc (spr "_DefAxiomSeven_%s" (strFlags flags))
  
  let _DefAxiomEight = pfFunc "_DefAxiomEight"

  let _DefAxiomNine  = pfFunc "_DefAxiomNine"

  let _TEMP_Rewrite_OrFalseFalseP = pfFunc "_TEMP_Rewrite_OrFalseFalseP"
  let _TEMP_Rewrite i = pfFunc (spr "_TEMP_Rewrite_%d" i)

  (* temporary *)
  let _Lemma_1_0 = pfFunc "_Lemma_1_0"
  let _Lemma_1_1 = pfFunc "_Lemma_1_1"
  let _Lemma_2_01 = pfFunc "_Lemma_2_01"
  let _Lemma_2_11 = pfFunc "_Lemma_2_11"
  let _Lemma_3_101 = pfFunc "_Lemma_3_101"

end


(****************************************************************************)
(* SPECIALIZED AXIOMS/THEOREMS                                              *)
(****************************************************************************)

module AutoAxioms = struct
  let monoDconinst di : var<typ> = 
      match ProofState.DataConstructors.monoAxiom di with
        | None -> raise (Translation "No monoAxiom for dcon")
        | Some v -> v
  
  let recdProj (s, f) : var<typ> = 
      ProofState.Records.projAxiom s f

  let recdEq (s,f) : var<typ> = 
      ProofState.Records.eqAxiom s f 
      
  let recdMonoEq : sort -> var<typ> = 
      ProofState.Records.monoAxiom
end


(****************************************************************************)
(* CREATING SPECIALIZED AXIOMS AND THEOREMS                                 *)
(****************************************************************************)

let createMonoRule info (tiil:sort list)
                        (retTypFun: exp list -> exp list -> typ) : typ =
  let til = List.map tiOfSort tiil in
  let argTyps = List.map typOfTi til in
  let n = List.length argTyps in
  let l1,l2 =
    List.mapi (fun i argTyp -> mkFormDom (spr "x%d" i) argTyp) argTyps,
    List.mapi (fun i argTyp -> mkFormDom (spr "y%d" i) argTyp) argTyps in
  let (xFds,xExps),(yFds,yExps) = List.split l1, List.split l2 in
  let eqTyps =
    map1N n (fun i ->
      let tii_i = List.nth tiil (i-1) in
      let tEqTi = eqtypOfSort info tii_i in (* mkTypConst (liEqTyp tii_i) in *)
      let ex,ey = List.nth xExps (i-1), List.nth yExps (i-1) in
      mkPfT (mkTypApp tEqTi [] [ex;ey])) in
  let ret = mkPfT (retTypFun xExps yExps) in
  let rec foo = function
    | (bvd,t)::rest, eqs      -> mkDepArrow [bvd,t] (foo (rest,eqs))
    | []           , eq::eqs' -> mkArrow eq (foo ([],eqs'))
    | []           , []       -> ret
  in
  foo (interleave xFds yFds, eqTyps)

let processProp info (li:lident)
                     (tiil:sort list) : sigelt list * ops = 
  let propid = ProofState.Props.addProp (slOfLi li) in
  let ops = [(DefPred (ProofState.Z3Symbols.symOfPropid propid,
                           Array.of_list tiil, None))] in
    [], ops
      

let processTupleInst info (sortTup:sort) (ti1:typinst) (ti2:typinst) : ops = 
    let sort1, sort2 = sortOfTi ti1, sortOfTi ti2 in
    let _ = ProofState.Tuples.addInstantiation sortTup (sort1, sort2) in
    let symCtor     = ProofState.Z3Symbols.symOfTuple sortTup in
    let symProj1    = ProofState.Z3Symbols.symOfTupleProj1 sortTup in
    let symProj2    = ProofState.Z3Symbols.symOfTupleProj2 sortTup in

    let opDefs = 
        [(DefFun (symCtor,  [|sort1;sort2|], sortTup, None));
         (DefFun (symProj1, [|sortTup|],     sort1,   None));
         (DefFun (symProj2, [|sortTup|],     sort2,   None))] in
      
    let bvX         = BoundV (1, sort1) in
    let bvY         = BoundV (0, sort2) in
    let bvTup1      = BoundV (1, sortTup) in
    let bvTup2      = BoundV (0, sortTup) in
      
    let typ1, typ2  = typOfTi ti1, typOfTi ti2 in
    let typTup      = typOfTi (TITuple (ti1, ti2)) in
      
    let tEqTup      = eqTypOfTyp info typTup in
    let tEqTyp1     = eqTypOfTyp info typ1 in
    let tEqTyp2     = eqTypOfTyp info typ2 in
      
    let defProjAxiom first =
        let bvdX, bvdY = bvdOfString "x", bvdOfString "y" in
        let sort1, sort2 = sortOfTyp typ1, sortOfTyp typ2 in
        let symX = ProofState.Z3Symbols.qvarOfBvd bvdX typ1 sort1 in
        let symY = ProofState.Z3Symbols.qvarOfBvd bvdY typ2 sort2 in
        let symProj, bv = if first then symProj1, bvX else symProj2, bvY in
        (Assume (Forall ([], [|sort1;sort2|], [|symX;symY|],
                                Eq (App (symProj, [|App (symCtor, [|bvX;bvY|])|]),
                                    bv)),
                        None,
                        ATupProj (sortTup,if first then 1 else 2))) in
    
    let defEqAxiom first =
        let bvd1, bvd2 = bvdOfString "tup1", bvdOfString "tup2" in
        let sort = sortOfTyp typTup in 
        let symTup1 = ProofState.Z3Symbols.qvarOfBvd bvd1 typTup sort in
        let symTup2 = ProofState.Z3Symbols.qvarOfBvd bvd2 typTup sort in
        let symProj = if first then symProj1 else symProj2 in
        (Assume (Forall ([], [|sortTup;sortTup|], [|symTup1;symTup2|],
                                Imp (Eq (bvTup1, bvTup2),
                                    Eq (App (symProj, [|bvTup1|]),
                                        App (symProj, [|bvTup2|])))),
                        None,
                        ATupEq (sortTup,if first then 1 else 2))) in
      
    let op1 = defProjAxiom true in
    let op2 = defProjAxiom false in
    let op3 = defEqAxiom true in
    let op4 = defEqAxiom false in
        opDefs @ [op1;op2;op3;op4]

(* TODO: Fix this to handle polymorphic records *)
let processRecordInst info (sortRecd: sort)
    (i: recdconid) (* assuming monomorphic for now *)
    (fields: fieldname list)
    (til: typinst list) : sigelt list * ops = 
  let n = List.length fields in
  let sortl = List.map sortOfTi til in
  let fieldSorts = sortl in 

  let sorts = Array.of_list sortl in
  let symCtor = ProofState.Z3Symbols.symOfRecd sortRecd in
  let ctorDef = (DefFun (symCtor, sorts, sortRecd, None)) in

  let bvXs    = map1N n (fun z -> BoundV (n-z, List.nth sortl (z-1))) in
  let bvXs    = Array.of_list bvXs in
  let rec1    = BoundV (1, sortRecd) in
  let rec2    = BoundV (0, sortRecd) in

  let typFields  = List.map typOfTi til in
  let typRecd    = typOfTi (TIRecordMono i) in

  let tEqFields  = List.map (eqTypOfTyp info) typFields in
  let tEqRecd    = eqtypOfSort info sortRecd in 
  let bvd1 = bvdOfString "recd1" in
  let bvd2 = bvdOfString "recd2" in
  let symRecd1 = ProofState.Z3Symbols.qvarOfBvd bvd1 typRecd sortRecd in
  let symRecd2 = ProofState.Z3Symbols.qvarOfBvd bvd2 typRecd sortRecd in 

  let defsForField (theField:fieldname) fieldIdx =
    let fieldId = ProofState.Records.fieldId (slOfLi theField) in 
    let l =
      map1N n (fun i -> mkFormDom (spr "x%d" i) (List.nth typFields (i-1))) in
    let fdXis, eXis = List.split l in

    (* stuff for AxRecdProj sigelt *)
    let projSigelt, projAx =
      if !Options.extract_proofs then
        let expRecdProj = mkProj (mkRecd fields eXis) theField in
        let expProjected = List.nth eXis fieldIdx in
        let tProj =
          mkPfDepArrow fdXis
            (mkPfEq (List.nth tEqFields fieldIdx) expRecdProj expProjected) in
        let projAx = (fieldId, mkVarTTyp (liDconRecdProj fieldId sortRecd) tProj) in
          [Sig_datacon_typ
             (liDconRecdProj fieldId sortRecd, [], tProj, None, Public, None, None,[])], projAx
      else
        let projAx = (fieldId, mkVarTTyp (liDconRecdProj fieldId sortRecd) dummyTyp) in
          [], projAx in

    (* stuff for AxRecdEq sigelt *)
    let eqSigelt, eqAx =
      if !Options.extract_proofs then
        let eRecd1 = bvdToExp bvd1 typRecd in
        let eRecd2 = bvdToExp bvd2 typRecd in
        let eProj1, eProj2 = mkProj eRecd1 theField, mkProj eRecd2 theField in
        let tEq =
          mkPfDepArrow [(bvd1, typRecd); (bvd2, typRecd)]
            (mkPfImp (mkPfEq tEqRecd eRecd1 eRecd2)
               (mkPfEq (List.nth tEqFields fieldIdx) eProj1 eProj2)) in
        let eqAx = (fieldId, mkVarTTyp (liDconRecdEq fieldId sortRecd) tEq) in
          [Sig_datacon_typ
             (liDconRecdEq fieldId sortRecd, [], tEq, None, Public, None, None,[])], eqAx
      else
        let eqAx = (fieldId, mkVarTTyp (liDconRecdEq fieldId sortRecd) dummyTyp) in
          [], eqAx in

    (* stuff for Z3 ops *)
    let symProj = ProofState.Z3Symbols.symOfRecdProj sortRecd fieldId in
    let symXis = Array.of_list (List.map2 (fun (bvd, t) sort -> ProofState.Z3Symbols.qvarOfBvd bvd t sort) fdXis fieldSorts) in 
    let ops =
      [(DefFun (symProj, [|sortRecd|], sorts.[fieldIdx], None));
       (Assume (Forall ([], sorts, symXis,
                            Eq (App (symProj, [|App (symCtor, bvXs)|]),
                                bvXs.[fieldIdx])),
                    None,
                    ARecdProj (sortRecd, fieldId)));
       (Assume (Forall ([], [|sortRecd;sortRecd|], [|symRecd1;symRecd2|],
                            Imp (Eq (rec1, rec2),
                                 Eq (App (symProj, [|rec1|]),
                                     App (symProj, [|rec2|])))),
                    None,
                    ARecdEq (sortRecd, fieldId)))] in
    let extra =  Eq (App (symProj, [|rec1|]),
                     App (symProj, [|rec2|])) in
      
      projSigelt@eqSigelt, ops, extra, (projAx, eqAx)
  in

  let _,sigelts, ops, extras, axs =
    List.fold_left
      (fun (j,acc1,acc2,acc3,acc4) fn -> 
         let l1,l2,extra,insts = defsForField fn j in (j+1,acc1@l1, acc2@l2, extra::acc3, insts::acc4))
      (0, [],[],[],[]) fields in
  let projAxs, eqAxs = List.split axs in 
  let rec_eq_iff = 
    (Assume (Forall ([], [|sortRecd;sortRecd|], [|symRecd1;symRecd2|],
                         Iff (Eq (rec1, rec2),
                              List.fold_left (fun out ex -> And (out, ex)) True extras)),
                 None, AOther)) in
  let ops = ops@[rec_eq_iff] in
  let seMono, monoAx =
    if !Options.extract_proofs then 
      let retTypFun xs ys =
        let recd1, recd2 = mkRecd fields xs, mkRecd fields ys in
          mkTypApp tEqRecd [] [recd1;recd2] in
      let tMono = createMonoRule info sortl retTypFun in
      let monoAx = mkVarTTyp (liDconRecdMonoEq sortRecd) tMono in
        [Sig_datacon_typ
           (liDconRecdMonoEq sortRecd, [], tMono, None, Public, None, None,[])], monoAx
    else
      [], mkVarTTyp (liDconRecdMonoEq sortRecd) dummyTyp in
  let inst = {ProofState.Records.sort=sortRecd; 
              ProofState.Records.fnames=fields; 
              ProofState.Records.fsorts=fieldSorts; 
              ProofState.Records.projAxs=projAxs; 
              ProofState.Records.eqAxs=eqAxs; 
              ProofState.Records.monoAx=monoAx} in 
  let _ = ProofState.Records.addInstantiation inst in 
    (sigelts@seMono, ctorDef::ops)



let genDiseqs info (sort:sort)
                   (j:dconid)
                   (typArgSorts:sort list)
                   (allArgSorts:sort list)
                   (l:(dconid * (sort list)) list)
    : sigelt list * ops =

  let typsOfTiil = List.map (fun tii -> typOfTi (tiOfSort tii)) in

  let aTyps = typsOfTiil allArgSorts in
  let al = List.mapi (fun i t -> mkFormDom (spr "a%d" (i+1)) t) aTyps in
  let dc1 = ProofState.DataConstructors.nameOfDconid j in
  let afds,aes = List.unzip al in
  let constructed1 = mkDconApp (mkVarT ( (liOfSl dc1))) [] aes in
  let symDc1 = ProofState.Z3Symbols.symOfDconinst (j, typArgSorts) in 
  let lenA = List.length aTyps in
  let aBvs = List.mapi
    (fun i sort -> BoundV (lenA - 1 - i, sort))
    allArgSorts in
  let tm1 = App (symDc1, Array.of_list aBvs) in

  let doOneSigelt (j',allArgSorts') =
    let bTyps = typsOfTiil allArgSorts' in
    let bl = List.mapi (fun i t -> mkFormDom (spr "b%d" (i+1)) t) bTyps in
    let (bfds,bes) = List.unzip bl in
    let dc2 = ProofState.DataConstructors.nameOfDconid j' in
    let tEqT = eqtypOfSort info sort in (* mkTypConst (liEqTyp tii) in *)
      (* omitting type parameters to data constructors *)
    let constructed2 = mkDconApp (mkVarT ( (liOfSl dc2))) [] bes in
    let tNeq =
      mkPfDepArrow (afds @ bfds)
        (mkPfNot (mkPfEq tEqT constructed1 constructed2)) in
    let neqId = ProofState.Disequalities.addDiseqAx 
                   (fun neqId -> mkVarTTyp (liDconNeq neqId sort) tNeq) in
    let sigelt =
      if !Options.extract_proofs 
      then [Sig_datacon_typ(liDconNeq neqId sort, [], tNeq, None, Public, None, None, [])]
      else [] in
    (* let lenA, lenB = List.length aTyps, List.length bTyps in *)
    (* let symDc1     = ProofState.Z3Symbols.symOfDconinst (j, typArgSorts) in *)
    (* let symDc2     = ProofState.Z3Symbols.symOfDconinst (j', typArgSorts) in *)

    (* let op = *)
    (*   if lenA + lenB = 0 then *)
    (*     (Assume (Not (Eq (App (symDc1, [||]), App (symDc2, [||]))), *)
    (*                  None, *)
    (*                  ANeq (neqId, sort))) *)
    (*   else *)
    (*     let syms  = Array.of_list (List.map (fun (bvd, t) -> 
           ProofState.Z3Symbols.qvarOfBvd bvd t (sortOfTyp t)) (afds @ bfds)) in *)
    (*     let sorts = Array.of_list (allArgSorts @ allArgSorts') in *)
    (*     let bBvs = *)
    (*       List.mapi *)
    (*         (fun i sort -> BoundV (lenB - 1 - i, sort)) *)
    (*         allArgSorts' in *)
    (*     let aBvs = *)
    (*       List.mapi *)
    (*         (fun i sort -> BoundV (lenB + lenA - 1 - i, sort)) *)
    (*         allArgSorts in *)
    (*     (Assume (Forall ([], sorts, syms, *)
    (*                          Not (Eq (App (symDc1, Array.of_list aBvs), *)
    (*                                   App (symDc2, Array.of_list bBvs)))), *)
    (*                  None, *)
      (*                  ANeq (neqId, sort))) *)
      sigelt in
    
  let sigelts = List.fold_left(fun elts x -> let l1 = doOneSigelt x in elts@l1) [] l in
  let kindFun = spr "kind%d"  sort in
  let syms = Array.of_list (List.map (fun (bvd, t) -> ProofState.Z3Symbols.qvarOfBvd bvd t (sortOfTyp t)) afds) in
  let sorts = Array.of_list allArgSorts in
  let tm = Forall([], sorts, syms, Eq(App(kindFun, [|tm1|]), Integer (List.length l))) in
  let op = Assume(tm, Some "diseq", mkAid AKUser) in (* TODO: Change this to a ANeq id for proof extraction *)
    sigelts, [op]
    
(* Creates FStar principles and Z3 ops for an equatable typinst.
   Does not drill recursively and process equatable sub-typinsts.
   Call this on a typinst that has already been determined to be equatable.
 *)
let rec processEquatableTypinst (info:info) (ti:typinst) : sigelt list * ops =
  let sort = ProofState.TypInsts.addTypinst ti in 
  let sigelts = [] in 
  let ops = [(DefSort(sort, Some (Pretty.strTyp (typOfTi ti))));
             (DefPred (predNameOfSort sort, [| sort |], None))] in
    
  let moreSigelts, moreOps = match ti with
    | TIMono(i) when (ssl (ProofState.TypeConstructors.nameOfSort i)) = "Prims.bool" -> 
        (* adding Prims.True, Prims.False, and their disequality manually
           since these constructors do not appear directly in prims.fst *)
        let tEqBool = eqtypOfSort info sort in (* mkTypConst (liEqTyp tii) in *)
        let tNeqBool = mkPfNot (mkPfEq tEqBool expTrue expFalse) in
        let sigelt =
          Sig_datacon_typ
            (liDconNeqBool, [], tNeqBool, None, Public, None, None, []) in
        let _ = ProofState.Disequalities.setNeqBool (mkVarTTyp liDconNeqBool tNeqBool) in
        let ops =
          [(DefFun (stringPrimsTrue, [||], sort, None));
           (DefFun (stringPrimsFalse, [||], sort, None));
           (Assume (inSort sort (FreeV(stringPrimsTrue, sort)), None, AOther));
           (Assume (inSort sort (FreeV(stringPrimsFalse, sort)), None, AOther));
           (Assume (Not (Eq (termTrue, termFalse)),
                        None,
                        ANeqBool))] in
        [sigelt], ops

    | TIMono(i) when (ssl (ProofState.TypeConstructors.nameOfSort i)) = "Prims.unit" -> 
        let tEqBool = eqtypOfSort info sort in 
        let tNeqBool = mkPfNot (mkPfEq tEqBool expTrue expFalse) in
        let unitVal = (DefFun (stringPrimsUnit, [||], sort, None)) in
        let unitIsUnit = (Assume(inSort sort (FreeV(stringPrimsUnit, sort)),
                                     None, AOther)) in
        let oneUnit = (Assume(Forall ([], [| sort; sort |], [| "x"; "y" |],
                                           (Imp(And(inSort sort (BoundV(0, sort)), 
                                                    inSort sort (BoundV(1, sort))),
                                                Eq(BoundV(0, sort), BoundV(1, sort))))), 
                                  None, AOther)) in
        [], [unitVal; oneUnit; unitIsUnit]

    | TIPoly(i,til) -> (* push instantiation to its datacons *)
        let sorts = List.map sortOfTi til in
          if not (ProofState.TypeConstructors.tryAddInstantiation i sorts) then [], [] //already instantiated
          else if not (ProofState.TypeConstructors.isUniform i) then raise Impos 
          else 
            let _ = DebugLog.Log (spr "Processing instantiation: %s\n" (Pretty.strTyp (typOfTi ti))) in
            let dconids = ProofState.TypeConstructors.dconIdsOfSort i in
            let monoSigelts, dconOps, neqSigelts, neqOps, _ =
              List.fold_left
                (fun (monoSigelts,
                      dconOps,
                      neqSigelts,
                      neqOps,
                      dconsArgTyps) j ->
                   let dconName = ProofState.DataConstructors.nameOfDconid j in     
                   let (l1,l2,allArgSortsOpt) = processDconinst info j i sorts in
                   let ((l3,l4),l5) =
                     (match allArgSortsOpt with
                        | None -> ([], []), []
                      (* explain sorts are the type parameter actuals,
                         allArgSorts are the term parameter types after substituting
                         the type actuals! *)
                        | Some(allArgSorts) -> 
                            let kindFun = DefFun(spr "kind%d" sort, [| sort |], intSort, None) in
                            let sigelts, ops = genDiseqs info sort j sorts allArgSorts dconsArgTyps in
                              (sigelts, kindFun::ops), [(j,allArgSorts)]) in
                   (monoSigelts @ l1,
                    dconOps @ l2,
                    neqSigelts @ l3,
                    neqOps @ l4,
                    dconsArgTyps @ l5)
                )
                ([],[],[],[],[])
                dconids
            in
              (monoSigelts @ neqSigelts, dconOps @ neqOps)
      

    | TITuple(ti1,ti2) -> [], processTupleInst info sort ti1 ti2

    | TIRecordMono(i) ->
        let fields, typs = ProofState.Records.fieldNamesAndTypsOfSort i |> sortByFieldName |> List.split in
        let til = List.map tiOfTyp typs in
        processRecordInst info sort i fields til

    | _ -> [], []
  in
  (sigelts@moreSigelts, ops@moreOps)
    

(* Processes typinst recursively, returning new sigelts and ops for all
   equatable types that have not been processed before. *)
and processForEquatableTypinsts (info:info) (ti:typinst) : list<sigelt> * ops =
  match ProofState.TypInsts.sortOptOfTypinst ti with 
    | Some _-> [], [] (* already processed *)
    | _ -> match ti with
        | TIMono(_) -> (* all monomorphic tcons are equatable *)
            processEquatableTypinst info ti
        | TIPoly(_,l) ->
            let sigelts, ops = processListForEquatableTypinsts info l in
            let sortl = List.map sortOfTi l in
            (* if any of the parameter types is not equatable, then this
               instantiation of the polymorphic tcon is not equatable *)
            let moreSigelts, moreOps = processEquatableTypinst info ti in
                 (sigelts@moreSigelts, ops@moreOps)
        | TITuple(ti1,ti2) ->
            let sigelts, ops = processListForEquatableTypinsts info [ti1;ti2] in
            let moreSigelts, moreOps = processEquatableTypinst info ti in
                   (sigelts@moreSigelts, ops@moreOps)
        | TIRecordMono(i) ->
            let fields, ts = ProofState.Records.fieldNamesAndTypsOfSort i |> sortByFieldName |> List.split  in
            let til = List.map tiOfTyp ts in
           // let sortl = List.map sortOfTi til in
            let sigelts, ops = processListForEquatableTypinsts info til in
            let moreSigelts, moreOps = processEquatableTypinst info ti in
              (sigelts@moreSigelts, ops@moreOps)
        | TITVar _ -> [], []

and processListForEquatableTypinsts info (l:typinst list)
    : sigelt list * ops =
  List.fold_left (fun (acc1,acc2) ti ->
    let l1,l2 = processForEquatableTypinsts info ti in acc1@l1, acc2@l2)
     ([],[]) l


and processDconinst info (di:dconid) (ti:tconid) (targSorts:sort list) 
    : sigelt list * ops * (sort list) option =

  (* argTyps, retTyp of dcon as it was defined *)
  let uniform = ProofState.TypeConstructors.isUniform ti in 
  let argPolyTyps, retPolyTyp, typBvdefs  = ProofState.DataConstructors.destructType di in
 
  let targTis       = List.map tiOfSort targSorts in
  let targTyps      = List.map typOfTi targTis in
  let tsubst        = if uniform then List.zip typBvdefs targTyps else [] in

  (* argTyps, retTyp of dcon instantiated with type params *)
  let argTyps       = List.map (fun t -> Absyn.substitute_l t tsubst) argPolyTyps in
  let retTyp        = Absyn.substitute_l retPolyTyp tsubst in
  let retArgsTis    = List.map tiOfTyp (retTyp::argTyps) in

    (* NIK: Sigelts contains monomorphic monotonicity principles for 
            the dataconstructors of any instantiated types in retArgsTil.
            TODO: Make this polymorphic and generate only one mono principle for a dcon.
            Note, Ops will continue to contain monomorphic function symbols for dcons in retargstil. *)
    let sigelts, ops  = processListForEquatableTypinsts info retArgsTis in

    let retArgsSorts  = List.map sortOfTi retArgsTis in
    let retSort, argsSorts = List.hd retArgsSorts, List.tl retArgsSorts in

    let dconLi = liOfSl (ProofState.DataConstructors.nameOfDconid di) in 
    let monoSigelt, monoAx =
      if (List.length argTyps = 0) || (not !Options.extract_proofs) || not uniform then [], None
      else  
        let retTypFun xs ys =
          let dc = mkVarTTyp dconLi (ProofState.DataConstructors.typOfDconid di) in 
            (* TODO omitting type parameters ok? *)
          let data1 = mkDconApp dc [] xs in
          let data2 = mkDconApp dc [] ys in
            mkTypApp (eqtypOfSort info retSort) [] [data1;data2] in
        let mono = createMonoRule info argsSorts retTypFun in
        let monoLi = liDconMonoDconinst (di,targSorts) in
        let monoAx = Some (mkVarTTyp monoLi mono) in
        let se = Sig_datacon_typ (monoLi, [], mono, None, Public, None, None, []) in
          (* let _ = pr "Generated mono principle (%s)\n %A\n" (Pretty.strSigelt se) se in *)
          [se], monoAx in
    let dcname = ProofState.Z3Symbols.symOfDconinst (di,targSorts) in
    let injectivityOps = 
        if argsSorts = [] then []
        else 
          let nvars, formals = List.fold_left (fun (i, out) sort -> let out = (spr "x%d" i)::out in (i+1, out)) (0, []) argsSorts in
          let ntoz = Util.list0N (nvars - 1) |> List.rev in
          let allArgSorts, allArgNames = argsSorts |> Array.ofList, formals |> Array.ofList in
          let tm = App(dcname, List.map2 (fun dbIx sort -> BoundV(dbIx, sort)) ntoz argsSorts |> Array.ofList) in
          let ops = List.fold_left2 (fun out i sort -> 
                                       let invName = spr "%s_inv%d" dcname i in
                                       let invOp = DefFun(invName, [| retSort |], sort,  Some "injectivity") in
                                       let ax = Assume(Forall([], allArgSorts, allArgNames, Eq(App(invName, [|tm|]), BoundV(i, sort))), None, mkAid AKUser) in
                                         ax::invOp::out) [] ntoz argsSorts in
            ops in
    let moreOps = (* NIK: Ok, this is good. Adding a monomorphic version of the datacon as a function symbol in Z3 *)
      [(Comment (spr "dconinst: %s" (longStrOfDconinst (di,targSorts))));
       (DefFun (dcname, Array.of_list argsSorts, retSort, None))]@
        injectivityOps in
    let inst = {ProofState.DataConstructors.monoAx=monoAx;
                ProofState.DataConstructors.retSort=retSort} in
    let _ = ProofState.DataConstructors.addInstantiation (di, targSorts) inst in   
      (* TODO need FStar dcon for injectivity *)
      (sigelts@monoSigelt, ops@moreOps, Some argsSorts)
        
  

//(****************************************************************************)
//(* PRINT AUTO-GENERATED PRINCIPLES                                          *)
//(****************************************************************************)
//
//let dumpAutoGenSigs_ oc =
//  let printCaption s = log oc (spr "\n(********** %s **********)\n" s) in
//  let printDcon li t =
//    log oc (spr "\n  | %s : %s\n" (sli li) (Pretty.strTyp t)) in
//  let printVal li t = 
//    log oc (spr "\nval %s : %s\n" (sli li) (Pretty.strTyp t)) in
//  log oc "\n(* Typ_unknown means that element was not generated *)\n";
//    List.iter (fun sort -> printCaption (Pretty.strTyp (typOgSort sort)))
//              ProofState.TypInsts.allSorts;
//    List.iter (fun (propid, name) -> 
//                  printCaption (spr "Proposition %d %s" propid (ssl name)))
//              ProofState.Props.allProps;
//    List.iter (fun (dc          
//    Ht.iter DconInsts.dconMono (fun (di,tiil) dconMono ->
//                                  printCaption (spr "DconInst %s" (longStrOfDconinst (di,tiil)));
//                                  printDcon (liDconMonoDconinst (di,tiil)) dconMono.sort);
//    Ht.iter TupleInsts.argTiis 
//      (fun tii _ ->
//         let tii1, tii2  = Ht.find TupleInsts.argTiis tii in
//           printCaption (spr "TupleInst: %d = (%d, %d)" tii tii1 tii2));
//    Id.iter Fields.idTable (fun fieldid sl ->
//                              printCaption (spr "Field %d = %s" fieldid (ssl sl)));
//    Ht.iter RecordInsts.fieldTiil (fun tii tiil ->
//                                     let fields = Ht.find RecordInsts.fieldnames tii in
//                                       printCaption (spr "RecordInst %d = %s"
//                                                       tii (String.concat ", " (List.map soi tiil)));
//                                       List.iter (fun field ->
//                                                    let j = Id.getId Fields.idTable (slOfLi field) in
//                                                    let proj = AutoAxioms.recdProj (tii,j) in
//                                                    let eq   = AutoAxioms.recdEq (tii,j) in
//                                                      printDcon proj.v proj.sort;
//                                                      printDcon eq.v eq.sort
//                                                 ) fields;
//                                       let mono = AutoAxioms.recdMonoEq tii in
//                                         printDcon mono.v mono.sort
//                                  );
//    printCaption "Disequalities";
//    let neqBool = !Disequalities.neqBool in
//      printDcon neqBool.v neqBool.sort;
//      Ht.iter Disequalities.dcon (fun i dc -> printDcon dc.v dc.sort);
//      ()
//        
//let dumpAutoGenSigs oc =
//  try dumpAutoGenSigs_ oc
//  with _ -> log oc "\n\n(* STOPPING DUMP *)\n\n"
//
//let printTables () = dumpAutoGenSigs stdout
//
//let printAutoGenSigsToFile () =
//  let streamAutoGen = new System.IO.StreamWriter(spr "%s/autogen.f9" !queries) in
//  dumpAutoGenSigs streamAutoGen;
//  streamAutoGen.Flush (); streamAutoGen.Close ();
//  ()

