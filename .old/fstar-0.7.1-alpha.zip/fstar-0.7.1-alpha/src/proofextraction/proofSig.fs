(* Modified by Nikhil Swamy; May, July 2010 *)
(*
  Copyright (c) 2009, Regents of the University of California

  Authors: Ravi Chugh
  
  All rights reserved.
  
  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following 
  conditions are met:
  
  1. Redistributions of source code must retain the above copyright 
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above 
  copyright notice, this list of conditions and the following disclaimer 
  in the documentation and/or other materials provided with the distribution.

  3. Neither the name of the University of California, San Diego, nor 
  the names of its contributors may be used to endorse or promote 
  products derived from this software without specific prior 
  written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
  CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
  PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
  PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
  LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
  SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*)


#light "off"

module Microsoft.FStar.ProofSig

open Absyn
open AbsynUtils
open ProofExp
open ProofCommon
open ProofCombinators
open Util
open Profiling 
open KindAbbrevs

let skipSigeltMessage = "not_handling_this_sigelt"

let patsOfSigelt = function 
 | Sig_datacon_typ(_,_,_,Some _,_,_,_,((_::_) as pats)) -> Some pats
 | _ -> None

let rec patternInfo info t = match (try_strip_pf_typ t).v with 
    | Typ_fun(Some bvd, t1, t2) 
    | Typ_dtuple([(Some bvd, t1); (_, t2)]) -> 
        let id = bvd.realname in 
        let envn = Tcenv.push_local_binding info.envn (Tcenv.Binding_var(id, t1)) in
        let binders = id.idText::info.binders in
        let info = {binders=binders; envn=envn} in
            patternInfo info t2
    | _ -> info
let doProcessSigelt (info:info) : (sigelt -> string * list<sigelt> * ops) = 
 "Proof.doProcessSigelt" ^^ lazy function
    | Sig_tycon_kind(li,ts,k0,false,_,_) when (sli li <> "Prims.NTuple") -> 
      ProofState.setCurMod (Tcenv.current_module info.envn);
      let title = spr "tycon_%s" (sli li) in
      let k = Tcenv.tycon_kind_from_tparams ts k0 in
      let tconid = ProofState.TypeConstructors.addTyp (slOfLi li) k in
      if tconIsEquatable k && isMonomorphic k then 
          let ti = TIMono tconid in
          let sigelts, ops = processEquatableTypinst info ti in
          let sort = sortOfTi ti in
          let op = DefFun (spr "kind%d" sort, [| sort |], intSort, None) in 
            title, sigelts, op::ops
      else  
         title, [], []

  (* to force a tuple or record type to be processed as equatable,
     must provide an explicit type abbreviation that has no remaining
     type parameters. *)
  | Sig_typ_abbrev(li,[],_,t) -> 
      ProofState.setCurMod (Tcenv.current_module info.envn);
      let title = spr "typ_abbrev_%s" (sli li) in
      let t = Tcenv.expand_typ_rec info.envn t in (* expand abbreviated typ *)
      let ti = tiOfTyp t in
      (* let _ = pr "(tiOfTyp (%s)) = %A\n" (Pretty.strTyp t) ti in *)
      let sigelts, ops = processForEquatableTypinsts info ti in
        title, sigelts, ops

  | Sig_record_typ(li,ts,_,{v=Typ_record(l,_);sort=_;p=_},_) -> 
      ProofState.setCurMod (Tcenv.current_module info.envn);
      let title = spr "typ_record_typ_%s" (sli li) in
      let recdName = slOfLi li in 
      let isExtern = (List.hd recdName) = "__Extern" in 
      let fnt_l = List.map (fun (f, t) -> (f, Tcenv.expand_typ_rec info.envn t)) l in 
      let recdconid = ProofState.Records.addRecord recdName fnt_l isExtern in 
      (* let _ = pr "Processing record %s got recdcondid %d\n" (sli li) recdconid in  *)
      if List.length ts = 0 then 
        let sigelts, ops = processForEquatableTypinsts info (TIRecordMono recdconid) in
        (* let _ = pr "Added equatable tinsts for recdcondid %d\n" recdconid in   *)
           title, sigelts, ops
      else 
        (* let _ = pr "Skipping equatable tinsts for recdcondid %d; has parameters %A\n" recdconid ts in   *)
          title, [], [] (* TODO handle polymorphic records *)

  (* proposition *)
  | Sig_tycon_kind(li,[],Kind_tcon(Some _, _, _), _,_,_) as se -> 
        Util.warn "Delaying polymorphic proposition %s\n" (sli li);
        spr "prop_%s" (sli li) , [], [(Delayed se)]

  | Sig_tycon_kind(li,[],k,true,_,_) ->
      ProofState.setCurMod (Tcenv.current_module info.envn);
      let title = spr "prop_%s" (sli li) in
      let ts = List.map (Tcenv.expand_typ_rec info.envn) (typArgsOfKind k) in
      let tis = List.map tiOfTyp ts in
      let sigelts, ops = processListForEquatableTypinsts info tis in
      let sorts = List.map sortOfTi tis in
      let moreSigelts, moreOps = processProp info li sorts in
        (title, sigelts@moreSigelts, ops@moreOps)

  (* user-supplied assumption *)
  | Sig_query(li, t) (* already proved query, can use as a lemma for future queries. TODO: fix wrt proof extraction *)
  | Sig_ghost_assume(li, t, _)
  | Sig_datacon_typ(li,[],t,Some _,_,_,_, _) as se -> begin
      ProofState.setCurMod (Tcenv.current_module info.envn);
      let pats = patsOfSigelt se in
      let patInfo = patternInfo info t in 
      let patTerms = bind_opt pats 
        (fun pats -> Some (stmap pats (fun pat -> (match pat with  
                                                     | Inl t -> (typToTerm patInfo t)
                                                     | Inr e -> (expToTerm patInfo e))
                                         >> (function 
                                               | None -> failwith "Untranslatable pattern"
                                               | Some e -> ret e)))) in
      let title = spr "assumption_%s" (sli li) in
      let t = Tcenv.expand_typ_rec info.envn t in
       match t.v with 
          | Typ_univ _ -> (* second-order assumption; not handled for now. *)
              Util.warn "Delaying 2nd order assumption %s\n" (sli li);
              title, [], [(Delayed se)]
          | _ -> 
              let aid =
                (match mkAid AKUser with
                   | AUser i -> AUser i
                   | _ -> raise (Never "aid user")) in
              let t = stripPfT t in
              let tmAndPats = 
                (typToTerm info t) >> (fun tmOpt -> 
                 match patTerms with 
                    | None -> ret (tmOpt, None)
                    | Some stPatTerm -> stPatTerm >> (fun patTerms -> ret (tmOpt, Some patTerms))) in
              let (tmopt, patTerms), stenv = runState ProofCommon.emptyEnv tmAndPats in 
              let ops = (match tmopt with 
                           | Some tm ->  
                                let tm = addPattern tm patTerms in 
                                 [Assume (tm, Some (sli li), aid)]
                           | None   -> bgWarn (spr "cannot axiomatize assumption %s\n;   %s" 
                                                 (sli li) (strTyp t))) in
                title, stenv.sigelts, ops@stenv.ops 
    end

  (* ordinary data constructor *)
  | Sig_datacon_typ(li,tps,t,None,_,_,_,_) -> 
      ProofState.setCurMod (Tcenv.current_module info.envn);
      let name = slOfLi li in 
      let title = spr "datacon_%s" (sli li) in
        if checkIfProofConstructor (sli li) then title, [], []
        else if Const.is_tuple_data_lid li then title, [], []
        else 
          let t = pushTparamsIntoTyp tps t in
          let t = Tcenv.expand_typ_rec info.envn t in
          let argTyps, retTyp, typBvdefs = flattenArrowTyp t in
          let tconid = ProofState.TypeConstructors.sortOfName (slOfLi (tconOfTyp retTyp)) in
          let wasUniform = ProofState.TypeConstructors.isUniform tconid in 
          let dconid = ProofState.DataConstructors.addConstructor name t tconid in
            if (ProofState.TypeConstructors.isMonomorphic tconid ||
                  not (ProofState.TypeConstructors.isUniform tconid))
            then  (* TODO: generalize for polymorphism *)
              let ti_sigelts, ti_ops = 
                if wasUniform then (* We've decided that ti is a GADT and that we're going to monomorphize it *)
                  let ti = TIMono tconid in
                  let sigelts, ops = processEquatableTypinst info ti in
                  let sort = sortOfTi ti in
                  let op = DefFun (spr "kind%d" sort, [| sort |], intSort, None) in 
                    sigelts, op::ops
                else [], [] in 
              let sigelts, ops, allArgSortsOpt = processDconinst info dconid tconid [] in
              let otherConstrs = ProofState.DataConstructors.constructorsOfTyp tconid |> 
                  List.map (fun (dc, ts) -> 
                              let sortOpts = List.map sortOptOfTyp ts in
                                if existsNone sortOpts then None
                                else Some(dc, projSomes sortOpts)) in 
              let otherConstrs = List.filter (function Some _ -> true | None -> false) otherConstrs |> projSomes in
              let neqSigelts, neqOps =
                (match allArgSortsOpt with 
                   | None -> [], []
                   | Some(allArgSorts) -> 
                       let retSort = sortOfTi (TIMono tconid) in 
                         genDiseqs info retSort dconid [] allArgSorts otherConstrs) in
                title, ti_sigelts @ sigelts @ neqSigelts, ti_ops @ ops @ neqOps
            else
              title, [], []
                  
  | Sig_value_decl(li,t) when List.hd (slOfLi li) <> "ProofLib" -> 
      ProofState.setCurMod (Tcenv.current_module info.envn);
      let title = spr "value_decl_%s" (sli li) in
      let t = Tcenv.expand_typ_rec info.envn t in
        (match tiOptOfTyp t with 
            | None -> skipSigeltMessage, [], []
            | Some ti -> 
                let sigelts, ops = processForEquatableTypinsts info ti in
                let funsym = match sortOptOfTi ti with 
                    | None -> []
                    | Some s -> 
                        let sym = sli li in
                         [(DefFun(sym, [||], s, None));
                          (Assume(inSort s (FreeV(sym, s)), None, AOther))] in
                title, sigelts, ops@funsym)

  | _ -> skipSigeltMessage, [], []
