#light "off"

module Microsoft.FStar.ProofState

open Microsoft.FStar
open Absyn
open AbsynUtils
open ProofCommon
open Profiling
open Util
open KindAbbrevs

type name = list<string>
    let cm = ref None
let setCurMod {Sugar.lid=(m::_)} = cm := Some (m:ident).idText
let curMod () = match !cm with 
  | Some s -> s
  | None -> raise (Bad "curMod unset")

module BiMap = struct

  type 'a t = int ref
      * (int, 'a) Hashtbl.t 
      * ('a, int) Hashtbl.t 
      * string 
      * ('a -> string)

  let index ((i, _, _, _, _):'a t) = !i
  let create i s f = ref i, Hashtbl.create 17, Hashtbl.create 17, s, f

  let addVal ((k,ht1,ht2,_,_):'a t) (x:'a) : int =
    if Hashtbl.mem ht2 x then Hashtbl.find ht2 x
    else (incr k; let i = !k in Hashtbl.add ht1 i x; Hashtbl.add ht2 x i; i)

  let getVal ((_,ht1,_,s,_):'a t) i =
    if Hashtbl.mem ht1 i then Hashtbl.find ht1 i
    else failwith (spr "IdTable.getVal: %d not in table %s" i s)
  let getValOpt ((_,ht1,_,s,_):'a t) i =
    if Hashtbl.mem ht1 i then Some (Hashtbl.find ht1 i)
    else None

  let getId ((_,_,ht2,s,f):'a t) (x:'a) =
    if Hashtbl.mem ht2 x then Hashtbl.find ht2 x
    else failwith (spr "IdTable.getId: %s not in table %s" (f x) s)

  let getIdOpt ((_,_,ht2,s,f):'a t) (x:'a) =
    if Hashtbl.mem ht2 x then Some (Hashtbl.find ht2 x)
    else None

  let iter ((_,ht1,_,_,_):'a t) f = Hashtbl.iter f ht1

  let clear ((k,ht1,ht2,_,_):'a t) =
    Hashtbl.clear ht1;
    Hashtbl.clear ht2;
    k := 0

  let mem ((_,_,ht2,_,_):'a t) = Hashtbl.mem ht2
  let containsKey ((_,ht1,_,_,_):'a t) = Hashtbl.mem ht1
  let containsValue = mem 

end

(* Stack of contexts used in several modules below *)
module IStack = struct
  type 'a t = list<'a> ref
  exception EmptyStack 

  let newStack () = ref []
  let peekOpt s = match !s with 
    | [] -> None
    | hd::tl -> Some hd
  let peek s = match !s with 
    | [] -> raise EmptyStack
    | hd::tl -> hd
  let push s x = s := x::!s
  let pop s = match !s with 
      hd::tl -> s := tl; hd
    | _ -> raise Impos 
  let size c = List.length !c
  let clear s = s := []

  let exists s f = List.exists f !s
  let iter s f = List.iter f !s
  let tryFind s f = List.tryFind f !s
    
  let mapFirst s f = 
    let rec aux = function
      | [] -> None
      | hd::tl -> match f hd with Some x -> Some x | None -> aux tl in
      aux !s

  let mustMapFirst s f err = 
    match mapFirst s f with 
      | None -> err ()
      | Some x -> x

  let fold ctx f env = List.fold_left f env !ctx
end

(****************************************************************************)
(* Various stateful modules                                                 *)
(****************************************************************************)
type polyinst = {plid:lident; pkind:kind; targs:list<typ>; mkind:kind; mlid:lident;} 
module Ops = struct 
    type context = {ops:ops ref;
                    delayedOps:ops ref;
                    polyInsts: list<polyinst> ref}
    let newContext () = {ops = ref []; delayedOps=ref []; polyInsts=ref []}
    let contexts = IStack.newStack ()
    let push _ = IStack.push contexts (newContext())
    let pop _ = IStack.pop contexts
    let clear _ = IStack.clear contexts 
    let init _ = push ()

    let storeOps ops = 
        let ctx = IStack.peek contexts in 
           ctx.ops := !ctx.ops@ops

    let storeDelayedOps ops = 
        let ctx = IStack.peek contexts in 
           ctx.delayedOps := !ctx.delayedOps@ops

    let getOps () = 
        IStack.fold contexts (fun out ctx -> !ctx.ops@out) []
    
    let getDelayedOps () = 
        IStack.fold contexts (fun out ctx -> !ctx.delayedOps@out) []

    let storePolyInsts insts = 
        let ctx = IStack.peek contexts in 
           ctx.polyInsts := !ctx.polyInsts@insts

    let getPolyInsts () =  
        IStack.fold contexts (fun out ctx -> !ctx.polyInsts@out) []
end

(* String literals are given unique ids *)
module StringConstants = struct
  type context = {idTable:BiMap.t<string>}
  let contexts = IStack.newStack ()
  let newContext i = {idTable=BiMap.create i "Strings.idTable" id}
  let push _ = 
    let i = match IStack.peekOpt contexts with 
        | None -> 0 
        | Some c -> BiMap.index c.idTable in
    IStack.push contexts (newContext i)
  
  let pop _ = IStack.pop contexts
  let clear _ = IStack.clear contexts 
  let init _ = push ()

  let addString s = 
    let ctx = IStack.peek contexts in 
      (*pr "Adding string %s at Query %d\n" s (queryCount());*)
      BiMap.addVal ctx.idTable s

  let stringOfId id = 
    let aux ctx = BiMap.getValOpt ctx.idTable id in
      IStack.mustMapFirst contexts aux 
        (fun () ->  raise (Translation (spr "String id %d is not a string constant" id)))
  
  let idOptOfString s = 
      let aux ctx = BiMap.getIdOpt ctx.idTable s in
      IStack.mapFirst contexts aux 

  let idOfString s = match idOptOfString s with 
    | Some s -> s
    | None -> raise (Translation (spr "String id %s is not a string constant" s))
end

(****************************************************************************)

module Records = struct
  type rctx<'a> = Ht.t<recdconid, 'a>
  type fctx<'a> = Ht.t<fieldid, 'a>
  type ictx<'a> = Ht.t<sort, 'a>
  type ifctx<'a> = Ht.t<sort*fieldid, 'a>

  (* TODO this assumes that fields of extern records are not polymorphic *)
  type context = {idTable: BiMap.t<list<string>>;
                  fieldTyps : rctx<list<(fieldname*typ)>>;
                  fieldIds: BiMap.t<list<string>>;
                  firstFieldToRecd: fctx<recdconid>;
                  isExtern : rctx<bool>;
                  recordInsts : icontext}
  and icontext = { fieldSorts : ictx<list<sort>>;
                   fieldNames : ictx<list<fieldname>>;
                   retSorts   : ictx<sort>;     
                   dconMonoEq : ictx<var<typ>>;
                   dconProj   : ifctx<var<typ>>;
                   dconEq     : ifctx<var<typ>> } 
  let contexts = IStack.newStack ()
  let newContext () = 
    let i = {fieldSorts = Ht.create "RecordInsts.fieldSorts" soi;
             fieldNames = Ht.create "RecordInsts.fieldNames" soi;
             retSorts = Ht.create "RecordInsts.retSorts" soi;
             dconProj = Ht.create "RecordInsts.dconProj" (fun (i,j) -> spr "%d,%d" i j);
             dconEq = Ht.create "RecordInsts.dconEq" (fun (i,j) -> spr "%d,%d" i j);
             dconMonoEq = Ht.create "RecordInsts.dconMonoEq" soi} in
    let k1, k2 = match IStack.peekOpt contexts with 
        | None -> 0, 0
        | Some c -> BiMap.index c.idTable, BiMap.index c.fieldIds in
      {idTable =BiMap.create k1 "Records.idTable" ssl;
       fieldTyps = Ht.create "Records.fieldsTyps" soi;
       fieldIds = BiMap.create k2 "Fields.idTable" ssl;
       firstFieldToRecd = Ht.create "Fields.recdId" soi;
       isExtern = Ht.create "Records.Externs" soi;
       recordInsts = i} 
  let push _ = IStack.push contexts (newContext())
  let pop _ = IStack.pop contexts
  let clear _ = IStack.clear contexts
  let init () = push ()

    

  let fieldnameOfFieldId fid = 
    let aux ctx = BiMap.getValOpt ctx.fieldIds fid in
      IStack.mustMapFirst contexts aux 
        (fun () -> raise (Bad_sort (spr "Unknown field id %d" fid)))

  let fieldTypsOfSort s =
    let aux ctx = Ht.findOpt ctx.fieldTyps s in
      IStack.mustMapFirst contexts aux 
        (fun () -> raise (Bad_sort (spr "Sort %d is not a record" s)))

  let isExtern s = 
    let aux ctx = Ht.findOpt ctx.isExtern s in
      match IStack.mapFirst contexts aux with 
        | Some _ -> true
        | None -> false 

  let lidOfSort s =  
    let aux ctx = BiMap.getValOpt ctx.idTable s in
      IStack.mustMapFirst contexts aux 
        (fun () -> raise (Bad_sort (spr "Sort %d is not a record" s)))
        |> liOfSl 

  let sortOfLid lid = 
    let name = slOfLi lid in   
    let aux ctx = BiMap.getIdOpt ctx.idTable name in
      IStack.mapFirst contexts aux
        
  (* ------------------------------ External interface ------------------------------ *)
  let addRecord name fnt_l isExtern = 
    let ctx = IStack.peek contexts in
    let recdconid = BiMap.addVal ctx.idTable name in
    let _ = Ht.add ctx.fieldTyps recdconid fnt_l in
    let fieldids = 
      fnt_l |> List.map (fun (fn, _) -> BiMap.addVal ctx.fieldIds (slOfLi fn)) in
    let _ = Ht.add ctx.firstFieldToRecd (List.hd fieldids) recdconid in
    let _ = Ht.add ctx.isExtern recdconid isExtern in
      recdconid

  let idOfName n = 
    let aux ctx = BiMap.getIdOpt ctx.idTable n in
    IStack.mustMapFirst contexts aux
        (fun () -> raise (Translation (spr "No id for record %s" (ssl n))))

  let typOfSort s = mkTypConst ((lidOfSort s))
    
  let sortOptOfTyp (t:typ) = match t.v with 
      Typ_const(x, _) ->  sortOfLid x.v 
    | _ -> None

  let projAxiom sort fieldId =
    let aux ctx = Ht.findOpt ctx.recordInsts.dconProj (sort, fieldId) in
      IStack.mustMapFirst contexts aux 
        (fun () -> raise (Bad_sort (spr "Invalid sort/field (%A)" (sort, fieldId))))

  let eqAxiom sort fieldId =
    let aux ctx = Ht.findOpt ctx.recordInsts.dconEq (sort, fieldId) in
      IStack.mustMapFirst contexts aux 
        (fun () -> raise (Bad_sort (spr "Invalid sort/field (%A)" (sort, fieldId))))

  let monoAxiom sort  =
    let aux ctx = Ht.findOpt ctx.recordInsts.dconMonoEq sort in
      IStack.mustMapFirst contexts aux 
        (fun () -> raise (Bad_sort (spr "Invalid sort %d" sort)))

  let fieldName fieldid = 
    let aux ctx = BiMap.getValOpt ctx.fieldIds fieldid in
      IStack.mustMapFirst contexts aux 
        (fun () -> raise (Bad_sort (spr "Field id %d not found" fieldid)))

  let fieldId name = 
    let aux ctx = BiMap.getIdOpt ctx.fieldIds name in
      IStack.mustMapFirst contexts aux
        (fun () -> raise (Bad_sort (spr "Field name %s not found" (ssl name))))

  type inst = {sort:sort;
               fnames:list<fieldname>;
               fsorts:list<sort>;
               projAxs:list<fieldid * var<typ>>;
               eqAxs:list<fieldid * var<typ>>;
               monoAx:var<typ>}

  let addInstantiation i = 
    let ctx = IStack.peek contexts in
      Ht.add ctx.recordInsts.fieldSorts i.sort i.fsorts;
      Ht.add ctx.recordInsts.fieldNames i.sort i.fnames;
      Ht.add ctx.recordInsts.dconMonoEq i.sort i.monoAx;
      List.iter (fun (fid, pax) -> Ht.add ctx.recordInsts.dconProj (i.sort, fid) pax) i.projAxs;
      List.iter (fun (fid, eax) -> Ht.add ctx.recordInsts.dconEq (i.sort, fid) eax) i.eqAxs
        
  let fieldNamesAndTypsOfSort s = 
    let ctx = IStack.peek contexts in 
    let aux ctx = Ht.findOpt ctx.fieldTyps s in 
      IStack.mustMapFirst contexts aux
        (fun () -> raise (Bad_sort (spr "No field types for sort %d" s)))
end

(****************************************************************************)

module Props = struct
  type context = BiMap.t<name>
  let contexts:IStack.t<context> = IStack.newStack () 
        
  let newContext k = BiMap.create k (spr "Props.idTable_%d" (IStack.size contexts)) ssl
  let push _ = 
     let k = match IStack.peekOpt contexts with 
        | None -> 0
        | Some c -> BiMap.index c in
     IStack.push contexts (newContext k)
  let pop _ = IStack.pop contexts
  let clear _ = IStack.clear contexts
  let init () = push ()

  let existsSort sort = IStack.exists contexts (fun tab -> BiMap.containsKey tab sort) 
  let existsName name = IStack.exists contexts (fun tab -> BiMap.containsKey tab name)

  let nameOptOfSort sort = IStack.mapFirst contexts (fun tab -> BiMap.getValOpt tab sort)
  (* ------------------------------ External interface ------------------------------ *)

  let addProp name = BiMap.addVal (IStack.peek contexts) name 
  let nameOfId pid = 
    match nameOptOfSort pid with
        None -> raise (Bad_sort (spr "Prop %d not found" pid))
      | Some n -> n

  let idOptOfName name = IStack.mapFirst contexts (fun tab -> BiMap.getIdOpt tab name)

  let idOfName n = 
    match idOptOfName n with
        None -> raise (Bad_sort (spr "Prop %s not found" (ssl n)))
      | Some s -> s
end

(****************************************************************************)

module TypeConstructors = struct
  type ctx<'a> = Ht.t<tconid, 'a>
  type instantiation = list<sort>
  type context = {idTable: BiMap.t<list<string>>;
                  dconIds: ctx<list<dconid>>;
                  instantiations: ctx<list<instantiation>>;
                  kinds: ctx<kind>;
                  uniform: ctx<bool>}
  let contexts:IStack.t<context> = IStack.newStack ()
  let newContext () =  
    let n = IStack.size contexts in 
    let k = match IStack.peekOpt contexts with 
        | None -> 0
        | Some c -> BiMap.index c.idTable in
    let ctx = {idTable = BiMap.create k (spr "Tcons.idTable_%d" n) ssl;
               dconIds = Ht.create (spr "Tcons.dconIds_%d" n) soi;
               instantiations = Ht.create (spr "Tcons.insts_%d" n) soi;
               kinds = Ht.create (spr "Tcons.kinds_%d" n) soi;
               uniform = Ht.create (spr "Tcons.uniform_%d" n) soi} in
      ctx
  let push _ = IStack.push contexts (newContext())
  let pop _ = IStack.pop contexts
  let clear _ = IStack.clear contexts
  let init () = push ()

  let addConstructor tconid dconid = 
    let ctx = IStack.peek contexts in 
      match Ht.findOpt ctx.dconIds tconid with 
        | None -> Ht.add ctx.dconIds tconid [dconid]
        | Some l -> Ht.replace ctx.dconIds tconid (dconid::l)

  let sortOptOfName n = 
    let aux ctx = BiMap.getIdOpt ctx.idTable n in
      IStack.mapFirst contexts aux 

  let alreadyInstantiated sort i = 
    let aux ctx = 
      match Ht.findOpt ctx.instantiations sort with 
        | Some insts -> 
            if List.exists (fun j -> i=j) insts 
            then Some true
            else None
        | _ -> None in 
      IStack.mustMapFirst contexts aux (fun () -> false)

  (* ------------------------------ External interface ------------------------------ *)
  let addTyp name k = 
    let ctx = IStack.peek contexts in 
    let sort = BiMap.addVal ctx.idTable name in
    let _ = Ht.add ctx.kinds sort k in 
    let _ = Ht.add ctx.uniform sort true in 
      sort
  
  let kindOfSort s = 
    let aux ctx = Ht.findOpt ctx.kinds s in 
    IStack.mustMapFirst contexts aux 
        (fun () -> raise (Bad_sort (spr "Sort %d does not map to a type constructor" s)))

  let tagAsNonUniform sort = 
    let ctx = IStack.peek contexts in 
    let _ = Ht.add ctx.uniform sort false in 
        ()

  let nameOfSort s =
    let aux ctx = BiMap.getValOpt ctx.idTable s in
      IStack.mustMapFirst contexts aux 
        (fun () -> raise (Bad_sort (spr "Sort %d does not map to a type constructor" s)))

  let sortOfName n = 
    match sortOptOfName n with 
        None -> raise (Bad_sort (spr "No sort for name %s" (ssl n))) 
     |  Some s -> s

  let typOfSort s =
    let sl = nameOfSort s in
      mkTypConst ((liOfSl sl))

  let sortOptOfTyp (t:typ) = match t.v with 
    | Typ_const(x, _) -> sortOptOfName (slOfLi x.v) 
    | _ -> None

  let dconIdsOfSort sort = 
    let allDcons = IStack.fold contexts 
      (fun dcons ctx -> 
         match Ht.findOpt ctx.dconIds sort with 
             Some l -> dcons@l
           | None -> dcons) [] in
      allDcons 

  let isMonomorphic sort = 
    let k = kindOfSort sort in 
        isMonomorphic k 

  let isUniform sort = 
    let aux ctx = Ht.findOpt ctx.uniform sort in
      IStack.mustMapFirst contexts aux 
        (fun () -> raise (Bad_sort (spr "Sort %d" sort)))

  let tryAddInstantiation sort i = 
    if alreadyInstantiated sort i then false
    else 
      let ctx = IStack.peek contexts in 
      let _ = match Ht.findOpt ctx.instantiations sort with 
        | None -> Ht.add ctx.instantiations sort [i]
        | Some is -> Ht.add ctx.instantiations sort (i::is) in
        true
end


(****************************************************************************)

module DataConstructors = struct
  type ctx<'a> = Ht.t<dconid, 'a>
  type ictx<'a> = Ht.t<dconinst, 'a>
  type dctyp = {typ:typ; argTyps:list<typ>; retTyp:typ; bvds:list<btvdef>; tconid:tconid}
  type instantiation = {monoAx: option<var<typ>>;
                        retSort: sort}

  type context = {idTable: BiMap.t<list<string>>;
                  sort:    ctx<sort>;
                  typ:     ctx<dctyp>;
                  insts:   ictx<instantiation>}
  let contexts:IStack.t<context> = IStack.newStack ()

  let newContext () =  
    let n = IStack.size contexts in 
    let k = match IStack.peekOpt contexts with 
        | None -> 0
        | Some c -> BiMap.index c.idTable in
    let ctx = {idTable = BiMap.create k (spr "Dcons.idTable_%d" n) ssl;
               typ =  Ht.create (spr "Dcons.idTable_%d" n) soi;
               sort = Ht.create (spr "Dcons.tconId_%d" n) soi;
               insts = Ht.create (spr "Dcons.Insts_%d" n) strOfDconinst} in
      ctx

  let push _ = IStack.push contexts (newContext())
  let pop _ = IStack.pop contexts
  let clear _ = IStack.clear contexts
  let init () = push ()

  let dctyp d = 
    let aux ctx = Ht.findOpt ctx.typ d in
      IStack.mustMapFirst contexts aux
        (fun () -> raise (Bad_sort (spr "No type for dcon %d" d)))

  let instOfDconinst di = 
    let aux ctx = Ht.findOpt ctx.insts di in
      IStack.mustMapFirst contexts aux
        (fun i -> raise (Bad_sort (spr "No inst for dconinst %A" di)))

  (* ------------------------------ External interface ------------------------------ *)
  let addConstructor name typ tconid = 
    let ctx = IStack.peek contexts in
    let argTyps, retTyp, bvds = flattenArrowTyp typ in 
    let dctyp = {typ=typ; argTyps=argTyps; retTyp=retTyp; bvds=bvds; tconid=tconid} in
    let dconid = BiMap.addVal ctx.idTable name in
    let _ = Ht.add ctx.typ dconid dctyp in 
    let _ = TypeConstructors.addConstructor tconid dconid in
    let k = TypeConstructors.kindOfSort tconid in 
    let targs = targsOfKind k in
    if (List.length bvds) <> (List.length targs) then TypeConstructors.tagAsNonUniform tconid;
      dconid

  let monoAxiom dconinst = 
    let aux ctx = Ht.findOpt ctx.insts dconinst in
      match IStack.mapFirst contexts aux with 
          None -> None
        | Some v -> v.monoAx

  let nameOfDconid d = 
    let aux ctx = BiMap.getValOpt ctx.idTable d in
      match IStack.mapFirst contexts aux with 
          Some sl -> sl   
        | None -> raise (Translation (spr "Dcon id %d does not correspond to a data constructor" d))
  
  let idOptOfName n = 
    let aux ctx = BiMap.getIdOpt ctx.idTable n in
        IStack.mapFirst contexts aux

  let idOfName n = match idOptOfName n with 
    | None -> raise (Translation (spr "No id of Dcon %s" (ssl n)))
    | Some id -> id
    
  let typOfDconid d = 
    let dt = dctyp d in dt.typ

  let destructType d = 
    let dt = dctyp d in (dt.argTyps, dt.retTyp, dt.bvds)

  let addInstantiation di i = 
    let ctx = IStack.peek contexts in 
      Ht.add ctx.insts di i

  let retSortOfDconinst di = 
    let i = instOfDconinst di in i.retSort

  let constructorsOfTyp tcon = 
    let dconids = TypeConstructors.dconIdsOfSort tcon in 
      List.map (fun dc -> dc, (dctyp dc).argTyps) dconids

  let isUniform dconid = 
    let dct = dctyp dconid in
      TypeConstructors.isUniform dct.tconid
end

(****************************************************************************)

module Tuples = struct
  type context = Ht.t<sort, sort*sort> 
    let contexts = IStack.newStack ()
  let newContext () =  Ht.create "TupleInsts.argTiis" soi
  let push _ = IStack.push contexts (newContext())
  let pop _ = IStack.pop contexts
  let clear _ = IStack.clear contexts
  let init () = push ()

  let addInstantiation sort (sort1:sort, sort2:sort) = 
    let ctx = IStack.peek contexts in
      Ht.add ctx sort (sort1, sort2) 

  let argSorts sort = 
    let aux ctx = Ht.findOpt ctx sort in
      IStack.mustMapFirst contexts aux
        (fun () -> raise (Bad_sort (spr "Tuple sort %d not found" sort)))
end

(****************************************************************************)

module Disequalities = struct
  type context = {map:Ht.t<int, var<typ>>;
                  neqBool:option<var<typ>> ref;
                  restoreCtr:int}

  let counter : int ref = ref 0
  let newContext () = {map=Ht.create "Disequalities.dcon" soi;
                       restoreCtr = !counter;
                       neqBool = ref None} 
  let contexts = IStack.newStack ()
  let push _ = IStack.push contexts (newContext())
  let pop _ = 
    let ctx = IStack.pop contexts in
      counter := ctx.restoreCtr

  let clear _ = IStack.clear contexts; counter := 0
  let init () = push ()

  let setNeqBool v = 
    let ctx = IStack.peek contexts in 
      match !ctx.neqBool with 
        | Some _ -> raise (Bad_sort "Neq bool already set")
        | _ -> ctx.neqBool := Some v

  let lookupNeqBool () = 
    let aux ctx = !ctx.neqBool in
      IStack.mustMapFirst contexts aux (fun () -> raise (Bad_sort "Neq bool not set"))
        
  let addDiseqAx mk_v = 
    let id = (incr counter; !counter) in
    let ctx = IStack.peek contexts in 
      Ht.add ctx.map id (mk_v id); id

        
end

(****************************************************************************)

module BoundTvars = struct
  type context = {sortToBvar: Ht.t<sort, btvar>;
                  bvarToSort: Ht.t<string, sort>} 
  let contexts = IStack.newStack ()
  let newContext _ = {sortToBvar = Ht.create "BoundTvars.SortToBvar" soi;
                      bvarToSort = Ht.create "BoundTvars.BvarToSort" id}
  let push _ = IStack.push contexts (newContext())
  let pop _ = IStack.pop contexts
  let clear _ = IStack.clear contexts
  let init () = push ()

  let sortCtr = ref -1 

  let lookupBvar s = 
    let aux ctx = if Ht.mem ctx.sortToBvar s 
    then Some (Ht.find ctx.sortToBvar s) 
    else None in
      IStack.mapFirst contexts aux

  let lookupSort bv =
    let aux ctx = let rn = bvar_real_name bv in
      if Ht.mem ctx.bvarToSort rn.idText 
      then Some (Ht.find ctx.bvarToSort rn.idText) 
      else None in
      IStack.mapFirst contexts aux

  let addBvar bv = 
    match lookupSort bv with
      | Some s -> s
      | _ -> 
          let ctx = IStack.peek contexts in
          let next = !sortCtr in 
            decr sortCtr; 
            Ht.add ctx.sortToBvar next bv;
            Ht.add ctx.bvarToSort ((bvar_real_name bv).idText) next;
            next 

  let typOfSort s = match lookupBvar s with 
    | Some v -> twithsort (Typ_btvar(v)) v.sort
    | None -> raise (Bad_sort (spr "Sort %d is not a type variable" s))
  let sortOptOfTyp (t:typ) = match t.v with 
    | Typ_btvar bv -> lookupSort bv
    | _ -> None
end 

(****************************************************************************)

module Uvars = struct
  type context = {sortToUvar: Ht.t<sort, uvar>;
                  uvarToSort: Ht.t<string, sort>} 
  let strOfUvar = soi -<- Unionfind.uvar_id
  let contexts = IStack.newStack ()
  let newContext _ = {sortToUvar = Ht.create "BoundTvars.SortToBvar" soi;
                      uvarToSort = Ht.create "BoundTvars.BvarToSort" id}
  let push _ = IStack.push contexts (newContext())
  let pop _ = IStack.pop contexts
  let clear _ = IStack.clear contexts
  let init () = push ()

  let sortCtr = ref -1 

  let lookupUvar s = 
    let aux ctx = if Ht.mem ctx.sortToUvar s
    then Some (Ht.find ctx.sortToUvar s) 
    else None in
      IStack.mapFirst contexts aux

  let lookupSort uv =
    let aux ctx = 
      if Ht.mem ctx.uvarToSort (strOfUvar uv)
      then Some (Ht.find ctx.uvarToSort (strOfUvar uv))
      else None in
      IStack.mapFirst contexts aux

  let addUvar uv = 
    match lookupSort uv with
      | Some s -> s
      | _ -> 
          let ctx = IStack.peek contexts in
          let next = !sortCtr in 
            decr sortCtr; 
            Ht.add ctx.sortToUvar next uv;
            Ht.add ctx.uvarToSort (strOfUvar uv) next;
            next 

  let typOfSort s = match lookupUvar s with 
    | Some uv -> twithsort (Typ_uvar(uv, Kind_star)) Kind_star 
    | None -> raise (Bad_sort (spr "Sort %d is not a type variable" s))

  let sortOptOfTyp (t:typ) = match t.v with 
    | Typ_uvar(uv,_) -> lookupSort uv
    | _ -> None

  let opsForUvars () : ops= 
    IStack.fold contexts 
      (fun out ctx -> 
         Ht.fold (fun sort _ out ->
                    let sortPred = (DefPred(predNameOfSort sort, [| sort |], None)) in
                    let ops =  [sortPred;DefSort(sort, None)] in 
                      ops@out)
           ctx.sortToUvar out) []
      
end 


(****************************************************************************)

module TypInsts = struct
  type ctx<'a> = Ht.t<sort, 'a>
  type context = {idTable : BiMap.t<typinst>;
                  modname : ctx<string>} 

  let contexts:IStack.t<context> = IStack.newStack ()
  let newContext () =  
    let n = IStack.size contexts in 
    let k = match IStack.peekOpt contexts with 
        | None -> 0
        | Some c -> BiMap.index c.idTable in
    let ctx = {idTable = BiMap.create k (spr "TypInsts.idTable_%d" n) strTypinst;
               modname = Ht.create (spr "TypInsts.modname_%d" n) soi} in
      ctx
  let push _ = IStack.push contexts (newContext())
  let pop _ = IStack.pop contexts
  let clear _ = IStack.clear contexts
  let init () = push ()

  let addTypinst ti = 
    let ctx = IStack.peek contexts in 
    let curMod = curMod () in 
    let sort = BiMap.addVal ctx.idTable ti in
    let _ = Ht.add ctx.modname sort curMod in
      sort

  let moduleOfSort s =
    let aux ctx = Ht.findOpt ctx.modname s in
      match IStack.mapFirst contexts aux with 
          None -> raise (Bad_sort (spr "Module of sort %d not found" s))
        | Some m -> m

  let sortOptOfTypinst ti = 
    let aux ctx = BiMap.getIdOpt ctx.idTable ti in
      match ti with 
        | TITVar s -> (match BoundTvars.lookupBvar s with 
                         | Some _ -> Some s
                         | _ -> None) 
        | _ -> IStack.mapFirst contexts aux

  let typinstOfSort s = 
    let aux ctx = BiMap.getValOpt ctx.idTable s in
      match BoundTvars.lookupBvar s with 
          Some _ -> TITVar s 
        | _ ->  match IStack.mapFirst contexts aux with
              Some ti -> ti 
            | _ -> raise (Bad_sort (spr "Sort %d does not map to a typinst" s))
end

open Microsoft.Z3
type ctx = Microsoft.Z3.Context


(****************************************************************************)
(* Z3 CONTEXT                                                               *)
(****************************************************************************)
let ctr = ref 0
type z3 = {ctx:Context; solver:Solver}
let z3:z3 ref = ref {ctx=null; solver=null}
let disposeZ3 () = 
  if (!z3).ctx = null then ()
  else ((!z3).ctx.Dispose(); 
        z3 := {ctx=null; solver=null})

let seed = 
  let s = spr "%d" (System.DateTime.Now.Second) in
  (* let _ = pr "Seed is %s\n" s in *)
    s

let new_z3 () = 
  let options = [("SOFT_TIMEOUT", Options.getZ3Timeout());
                 ("AUTO_CONFIG", "false");
                 ("MBQI", "false");
                 ("MODEL", "true");
                 ("MODEL_ON_TIMEOUT", "true");
                 ("RELEVANCY", "2");
                 ("ARRAY_DELAY_EXP_AXIOM", "false");
                 ("ARRAY_EXTENSIONAL", "false");
                 ("RANDOM_SEED", seed)] in 
  let cfg = new System.Collections.Generic.Dictionary<string,string>() in 
  let _ = options |> List.iter (fun (k,v) -> cfg.Add(k,v)) in 
  let ctx = new Context(cfg) in
    z3:={ctx=ctx;solver=ctx.MkSolver()}

(*
    ignore (par.SetParamValue("SOFT_TIMEOUT", Options.getZ3Timeout())); 
    ignore (par.SetParamValue("MBQI", "false")); 
    ignore (par.SetParamValue("ELIM_BOUNDS", "true"));
    ignore (par.SetParamValue("NG_LIFT_ITE", "2"));
    ignore (par.SetParamValue("PHASE_SELECTION", "0"));
    ignore (par.SetParamValue("PI_USE_DATABASE", "true"));
    ignore (par.SetParamValue("PROPAGATE_BOOLEANS", "true"));
    ignore (par.SetParamValue("QI_EAGER_THRESHOLD", "5"));
    ignore (par.SetParamValue("QI_LAZY_THRESHOLD", "20"));
    ignore (par.SetParamValue("QI_MAX_EAGER_MULTI_PATTERNS", "10"));
    ignore (par.SetParamValue("RESTART_FACTOR", "1.5"));
    ignore (par.SetParamValue("RESTART_STRATEGY", "0"));
    ignore (par.SetParamValue("QI_EAGER_THRESHOLD", "0")); 
    ignore (par.SetParamValue("RANDOM_SEED", seed));
    ignore (par.SetParamValue("PROOF_MODE", "0")));
 *)       

(****************************************************************************)
(* TO AND FROM Z3 FUNCTION SYMBOLS                                          *)
(****************************************************************************)
module Z3Symbols = struct
  (* calling one of the symOf functions registers the mapping from a Z3
     function symbol to the expression that it names. *)
  type ctx<'a> = Ht.t<string, 'a>
  type tuplectx = {tupleconstr: ctx<sort>;
                   tupleproj1: ctx<sort>;
                   tupleproj2: ctx<sort>}
  type recordctx = {recconstr: ctx<sort>;
                    recprojs:  ctx<sort*fieldid>}
  type context = {props: ctx<propid>;
                  dcons: ctx<dconinst>;
                  strings: ctx<int>;
                  symQvar: Ht.t<string, bvvdef*typ>; (* Written in ProofCombinators; read by ProofExtract in various places *)
                  tuples: tuplectx;
                  records: recordctx;
                  idents: ctx<sort>}
  let contexts = IStack.newStack ()
  let newContext () = 
    let tctx = {tupleconstr = Ht.create "symOfTuple" id;
                tupleproj1 = Ht.create "symOfTupleProj1" id;
                tupleproj2 = Ht.create "symOfTupleProj2" id} in
    let rctx = {recconstr = Ht.create "symOfRecd" id;
                recprojs = Ht.create "symOfRecdProj" id} in
      {props = Ht.create "symToPropid" id;
       dcons = Ht.create "symToDconinst" id;
       strings = Ht.create "symToString" id;
       idents = Ht.create "symToSort" id;
       symQvar = Ht.create "symQvar" id;
       tuples = tctx;
       records = rctx}
  let push _ = IStack.push contexts (newContext())
  let pop _ = IStack.pop contexts
  let clear _ = IStack.clear contexts
  let init () = push ()

  let (symOfPropid : propid -> string),
    (propidOfSym : string -> propid option) =
    (fun propid ->
       let sym = Props.nameOfId propid |> ssl in
       let ctx = IStack.peek contexts in
         Ht.add ctx.props sym propid; sym),
    (fun s ->
       let aux ctx = Ht.findOpt ctx.props s in
         IStack.mapFirst contexts aux)

  let (symOfDconinst : dconinst -> string),
    (dconinstOfSym : string -> dconinst option) =
    (fun (i,js) ->
       let s = String.concat "-" (List.map strSort js) in
       let sym = spr "%s_%s" (ssl (DataConstructors.nameOfDconid i)) s in
       let ctx = IStack.peek contexts in 
         Ht.add ctx.dcons sym (i,js); sym),
    (fun sym -> 
       let aux ctx = Ht.findOpt ctx.dcons sym in
         IStack.mapFirst contexts aux)

  let (symOfTuple : sort -> string),
    (symOfTupleProj1 : sort -> string),
    (symOfTupleProj2 : sort -> string),
    (tupleCtorOfSym : string -> sort option),
    (tupleProj1OfSym : string -> sort option),
    (tupleProj2OfSym : string -> sort option) =
    (fun sort -> 
       let sym = spr "Tup_tii%d" sort in 
       let ctx = IStack.peek contexts in
         Ht.add ctx.tuples.tupleconstr sym sort; sym),
    (fun sort -> 
       let sym = spr "TupProj_tii%d_1" sort in 
       let ctx = IStack.peek contexts in 
         Ht.add ctx.tuples.tupleproj1 sym sort; sym),
    (fun sort -> 
       let sym = spr "TupProj_tii%d_2" sort in
       let ctx = IStack.peek contexts in 
         Ht.add ctx.tuples.tupleproj2 sym sort; sym),
    (fun sym -> 
       let aux ctx = Ht.findOpt ctx.tuples.tupleconstr sym in
         IStack.mapFirst contexts aux),
    (fun sym -> 
       let aux ctx = Ht.findOpt ctx.tuples.tupleproj1 sym in
         IStack.mapFirst contexts aux),
    (fun sym -> 
       let aux ctx = Ht.findOpt ctx.tuples.tupleproj2 sym in
         IStack.mapFirst contexts aux)

  let (symOfRecd : sort -> string),
    (symOfRecdProj : sort -> fieldid -> string),
    (recdCtorOfSym : string -> sort option),
    (recdProjOfSym : string -> (sort * fieldid) option)  =
    (fun sort -> 
       let sym = spr "Recd_%d" sort in 
       let ctx = IStack.peek contexts in 
         Ht.add ctx.records.recconstr sym sort; sym),
    (fun sort j ->
       let fieldname = Records.fieldnameOfFieldId j in
       let sym = spr "RecdProj_%d_%s" sort (ssl fieldname) in // (Id.getVal Fields.idTable j)) in
  let ctx = IStack.peek contexts in
    Ht.add ctx.records.recprojs sym (sort, j); sym),
  (fun sym -> 
     let aux ctx = Ht.findOpt ctx.records.recconstr sym in
       IStack.mapFirst contexts aux),
  (fun sym -> 
     let aux ctx = Ht.findOpt ctx.records.recprojs sym in
       IStack.mapFirst contexts aux)


let (symOfIdent : ident -> sort -> string),
    (identSortOptOfSym : string -> sort option) =
  (fun id sort ->
     let sym = id.idText in
     let ctx = IStack.peek contexts in 
       Ht.add ctx.idents sym sort; sym), 
  (fun sym -> 
      let aux ctx = Ht.findOpt ctx.idents sym in
       IStack.mapFirst contexts aux)

let (symOfString : string -> string),
    (stringidOfSym : string -> int option) =
  let ht1 = Ht.create "symToString" id in
  (fun s ->
     let i = StringConstants.idOfString s in
     let sym = spr "str_%s" (s.Replace(' ','_')) in
     let ctx = IStack.peek contexts in 
        Ht.add ctx.strings sym i; sym), 
  (fun sym -> 
     let aux ctx = Ht.findOpt ctx.strings sym in 
     IStack.mapFirst contexts aux)

let qvarOfBvd (fd:bvvdef) (typ:typ) (sort:sort)  : string =
  let sym = symOfIdent (real_name fd) sort in
  let ctx = IStack.peek contexts in 
    Ht.add ctx.symQvar sym (fd, typ); 
    sym

let binderOptOfSym sym = 
  let aux ctx = Ht.findOpt ctx.symQvar sym in
    IStack.mapFirst contexts aux
     
end

(************************************************************************************)

(* module Extraction = struct *)
(*   type tmap<'a> = Ht.t<Term, 'a> *)
(*   type imap<'a> = Ht.t<int, 'a> *)
    
(*   type context = {idTerm: BiMap.t<Term>; *)
(*                   userAxiom: imap<lident*typ>; *)
(*                   varTermToSort: tmap<sort>;(\* Written in ProofZZZ.opToZ3; read by proofExtract (Ravi says:this is unreliable!) *\) *)
(*                   bgAssumeTerm: tmap<assumptionId>;(\* Written in ProofZZZ.opToZ3; read by ProofExtract._Asserted *\) *)
(*                   fgAssumeTerm: tmap<assumptionId>;(\* Written in ProofZZZ.opToZ3; read by ProofExtract._Asserted *\) *)
(*                   bindingVarIdToPf:imap<pfbinding>} (\* Written in ProofZZZ.processBinding; read by ProofExtract._Asserted *\) *)
(*       (\* Ravi says: since binding vars are not being reset in between queries, this table isn't being reset either *\) *)
(*   let contexts = IStack.newStack () *)
(*   let newContext _ =  *)
(*      let k = match IStack.peekOpt contexts with  *)
(*         | None -> 0 *)
(*         | Some c -> BiMap.index c.idTerm in *)
(*       { userAxiom=Ht.create "userAxiom" soi; *)
(*         bgAssumeTerm = Ht.create "bgAssumeTerm" strTerm; *)
(*         fgAssumeTerm = Ht.create "fgAssumeTerm" strTerm; *)
(*         varTermToSort = Ht.create "varTermToSort" strTerm; *)
(*         bindingVarIdToPf = Ht.create "bindingVarIdToPf" soi; *)
(*         idTerm = BiMap.create k "idTerm" strTerm} *)

(*   let push _ = IStack.push contexts (newContext()) *)
(*   let pop _ = IStack.pop contexts *)
(*   let clear _ = IStack.clear contexts *)
(*   let init () = push () *)

(*   let lookupTermId t = *)
(*     let aux ctx = BiMap.getIdOpt ctx.idTerm t in *)
(*       IStack.mapFirst contexts aux *)

(* (\* -------------------------------- External interface ---------------------------------------- *\)         *)
(*   let idOfTerm t =  *)
(*     match lookupTermId t with  *)
(*         Some id -> id *)
(*       | _ -> raise (Translation "No id for term") *)
          
(*   let termOfId id =  *)
(*     let aux ctx = BiMap.getValOpt ctx.idTerm id in *)
(*       IStack.mustMapFirst contexts aux *)
(*         (fun () -> raise (Translation "No term for id")) *)

(*   let addSortOfVar v s =  *)
(*     let ctx = IStack.peek contexts in  *)
(*       Ht.add ctx.varTermToSort v s *)

(*   let sortOfVar v =  *)
(*     let aux ctx = Ht.findOpt ctx.varTermToSort v in  *)
(*       IStack.mustMapFirst contexts aux *)
(*         (fun () -> raise (Translation "No sort for variable")) *)

(*   let addAssumption bg tm aid =  *)
(*     let ctx = IStack.peek contexts in *)
(*     let tab = if bg then ctx.bgAssumeTerm else ctx.fgAssumeTerm in *)
(*       Ht.add tab tm aid *)

(*   let bgAssumeOptOfTerm tm =  *)
(*     let aux ctx = Ht.findOpt ctx.bgAssumeTerm tm in  *)
(*       IStack.mapFirst contexts aux *)

(*   let fgAssumeOptOfTerm tm =  *)
(*     let aux ctx = Ht.findOpt ctx.fgAssumeTerm tm in  *)
(*       IStack.mapFirst contexts aux *)

(*   let addUserAxiom i lid t =  *)
(*     let ctx = IStack.peek contexts in  *)
(*       Ht.add ctx.userAxiom i (lid, t)  *)

(*   let userAxiom i = *)
(*     let aux ctx = Ht.findOpt ctx.userAxiom i in  *)
(*       IStack.mustMapFirst contexts aux *)
(*         (fun () -> raise (Translation (spr "User axiom not found"))) *)

(*   let addPfBinding i pb =  *)
(*     let ctx = IStack.peek contexts in  *)
(*       Ht.add ctx.bindingVarIdToPf i pb *)

(*   let pfBinding i =  *)
(*     let aux ctx = Ht.findOpt ctx.bindingVarIdToPf i in  *)
(*       IStack.mustMapFirst contexts aux *)
(*         (fun () -> raise (Translation (spr "Pf binding not found"))) *)

(*   (\* Assigns unique ids to Z3 Term and all its subterms. *\) *)
(*   let rec assignIdsToTerm t = *)
(*     match lookupTermId t with  *)
(*         Some _ -> () *)
(*       | _ ->      *)
(*           let _ = match (!z3).GetTermKind t with *)
(*             | TermKind.App         -> Array.iter assignIdsToTerm ((!z3).GetAppArgs t) *)
(*             | TermKind.Quantifier  -> assignIdsToTerm ((!z3).GetQuantifier t).Body *)
(*             | _                    -> () in *)
(*           let ctx = IStack.peek contexts in  *)
(*             BiMap.addVal ctx.idTerm t; () *)
(* end *)

(****************************************************************************)
(* External interface                                                       *)
(****************************************************************************)

let init () = 
    new_z3();
    Ops.init();
    StringConstants.init ();
    Records.init ();
    Props.init ();
    DataConstructors.init ();
    TypeConstructors.init ();
    TypInsts.init ();
    Tuples.init ();
    Disequalities.init ();
    BoundTvars.init ();
    Uvars.init ();
    Z3Symbols.init()

let push () = 
    if !Options.emulateContexts then new_z3() else (!z3).solver.Push(); 
    Ops.push();
    StringConstants.push ();
    Records.push ();
    Props.push ();
    DataConstructors.push ();
    TypeConstructors.push ();
    TypInsts.push ();
    Tuples.push ();
    Disequalities.push ();
    BoundTvars.push ();
    Uvars.push ();
    Z3Symbols.push ()


let pop () = 
    if !Options.emulateContexts then disposeZ3() else (!z3).solver.Pop(); //disposeZ3();
    ignore <| Ops.pop();
    ignore <| StringConstants.pop ();
    ignore <| Records.pop ();
    ignore <| Props.pop ();
    ignore <| DataConstructors.pop ();
    ignore <| TypeConstructors.pop ();
    ignore <| TypInsts.pop ();
    ignore <| Tuples.pop ();
    ignore <| Disequalities.pop ();
    ignore <| BoundTvars.pop ();
    ignore <| Uvars.pop ();
    ignore <| Z3Symbols.pop ()

let clear () = 
    disposeZ3();
    Ops.clear();
    StringConstants.clear ();
    Records.clear ();
    Props.clear ();
    DataConstructors.clear ();
    TypeConstructors.clear ();
    TypInsts.clear ();
    Tuples.clear ();
    Disequalities.clear ();
    BoundTvars.clear ();
    Uvars.clear ();
    Z3Symbols.push ()


