(* Modified by Nikhil Swamy; May, July 2010 *)
(*
  Copyright (c) 2009, Regents of the University of California

  Authors: Ravi Chugh
  
  All rights reserved.
   
  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following 
  conditions are met:
  
  1. Redistributions of source code must retain the above copyright 
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above 
  copyright notice, this list of conditions and the following disclaimer 
  in the documentation and/or other materials provided with the distribution.

  3. Neither the name of the University of California, San Diego, nor 
  the names of its contributors may be used to endorse or promote 
  products derived from this software without specific prior 
  written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
  CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
  PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
  PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
  LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
  SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*)


#light "off"

module Microsoft.FStar.ProofCommon

open System.Diagnostics
open System.Text.RegularExpressions
open Microsoft.Z3
open Microsoft.FStar
open Absyn
open AbsynUtils
open Util
open Profiling 
open KindAbbrevs

(* Some utilities (formerly proofUtils.fs) *)
exception Never of string
exception Bad_sort of string
exception Translation of string

module Ht = struct

  type ('a,'b) t = ('a,'b) Hashtbl.t * string * ('a -> string)

  let create s f : ('a,'b) t = (Hashtbl.create 17, s, f)

  let add ((ht,_,_):('a,'b) t) (k:'a) (v:'b) = Hashtbl.add ht k v

  let replace ((ht,_,_):('a,'b) t) (k:'a) (v:'b) = Hashtbl.replace ht k v

  let mem ((ht,_,_):('a,'b) t) (k:'a) = Hashtbl.mem ht k

  let iter ((ht,_,_):('a,'b) t) f = Hashtbl.iter f ht

  let fold f ((ht,_,_):('a,'b) t) x = Hashtbl.fold f ht x

  let find ((ht,s,f):('a,'b) t) (k:'a) =
    if Hashtbl.mem ht k then Hashtbl.find ht k
    else failwith (spr "Ht.find: %s not in table %s" (f k) s)
  
  let findOpt  ((ht,s,f):('a,'b) t) (k:'a) =
    if Hashtbl.mem ht k then Some (Hashtbl.find ht k)
    else None

  let clear ((ht,_,_):('a,'b) t) = Hashtbl.clear ht

  let remove ((ht,_,_):('a,'b) t) (x:'a) = Hashtbl.remove ht x

end


let strFlags l =
  String.concat "" (List.map (function true -> "1" | false -> "0") l)

let strIntList l = String.concat "" (List.map soi l)

let invertBijection l =
  List.map
    (fun i -> match findIdx i l with
                | Some j -> j+1
                | None   -> failwith "invertBijection: arg wasn't a bij")
    (list1N (List.length l))

let splitAntesAndGoal l =
  let l_rev = List.rev l in
  List.rev (List.tl l_rev), List.hd l_rev

let rec remove_deps t = match t.v with
      | Typ_dep(t, _) -> remove_deps t 
      | _ -> t 

(******************************************************************************************************)

let _ = Profiling.new_counter "Z3"
let _ = Profiling.new_counter "ProofZZZ.printCompactProof"
let _ = Profiling.new_counter "Proof.doProcessSigelt"
let _ = Profiling.new_counter "ProofExtract.termToTyp"
let _ = Profiling.new_counter "ProofExtract.termToExp"
let _ = Profiling.new_counter "ProofExtract.destructPats"
let _ = Profiling.new_counter "ProofExtract.synthesizeProof"

type ProofDebugLog() = class
(*   [<Conditional("DEBUG")>] *)
  static member Log (oc,s) = fpr oc "%s" s
end

let log oc s = ProofDebugLog.Log(oc,s)



let strTyp t = (Pretty.strTyp t).Replace('\n',' ')
let strExp e = (Pretty.strExp e).Replace('\n',' ')

let sli       = Pretty.str_of_lident
let strTerm   = fun _ -> "_(!z3).Term_"

let sortByFieldName l = 
  List.sortWith (fun (fn1, _) (fn2, _) -> let s1, s2 = sli fn1, sli fn2 in s1.CompareTo(s2)) l

(* let bumpQueryCount,  *)
(*     queryCount = *)
(*  let queryCount = ref 0 in *)
(*   (fun () ->  *)
(*       incr queryCount; *)
(*       pr "\n#############QUERY %d##################\n" !queryCount; !queryCount),  *)
(*   (fun () -> !queryCount) *)

(* let queries = ref "" *)
(* let set_queries () =  *)
(*     let q = spr "%s/bin/queries" (Util.get_fstar_home()) in *)
(*         queries := q; q *)

(* let queryFile ()        = spr "%s/query-%04d.smt" !queries (queryCount()) *)
let proofFile ()        = spr "%s/proof-%04d.txt" !queries (queryCount())
let longproofFile ()    = spr "%s/longproof-%04d.txt" !queries (queryCount())
let fineproofFile ()    = spr "%s/fineproof-%04d.f9" !queries (queryCount())
(* let streamQueries = ref null *)
(* let set_streamQueries ()    = *)
(*   let x = spr "%s/all.smt" !queries in *)
(*   let y =  *)
(*     if !Util.silent then System.IO.TextWriter.Null  *)
(*     else      *)
(*       (pr "%s\n" x; *)
(*        new System.IO.StreamWriter(spr "%s/all.smt" !queries) :> System.IO.TextWriter) in *)
(*     streamQueries := y *)
      
let stringPrimsTrue     = "Prims.True"
let stringPrimsFalse    = "Prims.False"
let stringPrimsUnit     = "Prims.unitval"
let strSortOther           = "other"

type tconid     = int
type dconid     = int
type fieldid    = int
type propid     = int
type recdconid  = int

type sort      = int
let intSort = -1
type dconinst   = dconid * sort list

type typinst =
  | TIMono    of tconid
  | TIPoly    of tconid * typinst list
  | TITuple   of typinst * typinst
  | TIRecordMono of recdconid
  | TITVar    of sort
  | TIUVar    of sort
  
let strSort s = 
  if !Options.newZ3encoding then 
    if s=1 then "Kind_sort"
    else if s=2 then "Type_sort"
    else if s=3 then "Term_sort" 
    else if s=intSort then "Int" 
    else spr "tii_%03d" s
  else
    if s >= 0 then spr "tii_%03d" s 
    else spr "bsrt_%03d" (-s) 
    
let strSortToSort s =
  let mre (re:Regex) = 
    let m = re.Match s in
    if m.Success then Some (ios (m.Groups.get_Item(1).Value))
    else None in 
  match mre (new Regex("^tii_([0-9][0-9][0-9])$")) with 
   | Some s -> s
   | _ -> match mre (new Regex("^bsrt_([0-9][0-9][0-9])$")) with
           | Some s -> -s
           | _ -> raise (Bad_sort (spr "Could not parse sort: %s" s))


type assumptionId =
  | AUser          of int
  | ABindingVar    of int
  | ABindingMatch  of int
  | ATupProj       of sort * int  (* 1 or 2 *)
  | ATupEq         of sort * int  (* 1 or 2 *)
  | ARecdProj      of sort * fieldid
  | ARecdEq        of sort * fieldid
  | ANeqBool
  | ANeq           of int * sort
  | AName          of string
  | AOther (*  remove this placeholder *)

let strOfAssumptionId = function
  | AUser i           -> spr "AUser %d" i
  | ABindingVar i     -> spr "ABindingVar %d" i
  | ABindingMatch i   -> spr "ABindingMatch %d" i
  | ATupProj(tii,i)   -> spr "ATupProj_%d %d" tii i
  | ATupEq(tii,i)     -> spr "ATupEq_%d %d" tii i
  | ARecdProj(tii,j)  -> spr "ARecdProj_%d_%d" tii j
  | ARecdEq(tii,j)    -> spr "ARecdEq_%d_%d" tii j
  | ANeqBool          -> "ANeqBool"
  | ANeq(i,tii)       -> spr "ANeq_%d_%d" i tii
  | AOther            -> "AOther"
  | AName s           -> s

type assumptionKind =
  | AKUser
  | AKBindingVar
  | AKBindingMatch
  | AKNeqBool

let mkAid =
  let next x = incr x; !x in
  let k1, k2, k3 = ref 0, ref 0, ref 0 in
  (function
     | AKUser           -> AUser (next k1)
     | AKBindingVar     -> ABindingVar (next k2)
     | AKBindingMatch   -> ABindingMatch (next k3)
     | _                -> raise (Never "mkAid"))

type caption = string

type term =
  | True
  | False
  | Integer  of int
  | BoundV   of int * sort
  | FreeV    of string * sort
  | App      of string * term array 
  | PolyApp  of Absyn.typ * Util.Disj<term, Absyn.typ> list
  | Not      of term
  | And      of term * term
  | Or       of term * term
  | Imp      of term * term
  | Iff      of term * term
  | Eq       of term * term
  | Forall   of pat list * sort array * string array * term  (* can make these scalars instead of arrays *)
  | Exists   of pat list * sort array * string array * term 
and pat = term

type op =
  | DefSort  of sort * option<caption>
  | DefPred  of string * sort array * caption option
  | DefFun   of string * sort array * sort * caption option
  | Assume   of term * caption option * assumptionId
  | Query    of term
  | Comment  of caption
  | Warning  of caption
  | Mark     of lident
  | Delayed  of Absyn.sigelt

type ops = list<op>

type info      = { envn: Tcenv.env;        binders: string list }
let inf e      = { envn = e;               binders = [] }
let emptyInfo  = { envn = Tcenv.empty_env; binders = [] }

type stenv = {ops:ops; sigelts:sigelts}
type st<'a> = Util.state<stenv, 'a>
let emptyEnv = {ops=[]; sigelts=[]}
let retOpt a = ret (Some a)
let addOps ops : st<unit> = get >> (fun stenv -> put {stenv with ops=ops@stenv.ops})
let addAndRet ops sigelts a : st<'a> = get >> (fun stenv ->
     put {stenv with ops=ops@stenv.ops; sigelts=sigelts@stenv.sigelts} >> (fun _ -> ret a)) 


let termTrue            = App (stringPrimsTrue, [||])
let termFalse           = App (stringPrimsFalse, [||])
let termUnit            = App (stringPrimsUnit, [||])

let fgComment s         = [Comment s]
let fgWarn s            = [Warning s]
let bgWarn s            = [Warning s]

let predNameOfSort s = spr "InSort_%s" (strSort s)
let inSort s t = App(predNameOfSort s, [| t |]) 
(* Ravi says: might not need this, if not doing anything with tupled proofs *)
(* TODO Nik: This is used in ProofExtract. Get rid of it. *)
type pfbinding =
  | BarePf of string
  | SndPf of string


(* Some utilities *)

let ssl (sl:string list) : string = String.concat "." sl

let rec strTypinst : typinst -> string =
  let strOfList l = String.concat "#" (List.map strTypinst l) in
  function
    | TIMono(i)     -> spr "TIMono_%d" i
    | TIPoly(i,l)   -> spr "TIPoly_%d<%s>" i (strOfList l)
    | TITuple(x,y)  -> spr "TITuple<%s#%s>" (strTypinst x) (strTypinst y)
    | TIRecordMono(i) -> spr "TIRecordMono_%d" i
    | TITVar tii -> spr "TITVar_%d" tii
    | TIUVar tii -> spr "TIUVar_%d" tii


let strOfDconinst ((i,js):dconinst) =
  spr "%d_%s" i (String.concat "#" (List.map strSort js))

let rec flatten_forall' (binders, pats) = function
    | Forall (pats', sorts, names, body) -> 
        flatten_forall' ((sorts, names)::binders, pats'@pats) body
    | f -> 
        let sorts, names = List.unzip (List.rev binders) in
        let pats = List.rev pats in
            Forall(pats, Array.concat sorts, Array.concat names, f) 
let flatten_forall fa =  flatten_forall' ([],[]) fa

let rec flatten_exists' (binders, pats) = function
    | Exists (pats', sorts, names, body) -> 
        flatten_exists' ((sorts, names)::binders, pats'@pats) body
    | f -> 
        let sorts, names = List.unzip (List.rev binders) in
        let pats = List.rev pats in
            Exists(pats, Array.concat sorts, Array.concat names, f) 
let flatten_exists ex = flatten_exists' ([],[]) ex  

let rec isMonomorphic k = match k(* .u *) with
    | Kind_erasable
    | Kind_prop
    | Kind_star 
    | Kind_affine -> true
    | Kind_dcon(_, _, k) -> isMonomorphic k
    | _ -> false

let targsOfKind k = 
   let rec aux out k = match k(* .u *) with
    | Kind_tcon(_, k1, k2) -> aux (k1::out) k2
    | Kind_dcon(_, _, k2) -> aux out k2
    | _ -> List.rev out in
 aux [] k
