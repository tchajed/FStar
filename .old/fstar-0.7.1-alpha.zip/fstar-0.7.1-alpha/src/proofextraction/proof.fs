(* Modified by Nikhil Swamy; May, July 2010 *)
(*
  Copyright (c) 2009, Regents of the University of California

  Authors: Ravi Chugh
  
  All rights reserved.
  
  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following 
  conditions are met:
  
  1. Redistributions of source code must retain the above copyright 
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above 
  copyright notice, this list of conditions and the following disclaimer 
  in the documentation and/or other materials provided with the distribution.

  3. Neither the name of the University of California, San Diego, nor 
  the names of its contributors may be used to endorse or promote 
  products derived from this software without specific prior 
  written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
  CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
  PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
  PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
  LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
  SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*)


#light "off"

module Microsoft.FStar.Proof
open Util
open Absyn
open AbsynUtils
open ProofCommon
open ProofZZZ
open ProofCombinators
open ProofExp
open ProofSig
open Profiling 
open KindAbbrevs

#if RISE4FUN
let init_state () = ()
let clear () = ()
let finish () = ()
let clear_gamma_cache () = ()
let process_sigelt : (Tcenv.env -> Absyn.sigelt -> list<Absyn.sigelt>) = fun e1 e2 -> []
let prove_and_extract : (Tcenv.env -> Absyn.typ -> bool * option<Absyn.exp'>) = fun e1 e2 -> (false, None)
let prove_eq_and_extract : (Tcenv.env -> Absyn.exp -> Absyn.exp -> bool * option<Absyn.exp'>) = fun e1 e2 e3 -> (false, None)
#else

let init_state () =  
    ProofState.clear ();
    ProofState.init (); 
    set_queries(); 
    set_streamQueries ()

let clear () = ProofState.clear ()

let finish () : unit =
 // printAutoGenSigsToFile ();
  (* ProofExtract.printStatsToFile (); *)
 // (!z3).Dispose ();
  stream_query (fun s -> s.Flush ()); 
  stream_query (fun s -> s.Close ())

let pb_ctr = Profiling.new_counter "Proof.process_binding"
let pbv_ctr = Profiling.new_counter "Proof.process_binding var"
let pbm_ctr = Profiling.new_counter "Proof.process_binding match"
let expt_ctr = Profiling.new_counter "Proof.process_binding expand_typ_rec"

let rec mkSortForTyp env t : option<(sort * list<Absyn.sigelt> * ops)> =     
    let sortOfAtomicMonoType env t = 
        let t' = Tcenv.expand_typ_rec env t in
        let ti = tiOfTyp t' in
         sortOfTyp t' in
//        if IdTable.mem TypInsts.idTable ti then sortOfTyp t', []
//        else 
//            let s = IdTable.processVal TypInsts.idTable ti in
//            let op = (BG, DefSort s) in
//                s, [op] in
//            try sortOfTyp t' with Bad_sort _  as e -> (pr "No sort for type %s\n" (Pretty.strTyp t'); raise e) in
    let rec getAtomicMonoType t = match t.v with 
        | Typ_btvar _ 
        | Typ_const _ -> Some t
        | Typ_dep(t, _) 
        | Typ_refine(_, t, _, _) -> getAtomicMonoType t 
        | Typ_app _  (* handled below *)
        | Typ_record _ 
        | Typ_dtuple _ 
        | Typ_fun _ (* These remaining ones should just not be translated to sorts *)
        | Typ_univ _
        | Typ_lam _  
        | Typ_affine _ 
        | Typ_uvar _
        | Typ_unknown -> None in
    let t = Tcenv.expand_typ_rec env (unrefine t) in
    let t = remove_deps t in
        (* match t.sort with  *)
        (*     Kind_affine -> None *)
        (*     | _ ->  *)
      match getAtomicMonoType t with
        | Some t -> Some(sortOfAtomicMonoType env t, [], [])
        | _ -> match t.v with
            | Typ_record(fnt_l,_) -> 
                failwith "Records not yet handled properly"
            | Typ_dtuple([(_, t1); (_, t2)]) ->  
                bind_opt (mkSortForTyps env [t1;t2])
                  (fun [(s1, ses1, tops1); (s2, ses2, tops2)] -> 
                     let ti = TITuple(tiOfSort s1, tiOfSort s2) in
                     let info = {envn=env; binders=[]} in
                     let ses, tops = processForEquatableTypinsts info ti in
                       Some(sortOfTi ti, ses1@ses2@ses, tops1@tops2@tops))
            | Typ_app _ -> 
                let tcon::targs = flattenTypApps t in
                  ProofState.setCurMod (Tcenv.current_module env);
                  let targs = List.map (Tcenv.expand_typ_rec env) targs in 
                    bind_opt (mkSortForTyps env targs)
                      (fun arg_sorts ->
                         let ti_t = tiOfTyp t in (* make this take a vmap and inst the sorts for targs as well*)
                         let info = {envn=env; binders=[]} in 
                         let sigelts, ops = processForEquatableTypinsts info ti_t in
                         let sigelts, ops = List.fold_left (fun (se, ops) (_, se', ops') -> se'@se, ops'@ops) 
                           (sigelts, ops) arg_sorts in
                           Some(sortOfTi ti_t, sigelts, ops))
            | _ -> None
and mkSortForTyps env ts : option<list<sort * list<Absyn.sigelt> * ops>> = 
  let rec aux out = function
    | hd::tl -> bind_opt (mkSortForTyp env hd) (fun i -> aux (i::out) tl) 
    | _ -> Some (List.rev out) in
    aux [] ts 

and predKindToSorts env k = 
  let rec aux (sorts, sigelts, ops) k = match k(* .u *) with
    | Kind_prop
    | Kind_erasable
    | Kind_star -> Some (Array.ofList (List.rev sorts), sigelts, ops)
    | Kind_dcon(_, t, k) -> 
        bind_opt (mkSortForTyp env t) (fun (sort, sigs, ops') -> 
          aux (sort::sorts, sigs@sigelts, ops'@ops) k) in
    aux ([],[],[]) k


let processBinding env binding : st<unit> = 
  let id2bvar id k = bvwithsort (mkbvd(id,id)) k in
  let thunk () = match binding with 
    | Tcenv.Binding_tmatch _ -> ret ()

    | Tcenv.Binding_typ (v, k) when base_kind k(* .u *) -> 
        let sort = ProofState.BoundTvars.addBvar (id2bvar v k) in 
        let sortPred = (DefPred(predNameOfSort sort, [| sort |], None)) in
         addOps [sortPred;DefSort(sort, None)]
            
    | Tcenv.Binding_typ (v, k) -> 
        let sort = ProofState.BoundTvars.addBvar (id2bvar v k) in
          (match predKindToSorts env k with 
             | None -> ret ()
             | Some (sorts, sigelts, ops) -> 
                 if List.length sigelts <> 0 then warn "Discarding sigelts gen'd during processBinding: %A\n" sigelts;
                 addOps ([DefPred (v.idText, sorts, Some "Quantified pred")]@ops))
                   
    (* | Tcenv.Binding_var(id,({v=_;sort=Kind_affine;p=_} as tt)) ->  *)
    (*     (match (normalizeRefinement tt).v with  *)
    (*        | Typ_refine(x, t, phi, _) ->  *)
    (*            (typToTerm (inf env) phi) >> (function  *)
    (*                  | None   -> let _ = pr "Couldn't convert refinement %s\n" (Pretty.strTyp phi) in  *)
    (*                              addOps <| fgWarn "can't convert refinement" *)
    (*                  | Some o -> addOps <| [(Assume (o, None, mkAid AKBindingVar))]) *)
    (*        | _ -> ret ()) *)
          
    | Tcenv.Binding_var(id,tt) -> 
          let defSymbolWithTyp uu = 
             try
              match mkSortForTyp env uu with
                | None -> [(Warning (spr "Ignoring variable %s; could not convert type %s\n" id.idText (Pretty.strTyp uu)))]
                | Some (sort, sigelts, ops) ->  
                    if List.length sigelts <> 0 then warn "Discarding sigelts gen'd during processBinding: %A\n" sigelts;
                    let uuSort = sortOfTyp uu in
                    let symName = ProofState.Z3Symbols.symOfIdent id uuSort in
                    let defFun = (DefFun (ProofState.Z3Symbols.symOfIdent id uuSort, [||], sort, None)) in
                    let sortFun = (Assume(inSort sort (FreeV(symName, sort)), None, AOther)) in
                    defFun::sortFun::ops
             with e -> pr "Unable to translate binding %s : %s :: %s \n%A\n" id.idText (Pretty.strTyp uu) (Pretty.strKind uu.sort) e; raise e in
          let tt = compress tt in
          let tt = Profiling.profile (fun () -> Tcenv.expand_typ_rec env tt) expt_ctr in
            (match (normalizeRefinement tt).v with
                 (* define new function symbol and assume refinement. *)
               | Typ_refine(bvd,uu,vv,_) -> 
                   let def = defSymbolWithTyp uu in
                   addOps def >> (fun _ -> 
                   let newe = bvdToExp (mkbvd (id,id)) tt in
                   let vv' = substitute_exp vv bvd newe in
                   (typToTerm (inf env) vv') >> (function 
                     | None   -> let _ = pr "Couldn't convert refinement %s\n" (Pretty.strTyp vv') in 
                                 addOps <| fgWarn "can't convert refinement"
                     | Some o -> addOps <| [(Assume (o, None, mkAid AKBindingVar))]))
                   (* assert proven formula and track proof term *)
               | Typ_app ({v=Typ_const(x,_);sort=_;p=_},t') when is_pf_wrapper x -> 
                   (typToTerm (inf env) t') >> (function 
                      | None   -> addOps <| fgWarn "can't convert proven formula"
                      | Some o ->
                          (match mkAid AKBindingVar with
                             | ABindingVar(i) ->
                                 addOps <| [(Assume (o, None, ABindingVar i))]
                             | _ ->
                                 raise (Never "processBinding: Binding_var")))
                     (* just define new function symbol *)
               | _ -> addOps <| defSymbolWithTyp tt) >> (fun _ -> 
            addOps <| fgComment (spr "BindingVar %s %s" id.idText (strTyp tt)))

    | Tcenv.Binding_match(e1,e2) -> 
          let warn msg = fgWarn (spr "Ignoring binding match %s=%s; %s" (Pretty.strExp e1) (Pretty.strExp e2) msg) in
          let t1, t2 = e1.sort, e2.sort in
            //          let _ = pr "Trying to translate match %s=%s\n with types %s, %s\n and kinds %s, %s\n" (Pretty.strExp e1) (Pretty.strExp e2)
              //                        (Pretty.strTyp t1) (Pretty.strTyp t2) (Pretty.strKind t1.sort) (Pretty.strKind t2.sort) in
          let ts = bind_opt (mkSortForTyp env t1) (fun (ti1, sigelts, ops) -> 
                   bind_opt (mkSortForTyp env t2) (fun (ti2, se', ops') -> 
                     Some ((ops@ops'), (se'@sigelts)))) in
            match ts with 
              | None -> addOps <| warn (spr "No sorts for types %s, %s" (Pretty.strTyp t1) (Pretty.strTyp t2))
              | Some(ops, ses) -> 
                    let info = inf env in
                      (stmap [e1;e2] (expToTerm info)) >> (function 
                        | [Some a; Some b] -> addOps <| ops@[(Assume (Eq (a,b), None, mkAid AKBindingMatch))]
                        | _ -> 
                            addOps <| ops@(warn "Couldn't convert expressions")) >> (fun _ -> 
            addOps <| fgComment (spr "BindingMatch %s %s" (strExp e1) (strExp e2)))
      in
    Profiling.profile thunk pb_ctr

(* Nik: TODO, resurrect this to make things go faster still.
        But, managing the ProofState properly while memo-izing results is non-trivial. 
        I tried a couple of variations, the one below comes close, but gets tripped up nevertheless. *)
(* let processAllBindings,  *)
(*     clear_gamma_cache = *)
(*   let cache: (list<Tcenv.binding * ops> ref) = ref [] in  *)
(*   let missed = ref false in  *)
(*   let cursor: option<Tcenv.binding> ref = ref None in  *)
(*   let reset () = cursor := None; missed := false in *)
(*   let clear () = (reset(); cache := []) in *)
    
(*   let popUntilCursor () = match !cursor with  *)
(*     | None -> List.iter (fun _ -> ProofState.pop()) !cache; cache := [] *)
(*     | Some b ->  *)
(*         let rec aux l = match l with *)
(*           | [] -> raise Impos *)
(*           | (b', _)::tl when b===b' -> cache := l *)
(*           | _::tl -> ProofState.pop(); aux tl in  *)
(*           aux !cache in *)

(*   let lookupCache binding =  *)
(*     if !missed then None *)
(*     else *)
(*       match List.tryFind (fun (b,_) -> binding === b) !cache with  *)
(*         | Some (_, ops) -> cursor := Some binding; Some ops *)
(*         | None -> missed := true; popUntilCursor (); None in *)
    
(*   let processOneBinding env binding =  *)
(*     match lookupCache binding with  *)
(*       | Some ops -> ops *)
(*       | None ->  *)
(*           ProofState.push();  *)
(*           let stenv, _ = runState ProofCommon.emptyEnv (processBinding env binding) in *)
(*           let newops = List.rev stenv.ops in *)
(*             cache := (binding, newops)::!cache;  *)
(*             newops in  *)
    
(*     ((fun env ->  *)
(*         let _ = reset() in *)
(*           Tcenv.fold_env env (fun out b ->  *)
(*                                 let newops = processOneBinding env b in  *)
(*                                   newops@out) []  |> List.rev),  *)
(*      clear) *)

let processAllBindings env = 
  Tcenv.fold_env env (fun out binding -> 
                        let _, stenv = runState ProofCommon.emptyEnv (processBinding env binding) in
                        let newops = List.rev stenv.ops in
                          newops@out) []  |> List.rev
let clear_gamma_cache () = ()
            
let teq info t1 t2 = 
    let env = Tcenv.clear_solver info.envn in
    match TypeRelations.equivalent_with_evidence env t1 t2 with
        | None -> false
        | Some ev -> warn_empty_ev ev; true

let keq info k1 k2 = 
    let env = Tcenv.clear_solver info.envn in
    match TypeRelations.equivalent_kinds_with_evidence env k1 k2 with 
        | None -> false
        | Some ev -> warn_empty_ev ev; true

let rec qvars_in_kind = function
    | Kind_tcon(Some x, _, k) -> x::qvars_in_kind k 
    | _ -> []

exception Irrelevant_poly_pred of typ
open ProofState
type subst = list<btvdef*typ>
type isubst = polyinst * list<subst>

let strInst i = (spr "%s [%s] \t=\t %s<%s>") (sli i.mlid) (String.concat ", " (List.map (fun t -> spr "%d" (sortOfTyp t)) i.targs))
                                             (sli i.plid)  (String.concat ", " (List.map Pretty.strTyp i.targs)) 
let strInsts is = String.concat "\n" (List.map strInst is)

let inst_eq info i1 i2 = 
    let res = (Sugar.lid_equals i1.plid i2.plid &&
               List.forall2 (fun t1 t2 -> sortOfTyp t1 = sortOfTyp t2) i1.targs i2.targs) in
      //DebugLog.Log (spr "Compared insts(%A): %s and %s\n" res (strInst i1) (strInst i2));
      res
    
let subtractInsts info l1 l2 = Util.subtract (inst_eq info) l1 l2    
let remove_dup_insts info il = Util.remove_dups (inst_eq info) il
let polyTypOfInst i = 
    let tc = twithsort (Typ_const(fvwithsort i.plid i.pkind, None)) i.pkind in
     AbsynUtils.mkTypApp tc i.targs []
let monoTypOfInst i = 
    let tc = twithsort (Typ_const(fvwithsort i.mlid i.mkind, None)) i.mkind in
      tc      
let sortSubst s = List.sortWith (fun (bvd1, _) (bvd2, _) -> String.compare bvd1.realname.idText bvd2.realname.idText) s

let substEq info s1 s2 = 
   (List.length s1 = List.length s2) &&
   List.forall2 (fun (x1, t1) (x2, t2) -> Absyn.bvd_eq x1 x2 && teq info t1 t2) s1 s2

let instid = ref 0
let polyAppToTerm info env tm : option<(info * list<polyinst> * term * ops)> = 
    let rec lookupInstProp env t targs vargs = 
        (match t.v with 
            | Typ_const(x, _) ->
                (try 
                   let i = List.find (fun i -> if (Sugar.lid_equals i.plid x.v) (* TODO Nik: The sorts of t<x> and t<y> are the same. Fix? *)
                                               then List.forall2 (fun (Inr t1) t2 -> sortOfTyp t1 = sortOfTyp t2 (*teq info t1 t2*)) targs i.targs  
                                               else false) env in
                   let mono_t = monoTypOfInst i in 
                   let tm, stenv = runState ProofCommon.emptyEnv (fullyAppliedPropToTerm info vargs mono_t) in
                     bind_opt tm (fun tm -> Some (tm, stenv.ops))
                 with 
                     | :? System.Collections.Generic.KeyNotFoundException -> None)
            | _ -> None)  
    and polyAppsToTerms info env tms = 
        let rec aux (info, env, out, ops) = function 
            [] -> Some (info, env, List.rev out, ops) 
          | tm::tl -> bind_opt (polyAppToTerm info env tm) (fun (info, env, tm', ops') -> aux (info, env, tm'::out, ops@ops') tl) in
        aux (info, env, [], []) tms 
    and polyAppToTerm info (env:list<polyinst>) tm = match tm with 
     | (PolyApp(t, args)) ->  
        let targs, vargs = List.partition (function Inr _ -> true | _ -> false) args in
         (match lookupInstProp env t targs vargs with 
            | Some (tm, ops) -> Some (info, env, tm, ops) (* We already have a monomorphic version of t<targs> *)     
            | None ->  (* Look in delayedOps to see if there's a polyprop that matches the name of t*)
                let dops = ProofState.Ops.getDelayedOps () in 
                (try
                   let found = List.find (function 
                                    | Delayed (Sig_tycon_kind(lid, [], k, true, _, _)) -> (* props must have [] tps *)
                                            (match t.v with 
                                                | Typ_const(x, _) -> Sugar.lid_equals x.v lid 
                                                | _ -> false)
                                    | _ -> false) dops in
                   let (Delayed (Sig_tycon_kind(lid, [], (Kind_tcon(Some _, _, _) as k), _, _, _))) = found in 
                   if List.length (qvars_in_kind k) <> List.length targs 
                   then None(* with the same number of ty params *)
                   else 
                     (* let _ = pr "Found tycon ... %A\n" lid in *)
                     let mono_k = List.fold_left (fun k (Inr t) -> open_kind k t) k targs in (* instantiate its kind with the targs *)
                     let monoPropName = asLid <| lid.lid@[string2ident(spr "%d" (incr instid; !instid))] in
                     let s = Sig_tycon_kind(monoPropName, [], mono_k, true, [], []) in (* make up a new monomorphic version *)
                     let info = {info with envn=Tcenv.push_sigelt info.envn s} in
                     let title, _, s_ops = doProcessSigelt info s in (* process it to get ops for it *)
                     (* let _ = pr "Processed monized sigelt ... got %A\n" s_ops in *)
                     let mono_t = twithsort (Typ_const(fvwithsort monoPropName mono_k, None)) mono_k in
                     let tm_opt, stenv = runState ProofCommon.emptyEnv (fullyAppliedPropToTerm info vargs mono_t) in 
                        match tm_opt with 
                            | Some tm -> 
                                let env' = {plid=lid; 
                                            mlid=monoPropName; 
                                            targs=List.map (function Inr t -> t) targs; 
                                            pkind=k; 
                                            mkind=mono_k}::env in 
                                (* let _ = pr "Translated to %A!\n" tm in *)
                                  Some(info, env', tm, s_ops) 
                            | None -> 
                                (* let _ = pr "Tried but failed to translate %s\n" (Pretty.strTyp mono_t) in *)
                                  None 
                 with 
                   | :? System.Collections.Generic.KeyNotFoundException -> None))
      | Integer _ 
      | True
      | False
      | BoundV _  
      | FreeV  _ -> Some(info, env, tm, [])
      | App (s, tms) -> combinel info env (Array.toList tms) (fun tms -> App(s, Array.ofList tms))
      | Not tm -> combine info env tm (fun tm' -> Not tm')
      | And(t1, t2) -> combinel info env [t1;t2] (fun [t1';t2'] -> And(t1',t2'))
      | Or(t1, t2) -> combinel info env [t1;t2] (fun [t1';t2'] -> Or(t1',t2'))
      | Imp(t1, t2) -> combinel info env [t1;t2] (fun [t1';t2'] -> Imp(t1',t2'))
      | Iff(t1, t2) -> combinel info env [t1;t2] (fun [t1';t2'] -> Iff(t1',t2'))
      | Eq(t1, t2) -> combinel info env [t1;t2] (fun [t1';t2'] -> Eq(t1',t2'))
      | Forall(pats, sa, xa, t) -> combine info env t (fun t' -> Forall(pats, sa, xa, t'))
      | Exists(pats, s, x, t) -> combine info env t (fun t' -> Exists(pats, s, x, t'))
   and combinel info env tl f = bind_opt (polyAppsToTerms info env tl) (fun (info, env, tl', ops) -> Some(info, env, f tl', ops))
   and combine info env t f = bind_opt (polyAppToTerm info env t) (fun (info, env, t', ops) -> Some(info, env, f t', ops)) in
 polyAppToTerm info env tm

let monomorphize info prior_insts ops = 
   let aux (info, env, outOps) top =  match top with  
        | Delayed _ -> info, env, outOps
        | DefSort _ 
        | DefPred _
        | DefFun _
        | Comment _
        | Warning _ -> info, env, top::outOps  
        | Assume(t, cop, aId) -> 
          (match polyAppToTerm info env t with 
               | Some(info, env, tm, ops) ->  
                    info, env, (Assume(tm, None, aId))::(List.rev ops)@outOps
               | None -> (info, env, outOps))            
        | Query t -> 
            (* let _ = pr "Trying to translate query ... %s\n" (ProofZZZ.opToSmt info (Query t))  in *)
          (match polyAppToTerm info env t with 
             | Some(info, env, tm, ops) ->  
                 info, env, (Query(tm))::(List.rev ops)@outOps
             | None -> (* pr "Failed to translate query!\n";  *)info, env, outOps) in
   let info, env, ops = List.fold_left aux (info, prior_insts, []) ops in 
   let new_insts = remove_tail env prior_insts in
     info, new_insts, List.rev ops 
       
let instantiateDelayedOps info : list<polyinst> -> list<polyinst> -> (list<polyinst> * info * ops) =  
    let dops = ProofState.Ops.getDelayedOps () in      
    let rec groupInsts groups i's : list<lident * list<polyinst>> = match i's with 
       | i::tl -> (* (propLid, monoPropLid, targs, poly_k, mono_k)::tl -> *)
           (match List.tryFind (fun (propLid', _) -> Sugar.lid_equals i.plid propLid') groups with
             | None -> let groups = (i.plid, [i])::groups in groupInsts groups tl
             | Some (_, insts) -> let groups = (i.plid, i::insts)::groups in groupInsts groups tl)
       | [] -> groups in
    let instantiateAssumption seen_insts new_insts : Absyn.sigelt -> (list<(Absyn.lident * subst * sigelt)> * list<polyinst*ops>) = 
        let groups = groupInsts [] new_insts in 
        let groupOf p = List.tryFind (fun (lid, _) -> Sugar.lid_equals p lid) groups in
        let polyPropInsts aid t : list<isubst> = //list<lident * (list<bvar<kind>> (* actuals *) * list<inst>)>  =
            let inst_t, bvd_uvars = TypeRelations.instantiate_typ info.envn t in
            let uvarMapToSubst = 
                List.map (fun (uvars, topt) -> match uvars, topt with 
                             [uv,_], Some t -> 
                                (match List.tryFind (fun (bvd, {v=Typ_uvar(uv',_);sort=_;p=_}) -> Unionfind.equivalent uv uv') bvd_uvars with
                                  | None -> raise Impos
                                  | Some (bvd, _) -> (bvd, t))
                            | _ -> raise Impos)  in
            let unifiable info t1 t2 = 
                let env = Tcenv.clear_solver info.envn in
                bind_opt (TypeRelations.convertible_ev env t1 t2) 
                         (fun (uv, evidence) -> Some(uvarMapToSubst uv)) in
            let tyApp2Props _ visitor _ () binders t : list<isubst> * unit = match t.v with 
                | Typ_app _ ->
                        (match flattenTypApps t with 
                            | ({v=Typ_const(v, _); sort=_; p=_})::targs-> 
                            (match groupOf v.v with 
                                | Some (_, insts) ->
                                    let rec getSubsts out = function
                                        | [] -> out
                                        | i::tl -> 
                                            let polyt = polyTypOfInst i in
                                            match unifiable info t polyt with 
                                                | Some subst -> 
                                                       getSubsts ((i,[subst])::out) tl 
                                                | _ -> getSubsts out tl in
                                        getSubsts [] insts, ()
                                     | None -> visitor () binders t)
                            | _ -> visitor () binders t) 
                | _ -> visitor () binders t in
            let combineProps t (_, (isubsts:list<list<isubst>>), _) () : list<isubst> * unit = 
                let isubsts = List.flatten isubsts in
                let rec groupByInst out = function
                    | ((i, substs) as hd)::tl ->
                        let i_l, rest = List.partition 
                                (fun (j, _) -> Sugar.lid_equals i.plid j.plid) tl in
                        let hd = List.fold_left (fun (i, substs) (_, s') -> (i, s'@substs)) hd i_l in
                            groupByInst (hd::out) rest  
                    | [] -> out in
                    groupByInst [] isubsts, () in   
            if List.length bvd_uvars = 0 then []
            else let res, _ = AbsynUtils.reduce_typ (fun _ _ _ _ _ _ -> (), ()) tyApp2Props (fun _ _ _ _ _ _ -> (), ())
                                                    (fun _ _ _ -> (), ()) combineProps (fun _ _ _ -> (), ()) () [] inst_t in
                   res in
       function
           | Sig_ghost_assume(lid, t, aq) 
           | Sig_datacon_typ(lid, [], t, Some _, aq, _, _, _ (*ignoring_patterns*) ) as assumption -> (* Nik: TODO, handle patterns in delayed assumptions *)
                DebugLog.Log (spr "Examining assumption %s\n" (sli lid));
                let isubsts = polyPropInsts lid t in 
                let isNonEqPolyProp t = match flattenTypApps t with 
                    ({v=Typ_const(v, _);sort=Kind_tcon(Some _, _, _); p=_} as tcon::args) when not (AbsynUtils.is_equality v) -> 
                         Tcenv.is_prop info.envn tcon 
                   | _ -> false in
                let replacePolyTyps insts t : ((typ*list<polyinst * ops>) * list<polyinst>) =  
                      let map_typ _ visitor _ (insts:list<polyinst>) binders t : ((typ*list<polyinst*ops>) * list<polyinst>) = match t.v with 
                        | Typ_app _ -> 
                             (match List.tryFind (fun inst -> teq info t (polyTypOfInst inst)) insts with
                                | Some i -> (monoTypOfInst i, []), insts
                                | _ -> if isNonEqPolyProp t then 
                                          //let _ = DebugLog.Log (spr "FOUND A POLYPROP %s\n" (Pretty.strTyp t)) in
                                          let tm, stenv = runState ProofCommon.emptyEnv (fullyAppliedPropToTermMsg info [] t) in
                                          match tm with 
                                             None -> 
                                                raise (Irrelevant_poly_pred t)
                                           | Some tm -> 
                                                match polyAppToTerm info [] tm with 
                                                   | None -> raise (Irrelevant_poly_pred t)
                                                   | Some (info, env, tm, ops) -> 
                                                        let [i] = env in
                                                       // let _ = DebugLog.Log (spr  "\nAUTO-GENERATED AN INST: %s " (strInst i)) in
                                                            (monoTypOfInst i, [(i, stenv.ops@ops)]), (i::insts)
                                       else visitor insts binders t)
                        | _ -> (match t.sort(* .u *) with 
                                    | Kind_tcon(Some _, _, _) when isNonEqPolyProp t -> raise (Irrelevant_poly_pred t) 
                                    | _ -> visitor insts binders t) in
                    let combine t (kl, (ti_l:list<typ * list<polyinst*ops>>), el) (insts:list<polyinst>) : ((typ * list<polyinst * ops>) * list<polyinst>) =
                        let tl, il = List.split ti_l in
                        let il = List.flatten il in
                        let il = Util.remove_dups (fun i1 i2 -> inst_eq info (fst i1) (fst i2)) il in 
                        let t, _ = AbsynUtils.combine_typ t (kl, tl, el) () in
                            (t, il), insts in 
                    let r, seen = AbsynUtils.reduce_typ (fun _ _ v i _ k -> k, i) map_typ (fun _ _ v i _ e -> e, i)
                                                 (fun k _ i -> k, i) combine (fun e _ i -> e, i) insts [] t in
                        r, seen in
                let rec instProps (polyts:list<typ * subst>) : list<isubst> -> list<typ*subst> = function
                   | (inst, substs)::tl -> //(polyProp, (targs, insts))::tl -> 
                       let polyts = List.map (fun polyt -> 
                                let rec applySubst s (t,s') = match t.v with 
                                    | Typ_univ(bvd, k, _::_, tinner) -> raise Impos
                                    | Typ_univ(bvd, k, [], tinner) -> (* NS: Ignoring formula *)
                                        (match List.tryFind (fun (bvd', _) -> Absyn.bvd_eq bvd bvd') s with 
                                            | Some (_, with_t) -> 
                                                 let t = Absyn.open_typ_with_typ t with_t in
                                                 let t', s' = applySubst s (t,s') in
                                                    t', (bvd, with_t)::s'
                                            | _ -> 
                                                let tinner, s' = applySubst s (tinner,s') in
                                                let t = twithsort (Typ_univ(bvd, k, [], tinner)) t.sort in
                                                    t, s')
                                    | _ -> t, s' in
                                 List.map (fun s -> applySubst s polyt) substs) polyts |> List.flatten in
                        instProps polyts tl
                   | _ -> polyts in 
                let mono_ts = instProps [(t,[])] isubsts in //props in
              //  let insts = List.map snd groups |> List.flatten in 
                let seen, _, assumptions, (autos:list<polyinst * ops>) = List.fold_left (fun (seen, ctr, out, autos) (mono_t, subst) -> match mono_t.v with 
                                                      | Typ_univ _ -> seen, ctr, out, autos (* not fully instantiated yet. warn? *)
                                                      | _ -> 
                                                        try 
                                                            let (mono_t, moreautos), seen = replacePolyTyps seen mono_t in
                                                            let assumption_mono_lid = asLid <| lid.lid@[string2ident (spr "%d" ctr)] in
                                                            let _ignoringPats = [] in 
                                                                (seen, ctr+1, (lid, sortSubst subst, Sig_datacon_typ (assumption_mono_lid, [], mono_t, Some Sugar.Assumption, aq, None, None, _ignoringPats))::out, moreautos@autos)
                                                        with Irrelevant_poly_pred t ->
                                                               Util.warn "!!!!!!!!!!!!!!!!Found ir_p_p: %s\n" (Pretty.strTyp t); (seen, ctr, out, autos))
                                  (seen_insts, 0, [], []) mono_ts in
                let insts:list<polyinst>  = List.map fst autos in
                let _ = DebugLog.Log (spr  "\nAuto generated instantiations:\n%s\n" (strInsts insts)) in
                let _ = DebugLog.Log (spr "\nInstantiated assumptions:\n\t%s\n" (String.concat "\n\t" (List.map (fun (lid, _, (Sig_datacon_typ(mlid, _, t, _, _, _, _, _))) -> (spr "%s: %s: %s" (sli lid) (sli mlid) (Pretty.strTyp t ))) assumptions))) in
                  assumptions, autos
           | _ -> [], [] in
       
    let rec instUntilFix (seen:list<polyinst>) info assumptions ops (insts:list<polyinst>) : list<polyinst> * list<sigelt> * ops = 
 //       let insts = List.filter (fun i -> not (List.exists (inst_eq info i) seen)) insts in
        if List.length insts = 0 then [], [], [] 
        else
            let _ = DebugLog.Log (spr "\n..................................\nInstantiating assumptions for\n[%s]\nInstantiations seen so far\n%s\n" (strInsts insts) (strInsts seen)) in
            let seen = seen@insts in 
            let asmpts, autos, seen = List.fold_left (fun (asmpts, autos, seen) -> function
                                                       | Delayed se ->  
                                                        let asmpts', autos' = instantiateAssumption seen insts se in
                                                        let autos' = List.filter (fun (i, _) -> not (List.exists (inst_eq info i) seen)) autos' in  
                                                        let seen' = seen@(List.map fst autos') in
                                                        (asmpts@asmpts', autos@autos', seen')
                                                      | _ -> asmpts, autos, seen) ([], [], seen) dops in
            let insts', ops' = List.split autos in
            let _ = DebugLog.Log (spr "\nGot auto-generated instantiations\n%s\n" (strInsts insts')) in
            let assumptions' = List.fold_left (fun out (lid, subst, a) -> 
                                                  match List.tryFind (fun (lid', subst', _) -> Sugar.lid_equals lid lid' && substEq info subst subst') out with 
                                                    None -> (lid, subst, a)::out
                                                  | Some _ -> out) assumptions asmpts in
            if (LanguagePrimitives.PhysicalEquality assumptions' assumptions) || 
                List.length autos=0 then (* converged *)
                let asmpts = List.map (fun (_, _, se) -> se) assumptions' in
                let ops = ((List.map snd autos) |> List.flatten)@ops in
                    seen, asmpts, ops
            else 
                let ops = (List.flatten ops') @ ops in 
                 instUntilFix seen info assumptions' ops insts' in
    fun prev all_insts -> 
        let inst, assumptions, ops = instUntilFix prev info [] [] all_insts in 
        let info, ops = List.fold_left (fun (info, out) se ->
                                 let info = {info with envn=Tcenv.push_sigelt info.envn se} in
                                 let title, ses, ops = doProcessSigelt info se in
                                    info, ops@out) (info, ops) assumptions in
        inst, info, (List.rev ops)      
          
let monize info orig_ops = 
  "monize" ^^ lazy
  let bginsts = ProofState.Ops.getPolyInsts () in  
//  let _ = pr "Monize with bginsts=%s\n" (strInsts bginsts) in
  let info, instantiations, ops = monomorphize info bginsts orig_ops in 
  let allinsts, info, moreops =
    if List.length instantiations <> 0 then 
     let _ = DebugLog.Log (spr "\nMonomorph computed instantiations\n %s\n" (strInsts instantiations)) in
     let allinsts, info, moreops = instantiateDelayedOps info bginsts instantiations in
     let _  = DebugLog.Log (spr "\nAll insts: %s\n" (strInsts allinsts)) in
        allinsts, info, moreops 
    else bginsts, info, [] in
  let ops = ops@moreops in 
  let newInsts = subtractInsts info allinsts bginsts in 
//  let _ = pr "Monize computed all insts=%s\n" (strInsts allinsts) in
//  let _ = pr "Monize storing new insts=%s\n" (strInsts newInsts) in
  let _ = ProofState.Ops.storePolyInsts newInsts in 
    ops

(****************************************************************************)
(* INTERFACE WITH SOURCE TYPE CHECKER                                       *)
(****************************************************************************)
let printOp op = pr "%A\n" op
let printOps msg ops = pr "*******%s********\n" msg; List.iter printOp ops

let process_sigelt (env:Tcenv.env) (se:sigelt) : sigelt list =
  let warn s =  Util.warn "Proof skipped sigelt (%s) %s\n" s (Pretty.nameOfSigelt se); [] in
  try 
      let info = inf env in
      let title, newSigelts, ops = doProcessSigelt info se in
      let delayed, ops = List.partition (function Delayed _ -> true | _ -> false) ops in
      let ops = monize info ops in
      //let _ = printOps (spr "Ops generated for sigelt %s" (Pretty.nameOfSigelt se)) ops in
      if title = skipSigeltMessage
      then newSigelts (* avoid writing all ProofLib sigelts to queries/all.smt *)
      else 
        (ProofState.Ops.storeOps ops;
         if !Options.emulateContexts then () else ignore (assertOps info ops "sigelt");
         ProofState.Ops.storeDelayedOps delayed;
         logToAllSmt info title ops;
         newSigelts)
  with 
    Bad_sort s
  | Translation s -> warn s 

let returnResult r = (*pr "Query result: %A\n" (fst r); *) ProofState.pop(); r 

let prove_and_extract env goal_t : bool * exp' option =
  let fail s =  Util.warn "Failed to process environment for proof %s\n\t%s\n" (Pretty.strTyp goal_t) s; returnResult (false, None) in
  try
      bumpQueryCount(); 
      let _ = ProofState.push () in
      let info = inf env in
      let goal_t = Tcenv.expand_typ_rec env goal_t in
        (* pr "prove_and_extract %s\n" (Pretty.strTyp goal_t); flush stdout; *)
      let ops = processAllBindings env in

      let goal_t = match goal_t.v with
        | Typ_app ({v=Typ_const(x,_);sort=_;p=_},t') when is_pf_wrapper x -> Absyn.whnf t' 
        | _ -> whnf goal_t in
        
      let tmopt, stenv = runState ProofCommon.emptyEnv (typToTerm info goal_t) in 
        match tmopt with
          | Some tm -> 
              let query = Query tm in
              (* let _ = pr "Translated goal %s in to %s\n" (Pretty.strTyp goal_t) (ProofZZZ.opToSmt info query) in *)
              let pops = ops@stenv.ops@[query] in
                //let _ = printOps "Generated polyops" pops in 
                let ops = monize info (ops@stenv.ops@[query]) in
                let uvops = ProofState.Uvars.opsForUvars () in
                  //let _ = printOps "Monized ops" ops in 
                  let _ = ProofState.Ops.storeOps ops in 
                  let allOps = (if !Options.emulateContexts then ProofState.Ops.getOps () else ops)@uvops in 
                    //let _ = printOps "All ops" allOps in 
                    let result = 
                      match processOps info allOps (spr "prove_and_extract_%04d" (queryCount())) with
                        | Some r -> r
                        | _ -> (false, None) in 
                      returnResult result
          | None -> fail (spr "Untranslatable goal term (%s): %A\n" (Pretty.strTyp goal_t) goal_t)
  with 
      Bad_sort s
    | Translation s -> fail s 
        
let prove_eq_and_extract env e1 e2 : bool * exp' option =
  let fail s =  Util.warn "Failed to process environment for proof (%s=%s)\n\t%s\n" (Pretty.strExp e1) (Pretty.strExp e2) s; 
    returnResult (false, None) in
    try 
      bumpQueryCount(); 
      let _ = ProofState.push() in
      let info = inf env in
      let ops = processAllBindings env in
      let tmlst, stenv = runState (ProofCommon.emptyEnv) (stmap [e1;e2] (expToTerm info)) in
        match tmlst with 
          | [Some a; Some b] ->
              let ops = monize info (ops@stenv.ops@[Query(Eq(a,b))]) in 
              let _ = ProofState.Ops.storeOps ops in 
              let uvops = ProofState.Uvars.opsForUvars () in
              let allOps = (if !Options.emulateContexts then ProofState.Ops.getOps () else ops)@uvops in 
                (match processOps info allOps (spr "prove_eq_and_extract_%04d" (queryCount())) with 
                   | Some r -> returnResult r
                   | _ -> returnResult (false, None))
          | _ -> fail "Untranslatable goal term"
    with 
        Bad_sort s
      | Translation s -> fail s 

#endif
