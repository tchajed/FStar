(* Modified by Nikhil Swamy; May, July 2010 *)
(*
  Copyright (c) 2009, Regents of the University of California

  Authors: Ravi Chugh
  
  All rights reserved.
  
  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following 
  conditions are met:
  
  1. Redistributions of source code must retain the above copyright 
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above 
  copyright notice, this list of conditions and the following disclaimer 
  in the documentation and/or other materials provided with the distribution.

  3. Neither the name of the University of California, San Diego, nor 
  the names of its contributors may be used to endorse or promote 
  products derived from this software without specific prior 
  written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
  CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
  PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
  PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
  LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
  SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*)


#light "off"

module Microsoft.FStar.ProofZZZ

open Microsoft.Z3
type ZZZSymbol = Microsoft.Z3.Symbol
type ZZZSort = Microsoft.Z3.Sort
type ZZZZ3Error = Microsoft.Z3.Z3Exception
open Microsoft.FStar
open ProofCommon
open ProofState
open Profiling
open Util


(****************************************************************************)
(* Pretty printing Z3 terms and ops in SMT Lib format for debugging support *)
(****************************************************************************)
let rec termToSmt (info:info) = function
  | True          -> "(true)"
  | False         -> "(false)"
  | Integer i     -> spr "%d" i 
  | BoundV(i,_)   -> if (i < List.length info.binders) then List.nth info.binders i else spr "(!!!!!!! out of bounds %d)" i
  | FreeV(x,_)    -> x
  | App(f,es)     -> let a = Array.map (termToSmt info) es in
                     let s = String.concat " " (Array.to_list a) in
                     spr "(%s %s)" f s
  | Not(x)        -> spr "(not %s)" (termToSmt info x)
  | And(x,y)      -> spr "(and %s %s)" (termToSmt info x) (termToSmt info y)
  | Or(x,y)       -> spr "(or %s %s)" (termToSmt info x) (termToSmt info y)
  | Imp(x,y)      -> spr "(implies %s %s)"(termToSmt info x)(termToSmt info y)
  | Iff(x,y)      -> spr "(iff %s %s)" (termToSmt info x) (termToSmt info y)
  | Eq(x,y)       -> spr "(= %s %s)" (termToSmt info x) (termToSmt info y)
  | Forall(pats,x,y,z) as q ->
      if Array.length x <> Array.length y then raise (Never (spr "Bad: %A" q))
      else
      let s = String.concat " "
                (Array.map (fun (a,b) -> spr "(%s %s)" a (strSort b))
                           (Array.zip y x)) in
      let binders' = (List.rev (Array.to_list y)) @ info.binders in
      let info' = { info with binders=binders' } in
        if Array.length x = 0 then (termToSmt info' z)
        else spr "(forall %s %s %s)" s (termToSmt info' z) (patsToSmt info pats)
  | Exists(pats,x,y,z) ->
      let s = String.concat " "
                (Array.map (fun (a,b) -> spr "(%s %s)" a (strSort b))
                           (Array.zip y x)) in
      let binders' = (List.rev (Array.to_list y)) @ info.binders in
      let info' = { info with binders=binders' } in
        if Array.length x = 0 then (termToSmt info' z)
        else spr "(exists %s %s %s)" s (termToSmt info' z) (patsToSmt info pats)
  | PolyApp(t, args) -> spr "PolyApp (%s(%s))" (Pretty.strTyp t) (String.concat ", " (List.map (function 
                                                                                                  | Inl t -> termToSmt info t
                                                                                                  | Inr t -> Pretty.strTyp t) args))
  | x -> failwith (spr "Unexpected term form %A\n" x) 
and patsToSmt info  = function 
  | [] -> ""
  | pats -> spr "{:pat %s}" (String.concat " " (List.map (termToSmt info) pats))
    
let strOfStrOpt = function Some x -> x | _ -> ""

let opToSmt info = function
  | DefSort(tiio, msg_opt) -> 
        spr "\n:extrasorts (%s) ; %s" (strSort tiio) (strOfStrOpt msg_opt)
  | Query(t)      -> spr "\n:formula    (not %s)" (termToSmt info t)
  | Comment(c)    -> spr "\n; %s" c
  | Mark l        -> spr "\n; module %s" (Pretty.sli l)
  | Warning(c)    -> spr "\n; WARNING: %s" c
  | DefPred(f,tiios,_) ->
      let l = Array.to_list (Array.map strSort tiios) in
      spr "\n:extrapreds ((%s %s))" f (String.concat " " l)
  | DefFun(f,ts,t,_) ->
      if Array.length ts = 0 then spr "\n:extrafuns  ((%s %s))" f (strSort t)
      else
        let l = Array.to_list (Array.map strSort ts) in
        spr "\n:extrafuns  ((%s %s %s))" f (String.concat " " l) (strSort t)
  | Assume(t,co,aid) ->
      let s = strOfAssumptionId aid in
      let c = match co with Some c -> spr ";;;;;;;;;;; %s (aid %s)\n" c s
                          | None -> spr "; (aid %s)\n" s in
      spr "\n%s:assumption %s" c (termToSmt info t)
  | Delayed _ as x-> failwith (spr "Unexpected op form %A\n" x)

let writeSmtFile info oc title ops =
  if !Options.silent then () else
    begin
      log oc "\n;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;\n";
      log oc (spr "\n(benchmark %s\n" title);
      log oc (spr "%s" (String.concat "\n" (List.map (opToSmt info) ops)));
      log oc "\n)\n";
      oc.Flush ()
    end

(****************************************************************************)
(* CHECKING Z3 ANSWER TO QUERY                                              *)
(****************************************************************************)

let processZ3Answer info (x:Expr) : (bool * option<Absyn.exp'>) =
  let status =
      Profiling.profile
        (fun () -> 
           (!z3).solver.Assert(x :?> BoolExpr);
           (!z3).solver.Check())
        "Z3 query" in
      if status = Status.UNSATISFIABLE  then true, None
      else 
        let msg = if status=Status.SATISFIABLE then "satisfiable" else "unknown result" in
          pr "\nZ3 : %s\n" msg;
          stream_query (fun s -> log s (spr "; unsat? %s\n" msg)); 
          stream_query (fun s -> s.Flush());
          false, None

(****************************************************************************)
(* Z3 TERM BUILDING                                                         *)
(****************************************************************************)
type z3sort = Sort
type z3term = Term 

let is_int_sort s = s = "-1"

(* Z3 creates sorts without requiring them to be explicitly defined first.
   I.e., it its internal format, Z3 theories do not have to have an (extrasorts ..) decl.
   This wrapper ensures that Def(Sort s) explicitly precedes all uses of the sort s. *)
let (defZ3Sort : string -> unit),
    (getZ3Sort : string -> z3sort) =
  let x = ref (Zset.empty compare) in
  (fun s -> x := Zset.add s !x), 
  (fun (s:string) ->
     if Zset.mem s !x then (!z3).ctx.MkUninterpretedSort s :> Sort
     else raise (Never (spr "undefined sort: [%s]" s)))

let sortToZ3Sort (tiio:sort) : z3sort = 
    if tiio=intSort then (!z3).ctx.MkIntSort() :> Sort
    else getZ3Sort (strSort tiio)

let (defFunSym : string -> FuncDecl -> unit),
    (getFunSym : string -> FuncDecl) =
  let x = ref [] in (* assoc list of FuncDecls *)
  (fun s fd -> x := (s,fd) :: !x),
  (fun s ->
     try List.assoc s !x
     with e -> 
       (let msg = spr "GetFunSym failed on symbol: %s\n" s in
          pr "%s" msg;
          raise (Never (msg))))

//let boolSort          = (!z3).MkBoolSort()
//let trueTerm          = (!z3).MkTrue()
//let falseTerm         = (!z3).MkFalse()

let rec termToZ3Term' = function
  | True          -> (!z3).ctx.MkTrue () :> Expr
  | False         -> (!z3).ctx.MkFalse () :> Expr
  | Integer i     -> (!z3).ctx.MkInt(i) :> Expr
  | BoundV(i,s)   -> (!z3).ctx.MkBound (uint32 i, sortToZ3Sort s)
  | FreeV(x,s)    -> (!z3).ctx.MkConst (x, sortToZ3Sort s) 
  | App(f,es)     -> (!z3).ctx.MkApp (getFunSym f, Array.map termToZ3Term es) 
  | Not(x)        -> (!z3).ctx.MkNot (termToBoolExpr x) :> Expr
  | And(x,y)      -> (!z3).ctx.MkAnd [|termToBoolExpr x; termToBoolExpr y|] :> Expr
  | Or(x,y)       -> (!z3).ctx.MkOr [|termToBoolExpr x; termToBoolExpr y|] :> Expr
  | Imp(x,y)      -> (!z3).ctx.MkImplies (termToBoolExpr x, termToBoolExpr y) :> Expr
  | Iff(x,y)      -> (!z3).ctx.MkIff (termToBoolExpr x, termToBoolExpr y) :> Expr
  | Eq(x,y)       -> (!z3).ctx.MkEq (termToZ3Term x, termToZ3Term y) :> Expr
  | Forall(_, _, _, Forall _) as fa -> termToZ3Term (flatten_forall fa)
  | Forall(pats, sorts, names, body) -> 
      let body = termToZ3Term body in 
      let patterns = patsToPattern pats in
        (!z3).ctx.MkForall (Array.map sortToZ3Sort sorts, 
                            names |> Array.map (fun x -> (!z3).ctx.MkSymbol(x) :> Symbol),
                            body,
                            1u, 
                            patterns, 
                            null, 
                            null,
                            null) :> Expr
                 
  | Exists(_, _, _, Exists _) as ex -> termToZ3Term (flatten_exists ex)
  | Exists(pats, sorts, names, body) -> 
      let body = termToZ3Term body in 
      let patterns = patsToPattern pats in
        (!z3).ctx.MkExists(Array.map sortToZ3Sort sorts, 
                            names |> Array.map (fun x -> (!z3).ctx.MkSymbol(x) :> Symbol),
                            body,
                            1u, 
                            patterns, 
                            null, 
                            null,
                            null) :> Expr
and termToBoolExpr x = termToZ3Term x :?> BoolExpr
and patsToPattern = function
  | [] -> [||]
  | pats ->
      let exprs = pats |> List.map (fun p -> (termToZ3Term p)) |> Array.ofList in 
      let pat = (!z3).ctx.MkPattern(exprs) in 
        [| pat |]
and termToZ3Term x = "termToZ3Term" ^^ lazy termToZ3Term' x

let opToZ3 bg = function 
  | DefSort(s, _)    -> defZ3Sort (strSort s)
  | DefPred(f,ts,_)  -> defFunSym f ((!z3).ctx.MkFuncDecl (f, Array.map sortToZ3Sort ts, (!z3).ctx.MkBoolSort() :> Sort))
  | DefFun(f,ts,t,_) -> defFunSym f ((!z3).ctx.MkFuncDecl (f, Array.map sortToZ3Sort ts, sortToZ3Sort t))
  | Assume(t,_,aid)  -> 
        let tm = termToZ3Term t in
           (!z3).solver.Assert(tm :?> BoolExpr)
  | Comment _ 
  | Warning _ 
  | Mark _        -> ()
  | a -> raise (Never (spr "op %A passed to opToZ3" a)) 

let handleZ3Error msg =  
    stdout.Flush ();
    stream_query (fun s -> s.Flush ());
    failwith (spr "\n\n  Z3 rejected operation on operation %A\n\n" msg)
    (* when this error gets thrown, it's useful to run make smt *)

let opsToZ3 (bg:bool) ops : unit =
  "opToZ3" ^^ lazy 
  let curOp = ref None in
  try 
    List.iter (fun op -> curOp := Some op; opToZ3 bg op) ops
  with 
   :? ZZZZ3Error -> handleZ3Error !curOp 

let queryToZ3 info = function 
   | Query(t) -> 
        (try 
            processZ3Answer info (termToZ3Term (Not t))
         with 
            :? ZZZZ3Error -> handleZ3Error (Not t))
   | _ -> raise (Never "queryToZ3 called with non-query")

let logToAllSmt info title ops = "logOps" ^^ lazy 
  (stream_query (fun s -> writeSmtFile info s title ops))
let writeToQueryFile info allOps query = 
  if !Options.logQueries then
    let _ = DebugLog.Log (spr "All ops: %A\n" allOps) in     
    let stream = new System.IO.StreamWriter (queryFile ()) in
    let _ = pr "Writing to query file %s\n" (queryFile ()) in
    let _ = writeSmtFile info stream (spr "query_%04d" (queryCount())) (allOps@query) in
      stream.Flush (); stream.Close ()

let partitionOps reorder ops = 
  let query, ops = List.partition (function Query _ -> true | _ -> false) ops in
    if not reorder then ops, query
    else
      let allSorts, rest = List.partition (function DefSort _ -> true | _ -> false) ops in
      let allPreds, rest = List.partition (function DefPred _ -> true | _ -> false) rest in
      let allFuns, rest = List.partition (function DefFun _ -> true | _ -> false) rest in
      let allAssumes, rest = List.partition (function Assume _ -> true | _ -> false) rest in  
      let comments, rest = List.partition (function Comment _ | Warning _ -> true | _ -> false) rest in  
      let allOps = allSorts@allPreds@allFuns@allAssumes@rest@comments in
        allOps, query

let __assertOps reorder (info:info) ops title : option<bool * option<Absyn.exp'>> =
  if !Options.logQueries then logToAllSmt info title ops;
  let allOps, query = partitionOps reorder ops in 
  let _ = writeToQueryFile info allOps query in 
    opsToZ3 true allOps;
    let result = match query with 
      | [] -> None
      | [q] -> Some (queryToZ3 info q) in
      result

let assertOps info ops title = __assertOps true info ops title
        
let processOps (info:info) ops title : option<bool * option<Absyn.exp'>> =
    "processOps" ^^ lazy 
     let _ = (!z3).solver.Push() in
     let result = assertOps info ops title in
     let _ = (!z3).solver.Pop() in
        result

let processZ3encoding (info:info) ops title : option<bool * option<Absyn.exp'>> =
    "processOps" ^^ lazy 
     let _ = (!z3).solver.Push() in
     let result = __assertOps false info ops title in
     let _ = (!z3).solver.Pop() in
        result
