(*
  Copyright (c) 2009, Regents of the University of California

  Authors: Ravi Chugh
  
  All rights reserved.
  
  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following 
  conditions are met:
  
  1. Redistributions of source code must retain the above copyright 
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above 
  copyright notice, this list of conditions and the following disclaimer 
  in the documentation and/or other materials provided with the distribution.

  3. Neither the name of the University of California, San Diego, nor 
  the names of its contributors may be used to endorse or promote 
  products derived from this software without specific prior 
  written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
  CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
  PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
  PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
  LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
  SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*)


#light "off"

module Microsoft.FStar.ProofUtils

open Util
exception Never of string

let strFlags l =
  String.concat "" (List.map (function true -> "1" | false -> "0") l)

let strIntList l = String.concat "" (List.map soi l)

let invertBijection l =
  List.map
    (fun i -> match findIdx i l with
                | Some j -> j+1
                | None   -> failwith "invertBijection: arg wasn't a bij")
    (list1N (List.length l))

let splitAntesAndGoal l =
  let l_rev = List.rev l in
  List.rev (List.tl l_rev), List.hd l_rev

module Ht = struct

  type ('a,'b) t = ('a,'b) Hashtbl.t * string * ('a -> string)

  let create s f : ('a,'b) t = (Hashtbl.create 17, s, f)

  let add ((ht,_,_):('a,'b) t) (k:'a) (v:'b) = Hashtbl.add ht k v

  let replace ((ht,_,_):('a,'b) t) (k:'a) (v:'b) = Hashtbl.replace ht k v

  let mem ((ht,_,_):('a,'b) t) (k:'a) = Hashtbl.mem ht k

  let iter ((ht,_,_):('a,'b) t) f = Hashtbl.iter f ht

  let fold f ((ht,_,_):('a,'b) t) x = Hashtbl.fold f ht x

  let find ((ht,s,f):('a,'b) t) (k:'a) =
    if Hashtbl.mem ht k then Hashtbl.find ht k
    else failwith (spr "Ht.find: %s not in table %s" (f k) s)

  let clear ((ht,_,_):('a,'b) t) = Hashtbl.clear ht

  let remove ((ht,_,_):('a,'b) t) (x:'a) = Hashtbl.remove ht x

end


module IdTable = struct

  type 'a t = int ref
                * (int, 'a) Hashtbl.t 
                * ('a, int) Hashtbl.t 
                * string 
                * ('a -> string)

  let create s f = ref 0, Hashtbl.create 17, Hashtbl.create 17, s, f

  let processVal ((k,ht1,ht2,_,_):'a t) (x:'a) =
    if Hashtbl.mem ht2 x then Hashtbl.find ht2 x
    else (incr k; let i = !k in Hashtbl.add ht1 i x; Hashtbl.add ht2 x i; i)

  let getVal ((_,ht1,_,s,_):'a t) i =
    if Hashtbl.mem ht1 i then Hashtbl.find ht1 i
    else failwith (spr "IdTable.getVal: %d not in table %s" i s)

  let getId ((_,_,ht2,s,f):'a t) (x:'a) =
    if Hashtbl.mem ht2 x then Hashtbl.find ht2 x
    else failwith (spr "IdTable.getId: %s not in table %s" (f x) s)

  let iter ((_,ht1,_,_,_):'a t) f = Hashtbl.iter f ht1

  let clear ((k,ht1,ht2,_,_):'a t) =
    Hashtbl.clear ht1;
    Hashtbl.clear ht2;
    k := 0

  let mem ((_,_,ht2,_,_):'a t) = Hashtbl.mem ht2
  let containsKey ((_,ht1,_,_,_):'a t) = Hashtbl.mem ht1
  let containsValue = mem 

end
