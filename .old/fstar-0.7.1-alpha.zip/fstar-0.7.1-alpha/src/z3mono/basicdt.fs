#light "off"

module Microsoft.FStar.Z3Exe.BasicDT
open Microsoft.FStar

open Util
open Term
open Absyn

type ppmap = HashMultiMap<string,string>
#if HASH
 type map<'a,'b> = HashMultiMap<'a,'b>
 let map_create i = Hashtbl.create i
 let map_tryfind m k = Hashtbl.tryfind m k
 let map_add m k v = Hashtbl.add m k v; m
 let map_replace m k v = Hashtbl.replace m k v; m
#else
 type map<'a,'b> = list<('a*'b)> 
 let map_create i = []
 let map_tryfind m k =
   match findOpt (fun (k', _) -> k=k') m with 
     | None -> None
     | Some(_,v) -> Some v
 let map_add m k v = (k,v)::m
 let map_replace m k v = (k,v)::m
#endif

type opState' = {ops:list<op>; 
                 qops:list<op>;
                 env:option<Tcenv.env>;
                 ctr:int;
                 uvars:list<(Unionfind.uvar<uvar_basis> * kind) * tm * ops>;
                 transformers:(map<int, map<int, list<(typ * tm * option<phi>)>>> * 
                               map<int, (typ * option<phi>)>);
                 bvars:list<bvvar * tm * ops>;
                 fvars:list<var<typ> * tm * ops>;
                 strings:list<byte[] * tm * ops>;
                 floats:list<float * tm * ops>;
                 holds_map:list<sort * string>;
                 cached_ops:list<lident * ops>;
                 unfoldings:list<binders * typ * typ>;
                 labels:list<string * tm>;
                 pp_name_map:ppmap;
                 qid:int;
                 named_typ_map:list<string*tm>}
and opState = {termctx:termctx; st:opState'; strip_labels:bool}
and termctx = ptermctx<unit>
and binders = list<bvvar>
and tm = term<unit>
and phi        = tm (* documenting terms that are expected to be formulas *)
and renaming = list<Disj<btvdef,bvvdef>*termref<unit>>
and ST<'a> = state<opState, 'a>
and op = op<unit>
and ops = list<op> 
type STR<'a> = ('a * opState)

let replaceDeclaration f def =
  upd (fun st -> 
    let pfx, foundOpt, suffix = Util.prefixUntil st.st.ops (function DeclFun(g, _, _, _) -> f=g | _ -> false) in 
    {st with st={st.st with ops=pfx@def@suffix}})
(* List.split  *)
(* let ops = List.filter (function DeclFun(g, _, _, _) when f = g -> false | _ -> true) st.st.ops in  *)
(*   {st with st={st.st with ops=ops}}) *)

let removeDeclaration f =
  upd (fun st -> 
         let ops = List.filter (function DeclFun(g, _, _, _) when f = g -> false | _ -> true) st.st.ops in 
           {st with st={st.st with ops=ops}})
           
let lookupHoldsMap sort : ST<option<string>> = 
  get >> (fun st -> 
  match findOpt (fun (s, _) -> s=sort) st.st.holds_map with 
    | None -> ret None
    | Some(_, f) -> ret (Some f))

let insertHoldsMap s : ST<unit> = 
  upd (fun st -> {st with st={st.st with holds_map=s::st.st.holds_map}})

let normalizeTerm tm = 
  let crossbinders n subst = 
    let rebindings = 
      Hashtbl.fold (fun key v out -> 
                      match v with 
                        | Inl _ -> out
                        | Inr tm -> (key, Inr (incrBoundV n tm))::out) subst [] in 
      List.iter (fun (key, v) -> Hashtbl.replace subst key v) rebindings in
  let rec norm subst tm = match tm.tm with 
    | True
    | False
    | Funsym _
    | Integer _
    | BoundV _
    | FreeV _  -> tm
    | Minus tm -> Minus (norm subst tm)
    | ResFree  tm -> ResFree (norm subst tm)
    | App(f,s,tms) -> App(f,s, norm_array subst tms)
    | Not tm -> Not(norm subst tm)
    | PP(t1, t2) ->  norm2 subst t1 t2 (fun t1 t2 -> PP(t1,t2))
    | Add(t1, t2) -> norm2 subst t1 t2 (fun t1 t2 -> Add(t1,t2))
    | Sub(t1, t2) -> norm2 subst t1 t2 (fun t1 t2 -> Sub(t1,t2))
    | Div(t1, t2) -> norm2 subst t1 t2 (fun t1 t2 -> Div(t1,t2))
    | Mod(t1, t2) -> norm2 subst t1 t2 (fun t1 t2 -> Mod(t1,t2))
    | Mul(t1, t2) -> norm2 subst t1 t2 (fun t1 t2 -> Mul(t1,t2))
    | And(t1,t2) -> norm2 subst t1 t2 (fun t1 t2 -> And(t1,t2))
    | Or(t1,t2) ->  norm2 subst t1 t2 (fun t1 t2 -> Or(t1,t2))
    | Imp(t1,t2) -> norm2 subst t1 t2 (fun t1 t2 -> Imp(t1,t2))
    | Iff(t1,t2) -> norm2 subst t1 t2 (fun t1 t2 -> Iff(t1,t2))
    | Eq(t1,t2) ->  norm2 subst t1 t2 (fun t1 t2 -> Eq(t1,t2))
    | LT(t1,t2) ->  norm2 subst t1 t2 (fun t1 t2 -> LT(t1,t2))
    | LTE(t1,t2) -> norm2 subst t1 t2 (fun t1 t2 -> LTE(t1,t2))
    | GT(t1,t2) ->  norm2 subst t1 t2 (fun t1 t2 -> GT(t1,t2))
    | GTE(t1,t2) -> norm2 subst t1 t2 (fun t1 t2 -> GTE(t1,t2))
    | Select(t1,t2) -> norm2 subst t1 t2 (fun t1 t2 -> Select(t1, t2))
    | Update(t1,t2,t3) -> norm3 subst t1 t2 t3 (fun t1 t2 t3 -> Update(t1,t2,t3))
    | IfThenElse(t1,t2,t3,topt) -> 
        norm3 subst t1 t2 t3 (fun t1 t2 t3 -> 
        let topt = norm_opt subst topt in 
        IfThenElse(t1,t2,t3,topt))
    | Forall(pats,sorts,vars,tm) -> 
        crossbinders (Array.length sorts) subst;
        Forall(pats,sorts,vars, norm subst tm)
    | Exists(pats,sorts,vars,tm) -> 
        crossbinders (Array.length sorts) subst;
        Exists(pats,sorts,vars, norm subst tm)
    | ConstArray(s,sort,tm) -> 
        ConstArray(s, sort, norm subst tm)
    | Cases(tl) -> 
        Cases(norm_list subst tl)
    | Residue(t1, _) -> raise Impos
    | Hole x -> 
        (match Hashtbl.tryfind subst x with 
           | Some (Inl tm')
           | Some (Inr tm') -> 
               if tm.tmsort <> tm'.tmsort 
               then raise (Bad (spr "Sort mismatch in normalize term: expected %A got %A\n" tm.tmsort tm'.tmsort))
               else tm'
           | None -> tm)
    | Application({tm=Function(var,s,tm)}, arg) -> 
        Hashtbl.add subst var (Inr (norm subst arg));
        norm subst tm
    | Function _ -> tm
    | Application(t1,t2) -> 
        let t1 = norm subst t1 in 
          (match t1.tm with 
             | Function _  -> norm subst (Application(t1, t2))
             | _ -> Application(t1, t2))
            (* norm2 subst t1 t2 (fun t1 t2 -> Application(t1,t2)) *)
  and norm_list subst l =
    l |> List.map (fun tm -> norm subst tm)
  and norm_array subst l =
    l |> Array.map (fun tm -> norm subst tm)
  and norm_opt subst = function 
    | None -> None
    | Some t -> Some (norm subst t)
  and norm2 subst t1 t2 f = 
    let t1 = norm subst t1 in 
    let t2 = norm subst t2 in 
      f t1 t2
  and norm3 subst t1 t2 t3 f = 
    let t1 = norm subst t1 in 
    let t2 = norm subst t2 in 
    let t3 = norm subst t3 in 
      f t1 t2 t3
  in 
    (* pr "start norm\n"; *)
  let t = norm (Hashtbl.create 100) tm in 
    (* pr "done\n"; *)
    t
      
let normalizeOp op = match op with 
  | Assume(tm,c,a) -> Assume(normalizeTerm tm, c, a)
  | Query(tm) -> Query(normalizeTerm tm)
  | _ -> op

let mkPrelude typenames termconstrs = 
spr  "(declare-sort Pseudo_term) \n \
      (declare-datatypes () ((Pseudo_term_opt (PTNone) \n \
                                              (PTSome (Primitive_PTSome_proj_0 Pseudo_term))))) \n \
      (declare-sort Ref)\n \
      (declare-datatypes () ((String (String_const (String_const_proj_0 Int))))) \n \
      (declare-datatypes () ((Type_name %s))) \n \
      (declare-datatypes () ((Kind (Kind_star)  \n \
                                   (Kind_erasable) \n \
                                   (Kind_affine) \n \
                                   (Kind_prop) \n \
                                   (Kind_tcon (Kind_tcon_fst Kind) (Kind_tcon_snd Kind)) \n \
                                   (Kind_dcon (Kind_dcon_fst Type) (Kind_dcon_snd Kind))) \n \
                             (Type (Typ_undef) \n \
                                   (Typ_other (Typ_other_fst Int)) \n \
                                   (Typ_btvar (Typ_btvar_fst Int)) \n \
                                   (Typ_const (Typ_const_fst Type_name)) \n \
                                   (Typ_fun   (Typ_fun_fst Type) (Typ_fun_snd Type)) \n \
                                   (Typ_univ  (Typ_univ_fst Kind) (Typ_univ_snd Type)) \n \
                                   (Typ_dtuple (Typ_dtuple_fst Type) (Typ_dtuple_snd Type)) \n \
                                   (Typ_refine (Typ_refine_fst Type) (Typ_refine_snd Type)) \n \
                                   (Typ_app (Typ_app_fst Type) (Typ_app_snd Type)) \n \
                                   (Typ_dep (Typ_dep_fst Type) (Typ_dep_snd Term)) \n \
                                   (Typ_lam (Typ_lam_fst Type) (Typ_lam_snd Type)) \n \
                                   (Typ_tlam (Typ_tlam_fst Kind) (Typ_tlam_snd Type)) \n \
                                   (Typ_affine (Typ_affine_fst Type))) \n \
                             (Term (Term_undef) \n \
                                   (Exp_bvar (Exp_bvar_proj_0 Int))\n \
                                   (Term_other (Term_other_proj_0 Int)) \n \
                                   (BoxInt (BoxInt_proj_0 Int)) \n \
                                   (BoxBool (BoxBool_proj_0 Bool)) \n \
                                   (BoxString (BoxString_proj_0 String)) \n \
                                   (BoxRef (BoxRef_proj_0 Ref)) \n \
                                   %s )))\n"
    typenames termconstrs

(* (assert (forall ((t Type) (x Term)) *)
(*                 (! (= (TypeOf x) t) *)
(*                    :pattern (Term_constr_Prims.V t x)))) *)


let mk_Kind_star  ()     = App("Kind_star", Kind_sort, [||])
let mk_Kind_erasable ()  = App("Kind_erasable", Kind_sort, [||])
let mk_Kind_affine   ()  = App("Kind_affine", Kind_sort, [||])
let mk_Kind_prop     ()  = App("Kind_prop", Kind_sort, [||])
let mk_Kind_dcon t1 t2 = App("Kind_dcon", Arrow(Type_sort, Arrow(Kind_sort, Kind_sort)), [|t1;t2|])
let mk_Kind_tcon t1 t2 = App("Kind_tcon", Arrow(Kind_sort, Arrow(Kind_sort, Kind_sort)), [|t1;t2|])

let boxInt t            = App("BoxInt", Arrow(Int_sort, Term_sort), [| t |]) 
let unboxInt t          = App("BoxInt_proj_0", Arrow(Term_sort, Int_sort), [| t |]) 
let boxBool t           = App("BoxBool", Arrow(Bool_sort, Term_sort), [| t |]) 
let unboxBool t         = App("BoxBool_proj_0", Arrow(Term_sort, Bool_sort), [| t |]) 
let boxString t         = App("BoxString", Arrow(String_sort, Term_sort), [| t |]) 
let unboxString t       = App("BoxString_proj_0", Arrow(Term_sort, String_sort), [| t |]) 
let boxRef t            = App("BoxRef", Arrow(Ref_sort, Term_sort), [| t |]) 
let unboxRef t          = App("BoxRef_proj_0", Arrow(Term_sort, Ref_sort), [| t |]) 
let boxTerm sort t = match sort with 
  | Int_sort -> boxInt t
  | Bool_sort -> boxBool t
  | String_sort -> boxString t
  | Ref_sort -> boxRef t
  | _ -> raise Impos
let unboxTerm sort t = match sort with 
  | Int_sort -> unboxInt t
  | Bool_sort -> unboxBool t
  | String_sort -> unboxString t
  | Ref_sort -> unboxRef t
  | _ -> raise Impos

let mk_Typ_const n      = App("Typ_const", Arrow(Ext "Type_name", Type_sort), [|App(n, Ext "Type_name", [||])|])
let mk_Typ_fun t1 t2    = App("Typ_fun", Arrow(Type_sort, Arrow(Type_sort, Type_sort)), [|t1;t2|])
let mk_Typ_univ t1 t2   = App("Typ_univ", Arrow(Kind_sort, Arrow(Type_sort, Type_sort)), [|t1;t2|])
let mk_Typ_dtuple t1 t2 = App("Typ_dtuple", Arrow(Type_sort, Arrow(Type_sort, Type_sort)), [|t1;t2|])
let mk_Typ_refine t1 t2 = App("Typ_refine", Arrow(Type_sort, Arrow(Type_sort, Type_sort)), [|t1;t2|])
let mk_Typ_app t1 t2    = App("Typ_app", Arrow(Type_sort, Arrow(Type_sort, Type_sort)), [|t1;t2|])
let mk_Typ_dep t1 t2    = App("Typ_dep", Arrow(Type_sort, Arrow(Term_sort, Type_sort)), [|t1;t2|])
let mk_Typ_affine t1    = App("Typ_affine", Arrow(Type_sort, Type_sort), [|t1|])
let mk_Typ_lam t1 t2    = App("Typ_lam", Arrow(Type_sort, Arrow(Type_sort, Type_sort)), [|t1;t2|])
let mk_Typ_tlam t1 t2   = App("Typ_tlam", Arrow(Kind_sort, Arrow(Type_sort, Type_sort)), [|t1;t2|])

let p2t_name = "p2t"
let p2t p = App(p2t_name, Arrow(Pseudo_term_sort, Term_sort), [|p|])

let t2p_name = "t2p"
let t2p t = App(t2p_name, Arrow(Term_sort, Pseudo_term_sort), [| t |])

let ptnone_name = "PTNone"
let ptnone : tm = FreeV(ptnone_name, Pseudo_term_opt_sort)

let ptsome_name = "PTSome"
let ptsome p = App(ptsome_name, Arrow(Pseudo_term_sort, Pseudo_term_opt_sort), [|p|])
let ptsome_proj_0 p = App(mkProj "PTSome" 0, Arrow(Pseudo_term_opt_sort, Pseudo_term_sort), [|p|])

let kOfName = "KindOf"
let kindOf t  = App(kOfName, Arrow(Type_sort, Kind_sort), [| t |]) 

let tOfName = "TypeOf"
let typeOf t  = App(tOfName, Arrow(Term_sort, Type_sort), [| t |]) 

let boolTerm b = if b then True() else False()

let mkTypeConstant i = App("Typ_other", Arrow(Int_sort, Type_sort), [| Integer i |])

let mkTermConstant i = App("Term_other", Arrow(Int_sort, Term_sort), [| Integer i |])
let unitTerm = mkTermConstant -1 
let unitAssumption =
  let unitType = mk_Typ_const (typeNameOfLid Const.unit_lid) in
    Assume(Eq(typeOf unitTerm, unitType), None, AName "unitval")

let mkStringConstant i = App("String_const", Arrow(Int_sort, String_sort), [| Integer i |])

let typeOfV = 
  let tref = termref() in
  let tident = ident("t",dummyRange) in
  let t =  BoundV(1, Type_sort, "t", tref) in 
  let xref = termref() in
  let xident = ident("x",dummyRange) in
  let x =  BoundV(0, Term_sort, "x", xref) in 
  let v = App("Term_constr_Prims.V", Arrow(Type_sort, Arrow(Term_sort, Term_sort)), [| t;x |]) in 
    Assume(Forall([v],
                  [| Type_sort; Term_sort |], 
                  [|(Inl(mkbvd(tident,tident)), tref); 
                    (Inr(mkbvd(xident,xident)), xref)|], 
                  (Imp(Eq(typeOf x, t), 
                       Eq(typeOf v, mk_Typ_app (mk_Typ_const "Type_name_Prims.result") t)))),
           None, 
           AName "V typing")

let typeOfE = 
  let tref = termref() in
  let tident = ident("t",dummyRange) in
  let t =  BoundV(1, Type_sort, "t", tref) in 
  let xref = termref() in
  let xident = ident("x",dummyRange) in
  let x =  BoundV(0, Term_sort, "x", xref) in 
  let v = App("Term_constr_Prims.E", Arrow(Type_sort, Arrow(Term_sort, Term_sort)), [| t;x |]) in 
    Assume(Forall([v],
                  [| Type_sort; Term_sort |], 
                  [|(Inl(mkbvd(tident,tident)), tref); 
                    (Inr(mkbvd(xident,xident)), xref)|], 
                  (Imp(Eq(typeOf x, mk_Typ_const "Type_name_Prims.exn"), 
                       Eq(typeOf v, mk_Typ_app (mk_Typ_const "Type_name_Prims.result") t)))),
           None, 
           AName "E typing")

let typeOfErr = 
  let tref = termref() in
  let tident = ident("t",dummyRange) in
  let t =  BoundV(0, Type_sort, "t", tref) in 
  let v = App("Term_constr_Prims.Err", Arrow(Type_sort, Term_sort), [| t |]) in 
    Assume(Forall([v],
                  [| Type_sort |], 
                  [|(Inl(mkbvd(tident,tident)), tref) |], 
                  (Eq(typeOf v, mk_Typ_app (mk_Typ_const "Type_name_Prims.result") t))),
           None, 
           AName "Err typing")

let intTyping = 
  let xref = termref() in
  let xident = ident("x",dummyRange) in
  let x =  BoundV(0, Term_sort, "x", xref) in 
    Assume(Forall([],
                  [| Term_sort |], 
                  [|(Inr(mkbvd(xident,xident)), xref)|], 
                  (Iff(App(mkTester "BoxInt", Arrow(Term_sort, Bool_sort), [|x|]),
                       Eq(typeOf x, mk_Typ_const (typeNameOfLid Const.int_lid))))), 
           None, 
           AName "Int typing")

let boolTyping = 
  let xref = termref() in
  let xident = ident("x",dummyRange) in
  let x =  BoundV(0, Term_sort, "x", xref) in 
    Assume(Forall([],
                  [| Term_sort |], 
                  [|(Inr(mkbvd(xident,xident)), xref)|], 
                  (Iff(App(mkTester "BoxBool", Arrow(Term_sort, Bool_sort), [|x|]),
                       Eq(typeOf x, mk_Typ_const (typeNameOfLid Const.bool_lid))))), 
           None, 
           AName "Bool typing")

let stringTyping = 
  let xref = termref() in
  let xident = ident("x",dummyRange) in
  let x =  BoundV(0, Term_sort, "x", xref) in 
    Assume(Forall([],
                  [| Term_sort |], 
                  [|(Inr(mkbvd(xident,xident)), xref)|], 
                  (Iff(Eq(typeOf x, mk_Typ_const (typeNameOfLid Const.string_lid)), 
                       App(mkTester "BoxString", Arrow(Term_sort, Bool_sort), [|x|])))),
           None, 
           AName "String typing")

let refTyping = 
  let xref = termref() in
  let xident = ident("x",dummyRange) in
  let x =  BoundV(1, Term_sort, "x", xref) in 
  let tref = termref() in
  let tident = ident("t",dummyRange) in
  let t =  BoundV(0, Type_sort, "t", tref) in 
    Assume(Forall([],
                  [| Term_sort; Type_sort |], 
                  [|(Inr(mkbvd(xident,xident)), xref); (Inl(mkbvd(tident,tident)), tref)|], 
                  (Imp(Eq(typeOf x, mk_Typ_app (mk_Typ_const (typeNameOfLid Const.ref_lid)) t), 
                       App(mkTester "BoxRef", Arrow(Term_sort, Bool_sort), [|x|])))),
           None, 
           AName "Ref typing")

let tappKinding = 
  let t1ref = termref() in 
  let t1_id = ident("t1", dummyRange) in
  let t1 = BoundV(1, Type_sort, "t1", t1ref) in 
  let t2ref = termref() in 
  let t2_id = ident("t2", dummyRange) in
  let t2 = BoundV(0, Type_sort, "t2", t2ref) in 
    Assume(Forall([], 
                  [| Type_sort; Type_sort |], 
                  [| (Inl(mkbvd(t1_id,t1_id)), t1ref); (Inl(mkbvd(t2_id,t2_id)), t2ref) |],
                  (Imp(And(Eq(kindOf t1, mk_Kind_tcon (mk_Kind_star()) (mk_Kind_star())), 
                           Eq(kindOf t2, mk_Kind_star())), 
                       Eq(kindOf (mk_Typ_app t1 t2), mk_Kind_star())))), 
           None, 
           AName "Typ_app kinding")

let pseudoTermInj = 
  let tref = termref() in
  let tident = ident("t",dummyRange) in
  let t =  BoundV(0, Term_sort, "t", tref) in 

  let pref = termref() in
  let pident = ident("p",dummyRange) in
  let p =  BoundV(0, Pseudo_term_sort, "p", pref) in 

  [DeclFun(p2t_name,  [| Pseudo_term_sort |], Term_sort, None);  
   DeclFun(t2p_name,  [| Term_sort |], Pseudo_term_sort, None);  
   Assume(Forall([], 
                 [| Pseudo_term_sort |], 
                 [| (Inl(mkbvd(pident,pident)), pref) |], 
                 Eq(p, t2p(p2t p))),
          None, 
          AName "P2T.T2P"); 
   Assume(Forall([], 
                 [| Term_sort |], 
                 [| (Inl(mkbvd(tident,tident)), tref) |], 
                 Eq(t, p2t(t2p t))),
          None, 
          AName "T2P.P2T")]
                 
let basicOps prelude termctx : list<op> = 
  List.rev
    ([ DefPrelude prelude;
       DeclFun(kOfName,  [| Type_sort |], Kind_sort, None);
       DeclFun(tOfName,  [| Term_sort |], Type_sort, None);
       unitAssumption;
       typeOfV;
       typeOfE;
       typeOfErr;
       boolTyping;
       intTyping;
       stringTyping;
       refTyping;
       tappKinding]@pseudoTermInj)

let mkTermctx (i:option<string>) (tns : list<string>) (data:list<string * list<sort>>) : (termctx * list<op>) =
  let smap = mkSortMap () in 
  let _ = smap.addSorts [Int_sort;
                         Bool_sort;
                         String_sort;
                         Ref_sort;
                         Pseudo_term_sort;
                         Pseudo_term_opt_sort;
                         Kind_sort;
                         Type_sort;
                         Term_sort] in 
  let termcons_prelude = data |> List.map (fun (nm, argsorts) -> 
                                             let arity = List.length argsorts in 
                                             let args = List.zip  argsorts in 
                                               spr "(%s %s)" nm
                                                 (String.concat "\n"
                                                    (List.map2  (fun i s -> spr "(%s %s)" (mkProj nm i) (strSort s))
                                                       (Util.list0N (arity - 1)) argsorts))) in
  let termcons_prelude = String.concat "\n\t" termcons_prelude in
    
  let fmap = mkFunSymMap () in 
  let termctx = {funSymMap=fmap;
                 sortMap=smap; 
                 stream=(match i with None -> None | Some i -> Some (openStream i));
                 id=i} in 

  let prelude = mkPrelude (String.concat "\n\t" (List.map (spr "(%s)") tns)) termcons_prelude in
    termctx, basicOps prelude termctx  
      
(* ******************************************************************************** *)
(* Type normalization *)
(* ******************************************************************************** *)

let normalizeTyp tcenv t : typ = 
  let rebuild subst t args = 
    let t = List.fold_left (fun t arg -> match arg with 
                              | Inl(t2,k,p) -> twithinfo (Typ_app(t,t2)) k p
                              | Inr(e2,k,p) -> twithinfo (Typ_dep(t,e2)) k p) t args in 
      t, ([], subst) in 
  let applyVSubst s x = 
    let x = bvar_to_bvd x in 
      findOpt (function Inl _ -> false | Inr (y, _) -> bvd_eq x y) s in
  let applyTSubst s x = 
    let x = bvar_to_bvd x in 
      findOpt (function Inl (y, _) -> bvd_eq x y | Inr _ -> false) s in
  let rec rt rk vt re (args, subst) binders t =
    let rt env t = rt rk vt re env binders t in 
    (* let k, _ = rk ([],subst) t.sort in  *)
    let k = t.sort in 
    let t = setsort t k in 
    let t = compress t in 
      match t.v with 
        | Typ_const(fv, eref) -> 
            (match Tcenv.lookup_typ_abbrev tcenv fv with 
               | None -> rebuild subst t args
               | Some t -> rt (args, subst) t)
              
        | Typ_btvar bv -> 
            (match applyTSubst subst bv with 
               | None -> rebuild subst t args
               | Some (Inl(_, t)) -> rt (args, subst) t
               | _ -> raise Impos)
              
        | Typ_app(t1,t2) -> 
            let t2, _ = rt ([],subst) t2 in 
              rt ((Inl(t2,t.sort,t.p))::args, subst) t1
                
        | Typ_dep(t1,e2) -> 
            let e2, _ = re ([],subst) binders e2 in 
              rt (Inr(e2,t.sort,t.p)::args, subst) t1 
                
        | Typ_lam(x,t1,body) -> 
            (match args with 
               | [] -> 
                   let t1, _ = rt ([], subst) t1 in 
                   let body, _ = rt ([], subst) body in 
                     twithinfo (Typ_lam(x, t1, body)) t.sort t.p, ([], subst)
               | (Inr(actual,_,_))::rest -> 
                   (* let _ = pr "Binding argument %s to actual parameter %s\n" (string_of_bvd x) (actual.ToString()) in *)
                   let t, _ = rt (rest, (Inr(x, actual)::subst)) body in 
                     t, ([], subst)
               | _ -> raise Impos)
              
        | Typ_tlam(a,k,body) -> 
            (match args with 
               | [] -> 
                   let k, _ = rk ([],subst) binders k in 
                   let body, _ = rt ([], subst) body in 
                     twithinfo (Typ_tlam(a, k, body)) t.sort t.p, ([], subst)
               | (Inl(actual,_,_))::rest -> 
                   (* let _ = pr "Binding argument %s to actual parameter %s\n" (string_of_bvd a) (actual.ToString()) in *)
                   let t, _ = rt (rest, (Inl(a, actual)::subst)) body in 
                     t, ([], subst)
               | (Inr(actual,_,_))::_ -> 
                   pr "Found type %s; \nexpected type app, got type dep %s\n"
                     (t.ToString()) (actual.ToString());
                   raise Impos)
              
        | Typ_ascribed(t, _) ->  rt (args, subst) t

        | _  ->  (* none of the remaining cases can reduce *) 
            let t, _ = vt ([], subst) binders t in 
              rebuild subst t args in 
  let rec re rk rt ve (_,subst) binders e =
    let re = re rk rt ve ([],subst) binders in 
    (* let t, _ = rt ([],subst) e.sort in  *)
    let t = e.sort in
    let e = setsort e t in 
      match e.v with 
        | Exp_bvar bv -> 
            (match applyVSubst subst bv with 
               | None -> e, ([], subst)
               | Some(Inr(_, e)) -> re e
               | _ -> raise Impos)
        | _ -> ve ([],subst) binders e in 
 fst <| AbsynUtils.reduce_typ 
      (fun rk rt re subst binders k -> rk subst binders k)
      rt re
      AbsynUtils.combine_kind
      AbsynUtils.combine_typ
      AbsynUtils.combine_exp
      ([],[]) [] t
      
(* ******************************************************************************** *)
(* Alpha conversion ... fast *)
(* ******************************************************************************** *)
let sprFvs fvs = 
  spr "Free variables are: [%s], %s\n" 
    (String.concat "; " (List.map (fun tv -> Pretty.strBvd tv.v) (fst fvs)))
    (String.concat "; " (List.map (fun tv -> Pretty.strBvd tv.v) (snd fvs)))

let exists_sub_term (p : typ -> bool) t : bool = 
  let r = snd <| AbsynUtils.reduce_typ 
      (fun vk rt re -> vk)
      (fun rk vt re env binders t -> 
         if p t then (),1
         else vt env binders t)
      (fun rk rt ve -> ve)
      (fun _ _ e -> ((),e))
      (fun t _ e -> if e > 0 then pr "Pred found(%d): %s\n" e (Pretty.strTyp t); ((), if e > 0 then e+1 else e))
      (fun _ _ e -> ((),e))
      0 [] t in 
    r > 0


(* ******************************************************************************** *)
type goals = list<tm>
type qnames     = list<string> 
type qvars      = list<tm>
type qsorts     = list<sort>

let takeUntil f = 
  let rec aux out = function 
    | [] -> List.rev out, []
    | hd::tl when f hd -> List.rev out, (hd::tl)
    | hd::tl -> aux (hd::out) tl in 
    aux [] 

let rec sortsFromTyp t = match t.v with 
  | Typ_univ(_, _, _, t) -> Type_sort::(sortsFromTyp t)
  | Typ_fun(_, _, t) -> Term_sort::(sortsFromTyp t)
  | _ -> [] 

let rec sortMapFromTyp t = match t.v with 
  | Typ_univ(a, k, _, t) -> (Inl(a,k), Type_sort)::(sortMapFromTyp t)
  | Typ_fun(x, t0, t) -> (Inr(x,t0), Term_sort)::(sortMapFromTyp t)
  | _ -> [] 


let addOp op : ST<unit>   = upd (fun s -> {s with st={s.st with ops=(normalizeOp op)::s.st.ops}})
let addOps ops : ST<unit> = upd (fun s -> {s with st={s.st with ops=(List.map normalizeOp ops)@s.st.ops}})
let addQops ops : ST<unit> = upd (fun s -> {s with st={s.st with qops=(List.map normalizeOp ops)@s.st.qops}})
let addPPName (k,v) (h:opState) : STR<unit> = 
  let s, h = get h in 
    Hashtbl.add s.st.pp_name_map k v; 
    (), h
let addUnfolding uf : ST<unit> = upd (fun s -> {s with st={s.st with unfoldings=uf::s.st.unfoldings}})
let internUvar uvar_k term ops : ST<unit> = 
  let ops = List.map normalizeOp ops in
  upd (fun s -> {s with st={s.st with uvars=(uvar_k,term,ops)::s.st.uvars}})
let internString bytes term ops : ST<unit> =
  let ops = List.map normalizeOp ops in
    upd (fun s -> {s with st={s.st with strings=(bytes,term,ops)::s.st.strings}})
let internFloat f term ops : ST<unit> = 
  let ops = List.map normalizeOp ops in
    upd (fun s -> {s with st={s.st with floats=(f,term,ops)::s.st.floats}})
let internBvar bv term ops : ST<unit> = 
  let ops = List.map normalizeOp ops in
    upd (fun s -> {s with st={s.st with bvars=(bv,term,ops)::s.st.bvars}})
let internFvar fv term ops : ST<unit> = 
  let ops = List.map normalizeOp ops in
    upd (fun s -> {s with st={s.st with fvars=(fv,term,ops)::s.st.fvars}})
let internTransformer str typ term phiopt : ST<unit> = 
  (* let _ = if !Options.silent then () else pr "Interning type %s at term %A\n" (typ.ToString()) term in  *)
    upd (fun s -> 
           let tx, rev = s.st.transformers in 
           let rev = match term.tm with 
             | App("Typ_other", _, [| {tm=Integer i} |]) -> 
                 map_add rev i (typ, phiopt)
             | _ -> raise Impos in 
           let hkt = AbsynUtils.hashkey_typ typ in 
           let hkk = AbsynUtils.hashkey_kind typ.sort in 
           let tx = match map_tryfind tx hkt with
             | None -> 
                 let ktable = map_create 17 in
                 let ktable = map_add ktable hkk [typ,term,phiopt] in 
                   map_add tx hkt ktable
             | Some ktable -> 
                 match map_tryfind ktable hkk with
                   | None -> map_replace tx hkt (map_add ktable hkk [typ,term,phiopt])
                   | Some l -> map_replace tx hkt (map_replace ktable hkk ((typ,term,phiopt)::l)) in 
             {s with st={s.st with transformers=(tx,rev)}})
      (* {s with transformers=(str,typ,term,phiopt)::s.transformers}) *)
let gammaLid = [ident("GAMMA", 0L)]
let incrCtr h : STR<int> = 
  let s, h = get h in 
  let _, h = put {s with st={s.st with ctr=s.st.ctr + 1}} h in 
    s.st.ctr, h

type env = (list<Disj<(bvvdef*typ),(btvdef*kind)>> * opState)
let get_tcenv (_, opstate) = match opstate.st.env with 
    | None -> raise Impos
    | Some tcenv -> tcenv
let push_typ (e1, e2) x t = (Inl(x, t))::e1, e2
let push_kind (e1, e2) x k = (Inr(x, k))::e1, e2
let lookup (e, _) ix = 
  if ix >= List.length e 
  then failwith "decoding failed: index out of bounds"
  else List.nth e ix
let lookup_bvar_ix e ix = 
  match lookup e ix with 
    | Inl(x, t) -> Absyn.bvd_to_bvar_s x t
    | _ -> failwith "decoding failed: expected type, got kind"
let lookup_btvar_ix e ix = 
  match lookup e ix with 
    | Inr(x, k) -> Absyn.bvd_to_bvar_s x k
    | _ -> failwith "decoding failed: expected kind, got type"
let lookup_lid e lid = Tcenv.lookup_lid (get_tcenv e) lid
let lookup_bvar e bv = Tcenv.lookup_bvar (get_tcenv e) bv
let lookup_typ_lid e lid = Tcenv.lookup_typ_lid (get_tcenv e) lid
