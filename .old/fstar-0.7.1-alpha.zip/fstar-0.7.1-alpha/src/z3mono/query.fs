#light "off"
 
module Microsoft.FStar.Z3Exe.Query

open Microsoft.FStar
open Z3Exe.Env
open Z3Exe.BasicDT
open Z3Exe.Term
open Z3Exe.EncodingDT
open Util
open Absyn
open Profiling 

let log = logopt
let flush = function None -> () | Some (s:System.IO.StreamWriter) -> s.Flush()
let close = function None -> () | Some (s:System.IO.StreamWriter) -> s.Close()
let logOps = function None -> fun _ _ -> () | Some s -> logOps s
let cleanup tc =  close tc.stream
  
let giveZ3 opstack opstate theory = 
  let stream = opstate.termctx.stream in
  let ppmap = opstate.st.pp_name_map in 
    logOps stream ppmap theory;
    flush stream;
    opstack@theory
        
let z3ctr = ref 1

let askZ3 ctx q hdl = 
  incr z3ctr;
  let labels = ctx.st.labels in
  let info = init_info ctx.st.pp_name_map in 
    log ctx.termctx.stream (opToSmt info (Assume(q, None, AName "Query")));
    log ctx.termctx.stream "\n(check-sat)\n";
    flush ctx.termctx.stream;
    hdl (processZ3Answer ctx.termctx.stream labels) info
      
let insistZ3Unsat ctx q = askZ3 ctx q (fun b _ -> b)
        
(* ******************************************************************************** *)
(* External interface *)
(* ******************************************************************************** *)
let query' (env:Tcenv.env) (phi:formula) : bool =
  let init, mkTctx = initState env in 
  let _, envops = "encodeEnvironment" ^^ lazy (runState init encodeEnvironment) in 
  let bgtheory = List.rev envops.st.ops in
  let _ = giveZ3 [] envops bgtheory in 
  let _ = 
    if !Options.logQueries 
    then logopt init.termctx.stream ";; Starting queries\n" in
  let envops = {envops with st={envops.st with ops=Mark (Inr 0)::envops.st.ops}; strip_labels=false} in
  let query, qstate = "encodeQueryFormula" ^^ lazy runState envops (encodeFormula' phi) in 
  let queryOps, _ = takeUntil (function (Mark (Inr 0)) -> true | _ -> false) qstate.st.ops in 
    if !Options.__unsafe 
    then true
    else
      let opstack = giveZ3 bgtheory envops (List.rev queryOps) in 
      let res = insistZ3Unsat qstate (Not query) in 
        cleanup envops.termctx;
        res

let check_skip descr f : bool =
  ignore (bumpQueryCount ());
  if !Options.describe_queries then descr ();
  let skip =
    (match !Options.skip_queries with
       | None -> false
       | Some x ->
           (if x > !Options.skipped_queries then
              (Options.skipped_queries := !Options.skipped_queries + 1;
               true)
            else
              (if x = !Options.skipped_queries && not (!Options.describe_queries) then
                 (descr ();  (* print the starting point *)
                  Options.skipped_queries := !Options.skipped_queries + 1);
               false))) in
    if skip then true
    else f ()
            
let query env phi = 
  check_skip 
    (fun () -> 
       pr "%s\n" (Range.string_of_range (Tcenv.get_range env));
       pr "%s\n" (Pretty.strTypAsFormula phi))
    (fun () -> query' env phi)
    
let mkEq (env:Tcenv.env) (t:typ) (e1:exp) (e2:exp) : typ =
  let eq_k = Tcenv.lookup_typ_lid env Const.eq_lid in
  let eq_typ = twithsort (Typ_const((fvwithsort Const.eq_lid eq_k), None)) eq_k in
  let eq_app1_k = open_kind eq_k t in
  let eq_app1 = twithinfo (Typ_app(eq_typ, t)) eq_app1_k eq_typ.p in
  let eq_app2_k = open_kind_with_exp eq_app1.sort e1 in
  let eq_app2 = twithinfo (Typ_dep(eq_app1, e1)) eq_app2_k e1.p in
  let eq_app3_k = open_kind_with_exp eq_app2.sort e2 in
  let eq_app3 = twithinfo (Typ_dep(eq_app2, e2)) eq_app3_k e2.p in
    eq_app3

let query_equality (env:Tcenv.env) (e1:Absyn.exp) (e2:Absyn.exp) : bool =
  let phi = mkEq env e1.sort e1 e2 in 
    query env phi
