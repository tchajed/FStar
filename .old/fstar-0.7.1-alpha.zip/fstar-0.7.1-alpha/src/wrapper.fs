module Microsoft.FStar.Wrapper

let cleanup () = 
#if MONO
#else
  ProofState.clear();
  Z3Encoding.Term.cleanup();
#endif
  System.Console.Out.Flush();
  Util.flush_err_out();
  #if NOCERT
  #else
      Runtime.Pickler.flushFiles();
  #endif
    flush(stdout)
    
let _ = 
  try
    let result = Microsoft.FStar.FStar.main () in 
    let _ = cleanup() in
      System.Environment.Exit(if result then 0 else -1)
  with e when !Options.suppress_trace -> (* when !Util.silent ->  *)
    (Printf.printf "Unexpected exception :( \n";
     if not !Options.silent then Printf.printf "%A" e;
     cleanup();
     System.Environment.Exit(-1))
      
