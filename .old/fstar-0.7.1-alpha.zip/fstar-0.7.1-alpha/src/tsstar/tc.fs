#light "off"
// (c) Microsoft Corporation. All rights reserved

(*
  Translates a sequence of source modules into a sequence of JS statements
  
  The main idea:
    1. Implement a **source-to-source** translation of a TS* Absyn.exp
    2. Translate the elaborated source to JavaScript by calling Absyn2JS

  Note: We DO NOT interleave the typechecking and elaboration of a
  source term with JS code generation. Implementing elaboration as a
  source-to-source translation allows us to reuse Absyn2JS mostly as
  is, rather than reimplementing it from scratch.

  Here's the general structure of step (1)
  
   __________________
  |                  |
  | S;G |- e ~> e':t |  where e' is also TS* (i.e., a source-to-source translation)
  |__________________|


  S;G |- e_i ~> e_i': t_i	t = {f_i : t_i}
  ------------------------------------------------- [T-Rec]
  S;G |- {f_i=e_i} ~> createRecord{f_i=e_i', tag=[[ t ]]} : t


  S;G |- e ~> e' : {f_i : t_i}	 
  --------------------------------------------[T-Read]
  S;G |- e.f_i ~> e'.f_i : t_i 


  S;G |- e ~> e' : Any                      //following TS
  -------------------------------------------- [A-Read]
  S; G |- e.f ~> read e' f: Any

  S; G |- e1 ~> e1' : {..., f_i :W t_i, ...}
  S; G |- e2 ~> e2' : t_i'    t_i' < t_i
  ------------------------------------------- [T-Write]
  S; G |- e1.f := e2 ~> e1'.f := e2' : t_i'


  S; G |- e1 ~> e1' : Any
  S; G |- e2 ~> e2' : t
  ------------------------------------------------------ [A-Write]
  S;G |- e1.f = e2 ~> write e1' f e2': Any


  S;G,x:t |- e ~> e' : t'
  ------------------------------------------------ [T-Lam]
  S;G |- \x:t.e ~> createFunction x t e': t -> t'
  
  S;G |- e1 ~> e1' : t -> t'
  S;G |- e2 ~> e2' : t2		t2 < t
  -------------------------------------------- [T-App]
  S;G |- e1 e2 ~> e1' e2' : t'


  S;G |- e1 ~> e1' : Any
  S;G |- e2 ~> e2' : t
  ------------------------------------------------------ [A-App]
  S;G |- e1 e2 ~> apply e1' e2' : Any
    

  S(D) = t_1 -> ... -> t_n -> T      
  S;G |- e_i ~> e_i' : t_i'    t_i' < t_i
  ------------------------------------------------------------ [T-D]
  S;G |- D e_i ~> createRecord{c=[[D]], i = e_i', tag = [[T]]} : T


  S;G |- e ~> e' : T
  S(D) = t_1 -> ... -> t_n -> T        |x_i| = |t_i|
  S;G,x_i:t_i |- e1 ~> e1' : t1
  S;G |- e2 ~> e2' : t2          t3 = t1 if t1 == t2 and Any otherwise
  -------------------------------------------------------------[T-Match]
  S;G |- match e with D ~x -> e1 else e2  
  ~> match e' T D ~x e1' e2'
  

  S;G |- e1 ~> e1' : t
  S;G,x:t |- e2 ~> e2' : t2 
  -----------------------------------------------------[T-Let]
  S;G |- let x = e1 in e2 ~> let x = e1' in e2' : t2


  S;G |- e ~> e': t'   t' ~ t
  ---------------------------------------------- [T-Can]
  S;G |- canTag t e ~> canTag t e' : t


  S;G |- e ~> e' : t'    t' ~ t
  ---------------------------------- [TA-Wrap] //may fail eagerly on primitives; but otherwize lazy wrapping
  S;G |- wrap t e ~> wrap t e' : t

*)

module Microsoft.FStar.TSStar

open Microsoft.FStar
open Tcenv
open Absyn

exception NYI
exception Impos

(* environment with a list of lident for user-defined types *)
type tsenv = { tcenv: Tcenv.env; lids: lident list}

(* Utils *)
let spr = Printf.sprintf
let pr = Printf.printf

let liOfSl = AbsynUtils.liOfSl
let bvdOfString = AbsynUtils.bvdOfString
let bvdToExp = AbsynUtils.bvdToExp
let Wfv = AbsynUtils.Wfv
let mkExpApp = AbsynUtils.mkExpApp

let e_String (s : string) : exp =
  AbsynUtils.mkExpTyp (Exp_constant (Sugar.Const_string (Util.unicodeEncoding.GetBytes(s), dummyRange))) Const.string_typ


let mkeseq es =
    let do1 e aout =
        let name = bvdOfString "_" in
            ewithinfo (Exp_let (false, [(name, e.sort, e)], aout)) aout.sort e.p
    in

    match List.rev es with
    | [] -> failwith "mkeseq: empty-list"
    | e :: es -> List.fold_right do1 es e

let tagName = "rtti"

(* TS* [mutable] tag encoding *)
let tmut_id, tmut = Const.mutable_lid, Const.mutable_typ

let is_mutable (env:tsenv) ty =
    match (Tcenv.expand_typ env.tcenv ty).v with
    | Typ_app (cty, ty) when TypeRelations.alpha_equiv env.tcenv cty tmut -> Some ty
    | _ -> None

let desugar_field_type (env:tsenv) ty =
    match is_mutable env ty with
    | None    -> (false, ty)
    | Some ty -> (true, ty)

(* TS* types *)
let tany_id   , tany    = Const.mk_typ ["Prims"; "any"] Kind_star
let tun_id    , tun     = Const.mk_typ ["Prims"; "un"] Kind_star
let tunit_id  , tunit   = Const.unit_lid, Const.unit_typ  //Const.mk_typ ["Prims"; "unit"] Kind_star
let tbool_id  , tbool   = Const.bool_lid, Const.bool_typ //Const.mk_typ ["Prims"; "bool"] Kind_star
let tnumber_id, tnumber = Const.num_lid, Const.num_typ   //Const.mk_typ ["Prims"; "number"] Kind_star
let tstring_id, tstring = Const.string_lid, Const.string_typ //Const.mk_typ ["Prims"; "string"] Kind_star

let kcon = Kind_tcon(None, Kind_star, Kind_star) 
let tarray_id, tarray = Const.array_lid, twithsort (Typ_const({v=Const.array_lid; sort=kcon; p = dummyRange}, None)) kcon

let tbase = [tunit; tbool; tnumber; tstring]

let tarrow ty1 ty2 = twithinfo (Typ_fun (None, ty1, ty2)) Kind_star dummyRange

let id_typeOf = Const.p2l ["Prims"; "typeof"]
let pr_typeOf : var<typ> = { v = id_typeOf; sort = tarrow tany tstring ; p = dummyRange; }

let is_any_type env ty =TypeRelations.alpha_equiv env.tcenv ty tany

let is_un_type env ty =TypeRelations.alpha_equiv env.tcenv ty tun

let is_array_type ty = match ty.v with
  | Typ_app({v = Typ_const({v=lid; sort = _; p = _}, _); sort = _; p = _}, _) -> Sugar.lid_equals lid Const.array_lid
  | _ -> false

let get_array_element_type ty = match ty.v with
  | Typ_app({v = Typ_const({v=lid; sort = _; p = _}, _); sort = _; p = _}, t) -> t
  | _ -> raise (Error (spr "get_array_element_type: %s not an array type" (Pretty.strTyp ty), dummyRange))

let is_base_type env ty =
    List.exists
        (fun bty -> TypeRelations.alpha_equiv env.tcenv ty bty)
        tbase


let is_ts_type env (t : typ) = 
  let rec aux t = match t.v with
    | Typ_unknown
    | Typ_uvar   _
    | Typ_meta   _
     
    | Typ_dep    _
    | Typ_affine _
    | Typ_refine _
    | Typ_lam    _
    | Typ_tlam   _
    | Typ_univ   _
    | Typ_ascribed _ -> false

    | Typ_app(tf, ta) -> is_array_type t && aux ta 

    | Typ_btvar btvar -> 
      List.exists (function lid -> btvar.v.realname.idText = (Pretty.str_of_lident lid)) env.lids

    | Typ_const (c, _) -> 
       //let _ = Printf.printf "\n is_ts_type: %s" (Pretty.str_of_lident c.v) in
       //let _ = List.map (function lid -> Printf.printf "\n lid: %s" (Pretty.str_of_lident lid)) env.lids in
      is_any_type env t || is_un_type env t || is_base_type env t || 
                    (List.exists (function lid -> Sugar.lid_equals lid c.v) env.lids)
    | Typ_fun (_, ty1, ty2) -> List.forall aux [ty1; ty2]
    | Typ_dtuple tys -> List.forall (fun (_, ty) -> aux ty) tys

    | Typ_record (fds, _) ->
        List.forall (fun (_, ty) -> aux (snd (desugar_field_type env ty))) fds
  in aux t  

let e_True  : exp = AbsynUtils.expTrue
let e_False : exp = AbsynUtils.expFalse
let e_Unit : exp = AbsynUtils.mkExpTyp (Exp_constant (Sugar.Const_unit)) tunit

(* [Q] object *)
let id_Q = Const.p2l ["Q"]
let pr_Q : var<typ> = { v = id_Q; sort = tany; p = dummyRange; }

let Q = AbsynUtils.mkFvarTyp pr_Q.v pr_Q.sort

let Q_field (x : string) : exp =
    ewithinfo (Exp_proj (Q, Const.p2l [x])) tany dummyRange

let get_base_type env ty =
    let bty = List.find (fun bty -> TypeRelations.alpha_equiv env.tcenv ty bty) tbase in

    match bty.v with
    | Typ_const (c, _) ->
      if Sugar.lid_equals c.v Const.num_lid then Q_field "Number"
      else if Sugar.lid_equals c.v Const.string_lid then Q_field "String"
      else if Sugar.lid_equals c.v Const.unit_lid then Q_field "Unit"
      else Q_field "Bool"
    | _ -> failwith "get_base_type"

let Q_Any      : exp = Q_field "Any"
let Q_Un       : exp = Q_field "Un"
let Q_addField : exp = Q_field "addField"
let Q_arrow    : exp = Q_field "arrow"
let Q_data     : exp = Q_field "data"
let Q_rec      : exp = Q_field "rec"
let Q_recname  : exp = Q_field "recname"

let Q_apply q es =
    List.fold_left
        (fun q e -> ewithinfo (Exp_app (q, e)) tany dummyRange)
        q es

let Q_P_arrow e1 e2 : exp =
    Q_apply Q_arrow [e1; e2]

let Q_P_data name =
    Q_apply Q_data [e_String name]

let Q_P_rec name =
    Q_apply Q_recname [e_String name]


let Q_P_fields fds =
    List.fold_left
        (fun fty ((x : Sugar.LongIdent), m, ty) ->
            Q_apply
                Q_addField
                [e_String x.str; ty; fty; (if m then e_True else e_False)])
        (Q_apply Q_rec [e_Unit]) fds

(* pair : {0:t1; 1:t2} *)
let Q_P_pair e1 e2 : exp = 
    Q_P_fields [(liOfSl ["0"], true, e1); (liOfSl ["1"], true, e2)]

(* TS* sub-typing *)
let rec is_sub env ty1 ty2 =
    // let _ = printfn "SUB: %s %s" (Pretty.strTyp ty1) (Pretty.strTyp ty2) in

    let ty1 = Tcenv.expand_typ env.tcenv ty1 in
    let ty2 = Tcenv.expand_typ env.tcenv ty2 in

    // let _ = printfn "SUBX: %s %s" (Pretty.strTyp ty1) (Pretty.strTyp ty2) in

    let for_field fds (f, (m, ty)) =
        match List.tryFind (fun (f', _) -> Sugar.lid_equals f f') fds |> Option.map snd with
        | None -> is_sub env ty tany
        | Some (m', _) when m || m' -> false
        | Some (_, ty') -> is_sub env ty ty'
    in

    if TypeRelations.alpha_equiv env.tcenv ty1 ty2 then
        true
    else if is_any_type env ty2 then
        match ty1.v with
        | _ when is_base_type env ty1 || is_any_type env ty1 ->
            true
        | Typ_fun (_, dom, codom) ->
            List.forall (fun t -> is_sub env t tany) [dom; codom]
        | Typ_record (fields, _) ->
            List.forall (fun (_, t) -> is_sub env t tany) fields
        | Typ_const(c, _) when Tcenv.is_record env.tcenv c.v ->
          if List.exists (function lid -> Sugar.lid_equals lid c.v) env.lids then true
          else let (l, t, ps, t') = Tcenv.lookup_record_typ_by_name env.tcenv c.v in
            is_sub ({env with lids = c.v :: env.lids}) t' tany
        | Typ_dtuple ([(_, t1); (_, t2)]) -> List.forall (fun t -> is_sub env t tany) [t1; t2]
        | Typ_app (tf, ta) when is_array_type ty1 -> is_sub env ta tany
        | _ -> false
    else
        match ty1.v, ty2.v with
        | Typ_fun (_, dom1, codom1), Typ_fun (_, dom2, codom2) ->
            is_sub env dom2 dom1 && is_sub env codom1 codom2
        | Typ_record (fds1, _), Typ_record (fds2, _) ->
            let fds1 = List.map (fun (x, t) -> (x, desugar_field_type env t)) fds1 in
            let fds2 = List.map (fun (x, t) -> (x, desugar_field_type env t)) fds2 in
                   List.forall (for_field fds2) fds1
                && List.forall
                        (fun (f, _) -> List.exists (fun (f', _) -> Sugar.lid_equals f f') fds1)
                        fds2
        | Typ_record _, Typ_const (c, _) when Tcenv.is_record env.tcenv c.v ->
            let (l, t, ps, t') = Tcenv.lookup_record_typ_by_name env.tcenv c.v in
                if not (List.isEmpty ps) then
                    false
                else
                    is_sub env ty1 t'
        | Typ_const (c, _), Typ_record _ when Tcenv.is_record env.tcenv c.v ->
            let (l, t, ps, t') = Tcenv.lookup_record_typ_by_name env.tcenv c.v in
                if not (List.isEmpty ps) then
                    false
                else
                    is_sub env t' ty2
        | _, _ -> false

(* TS* type compatibility *)
let rec is_compatible (env:tsenv) ty1 ty2 =
    let ty1 = Tcenv.expand_typ env.tcenv ty1 in
    let ty2 = Tcenv.expand_typ env.tcenv ty2 in

    match ty1.v, ty2.v with
    | Typ_fun (_, dom1, codom1), Typ_fun (_, dom2, codom2) ->
        is_compatible env dom1 dom2 && is_compatible env codom1 codom2

    | Typ_const(c1, _), Typ_const(c2, _) when Sugar.lid_equals c1.v c2.v -> true

    | Typ_const(c, _), _ when Tcenv.is_record env.tcenv c.v ->
        let (_, _, _, t) = Tcenv.lookup_record_typ_by_name env.tcenv c.v in
        is_compatible env t ty2

    | _, Typ_const(c, _) when Tcenv.is_record env.tcenv c.v ->
        let (_, _, _, t) = Tcenv.lookup_record_typ_by_name env.tcenv c.v in
        is_compatible env ty1 t

    | Typ_record (fds1, _), Typ_record (fds2, _) ->
        let fds1 = List.map (fun (x, t) -> (x, desugar_field_type env t)) fds1 in
        let fds2 = List.map (fun (x, t) -> (x, desugar_field_type env t)) fds2 in

            List.forall
                (fun (f, (m, ty)) ->
                    match List.tryFind (fun (f', _) -> Sugar.lid_equals f f') fds2 with
                    | None -> is_compatible env ty tany
                    | Some (_, (m', ty')) -> m = m' && is_compatible env ty ty')
                fds2
         && List.forall
                (fun (f, (_, ty)) ->
                     match List.tryFind (fun (f', _) -> Sugar.lid_equals f f') fds1 with
                     | None -> is_compatible env ty tany
                     | Some _ -> true)
                fds1
    | Typ_app (tf1, ta1), Typ_app(tf2, ta2) when is_array_type ty1 && is_array_type ty2 -> is_compatible env ta1 ta2
    | _, _ when is_any_type env ty1 || is_any_type env ty2 || is_un_type env ty1 || is_un_type env ty2 -> true
    | _, _ -> TypeRelations.alpha_equiv env.tcenv ty1 ty2

(* translates expression, insert types to the result expression's sort *)
let rec texp (env:tsenv) e : exp =
//let _ = Printf.printf "\n texp: %s " (Pretty.strExp e) in
let loc = e.p in
let e', t' = match e.v with
    | Exp_constr_app (constr, _, ps, [e1;e2]) when Sugar.lid_equals constr.v Const.tuple_UU_lid -> (* Tuple_UU(e1, e2) *)
      let e1' = texp env e1 in
      let e2' = texp env e2 in
      let ttuple = twithsort (Typ_dtuple [(None, e1'.sort); (None, e2'.sort)]) Kind_star in
      (* tag:{0:t1, 1:t2}, 0:e1, 1:e2*)
      createRecord [(liOfSl [tagName], typ2Tag e.p env ttuple); (liOfSl ["0"], e1'); (liOfSl ["1"], e2')], ttuple 
    | Exp_constr_app (constr, _, ps, es) -> (* translate to a record with a tag (typed any) *)
      let ctyp, _ = match lookup_fvar_with_params env.tcenv constr with
          None -> raise (Error ("data constructor not found: " ^ (Sugar.text_of_lid constr.v), loc))
        | Some t -> t in
      let args, result_typ, _ = List.fold_left  
        (fun (result, ctyp, n) arg -> match ctyp.v with
             Typ_fun (_, arg_typ, ret_typ) -> 
             let arg' = texp env arg in
             if is_sub env arg'.sort arg_typ then
               (liOfSl [n.ToString()], arg')::result, ret_typ, n+1
             else raise (Error (spr "Exp_constr_app: expect type %s but got %s: %s" (Pretty.strTyp arg_typ) (Pretty.strExp arg) (Pretty.strTyp arg'.sort), loc))
	     | _ -> raise (Error ("too many arguments for " ^ (Sugar.text_of_lid constr.v), loc)))
        ([], ctyp, 0) es in
      (* c:[[D]], tag:[[T]], 0:e_0, ..., n:e_n *)
      createRecord((liOfSl [tagName], typ2Tag e.p env result_typ) :: 
                    (liOfSl ["c"], dcon2Tag env constr) :: 
                    (List.rev args)), result_typ
    | Exp_abs (bvd, t, e) -> 
      let env' = {tcenv = push_local_binding env.tcenv (Binding_var (bvd.realname, t)); lids = env.lids} in
      let e' = texp env' e in
      let tfun = twithsort (Typ_fun (None, t, e'.sort)) Kind_unknown in
      createFunction env bvd t e' tfun, tfun
    | Exp_tabs (btd, k, fs, e) -> raise NYI (* no polymorphism *)
    | Exp_app ({v = Exp_tapp({v=Exp_fvar (fv, _); sort = _; p = _}, t); sort = _; p = _}, ea) -> (* check if cast<t> ea *)
      let fvname = Pretty.str_of_lident (fv.v) in
      let ea' = texp env ea in
      if fvname = "newArray" && TypeRelations.alpha_equiv env.tcenv ea'.sort tunit (* newArray t () *)
      then (mkExpApp (Q_field "newArray") e_Unit).v, twithsort (Typ_app(tarray, t)) Kind_star
      else let src_t, tgt_t = typ2Tag e.p env (ea'.sort), typ2Tag e.p env t in
      if (List.exists (function nm -> fvname = nm) ["setTag"; "canTag"; "isTag"; "canWrap"; "wrap"])
      then if (is_compatible env ea'.sort t)
           then if fvname = "setTag" && is_array_type t (* setTag (array T) v *)
                then (Q_apply (Q_field "setTagArray") [tgt_t; typ2Tag e.p env (get_array_element_type t); ea']).v, t
                else if fvname = "setTag" || fvname = "canTag" 
                    then if is_un_type env ea'.sort then raise (Err "cannot cast to un") else ((tagOp2 fvname tgt_t ea').v, if fvname="setTag" then t else tbool)
                    else (tagOp3 fvname src_t tgt_t ea').v, if fvname = "wrap" then t else tbool
          else raise (Error (spr "incompatible types in cast: %s vs %s" (Pretty.strTyp ea'.sort) (Pretty.strTyp t), loc))
        else raise (Error ("unknown polymorphic value: " ^ fvname, loc))
    | Exp_app ({v = Exp_app({v = Exp_fvar(fv, _); sort = _; p = _} as op, e1); sort = _; p = _}, e2) 
        when (Sugar.lid_equals fv.v Const.op_Eq || Sugar.lid_equals fv.v Const.op_ColonEquals_lid 
        || Sugar.lid_equals fv.v Const.op_read_lid || Sugar.lid_equals fv.v Const.readArray_lid) -> 
        (* = or :=  or read or readArray *)
      let e1' = texp env e1 in
      let e2' = texp env e2 in
      if (Sugar.lid_equals fv.v Const.op_Eq) then (* = *)
        if is_sub env e1'.sort e2'.sort || is_sub env e2'.sort e1'.sort then (mkExpApp (mkExpApp op e1') e2').v, tbool
        else raise (Error (spr "op_Eq: incompatible types %s vs %s" (Pretty.strTyp e1'.sort) (Pretty.strTyp e2'.sort), loc))         
      else if (Sugar.lid_equals fv.v Const.op_ColonEquals_lid) then (* := *)
        if is_sub env e2'.sort e1'.sort then (mkExpApp (mkExpApp op e1') e2').v, tunit
        else raise (Error (spr "op_ColonEquals: %s not a subtype of %s" (Pretty.strTyp e2'.sort) (Pretty.strTyp e1'.sort), loc))
      else if Sugar.lid_equals fv.v Const.op_read_lid then read e1' e2', tany (* read *)
      else if is_array_type e1'.sort && TypeRelations.alpha_equiv env.tcenv e2'.sort tnumber 
      then (readComputedProperty e1' (num2string e2')).v, get_array_element_type e1'.sort
      else raise (Error (spr "readArray (%s:%s) (%s:%s): unexpected type" (Pretty.strExp e1) (Pretty.strTyp e1'.sort) (Pretty.strExp e2) (Pretty.strTyp e2'.sort), loc)) 
    | Exp_app ({v = Exp_app({v = Exp_app({v= Exp_fvar(fv, _); sort = _; p = _}, er); sort = _; p = _}, ef); sort = _; p = _}, ev) 
        when (Sugar.lid_equals fv.v Const.op_write_lid || Sugar.lid_equals fv.v Const.writeArray_lid) -> (* write or writeArray *) 
      let er' = texp env er in
      let ef' = texp env ef in
      let ev' = texp env ev in
      if Sugar.lid_equals fv.v Const.op_write_lid then write er' ef' ev', tany (* write *)
      else if is_array_type er'.sort && TypeRelations.alpha_equiv env.tcenv ef'.sort tnumber &&
              is_sub env ev'.sort (get_array_element_type er'.sort) 
           then write er' (num2string ef') ev', tany
      else raise (Error (spr "writeArray (%s:%s) (%s:%s) (%s:%s): unexpected type" 
                            (Pretty.strExp er) (Pretty.strTyp er'.sort) (Pretty.strExp ef) (Pretty.strTyp ef'.sort) (Pretty.strExp ev) (Pretty.strTyp ev'.sort), loc)) 
    | Exp_app (ef, ea) ->
      let ef', ea' = texp env ef, texp env ea in
      if is_any_type env ef'.sort then
        if is_sub env ea'.sort tany then (apply ef' ea', tany) (* A-App *) 
        else raise (Error (spr "Exp_app: expect an any value but got %s : %s" (Pretty.strExp ea) (Pretty.strTyp ea'.sort), loc))
      else (match ef'.sort.v with
        | Typ_fun(_, arg_typ, res_typ) ->
          if is_sub env ea'.sort arg_typ then (Exp_app(ef', ea'), res_typ) (* T-App *) 
          else raise (Error (spr "Exp_app: expect %s but got %s:%s" (Pretty.strTyp arg_typ) (Pretty.strExp ea) (Pretty.strTyp ea'.sort), loc))
        | _ -> raise (Error (spr "Exp_app: expect a function but got %s: %s " (Pretty.strExp ef) (Pretty.strTyp ef'.sort), loc)))
      
    | Exp_tapp _ -> raise (Error ("no support for polymorphism", loc))
    | Exp_match(v, [(Pat_variant(c, tys, gs, [bv1; bv2], _), eb)], d) when Sugar.lid_equals c Const.tuple_UU_lid -> (* pair *)
      let v' = texp env v in
      (match v'.sort.v with
        | Typ_dtuple([(_, t1); (_, t2)]) ->
          let env = {env with tcenv = push_local_binding (env.tcenv) (Binding_var (bv1.v.realname, t1))} in
          let env = {env with tcenv = push_local_binding (env.tcenv) (Binding_var (bv2.v.realname, t2))} in
          let eb' = texp env eb in
          (* let bv1 = v'.0 in let bv2 = v'.1 in eb' *)
          Exp_let(false, [(bv1.v, t1, readComputedProperty v' (e_String "0"))],
                  ewithsort (Exp_let(false, [(bv2.v, t2, readComputedProperty v' (e_String "1"))], eb')) eb'.sort), eb'.sort
        | _ -> raise (Error (spr "Exp_match: expect a tuple type but got %s:%s" (Pretty.strExp v) (Pretty.strTyp v'.sort), loc)))
    | Exp_match (v, pes, d) ->
      let env_v = {tcenv=fst (clear_expected_typ env.tcenv); lids = env.lids} in
      let (v', d') = (texp env_v v, texp env d) in
      //let _ = pr "\n match %s : %s" (Pretty.strExp v) (Pretty.strTyp v'.sort) in
      let pes' = List.map (tbranch env loc) pes in
      let t' =
        let check (_, _, b) = TypeRelations.alpha_equiv env.tcenv b.sort d'.sort in
            match List.forall check pes' with
            | true  -> d'.sort
            | false -> tany
      in

      (* TODO: check that patterns match the type of the destructed expression *)

      let vx  = bvdOfString "v" in
      let evx = bvdToExp vx v'.sort in

      let tpat ((_, _, xs), (datacon, c, cty), b) =
         let realb =
            ewithinfo (Exp_cond (isData env evx cty datacon, b, d')) t' b.p
         in
            (Pat_variant (c, [], [], xs, false), realb)
      in

      let seq2    = ewithinfo (Exp_match (evx, List.map tpat pes', d')) t' e.p in

      let aout = Exp_let (false, [(vx, evx.sort, v')], seq2) in
        (aout, t')

    | Exp_cond (ec, et, ef) -> 
      let ec', et', ef' = texp env ec, texp env et, texp env ef in
      if TypeRelations.alpha_equiv env.tcenv ec'.sort tbool then
        Exp_cond(ec', et', ef'), 
        if TypeRelations.alpha_equiv env.tcenv et'.sort ef'.sort then et'.sort else tany
      else raise (Error ("Exp_cond:expect a bool, but got " ^ (Pretty.strExp ec), loc))
    | Exp_recd (lidopt, ts, es, fes) -> (* add tag to records *)
      let fes', rec_typ = (match expected_typ env.tcenv with
         | Some t -> 
           let fts = if is_any_type env t then [] else Tcenv.get_record_fields e.p env.tcenv t in
           let _ = List.map (function (fi, ti) ->  (* match all fields in the expected type *)
                                       (match List.tryFind (function (fi', _) -> Sugar.lid_equals fi fi') fes with
                                          | Some _ -> ()
                                          | None -> raise (Error (spr "field %s:%s not found" (Pretty.str_of_lident fi) (Pretty.strTyp ti), loc)))) fts in
          let fes' = List.map (function (fi, ei) -> 
                                       (match List.tryFind (function (fi', _) -> Sugar.lid_equals fi fi') fts with
                                         | Some (_, ti) -> 
                                           let env' : tsenv = {env with tcenv = set_expected_typ env.tcenv (snd(desugar_field_type env ti))} in
                                           (fi, texp env' ei)
                                         | None -> (* check that no fields omitted in the expected type have type un *)
                                           let env = {env with tcenv = fst(clear_expected_typ env.tcenv)} in
                                           let ei' = texp env ei in
                                           if is_un_type env ei'.sort then raise (Error (spr "field %s : un cannot be omitted" (Pretty.str_of_lident fi), loc))
                                           else (fi, ei'))) fes in
          fes', t
         | _ -> (* no ascription, use the precise record type *)
           let fes' = List.map (fun (f, e) -> (f,  texp env e)) fes in
           let fts = List.map (fun (f, e) ->
                          if is_sub env e.sort tany then (f, e.sort) 
                          else raise (Error (spr "field %s : %s not a subtype of any" (Pretty.str_of_lident f) (Pretty.strExp e), loc))) fes' in
           fes', twithsort (Typ_record(fts, None)) Kind_unknown) in
      createRecord((liOfSl [tagName], typ2Tag e.p env rec_typ) :: fes'), rec_typ
    | Exp_proj (er, f) when Sugar.lid_equals f Const.foreach_lid -> (* o.foreach : (string -> any -> any) -> any *)
      let er' = texp env er in
      if is_sub env er'.sort tany then Exp_proj(er', f), tarrow (tarrow tstring (tarrow tany tany)) tany
      else raise (Error (spr "Exp_proj:expect a subtype of any, but got %s:%s" (Pretty.strExp er) (Pretty.strTyp er'.sort), loc))
    | Exp_proj (er, f) ->
      let er' = texp env er in
      let tr = Tcenv.expand_typ env.tcenv er'.sort in
      if is_any_type env tr then read er' (e_String (Pretty.str_of_lident f)), tany (* A-Read *)
      else if is_array_type tr && (Pretty.str_of_lident f = "length") then Exp_proj(er', f), tnumber  (* a.length *)
      else let rec last = function [tl] -> tl | _ :: tl -> last tl in  
          (match List.tryFind (fun (fi:lident, _) -> Sugar.text_of_id (last fi.lid) = Sugar.text_of_id (last f.lid)) (Tcenv.get_record_fields e.p env.tcenv tr) with
            | Some (_, ti) -> Exp_proj(er', f), snd (desugar_field_type env ti)
            | None -> raise (Error (spr "field %s not found" (Pretty.str_of_lident f), loc)))
    | Exp_ascribed (e, t, ev) -> 
      let e' = texp env e in
      if is_sub env e'.sort t then Exp_ascribed(e', t, ev), t
      else raise (Error (spr "Exp_ascribed: %s: %s, not compatible with %s" (Pretty.strExp e) (Pretty.strTyp e'.sort) (Pretty.strTyp t), loc)) 
    | Exp_let (isrec, bvd_ty_es, em) when isrec = false -> 
      (match bvd_ty_es with
        | [(bvd, t, e)] ->
          let hasRecTyp = match t.v with
                         | Typ_unknown -> false 
                         | Typ_record _ -> true 
                         | Typ_const(c, _) -> is_record env.tcenv c.v
                         | _ -> false in
          let env' = if hasRecTyp then {env with tcenv = set_expected_typ env.tcenv t} else env in
          let e' = texp env' e in

          let t' = if not hasRecTyp then e'.sort 
             else if is_sub env e'.sort t then t 
             else raise (Error (spr "Exp_let: expect %s but got %s : %s" (Pretty.strTyp t) (Pretty.strExp e) (Pretty.strTyp e'.sort), loc)) in
          let binding = Binding_var (bvd.realname, t') in
          let env' = {tcenv = push_local_binding (env.tcenv) binding; lids = env.lids} in
          let em' = texp env' em in
          Exp_let(false, [(bvd, t', e')], em'), em'.sort
        | _ -> raise (Error ("more than one bindings in non-recursive Exp_let: " ^ (Pretty.strExp e), loc))
      )
    | Exp_let (isrec, bvd_ty_es, em) when isrec ->
      let env' = List.fold_left (fun env (bvd, t, e) -> let binding = Binding_var (bvd.realname, t) in
                                                        {tcenv = push_local_binding (env.tcenv) binding; lids = env.lids}) env bvd_ty_es in
      let bvd_ty_es' = List.map (fun (bvd, t, e) -> let e' = texp env' e in
                                                    if is_sub env' (e'.sort) t then (bvd, t, e')
                                                    else raise (Error ("Exp_let: incompatible type for " ^ (Pretty.strBvd bvd), loc))) bvd_ty_es in
      let em' = texp env' em in
      Exp_let(isrec, bvd_ty_es', em'), em'.sort
    | Exp_extern_call (ext, id, t, ts, es) -> raise NYI
    | Exp_primop (op, es) ->
      let es' = List.map (texp env) es in
      if (List.exists (fun e -> is_any_type env e.sort) es') then Exp_primop(op, es'), tany
      else (match lookup_operator env.tcenv op with
      	| None -> raise (Error ("unknown operator " ^ op.idText, loc))
	    | Some t ->
        //let _ = Printf.printf "\n operator: %s : %s" op.idText (Pretty.strTyp t) in
         let res_typ = List.fold_left
           (fun t arg -> match t.v with
	        Typ_fun(_, t_arg, t_ret) -> 
	            match TypeRelations.convertible_ev env.tcenv arg.sort t_arg with
		          | None -> raise (Error (spr "Exp_primop %s: expect %s, but got %s: %s" (Pretty.strExp e) (Pretty.strTyp t_arg) (Pretty.strExp arg) (Pretty.strTyp arg.sort), loc))
		          | Some _ -> t_ret) t es' in
           Exp_primop(op, es'), res_typ)
    | Exp_bvar bv ->
      let t = lookup_bvar env.tcenv bv in
      let bv = setsort bv t in
      //let _ = Printf.printf "\n bvar: %s : %s" (Pretty.strBvar bv) (Pretty.strTyp t) in
      Exp_bvar bv, t
    | Exp_fvar (fv, eref) -> 
      if Tcenv.is_datacon env.tcenv fv then
       let e' = texp env (AbsynUtils.W (Exp_constr_app(fv, [], [], []))) in e'.v, e'.sort
      else let t = match lookup_fvar env.tcenv fv with
        | None -> raise (Error ("variable not found: " ^ (Sugar.text_of_lid fv.v), loc))
        | Some t -> t in
        let fv = setsort fv t in
        Exp_fvar(fv, eref), t
    | Exp_constant c ->
      (match c with
        | Sugar.Const_unit -> e.v, tunit
	    | Sugar.Const_bool _ -> e.v, tbool
	    | Sugar.Const_int32 _ 
	    | Sugar.Const_float _ -> e.v, tnumber
	    | Sugar.Const_string _ -> e.v, tstring
	    | _ -> raise (Error ("cannot type " ^ (Pretty.strExp e), loc)))
    | Exp_gvar _ -> raise NYI 
    | Exp_bot -> e.v, e.sort
in ewithinfo e' t' e.p

and tbranch env loc (Pat_variant (c, tys, gs, es, _), br) =
    if not (List.isEmpty tys) || not (List.isEmpty gs) then
        raise (Error ("unsupported: constructor with (type|ghost) variables", loc));
    let ctyp =
        match lookup_fvar_with_params env.tcenv (Wfv c) with
        | None -> raise (Error ("data constructor not found", loc))
        | Some (cty, gp) ->
            if not (List.isEmpty gp) then
                raise (Error ("unsupported: constructor type with ghost parameters", loc));
            if Sugar.lid_equals c Const.tuple_UU_lid then
              (match cty.v with
                 | Typ_univ(_, _, _, {v=Typ_univ(_,_,_,t); sort=_; p = _}) -> t
                 | _ -> cty)
            else cty in
    let datacon = fvwithinfo c ctyp (Sugar.range_of_lid c) in
    let _ = pr "\n cty = %s" (Pretty.strTyp ctyp) in
    let _ = List.map (function e -> pr "\n e: %s" (Pretty.strBvar e)) es in
    
    let rec applyv (bds, bvs) es ctyp =
        match es, ctyp.v with
        | bv :: es, Typ_fun (x, ty1, ty2) ->
            let bv' = setsort bv ty1 in
            let exp = ewithinfo (Exp_bvar bv') ty1 bv'.p in
            let ty2 = open_typ_with_exp ctyp exp in
            let bd  = Binding_var (bvar_real_name bv', ty1) in
                applyv (bd::bds, bv'::bvs) es ty2
        | [], Typ_univ _ -> raise (Error ("unsupported: pattern constructor with type parameters", loc))
        | [], Typ_fun _ -> raise (Error ("pattern constructor not fully applied", loc))
        | _ :: _, _ -> raise (Error ("pattern constructor has too many arguments", loc))
        | [], _ -> ((bds, bvs), ctyp)
    in

    let ((bds, bvs), cty) = applyv ([], []) es ctyp in
    let env = {tcenv=List.fold_right (fun bd env -> push_local_binding env bd) bds env.tcenv; lids = env.lids} in

        ((bds, bvs, es), (datacon, c, cty), texp env br)

and typ2Tag loc env (t:typ) : exp =
    let t = expand_typ env.tcenv t in

    match t.v with
    | _ when is_any_type env t -> Q_Any
    | _ when is_un_type env t -> Q_Un
    | _ when is_base_type env t -> get_base_type env t
    | Typ_fun (_, ty1, ty2) -> Q_P_arrow (typ2Tag loc env ty1) (typ2Tag loc env ty2)
    | Typ_record (fds, _) ->
        let do1 (x, ty) =
            let (m, ty) = desugar_field_type env ty in
                (x, m, typ2Tag loc env ty)
        in
            Q_P_fields (List.map do1 fds)
    | Typ_const(c, _) -> Q_P_rec (Pretty.str_of_lident c.v)
    | Typ_dtuple ([(_, t1); (_, t2)]) -> Q_P_pair (typ2Tag loc env t1) (typ2Tag loc env t2)
    | Typ_app _ when is_array_type t -> Q_P_fields []
    | _ -> raise (Error (spr "typ2Tag: not a valid TS* type: %s" (Pretty.strTyp t), loc))

and dcon2Tag env (d:var<typ>) : exp =
    e_String (d.v.str)

(* let x = new Q() in (x.fi = si, x), rtti is included already in fes *)
and createRecord fes : exp' = 
  let x = bvdOfString "x" in
  let xexp = bvdToExp x tany in
  Exp_let(false, [(x, tany, mkExpApp (Q_field "newRecord") e_Unit)], 
          mkeseq ((List.map (function (f, e) -> (* Q.setFieldRecord x f e *)
                            mkExpApp (mkExpApp (mkExpApp (Q_field "setFieldRecord") xexp) (e_String (Pretty.str_of_lident f))) e)  fes) @
                  [xexp]))

(* create a function of type ft: function (x:xty) => e
   let f = \bvd:t . e in
   let dummy = Q.defineProperty f "rtti" {value:tag; enumerable:false} in
   f *)
and createFunction env bvd t e tfun : exp' = 
  let tag = typ2Tag e.p env tfun in
  let f, dummy = bvdOfString "f", bvdOfString "dummy" in
  let fexp = bvdToExp f tfun in
  let des = ewithinfo (Exp_recd(None, [], [], [(liOfSl ["value"], tag); (liOfSl ["enumable"], e_False)])) tany e.p in
  Exp_let(false, [(f, tfun, ewithinfo (Exp_abs(bvd, t, e)) tfun e.p)],
          ewithinfo (Exp_let(false, [(dummy, tany, Q_apply (Q_field "defineProperty") [fexp; e_String "rtti"; des])], fexp)) tany e.p)

(* read field f from record r *)
and read er (f:exp) : exp' = 
  let x = bvdOfString "x"in
  let xty = er.sort in
  let xexp = bvdToExp x xty in
  Exp_let (false, [(x, xty, er)],
           testCond (hasFld xexp f) (readComputedProperty xexp f))

and readComputedProperty er (f:exp) : exp = mkExpApp (mkExpApp (Q_field "readComputedProperty") er) f

(* write field f of record r to v 
   let x = er in let v = ev in let t = typeof(x) === "object" ? x.rtti : Q.die() in
     Q.mutable(t,f)? Q.setFieldRecord x f (Q.setTag(Q.hasField(t,f) ? t[f]: Q.Any, v)) : Q.die()
*)
and write er (f:exp) ev : exp' = 
  let x, v, t = bvdOfString "x", bvdOfString "v", bvdOfString "t" in
  let xty, vty = er.sort, ev.sort in
  let xexp, vexp, texp = bvdToExp x xty, bvdToExp v vty, bvdToExp t tany in
  let aout = 
      let tf = readComputedProperty texp f in
      let hasField = mkExpApp (mkExpApp (Q_field "hasField") texp) f in
      testCond (Qmutable texp f)
               (updateField xexp f (tagOp2 "setTag" (AbsynUtils.mkExpTyp (Exp_cond(hasField, tf, Q_Any)) tany) vexp)) in
  let aout = Exp_let(false, [(t, tany, testCond (testTypeof xexp "object") 
                                                (AbsynUtils.mkExpTyp (Exp_proj(xexp, liOfSl ["rtti"])) tany))], aout) in
  let aout = Exp_let(false, [(v, vty, ev)], AbsynUtils.mkExpTyp aout tany) in
  let aout = Exp_let(false, [(x, xty, er)], AbsynUtils.mkExpTyp aout tany) in
    aout

and updateField er (f:exp) ev : exp = 
  mkExpApp (mkExpApp (mkExpApp (Q_field "setFieldRecord") er) f) ev

(* return expression typeOf(texp env e) *)
and typeOf (e : exp) : exp =
    let e' = Exp_app (AbsynUtils.mkFvarTyp pr_typeOf.v pr_typeOf.sort, e) in
        ewithinfo e' tstring e.p

(* return e.rtti.arg *)
and paramTag e: exp = AbsynUtils.mkProj (AbsynUtils.mkProj e (liOfSl ["rtti"])) (liOfSl ["arg"])

(* typeOf e === "object" *)
and testTypeof e tst = AbsynUtils.mk_eqtest (typeOf e) (e_String tst)

(* return (typeOf e === "object" && Q.hasField e f *)
and hasFld e (f:exp) : exp =
    let e1 = testTypeof e "object" in
    let e2 = mkExpApp (mkExpApp (Q_field "hasField") e) f in
    mkExpApp (mkExpApp (AbsynUtils.mkFvar Const.op_And_lid) e1) e2

(* if (c) then e else Q.die() *)
and testCond c e : exp = 
  let dieExp = mkExpApp (Q_field "die") e_Unit in
  ewithinfo (Exp_cond(c, e, dieExp)) e.sort dummyRange

(* return v.tag *)
and tag v : exp = AbsynUtils.mkProj v (liOfSl [tagName])

(* return Q.tagOf(v) *)
and tagOf v : exp = mkExpApp (Q_field "tagOf") v

and num2string e : exp = mkExpApp (Q_field "num2string") e

(* return Q.mutable(t, f) *)
and Qmutable (t:exp) (f:exp): exp = mkExpApp (mkExpApp (Q_field "mutable") t) f

(* return Q.funTag(f) *)
and functionTag f : exp = mkExpApp (Q_field "funTag") f

(* return Q.setTag/canTag(t, v) *)
and tagOp2 opName t v : exp = mkExpApp (mkExpApp (Q_field opName) t) v

(* return Q.isTag/canWrap/wrap(src_t, tgt_t, v) *)
and tagOp3 opName src_t tgt_t v : exp = mkExpApp (mkExpApp (mkExpApp (Q_field opName) src_t) tgt_t) v

(* Q.isData(e, t, d) *)
and isData env (e:exp) (t:typ) (d:var<typ>) : exp = 
  mkExpApp (mkExpApp (mkExpApp (Q_field "isData") e) (typ2Tag e.p env t)) (dcon2Tag env d)

(* apply ef to argument ea
   let f = ef in let x = ea in typeof(f) === "function"? f(Q.setTag(f.rtti.arg, x)) : Q.die()
 *)
and apply ef ea : exp' = 
  let f, x = bvdOfString "f", bvdOfString "x" in
  let fty, xty = ef.sort, ea.sort in
  let fexp, xexp = bvdToExp f fty, bvdToExp x xty in
  let aout = AbsynUtils.mkExpTyp (Exp_app (fexp, tagOp2 "setTag" (paramTag fexp) xexp)) tany in
  let aout = testCond (testTypeof fexp "function") aout in
  let aout = AbsynUtils.mkExpTyp (Exp_let (false, [(x, xty, ea)], aout)) tany in
  let aout = Exp_let (false, [(f, fty, ef)], aout) in
     aout

let tlet (env : tsenv) (isrec : bool) (lb : letbinding) : tsenv * (letbinding * bool) =
    let _ = Printf.printf "\n: tlet: %s" (Pretty.strLet [(lb, false)]) in
    let bind_lb env lb = 
        List.fold_left
           (fun env (x, ty, _) ->
                push_local_binding env (Binding_var (x.realname, ty)))
           env lb
    in
    if not (List.forall
                (fun (bvd, ty, e) -> 
                    match ty.v with
                      | Typ_unknown -> true
                      | _ -> 
                    let isTsType = is_ts_type env ty in
                    if not isTsType then
                        Printf.printf "\n not a ts type %s (%s): %s"
                            (bvd.ppname.idText) (Range.string_of_range e.p) (Pretty.strTyp ty);
                    isTsType) lb) then
        raise (Error ("let-binding is not typed at the TS* level", dummyRange));
    let xenv = if isrec then env else {tcenv = bind_lb env.tcenv lb; lids = env.lids} in
    let lb = List.map
        (fun (x, ty, e) ->
            let e' = texp env e in
	       let _ = pr "\n: let: %s : %s with ty = %s" (Pretty.strExp e) (Pretty.strTyp e'.sort) (Pretty.strTyp ty) in
               match ty.v with
                 | Typ_unknown -> (x, e'.sort, e')
                 | _ -> 
                   if not (is_sub env e'.sort ty) then
                       raise (Error (spr "let-binding body is not a subtype of given annotation: %s / %s"
                                     (Pretty.strTyp e'.sort) (Pretty.strTyp ty), e.p));
                  (x, ty, e')) lb
    in
        ({tcenv = bind_lb env.tcenv lb; lids = env.lids}, (lb, isrec))

(* process type declarations and add them to the signature *)
let tdata (env:tsenv) sigelt : tsenv = 
  let sigelt', lids = match sigelt with
  | Sig_tycon_kind _ 
  | Sig_extern_value _ 
  | Sig_extern_typ _ 
  | Sig_query _ 
  | Sig_ghost_assume _
  | Sig_logic_function _ -> raise (Error ("unsupported type", dummyRange))

  | Sig_typ_abbrev (x, _, _, _) ->
        printfn "A: %s" x.str; raise NYI

  | Sig_record_typ (x, ps, k, ty, _) ->
        if not (List.isEmpty ps) then
            raise (Error ("unsupported: record type with type parameters", dummyRange));
        begin match k with
        | Kind_star -> ()
        | _ -> raise (Error ("record type not at *-kind", dummyRange));
        end;

        let fields =
            match ty.v with
            | Typ_record (fields, _) -> fields
            | _ -> raise Impos
        in

        let fields = List.map (fun (x, ty) -> (x, desugar_field_type env ty)) fields in

        if not (List.forall (fun (f, (_, ty)) -> 
                            let isTsType = is_ts_type ({tcenv = env.tcenv; lids = x :: env.lids}) ty  in
                            let _ = if not isTsType then Printf.printf "\n not a ts type %s: %s" (Pretty.str_of_lident f) (Pretty.strTyp ty) in
                            isTsType) fields) then
            raise (Error ("in record definition, field types must be TS types", dummyRange));
        sigelt, [x]

  | Sig_datacon_typ (x, _, _, _, _, _, _, _) ->
        printfn "D: %s" x.str; raise NYI

  | Sig_value_decl (x, ty) ->
        //let _ = List.map (function lid -> Printf.printf "\n lid: %s" (Pretty.str_of_lident lid)) env.lids in
        if not (is_ts_type env ty) then
            (
            raise (Error (spr "value %s does not have a TS type: %s"
                                (Pretty.str_of_lident x) (Pretty.strTyp ty), dummyRange)));
        sigelt, []
  in
    {tcenv = push_sigelt env.tcenv sigelt'; lids = env.lids@lids}

let tmod (env:tsenv) (m:Absyn.modul) : (Absyn.modul * tsenv) = 
  //let _ = Printf.printf "translate module: %s" (Pretty.strModule m) in
  //let _ = Printf.printf "\n env.signature %s " (String.concat "\n" (List.map Pretty.strSigelt env.tcenv.e_signature)) in
  let env = {env with tcenv = {env.tcenv with curmodule=m.name}} in
  let env = List.fold_left tdata env m.signature in 
  let env,lbs = List.fold_left (fun (env,lbs) (lb, isRec) -> 
    let env, lb = tlet env isRec lb in 
    env, lbs@[lb]) (env, []) m.letbindings in
  let m = {m with letbindings=lbs} in
  let modules' = (m.name, m):: env.tcenv.modules in
  let tcenv':Tcenv.env = {env.tcenv with modules = modules'} in
  m,{env with tcenv = tcenv'}

let checkAndTranslate (env:tsenv) (ms:Absyn.modul list) : (Absyn.modul list * tsenv) =
 try
     (* 1. Source-to-source translation of modules *)
      let env, ms = List.fold_left (fun (env, ms) m -> 
        let m, env = tmod env m in 
        env, ms@[m]) (env, []) ms in
     (* 2. JS code generation *)
      
      //let js = Absyn2JSMin.translate_modules ms in 
      ms, env
 with
 | Error (msg, loc) ->
   Printf.eprintf "\n\nTS* error: %s: %s\n" (Range.string_of_range loc) msg;
   exit 1 
 | e ->
    Printf.eprintf "\n\nTS* error: %A (%s)\n" e e.StackTrace;
    exit 1 
