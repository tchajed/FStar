#!/usr/bin/perl -w

$basedir=".";
$tmpdir="$basedir/units";
$sourcetxt="$basedir/unittests-release.txt";
$fine = "../bin/fine.exe --silent --noss --prims prims_unit.f9 --prooflibvals ../lib/prooflibvals.f9 --odir $tmpdir";
$configurations = [ $fine,
                    "$fine --to_dcil --typecheck_proofs",
                    "$fine --genIL" ];
# Add your configrs here. For example:
# $configurations = [ $fine,
#                     "$fine --to_dcil",
#                     "$fine --to_dcil --typecheck_proofs",
#                     "$fine --genIL"];
                    
sub execute_test {
    my $config = shift;
    my $testname = shift;
    my $configid = shift;
    my $expected = shift;
    my $modulename = shift;
    my $testdescr = shift;
    my $outfile = "$testname.out.$configid";
    my $cmd = "$config $testname >> $outfile 2>&1";

#    print "\nEXECUTING TEST: $cmd";
    system "echo $cmd >> $outfile";
    system $cmd;

    if ($expected =~ /success/) {
        open(OUTFILE, $outfile);
        while ($line = <OUTFILE>) {
            chomp $line;
            if ($line eq "Checked module: $modulename") {
                print "SUCCESS $modulename(Config $configid): $testdescr\n";
                close(OUTFILE);
                return;
            }
            if ($line =~ /error/i) {
                print "FAILURE $modulename(Config $configid): $testdescr\n \tError $line\n";
                print "\tFor details, see $outfile\n";
                close(OUTFILE);
                return;
            }
        }
        print "FAILURE $modulename(Config $configid): $testdescr\n \tUnknown reason\n";
        print "\tFor details, see $outfile\n";
        close(OUTFILE);
    }
    else {
        print "??????? $modulename(Config $configid): $testdescr\n \tUnexpected result ($expected)\n";
        print "\tFor details, see $outfile\n";
    }

}

sub run_one_test {
    my $test = shift;
    my $testid = shift;
    my @testlines = @$test;
    my $testname = $tmpdir . "/Test$testid.fine";
    my $testdescr;
    my $expected = 0;
    open(TESTFILE, ">".$testname);
    my $modulename = "Test$testid";
    print TESTFILE "module $modulename\n";
    foreach $line (@testlines) {
        if ($line =~ /Test name: ([^#]*)/) {
            $testdescr = $1;
        }
        elsif ($line =~ /Expected result: ([^#]*)/) {
            $expected = $1;
            chomp $expected;
        }
        else {
            print TESTFILE $line;
        }
    }
    close(TESTFILE);
    my $configid = 1;
    foreach $cmd (@$configurations) {
        execute_test($cmd, $testname, $configid++, 
                     $expected, $modulename, $testdescr);
    }
}

system "rm -rf $tmpdir";
system "mkdir -p $tmpdir";
system "mkdir -p queries";
if ($ARGV[0]) {
    print "READING FROM $ARGV[0]\n";
    $sourcetxt = $ARGV[0];
}
open(UNITS, $sourcetxt);
$test = [];
$testid = 1;
while (my $line = <UNITS>) {
    if ($line =~ /^------*/) {
        run_one_test($test, $testid);
        $test = [];
        $testid++;
    }
    else {
        push(@$test, $line);
    }
}
