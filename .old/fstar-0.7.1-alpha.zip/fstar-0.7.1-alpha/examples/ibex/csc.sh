#!/bin/bash
# Content Script Compiler

# Uses aspect-oriented programming to link a content script with the runtime
# system and call the start function.

# Tip: do not call anything else start

SRC=$1
DEST=$2
START=`cat $SRC | sed 's/.*\(start[0-9][0-9]*\).*/\1/g'`

cat es-mode/extern.js > $DEST

cat $SRC | sed "s/\\(.*; \\)\\(return undefined\\) ; }/\1$START(document) ; }/g" >> $DEST
