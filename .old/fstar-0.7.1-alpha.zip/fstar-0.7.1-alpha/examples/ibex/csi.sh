#!/bin/bash

# Content Script Installer

F9=$1

JS=`echo $F9 | cut -d "." -f1`
JS="bin/$JS.js"

DEST=`head -n1 $F9 | cut -d " " -f2`
DEST="../Examples/$DEST"

echo "cp $JS $DEST"
cp $JS $DEST