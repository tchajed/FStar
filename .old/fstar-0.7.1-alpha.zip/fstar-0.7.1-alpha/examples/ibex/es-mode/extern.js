// parseUri 1.2.2
// (c) Steven Levithan <stevenlevithan.com>
// MIT License

function parseUri (str) {
	var	o   = parseUri.options,
		m   = o.parser[o.strictMode ? "strict" : "loose"].exec(str),
		uri = {},
		i   = 14;

	while (i--) uri[o.key[i]] = m[i] || "";

	uri[o.q.name] = {};
	uri[o.key[12]].replace(o.q.parser, function ($0, $1, $2) {
		if ($1) uri[o.q.name][$1] = $2;
	});

	return uri;
};

parseUri.options = {
	strictMode: false,
	key: ["source","protocol","authority","userInfo","user","password","host","port","relative","path","directory","file","query","anchor"],
	q:   {
		name:   "queryKey",
		parser: /(?:^|&)([^&=]*)=?([^&]*)/g
	},
	parser: {
		strict: /^(?:([^:\/?#]+):)?(?:\/\/((?:(([^:@]*)(?::([^:@]*))?)?@)?([^:\/?#]*)(?::(\d*))?))?((((?:[^?#\/]*\/)*)([^?#]*))(?:\?([^#]*))?(?:#(.*))?)/,
		loose:  /^(?:(?![^:@]+:[^:@\/]*@)([^:\/?#.]+):)?(?:\/\/)?((?:(([^:@]*)(?::([^:@]*))?)?@)?([^:\/?#]*)(?::(\d*))?)(((\/(?:[^?#](?![^?#\/]*\.[^?#\/.]+(?:[?#]|$)))*\/?)?([^?#\/]*))(?:\?([^#]*))?(?:#(.*))?)/
	}
};

function objEquality(v, w) {
  if (v === w) {
    return true;
  }
  else if (typeof v === "object" && typeof w === "object") {
    for (var key in v) {
      if (v.hasOwnProperty(key)) {
        if (w.hasOwnProperty(key) === false ||
            objEquality(v[key], w[key] === false)) {
          return false;
        }
      }
    }
    
    // Ensure that w does not have additional fields.
    for (var key in w) {
      if (w.hasOwnProperty(key)) {
        if (v.hasOwnProperty(key) === false) {
          return false;
        }
      }
    }
    
    return true;
  }
  else {
    return false;
  }
};
          

// op_Equality is injected into Prims by magic. We inject op_Equality into all
// modules.
Object.prototype.op_Equality = function(v) {
 return function(w) {
      return objEquality(v, w);
    };
};

var extern = {

  _toList: function(arr) {
    var lst = [ "Prims.Nil" ];
    for (var i = arr.length - 1; i >= 0; i--) {
      lst = [ "Prims.Cons", arr[i], lst ];
    }
    return lst;
  },

  someSetAttr: function(elt) { 
    return function(attrName) {
      return function(attrVal)  {
        elt.setAttribute(attrName, attrVal);
        return false;
      }
    }
  },
 
  getAttr: function(elt) {
    return function(attrName) {
      return elt.getAttribute(attrName);
    }
  },

  makeWorld: function(initState) {
    return { state : initState, handlers: [] };
  },

  reactPar: function(w) {
    return function(needCb) {
      return function(pureCb) {
        var handler = function(evt) {
          var r = pureCb(w)(evt);
          if (r[0] === "Prims.None") {
            for (var i = 0; i < w.handlers.length; i++) {
              w.handlers[i].detach();
            }
            w.handlers = [];
          }
          else {
            w.state = r[1];
          }
        };
        var cb = needCb(handler);
        w.handlers.push(cb);
        return cb;
      };
    };
  },

  someLog: function(s) {
    console.log(s);
    return false;
  },

  getChild: function(elt) { 
    return function(ix) {
      return elt.children[ix];
    };
  },

  op_Addition: function(x) {
    return function(y) {
      return x + y; 
    }
  },

  numChildren: function(elt)  {
    return elt.children.length;
  },


  getValue: function(elt) {
    return elt.value;
  },

  setValue: function(elt) {
    return function(str) {
      elt.value = str;
    };
  },

  urlOfString: function(str) {
    var uri = parseUri(str);
    uri.str = str;
    return uri;
  },

  urlPath: function(url) {
    return url.path;
  },

  op_Equality: function(v) {
    return function(w) {
      return v === w; // TODO: lol deep
    }
  },

  getEltsByClassName: function(doc) {
    return function(className) {
      return extern._toList(doc.getElementsByClassName(className));
    };
  },

  tagName: function(elt) {
    return elt.tagName;
  },

  getEltsByTagName: function(doc) {
    return function(tagName) {
      return extern._toList(doc.getElementsByTagName(tagName));
    }
  },

  getEltById: function(id) {
    return window.document.getElementById(id);
  },

  isTextNode: function(elt) {
    return elt.nodeType === 3;
  },

  parentNode: function(elt) {
    return elt.parentNode;
  },

  mkUrl: function(scheme) {
    return function(host) {
      return function(path) {
        return extern.urlOfString(scheme + "//" + host + path);
      };
    };
  },

  urlAppendQuery: function(url) {
    return function (key) {
      return function (value) {
        if (url.query) {
          return extern.urlOfString(url.str + "&" + escape(url.key) + "=" +
                                    escape(url.value));
        }
        else {
          return extern.urlOfString(url.str + "?" + escape(url.key) + "=" +
                                    escape(url.value));
        }
      };
    };
  },

  stringAppend: function(s1) {
    return function(s2) {
      return s1 + s2;
    };
  },

  getWorld: function(w) {
    return w.state;
  },

  elt: function(evt) {
    return evt.target;
  },

  getFontSize: function(sty) {
    return sty.style.fontSize;
  },

  setFontSize: function(sty) {
    return function(txt) {
      sty.style.fontSize = txt;
      return sty;
    };
  },

  getStyle: function(elt) {
    return elt;
  },

  attachEvent: function(elt) {
    return function(evtName) {
      return function(callback) {
        var handler = elt.addEventListener(evtName.substring(2), callback);
        return { detach: function() { elt.removeEventListener(handler); } };
      };
    };
  },

  body: function(doc) {
    return doc.body;
  },

  registerContentScript: function(str) {
    console.log("registerContentScript(str)");
  },

  jsonValue: function(evt) {
    return evt.jsonRecvd;
  },

  query: function(key) {
    return function(json) {
      if (json instanceof Array) {
        var arr = [];
        for (var i = 0; i < json.length; i++) {
          arr.push(extern.query(key)(arr[i]));
        }
        return arr;
      }
      else if (typeof json === "object" && json.hasOwnProperty(key)) {
        return json[key];
      }
      else {
        return null;
      }
    };
  },

  _cons: function(hd, tl) {
    return [ "Prims.Cons", hd, tl ];
  },

  _nil: [ "Prims.Nil" ],

  _append: function(lst1, lst2) {
    if (lst1[0] === "Prims.Nil") {
      return lst2;
    }
    else {
      return cons(lst1[1], extern._append(lst1[2], lst2));
    }
  },

  strings: function(json) {
    if (typeof json === "string") {
      return extern._cons(json, extern._nil);
    }
    else if (json instanceof Array) {
      var result = extern._nil;
      for (var i = json.length - 1; i >= 0; i--) {
        result = extern._append(extern.strings(json[i]), result);
      };
      return result;
    }
    else if (json === null) {
      return extern._nil;
    }
    else {
      throw "expected array of strings";
    }
  },

  getSelectedText: function(doc) {
    return doc.getSelection().toString();
  },

  jsonFromFine: function(v) { 
    if (v[0] === "DOM.Obj") {
      var obj = { };
      var lst = v[1];
      while (lst[0] !== "Prims.Nil") {
        obj[lst[1][1]] = extern.jsonFromFine(lst[1][2]);
        lst = lst[2];
      }
      return obj;
    }
    else if (v[0] === "DOM.Str") {
      return v[1];
    }
    else if (v[0] === "DOM.Arr") {
      var arr = [ ];
      var lst = v[1];
      while (lst[0] !== "Prims.Nil") {
        arr.push(extern.jsonFromFine(lst[1]));
        lst = lst[2];
      }
      return arr;
    }
    else {
      throw "jsonFromFine : unhandled case";
    }
  },

  jsonResponse: function(evt) {
    return function(json) {
      evt.jsonResp = json;
    };
  },

  recvMessages: function(callback) {
    chrome.extension.onRequest.addListener(function(json, sender, resp) {
      var evt = { jsonRecvd: json, jsonResp: undefined };
      callback(evt);
      if (evt.jsonResp !== undefined) {
        resp(evt.jsonResp);
      }
    });

    return { detach: function() { console.log("don't know how to detach"); }};
  },

  connListen: function(callback) {
    var cb = function(port) {
      callback({ evtType: "onConnect", port: port });
    };
    chrome.extension.onConnect.addListener(cb);
    return { 
      detach: function() { 
        chrome.extension.onConnect.removeListener(cb);
      }
    };
  },

  connPort: function(evt) {
    if (evt.evtType === "onConnect") {
      return evt.port;
    }
    else {
      throw "connPort requires an event from connListen";
    }
  },

  portRecv: function(port) {
    return function(callback) {
      var cb = function(msg) {
        callback({ jsonRecvd: msg, evtType: "Port.onMessage" });
      };
      port.onMessage.addListener(cb);

      return {
        detach: function() { port.onMessage.removeListener(cb); }
      };
    };
  },
  
  portPost: function(port) {
    return function(json) {
      port.postMessage(json);
      return false;
    };
  },

  postAll: function(json) {
    chrome.extension.connect().postMessage(json);
    return;
  },

  matchRegexp: function(str) {
    return function(regexpStr) {
      return str.match(regexpStr) !== null;
    };
  },

  replaceRegexp : function(str) {
    return function(regexpStr) {
      return function(substStr) {
        return str.replace(regexpStr, substStr);
      };
    };
  },

  activeElt: function(doc) {
    return doc.activeElement;
  },

  jsonRequest: function(json) {
    chrome.extension.sendRequest(json, function(response) { return; });
  },

}




