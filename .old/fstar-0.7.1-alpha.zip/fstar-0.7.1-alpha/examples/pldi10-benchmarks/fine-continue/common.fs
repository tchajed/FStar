
let pr  = Printf.printf
let fpr = Printf.fprintf
let spr = Printf.sprintf
let soi = string_of_int
let ios = int_of_string

let string_of_int (i:int):string = string_of_int i

let dummy = true

(* there must be a builtin F# func to lookup in assoc lists... *)
let rec lookup x l = match l with
  | [] -> failwith "lookup"
  | (k,v)::tl -> if k = x then v else lookup x tl

let findIdx x l =
  let rec f k = function
    | [] -> failwith "findIdx"
    | h::tl -> if h = x then k else f (k+1) tl
  in
  f 0 l

let trim s = String.trim [' '] s

let print_string (s:string) = let _ = Printf.printf "%s\n" s in 0
let strcat s1 s2 = s1 ^ s2
let strcat3 s1 s2 s3 = strcat s1 (strcat s2 s3)
