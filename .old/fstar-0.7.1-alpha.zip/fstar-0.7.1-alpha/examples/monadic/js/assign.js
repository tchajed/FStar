function f() {
    var x = 5;
}