function f() {
    var x = 5;

    x = 7;

    //var y = document.domaind;
    var z = document.getElementsByTagName("");
}

f()