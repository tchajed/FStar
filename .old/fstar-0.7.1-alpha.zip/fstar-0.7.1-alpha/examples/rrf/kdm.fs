﻿module KDM

// From Rogaway et al. 

// open Lib
type bytes = byte array
#if concrete
let randomBytes n = Lib.randomBytes n
let zeroCreate n = Lib.zeroCreate n
let xor x y : bytes = Array.map2 (^^^) x y 
#else
type 't eq = 't
let randomBytes (n:int) = failwith "spec" : bytes 
let zeroCreate (n:int) = failwith "spec" : bytes 
let (||) (b0:bytes) (b1:bytes) = failwith "spec" : bytes
let split (n:int) (b:bytes) = failwith "spec" : bytes * bytes
let xor (x:bytes) (y:bytes) = failwith "spec" : bytes
#endif

(* Key-dependent encryption
   - we first consider fixed-sized plaintexts;
     variable-sized plaintexts work well with relational formulas.
   - we consider a single key; we could instead pass the list of keys allocated so far.
   - once we have CPA, we can illustrate the use of this encryption in rpc.fs etc *)

(*
type htype = b:bytes{Length(b)=n} -> h:bytes{Length(h)=plainsize
*)

// let (||) x y : bytes = append x y
let keysize = 16
let plainsize = 128
let rsize = keysize


type hashed = bytes
type key = bytes
type plain = bytes  // {Length(b)=plainsize}
type cipher = bytes // {Length(b)=rsize+plainsize}

(* standard lists, for retyping *)
let rec mem xs (x:bytes) = 
  match xs with 
  | y::_ when x = y -> true
  | _::xs           -> mem xs x
  | []              -> false 
let rec assoc xzs (x:bytes) =
  match xzs with 
  | (y,z)::xzs when x = y -> Some (z:bytes)
  | _::xzs                -> assoc xzs x
  | []                    -> None 
let cons (x:hashed) (h:plain) xhs = (x,h)::xhs

let n = keysize + rsize // size of the domain of H
let HT = ref []         // sampled definition of H so far

let bad = ref false
let chi = ref []     // domain of H used secretly by the encryption 
let H x = 
  // we add this line in H1: 
  if mem !chi x then bad:=true  
  match assoc !HT x with 
  | Some(h) -> h
  | None -> 
      let h:plain = randomBytes plainsize
      HT:= cons x h !HT
      h

let gen() = randomBytes keysize
let K = gen()

let decrypt E = 
  let (R,C) = split plainsize E
  let P = H(K||R)
  xor C P

(*** the kdm main game ***)

type innerAdv = (plain -> plain) -> key -> plain 

let zero = zeroCreate plainsize

(* this is NOT typable, as it requires Sample *)
let randomMask (M:plain) = failwith "not yet": plain // randomBytes plainsize 

type leaker = key (* noref *) -> plain  
//take2
// type leaker = key{true} -> plain{true}  

let game (GEN,ENC) b adv =
  let k = GEN() 
  let log = ref [] // empty_log k 
  let enc (g:innerAdv) = // g must be typed as pure 
    let x0 = g H k       // added explicit access to H
    let x = if b then x0 else zero 
    let v = ENC k x in
    log := (v,x):: !log; v
  adv enc   
 
// Adv[a enc] =def= | Pr[ game true a = true ] - Pr[ game false a = true ] | 
// GOAL Adv[a enc] <= (Length !HT)^2 / 2^(rsize*8-2) 
// assuming that keysize >= rsize 

(*** concrete construction ***)

let cheat (M:plain) = failwith "not typable otherwise!": plain eq

let encrypt g = // (g: htype -> key -> plain {Pure(g)})  
  let M = g H K // g implicitly gets to call RO
  let R = randomBytes rsize
  let P = H(K||R) 
  R || cheat(xor M P) (* this rightfully fails to typecheck. *) 

(* we can typecheck that decrypt;encrypt(...) is identity on plaintexts *)

(*1* obtained by inlining H, and if we don't observe bad and chi,
     we give H1 to the external attacker but still H to the internal one 
     this is perfectly equivalent to: ***)

let encrypt1 g = // (g: htype -> key -> plain {Pure(g)}) 
  let M = g H K // g implicitly gets to call RO
  let R = randomBytes rsize
  let x = K||R 
  let C: plain eq = 
    match assoc !HT x with 
    | Some(P) -> 
        bad := true; cheat (xor M P) (*2*)
    | None -> 
        let P = randomMask M  
        HT:= (x,P)::!HT
        chi:= x::!chi
        xor M P in
   R || C

// guess: the fake game is obtained from the real one by using
// let fake g H K = let plain = g H K in zero

// we can bound the probability of bad happening from collisions, e.g.
// Pr[ ... | bad ] < length !HT 

(*2: encrypt2 is encrypt1 with zero instead of xor M P (*2*); 
     using an alias of sample with type

       val sample_shift: M:bytes{Length(M)=plainsize} -> 
                         P:bytes{Length(P)=plainsize /\ xor M0 P0 = xor M1 P1 }  

     we can give C the type

       C:bytes{Length(C)=plainsize /\ C0=C1 /\ (Bad \/ ...) }   *)
