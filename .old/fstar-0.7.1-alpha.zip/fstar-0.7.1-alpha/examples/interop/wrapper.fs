(* compilation (3):
   fsc -r bin\Seq.dll -r bin\FSeq.dll -o bin\wrapper.exe --platform:x86 wrapper.fs
   *)

module Wrapper
  open Sequence

  let l = Cons("f", Cons("st", Cons("ar OK!\n", Nil))) in
  let l2 = transtofst l in
  FSeq.printf_fst l2
  (* let l3 = Tofs.transtofs l2 
  printf_fs l3 *)
