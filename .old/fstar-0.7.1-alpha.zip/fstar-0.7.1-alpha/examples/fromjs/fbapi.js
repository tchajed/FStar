
/* for tests: */
function __inline(){}
function __sig(){}
function __type(){}
function setTag(t, o) {return o; }

/* end library */

__inline("type profile = {id: string; email: string; verified: bool; age_range: number}") 

function authRPC(url,func,args) {
    __sig("string", "string", "string", "string");
    return ""
}

function getProfile(b){
    __sig("bool", "profile");
    var resp = 
        authRPC("http://graph.facebook.com/me","GET","email,verified,age_range");__type("string");
    return setTag("profile", 
                  {"id":"1", "email":"f.com", "verified":true, "age_range":50}) ;
}

    
function fbapi(url){
    __sig("string","any");
    if (url === "/me") return (getProfile(true));
    else return {}
}

//var FB = {api:fbapi}
 
function test(x) {
  __sig("unit", "any");
  return fbapi("/me");
}
          
__end();
