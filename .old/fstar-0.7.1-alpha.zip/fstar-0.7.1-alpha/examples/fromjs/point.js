var __sig = function () { }
var __type = function () { }

__inline("type point = {x:mutable number; y: mutable number; setX: number -> unit}")

function Point(x, y) {
    __sig("number", "number", "point"); 

    var self = {}; __type("@any");
    
    self.x = x;
    self.y = y;
    
    self.setX = function(d) {
        __sig("number", "any");
        self.x = d;
    };
    return setTag("point", self);
}


function test(x) {
    __sig("unit", "any");
    var o = Point(0, 0); __type("@point");
    o.setX(17); 
    return o.x;
};
