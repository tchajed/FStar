/* We assume the following:
   window.postMessage: (any,string) => void [untampered, get from LIB object] 1*/

/* for tests: */
/*
var __sig = function(){}
var __type = function(){}
var __inline = function () {}
var window = {postMessage: function(m,o){console.log(o + " got message "+ m)}}
*/


function setTag (t,o) {return o;}
/* end library */

function checkOrigin (given,expected) {
    __sig("string", "string", "bool");
    return given === expected
}
    
function checkOrigins (given,expected) {
    __sig("string", "array string", "bool");
    var aout = false; __type("bool");
    for (var k in expected) {
        __type("string");
        var exp = setTag("string",expected[k]); __type("string");
        if (given === exp) aout = true;
    } 
    return aout;
}

function proxyMessageString (host,msg,origin){
    __sig("string","any","string","any");
    if (checkOrigin(host,origin)) window.postMessage(msg,host);
    else console.log("denied");
}

function proxyMessageArray(host,msg,origins){
    __sig("string","any","array string","any");
    if (checkOrigins(host,origins)) window.postMessage(msg,host);
    else console.log("denied");
}

/* Should fail, because we do not have a tight 
   enough type annotation on the else */
function checkOriginAny (given,expected) {
    __sig("string", "any", "bool");
    if (typeof expected === 'string') 
        return (checkOrigin(given,setTag("string", expected)));
    else return (checkOrigins(given, setTag("(array string)", expected)));
}


function proxyMessageAny (host,msg,origins){
    __sig("string","any","any","any");
    if (checkOriginAny(host,origins)) window.postMessage(msg,host);
    else console.log("denied");
}

function test(x) {
   __sig("unit", "any");
  proxyMessageString("honest.com","secret","honest.com");
};

/* Tests (how do we annotate these?) */
/*

let test(): any =
  let origins = newArray string () in
  let _ = writeArray origins 0 "honest.com" in
  let _ = writeArray origins 1 "other.com" in
  (* proxyMessageString "honest.com" "secret" "honest.com" *)
  (* proxyMessageString "evil.com" "secret" "honest.com" *)
  (* proxyMessageAny "evil.com" "secret" "honest.com"*)
  proxyMessageAny "honest.com" "secret" origins

var test1 = proxyMessageString("honest.com","secret","honest.com");    
var test2 = proxyMessageString("evil.com","secret","honest.com");    

var test3 = proxyMessageArray("honest.com","secret",["honest.com","other.com"]);    
var test4 = proxyMessageArray("evil.com","secret",["honest.com","other.com"]);    
var test5 = proxyMessageAny("honest.com","secret","honest.com");    
var test6 = proxyMessageAny("evil.com","secret","honest.com");    

var test7 = proxyMessageAny("honest.com","secret",["honest.com","other.com"]);    
var test8 = proxyMessageAny("evil.com","secret",["honest.com","other.com"]);    

var testbad1 = proxyMessageArray("o","secret","honest.com");    

var testbad2 = proxyMessageAny("o","secret","honest.com");    
*/
