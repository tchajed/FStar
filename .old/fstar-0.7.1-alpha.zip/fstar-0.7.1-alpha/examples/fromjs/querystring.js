/* We assume the following:
   window.encodeURIComponent: string => string [untampered, get from LIB object] 
   String.split: (string,string) => string[] [defined in LIB]
   String.concat: (string,string) => string [defined in LIB]
   getFields: any  => string[]   [defined in Q?]
   setTag: string => any => any  [defined in Q?]
   we assume that 
      o[k] translates to getFieldValue(o,k)  [defined in Q?]
   and o[k] = v translates to setFieldValue(o,k,v)[defined in Q?]
 */

/* for tests: */
var __sig = function(){}
var __type = function(){}

var window = {encodeURIComponent: function(s){return s}}
var String = {split: function(orig,delim){return orig.split(delim)},
              concat: function(s1,s2){return s1+s2}}
    
function getFields(o){
    var res = [];
    var k;
    for (k in o) res.push(k);
    return res}

function setTag (t,o) {return o;}
/* end library */

function encode (bag){
    __sig("any","string");
    var res = ""; __type("string");
    for (var k in bag) {
        __type("string");
        var v = setTag("string",bag[k]); __type("@string");
        var s = String.concat(k,String.concat("=",v)); __type("@string");
        if (res === "") res = String.concat(res,s);
        else res = String.concat(res, String.concat("&",s));
    };
    return res}

function decode (s){
    __sig("string","any");
    var res = {}; __type("any");
    if (s === "") return res;
    else {
        var params = String.split(s,"&"); __type("@any");
        for (var k in params) {
            __type("string");
            var kv = String.split(setTag("string", params[k]),"="); __type("@any");
            res[kv[0]] = kv[1];
        }
        return res;
    }
}

function test(x) {
  __sig("unit", "any");
  encode({"a":"1","b":"2"});
}
__end();

var o = {"a":"1","b":"2"}

var test1 = console.log(encode (o))
var test2 = console.log(decode(encode(o)));
