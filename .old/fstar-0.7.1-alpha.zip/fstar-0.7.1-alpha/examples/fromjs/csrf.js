/* We assume:
   xhr_get: string -> string                  [frozen in LIB]
*/

/* for tests: */
var __sig = function(){}
var __type = function(){}

var String = {
    concat : function(s1,s2){return s1 + s2},
    startsWith: function (s1,s2) {
      if (s1.length < s2.length) return false;
      var i;
      for (i = 0; i < s1.length; i++) {
          if (s1[i] !== s2[i]) return false
      }
      return true},
    noQueryHash: function (s) {
      var i;
      for (i = 0; i < s.length; i++) {
          if (s[i] === "?" || s[i] === "#") return false
      }
      return true;
    }}
function setTag (t,o) {return o;}    
/* end library */

function encode (bag){
    __sig("any","string");
    var res = ""; __type("string");
    for (var k in bag) {
        __type("string");
        var v = setTag("string",bag[k]); __type("@string");
        var s = String.concat(k,String.concat("=",v)); __type("@string");
        if (res === "") res = String.concat(res,s);
        else res = String.concat(res, String.concat("&",s));
    };
    return res}

var csrfToken = "%GENERATED_TOKEN%"; 
var targetOrigin = "%TARGET_ORIGIN%";

function xhrGet(url) {
    __sig("string","string");
    return url;
}

function authRpc(url,apifun,args) {
    __sig("string","string","string","string");
    if (String.startsWith(url,String.concat(targetOrigin,"/")) &&
        String.noQueryHash(url)) {
        var m = {methd:apifun, args:args, token: csrfToken}; __type("any");
        var msg = encode(m); __type("string");
        return xhrGet(String.concat(url,String.concat("?",msg)))
        }
    else return "unauthorized URL"
}

function test(x) {
  __sig("unit", "string");
  return authRpc("%TARGET_ORIGIN%/","f","1");
}

__end();

var test1 = console.log(authRpc("%TARGET_ORIGIN%/","f","1"))
var test2 = console.log(authRpc("evil.com/","f","1"))
var test3 = console.log(authRpc("%TARGET_ORIGIN%/#","f","1"))
var test3 = console.log(authRpc("%TARGET_ORIGIN%/?token=1&","f","1"));

/*
val test:unit -> any
let test() : any = authRpc "%TARGET_ORIGIN%/" "f" "1"
authRpc "evil.com/" "f" "1"
authRpc "%TARGET_ORIGIN%/#" "f" "1"
authRpc "%TARGET_ORIGIN%/?token=1&" "f" "1"
*/
